


#===================================================================================
#===================================================================================

"""
@router.post("/upfile/")
async def create_upload_files( files: list[UploadFile] = File(...)):
    try:
        filesID =[]
        dir_path = os.path.dirname(os.path.realpath(__file__))
        fp = os.path.join(dir_path, os.pardir, os.pardir, 'upload')
        isDirectory = os.path.isdir(fp)
        if isDirectory == False:
            os.mkdir(fp)
        for file in files:
            filename = str(uuid.uuid4())
            extension = file.filename.split('.')[-1]
            fp = os.path.join(dir_path, os.pardir, os.pardir,
                              'upload', filename+'.'+extension)
            destination_file_path = fp
            async with aiofiles.open(destination_file_path, 'wb') as out_file:
                # async read file chunk
                while content := await file.read(1024):
                    await out_file.write(content)  # async write file chunk
            file_size = os.path.getsize(fp)
            ##==============>    save file in db
            now = datetime.now()
            new_id = db.upload.insert(
                file_name=file.filename,
                file_type=extension,
                file_size=file_size ,
                file_date=now,
                file_save_name=filename+'.'+extension,
            )
            filesID.append(new_id)
        db.commit()
        return {"files": filesID }
    except Exception as e:
        db.rollback()
        return {'err': str(e)}


@router.delete("/{row_id}", status_code=204)
def delete(row_id: int, response: Response,
           current_user: TokenData = Depends(oauth2.get_current_user)
           ):
    try:
        usr = current_user.username
        #acc = users.chkAccess(usr, '019002', 'can_delete')
        #if acc == 0:
        #    response.status_code = status.HTTP_401_UNAUTHORIZED
        #    return {}
        row = db.upload[row_id]
        dir_path = os.path.dirname(os.path.realpath(__file__))
        fname = os.path.join(dir_path, os.pardir, os.pardir,
                          'upload', row.file_save_name)
        os.remove(fname)
        #assert exists(fname)
        #aiofiles.os.remove(fname)
        #assert exists(fname) is False
        row.delete_record()
        db.commit()
        return {'msg': 'deleted'}
    except Exception as e:
        print(e)
        db.rollback()
        return {'err': str(e)}
"""

# @router.post("/uploadfile/")
# async def create_upload_file(file: UploadFile):
#     return {"filename": file.filename}


# @router.post("/u1/")
# async def create_file(data: dict ):
#     print(data)
#     return {"Result": "OK"}


# @router.post("/u2/{disc}/{screen}/{id}")
# async def create_upload_files(disc: str, screen: str, id: int,data:dict , files: list[UploadFile] = File(...)  ):
#     try :
#         print(data)
#         dir_path = os.path.dirname(os.path.realpath(__file__))
#         fp = os.path.join(dir_path, os.pardir, os.pardir, 'upload')
#         isDirectory = os.path.isdir(fp)
#         if isDirectory ==False :
#             os.mkdir(fp)
#         for file in files:        
#             filename = str(uuid.uuid4())
#             extension = file.filename.split('.')[-1]
#             print(filename)
#             print(extension)
#             fp = os.path.join(dir_path, os.pardir, os.pardir,
#                             'upload', filename+'.'+extension)
#             destination_file_path = fp # +'/' + file.filename  # output file path
#             print(file.filename)
#             print(destination_file_path)
#             async with aiofiles.open(destination_file_path, 'wb') as out_file:
#                 while content := await file.read(1024):  # async read file chunk
#                     await out_file.write(content)  # async write file chunk
#             ## save file in db 
#             now = datetime.now()
#             new_id = db.upload.insert(
#                 disc=disc,
#                 screen=screen,
#                 screen_id=id ,
#                 file_name=file.filename,
#                 file_type=extension,
#                 file_size=555 , 
#                 file_date=now ,
#                 file_save_name=filename+'.'+extension,
#             )
#             db.commit()
#         return {"Result": "OK", "filenames": [file.filename for file in files]}
#     except Exception as e:
#         print(e)
#         db.rollback()
#         return {'err': str(e)}


#https://stackoverflow.com/questions/63048825/how-to-upload-file-using-fastapi
#https://www.tutorialsbuddy.com/python-fastapi-upload-files
#https://www.tutorialsbuddy.com/python-fastapi-download-files


"""
@router.post("/u1/")
async def create_file(file: UploadFile = File(...)):
    print(file)
    print(file.filename)
    print("filename = ", file.filename)  # getting filename
    destination_file_path = "d://upload/" + \
         file.filename  # location to store file
    async with aiofiles.open(destination_file_path, 'wb') as out_file:
        while content := await file.read(1024):  # async read file chunk
            await out_file.write(content)  # async write file chunk
    return {"Result": "OK"}
"""