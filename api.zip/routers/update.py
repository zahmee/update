# routers/update.py
# -*- coding: utf-8 -*-
# --type: ignore

from fastapi import APIRouter, Request, HTTPException
from datetime import datetime, timezone
from pathlib import Path
import asyncio
import urllib.request
import zipfile
import os
import shlex
import subprocess
import logging


router = APIRouter(prefix="/update", tags=["update API"])


@router.get("/", summary="Update application from remote zip")
async def up(request: Request):
    current_file = Path(__file__)
    app_path = current_file.resolve().parent.parent
    url = "https://github.com/zahmee/update/raw/refs/heads/main/api.zip"
    saved_file = app_path / "li.zip"

    def download_and_extract():
        urllib.request.urlretrieve(url, saved_file)
        with zipfile.ZipFile(saved_file, "r") as zf:
            zf.extractall(app_path)
        try:
            saved_file.unlink(missing_ok=True)
        except TypeError:
            # Python <3.8 compatibility: ignore if missing_ok not supported
            if saved_file.exists():
                saved_file.unlink()

    try:
        await asyncio.to_thread(download_and_extract)
        # perform the specific restart command requested by user
        restart_cmd = "sudo systemctl restart fastapi_app"

        def run_cmd(cmd):
            try:
                proc = subprocess.run(shlex.split(cmd), capture_output=True, text=True, timeout=60)
                return proc.returncode, proc.stdout, proc.stderr
            except Exception as ex:
                return -1, "", str(ex)

        rc, out, err = await asyncio.to_thread(run_cmd, restart_cmd)
        restart_result = {
            "performed": rc == 0,
            "command": restart_cmd,
            "returncode": rc,
            "output": out,
            "error": err,
        }

        return {
            "status": "success",
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "app_path": str(app_path),
            "restart": restart_result,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"update failed: {e}")