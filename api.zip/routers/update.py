# routers/update.py
# -*- coding: utf-8 -*-
# --type: ignore

from fastapi import APIRouter, Request, HTTPException
from datetime import datetime, timezone
from pathlib import Path
import asyncio
import urllib.request
import zipfile
import os
import shlex
import subprocess
import logging


router = APIRouter(prefix="/update", tags=["update API"])


@router.get("/", summary="Update application from remote zip")
async def up(request: Request):
    current_file = Path(__file__)
    app_path = current_file.resolve().parent.parent
    url = "https://github.com/zahmee/update/raw/refs/heads/main/api.zip"
    saved_file = app_path / "li.zip"

    def download_and_extract():
        urllib.request.urlretrieve(url, saved_file)
        with zipfile.ZipFile(saved_file, "r") as zf:
            zf.extractall(app_path)
        try:
            saved_file.unlink(missing_ok=True)
        except TypeError:
            # Python <3.8 compatibility: ignore if missing_ok not supported
            if saved_file.exists():
                saved_file.unlink()

    try:
        await asyncio.to_thread(download_and_extract)
        # attempt service restart (best-effort)
        restart_result = {
            "performed": False,
            "command": None,
            "output": None,
            "error": None,
        }

        async def try_restart():
            # Priority: explicit command via env, then service name via systemctl/service, then supervisor
            cmd_env = os.getenv("systemctl restart fastapi_app")
            svc_name = os.getenv("fastapi_app")
            supervisor_name = os.getenv("zahmee")

            def run_cmd(cmd):
                try:
                    proc = subprocess.run(shlex.split(cmd), capture_output=True, text=True, timeout=60)
                    return (proc.returncode, proc.stdout, proc.stderr)
                except Exception as ex:
                    return (-1, "", str(ex))

            # explicit command
            if cmd_env:
                restart_result["command"] = cmd_env
                rc, out, err = await asyncio.to_thread(run_cmd, cmd_env)
                restart_result.update({"performed": rc == 0, "output": out, "error": err})
                return

            # systemd service
            if svc_name:
                for c in (f"systemctl restart {svc_name}", f"service {svc_name} restart"):
                    restart_result["command"] = c
                    rc, out, err = await asyncio.to_thread(run_cmd, c)
                    restart_result.update({"performed": rc == 0, "output": out, "error": err})
                    if rc == 0:
                        return

            # supervisor
            if supervisor_name:
                c = f"supervisorctl restart {supervisor_name}"
                restart_result["command"] = c
                rc, out, err = await asyncio.to_thread(run_cmd, c)
                restart_result.update({"performed": rc == 0, "output": out, "error": err})
                return

            # nothing configured -> do not restart automatically
            restart_result["error"] = "no restart command or service name configured (use FASTAPI_RESTART_CMD or FASTAPI_SERVICE_NAME)"

        try:
            await try_restart()
        except Exception as re:
            logging.exception("restart failed")
            restart_result.update({"performed": False, "error": str(re)})

        return {
            "status": "success",
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "app_path": str(app_path),
            "restart": restart_result,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"update failed: {e}")