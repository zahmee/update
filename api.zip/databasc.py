from pymongo import AsyncMongoClient
from beanie import init_beanie
from models import ClientsCSR_log, OnBoarding_log, Send_Invoice

MONGO_URI="mongodb://localhost:27017"

async def init_db():
    client = AsyncMongoClient(MONGO_URI)
    await init_beanie(database=client.zatca_vase2, document_models=[ClientsCSR_log, OnBoarding_log, Send_Invoice])
    print("Database initialized")
