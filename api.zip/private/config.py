from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_name                        :          str  = "KOOD"
    SEC_SECRET_KEY                  :          str  = "Ah5445Za@ahmEE!@-?."
    SEC_ACCESS_TOKEN_EXPIRE_MINUTES :          int  = 60*24*30
    DB_uri                          :          str = "postgres://admin:5445za@localhost:5432/kood" #"sqlite: // db.sqlite"
    DB_migrate                      :          bool = True
    DB_pool_size                    :          int  = 10
