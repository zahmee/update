from typing import Optional
from pymongo import AsyncMongoClient
from pydantic import BaseModel
from beanie import Document, Indexed, init_beanie
from datetime import datetime, timezone


class ClientsCSR_log(Document):
    environmentType: Optional[str]
    C: Optional[str] = "SA"
    O: Optional[str]
    OU: Optional[str]
    CN: Optional[str]
    VAT: Optional[str]
    CRN: Optional[str]
    ADDRESS: Optional[str]
    CATEGORY: Optional[str]
    TITLE: Optional[str]
    OTP: Optional[str]
    complianceCsidUrl: Optional[str]
    complianceChecksUrl: Optional[str]
    productionCsidUrl: Optional[str]
    reportingUrl: Optional[str]
    clearanceUrl: Optional[str]
    # clientIP: Optional[str]= None
    responce_data: Optional[dict] = None
    created_at: datetime = datetime.now(timezone.utc)

    class Settings:
        name = "clients_csr_log"  # Collection name in MongoDB


class OnBoarding_log(Document):
    environmentType: Optional[str]
    C: Optional[str] = "SA"
    O: Optional[str]
    OU: Optional[str]
    CN: Optional[str]
    VAT: Optional[str]
    CRN: Optional[str]
    ADDRESS: Optional[str]
    CATEGORY: Optional[str]
    TITLE: Optional[str]
    OTP: Optional[str]
    complianceCsidUrl: Optional[str]
    complianceChecksUrl: Optional[str]
    productionCsidUrl: Optional[str]
    reportingUrl: Optional[str]
    clearanceUrl: Optional[str]
    privateKey: Optional[str]
    csr: Optional[str]
    csr_src: Optional[str]
    egs_uuid: Optional[str]
    ccsid_requestID: Optional[int]
    ccsid_binarySecurityToken: Optional[str]
    ccsid_secret: Optional[str]
    pcsid_requestID          : Optional[int] 
    pcsid_binarySecurityToken: Optional[str] 
    pcsid_secret             : Optional[str] 
    created_at: datetime = datetime.now(timezone.utc)
    compliance_check_results: Optional[list] = None

    class Settings:
        name = "onboarding_log"  # Collection name in MongoDB


class Send_Invoice(Document):
    VAT: Optional[str]
    send_data: Optional[dict] = None
    responce_data: Optional[dict] = None
    created_at: datetime = datetime.now(timezone.utc)

    class Settings:
        name = "send_invoice"  # Collection name in MongoDB
