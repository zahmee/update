import logging

import requests
import uvicorn
from datetime import datetime
from contextlib import asynccontextmanager
from fastapi import APIRouter, Depends, FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from starlette.staticfiles import StaticFiles
import pathlib
from databasc import init_db
from zatca import zatca_csr, zatca_send_invoce, zatca_send_test_invoces , reporting , create_xml
from routers import update
@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield
    # Shutdown code here


logging.basicConfig(
    filename="logg.log",
    filemode="w",
    format="%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.DEBUG,
)

logging.info("-------------- Start Application ---------------- ")

app = FastAPI(lifespan=lifespan, title="ZATCA VASE 2 API", version="1.0.0")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# @app.middleware("http")
# async def add_process_time_header(request: Request, call_next):
#     start_time = time.time()
#     response = await call_next(request)
#     response.headers["X-Process-Time"] = str(time.time() - start_time)
#     return response


# ========================================================================
# ----------------------   start up api       ----------------------------
# ========================================================================
@app.get("/")
def index(request: Request):
    app_path = pathlib.Path(__file__).resolve().parent
    local_file = app_path / "zatc_api.txt"

    def parse_ver(v):
        try:
            return float(v)
        except Exception:
            return v

    # read local version (from zatc_api.txt) if present
    if local_file.exists():
        try:
            local_text = local_file.read_text(encoding="utf-8").strip()
            local_ver = parse_ver(local_text)
        except Exception:
            local_ver = app.version if hasattr(app, "version") else "unknown"
    else:
        local_ver = app.version if hasattr(app, "version") else "unknown"

    # try fetching remote version for comparison (best-effort)
    remote_ver = None
    try:
        url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/zatc_api.txt"
        resp = requests.get(url, timeout=5)
        if resp.ok:
            remote_ver = parse_ver(resp.text.strip())
    except Exception:
        remote_ver = None

    # determine if update is needed (only when both numeric)
    need_update = None
    try:
        if isinstance(local_ver, float) and isinstance(remote_ver, float):
            need_update = remote_ver > local_ver
    except Exception:
        need_update = None

    info = {
        "app": "zatca vase 2 fastapi by zahmee",
        "running_version": local_ver,
        "remote_version": remote_ver,
        "need_update": need_update,
        "date": "2025-12-10",
        "Developer": "Ebdae Development and Programming",
        "tel": "966502010911",
        "website": "cdit.co",
        "programming language": "Python",
        "environment": "FastAPI",
        "server_datetime": datetime.now().isoformat(),
    }

    if need_update:
        info["update_link"] = str(request.base_url) + "update"

    return info
app.mount("/site", StaticFiles(directory="public", html=True), name="site")
app.include_router(zatca_csr.router)
app.include_router(zatca_send_test_invoces.router)
app.include_router(zatca_send_invoce.router)
app.include_router(reporting.router)
app.include_router(create_xml.router)
app.include_router(update.router)
# app.include_router(users.router)
# app.include_router(setting.router)


# app.mount('/files', app=StaticFiles(directory='private\\upload'), name="files")


# run on localhost
# uvicorn.run(app, host="127.0.0.1" , port=8011)
