import base64
import hashlib
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

# مسار ملف الفاتورة
INVOICE_XML_PATH = "output_invoice.xml"

# نيمسبيسات UBL/ZATCA الشائعة
NS = {
    "ubl": "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
    "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
    "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
    "ext": "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2",
    "ds": "http://www.w3.org/2000/09/xmldsig#",
}


def tlv_encode(tag: int, value_bytes: bytes) -> bytes:
    """
    يبني حقل TLV واحد:
    Tag: بايت واحد
    Length: طول القيمة (بايت واحد)
    Value: نفس البايتات
    """
    if len(value_bytes) > 255:
        raise ValueError(
            f"قيمة التاق {tag} أطول من 255 بايت، زاتكا تتوقع طول بايت واحد للـ Length."
        )
    return bytes([tag, len(value_bytes)]) + value_bytes


def get_text(elem):
    return (elem.text or "").strip() if elem is not None and elem.text else ""


def parse_invoice(xml_path: str):
    tree = ET.parse(xml_path)
    root = tree.getroot()

    # 1️⃣ اسم البائع
    supplier_name = get_text(
        root.find(
            ".//cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName",
            NS,
        )
    )
    if not supplier_name:
        raise ValueError("لم يتم العثور على اسم البائع (RegistrationName) في الفاتورة.")

    # 2️⃣ رقم تسجيل ضريبة القيمة المضافة للبائع
    supplier_vat = get_text(
        root.find(
            ".//cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID",
            NS,
        )
    )
    if not supplier_vat:
        raise ValueError(
            "لم يتم العثور على رقم تسجيل ضريبة القيمة المضافة للبائع (CompanyID) في الفاتورة."
        )

    # 3️⃣ التاريخ والوقت (IssueDate + IssueTime)
    issue_date = get_text(root.find("./cbc:IssueDate", NS))
    issue_time = get_text(root.find("./cbc:IssueTime", NS))
    if not issue_date:
        raise ValueError("لم يتم العثور على IssueDate في الفاتورة.")
    # لو الوقت غير موجود، نعتبره 00:00:00
    if not issue_time:
        issue_time = "00:00:00"
    # بإمكانك تعديلها لإضافة +03:00 إذا حاب بصيغة كاملة
    timestamp = f"{issue_date}T{issue_time}"

    # 4️⃣ إجمالي الفاتورة (مع الضريبة) - نستخدم TaxInclusiveAmount حسب دليل زاتكا
    tax_inclusive = root.find(".//cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount", NS)
    if tax_inclusive is None or not get_text(tax_inclusive):
        # بديل: PayableAmount إذا احتجت
        payable = root.find(".//cac:LegalMonetaryTotal/cbc:PayableAmount", NS)
        if payable is None or not get_text(payable):
            raise ValueError(
                "لم يتم العثور على إجمالي الفاتورة مع الضريبة (TaxInclusiveAmount/PayableAmount)."
            )
        total_with_vat = get_text(payable)
    else:
        total_with_vat = get_text(tax_inclusive)

    # 5️⃣ إجمالي ضريبة القيمة المضافة - أول TaxTotal على مستوى الهيدر
    vat_total_elem = root.find("./cac:TaxTotal/cbc:TaxAmount", NS)
    if vat_total_elem is None or not get_text(vat_total_elem):
        # محاولة أخرى من أول TaxTotal تحت الجذر
        vat_total_elem = root.find(".//cac:TaxTotal/cbc:TaxAmount", NS)
    if vat_total_elem is None or not get_text(vat_total_elem):
        raise ValueError(
            "لم يتم العثور على إجمالي الضريبة (TaxTotal/TaxAmount) في الفاتورة."
        )
    vat_total = get_text(vat_total_elem)

    # 6️⃣ Hash XML invoice (PIH) من AdditionalDocumentReference ID=PIH
    xml_hash_bytes = None
    for adr in root.findall(".//cac:AdditionalDocumentReference", NS):
        doc_id = get_text(adr.find("./cbc:ID", NS))
        if doc_id == "PIH":
            emb = adr.find(".//cbc:EmbeddedDocumentBinaryObject", NS)
            if emb is not None and get_text(emb):
                # قيمة الـ PIH في الغالب Base64 للهاش (32 بايت SHA256)
                try:
                    xml_hash_bytes = base64.b64decode(get_text(emb))
                except Exception:
                    # لو ليست Base64 نفترض أنها HEX
                    xml_hash_bytes = bytes.fromhex(get_text(emb))
            break

    if xml_hash_bytes is None:
        # بديل: حساب الهاش من محتوى XML بالكامل (حسب دليل Security Features)
        # ⚠ تأكد من مطابقة أسلوب canonicalization المستخدم عند التوقيع الحقيقي
        xml_bytes = Path(xml_path).read_bytes()
        xml_hash_bytes = hashlib.sha256(xml_bytes).digest()

    # 7️⃣ توقيع ECDSA للفاتورة (SignatureValue) - يجب أن يكون موجود بعد التوقيع
    # سيبحث داخل UBLExtensions/ds:SignatureValue أو أي مكان قياسي
    signature_value_bytes = None
    sig_val = root.find(".//ds:SignatureValue", NS)
    if sig_val is not None and get_text(sig_val):
        # غالباً Base64 -> نحول إلى bytes
        signature_value_bytes = base64.b64decode(get_text(sig_val))

    if signature_value_bytes is None:
        raise ValueError(
            "لم يتم العثور على توقيع ECDSA داخل الفاتورة (ds:SignatureValue). "
            "أكمل خطوة التوقيع بختم التشفير (CSID) ثم أعد توليد QR."
        )

    # 8️⃣ المفتاح العام (ECDSA public key) المستخدم في التوقيع
    # غالباً موجود داخل X509Certificate
    public_key_bytes = None
    cert_elem = root.find(".//ds:X509Certificate", NS)
    if cert_elem is not None and get_text(cert_elem):
        # هنا نضع الشهادة كما هي (DER) أو تستخرج منها المفتاح العام حسب التفسير؛
        # في معظم تطبيقات زاتكا، يتم وضع الـ CSID cert أو المفتاح حسب دليل الأمن.
        public_key_bytes = base64.b64decode(get_text(cert_elem))

    if public_key_bytes is None:
        raise ValueError(
            "لم يتم العثور على الشهادة/المفتاح العام (ds:X509Certificate) داخل الفاتورة لاستخدامه في التاق 8."
        )

    # 9️⃣ توقيع/شهادة CSID من ZATCA (للـ Simplified)
    # في تطبيقات كثيرة يتم استخدام شهادة CSID نفسها أو توقيع الـ public key من ZATCA.
    # نفترض هنا وجودها كـ X509Certificate آخر أو EmbeddedDocumentBinaryObject.
    csid_sig_bytes = None

    # محاولة إيجاد CSID ضمن UBLExtensions أو AdditionalDocumentReference
    for emb in root.findall(".//cbc:EmbeddedDocumentBinaryObject", NS):
        # يمكنك هنا تمييز حقل CSID باسم الملف أو الـ mimeCode حسب تصميمك
        # مؤقتاً: نستخدم أول EmbeddedDocumentBinaryObject غير الـ PIH إذا احتجنا
        parent_id = (
            emb.getparent().find("../cbc:ID") if hasattr(emb, "getparent") else None
        )
        _ = parent_id  # لسلامة الكود في حال عدم دعم getparent في ElementTree

    # في هذا السكربت، لو ما عرفنا نجيب CSID/التوقيع من XML نرمي خطأ واضح
    if csid_sig_bytes is None:
        raise ValueError(
            "Tag 9 (توقيع/شهادة CSID من ZATCA) غير موجودة في XML. "
            "يجب تضمين شهادة CSID/التوقيع في الفاتورة أولاً حسب مواصفات ZATCA."
        )

    return {
        "seller_name": supplier_name,
        "seller_vat": supplier_vat,
        "timestamp": timestamp,
        "total_with_vat": total_with_vat,
        "vat_total": vat_total,
        "xml_hash": xml_hash_bytes,
        "signature": signature_value_bytes,
        "public_key": public_key_bytes,
        "csid_signature": csid_sig_bytes,
    }


def build_qr_base64_from_invoice(xml_path: str) -> str:
    data = parse_invoice(xml_path)

    tlv_bytes = b""
    # Tags 1-5 كنص UTF-8
    tlv_bytes += tlv_encode(1, data["seller_name"].encode("utf-8"))
    tlv_bytes += tlv_encode(2, data["seller_vat"].encode("utf-8"))
    tlv_bytes += tlv_encode(3, data["timestamp"].encode("utf-8"))
    tlv_bytes += tlv_encode(4, data["total_with_vat"].encode("utf-8"))
    tlv_bytes += tlv_encode(5, data["vat_total"].encode("utf-8"))

    # Tag 6: Hash of XML invoice (بايتات مباشرة)
    tlv_bytes += tlv_encode(6, data["xml_hash"])

    # Tag 7: ECDSA signature (بايتات مباشرة)
    tlv_bytes += tlv_encode(7, data["signature"])

    # Tag 8: ECDSA public key (أو شهادة/Key bytes)
    tlv_bytes += tlv_encode(8, data["public_key"])

    # Tag 9: CSID signature / certificate bytes
    tlv_bytes += tlv_encode(9, data["csid_signature"])

    # QR النهائي = Base64 لـ TLV
    qr_base64 = base64.b64encode(tlv_bytes).decode("utf-8")
    return qr_base64


if __name__ == "__main__":
    xml_path = INVOICE_XML_PATH
    if len(sys.argv) > 1:
        xml_path = sys.argv[1]

    qr_value = build_qr_base64_from_invoice(xml_path)
    print(qr_value)
