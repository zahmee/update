# routers/zatca_invoices.py
# -*- coding: utf-8 -*-
# --type: ignore

from __future__ import annotations
from typing import List, Optional, Literal
from enum import Enum
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
import json, base64, time
from lxml import etree  # type: ignore
from models import Send_Invoice
from zatca.utilities.api_helper import api_helper
from zatca.utilities.invoice_helper import invoice_helper
from zatca.utilities.einvoice_signer import einvoice_signer
from zatca.create_xml import InvoiceData , gen_invoice_file
from zatca.utilities.get_qr_from_request import extract_qr_from_invoice
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

router = APIRouter(prefix="/zatca", tags=["ZATCA Invoices"])

# -----------------------------
# نماذج الإدخال/الإخراج
# -----------------------------


class DocumentType(str, Enum):
    STDSI = "STDSI"  # Standard Invoice        -> 388
    STDCN = "STDCN"  # Standard Credit Note    -> 383
    STDDN = "STDDN"  # Standard Debit  Note    -> 381
    SIMSI = "SIMSI"  # Simplified Invoice      -> 388
    SIMCN = "SIMCN"  # Simplified Credit Note  -> 383
    SIMDN = "SIMDN"  # Simplified Debit  Note  -> 381   


DOC_TYPE_MATRIX = {
    "STDSI": ("388", "Standard Invoice", ""),
    "STDCN": ("383", "Standard CreditNote", "InstructionNotes for Standard CreditNote"),
    "STDDN": ("381", "Standard DebitNote", "InstructionNotes for Standard DebitNote"),
    "SIMSI": ("388", "Simplified Invoice", ""),
    "SIMCN": (
        "383",
        "Simplified CreditNote",
        "InstructionNotes for Simplified CreditNote",
    ),
    "SIMDN": (
        "381",
        "Simplified DebitNote",
        "InstructionNotes for Simplified DebitNote",
    ),
}


class CertInfo(BaseModel):
    # محتوى user_pass_zatca.json المرغوب تمريره مباشرة
    privateKey: str = Field(
        "MHQCAQEEIL5YbLEf7/MGaw6s7mkddA25Rhk4aQj12NC8QdXJZLweoAcGBSuBBAAKoUQDQgAEJ2fEpV4Syt4bYb0jTrryyrtao/fJsgkCy1dmfeN7eYjenPYXnIB0Ogwp65thA+CPZpL9MOK3VJZqugmBlkHrVQ=="
    )
    csr: str = Field(
        "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURSBSRVFVRVNULS0tLS0NCk1JSUIvRENDQWFNQ0FRQXdUekVMTUFrR0ExVUVCaE1DVTBFeEZUQVRCZ05WQkFvTURHVmlaR0V0ZEdGMGQyVmwNCmNqRVVNQklHQTFVRUN3d0xTVlFnVTJWeWRtbGpaWE14RXpBUkJnTlZCQU1NQ2pVNE5UVXpOVE0xTnpFd1ZqQVENCkJnY3Foa2pPUFFJQkJnVXJnUVFBQ2dOQ0FBUW5aOFNsWGhMSzNodGh2U05PdXZMS3UxcWo5OG15Q1FMTFYyWjkNCjQzdDVpTjZjOWhlY2dIUTZEQ25ybTJFRDRJOW1rdjB3NHJkVWxtcTZDWUdXUWV0Vm9JSDBNSUh4QmdrcWhraUcNCjl3MEJDUTR4Z2VNd2dlQXdKQVlKS3dZQkJBR0NOeFFDQkJjVEZWQlNSVnBCVkVOQkxVTnZaR1V0VTJsbmJtbHUNClp6Q0J0d1lEVlIwUkJJR3ZNSUdzcElHcE1JR21NVTR3VEFZRFZRUUVERVV4TFRNeE1ESXpNakkyTmpRd01EQXcNCk0zd3lMVFU0TlRVek5UTTFOekY4TXkwMFlqZGtZVGMyTUMwMVlqazRMVFEwWm1JdE9XUmtNaTB3WVdVd1lqVmwNCllqazVOVGt4SHpBZEJnb0praWFKay9Jc1pBRUJEQTh6TVRBeU16SXlOalkwTURBd01ETXhEVEFMQmdOVkJBd00NCkJERXhNREF4RHpBTkJnTlZCQm9NQmxKcGVXRmthREVUTUJFR0ExVUVEd3dLVkdWamFHNXZiRzluZVRBS0JnZ3ENCmhrak9QUVFEQWdOSEFEQkVBaUFZOWRNVWxaWVk1THNkVzBOV2d6QTRxYzV0VlFSbTJ3ZVJ3dTRMcUZwODNBSWcNCmEwYks5MTRQOVAvbnEzUGdEQld3SERFV1BHSXFSSjFWbmZ5QWcyNVdybGc9DQotLS0tLUVORCBDRVJUSUZJQ0FURSBSRVFVRVNULS0tLS0NCg=="
    )

    pcsid_binarySecurityToken: str = Field(
        "TUlJRS96Q0NCS1NnQXdJQkFnSVRFd0FBZm8yclBiRzkySlBqdmdBQkFBQitqVEFLQmdncWhrak9QUVFEQWpCaU1SVXdFd1lLQ1pJbWlaUHlMR1FCR1JZRmJHOWpZV3d4RXpBUkJnb0praWFKay9Jc1pBRVpGZ05uYjNZeEZ6QVZCZ29Ka2lhSmsvSXNaQUVaRmdkbGVIUm5ZWHAwTVJzd0dRWURWUVFERXhKUVJWcEZTVTVXVDBsRFJWTkRRVEl0UTBFd0hoY05NalV4TURJNE1qQTFNakkwV2hjTk1qY3hNREk0TWpFd01qSTBXakJQTVFzd0NRWURWUVFHRXdKVFFURVZNQk1HQTFVRUNoTU1aV0prWVMxMFlYUjNaV1Z5TVJRd0VnWURWUVFMRXd0SlZDQlRaWEoyYVdObGN6RVRNQkVHQTFVRUF4TUtOVGcxTlRNMU16VTNNVEJXTUJBR0J5cUdTTTQ5QWdFR0JTdUJCQUFLQTBJQUJDZG54S1ZlRXNyZUcyRzlJMDY2OHNxN1dxUDN5YklKQXN0WFpuM2plM21JM3B6MkY1eUFkRG9NS2V1YllRUGdqMmFTL1REaXQxU1dhcm9KZ1paQjYxV2pnZ05OTUlJRFNUQ0J0d1lEVlIwUkJJR3ZNSUdzcElHcE1JR21NVTR3VEFZRFZRUUVERVV4TFRNeE1ESXpNakkyTmpRd01EQXdNM3d5TFRVNE5UVXpOVE0xTnpGOE15MDBZamRrWVRjMk1DMDFZams0TFRRMFptSXRPV1JrTWkwd1lXVXdZalZsWWprNU5Ua3hIekFkQmdvSmtpYUprL0lzWkFFQkRBOHpNVEF5TXpJeU5qWTBNREF3TURNeERUQUxCZ05WQkF3TUJERXhNREF4RHpBTkJnTlZCQm9NQmxKcGVXRmthREVUTUJFR0ExVUVEd3dLVkdWamFHNXZiRzluZVRBZEJnTlZIUTRFRmdRVWF2Z01TOUxqRXBMWStFdGNSUVNBZXpUVVlWQXdId1lEVlIwakJCZ3dGb0FVZ2ZLamUzSjd2VkNqYXAveDZOT04xbnVjY0xVd2dlVUdBMVVkSHdTQjNUQ0IyakNCMTZDQjFLQ0IwWWFCem14a1lYQTZMeTh2UTA0OVVFVmFSVWxPVms5SlEwVlRRMEV5TFVOQktERXBMRU5PUFZCU1drVkpUbFpQU1VORlVFdEpNaXhEVGoxRFJGQXNRMDQ5VUhWaWJHbGpKVEl3UzJWNUpUSXdVMlZ5ZG1salpYTXNRMDQ5VTJWeWRtbGpaWE1zUTA0OVEyOXVabWxuZFhKaGRHbHZiaXhFUXoxbGVIUjZZWFJqWVN4RVF6MW5iM1lzUkVNOWJHOWpZV3cvWTJWeWRHbG1hV05oZEdWU1pYWnZZMkYwYVc5dVRHbHpkRDlpWVhObFAyOWlhbVZqZEVOc1lYTnpQV05TVEVScGMzUnlhV0oxZEdsdmJsQnZhVzUwTUlIT0JnZ3JCZ0VGQlFjQkFRU0J3VENCdmpDQnV3WUlLd1lCQlFVSE1BS0dnYTVzWkdGd09pOHZMME5PUFZCRldrVkpUbFpQU1VORlUwTkJNaTFEUVN4RFRqMUJTVUVzUTA0OVVIVmliR2xqSlRJd1MyVjVKVEl3VTJWeWRtbGpaWE1zUTA0OVUyVnlkbWxqWlhNc1EwNDlRMjl1Wm1sbmRYSmhkR2x2Yml4RVF6MWxlSFI2WVhSallTeEVRejFuYjNZc1JFTTliRzlqWVd3L1kwRkRaWEowYVdacFkyRjBaVDlpWVhObFAyOWlhbVZqZEVOc1lYTnpQV05sY25ScFptbGpZWFJwYjI1QmRYUm9iM0pwZEhrd0RnWURWUjBQQVFIL0JBUURBZ2VBTUR3R0NTc0dBUVFCZ2pjVkJ3UXZNQzBHSlNzR0FRUUJnamNWQ0lHR3FCMkUwUHNTaHUyZEpJZk8reG5Ud0ZWbWdaellMWVBseFYwQ0FXUUNBUkF3SFFZRFZSMGxCQll3RkFZSUt3WUJCUVVIQXdJR0NDc0dBUVVGQndNRE1DY0dDU3NHQVFRQmdqY1ZDZ1FhTUJnd0NnWUlLd1lCQlFVSEF3SXdDZ1lJS3dZQkJRVUhBd013Q2dZSUtvWkl6ajBFQXdJRFNRQXdSZ0loQU5PWWJJdGhjcjlLWXgwTUFIQytreDZYNlIrWE1FTTU5OWpUak9wM0xBNitBaUVBK2o5aTRhVE1BYU9NbkRZUndZaktIUzY0YjFXdnNMMnAxd24yeFpsQytXTT0="
    )
    pcsid_secret: str = Field("U5M7BjTpxPu0XfP+YjbCvImoGjDHnUcJQSTMXlFdynM=")
    environment: str = Field("Simulation")  # أو "Production"
    reportingUrl: str = (
        "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/reporting/single"
    )
    clearanceUrl: str = (
        "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/clearance/single"
    )
    # باقي الحقول (clientId, otp, environment...) إن كانت موجودة في مشروعك يمكن إضافتها هنا
    # سنمرر الكائن كما هو إلى دوال api_helper.* التي تستخدمها


class InputXML(BaseModel):
    # اختر أحدهما:
    xml_template_path: Optional[str] = Field(
        "zatca/output_invoice.xml", description="مسار ملف XML جاهز كأساس"
    )
    xml_text: Optional[str] = Field(None, description="نص XML جاهز كأساس")


class ProcessOneRequest(BaseModel):
    cert_info: CertInfo
    input_xml: InputXML
    document_type: DocumentType
    # قيم اختيارية/إجبارية حسب سيناريوك
    invoice_number: str = Field("DOC-0001", description="رقم المستند الجديد")
    icv_start: int = Field(1, description="قيمة ICV الابتدائية")
    pih_base64: str = Field(
        "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
        description="PIH الافتراضي (Base64) عند أول طلب",
    )
    override_instruction_note: Optional[str] = None
    invoice : InvoiceData


class ProcessBatchRequest(BaseModel):
    cert_info: CertInfo
    input_xml: InputXML
    document_types: List[DocumentType]
    icv_start: int = 1
    pih_base64: str = (
        "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
    )
    invoice_prefix: str = "DOC"
    # سيُولَّد رقم الوثيقة كـ DOC-0001, DOC-0002, ...


class ZatcaResult(BaseModel):
    #request_type: Literal["Reporting Api", "Clearance Api"]
    # api_url: str
    # status: str
    #icv: int
    pih_base64: str =""
    # invoice_number: str
    # description: str
    # clean_response: str
    raw_response: dict
    json_payload: dict ={}
    qr_value: str = ""


class BatchResult(BaseModel):
    results: List[ZatcaResult]


# -----------------------------
# أدوات داخلية
# -----------------------------


def _load_xml_doc(inp: InputXML) -> etree._ElementTree:
    print("Loading XML document...", inp )
    parser = etree.XMLParser(remove_blank_text=False)
    if inp.xml_text and inp.xml_text.strip():
        try:
            return etree.fromstring(
                inp.xml_text.encode("utf-8"), parser=parser
            ).getroottree()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"تعذر قراءة xml_text: {e}")
    if inp.xml_template_path:
        try:
            return etree.parse(inp.xml_template_path, parser)
        except Exception as e:
            raise HTTPException(
                status_code=400, detail=f"تعذر فتح xml_template_path: {e}"
            )
    raise HTTPException(
        status_code=422, detail="يجب تزويد xml_text أو xml_template_path كأساس للبناء."
    )


def _decode_cert_text(pcsid_binarySecurityToken: str) -> str:
    try:
        return base64.b64decode(pcsid_binarySecurityToken).decode("utf-8")
    except Exception as e:
        raise HTTPException(
            status_code=400, detail=f"pcsid_binarySecurityToken غير صالح Base64: {e}"
        )


def _is_simplified(prefix: str) -> bool:
    return prefix.startswith("SIM")


def _build_one(
    cert: CertInfo,
    base_document: etree._ElementTree,
    prefix: str,
    type_code: str,
    invoice_number: str,
    subtype_name: str,
    icv_value: int,
    pih_b64: str,
    instruction_note: str,
) -> ZatcaResult:

    # تعديل XML بحسب قوالب مشروعك عبر invoice_helper.modify_xml
    new_doc = invoice_helper.modify_xml(
        base_document,
        invoice_number,  # رقم الفاتورة/المستند الجديد
        subtype_name,  # "0200000" للمبسطة, "0100000" للقياسية
        type_code,  # 388/383/381
        icv_value,  # ICV
        pih_b64,  # PIH base64
        instruction_note,  # InstructionNotes (إن لزم)
    )
    # pretty_xml = etree.tostring(new_doc, pretty_print=True, encoding="unicode")
    # print(pretty_xml)
    # تجهيز payload للتوقيع والإرسال
    x509_certificate_content = _decode_cert_text(cert.pcsid_binarySecurityToken)
    json_payload_str = einvoice_signer.get_request_api(
        new_doc, x509_certificate_content, cert.privateKey
    )
    # print(json_payload_str)
    json_payload = json.loads(json_payload_str)
    # تحديد نوع الطلب والإرسال
    if einvoice_signer.is_simplified_invoice(new_doc):
        response_str = api_helper.invoice_reporting(cert.model_dump(), json_payload_str)
        request_type = "Reporting Api"
        api_url = cert.reportingUrl
    else:
        response_str = api_helper.invoice_clearance(cert.model_dump(), json_payload_str)
        request_type = "Clearance Api"
        api_url = cert.clearanceUrl

    # تنظيف وقراءة الاستجابة
    clean_response = api_helper.clean_up_json(response_str, request_type, api_url)
    try:
        raw_response = json.loads(response_str or "{}")
    except Exception:
        raise HTTPException(
            status_code=502, detail=f"استجابة غير صالحة من الخادم:\n{response_str}"
        )

    if not raw_response:
        raise HTTPException(
            status_code=502, detail=f"استجابة فارغة من الخادم:\n{response_str}"
        )

    status_key = "reportingStatus" if _is_simplified(prefix) else "clearanceStatus"
    status = raw_response.get(status_key, "")

    # لو ناجحة، حدّث PIH للقادم من حقل invoiceHash
    if "REPORTED" in status or "CLEARED" in status:
        pih_b64 = json_payload.get("invoiceHash", pih_b64)
    else:
        # نُعيد التفاصيل مع الحالة كما هي (ليس نجاح)
        pass

    return ZatcaResult(        
        raw_response=raw_response,pih_base64=pih_b64,json_payload=json_payload
    )


# -----------------------------
# Endpoints
# -----------------------------


# @router.get("/document-types", summary="القائمة المعتمدة لأنواع المستندات")
# def list_document_types():
#     """
#     يوضح الأنواع المدعومة مع كود UN/CEFACT ووصف مختصر.
#     """
#     out = []
#     for k, (code, desc, note) in DOC_TYPE_MATRIX.items():
#         out.append(
#             {
#                 "key": k,
#                 "un_cefact_code": code,
#                 "description": desc,
#                 "default_instruction_note": note,
#             }
#         )
#     return out


@router.post(
    "/process-one",
    response_model=ZatcaResult,
    summary="معالجة مستند واحد (Clearance/Reporting)",
)
async def process_one(req: ProcessOneRequest):
    """
    يستقبل نوع المستند والمتغيرات اللازمة، يبني XML عبر invoice_helper.modify_xml،
    يوقع ويبني Payload عبر einvoice_signer، ثم يرسل عبر api_helper (Reporting/Clearance) ويعيد الاستجابة.
    """
    # انشاء ملف الفاتورة XML
    # print("resive invoce")
    # print(req)
    req.invoice.InvoiceTypeCode = DOC_TYPE_MATRIX[req.document_type][0]
    # req.invoice.InvoiceTypeCodeName = DOC_TYPE_MATRIX[req.document_type][1]
    file_name = gen_invoice_file(req.invoice)
    # تحميل الـ XML الأساسي
    parser = etree.XMLParser(remove_blank_text=False)
    base_document = etree.parse(file_name, parser )  # _load_xml_doc(file_name)

    # معلومات النوع
    type_code, _description, default_note = DOC_TYPE_MATRIX[req.document_type.value]
    is_simplified = req.document_type.value.startswith("SIM")
    subtype_name = "0200000" if is_simplified else "0100000"  # حسب مواصفات ZATCA
    instruction_note = req.override_instruction_note or default_note
    result = _build_one( 
        cert=req.cert_info,
        base_document=base_document,
        prefix=req.document_type.value,
        type_code=type_code,
        invoice_number=req.invoice_number,
        subtype_name=subtype_name,
        icv_value=req.icv_start,
        pih_b64=req.pih_base64,
        instruction_note=instruction_note,
    )

    send_log = Send_Invoice(
        VAT=req.invoice.SupplierVAT,
        send_data=req.model_dump(),
        responce_data=result.model_dump(),
    )
    send_log.created_at = datetime.now(timezone.utc)
    await send_log.create()

    if is_simplified :
        cleared_invoice_b64 = result.model_dump()["json_payload"]["invoice"]
        qr_value = extract_qr_from_invoice(cleared_invoice_b64)
        result.qr_value = qr_value or ""
        result.json_payload = {}
    else :
        cleared_invoice_b64 = result.model_dump()["raw_response"]["clearedInvoice"]
        qr_value = extract_qr_from_invoice(cleared_invoice_b64)
        result.qr_value = qr_value or ""
        result.json_payload = {}

    return result


# @router.post(
#     "/process-batch",
#     response_model=BatchResult,
#     summary="معالجة مجموعة مستندات بالتتابع",
# )
# def process_batch(req: ProcessBatchRequest):
#     """
#     يعالج قائمة أنواع مستندات بترقيم متسلسل للفاتورة وزيادة ICV تباعًا.
#     يعيد نتائج مفصلة لكل عنصر.
#     """
#     base_document = _load_xml_doc(req.input_xml)
#     icv = int(req.icv_start)
#     pih = req.pih_base64
#     results: List[ZatcaResult] = []

#     for idx, dt in enumerate(req.document_types, start=1):
#         type_code, _desc, default_note = DOC_TYPE_MATRIX[dt.value]
#         is_simplified = dt.value.startswith("SIM")
#         subtype_name = "0200000" if is_simplified else "0100000"
#         invoice_number = f"{req.invoice_prefix}-{idx:04d}"

#         r = _build_one(
#             cert=req.cert_info,
#             base_document=base_document,
#             prefix=dt.value,
#             type_code=type_code,
#             invoice_number=invoice_number,
#             subtype_name=subtype_name,
#             icv_value=icv,
#             pih_b64=pih,
#             instruction_note=default_note,
#         )
#         results.append(r)

#         # تحديث PIH (لو نجحت) و ICV
#         pih = r.pih_base64
#         icv += 1

#         # تأخير بسيط نفس سلوك السكربت الأصلي
#         time.sleep(1)

#     return BatchResult(results=results)
