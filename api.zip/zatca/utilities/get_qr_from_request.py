import base64
import xml.etree.ElementTree as ET
from typing import Optional

import base64
import xml.etree.ElementTree as ET
from typing import Optional

def extract_qr_from_invoice(invoice_input: str) -> Optional[str]:
    """
    يستقبل:
      1. نص Base64 (مثل رد هيئة الزكاة).
      2. أو نص XML مباشر (مثل قراءة ملف محلي).
    
    يرجّع:
      قيمة QR (سلسلة TLV مشفّرة Base64) أو None.
    """
    
    xml_content = ""
    # تنظيف المدخل من المسافات الزائدة
    cleaned_input = invoice_input.strip()

    # --- 1) تحديد نوع المدخل (XML عادي أم Base64) ---
    # إذا بدأ النص بـ "<" فهو غالباً XML مباشر
    if cleaned_input.startswith("<"):
        xml_content = cleaned_input
    else:
        # نفترض أنه Base64 ونحاول فكه
        try:
            # محاولة فك التشفير
            xml_bytes = base64.b64decode(cleaned_input)
            xml_content = xml_bytes.decode("utf-8", errors="ignore")
            
            # تحقق إضافي: بعد الفك، هل يبدو كـ XML؟
            if not xml_content.strip().startswith("<"):
                # إذا فك التشفير وطلع نص عشوائي، قد يكون هناك خطأ
                raise ValueError("النص بعد فك Base64 لا يبدو كملف XML صالح.")
                
        except Exception as e:
            # إذا فشل الفك ولم يكن يبدأ بـ <
            raise ValueError(f"المدخل غير صالح. تأكد أنه XML أو Base64 صحيح. الخطأ: {e}")

    # --- 2) قراءة XML (Parsing) ---
    try:
        root = ET.fromstring(xml_content)
    except ET.ParseError as e:
        raise ValueError(f"XML غير صالح (Parse Error): {e}")

    # --- 3) البحث عن QR Code ---
    # QR في فاتورة زاتكا يكون في AdditionalDocumentReference
    # حيث ID = QR
    
    # نستخدم ".//*" للبحث في أي مستوى وأي Namespace لتجنب مشاكل الـ Namespaces
    for adr in root.findall(".//{*}AdditionalDocumentReference"):
        id_el = adr.find(".//{*}ID")
        
        # استخراج قيمة ID
        id_val = id_el.text.strip() if (id_el is not None and id_el.text) else ""
        
        # التحقق إذا كان هذا هو المقطع الخاص بالـ QR
        if id_val == "QR":
            embedded = adr.find(".//{*}EmbeddedDocumentBinaryObject")
            if embedded is not None and embedded.text:
                return embedded.text.strip()

    # إذا انتهى البحث ولم نجد شيئاً
    return None
# if __name__ == "__main__":
#     # هنا حطّ النص اللي أرسلته لك زاتكا (clearedInvoice) كنص Base64
#     cleared_invoice_b64 = """PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPEludm9pY2UgeG1sbnM9InVybjpvYXNpczpuYW1lczpzcGVjaWZpY2F0aW9uOnVibDpzY2hlbWE6eHNkOkludm9pY2UtMiIgeG1sbnM6Y2FjPSJ1cm46b2FzaXM6bmFtZXM6c3BlY2lmaWNhdGlvbjp1Ymw6c2NoZW1hOnhzZDpDb21tb25BZ2dyZWdhdGVDb21wb25lbnRzLTIiIHhtbG5zOmNiYz0idXJuOm9hc2lzOm5hbWVzOnNwZWNpZmljYXRpb246dWJsOnNjaGVtYTp4c2Q6Q29tbW9uQmFzaWNDb21wb25lbnRzLTIiIHhtbG5zOmV4dD0idXJuOm9hc2lzOm5hbWVzOnNwZWNpZmljYXRpb246dWJsOnNjaGVtYTp4c2Q6Q29tbW9uRXh0ZW5zaW9uQ29tcG9uZW50cy0yIj48ZXh0OlVCTEV4dGVuc2lvbnM+CiAgICA8ZXh0OlVCTEV4dGVuc2lvbj4KICAgICAgICA8ZXh0OkV4dGVuc2lvblVSST51cm46b2FzaXM6bmFtZXM6c3BlY2lmaWNhdGlvbjp1Ymw6ZHNpZzplbnZlbG9wZWQ6eGFkZXM8L2V4dDpFeHRlbnNpb25VUkk+CiAgICAgICAgPGV4dDpFeHRlbnNpb25Db250ZW50PgogICAgICAgICAgICA8c2lnOlVCTERvY3VtZW50U2lnbmF0dXJlcyB4bWxuczpzaWc9InVybjpvYXNpczpuYW1lczpzcGVjaWZpY2F0aW9uOnVibDpzY2hlbWE6eHNkOkNvbW1vblNpZ25hdHVyZUNvbXBvbmVudHMtMiIgeG1sbnM6c2FjPSJ1cm46b2FzaXM6bmFtZXM6c3BlY2lmaWNhdGlvbjp1Ymw6c2NoZW1hOnhzZDpTaWduYXR1cmVBZ2dyZWdhdGVDb21wb25lbnRzLTIiIHhtbG5zOnNiYz0idXJuOm9hc2lzOm5hbWVzOnNwZWNpZmljYXRpb246dWJsOnNjaGVtYTp4c2Q6U2lnbmF0dXJlQmFzaWNDb21wb25lbnRzLTIiPgogICAgICAgICAgICAgICAgPHNhYzpTaWduYXR1cmVJbmZvcm1hdGlvbj4gCiAgICAgICAgICAgICAgICAgICAgPGNiYzpJRD51cm46b2FzaXM6bmFtZXM6c3BlY2lmaWNhdGlvbjp1Ymw6c2lnbmF0dXJlOjE8L2NiYzpJRD4K    ... الخ ..."""

#     qr_value = extract_qr_from_cleared_invoice_b64(cleared_invoice_b64)

#     if qr_value:
#         print("QR Base64 TLV:")
#         print(qr_value)
#     else:
#         print("لم يتم العثور على QR داخل الفاتورة.")
