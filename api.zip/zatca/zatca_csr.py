import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path
import base64
import time
import json
import os
import re
from datetime import datetime, timezone
import requests
from requests.auth import HTTPBasicAuth
from typing import Optional

# --- FastAPI Imports ---
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import json
import logging
from fastapi import APIRouter, Depends, Response, status
from models import ClientsCSR_log
import random
import string

router = APIRouter(prefix="/zatca")


# ---------------------------------------------------------------
# 1. Pydantic Models (defining API Input and Output)
# ---------------------------------------------------------------


class CsrConfig(BaseModel):
    """
    بيانات الإدخال المطلوبة لإنشاء CSID.
    كانت هذه البيانات تُقرأ سابقاً من configuration.json
    """
    environmentType: str = Field(
        "simulation", description="Environment type: simulation or production"
    )
    C: str = Field("SA", description="Country (C)")
    O: str = Field("name of org ", description="Organization (O)")
    OU: str = Field("all  Services", description="Organizational Unit (OU)")
    CN: str = Field("1010010000", description="Common Name (CN)")
    VAT: str = Field("399999999900003", description="VAT number (15 digits)")
    CRN: str = Field("1010010000", description="Commercial Registration Number (CRN)")
    ADDRESS: str = Field("Riyadh", description="Registered Address")
    CATEGORY: str = Field("Technology", description="Business Category")
    TITLE: str = Field("1100", description="Title or position")
    OTP: str = Field( "123345", description="OTP from Fatoora portal for compliance check"    ) 
    complianceCsidUrl:str = Field("*" , description="complianceCsidUrl")
    complianceChecksUrl :str = Field("*" , description="complianceChecksUrl")
    productionCsidUrl: str = Field("*" , description="productionCsidUrl")
    reportingUrl: str = Field("*" , description="reportingUrl")
    clearanceUrl: str = Field("*" , description="clearanceUrl")
class CsidResponse(CsrConfig):
    """
    بيانات الإخراج الناتجة عن العملية.
    تتضمن جميع بيانات الإدخال بالإضافة إلى البيانات الجديدة التي تم إنشاؤها.
    """
    privateKey: Optional[str] = None
    csr: Optional[str] = None
    csr_src: Optional[str] = None
    egs_uuid: Optional[str] = None
    ccsid_requestID: Optional[int] = None
    ccsid_binarySecurityToken: Optional[str] = None
    ccsid_secret: Optional[str] = None


# ---------------------------------------------------------------
# 3. Helper Functions (من السكربت الأصلي)
# ---------------------------------------------------------------


def ensure_openssl() -> str:
    """
    Finds the OpenSSL executable on the system (cross-platform).
    On Linux/macOS, it relies on 'openssl' being in the system PATH.
    On Windows, it first checks PATH, then checks common install locations.
    """

    # 1. الفحص القياسي (يعمل على جميع الأنظمة)
    # يبحث في متغير PATH
    exe = shutil.which("openssl")
    if exe:
        return exe

    # 2. الفحص الإضافي الخاص بويندوز فقط
    # 'nt' هو الاسم الذي يستخدمه بايثون للإشارة إلى نظام ويندوز
    if os.name == "nt":
        candidates = [
            r"C:\Program Files\OpenSSL-Win64\bin\openssl.exe",
            r"C:\Program Files\OpenSSL-Win32\bin\openssl.exe",
            r"C:\Program Files\Git\usr\bin\openssl.exe",
        ]
        for p in candidates:
            if Path(p).exists():
                return p  # p هي المسار كنص (string)

    # 3. إذا فشلت كل المحاولات (على أي نظام)
    raise FileNotFoundError("OpenSSL not found. Install it or add to PATH.")


# قم بتشغيل الفحص عند بدء تشغيل الـ API
try:
    OPENSSL = ensure_openssl()
except FileNotFoundError as e:
    print(f"CRITICAL ERROR: {e}", file=sys.stderr)
    # يمكنك السماح للـ API بالعمل وإطلاق الخطأ عند الاستدعاء، أو الخروج
    # sys.exit(1)
    OPENSSL = "openssl"  # افتراض أنه موجود في الـ PATH


def clean_text(pem_content: str) -> str:
    """Cleans a PEM string by removing headers/footers and newlines."""
    match = re.search(
        r"-----BEGIN(?:.*?)-----(.*?)-----END(?:.*?)-----", pem_content, re.DOTALL
    )
    if not match:
        return pem_content.replace("\n", "").replace("\r", "").strip()
    key_data = match.group(1)
    cleaned_key = key_data.replace("\n", "").replace("\r", "").strip()
    return cleaned_key


def run(cmd, cwd=None):
    """Runs a subprocess command and handles errors."""
    print(f"Running command: {' '.join(cmd)}")  # لغرض التصحيح
    r = subprocess.run(
        cmd,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="ignore",
    )
    if r.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\nSTDERR:\n{r.stderr}")
    return r.stdout


def post_request_with_retries(
    url, headers, json_payload, auth=None, retries=3, backoff_factor=1
):
    """Performs a POST request with exponential backoff."""
    for attempt in range(retries):
        try:
            response = requests.post(url, headers=headers, data=json_payload, auth=auth)
            if response.status_code != 200:
                try:
                    json_txt = json.loads(response.text)
                    print(json.dumps(json_txt, indent=4))
                except json.JSONDecodeError:
                    print(f"Non-JSON error response: {response.text}")

                # إطلاق خطأ ليتم التقاطه بواسطة FastAPI
                raise HTTPException(
                    status_code=response.status_code,
                    detail=f"ZATCA API Error: {response.text}",
                )
            return response.text
        except requests.exceptions.ConnectionError as e:
            print(f"ConnectionError: {e}. Attempt {attempt + 1} of {retries}.")
            if attempt < retries - 1:
                time.sleep(backoff_factor * (2**attempt))
            else:
                # إطلاق خطأ ليتم التقاطه بواسطة FastAPI
                raise HTTPException(status_code=503, detail=f"ConnectionError: {e}")
        except Exception as e:
            # التقاط الأخطاء الأخرى (مثل HTTPException من السطر 155) وإعادة إطلاقها
            if isinstance(e, HTTPException):
                raise
            raise HTTPException(status_code=500, detail=f"Request Error: {e}")


# ---------------------------------------------------------------
# 4. Refactored Core Logic
# ---------------------------------------------------------------


def generate_random_code(length=6):
    # تعريف الحروف (كبيرة وصغيرة) والأرقام
    characters = string.ascii_letters + string.digits
    
    # اختيار 6 عناصر عشوائياً ودمجهم في نص واحد
    code = ''.join(random.choices(characters, k=length))
    return code


def make_cnf(tmpdir: Path, config: CsrConfig, egs_uuid: str) -> Path:
    """
    Creates the OpenSSL config file in a temporary directory.
    يأخذ الإعدادات من Pydantic model بدلاً من المتغيرات العامة.
    """
    # Determine API path based on environment type
    # api_path = ""
    # if config.environmentType.lower() == "nonproduction".lower():
    #     api_path = "developer-portal"
    # elif config.environmentType.lower() == "simulation".lower():
    #     api_path = "simulation"
    # elif config.environmentType.lower() == "production".lower():
    #     api_path = "core"
    # config.complianceCsidUrl = (
    #     f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance"
    # )
    # Build the SN field required by ZATCA
    # SN = f"1-{config.VAT}|2-{config.CRN}|3-{egs_uuid}"
    # تجربة الكود
    cn3 = generate_random_code()

    SN = f"1-{config.VAT}|2-{config.CRN}|3-{cn3}"

    #certificateTemplateName = ASN1:PRINTABLESTRING:PREZATCA-Code-Signing
    tmpl = f"""
oid_section = OIDs
[OIDs]
certificateTemplateName = 1.3.6.1.4.1.311.20.2

[req]
default_bits = 2048
emailAddress = zahmee@gmail.com
req_extensions = v3_req
prompt = no
default_md = sha256
req_extensions = req_ext
distinguished_name = dn

[dn]
C  = {config.C}
O  = {config.O}
OU = {config.OU}
CN = {config.CN}

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment

[req_ext]
certificateTemplateName = ASN1:PRINTABLESTRING:ZATCA-Code-Signing
subjectAltName = dirName:alt_names


[alt_names]
SN = {SN}
UID = {config.VAT}
title = {config.TITLE}
registeredAddress = {config.ADDRESS}
businessCategory = {config.CATEGORY}
"""
    cnf = tmpdir / "config.cnf"
    cnf.write_text(tmpl.strip() + "\n", encoding="utf-8")
    return cnf


def compliance_csid(config: CsrConfig, csr_base64: str):
    """
    Sends the generated CSR to ZATCA for compliance CSID.
    """
    headers = {
        "accept": "application/json",
        "accept-language": "en",
        "OTP": config.OTP,
        "Accept-Version": "V2",
        "Content-Type": "application/json",
    }
    json_payload = json.dumps({"csr": csr_base64})

    return post_request_with_retries(
        config.complianceCsidUrl, headers, json_payload, retries=3, backoff_factor=1
    )


def generate_keys_and_csid(config: CsrConfig) -> CsidResponse:
    """
    The main logic function.
    لا يقرأ أو يكتب في ملفات محلية (باستثناء المجلد المؤقت).
    """
    if not (config.VAT.isdigit() and len(config.VAT) == 15):
        print(
            f"WARNING: VAT should be 15 digits. Provided: {config.VAT}", file=sys.stderr
        )

    egs_uuid = str(uuid.uuid4())

    private_key_pem: str
    csr_pem: str
    csr_bytes: bytes

    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        cnf = make_cnf(tmp, config, egs_uuid)

        key_path = tmp / "private_key.pem"
        csr_path = tmp / "csr_zatca.csr"

        # 1) Generate EC private key (secp256k1)
        run(
            [
                OPENSSL,
                "ecparam",
                "-name",
                "secp256k1",
                "-genkey",
                "-noout",
                "-out",
                str(key_path),
            ]
        )

        # 2) CSR using our CNF
        run(
            [
                OPENSSL,
                "req",
                "-new",
                "-sha256",
                "-key",
                str(key_path),
                "-config",
                str(cnf),
                "-out",
                str(csr_path),
            ]
        )

        # 3) قراءة النتائج من الملفات المؤقتة إلى الذاكرة
        private_key_pem = key_path.read_text(encoding="utf-8")
        csr_pem = csr_path.read_text(encoding="utf-8")
        csr_bytes = csr_path.read_bytes()

    # 4) معالجة النتائج بعد حذف المجلد المؤقت
    csr_base64 = base64.b64encode(csr_bytes).decode("utf-8")

    # إنشاء قاموس بيانات للاستجابة
    # نبدأ بنسخ جميع بيانات الإدخال
    response_data = config.model_dump()

    # إضافة البيانات الجديدة التي تم إنشاؤها
    response_data["csr"] = csr_base64 
    response_data["privateKey"] = clean_text(private_key_pem)
    response_data["csr_src"] = clean_text(csr_pem)
    response_data["egs_uuid"] = egs_uuid

    # 5) get compliance csid response
    try:
        compliance_response_text = compliance_csid(config, csr_base64) or ""
        basic_compliance = json.loads(compliance_response_text)

        if basic_compliance.get("requestID"):
            response_data["ccsid_requestID"] = basic_compliance.get("requestID")
            response_data["ccsid_binarySecurityToken"] = basic_compliance.get(
                "binarySecurityToken"
            )
            response_data["ccsid_secret"] = basic_compliance.get("secret")
        else:
            # في حال كانت الاستجابة 200 ولكنها لا تحتوي على البيانات المتوقعة
            print(f"WARN: Compliance response OK but missing data: {basic_compliance}")

    except Exception as e:
        # إذا فشلت خطوة الاتصال بـ ZATCA، نرجع الخطأ
        # إذا كان الخطأ هو HTTPException، سيتم إطلاقه كما هو
        if isinstance(e, HTTPException):
            raise
        # لأي خطأ آخر (مثل فشل json.loads)
        raise HTTPException(
            status_code=500, detail=f"Compliance CSID step failed: {str(e)}"
        )

    # 6) إرجاع كائن Pydantic بالبيانات الكاملة
    return CsidResponse(**response_data)


# ---------------------------------------------------------------
# 5. API Endpoint
# ---------------------------------------------------------------


@router.post(
    "/generate-csid",
    response_model=CsidResponse,
    summary="Generate Keys and Request Compliance CSID",
    description="""
    يقوم بإنشاء مفتاح خاص (EC secp256k1) وطلب توقيع شهادة (CSR)
    وفقاً لمتطلبات ZATCA.
    ثم يرسل الـ CSR إلى ZATCA (باستخدام الـ OTP) للحصول على CSID (Compliance).
    
    - **المدخلات**: إعدادات الفاتورة (VAT, CRN, ...) + OTP.
    - **المخرجات**: جميع المدخلات + المفتاح الخاص، CSR، وبيانات CSID.
    """,
)
async def api_create_csid(config: CsrConfig):
    """
    نقطة النهاية الرئيسية للـ API.
    تستقبل الإعدادات كـ JSON، وتُرجع النتائج كـ JSON.
    """
    try:
        api_path = "nonproduction"
        if config.environmentType.lower() == "nonproduction".lower():
            api_path = 'developer-portal'
        elif config.environmentType.lower() == "simulation".lower():
            api_path = 'simulation'
        elif config.environmentType.lower() == "production".lower():
            api_path = 'core'
        config.complianceCsidUrl = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance"
        config.complianceChecksUrl = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance/invoices"
        config.productionCsidUrl = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/production/csids"
        config.reportingUrl = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
        config.clearanceUrl = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single"
        # استدعاء الدالة المنطقية الرئيسية
        # بما أنها تستخدم subprocess و requests (I/O)،
        # فإن FastAPI سيقوم بتشغيلها بذكاء في "thread pool"
        cli_log = ClientsCSR_log(**config.model_dump() )
        response = generate_keys_and_csid(config)
        cli_log.responce_data = response.model_dump(
            include={
                "privateKey",
                "csr",
                "csr_src",
                "egs_uuid",
                "ccsid_binarySecurityToken",
                "ccsid_secret",
            }
        )
        cli_log.created_at = datetime.now(timezone.utc)
        await cli_log.create()
        return response

    except FileNotFoundError as e:
        # خطأ إذا لم يتم العثور على openssl
        logging.error(f" open ssl not found {e}")
        raise HTTPException(
            status_code=500, detail=f"Server Configuration Error: {str(e)}"
        )
    except RuntimeError as e:
        # خطأ من دالة 'run' (فشل في openssl)
        logging.error(f" run error : {e}")
        raise HTTPException(status_code=500, detail=f"OpenSSL Command Error: {str(e)}")
    except HTTPException as e:
        # إعادة إطلاق أخطاء ZATCA API التي تم التقاطها سابقاً
        raise e
    except Exception as e:
        # التقاط أي أخطاء أخرى غير متوقعة
        logging.error(f" error : {e}")
        raise HTTPException(
            status_code=500, detail=f"An unexpected error occurred: {str(e)}"
        )
