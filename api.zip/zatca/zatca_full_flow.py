#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ZATCA Full Flow - نسخة تعتمد على شهادة csid_cert بصيغة Base64 فقط داخل JSON
(بدون BEGIN/END)
المكتبات المطلوبة:
    pip install cryptography lxml requests
"""

import json
import base64
import argparse
import hashlib
import requests
from lxml import etree
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography import x509

ZATCA_SIM_INVOICE_URL = (
    "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/compliance/invoices"
)

# ---------- helpers ----------


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_xml(path: str) -> bytes:
    with open(path, "rb") as f:
        return f.read()


def canonicalize(xml_bytes: bytes) -> bytes:
    parser = etree.XMLParser(remove_blank_text=True)
    root = etree.fromstring(xml_bytes, parser)
    return etree.tostring(root, method="c14n", exclusive=True, with_comments=False)


def load_ec_private_key_from_b64(b64_key: str):
    der = base64.b64decode(b64_key)
    key = serialization.load_der_private_key(der, password=None)
    if not isinstance(key, ec.EllipticCurvePrivateKey):
        raise ValueError("المفتاح الخاص غير صحيح أو ليس ECDSA")
    return key


def sha256_digest(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def sign_hash_ecdsa(private_key: ec.EllipticCurvePrivateKey, digest: bytes) -> bytes:
    return private_key.sign(digest, ec.ECDSA(hashes.SHA256()))


def load_cert_from_b64_string(cert_b64: str) -> x509.Certificate:
    """تحميل الشهادة من نص Base64 خام (بدون BEGIN/END)"""
    cert_b64_clean = cert_b64.strip().replace(" ", "").replace("\n", "")
    der_bytes = base64.b64decode(cert_b64_clean)
    return x509.load_der_x509_certificate(der_bytes)


def tlv_encode(tag: int, value: bytes) -> bytes:
    length = len(value)
    return bytes([tag, length]) + value


def build_qr_tlv_base64(fields: list[tuple[int, bytes]]) -> str:
    tlv_bytes = b"".join(tlv_encode(t, v) for t, v in fields)
    return base64.b64encode(tlv_bytes).decode()


def extract_text(root, xpaths: list[str], default="") -> str:
    for xp in xpaths:
        res = root.xpath(xp, namespaces=root.nsmap)
        if res:
            v = res[0]
            if isinstance(v, etree._Element):
                return (v.text or "").strip()
            else:
                return str(v).strip()
    return default


def build_qr_from_invoice(
    xml_bytes: bytes,
    config: dict,
    cert: x509.Certificate,
    invoice_hash_b64: str,
    invoice_sig_b64: str,
) -> str:
    root = etree.fromstring(xml_bytes)

    seller_name = extract_text(
        root,
        [
            "//cac:AccountingSupplierParty/cbc:RegistrationName",
            "//cac:AccountingSupplierParty//cbc:Name",
            "//cbc:Name",
        ],
        default=config.get("O", "Seller"),
    )

    vat_reg = config.get("VAT") or extract_text(
        root,
        ["//cac:AccountingSupplierParty//cbc:CompanyID", "//cbc:CompanyID"],
        default="000000000000000",
    )

    issue_date = extract_text(root, ["//cbc:IssueDate"], default="")
    issue_time = extract_text(root, ["//cbc:IssueTime"], default="")
    issue_datetime = issue_date + ("T" + issue_time if issue_time else "")

    total = extract_text(
        root,
        ["//cac:LegalMonetaryTotal/cbc:PayableAmount", "//cbc:TotalAmount"],
        default="0.00",
    )

    vat_amount = extract_text(
        root, ["//cac:TaxTotal/cbc:TaxAmount", "//cbc:TaxAmount"], default="0.00"
    )

    # tag 8: public key من الشهادة
    pub_spki_der = cert.public_key().public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    tag8_b64 = base64.b64encode(pub_spki_der).decode()

    # tag 9: توقيع الشهادة نفسها (اللي توقعها الهيئة)
    tag9_b64 = base64.b64encode(cert.signature).decode()

    fields = [
        (1, seller_name.encode("utf-8")),
        (2, vat_reg.encode("utf-8")),
        (3, issue_datetime.encode("utf-8")),
        (4, total.encode("utf-8")),
        (5, vat_amount.encode("utf-8")),
        (6, invoice_hash_b64.encode("utf-8")),
        (7, invoice_sig_b64.encode("utf-8")),
        (8, tag8_b64.encode("utf-8")),
        (9, tag9_b64.encode("utf-8")),
    ]
    return build_qr_tlv_base64(fields)


def submit_to_zatca_simulation(xml_bytes: bytes, config: dict):
    token = config["ccsid_binarySecurityToken"]
    secret = config["ccsid_secret"]

    auth = (token, secret)
    headers = {"Content-Type": "application/xml", "Accept": "application/json"}

    resp = requests.post(
        ZATCA_SIM_INVOICE_URL, data=xml_bytes, headers=headers, auth=auth, timeout=30
    )
    return resp.status_code, resp.text


# ---------- main flow ----------


def main():
    parser = argparse.ArgumentParser(
        description="ZATCA full flow (QR + sign + submit) - csid_cert Base64 only"
    )
    parser.add_argument("--xml", required=True, help="مسار ملف الفاتورة XML")
    parser.add_argument("--config", default="config.json", help="ملف الإعدادات")
    args = parser.parse_args()

    config = load_config(args.config)
    xml_bytes = load_xml(args.xml)

    # 1) canonicalize
    c14n = canonicalize(xml_bytes)

    # 2) load private key
    priv = load_ec_private_key_from_b64(config["privateKey"])

    # 3) hash
    inv_hash = sha256_digest(c14n)
    inv_hash_b64 = base64.b64encode(inv_hash).decode()

    # 4) sign hash
    sig_der = sign_hash_ecdsa(priv, inv_hash)
    sig_b64 = base64.b64encode(sig_der).decode()

    # 5) load certificate from Base64 (csid_cert)
    if "csid_cert" not in config:
        raise ValueError("أضف csid_cert داخل ملف JSON (Base64 فقط بدون BEGIN/END)")
    cert = load_cert_from_b64_string(config["csid_cert"])

    # 6) build QR
    qr_b64 = build_qr_from_invoice(xml_bytes, config, cert, inv_hash_b64, sig_b64)
    print("QR (Base64 TLV):", qr_b64)

    # 7) إرسال للهيئة (بيئة Simulation)
    status, text = submit_to_zatca_simulation(xml_bytes, config)
    print("ZATCA HTTP status:", status)
    print("ZATCA response:")
    print(text)


if __name__ == "__main__":
    main()
