from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend
import datetime
import base64

# 1. الـ CSR الذي قدمته (بدون ترويسات)
csr_base64 = "MIIB/DCCAaMCAQAwTzELMAkGA1UEBhMCU0ExFTATBgNVBAoMDGViZGEtdGF0d2VlcjEUMBIGA1UECwwLSVQgU2VydmljZXMxEzARBgNVBAMMCjU4NTUzNTM1NzEwVjAQBgcqhkjOPQIBBgUrgQQACgNCAAQnZ8SlXhLK3hthvSNOuvLKu1qj98myCQLLV2Z943t5iN6c9hecgHQ6DCnrm2ED4I9mkv0w4rdUlmq6CYGWQetVoIH0MIHxBgkqhkiG9w0BCQ4xgeMwgeAwJAYJKwYBBAGCNxQCBBcTFVBSRVpBVENBLUNvZGUtU2lnbmluZzCBtwYDVR0RBIGvMIGspIGpMIGmMU4wTAYDVQQEDEUxLTMxMDIzMjI2NjQwMDAwM3wyLTU4NTUzNTM1NzF8My00YjdkYTc2MC01Yjk4LTQ0ZmItOWRkMi0wYWUwYjVlYjk5NTkxHzAdBgoJkiaJk/IsZAEBDA8zMTAyMzIyNjY0MDAwMDMxDTALBgNVBAwMBDExMDAxDzANBgNVBBoMBlJpeWFkaDETMBEGA1UEDwwKVGVjaG5vbG9neTAKBggqhkjOPQQDAgNHADBEAiAY9dMUlZYY5LsdW0NWgzA4qc5tVQRm2weRwu4LqFp83AIga0bK914P9P/nq3PgDBWwHDEWPGIqRJ1VnfyAg25Wrlg="

# تنسيقه كـ PEM بإضافة الترويسات
csr_pem = f"-----BEGIN CERTIFICATE REQUEST-----\n{csr_base64}\n-----END CERTIFICATE REQUEST-----\n"


def sign_csr_demo(csr_pem_text):
    # تحميل الـ CSR
    csr = x509.load_pem_x509_csr(csr_pem_text.encode("utf-8"), default_backend())

    # إنشاء مفتاح خاص مؤقت *فقط* لغرض هذا المثال (لتوقيع الشهادة)
    # في الواقع، يجب استخدام مفتاحك الخاص الأصلي أو مفتاح الـ CA
    temp_ca_private_key = ec.generate_private_key(ec.SECP256K1(), default_backend())

    # إعداد الشهادة
    builder = x509.CertificateBuilder()
    builder = builder.subject_name(csr.subject)
    builder = builder.issuer_name(csr.subject)  # شهادة موقعة ذاتياً لهذا المثال
    builder = builder.public_key(csr.public_key())
    builder = builder.serial_number(x509.random_serial_number())
    builder = builder.not_valid_before(datetime.datetime.utcnow())
    builder = builder.not_valid_after(
        datetime.datetime.utcnow() + datetime.timedelta(days=365)
    )

    # نقل الامتدادات (مهم جداً لـ ZATCA)
    for ext in csr.extensions:
        builder = builder.add_extension(ext.value, ext.critical)

    # التوقيع
    certificate = builder.sign(
        private_key=temp_ca_private_key,
        algorithm=hashes.SHA256(),
        backend=default_backend(),
    )

    return certificate


# تنفيذ التحويل
generated_cert = sign_csr_demo(csr_pem)

# طباعة النتيجة بتنسيق PEM
print(generated_cert.public_bytes(serialization.Encoding.PEM).decode("utf-8"))
