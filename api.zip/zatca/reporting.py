# from zatca.onboarding import run_onboarding
from zatca.clearance_reporting import run_clearance_reporting
# from zatca.create_xml_invoce import create_invoice_xml
from pydantic import BaseModel
from typing import Dict
import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
import json, base64, time
from lxml import etree  # type: ignore

# استيراد الأدوات كما في سكربتك الأصلي
from zatca.utilities.api_helper import api_helper
from zatca.utilities.invoice_helper import invoice_helper
from zatca.utilities.einvoice_signer import einvoice_signer

router = APIRouter(prefix="/zatca_2", tags=["ZATCA Invoices"])


class CSRRequest(BaseModel):
    environment_type: str
    otp: str
    csr_config: Dict[str, str]


class ReportingRequest(BaseModel):
    invoice_id: str
    user_id: str
    invoice_data: dict


# @app.post("/onboarding")
# def onboarding(request: CSRRequest):
#     return run_onboarding(request.environment_type, request.otp, request.csr_config)


@router.post("/reporting")
def reporting(request: ReportingRequest):
    try:
        file_path = f"zatca/output_invoice2.xml"  # ✅ use /tmp on Vercel
        # create_invoice_xml(request.invoice_data, file_path)
        return run_clearance_reporting(file_path, request.user_id)
    except Exception as e:
        print(f"Error during reporting: {e}")   
        return {"error": str(e)}
