import json
import base64
from pathlib import Path
from lxml import etree # type: ignore
from typing import Optional

from fastapi import APIRouter, HTTPException
from datetime import datetime, timezone
from models import OnBoarding_log

# --- استيراد الأدوات المساعدة الخاصة بك ---
# (أفترض أنها موجودة في مجلد 'utilities')
from zatca.utilities.api_helper import api_helper
from zatca.utilities.invoice_helper import invoice_helper
from zatca.utilities.einvoice_signer import einvoice_signer

# --- استيراد النماذج من ملفك الرئيسي ---
# (نفترض أن الملف الأول اسمه main.py)
from zatca.zatca_csr import CsidResponse


# --- تعريف نموذج الإخراج ---
# هذا النموذج "يرث" كل حقول الإدخال ويضيف حقول الإنتاج
class ProductionCsidResponse(CsidResponse):
    pcsid_requestID          : Optional[int] = None
    pcsid_binarySecurityToken: Optional[str] = None
    pcsid_secret             : Optional[str] = None

    # (يمكنك إضافة أي حقول أخرى تُرجع من الخطوة 4)
    compliance_check_results: list = []


# --- إنشاء الراوتر ---
router = APIRouter(prefix="/zatca")


# --- الدالة المنطقية الرئيسية ---
# تم تحويل السكربت الخاص بك إلى دالة تستقبل البيانات وترجع النتائج
def run_onboarding_logic(cert_info: CsidResponse) -> ProductionCsidResponse:

    # 1. تحديد مسارات API بناءً على البيئة
    environment_type = cert_info.environmentType
    if environment_type.lower() == "nonproduction":
        api_path = "developer-portal"
    elif environment_type.lower() == "simulation":
        api_path = "simulation"
    elif environment_type.lower() == "production":
        api_path = "core"
    else:
        raise ValueError(f"Invalid environmentType: {environment_type}")

    # تحويل نموذج Pydantic إلى قاموس (dict) لتمريره للأدوات المساعدة
    cert_info_dict = cert_info.model_dump()

    # إضافة/تحديث مسارات URL المطلوبة في الخطوات 3 و 4
    # (كان السكربت الأصلي يبنيها، ولكن CsidResponse لم تكن تحتوي عليها)
    cert_info_dict["complianceChecksUrl"] = (
        f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance/invoices"
    )
    cert_info_dict["productionCsidUrl"] = (
        f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/production/csids"
    )
    cert_info_dict["reportingUrl"] = (
        f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
    )
    cert_info_dict["clearanceUrl"] = (
        f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single"
    )

    # 2. الخطوة 3: إرسال الفواتير التجريبية
    # print("\n3: Sending Sample Documents\n")

    xml_template_path = "zatca/templates/invoice.xml"
    if not Path(xml_template_path).exists():
        raise FileNotFoundError(f"Template file '{xml_template_path}' not found.")

    private_key = cert_info.privateKey
    x509_certificate_content = base64.b64decode(
        cert_info.ccsid_binarySecurityToken or ""
    ).decode("utf-8")

    parser = etree.XMLParser(remove_blank_text=False)
    base_document = etree.parse(xml_template_path, parser)
    root = base_document.getroot()
    namespace = {
        "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
        "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
    }
    # تاريخ الفاتورة
    name_element = root.find(".//cbc:IssueDate", namespaces=namespace)
    name_element.text = datetime.today().strftime("%Y-%m-%d")
    # وقت الفاتورة
    name_element = root.find(".//cbc:IssueTime", namespaces=namespace)
    name_element.text = datetime.now().strftime("%H:%M:%S")
    # الرقم الضريبي
    name_element = root.find(".//cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID", namespaces=namespace)
    name_element.text = cert_info.VAT
    # السجل التجاري
    name_element = root.find(".//cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID", namespaces=namespace)
    name_element.text = cert_info.CN
    
    document_types = [
        ["STDSI", "388", "Standard Invoice", ""],
        [
            "STDCN",
            "383",
            "Standard CreditNote",
            "InstructionNotes for Standard CreditNote",
        ],
        [
            "STDDN",
            "381",
            "Standard DebitNote",
            "InstructionNotes for Standard DebitNote",
        ],
        ["SIMSI", "388", "Simplified Invoice", ""],
        [
            "SIMCN",
            "383",
            "Simplified CreditNote",
            "InstructionNotes for Simplified CreditNote",
        ],
        [
            "SIMDN",
            "381",
            "Simplified DebitNote",
            "InstructionNotes for Simplified DebitNote",
        ],
    ]

    icv = 0
    pih = "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="

    all_results = []  # لتخزين نتائج الفحص

    for doc_type in document_types:
        prefix, type_code, description, instruction_note = doc_type
        icv += 1
        is_simplified = prefix.startswith("SIM")
        print(f"Processing {description}...\n")
        new_doc = invoice_helper.modify_xml( # type: ignore
            base_document,
            f"{prefix}-0001",
            "0200000" if is_simplified else "0100000",
            type_code,
            icv,
            pih,
            instruction_note,
        )

        json_payload = einvoice_signer.get_request_api(
            new_doc, x509_certificate_content, private_key
        )

        # استدعاء فحص الامتثال
        response = api_helper.compliance_checks(cert_info_dict, json_payload)

        clean_response = api_helper.clean_up_json(
            response, "Compliance Checks", cert_info_dict["complianceChecksUrl"]
        )

        try:
            json_decoded_response = json.loads(response or "{}")
            all_results.append(json_decoded_response)  # إضافة النتيجة للقائمة
        except json.JSONDecodeError:
            #print(f"Invalid JSON Response: \n{response}")
            raise HTTPException(
                status_code=400,
                detail=f"Failed to process {description}: Invalid JSON response from ZATCA.",
            )

        if response is None:
            raise HTTPException(
                status_code=400,
                detail=f"Failed to process {description}: serverResult is null.",
            )

        status = (
            json_decoded_response.get("reportingStatus")
            if is_simplified
            else json_decoded_response.get("clearanceStatus")
        )

        if status and ("REPORTED" in status or "CLEARED" in status):
            json_payload_dict = json.loads(json_payload)
            pih = json_payload_dict["invoiceHash"]
            # print(f"\n{description} processed successfully\n\n")
        else:
            # print(f"Failed to process {description}: status is {status}\n")
            raise HTTPException(
                status_code=400,
                detail=f"Failed to process {description}: status is {status}. Full response: {clean_response}",
            )

    # 3. الخطوة 4: الحصول على Production CSID
    # print(f"\n\n4. Get Production CSID\n")

    response = api_helper.production_csid(cert_info_dict)
    clean_response = api_helper.clean_up_json(
        response, "Production CSID", cert_info_dict["productionCsidUrl"]
    )

    pcsid_data = {}
    try:
        json_decoded_response = json.loads(response or "{}")

        pcsid_data["pcsid_requestID"] = json_decoded_response.get("requestID")
        pcsid_data["pcsid_binarySecurityToken"] = json_decoded_response.get(
            "binarySecurityToken"
        )
        pcsid_data["pcsid_secret"] = json_decoded_response.get("secret")

        #print(f"Production CSID Server Response: \n{clean_response}")

    except json.JSONDecodeError:
        #print(f"Production CSID Server Response: \n{clean_response}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to decode Production CSID response: {clean_response}",
        )

    # 4. تجميع وإرجاع الاستجابة النهائية
    # نبدأ بالبيانات الأصلية ونضيف إليها البيانات الجديدة
    final_response_data = cert_info.model_dump()
    final_response_data.update(pcsid_data)  # إضافة بيانات PCSID
    final_response_data["compliance_check_results"] = all_results  # إضافة نتائج الفحص
    return ProductionCsidResponse(**final_response_data)


# --- نقطة النهاية (Endpoint) الخاصة بالراوتر ---
@router.post(
    "/run-onboarding-steps",
    response_model=ProductionCsidResponse,
    summary="Run Compliance Checks & Get Production CSID",
)
async def api_run_onboarding_steps(compliance_data: CsidResponse):
    """
    تستقبل هذه النقطة بيانات الامتثال (CSID) التي تم إنشاؤها
    من الخطوة الأولى، وتقوم بتنفيذ الخطوات التالية:

    1.  **إرسال 6 فواتير تجريبية** (قياسية ومبسطة) للتحقق من الامتثال.
    2.  إذا نجحت جميعها، **تطلب شهادة CSID للإنتاج** (Production).
    3.  تُرجع جميع البيانات مجمعة (البيانات الأصلية + نتائج الفحص + بيانات الإنتاج).
    """
    try:
        result = run_onboarding_logic(compliance_data)
        bord_log = OnBoarding_log(**result.model_dump())
        bord_log.created_at = datetime.now(timezone.utc)
        # print(bord_log)
        # print(result)
        # bord_log.responce_data = result.model_dump(
        #     include={
        #         "compliance_check_results"
        #     }
        # )
        await bord_log.insert()
        return result
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=f"Server Configuration Error: {e}")
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(
            status_code=500, detail=f"An unexpected error occurred: {str(e)}"
        )
