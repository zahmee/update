# type: ignore

# --- FastAPI Imports ---
from fastapi import FastAPI, HTTPException
from fastapi import APIRouter, Depends, Response, status
from pydantic import BaseModel, Field
from typing import List, Optional
from xml.sax.saxutils import escape
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/zatca")


# =========================
# 1) Pydantic Models
# =========================


class TaxCategory(BaseModel):
    ID: str
    Percent: float
    SchemeID: str = Field(default="VAT")


class AllowanceCharge(BaseModel):
    ChargeIndicator: bool
    Reason: str
    Amount: float
    TaxCategories: Optional[List[TaxCategory]] = None


class InvoiceLineAllowanceCharge(BaseModel):
    ChargeIndicator: bool
    Reason: str
    Amount: float


class InvoiceLine(BaseModel):
    ID: str
    UnitCode: str
    Quantity: float
    LineExtensionAmount: float
    TaxAmount: float
    RoundingAmount: float
    Name: str
    TaxCategoryID: str
    TaxPercent: float
    PriceAmount: float
    AllowanceCharge: InvoiceLineAllowanceCharge


class AdditionalDocumentReference(BaseModel):
    ID: str
    UUID: Optional[str] = None
    Attachment: Optional[str] = None
    FileName: Optional[str] = None


class InvoiceData(BaseModel):
    # --- General Info ---
    ProfileID: str
    ID: str
    UUID: str
    IssueDate: str
    IssueTime: str
    InvoiceTypeCode: str
    InvoiceTypeCodeName: Optional[str] = None
    Note: Optional[str] = None
    DocumentCurrencyCode: str
    TaxCurrencyCode: str

    # --- References ---
    BillingReference: Optional[str] = None
    AdditionalDocumentReferences: Optional[List[AdditionalDocumentReference]] = None

    # --- Supplier ---
    SupplierStreetName: str
    SupplierBuildingNumber: str
    SupplierCityName: str
    SupplierDistrict: str
    SupplierPostalZone: str
    SupplierCountryCode: str
    SupplierVAT: str
    SupplierName: str
    SupplierSchemeID: Optional[str] = "CRN"
    SupplierCRN: Optional[str] = None

    # --- Customer ---
    CustomerStreetName: str
    CustomerBuildingNumber: str
    CustomerCityName: str
    CustomerDistrict: str
    CustomerPostalZone: str
    CustomerCountryCode: str
    CustomerVAT: str
    CustomerName: str
    CustomerCRN: Optional[str] = None

    # --- Delivery & Payment ---
    DeliveryDate: Optional[str] = None
    PaymentMeansCode: Optional[str] = None

    # --- Allowance / Discounts ---
    AllowanceCharge: AllowanceCharge

    # --- Invoice Lines ---
    InvoiceLines: List[InvoiceLine]

    # --- Totals ---
    TaxAmount: float
    TaxableAmount: float
    TaxPercent: float
    LineExtensionAmount: float
    TaxExclusiveAmount: float
    TaxInclusiveAmount: float
    AllowanceTotalAmount: float
    PrepaidAmount: float
    PayableAmount: float


# =========================
# 2) Helpers
# =========================


def fmt2(x) -> str:
    return f"{float(x):.2f}"


def fmt6(x) -> str:
    return f"{float(x):.6f}"


# =========================
# 3) XML Renderers (f-strings)
# =========================


def _render_additional_doc_ref(doc: AdditionalDocumentReference) -> str:
    if doc.ID == "ICV":
        uuid = escape(doc.UUID or "")
        return f"""
    <cac:AdditionalDocumentReference>
        <cbc:ID>ICV</cbc:ID>
        <cbc:UUID>{uuid}</cbc:UUID>
    </cac:AdditionalDocumentReference>"""
    elif doc.ID == "PIH":
        att = escape(doc.Attachment or "")
        return f"""
    <cac:AdditionalDocumentReference>
        <cbc:ID>PIH</cbc:ID>
        <cac:Attachment>
            <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">{att}</cbc:EmbeddedDocumentBinaryObject>
        </cac:Attachment>
    </cac:AdditionalDocumentReference>"""
    else:
        idv = escape(doc.ID)
        # Generic reference (expand as needed)
        fn = (
            f"\n        <cbc:DocumentDescription>{escape(doc.FileName)}</cbc:DocumentDescription>"
            if doc.FileName
            else ""
        )
        return f"""
    <cac:AdditionalDocumentReference>
        <cbc:ID>{idv}</cbc:ID>{fn}
    </cac:AdditionalDocumentReference>"""


def _render_line(line: InvoiceLine) -> str:
    return f"""
    <cac:InvoiceLine>
        <cbc:ID>{escape(str(line.ID))}</cbc:ID>
        <cbc:InvoicedQuantity unitCode="{escape(line.UnitCode)}">{fmt6(line.Quantity)}</cbc:InvoicedQuantity>
        <cbc:LineExtensionAmount currencyID="SAR">{fmt2(line.LineExtensionAmount)}</cbc:LineExtensionAmount>
        <cac:TaxTotal>
            <cbc:TaxAmount currencyID="SAR">{fmt2(line.TaxAmount)}</cbc:TaxAmount>
            <cbc:RoundingAmount currencyID="SAR">{fmt2(line.RoundingAmount)}</cbc:RoundingAmount>
        </cac:TaxTotal>
        <cac:Item>
            <cbc:Name>{escape(line.Name)}</cbc:Name>
            <cac:ClassifiedTaxCategory>
                <cbc:ID>{escape(line.TaxCategoryID)}</cbc:ID>
                <cbc:Percent>{fmt2(line.TaxPercent)}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:ClassifiedTaxCategory>
        </cac:Item>
        <cac:Price>
            <cbc:PriceAmount currencyID="SAR">{fmt2(line.PriceAmount)}</cbc:PriceAmount>
            <cac:AllowanceCharge>
                <cbc:ChargeIndicator>{"true" if line.AllowanceCharge.ChargeIndicator else "false"}</cbc:ChargeIndicator>
                <cbc:AllowanceChargeReason>{escape(line.AllowanceCharge.Reason)}</cbc:AllowanceChargeReason>
                <cbc:Amount currencyID="SAR">{fmt2(line.AllowanceCharge.Amount)}</cbc:Amount>
            </cac:AllowanceCharge>
        </cac:Price>
    </cac:InvoiceLine>"""


def render_invoice_xml(inv: InvoiceData) -> str:
    # AdditionalDocumentReferences
    add_refs = ""
    if inv.AdditionalDocumentReferences:
        add_refs = "".join(
            _render_additional_doc_ref(doc) for doc in inv.AdditionalDocumentReferences
        )

    # Invoice lines
    lines_xml = "".join(_render_line(line) for line in inv.InvoiceLines)

    # Optional note
    note_xml = (
        f'\n    <cbc:Note languageID="ar">{escape(inv.Note)}</cbc:Note>'
        if inv.Note
        else ""
    )

    # Optional BillingReference
    billing_ref_xml = ""
    if inv.BillingReference:
        billing_ref_xml = f"""
    <cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>{escape(inv.BillingReference)}</cbc:ID>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>"""

    # Header AllowanceCharge (with optional tax categories)
    header_allowance_taxcats = ""
    if inv.AllowanceCharge.TaxCategories:
        for tc in inv.AllowanceCharge.TaxCategories:
            header_allowance_taxcats += f"""
        <cac:TaxCategory>
            <cbc:ID schemeID="UN/ECE 5305" schemeAgencyID="6">{escape(tc.ID)}</cbc:ID>
            <cbc:Percent>{fmt2(tc.Percent)}</cbc:Percent>
            <cac:TaxScheme>
                <cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">{escape(tc.SchemeID)}</cbc:ID>
            </cac:TaxScheme>
        </cac:TaxCategory>"""

    header_allowance_xml = f"""
    <cac:AllowanceCharge>
        <cbc:ChargeIndicator>{"true" if inv.AllowanceCharge.ChargeIndicator else "false"}</cbc:ChargeIndicator>
        <cbc:AllowanceChargeReason>{escape(inv.AllowanceCharge.Reason)}</cbc:AllowanceChargeReason>
        <cbc:Amount currencyID="SAR">{fmt2(inv.AllowanceCharge.Amount)}</cbc:Amount>{header_allowance_taxcats}
    </cac:AllowanceCharge>"""

    BillingReference = ""
    if inv.InvoiceTypeCode == "383":  # Credit Note اضافة رقم فاتورة الارجاع
        BillingReference = f"""<cac:BillingReference>
                <cac:InvoiceDocumentReference>
                    <cbc:ID>1001</cbc:ID>  
                </cac:InvoiceDocumentReference>
    </cac:BillingReference>"""
    # print(json.dumps(inv.model_dump() , ensure_ascii=False, indent=4))

    xml_text = f"""<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">
    <cbc:ProfileID>{escape(inv.ProfileID)}</cbc:ProfileID>
    <cbc:ID>{escape(inv.ID)}</cbc:ID>
    <cbc:UUID>{escape(inv.UUID)}</cbc:UUID>
    <cbc:IssueDate>{escape(inv.IssueDate)}</cbc:IssueDate>
    <cbc:IssueTime>{escape(inv.IssueTime)}</cbc:IssueTime>
    <cbc:InvoiceTypeCode name="{escape(inv.InvoiceTypeCodeName or "")}">{escape(inv.InvoiceTypeCode)}</cbc:InvoiceTypeCode>{note_xml}
    <cbc:DocumentCurrencyCode>{escape(inv.DocumentCurrencyCode)}</cbc:DocumentCurrencyCode>
    <cbc:TaxCurrencyCode>{escape(inv.TaxCurrencyCode)}</cbc:TaxCurrencyCode>{billing_ref_xml}
    {BillingReference}    
    {add_refs}
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="{escape(inv.SupplierSchemeID or "CRN")}">{escape(inv.SupplierCRN or "")}</cbc:ID>
            </cac:PartyIdentification>
            <cac:PostalAddress>
                <cbc:StreetName>{escape(inv.SupplierStreetName)}</cbc:StreetName>
                <cbc:BuildingNumber>{escape(inv.SupplierBuildingNumber)}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{escape(inv.SupplierDistrict)}</cbc:CitySubdivisionName>
                <cbc:CityName>{escape(inv.SupplierCityName)}</cbc:CityName>
                <cbc:PostalZone>{escape(inv.SupplierPostalZone)}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>{escape(inv.SupplierCountryCode)}</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{escape(inv.SupplierVAT)}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{escape(inv.SupplierName)}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PostalAddress>
                <cbc:StreetName>{escape(inv.CustomerStreetName)}</cbc:StreetName>
                <cbc:BuildingNumber>{escape(inv.CustomerBuildingNumber)}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{escape(inv.CustomerDistrict)}</cbc:CitySubdivisionName>
                <cbc:CityName>{escape(inv.CustomerCityName)}</cbc:CityName>
                <cbc:PostalZone>{escape(inv.CustomerPostalZone)}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>{escape(inv.CustomerCountryCode)}</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{escape(inv.CustomerVAT)}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{escape(inv.CustomerName)}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>
    <cac:Delivery>
        <cbc:ActualDeliveryDate>{escape(inv.DeliveryDate or "")}</cbc:ActualDeliveryDate>
    </cac:Delivery>
    <cac:PaymentMeans>
        <cbc:PaymentMeansCode>{escape(inv.PaymentMeansCode or "")}</cbc:PaymentMeansCode>
    </cac:PaymentMeans>
    {header_allowance_xml}
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{fmt2(inv.TaxAmount)}</cbc:TaxAmount>
    </cac:TaxTotal>
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{fmt2(inv.TaxAmount)}</cbc:TaxAmount>
        <cac:TaxSubtotal>
            <cbc:TaxableAmount currencyID="SAR">{fmt2(inv.TaxableAmount)}</cbc:TaxableAmount>
            <cbc:TaxAmount currencyID="SAR">{fmt2(inv.TaxAmount)}</cbc:TaxAmount>
            <cac:TaxCategory>
                <cbc:ID schemeID="UN/ECE 5305" schemeAgencyID="6">S</cbc:ID>
                <cbc:Percent>{fmt2(inv.TaxPercent)}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>
    </cac:TaxTotal>
    <cac:LegalMonetaryTotal>
        <cbc:LineExtensionAmount currencyID="SAR">{fmt2(inv.LineExtensionAmount)}</cbc:LineExtensionAmount>
        <cbc:TaxExclusiveAmount currencyID="SAR">{fmt2(inv.TaxExclusiveAmount)}</cbc:TaxExclusiveAmount>
        <cbc:TaxInclusiveAmount currencyID="SAR">{fmt2(inv.TaxInclusiveAmount)}</cbc:TaxInclusiveAmount>
        <cbc:AllowanceTotalAmount currencyID="SAR">{fmt2(inv.AllowanceTotalAmount)}</cbc:AllowanceTotalAmount>
        <cbc:PrepaidAmount currencyID="SAR">{fmt2(inv.PrepaidAmount)}</cbc:PrepaidAmount>
        <cbc:PayableAmount currencyID="SAR">{fmt2(inv.PayableAmount)}</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>
    {lines_xml}
</Invoice>
"""
    # إزالة الأسطر الفارغة المتكررة لتحسين التنسيق
    return "\n".join([ln for ln in xml_text.splitlines() if ln.strip() != ""])


# =========================
# 4) Example usage
# =========================
@router.post(
    "/generate-xml_invoice",
    response_model=InvoiceData,
    summary="Generate xml Invoice for ZATCA",
    description="""
    Generate xml Invoice for ZATCA
    يقوم بانشاء فاتورة XML متوافقة مع متطلبات ZATCA.
    """,
)
async def generate_xml_invoice(invoce: InvoiceData) -> Response:
    xml_output = render_invoice_xml(invoce)
    # اطبع أو احفظ الملف
    # print(xml_output)
    # with open("inv_003.xml", "w", encoding="utf-8") as f:
    #     f.write(xml_output)
    # print("\nSaved -> inv_003.xml")
    return Response(content=xml_output, media_type="application/xml")


def gen_invoice_file(invoce: InvoiceData) -> str:
    xml_output = render_invoice_xml(invoce)
    file_name = f"static/invoice_files/{invoce.UUID}.xml"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write(xml_output)
    return file_name
    # print("\nSaved -> inv_003.xml")

    """
    # invoice_data = {
    #     "ProfileID": "reporting:1.0",
    #     "ID": "SME00011",
    #     "UUID": "8e6000cf-1a98-4123-b3e7-b5d5954bc10d",
    #     "IssueDate": "2025-11-10",
    #     "IssueTime": "14:30:08",
    #     "InvoiceTypeCode": "388",
    #     "InvoiceTypeCodeName": "0200000",
    #     "Note": "ABC",
    #     "DocumentCurrencyCode": "SAR",
    #     "TaxCurrencyCode": "SAR",
    #     "BillingReference": "Invoice Number: 525; Invoice Issue Date: 2025-11-09",
    #     "AdditionalDocumentReferences": [
    #         {"ID": "ICV", "UUID": "10"},
    #         {
    #             "ID": "PIH",
    #             "Attachment": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
    #             "FileName": "pih.txt",
    #         },
    #     ],
    #     "SupplierStreetName": "Riyadh 1234 Street",
    #     "SupplierBuildingNumber": "2322",
    #     "SupplierCityName": "الرياض | Riyadh",
    #     "SupplierDistrict": "المربع | Al-Murabba",
    #     "SupplierPostalZone": "23333",
    #     "SupplierCountryCode": "SA",
    #     "SupplierVAT": "310232266400003",
    #     "SupplierName": "ebda-tatweer",
    #     "SupplierSchemeID": "CRN",
    #     "SupplierCRN": "5855353571",
    #     "CustomerStreetName": "Riyadh 1234 Street",
    #     "CustomerBuildingNumber": "1111",
    #     "CustomerCityName": "الرياض | Riyadh",
    #     "CustomerDistrict": "المروج | Al-Murooj",
    #     "CustomerPostalZone": "12222",
    #     "CustomerCountryCode": "SA",
    #     "CustomerVAT": "300332092200003",
    #     "CustomerName": "SME",
    #     "CustomerCRN": "2000020000",
    #     "DeliveryDate": "2025-12-07",
    #     "PaymentMeansCode": "10",
    #     "AllowanceCharge": {
    #         "ChargeIndicator": False,
    #         "Reason": "discount",
    #         "Amount": 0.00,
    #         "TaxCategories": [
    #             {"ID": "S", "Percent": 15, "SchemeID": "VAT"},
    #         ],
    #     },
    #     "InvoiceLines": [
    #         {
    #             "ID": "1",
    #             "UnitCode": "PCE",
    #             "Quantity": 33,
    #             "LineExtensionAmount": 99.00,
    #             "TaxAmount": 14.85,
    #             "RoundingAmount": 113.85,
    #             "Name": "كتاب",
    #             "TaxCategoryID": "S",
    #             "TaxPercent": 15.00,
    #             "PriceAmount": 3.00,
    #             "AllowanceCharge": {
    #                 "ChargeIndicator": False,
    #                 "Reason": "discount",
    #                 "Amount": 0.00,
    #             },
    #         },
    #         {
    #             "ID": "2",
    #             "UnitCode": "PCE",
    #             "Quantity": 3,
    #             "LineExtensionAmount": 102.00,
    #             "TaxAmount": 15.30,
    #             "RoundingAmount": 117.30,
    #             "Name": "قلم",
    #             "TaxCategoryID": "S",
    #             "TaxPercent": 15.00,
    #             "PriceAmount": 34.00,
    #             "AllowanceCharge": {
    #                 "ChargeIndicator": False,
    #                 "Reason": "discount",
    #                 "Amount": 0.00,
    #             },
    #         },
    #     ],
    #     "TaxAmount": 30.15,
    #     "TaxableAmount": 201.00,
    #     "TaxPercent": 15.00,
    #     "LineExtensionAmount": 201.00,
    #     "TaxExclusiveAmount": 201.00,
    #     "TaxInclusiveAmount": 231.15,
    #     "AllowanceTotalAmount": 0.00,
    #     "PrepaidAmount": 0.00,
    #     "PayableAmount": 231.15,
    # }
    # inv = InvoiceData(**invoce)

    """
