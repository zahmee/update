# type: ignore


import base64
import hashlib
import json
import sys
from pathlib import Path
from textwrap import wrap
from xml.etree import ElementTree as ET

from cryptography import x509
from cryptography.hazmat.primitives.serialization import (
    load_der_private_key,
    load_pem_private_key,
    Encoding,
    PublicFormat,
)
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend
import datetime

# -------------------------------
# Namespaces UBL/ZATCA
# -------------------------------
NS = {
    "ubl": "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
    "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
    "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
    "ext": "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2",
    "ds": "http://www.w3.org/2000/09/xmldsig#",
}


def get_text(elem):
    return (elem.text or "").strip() if elem is not None and elem.text else ""


def tlv(tag: int, value_bytes: bytes) -> bytes:
    """TLV بعرض واحد للـ Length (<=255)."""
    length = len(value_bytes)
    if length > 255:
        raise ValueError(
            f"TLV tag {tag}: length {length} > 255 bytes (تجاوز الحد المسموح)."
        )
    return bytes([tag, length]) + value_bytes


# -------------------------------
# 1) قراءة بيانات الفاتورة + PIH (Tags 1-6)
# -------------------------------


def extract_invoice_hash(root: ET.Element, xml_bytes: bytes) -> bytes:
    """
    استخراج هاش الفاتورة من PIH:
    - لو Base64 -> نفك
        - إذا 32 بايت -> ممتاز
        - إذا نص HEX داخل (64 خانة) -> نحوله لـ 32 بايت
    - لو HEX مباشر -> نحوله
    - لو ما ضبط: نستخدم SHA256 للـ XML كحل أخير
    """
    for adr in root.findall(".//cac:AdditionalDocumentReference", NS):
        doc_id = get_text(adr.find("./cbc:ID", NS))
        if doc_id == "PIH":
            emb = adr.find(".//cbc:EmbeddedDocumentBinaryObject", NS)
            pih_val = get_text(emb)
            if not pih_val:
                continue
                
            # نحاول Base64
            try:
                decoded = base64.b64decode(pih_val, validate=True)
                # إذا 32 بايت → هذا هو هاش SHA256
                if len(decoded) == 32:
                    return decoded
                # إذا يبان كنص HEX
                if all(chr(b).lower() in "0123456789abcdef" for b in decoded) and len(
                    decoded
                ) in (64, 128):
                    hx = decoded.decode()
                    if len(hx) % 2 == 0:
                        h_bytes = bytes.fromhex(hx)
                        if len(h_bytes) == 32:
                            return h_bytes
            except Exception:
                pass

            # نحاول HEX مباشر من pih_val
            try:
                if (
                    all(c.lower() in "0123456789abcdef" for c in pih_val)
                    and len(pih_val) % 2 == 0
                ):
                    h_bytes = bytes.fromhex(pih_val)
                    if len(h_bytes) == 32:
                        return h_bytes
            except Exception:
                pass

            # لو وصلنا هنا → PIH مش بالنمط المتوقع
            # نرجع SHA256 للـ XML كـ fallback (يشتغل، لكن راجع PIH عندك)
            return hashlib.sha256(xml_bytes).digest()

    # لو ما فيه PIH أساسًا → نستخدم SHA256 للـ XML
    return hashlib.sha256(xml_bytes).digest()


def parse_invoice_fields(xml_path: str):
    xml_bytes = Path(xml_path).read_bytes()
    root = ET.fromstring(xml_bytes)

    # 1) اسم البائع
    seller_name = get_text(
        root.find(
            ".//cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName",
            NS,
        )
    )
    if not seller_name:
        raise ValueError("لم يتم العثور على اسم البائع RegistrationName في الفاتورة.")

    # 2) رقم التسجيل الضريبي
    seller_vat = get_text(
        root.find(
            ".//cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID",
            NS,
        )
    )
    if not seller_vat:
        raise ValueError(
            "لم يتم العثور على رقم تسجيل ضريبة القيمة المضافة للبائع CompanyID في الفاتورة."
        )

    # 3) التاريخ والوقت
    issue_date = get_text(root.find("./cbc:IssueDate", NS))
    if not issue_date:
        raise ValueError("لم يتم العثور على IssueDate في الفاتورة.")
    issue_time = get_text(root.find("./cbc:IssueTime", NS)) or "00:00:00"
    timestamp = f"{issue_date}T{issue_time}"

    # 4) الإجمالي مع الضريبة
    tax_inclusive = root.find(".//cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount", NS)
    payable = root.find(".//cac:LegalMonetaryTotal/cbc:PayableAmount", NS)
    if tax_inclusive is not None and get_text(tax_inclusive):
        total_with_vat = get_text(tax_inclusive)
    elif payable is not None and get_text(payable):
        total_with_vat = get_text(payable)
    else:
        raise ValueError(
            "لم يتم العثور على TaxInclusiveAmount أو PayableAmount في الفاتورة."
        )

    # 5) إجمالي الضريبة
    vat_total_elem = root.find("./cac:TaxTotal/cbc:TaxAmount", NS)
    if vat_total_elem is None or not get_text(vat_total_elem):
        vat_total_elem = root.find(".//cac:TaxTotal/cbc:TaxAmount", NS)
    if vat_total_elem is None or not get_text(vat_total_elem):
        raise ValueError(
            "لم يتم العثور على إجمالي الضريبة (TaxTotal/TaxAmount) في الفاتورة."
        )
    vat_total = get_text(vat_total_elem)

    # 6) هاش الفاتورة
    invoice_hash = extract_invoice_hash(root, xml_bytes)
    if len(invoice_hash) != 32:
        # نكمّل لكن ننبه المطوّر في الرسالة
        raise ValueError(
            f"هاش الفاتورة الناتج طوله {len(invoice_hash)} بايت، والمتوقع 32. تحقق من PIH في الفاتورة."
        )

    return {
        "seller_name": seller_name,
        "seller_vat": seller_vat,
        "timestamp": timestamp,
        "total_with_vat": total_with_vat,
        "vat_total": vat_total,
        "invoice_hash": invoice_hash,
    }


# -------------------------------
# 2) قراءة privateKey + csid_cert2 (Tags 7-9)
# -------------------------------


def load_private_key_from_b64(b64_key: str):
    raw = base64.b64decode(b64_key)
    key = None

    # DER (PKCS#8) أولاً
    try:
        key = load_der_private_key(raw, password=None)
    except Exception:
        key = None

    # لو فشل، نجرب نحوله PEM
    if key is None:
        pem = (
            "-----BEGIN PRIVATE KEY-----\n"
            + "\n".join(wrap(b64_key, 64))
            + "\n-----END PRIVATE KEY-----\n"
        )
        try:
            key = load_pem_private_key(pem.encode(), password=None)
        except Exception:
            key = None

    if key is None:
        raise ValueError(
            "فشل تحميل privateKey من JSON. تأكد أنك ناسخه كامل بدون تعديل."
        )
    if not isinstance(key, ec.EllipticCurvePrivateKey):
        raise ValueError("المفتاح الخاص ليس ECDSA. تحقق من أنه مفتاح CSID الصحيح.")
    return key


def load_csid_cert_from_json(cfg: dict) -> x509.Certificate:
    """
    نستخدم csid_cert2 (شهادة CSID) كما أرسلتها ZATCA.
    لو فشلت نحاول csid_cert، ولو الاثنين ما ينفعوا → نرمي خطأ.
    """
    b64_cert = cfg.get("csid_cert2")
    if not b64_cert:
        raise ValueError("لا يوجد csid_cert2 أو csid_cert في JSON (شهادة CSID مفقودة).")
    # جرّب DER مباشرة
    cert = None
    # try:
    #     cert = x509.load_der_x509_certificate(base64.b64decode(b64_cert))
    #     print(" :::====>" , cert    )
    # except Exception as e:
    #     print("error:====> : ", e)
    #     cert = None

    # لو فشل DER، جرّب PEM
    if cert is None:
        pem =  f"-----BEGIN CERTIFICATE REQUEST-----\n{b64_cert}\n-----END CERTIFICATE REQUEST-----\n"
        try:
            cert = x509.load_pem_x509_csr(pem.encode("utf-8"), default_backend())
            # csr = x509.load_pem_x509_csr(b64_cert.encode("utf-8"), default_backend())
            # print("=====:::====>" , csr    )
        except Exception as e:
            print("error:====> : ", e)
            cert = None

    if cert is None:
        raise ValueError(
            "csid_cert2 غير صالح أو ناقص. تأكد أنك مستخدم القيمة الكاملة من شهادة CSID كما رجعت من ZATCA بدون '...'."
        )

    return cert


def load_crypto(config_path: str):
    cfg = json.loads(Path(config_path).read_text(encoding="utf-8"))

    if "privateKey" not in cfg:
        raise ValueError("ملف JSON لا يحتوي على privateKey.")
    private_key = load_private_key_from_b64(cfg["privateKey"])
    cert = load_csid_cert_from_json(cfg)
    # Tag 8: المفتاح العام من شهادة CSID (متوافق مع المفتاح الخاص)
    public_key = cert.public_key()
    public_key_bytes = public_key.public_bytes(
        encoding=Encoding.DER,
        format=PublicFormat.SubjectPublicKeyInfo,
    )

    # Tag 9: توقيع ZATCA على المفتاح العام (signature من الشهادة)
    csid_signature_bytes = cert.signature

    if len(public_key_bytes) > 255:
        raise ValueError("المفتاح العام أطول من 255 بايت (غير متوقع).")
    if len(csid_signature_bytes) > 255:
        raise ValueError("توقيع شهادة CSID أطول من 255 بايت (غير متوقع).")

    return {
        "private_key": private_key,
        "public_key_bytes": public_key_bytes,
        "csid_signature_bytes": csid_signature_bytes,
    }


# -------------------------------
# 3) بناء QR TLV (Phase 2)
# -------------------------------


def build_qr_base64(invoice_xml_path: str, config_json_path: str) -> str:
    inv = parse_invoice_fields(invoice_xml_path)
    crypto = load_crypto(config_json_path)

    # Tag 7: توقيع ECDSA على هاش الفاتورة
    invoice_signature = crypto["private_key"].sign(
        inv["invoice_hash"], ec.ECDSA(hashes.SHA256())
    )

    if len(invoice_signature) > 255:
        raise ValueError("طول توقيع الفاتورة (Tag 7) أكبر من 255 بايت (غير متوقع).")

    tlv_bytes = b""
    # 1-5 نصوص
    tlv_bytes += tlv(1, inv["seller_name"].encode("utf-8"))
    tlv_bytes += tlv(2, inv["seller_vat"].encode("utf-8"))
    tlv_bytes += tlv(3, inv["timestamp"].encode("utf-8"))
    tlv_bytes += tlv(4, inv["total_with_vat"].encode("utf-8"))
    tlv_bytes += tlv(5, inv["vat_total"].encode("utf-8"))
    # 6-9 قيم ثنائية حسب مواصفات المرحلة الثانية
    tlv_bytes += tlv(6, inv["invoice_hash"])
    tlv_bytes += tlv(7, invoice_signature)
    tlv_bytes += tlv(8, crypto["public_key_bytes"])
    tlv_bytes += tlv(9, crypto["csid_signature_bytes"])

    # القيمة النهائية للـ QR (Base64 للـ TLV)
    return base64.b64encode(tlv_bytes).decode("utf-8")


if __name__ == "__main__":
    invoice_xml = sys.argv[1] if len(sys.argv) > 1 else "inv_001.xml"
    config_json = sys.argv[2] if len(sys.argv) > 2 else "user_pass_zatca.json"
    qr_value = build_qr_base64(invoice_xml, config_json)
    print(qr_value)
