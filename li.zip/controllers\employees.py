# -*- coding: utf-8 -*-
#  type: ignore


@can_access(7001)
def index():
    sc = screens_rules(7001)
    return dict(
        can_add=sc.can_add if sc else False,
        can_edit=sc.can_edit if sc else False,
        can_delete=sc.can_delete if sc else False,
    )


def get_lookups():
    job_titles = db(db.key_job_titles.id > 0).select(
        db.key_job_titles.id, db.key_job_titles.name,
        orderby=db.key_job_titles.name
    )
    nationalities = db(db.key_nationalities.id > 0).select(
        db.key_nationalities.id, db.key_nationalities.name,
        orderby=db.key_nationalities.name
    )
    statuses = db(db.key_emp_status.id > 0).select(
        db.key_emp_status.id, db.key_emp_status.name,
        orderby=db.key_emp_status.id
    )
    auth_users = db(db.auth_user.id > 0).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
    )
    return response.json({
        "job_titles": job_titles,
        "nationalities": nationalities,
        "statuses": statuses,
        "auth_users": auth_users,
    })


def get_employees():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( e.emp_name LIKE %s OR e.id_number LIKE %s "
                "OR CAST(e.start_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])

    # فلتر حالة الموظف
    if ReqVar.emp_status and ReqVar.emp_status != '' and ReqVar.emp_status != '0':
        conditions.append("( e.emp_status = %s )")
        params.append(int(ReqVar.emp_status))

    # ترتيب
    allowed_sort_columns = {'id', 'emp_name', 'job_title', 'id_number', 'start_date', 'nationality', 'emp_status'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    # ترقيم
    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT e.id, e.emp_name, e.job_title, e.id_number, "
        f"e.start_date, e.nationality, e.emp_status, e.created_on, "
        f"e.mobile, e.user_id, "
        f"jt.name AS job_title_name, "
        f"nt.name AS nationality_name, "
        f"es.name AS emp_status_name, "
        f"COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
        f"FROM employees e "
        f"LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
        f"LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
        f"LEFT JOIN key_emp_status es ON es.id = e.emp_status "
        f"LEFT JOIN auth_user au ON au.id = e.user_id "
        f"{where} ORDER BY e.{sc} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM employees e "
        f"LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
        f"LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
        f"LEFT JOIN key_emp_status es ON es.id = e.emp_status "
        f"LEFT JOIN auth_user au ON au.id = e.user_id "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


@can_access(7001)
def new_employee():
    try:
        sc = screens_rules(7001)
        if not sc or not sc.can_add:
            return response.json({"id": 0, "mess": "غير مسموح بالإضافة"})
        data = request.vars

        start_date = None
        if data.start_date and data.start_date != '':
            start_date = data.start_date

        nid = db.employees.insert(
            emp_name=data.emp_name,
            job_title=int(data.job_title) if data.job_title else None,
            id_number=data.id_number or '',
            start_date=start_date,
            nationality=int(data.nationality) if data.nationality else None,
            emp_status=int(data.emp_status) if data.emp_status else None,
            mobile=data.mobile or '',
            user_id=int(data.user_id) if data.user_id else None,
        )
        db.commit()

        inserted = db.executesql(
            "SELECT e.id, e.emp_name, e.job_title, e.id_number, "
            "e.start_date, e.nationality, e.emp_status, e.created_on, "
            "e.mobile, e.user_id, "
            "jt.name AS job_title_name, "
            "nt.name AS nationality_name, "
            "es.name AS emp_status_name, "
            "COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
            "FROM employees e "
            "LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
            "LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
            "LEFT JOIN key_emp_status es ON es.id = e.emp_status "
            "LEFT JOIN auth_user au ON au.id = e.user_id "
            "WHERE e.id = %s",
            placeholders=[nid], as_dict=True
        )
        return response.json(inserted[0] if inserted else {"id": nid})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


@can_access(7001)
def update_employee():
    try:
        sc = screens_rules(7001)
        if not sc or not sc.can_edit:
            return response.json({"id": 0, "mess": "غير مسموح بالتعديل"})
        data = request.vars
        row = db.employees[data.id]
        if not row:
            return response.json({"id": 0, "mess": "السجل غير موجود"})

        row.emp_name = data.emp_name
        row.job_title = int(data.job_title) if data.job_title else None
        row.id_number = data.id_number or ''
        row.nationality = int(data.nationality) if data.nationality else None
        row.emp_status = int(data.emp_status) if data.emp_status else None
        row.mobile = data.mobile or ''
        row.user_id = int(data.user_id) if data.user_id else None

        if data.start_date and data.start_date != '':
            row.start_date = data.start_date
        else:
            row.start_date = None

        row.update_record()
        db.commit()

        updated = db.executesql(
            "SELECT e.id, e.emp_name, e.job_title, e.id_number, "
            "e.start_date, e.nationality, e.emp_status, e.created_on, "
            "e.mobile, e.user_id, "
            "jt.name AS job_title_name, "
            "nt.name AS nationality_name, "
            "es.name AS emp_status_name, "
            "COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
            "FROM employees e "
            "LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
            "LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
            "LEFT JOIN key_emp_status es ON es.id = e.emp_status "
            "LEFT JOIN auth_user au ON au.id = e.user_id "
            "WHERE e.id = %s",
            placeholders=[data.id], as_dict=True
        )
        return response.json(updated[0] if updated else {"id": data.id})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


@can_access(7001)
def delete_employee():
    try:
        sc = screens_rules(7001)
        if not sc or not sc.can_delete:
            return response.json({"status": 0, "mess": "غير مسموح بالحذف"})
        row = db.employees[request.args(0)]
        if not row:
            return response.json({"status": 0, "mess": "السجل غير موجود"})
        row.delete_record()
        db.commit()
        return response.json({"status": 1})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"status": 0, "mess": str(e)})
