var API_BASE = window.location.href + '/../../advances/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
            status_filter: '0'
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        employees_list: [],
        advance_types: [],
        loading: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    created: function () {
        this.loading = true;
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.employees_list = data.employees;
                this.advance_types = data.advance_types;
            }.bind(this));
        this.fetchData().then(function (data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                status_filter: this.getData.status_filter,
            };
            var url = new URL(API_BASE + 'get_advances');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
            // تحويل boolean من PostgreSQL
            this.edit_row_data.is_closed = (row.is_closed === 'T' || row.is_closed === true);
        },
        edit_row: function () {
            this.new_row = false;
        },
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_data: function () {
            if (!this.edit_row_data.employee) {
                Swal.fire('تنبيه', 'يجب اختيار الموظف', 'error');
                return;
            }
            if (!this.edit_row_data.advance_type) {
                Swal.fire('تنبيه', 'يجب اختيار نوع السلفة', 'error');
                return;
            }
            if (!this.edit_row_data.amount) {
                Swal.fire('تنبيه', 'يجب إدخال المبلغ', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('employee', this.edit_row_data.employee);
            formData.append('advance_type', this.edit_row_data.advance_type);
            formData.append('amount', this.edit_row_data.amount);
            formData.append('advance_date', this.edit_row_data.advance_date || '');

            var endpoint = this.new_row ? 'new_advance' : 'update_advance';
            if (!this.new_row) {
                formData.append('id', this.edit_row_data.id);
                formData.append('paid_amount', this.edit_row_data.paid_amount || 0);
                formData.append('is_closed', this.edit_row_data.is_closed ? 'true' : 'false');
                formData.append('closed_date', this.edit_row_data.closed_date || '');
            }

            var self = this;
            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.id && data.id > 0) {
                        if (self.new_row) {
                            self.data.splice(0, 0, data);
                            self.data_row_count++;
                        } else {
                            self.$set(self.data, self.selectedRow, data);
                        }
                        self.edit_row_data = {};
                        self.selectedRow = -1;
                        self.new_row = true;
                        bootstrap.Modal.getInstance(document.getElementById("advModal")).hide();
                        Swal.fire('تم بنجاح', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        delete_adv: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف سلفة: ' + row.emp_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_advance/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ أثناء الحذف', 'error');
                            }
                        });
                }
            });
        },
        cancel_data: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        isClosed: function (row) {
            return row.is_closed === 'T' || row.is_closed === true;
        },
        remaining: function (row) {
            return (parseFloat(row.amount) || 0) - (parseFloat(row.paid_amount) || 0);
        },
        formatNum: function (n) {
            if (n === null || n === undefined) return '0.00';
            return parseFloat(n).toFixed(2);
        },
    }
});
