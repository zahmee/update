# type: ignore

import os
import sys
import json
from pathlib import Path
import subprocess
import uuid


def c_xml():
    return create_xml_invoce()


screens_code = [
    # ====== نظام العملاء (1000) ======
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    # ====== فواتير التوريد (2000) ======
    {"systems": 1, "name": "فواتير التوريد - استعراض", "screen_code": 2001},
    # ====== عروض الأسعار (3000) ======
    {"systems": 1, "name": "عروض الأسعار - استعراض", "screen_code": 3001},
    # ====== المبيعات (4000) ======
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض فاتورة", "screen_code": 4003},
    # ====== التقارير (5000) ======
    {"systems": 1, "name": "التقارير - التقارير المحاسبية", "screen_code": 5001},
    # ====== ZATCA (6000) ======
    {"systems": 1, "name": "ZATCA - Onboarding", "screen_code": 6001},
    {"systems": 1, "name": "ZATCA - Direct Submit", "screen_code": 6002},
    {"systems": 1, "name": "ZATCA - QR Parser", "screen_code": 6003},
    # ====== شؤون الموظفين (7000) ======
    {"systems": 1, "name": "الموارد البشرية - الموظفين", "screen_code": 7001},
    {"systems": 1, "name": "الموارد البشرية - الرواتب", "screen_code": 7002},
    {"systems": 1, "name": "الموارد البشرية - السلف", "screen_code": 7003},
    {"systems": 1, "name": "الموارد البشرية - الإجازات", "screen_code": 7004},
    {"systems": 1, "name": "الموارد البشرية - مسير الرواتب", "screen_code": 7005},
    {"systems": 1, "name": "الموارد البشرية - الحضور والانصراف", "screen_code": 7006},
    # ====== مستنداتي (8000) ======
    {"systems": 1, "name": "مستنداتي - إدارة المستندات", "screen_code": 8001},
    # ====== الإعدادات (9000) ======
    {"systems": 1, "name": "الإعدادات - معلومات الشركة", "screen_code": 9001},
    {"systems": 1, "name": "الإعدادات - ZATCA Config", "screen_code": 9002},
]


@auth.requires_membership("admin")
def unit_key():
    grid = SQLFORM.grid(
        db.key_unit,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def type_key():
    grid = SQLFORM.grid(
        db.key_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def payment_method_key():
    grid = SQLFORM.grid(
        db.key_payment_method.id > 3,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def update_items_det():
    qry = "update items_det set  item_id = (select item_id from items_main where id = items_det.item_idr )"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def update_items_main1():
    qry = "update items_main set  vat = 0.0 where vat is null "
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def print_report():
    grid = SQLFORM.grid(
        db.print_report,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def users():
    links = [
        lambda row: A(
            I(" ", _class="far fa-key"),
            " صلاحيات المستخدم ",
            _class="btn btn-info ",
            _title="صلاحيات المستخدم",
            _href=URL("setup", "screens_rules", args=[row.id]),
        )
    ]
    grid = SQLFORM.grid(
        db.auth_user,
        links=links,
        user_signature=True,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ====================================================================
@auth.requires(auth.has_membership("admin"))
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ===============================================
@auth.requires(auth.has_membership("admin"))
def screens():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@auth.requires(auth.has_membership("admin"))
def screens_rules():
    user_id = request.args(0)
    # 1. تأكد من وجود كل الشاشات في جدول screens
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.commit()
    # 2. تأكد من أن كل شاشة لها سجل في screens_rules لهذا المستخدم (حتى لو false)
    all_screens = db(db.screens.id > 0).select()
    for scr in all_screens:
        existing = db(
            (db.screens_rules.screens == scr.id) & (db.screens_rules.to_user == user_id)
        ).select().first()
        if not existing:
            db.screens_rules.insert(
                screens=scr.id,
                to_user=user_id,
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    return dict()


# ===================== API for screens_rules Vue.js =====================

@auth.requires(auth.has_membership("admin"))
def get_screens_rules():
    """جلب صلاحيات الشاشات للمستخدم مع pagination"""
    user_id = request.args(0)
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    offset = pg * rc
    sql = (
        "SELECT sr.id, sr.screens, sr.can_log_in, sr.can_add, sr.can_edit, sr.can_delete, "
        "s.name as screen_name, s.screen_code "
        "FROM screens_rules sr "
        "JOIN screens s ON s.id = sr.screens "
        "WHERE sr.to_user = %s "
        "ORDER BY s.screen_code "
        "LIMIT %s OFFSET %s"
    )
    rows = db.executesql(sql, placeholders=[user_id, rc, offset], as_dict=True)
    count_sql = "SELECT COUNT(*) FROM screens_rules WHERE to_user = %s"
    count = db.executesql(count_sql, placeholders=[user_id])[0][0]
    return response.json({"data": rows, "count": count})


@auth.requires(auth.has_membership("admin"))
def get_available_screens():
    """جلب الشاشات غير المضافة للمستخدم"""
    user_id = request.args(0)
    sql = (
        "SELECT s.id, s.name, s.screen_code "
        "FROM screens s "
        "WHERE s.id NOT IN ("
        "   SELECT screens FROM screens_rules WHERE to_user = %s"
        ") ORDER BY s.screen_code"
    )
    rows = db.executesql(sql, placeholders=[user_id], as_dict=True)
    return response.json(rows)


@auth.requires(auth.has_membership("admin"))
def save_rule():
    """حفظ أو تحديث صلاحية"""
    try:
        data = request.vars
        rule_id = data.get("id")
        if rule_id:
            row = db.screens_rules[rule_id]
            if row:
                row.update_record(
                    can_log_in=data.get("can_log_in") == "true",
                    can_add=data.get("can_add") == "true",
                    can_edit=data.get("can_edit") == "true",
                    can_delete=data.get("can_delete") == "true",
                )
        else:
            db.screens_rules.insert(
                to_user=int(data.get("to_user")),
                screens=int(data.get("screens")),
                can_log_in=data.get("can_log_in") == "true",
                can_add=data.get("can_add") == "true",
                can_edit=data.get("can_edit") == "true",
                can_delete=data.get("can_delete") == "true",
            )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def delete_rule():
    """حذف صلاحية"""
    try:
        db(db.screens_rules.id == request.args(0)).delete()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


#
@auth.requires(auth.has_membership("admin"))
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@auth.requires(auth.has_membership("admin"))
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


# ===================== API grant_all / delete_all for Vue.js =====================

@auth.requires(auth.has_membership("admin"))
def api_grant_all():
    """منح جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=True, can_add=True, can_edit=True, can_delete=True
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=True,
                    can_add=True,
                    can_edit=True,
                    can_delete=True,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def api_delete_all():
    """حذف جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=False, can_add=False, can_edit=False, can_delete=False
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=False,
                    can_add=False,
                    can_edit=False,
                    can_delete=False,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ============================================================================
#         إدارة المستخدمين والصلاحيات - Users Management (Vue.js)
# ============================================================================

@auth.requires(auth.has_membership("admin"))
def users_management():
    return dict()


@auth.requires(auth.has_membership("admin"))
def get_users():
    """جلب المستخدمين مع pagination وبحث"""
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    search = request.vars.SearchText or ""
    offset = pg * rc

    conditions = []
    params = []
    if search.strip():
        pattern = "%" + search.strip() + "%"
        conditions.append(
            "(first_name LIKE %s OR last_name LIKE %s OR email LIKE %s)"
        )
        params.extend([pattern, pattern, pattern])

    where = ""
    if conditions:
        where = "WHERE " + " AND ".join(conditions)

    sql = (
        "SELECT id, first_name, last_name, email, registration_key, "
        "COALESCE(NULLIF(first_name || ' ' || last_name, ' '), first_name, last_name, email) as full_name "
        "FROM auth_user " + where + " ORDER BY id LIMIT %s OFFSET %s"
    )
    params.extend([rc, offset])
    rows = db.executesql(sql, placeholders=params, as_dict=True)

    count_sql = "SELECT COUNT(*) FROM auth_user " + where
    if conditions:
        count_rows = db.executesql(count_sql, placeholders=params[:-2], as_dict=False)
    else:
        count_rows = db.executesql(count_sql, as_dict=False)
    count = count_rows[0][0]

    return response.json({"data": rows, "count": count})


@auth.requires(auth.has_membership("admin"))
def get_user_detail():
    """جلب تفاصيل مستخدم"""
    user_id = request.args(0)
    row = db(db.auth_user.id == user_id).select().first()
    if not row:
        return response.json({"err": 1, "mess": "المستخدم غير موجود"})
    return response.json({
        "id": row.id,
        "first_name": row.first_name,
        "last_name": row.last_name,
        "email": row.email,
        "username": row.username,
        "registration_key": row.registration_key,
    })


@auth.requires(auth.has_membership("admin"))
def save_user():
    """إضافة أو تعديل مستخدم"""
    try:
        data = request.vars
        user_id = data.get("id")
        if user_id:
            row = db.auth_user[user_id]
            if row:
                row.update_record(
                    first_name=data.first_name,
                    last_name=data.last_name,
                    email=data.email,
                )
                if data.password and str(data.password).strip():
                    row.update_record(password=db.auth_user.password.validate(data.password)[0])
        else:
            password = db.auth_user.password.validate(data.password or "5445Za@")[0]
            user_id = db.auth_user.insert(
                first_name=data.first_name,
                last_name=data.last_name,
                email=data.email,
                password=password,
            )
        db.commit()
        return response.json({"err": 0, "id": user_id})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def delete_user():
    """حذف/تعطيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if row:
            # تعطيل المستخدم بدلاً من الحذف الفعلي (آمن)
            row.update_record(registration_key="disabled")
            db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def activate_user():
    """تفعيل مستخدم معطل"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if row:
            row.update_record(registration_key="")
            db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def get_groups():
    """جلب كل المجموعات"""
    rows = db(db.auth_group.id > 0).select(db.auth_group.id, db.auth_group.role, orderby=db.auth_group.role)
    return response.json(rows.as_list())


@auth.requires(auth.has_membership("admin"))
def get_user_membership():
    """جلب عضويات المستخدم"""
    user_id = request.args(0)
    sql = (
        "SELECT am.id, am.user_id, am.group_id, ag.role "
        "FROM auth_membership am "
        "JOIN auth_group ag ON ag.id = am.group_id "
        "WHERE am.user_id = %s"
    )
    rows = db.executesql(sql, placeholders=[user_id], as_dict=True)
    return response.json(rows)


@auth.requires(auth.has_membership("admin"))
def save_membership():
    """حفظ أو حذف عضوية"""
    try:
        data = request.vars
        user_id = data.get("user_id")
        group_id = data.get("group_id")
        checked = data.get("checked") == "true"

        if checked:
            # إضافة عضوية
            existing = db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).select().first()
            if not existing:
                db.auth_membership.insert(user_id=user_id, group_id=group_id)
        else:
            # حذف عضوية
            db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).delete()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9001)
def important_info():
    q = db(db.important_info.id > 0).select().first()
    logo_url = ''
    if q and q.logo:
        logo_url = URL('default', 'download', args=q.logo)
    return dict(row=q, logo_url=logo_url)


def important_info_load():
    q = db(db.important_info.id > 0).select().first()
    if not q:
        return response.json(dict(err=1, mess="لا توجد بيانات"))
    logo_url = ''
    if q.logo:
        logo_url = URL('default', 'download', args=q.logo)
    return response.json(dict(
        id=q.id,
        name=q.name or '',
        vat=q.vat or '',
        tel=q.tel or '',
        mobile=q.mobile or '',
        address=q.address or '',
        msg1=q.msg1 or '',
        msg2=q.msg2 or '',
        currency=q.currency or '',
        send_sms=q.send_sms if q.send_sms is not None else True,
        logo_url=logo_url,
    ))


def important_info_save():
    try:
        rec = db(db.important_info.id > 0).select().first()
        if not rec:
            return response.json(dict(err=1, mess="لا توجد بيانات"))
        rec.name = request.vars.name
        rec.vat = request.vars.vat or ''
        rec.tel = request.vars.tel
        rec.mobile = request.vars.mobile
        rec.address = request.vars.address or ''
        rec.msg1 = request.vars.msg1 or ''
        rec.msg2 = request.vars.msg2 or ''
        rec.currency = request.vars.currency or ''
        rec.send_sms = request.vars.send_sms == 'true'
        attachment = request.vars.logo
        if attachment is not None and hasattr(attachment, 'file') and attachment.filename:
            rec.logo = db.important_info.logo.store(attachment.file, attachment.filename)
        rec.update_record()
        db.commit()
        return response.json(dict(err=0, mess="تم الحفظ بنجاح"))
    except Exception as e:
        db.rollback()
        return response.json(dict(err=1, mess=str(e)))


def important_info_2():
    redirect(URL('setup', 'important_info'))


def t1():
    return dict()


# ========================================================
@auth.requires_membership("admin")
def update_crus():
    qry = "CREATE EXTENSION tablefunc;"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def sample_item():
    grid = SQLFORM.grid(
        db.sample_item,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9002)
def zatca_info():
    # Print the data of dictionary
    # print("\nLinux:", data['Linux'])
    # print("\nPeople2:", data['people2'])
    # data['Linux'] = ["ahmed"]
    # data['zahmee'] = "ahmed zahmah"

    q = db(db.important_info.id > 0).select().first()
    logo_url = ''
    if q and q.logo:
        logo_url = URL('default', 'download', args=q.logo)
    return dict(
        zatca_info=q,
        logo_url=logo_url,
        # Linux=data['Linux'],
        # people2=data['people2'],
    )


@can_access(9002)
def get_zatca_info():
    q = db(db.important_info.id > 0).select().first()
    if not q:
        return response.json(dict(err=1, mess="لا توجد بيانات"))
    logo_url = ''
    if q.logo:
        logo_url = URL('default', 'download', args=q.logo)
    return response.json(dict(
        id=q.id,
        name=q.name or '',
        vat=q.vat or '',
        tel=q.tel or '',
        mobile=q.mobile or '',
        address=q.address or '',
        msg1=q.msg1 or '',
        msg2=q.msg2 or '',
        currency=q.currency or '',
        send_sms=q.send_sms if q.send_sms is not None else True,
        logo_url=logo_url,
    ))


@can_access(9002)
def get_zatca_info_files():
    q = db(db.important_info.id > 0).select().first()
    return dict(
        logo_url=URL('default', 'download', args=q.logo),
    )


@can_access(9002)
def csr_config():
    import glob
    q = db(db.csr_config.id > 0).select().first()
    if q:
        cr = db(db.csr_config.id > 0).select().first()
    files = []
    if q:
        for f in glob.glob("applications/light/private/*"):
            files.append(os.path.basename(f))
    return dict(files=files, cr=cr)


@can_access(9002)
def git_csr_config():
    q = db(db.csr_config.id > 0).select().first()
    return response.json(q.as_dict() if q else {})


@can_access(9002)
def update_csr_config():
    try:
        v = request.vars
        rec = db(db.csr_config.id > 0).select().first()
        if rec:
            rec.update_record(
                organization_name=v.organization_name,
                organization_identifier=v.organization_identifier,
                organization_unit_name=v.organization_unit_name,
                address_city_name=v.address_city_name,
                address_street_name=v.address_street_name,
                address_postal_zone=v.address_postal_zone,
                address_building_number=v.address_building_number,
                address_neighborhood=v.address_neighborhood,
                location_address=v.location_address,
                business_category=v.business_category,
                company_id=v.company_id,
                company_uuid=v.company_uuid,
                otp=v.otp,
                serial_number=v.serial_number,
                common_name=v.common_name,
                invoice_type=v.invoice_type,
                environment=v.environment,
            )
        db.commit()
        return response.json(dict(err=0, mess="تم الحفظ بنجاح"))
    except Exception as e:
        db.rollback()
        return response.json(dict(err=1, mess=str(e)))


@can_access(9002)
def create_csr():
    ReqVar = request.vars
    # Generate private key and CSR using OpenSSL commands
    config = {
        "csr_config": {
            "otp": ReqVar.otp,
            "serial_number": ReqVar.serial_number,
            "common_name": ReqVar.common_name,
            "organization_name": ReqVar.organization_name,
            "organization_identifier": ReqVar.organization_identifier,
            "organization_unit_name": ReqVar.organization_unit_name,
            "country_name": "SA",
            "invoice_type": ReqVar.invoice_type,
            "location_address": ReqVar.location_address,
            "business_category": ReqVar.business_category,
            "address_city_name": ReqVar.address_city_name,
            "address_street_name": ReqVar.address_street_name,
            "address_postal_zone": ReqVar.address_postal_zone,
            "address_building_number": ReqVar.address_building_number,
            "address_neighborhood": ReqVar.address_neighborhood,
            "company_id": ReqVar.company_id,
            "company_uuid": ReqVar.company_uuid,
        }
    }

    # Save configuration to a JSON file
    json_file_path = os.path.join(request.folder, "private", "zatca.json")
    with open(json_file_path, "w", encoding="utf-8") as json_file:
        json.dump(config, json_file, ensure_ascii=False, indent=4)

    return response.json({"message": "Configuration saved successfully", "file": json_file_path})
