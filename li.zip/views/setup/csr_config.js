var app = new Vue({
  el: "#app",
  data: {
    counter: 0,
    data: [],
    getData: {
      page: 0,
      RecordCount: 20,
      SearchText: "",
      SortBy: "id",
      sortAsc: true,
    },
    data_row_count: 0,
    coding: {
      supplier: [],
      Allsupplier: [],
      types: [],
      units: [],
    },
    select_obj_1: {
      serch_text: "",
      show_select: false,
      select_value: "",
      select_id: "",
    },
    select_obj_2: 0,
    showBtn: 0,
    show_model: false,
    selectedRow: -1,
    text_ltr: false,
    new_row: true,
    edit_row_data: {
      country_name: "SA",
      organization_unit_name: "1",
    },
    value: "",
    options: [],
    phase1: false,
    phase2: false,
  },
  created() {
    fetch(window.location.href + "/../git_csr_config", {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        // console.log(data);
        this.edit_row_data = data;
      })
      .then(() => { });
  },
  methods: {
    chkdata() {
      if (!this.edit_row_data.organization_name) {
        Swal.fire("تنبية", "يجب ادخال [اسم النشاط ] .", "error");
        return false;
      } else if (
        !this.edit_row_data.organization_identifier ||
        this.edit_row_data.organization_identifier.length != 15
      ) {
        Swal.fire(
          "تنبية",
          "يجب ادخال [ الرقم الضريبي بالشكل الصحيح 15 خانة و يبدأ برقم 3 ] ",
          "error"
        );
        return false;
      } else if (!this.edit_row_data.organization_unit_name) {
        Swal.fire("تنبية", "يجب ادخال [ اسم او رقم الفرع ] .", "error");
        return false;
      } else if (
        !this.edit_row_data.location_address ||
        this.edit_row_data.location_address.length != 8
      ) {
        Swal.fire(
          "تنبية",
          "يجب ادخال [ العنوان المختصر يجب ان يتكون من 8 خانات] .",
          "error"
        );
        return false;
      } else if (!this.edit_row_data.business_category) {
        Swal.fire("تنبية", "يجب ادخال [ تصنيف العميل ] .", "error");
        return false;
      } else if (
        !this.edit_row_data.otp ||
        this.edit_row_data.otp.length != 6
      ) {
        Swal.fire(
          "تنبية",
          "يجب ادخال [ الرقم السري لمرة واحدة  يجب ان يكون 6 ارقام] .",
          "error"
        );
        return false;
      } else if (!this.edit_row_data.address_city_name) {
        Swal.fire("تنبية", "يجب ادخال [ المدينة ] .", "error");
        return false;
      } else if (!this.edit_row_data.address_street_name) {
        Swal.fire("تنبية", "يجب ادخال [ اسم الشارع ] .", "error");
        return false;
      } else if (
        !this.edit_row_data.address_postal_zone ||
        this.edit_row_data.address_postal_zone.length != 5
      ) {
        Swal.fire("تنبية", "يجب ادخال [ الرمز البريدي  5 ارقام] .", "error");
        return false;
      } else if (
        !this.edit_row_data.address_building_number ||
        this.edit_row_data.address_building_number.length != 4
      ) {
        Swal.fire("تنبية", "يجب ادخال [ رقم المبنى 4 ارقام] .", "error");
        return false;
      } else if (
        !this.edit_row_data.company_id ||
        this.edit_row_data.company_id.length != 10
      ) {
        Swal.fire(
          "تنبية",
          "يجب ادخال [ السجل التجاري  10 خانات يبدأ ب 7] .",
          "error"
        );
        return false;
      } else {
        return true;
      }
    },
    save_data() {
      if (this.chkdata() == false) {
        return;
      }
      // تعديل
      //
      var url = new URL(window.location.href + "/../update_csr_config");
      params = this.edit_row_data;
      fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(params),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data == "0") {
            $("#exampleModal").modal("hide");
            Swal.fire(
              "عمل رائع",
              "شكرا لك لقد تمت عملية الحفظ بشكل صحيح",
              "success"
            );
          } else {
            Swal.fire("تنبية", data.mess, "error");
          }
        });
    },
    connect_zatca() {
      if (this.chkdata() == false) {
        return;
      }
      var url = new URL(window.location.href + "/../../zatca/generate_csid");
      params = {
        environmentType: this.edit_row_data.environment,
        C: "SA",
        O: this.edit_row_data.organization_name,
        OU: this.edit_row_data.organization_unit_name,
        CN: this.edit_row_data.company_id,
        VAT: this.edit_row_data.organization_identifier,
        CRN: this.edit_row_data.company_id,
        ADDRESS: this.edit_row_data.location_address,
        CATEGORY: this.edit_row_data.business_category,
        TITLE: "1100",
        OTP: this.edit_row_data.otp,
      };
      fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(params),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data["status"] == "ok") {
            this.phase1 = true;
            $("#exampleModal").modal("hide");
            Swal.fire(
              "عمل رائع",
              "تمت عملية الاتصال بنجاح ",
              "success"
            );
            fetch(window.location.href + "/../git_csr_config", {
              headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
              },
            })
              .then((response) => response.json())
              .then((data) => {
                // console.log(data);
                this.edit_row_data = data;
              })
              .then(() => { });
          } else {
            Swal.fire("تنبية", data.mess, "error");
          }
        });
    },
    convertKeysToLowerCase(jsonObject) {
      if (
        typeof jsonObject !== "object" ||
        jsonObject === null ||
        Array.isArray(jsonObject)
      ) {
        return jsonObject;
      }
      const lowerCaseObject = Object.keys(jsonObject).reduce((acc, key) => {
        const lowerCaseKey = key.toLowerCase();
        const value = jsonObject[key];
        if (typeof value === "object" && value !== null) {
          acc[lowerCaseKey] = convertKeysToLowerCase(value);
        } else {
          acc[lowerCaseKey] = value;
        }
        return acc;
      }, {});
      return lowerCaseObject;
    },
    export_json() {
      const dataStr = JSON.stringify(this.edit_row_data, null, 2);
      const dataUri =
        "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);
      const exportFileDefaultName = "edit_row_data.json";
      const linkElement = document.createElement("a");
      linkElement.setAttribute("href", dataUri);
      linkElement.setAttribute("download", exportFileDefaultName);
      linkElement.click();
    },
    import_json() {
      this.$refs.fileInput.click();
    },
    handle_file_upload(event) {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const json = JSON.parse(e.target.result);
          this.edit_row_data = json;
          Swal.fire("نجاح", "تم استيراد الملف بنجاح", "success");
        } catch (error) {
          Swal.fire("خطأ", "فشل قراءة الملف. تأكد من صحة الملف.", "error");
        }
      };
      reader.readAsText(file);
      // Clear the input so the same file can be selected again if needed
      event.target.value = "";
    },
  },
});
