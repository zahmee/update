var API_BASE = window.location.href.replace(/\/view_month\/.*$/, '/');

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
        },
        fixed_month: PAYROLL_MONTH,
        fixed_year: PAYROLL_YEAR,
        period_id: PERIOD_ID,
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        edit_row_data: {},
        new_form: { employee: '' },
        // lookups
        employees_list: [],
        ad_types: [],
        // details
        details: [],
        detailLoading: false,
        new_detail: true,
        detail_form: { allowance_deduction: '', amount: '', notes: '' },
        loading: false,
        adding_all: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        allowances: function () {
            return this.ad_types.filter(function (a) { return a.ad_type === 'بدل'; });
        },
        deductions: function () {
            return this.ad_types.filter(function (a) { return a.ad_type === 'خصم'; });
        },
        totals: function () {
            var t = { basic_salary: 0, total_allowances: 0, total_deductions: 0, net_salary: 0, advance_remaining: 0 };
            for (var i = 0; i < this.data.length; i++) {
                var r = this.data[i];
                t.basic_salary += parseFloat(r.basic_salary) || 0;
                t.total_allowances += parseFloat(r.total_allowances) || 0;
                t.total_deductions += parseFloat(r.total_deductions) || 0;
                t.net_salary += parseFloat(r.net_salary) || 0;
                t.advance_remaining += parseFloat(r.advance_remaining) || 0;
            }
            return t;
        },
    },
    created: function () {
        this.loading = true;
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.employees_list = data.employees;
                this.ad_types = data.ad_types;
            }.bind(this));
        this.fetchData().then(function (data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                emp_filter: '0',
                month_filter: this.fixed_month,
                year_filter: this.fixed_year,
            };
            var url = new URL(API_BASE + 'get_payrolls');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.details = [];
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.details = [];
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
            this.loadDetails(row.id);
        },
        loadDetails: function (payrollId) {
            var self = this;
            self.detailLoading = true;
            fetch(API_BASE + 'get_payroll_details/' + payrollId)
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    self.details = data;
                    self.detailLoading = false;
                });
        },
        edit_row: function () {},
        new_row_click: function () {
            this.new_form = { employee: '' };
        },
        save_new_payroll: function () {
            if (!this.new_form.employee) {
                Swal.fire('تنبيه', 'يجب اختيار الموظف', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('employee', this.new_form.employee);
            formData.append('pay_month', this.fixed_month);
            formData.append('pay_year', this.fixed_year);

            var self = this;
            fetch(API_BASE + 'new_payroll', {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.id && data.id > 0) {
                        bootstrap.Modal.getInstance(document.getElementById("payrollModal")).hide();
                        Swal.fire('تم بنجاح', 'تم إنشاء المسير بنجاح', 'success');
                        self.onChange();
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        save_edit_payroll: function () {
            var formData = new FormData();
            formData.append('id', this.edit_row_data.id);
            formData.append('basic_salary', this.edit_row_data.basic_salary);

            var self = this;
            var payrollId = this.edit_row_data.id;
            fetch(API_BASE + 'update_payroll', {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status === 'success') {
                        bootstrap.Modal.getInstance(document.getElementById("editModal")).hide();
                        Swal.fire('تم بنجاح', 'تم تعديل الراتب الأساسي', 'success');
                        self.refreshAndReselect(payrollId);
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        delete_payroll: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف مسير: ' + row.emp_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_payroll/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                self.details = [];
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ أثناء الحذف', 'error');
                            }
                        });
                }
            });
        },
        // ====== التفاصيل (بدلات/خصومات) ======
        openDetailModal: function (isNew) {
            this.new_detail = isNew;
            if (isNew) {
                this.detail_form = { allowance_deduction: '', amount: '', notes: '' };
            }
            bootstrap.Modal.getOrCreateInstance(document.getElementById("detailModal")).show();
        },
        editDetail: function (d) {
            this.new_detail = false;
            this.detail_form = {
                id: d.id,
                allowance_deduction: d.allowance_deduction,
                amount: d.amount,
                notes: d.notes || ''
            };
            bootstrap.Modal.getOrCreateInstance(document.getElementById("detailModal")).show();
        },
        save_detail: function () {
            if (!this.detail_form.allowance_deduction) {
                Swal.fire('تنبيه', 'يجب اختيار البدل أو الخصم', 'error');
                return;
            }
            if (!this.detail_form.amount) {
                Swal.fire('تنبيه', 'يجب إدخال المبلغ', 'error');
                return;
            }

            var self = this;
            var row = this.data[this.selectedRow];
            var formData = new FormData();
            formData.append('payroll_id', row.id);
            formData.append('allowance_deduction', this.detail_form.allowance_deduction);
            formData.append('amount', this.detail_form.amount);
            formData.append('notes', this.detail_form.notes || '');

            var endpoint = this.new_detail ? 'add_detail' : 'update_detail';
            if (!this.new_detail) {
                formData.append('id', this.detail_form.id);
            }

            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status === 'success') {
                        bootstrap.Modal.getInstance(document.getElementById("detailModal")).hide();
                        Swal.fire('تم', 'تم الحفظ بنجاح', 'success');
                        self.loadDetails(row.id);
                        self.refreshAndReselect(row.id);
                    } else {
                        Swal.fire('خطأ', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        deleteDetail: function (d) {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف: ' + d.ad_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_detail/' + d.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                                self.loadDetails(row.id);
                                self.refreshAndReselect(row.id);
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ', 'error');
                            }
                        });
                }
            });
        },
        refreshAndReselect: function (payrollId) {
            var self = this;
            self.loading = true;
            self.fetchData().then(function (d) {
                self.data = d.data;
                self.data_row_count = d.count;
                self.selectedRow = -1;
                for (var i = 0; i < self.data.length; i++) {
                    if (self.data[i].id === payrollId) {
                        self.selectedRow = i;
                        self.edit_row_data = Object.assign({}, self.data[i]);
                        break;
                    }
                }
            }).finally(function () { self.loading = false; });
        },
        cancel_data: function () {
            this.edit_row_data = {};
            this.selectedRow = -1;
            this.details = [];
        },
        formatNum: function (n) {
            if (n === null || n === undefined) return '0.00';
            return parseFloat(n).toFixed(2);
        },
        add_all_employees: function () {
            var self = this;
            Swal.fire({
                title: 'إضافة جميع الموظفين',
                text: 'سيتم إضافة جميع الموظفين الذين لم يُضافوا بعد مع بدلاتهم وخصوماتهم',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم، أضف الجميع',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    self.adding_all = true;
                    var formData = new FormData();
                    formData.append('pay_month', self.fixed_month);
                    formData.append('pay_year', self.fixed_year);
                    fetch(API_BASE + 'add_all_employees', {
                        method: 'POST',
                        body: formData
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            self.adding_all = false;
                            if (data.status === 'success') {
                                var msg = 'تم إضافة ' + data.added + ' موظف';
                                if (data.skipped > 0) {
                                    msg += '\nتم تخطي ' + data.skipped + ' موظف (مُضاف مسبقاً)';
                                }
                                Swal.fire('تم بنجاح', msg, 'success');
                                self.onChange();
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ', 'error');
                            }
                        }).catch(function () { self.adding_all = false; });
                }
            });
        },
        printReport: function () {
            window.print();
        },
        monthName: function (m) {
            var names = {
                1: 'يناير', 2: 'فبراير', 3: 'مارس', 4: 'أبريل',
                5: 'مايو', 6: 'يونيو', 7: 'يوليو', 8: 'أغسطس',
                9: 'سبتمبر', 10: 'أكتوبر', 11: 'نوفمبر', 12: 'ديسمبر',
            };
            return names[m] || m;
        },
    }
});
