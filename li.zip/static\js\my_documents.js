var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        downloadUrl: downloadUrl,
        docs: [],
        searchText: '',
        form: {
            id: null,
            doc_type: '',
            doc_description: '',
            expiry_date: '',
            notes: '',
            attachment: ''
        },
        isEdit: false
    },
    computed: {
        formTitle: function () {
            return this.isEdit ? 'تعديل مستند' : 'إضافة مستند جديد';
        },
        filteredDocs: function () {
            if (!this.searchText || this.searchText.trim() === '') {
                return this.docs;
            }
            var s = this.searchText.toLowerCase();
            return this.docs.filter(function (doc) {
                return (doc.doc_type && doc.doc_type.toLowerCase().indexOf(s) > -1) ||
                    (doc.doc_description && doc.doc_description.toLowerCase().indexOf(s) > -1) ||
                    (doc.notes && doc.notes.toLowerCase().indexOf(s) > -1) ||
                    (doc.expiry_date && doc.expiry_date.indexOf(s) > -1);
            });
        }
    },
    created: function () {
        this.loadDocs();
    },
    methods: {
        loadDocs: function () {
            this.$http.get(this.URL + '/../my_documents_list').then(function (res) {
                this.docs = res.body;
            });
        },
        resetForm: function () {
            this.form = {
                id: null,
                doc_type: '',
                doc_description: '',
                expiry_date: '',
                notes: '',
                attachment: ''
            };
            this.isEdit = false;
            if (this.$refs.attachmentFile) {
                this.$refs.attachmentFile.value = '';
            }
        },
        openAdd: function () {
            this.resetForm();
            showModal('docModal');
        },
        openEdit: function (doc) {
            this.isEdit = true;
            this.form = {
                id: doc.id,
                doc_type: doc.doc_type,
                doc_description: doc.doc_description || '',
                expiry_date: doc.expiry_date || '',
                notes: doc.notes || '',
                attachment: doc.attachment || ''
            };
            if (this.$refs.attachmentFile) {
                this.$refs.attachmentFile.value = '';
            }
            showModal('docModal');
        },
        saveDoc: function () {
            if (!this.form.doc_type || this.form.doc_type.trim() === '') {
                Swal.fire('يجب ادخال نوع المستند');
                return;
            }
            var formData = new FormData();
            formData.append('doc_type', this.form.doc_type);
            formData.append('doc_description', this.form.doc_description || '');
            formData.append('expiry_date', this.form.expiry_date || '');
            formData.append('notes', this.form.notes || '');
            if (this.form.id) {
                formData.append('id', this.form.id);
            }
            var fileInput = this.$refs.attachmentFile;
            if (fileInput && fileInput.files && fileInput.files.length > 0) {
                formData.append('attachment', fileInput.files[0]);
            }
            this.$http.post(
                this.URL + '/../my_documents_save',
                formData
            ).then(function (res) {
                if (res.body.err === 0) {
                    Swal.fire({
                        title: res.body.mess,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    hideModal('docModal');
                    this.loadDocs();
                } else {
                    Swal.fire(res.body.mess);
                }
            });
        },
        deleteDoc: function (id) {
            Swal.fire({
                title: 'هل انت متأكد ؟',
                text: 'لن تتمكن من استعادة المستند بعد الحذف',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then(function (result) {
                if (result.value) {
                    this.$http.get(this.URL + '/../my_documents_delete/' + id).then(function (res) {
                        if (res.body.err === 0) {
                            Swal.fire({
                                title: 'تم الحذف',
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            });
                            this.loadDocs();
                        } else {
                            Swal.fire(res.body.mess);
                        }
                    });
                }
            }.bind(this));
        },
        isExpired: function (date) {
            if (!date) return false;
            return new Date(date) < new Date();
        },
        isExpiringSoon: function (date) {
            if (!date) return false;
            var d = new Date(date);
            var now = new Date();
            var diff = (d - now) / (1000 * 60 * 60 * 24);
            return diff >= 0 && diff <= 30;
        }
    }
});
