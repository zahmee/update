var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        docs: [],
        form: {
            id: null,
            doc_type: '',
            doc_description: '',
            expiry_date: '',
            notes: ''
        },
        isEdit: false
    },
    computed: {
        formTitle: function () {
            return this.isEdit ? 'تعديل مستند' : 'إضافة مستند جديد';
        }
    },
    created: function () {
        this.loadDocs();
    },
    methods: {
        loadDocs: function () {
            this.$http.get(this.URL + '/../my_documents_list').then(function (res) {
                this.docs = res.body;
            });
        },
        resetForm: function () {
            this.form = {
                id: null,
                doc_type: '',
                doc_description: '',
                expiry_date: '',
                notes: ''
            };
            this.isEdit = false;
        },
        openAdd: function () {
            this.resetForm();
            $('#docModal').modal('show');
        },
        openEdit: function (doc) {
            this.isEdit = true;
            this.form = {
                id: doc.id,
                doc_type: doc.doc_type,
                doc_description: doc.doc_description || '',
                expiry_date: doc.expiry_date || '',
                notes: doc.notes || ''
            };
            $('#docModal').modal('show');
        },
        saveDoc: function () {
            if (!this.form.doc_type || this.form.doc_type.trim() === '') {
                Swal.fire('يجب ادخال نوع المستند');
                return;
            }
            this.$http.post(
                this.URL + '/../my_documents_save',
                JSON.stringify(this.form),
                { emulateJSON: true }
            ).then(function (res) {
                if (res.body.err === 0) {
                    Swal.fire({
                        title: res.body.mess,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    $('#docModal').modal('hide');
                    this.loadDocs();
                } else {
                    Swal.fire(res.body.mess);
                }
            });
        },
        deleteDoc: function (id) {
            Swal.fire({
                title: 'هل انت متأكد ؟',
                text: 'لن تتمكن من استعادة المستند بعد الحذف',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then(function (result) {
                if (result.value) {
                    this.$http.get(this.URL + '/../my_documents_delete/' + id).then(function (res) {
                        if (res.body.err === 0) {
                            Swal.fire({
                                title: 'تم الحذف',
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            });
                            this.loadDocs();
                        } else {
                            Swal.fire(res.body.mess);
                        }
                    });
                }
            }.bind(this));
        },
        isExpired: function (date) {
            if (!date) return false;
            return new Date(date) < new Date();
        },
        isExpiringSoon: function (date) {
            if (!date) return false;
            var d = new Date(date);
            var now = new Date();
            var diff = (d - now) / (1000 * 60 * 60 * 24);
            return diff >= 0 && diff <= 30;
        }
    }
});
