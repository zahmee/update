var API_BASE = window.location.href.replace(/\/screens_rules\/.*$/, '/');
var USER_ID = (window.location.pathname.match(/screens_rules\/(\d+)/) || [])[1] || '0';

var app = new Vue({
    el: '#app',
    data: {
        rules: [],
        availableScreens: [],
        data_row_count: 0,
        getData: {
            page: 0,
            RecordCount: 20,
        },
        newRule: {
            screens: '',
            can_log_in: false,
            can_add: false,
            can_edit: false,
            can_delete: false,
        },
        searchScreen: '',
        loading: false,
        savingId: null,
        showAddModal: false,
        userName: USER_NAME,
        userId: USER_ID,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        filteredScreens: function () {
            if (!this.searchScreen) return this.availableScreens;
            var term = this.searchScreen.trim();
            return this.availableScreens.filter(function (s) {
                return s.name.indexOf(term) !== -1 || String(s.screen_code).indexOf(term) !== -1;
            });
        },
    },
    created: function () {
        this.fetchRules();
    },
    methods: {
        fetchRules: function () {
            this.loading = true;
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
            };
            this.$http.get(API_BASE + 'get_screens_rules/' + USER_ID, { params: params })
                .then(function (res) {
                    var rows = res.body.data || [];
                    // PostgreSQL returns booleans as "T"/"F" strings - convert to real booleans
                    for (var i = 0; i < rows.length; i++) {
                        var r = rows[i];
                        r.can_log_in = (r.can_log_in === true || r.can_log_in === 'T' || r.can_log_in === 't');
                        r.can_add = (r.can_add === true || r.can_add === 'T' || r.can_add === 't');
                        r.can_edit = (r.can_edit === true || r.can_edit === 'T' || r.can_edit === 't');
                        r.can_delete = (r.can_delete === true || r.can_delete === 'T' || r.can_delete === 't');
                    }
                    this.rules = rows;
                    this.data_row_count = res.body.count || 0;
                }.bind(this), function () {
                    this.rules = [];
                    this.data_row_count = 0;
                }.bind(this))
                .finally(function () {
                    this.loading = false;
                }.bind(this));
        },
        fetchAvailableScreens: function () {
            this.$http.get(API_BASE + 'get_available_screens/' + USER_ID)
                .then(function (res) {
                    this.availableScreens = res.body || [];
                    if (this.availableScreens.length > 0 && !this.newRule.screens) {
                        this.newRule.screens = this.availableScreens[0].id;
                    }
                }.bind(this), function () {
                    this.availableScreens = [];
                }.bind(this));
        },
        goToPage: function (p) {
            if (p === '...') return;
            this.getData.page = p - 1;
            this.fetchRules();
        },
        saveRule: function (rule) {
            this.savingId = rule.id;
            var params = {
                id: rule.id,
                can_log_in: rule.can_log_in ? 'true' : 'false',
                can_add: rule.can_add ? 'true' : 'false',
                can_edit: rule.can_edit ? 'true' : 'false',
                can_delete: rule.can_delete ? 'true' : 'false',
            };
            this.$http.post(API_BASE + 'save_rule', params)
                .then(function (res) {
                    if (res.body.err !== 0) {
                        Swal.fire({
                            icon: 'error',
                            title: 'خطأ',
                            text: res.body.mess || 'حدث خطأ أثناء الحفظ',
                            confirmButtonText: 'حسناً',
                        });
                    }
                }.bind(this), function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'خطأ',
                        text: 'فشل الاتصال بالخادم',
                        confirmButtonText: 'حسناً',
                    });
                }.bind(this))
                .finally(function () {
                    this.savingId = null;
                }.bind(this));
        },
        openAddModal: function () {
            this.newRule = {
                screens: '',
                can_log_in: false,
                can_add: false,
                can_edit: false,
                can_delete: false,
            };
            this.searchScreen = '';
            this.fetchAvailableScreens();
            this.showAddModal = true;
        },
        closeAddModal: function () {
            this.showAddModal = false;
        },
        addRule: function () {
            if (!this.newRule.screens) {
                Swal.fire({
                    icon: 'warning',
                    title: 'تنبيه',
                    text: 'يجب اختيار شاشة',
                    confirmButtonText: 'حسناً',
                });
                return;
            }
            var params = {
                to_user: USER_ID,
                screens: this.newRule.screens,
                can_log_in: this.newRule.can_log_in ? 'true' : 'false',
                can_add: this.newRule.can_add ? 'true' : 'false',
                can_edit: this.newRule.can_edit ? 'true' : 'false',
                can_delete: this.newRule.can_delete ? 'true' : 'false',
            };
            this.$http.post(API_BASE + 'save_rule', params)
                .then(function (res) {
                    if (res.body.err === 0) {
                        this.closeAddModal();
                        this.getData.page = 0;
                        this.fetchRules();
                        Swal.fire({
                            icon: 'success',
                            title: 'تم',
                            text: 'تمت الإضافة بنجاح',
                            timer: 1500,
                            showConfirmButton: false,
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'خطأ',
                            text: res.body.mess || 'حدث خطأ أثناء الإضافة',
                            confirmButtonText: 'حسناً',
                        });
                    }
                }.bind(this), function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'خطأ',
                        text: 'فشل الاتصال بالخادم',
                        confirmButtonText: 'حسناً',
                    });
                }.bind(this));
        },
        deleteRule: function (rule) {
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف صلاحية "' + rule.screen_name + '"؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-trash-alt"></i> نعم، احذف',
                cancelButtonText: 'إلغاء',
            }).then(function (result) {
                if (result.isConfirmed) {
                    this.$http.post(API_BASE + 'delete_rule/' + rule.id)
                        .then(function (res) {
                            if (res.body.err === 0) {
                                this.fetchRules();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'تم الحذف',
                                    text: 'تم حذف الصلاحية بنجاح',
                                    timer: 1500,
                                    showConfirmButton: false,
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'خطأ',
                                    text: res.body.mess || 'حدث خطأ أثناء الحذف',
                                    confirmButtonText: 'حسناً',
                                });
                            }
                        }.bind(this), function () {
                            Swal.fire({
                                icon: 'error',
                                title: 'خطأ',
                                text: 'فشل الاتصال بالخادم',
                                confirmButtonText: 'حسناً',
                            });
                        }.bind(this));
                }
            }.bind(this));
        },
        grantAll: function () {
            var self = this;
            Swal.fire({
                title: 'تأكيد',
                text: 'هل أنت متأكد من منح جميع الصلاحيات لهذا المستخدم؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم، منح الكل',
                cancelButtonText: 'إلغاء',
            }).then(function (result) {
                if (result.value || result.isConfirmed) {
                    self.$http.post(API_BASE + 'api_grant_all/' + USER_ID)
                        .then(function (res) {
                            if (res.body.err === 0) {
                                self.getData.page = 0;
                                self.fetchRules();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'تم',
                                    text: 'تم منح جميع الصلاحيات',
                                    timer: 1500,
                                    showConfirmButton: false,
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'خطأ',
                                    text: res.body.mess || 'حدث خطأ',
                                    confirmButtonText: 'حسناً',
                                });
                            }
                        }, function () {
                            Swal.fire({
                                icon: 'error',
                                title: 'خطأ',
                                text: 'فشل الاتصال بالخادم',
                                confirmButtonText: 'حسناً',
                            });
                        });
                }
            });
        },
        deleteAll: function () {
            var self = this;
            Swal.fire({
                title: 'تأكيد',
                text: 'هل أنت متأكد من حذف جميع الصلاحيات لهذا المستخدم؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonText: 'إلغاء',
                confirmButtonText: 'نعم، احذف الكل',
            }).then(function (result) {
                if (result.value || result.isConfirmed) {
                    self.$http.post(API_BASE + 'api_delete_all/' + USER_ID)
                        .then(function (res) {
                            if (res.body.err === 0) {
                                self.getData.page = 0;
                                self.fetchRules();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'تم',
                                    text: 'تم حذف جميع الصلاحيات',
                                    timer: 1500,
                                    showConfirmButton: false,
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'خطأ',
                                    text: res.body.mess || 'حدث خطأ',
                                    confirmButtonText: 'حسناً',
                                });
                            }
                        }, function () {
                            Swal.fire({
                                icon: 'error',
                                title: 'خطأ',
                                text: 'فشل الاتصال بالخادم',
                                confirmButtonText: 'حسناً',
                            });
                        });
                }
            });
        },
    },
});
