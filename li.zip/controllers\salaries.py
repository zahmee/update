# -*- coding: utf-8 -*-
#  type: ignore


@can_access(7002)
def index():
    return dict()


def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    ad_types = db(db.key_allowance_deduction.id > 0).select(
        db.key_allowance_deduction.id,
        db.key_allowance_deduction.name,
        db.key_allowance_deduction.ad_type,
        orderby=db.key_allowance_deduction.name
    )
    return response.json({
        "employees": employees,
        "ad_types": ad_types,
    })


def get_salaries():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append("( emp.emp_name LIKE %s OR emp.id_number LIKE %s )")
            params.extend([pattern, pattern])

    # ترتيب
    allowed_sort_columns = {'id', 'emp_name', 'basic_salary', 'total_allowances', 'total_deductions', 'net_salary'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'emp_name'

    # تحويل أسماء الأعمدة المحسوبة للترتيب
    sort_map = {
        'id': 's.id',
        'emp_name': 'emp.emp_name',
        'basic_salary': 's.basic_salary',
        'total_allowances': 'total_allowances',
        'total_deductions': 'total_deductions',
        'net_salary': 'net_salary',
    }
    sort_col = sort_map.get(sc, 'emp.emp_name')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' AND ' + ' AND '.join(conditions)

    sql = (
        f"SELECT s.id, s.employee, s.basic_salary, "
        f"emp.emp_name, jt.name AS job_title_name, "
        f"COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'بدل' "
        f"), 0) AS total_allowances, "
        f"COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'خصم' "
        f"), 0) AS total_deductions, "
        f"s.basic_salary + COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'بدل' "
        f"), 0) - COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'خصم' "
        f"), 0) AS net_salary "
        f"FROM emp_salary s "
        f"JOIN employees emp ON emp.id = s.employee "
        f"LEFT JOIN key_job_titles jt ON jt.id = emp.job_title "
        f"WHERE 1=1 {where} "
        f"ORDER BY {sort_col} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM emp_salary s "
        f"JOIN employees emp ON emp.id = s.employee "
        f"WHERE 1=1 {where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def get_salary_details():
    employee_id = request.args(0)
    if not employee_id:
        return response.json([])

    sql = (
        "SELECT sd.id, sd.employee, sd.allowance_deduction, sd.amount, sd.notes, "
        "ad.name AS ad_name, ad.ad_type "
        "FROM emp_salary_detail sd "
        "JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        "WHERE sd.employee = %s "
        "ORDER BY ad.ad_type, ad.name"
    )
    qry = db.executesql(sql, placeholders=[employee_id], as_dict=True)
    return response.json(qry)


def save_salary():
    try:
        data = request.vars
        employee_id = int(data.employee)
        basic_salary = float(data.basic_salary or 0)

        # upsert
        existing = db(db.emp_salary.employee == employee_id).select().first()
        if existing:
            existing.update_record(basic_salary=basic_salary)
            sid = existing.id
        else:
            sid = db.emp_salary.insert(
                employee=employee_id,
                basic_salary=basic_salary,
            )
        db.commit()
        return response.json({"id": sid, "status": "success"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


def add_detail():
    try:
        data = request.vars
        nid = db.emp_salary_detail.insert(
            employee=int(data.employee),
            allowance_deduction=int(data.allowance_deduction),
            amount=float(data.amount or 0),
            notes=data.notes or '',
        )
        db.commit()
        return response.json({"id": nid, "status": "success"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


def update_detail():
    try:
        data = request.vars
        row = db.emp_salary_detail[data.id]
        if not row:
            return response.json({"id": 0, "mess": "السجل غير موجود"})
        row.update_record(
            allowance_deduction=int(data.allowance_deduction),
            amount=float(data.amount or 0),
            notes=data.notes or '',
        )
        db.commit()
        return response.json({"id": row.id, "status": "success"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


def delete_detail():
    try:
        row = db.emp_salary_detail[request.args(0)]
        if not row:
            return response.json({"status": 0, "mess": "السجل غير موجود"})
        row.delete_record()
        db.commit()
        return response.json({"status": 1})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"status": 0, "mess": str(e)})


def delete_salary():
    try:
        row = db.emp_salary[request.args(0)]
        if not row:
            return response.json({"status": 0, "mess": "السجل غير موجود"})
        # حذف التفاصيل أولاً
        db(db.emp_salary_detail.employee == row.employee).delete()
        row.delete_record()
        db.commit()
        return response.json({"status": 1})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"status": 0, "mess": str(e)})
