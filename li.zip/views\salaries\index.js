var API_BASE = window.location.href + '/../../salaries/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'emp_name',
            sortAsc: true,
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        // lookups
        employees_list: [],
        ad_types: [],
        // details
        details: [],
        detailLoading: false,
        new_detail: true,
        detail_form: { allowance_deduction: '', amount: '', notes: '' },
        loading: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        allowances: function () {
            return this.ad_types.filter(function (a) { return a.ad_type === 'بدل'; });
        },
        deductions: function () {
            return this.ad_types.filter(function (a) { return a.ad_type === 'خصم'; });
        },
    },
    created: function () {
        this.loading = true;
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.employees_list = data.employees;
                this.ad_types = data.ad_types;
            }.bind(this));
        this.fetchData().then(function (data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
            };
            var url = new URL(API_BASE + 'get_salaries');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.details = [];
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.details = [];
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
            this.loadDetails(row.employee);
        },
        loadDetails: function (employeeId) {
            var self = this;
            self.detailLoading = true;
            fetch(API_BASE + 'get_salary_details/' + employeeId)
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    self.details = data;
                    self.detailLoading = false;
                });
        },
        edit_row: function () {
            this.new_row = false;
        },
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_salary: function () {
            if (!this.edit_row_data.employee) {
                Swal.fire('تنبيه', 'يجب اختيار الموظف', 'error');
                return;
            }
            if (!this.edit_row_data.basic_salary && this.edit_row_data.basic_salary !== 0) {
                Swal.fire('تنبيه', 'يجب إدخال الراتب الأساسي', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('employee', this.edit_row_data.employee);
            formData.append('basic_salary', this.edit_row_data.basic_salary);

            var self = this;
            fetch(API_BASE + 'save_salary', {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status === 'success') {
                        self.edit_row_data = {};
                        self.selectedRow = -1;
                        self.new_row = true;
                        self.details = [];
                        bootstrap.Modal.getInstance(document.getElementById("salaryModal")).hide();
                        Swal.fire('تم بنجاح', 'تمت عملية الحفظ بشكل صحيح', 'success');
                        self.onChange();
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                }.bind(this));
        },
        delete_salary: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف راتب: ' + row.emp_name + '؟ سيتم حذف جميع البدلات والخصومات أيضاً',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_salary/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                self.details = [];
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ أثناء الحذف', 'error');
                            }
                        });
                }
            });
        },
        // ====== التفاصيل (بدلات/خصومات) ======
        openDetailModal: function (isNew) {
            this.new_detail = isNew;
            if (isNew) {
                this.detail_form = { allowance_deduction: '', amount: '', notes: '' };
            }
            bootstrap.Modal.getOrCreateInstance(document.getElementById("detailModal")).show();
        },
        editDetail: function (d) {
            this.new_detail = false;
            this.detail_form = {
                id: d.id,
                allowance_deduction: d.allowance_deduction,
                amount: d.amount,
                notes: d.notes || ''
            };
            bootstrap.Modal.getOrCreateInstance(document.getElementById("detailModal")).show();
        },
        save_detail: function () {
            if (!this.detail_form.allowance_deduction) {
                Swal.fire('تنبيه', 'يجب اختيار البدل أو الخصم', 'error');
                return;
            }
            if (!this.detail_form.amount) {
                Swal.fire('تنبيه', 'يجب إدخال المبلغ', 'error');
                return;
            }

            var self = this;
            var row = this.data[this.selectedRow];
            var formData = new FormData();
            formData.append('employee', row.employee);
            formData.append('allowance_deduction', this.detail_form.allowance_deduction);
            formData.append('amount', this.detail_form.amount);
            formData.append('notes', this.detail_form.notes || '');

            var endpoint = this.new_detail ? 'add_detail' : 'update_detail';
            if (!this.new_detail) {
                formData.append('id', this.detail_form.id);
            }

            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status === 'success') {
                        bootstrap.Modal.getInstance(document.getElementById("detailModal")).hide();
                        Swal.fire('تم', 'تم الحفظ بنجاح', 'success');
                        self.loadDetails(row.employee);
                        // تحديث المجاميع
                        self.loading = true;
                        self.fetchData().then(function (d) {
                            self.data = d.data;
                            self.data_row_count = d.count;
                            // إعادة تحديد الصف
                            for (var i = 0; i < self.data.length; i++) {
                                if (self.data[i].employee === row.employee) {
                                    self.selectedRow = i;
                                    self.edit_row_data = Object.assign({}, self.data[i]);
                                    break;
                                }
                            }
                        }).finally(function () { self.loading = false; });
                    } else {
                        Swal.fire('خطأ', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        deleteDetail: function (d) {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف: ' + d.ad_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_detail/' + d.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                                self.loadDetails(row.employee);
                                // تحديث المجاميع
                                self.fetchData().then(function (d) {
                                    self.data = d.data;
                                    self.data_row_count = d.count;
                                    for (var i = 0; i < self.data.length; i++) {
                                        if (self.data[i].employee === row.employee) {
                                            self.selectedRow = i;
                                            self.edit_row_data = Object.assign({}, self.data[i]);
                                            break;
                                        }
                                    }
                                });
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ', 'error');
                            }
                        });
                }
            });
        },
        cancel_data: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
            this.details = [];
        },
        formatNum: function (n) {
            if (n === null || n === undefined) return '0.00';
            return parseFloat(n).toFixed(2);
        },
    }
});
