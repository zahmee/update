# type: ignore

from datetime import date, datetime
import send_sms as sms
import json
from base64 import b64decode, b64encode
from io import BytesIO
import httpx
import os
import zatca_libs

# import qrcode

payment_means_codes = {
    "10": {
        "ar": "نقدًا",
        "en": "Cash"
    },
    "20": {
        "ar": "شيك",
        "en": "Cheque"
    },
    "30": {
        "ar": "تحويل بنكي",
        "en": "Credit Transfer"
    },
    "31": {
        "ar": "إيداع لحساب بنكي",
        "en": "Payment to Bank Account"
    },
        "42": {
        "ar": "بطاقة دفع (مدى/فيزا/ماستر)",
        "en": "Payment Card"
    },
    "48": {
        "ar": "دفع عبر محفظة إلكترونية",
        "en": "Mobile Payment"
    },
    "1": {
        "ar": "وسيلة دفع غير محددة",
        "en": "Instrument Not Defined"
    },
    "97": {
        "ar": "مقاصة بين طرفين",
        "en": "Clearing Between Partners"
    },
    "ZZZ": {
        "ar": "وسيلة دفع مخصصة",
        "en": "Custom Payment Method"
    }
}

@can_access(4001)
def index():
    return dict()


def getco():
    qry = "select * from customers where id=%s or mobile=%s"
    custdata = db.executesql(qry, placeholders=[request.args(0), request.args(0)], as_dict=True)
    lastpay = 0
    if custdata:
        cid = custdata[0]["id"]
        qry = (
            "update customers set total = (select sum(total_after_discount) from invoice_master "
            " where payment_method=3 and customer=%s) , payed=( select sum(amount) "
            " from customers_pay where customers_id=%s) , "
            " amount = (select sum(total_after_discount) from invoice_master where "
            " payment_method=3 and customer=%s) -( select sum(amount) "
            " from customers_pay where customers_id=%s) where id=%s"
        )
        db.executesql(qry, placeholders=[cid, cid, cid, cid, cid])
        cus = (
            db(db.customers_pay.customers_id == cid)
            .select(
                db.customers_pay.ALL,
                orderby=~db.customers_pay.modified_on,
                limitby=(0, 1),
            )
            .first()
        )
        if cus:
            now = datetime.now()
            lastpay = (now - cus.modified_on).days
        else:
            lastpay = 0
        qry = "select * from customers where id=%s"
        custdata = db.executesql(qry, placeholders=[cid], as_dict=True)
        if custdata:
            custdata[0]["lastpay"] = lastpay
            if custdata[0]["payed"] is None:
                custdata[0]["payed"] = 0
            if custdata[0]["amount"] is None:
                custdata[0]["amount"] = 0
    return response.json(custdata)


def get_payment_method():
    q = db(db.key_payment_method.id > 0).select()
    return response.json(q)


def get_key_type():
    q = db(db.key_type.id > 0).select()
    return response.json(q)


def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(3001)
def offer_price():
    return dict()


@can_access(3001)
@can_access(3001)
def op_save():
    try:
        sc = screens_rules(3001)
        if not sc or not sc.can_add:
            return response.json({"err": 1, "invno": 0, "mess": "غير مسموح بالإضافة"})
        # import uuid
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.offer_price.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        for i in itm["itm"]:
            db.offer_price_details.insert(
                item_dis=i["item_dis"],
                item_count=i["item_count"],
                amount=i["item_price"],
                total=i["total_price"],
                uuid=uuid,
                total_after_discount=i["total_price"],
                vat_total=i["total_vat"],
                vat=i["item_vat"],
                key_type=i["type"],
            )
        invno = db.offer_price.insert(
            customer=itm["customer"],
            customer_info=itm["customer_info"],
            total=itm["net_total"],
            payment_method=itm["method"],
            total_after_discount=itm["total_all"],
            uuid=uuid,
            vat=itm["vat"],
            disc=itm["disc"],
        )
        db.commit()
        ret = {"err": 0, "invno": invno, "mess": "0"}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


def invoice():
    return dict()


# حفظ الفواتير و ارسالها الى الهيئة
@can_access(4001)
def save():
    try:
        sc = screens_rules(4001)
        if not sc or not sc.can_add:
            return response.json({"err": 1, "invno": 0, "mess": "غير مسموح بالإضافة"})
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        sim_invoce = True 
        inv_type = "SIMSI"
        if int(itm["customer"]) > 1 :
            customar = db.customers[itm["customer"]]
            #print(customar)
            if customar.vat and customar.crn :
                sim_invoce = False
                inv_type = "STDSI"
        configuration = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        ## يتم هنا ارسال الفاتورة مباشرة لهيئة الزكاة (بدون وسيط)
        if csr_config.pcsid_requestid:
            is_standard = (inv_type == "STDSI")
            now = datetime.now()
            icv_value = str(int(csr_config.icv or 0) + 1)
            pih_value = csr_config.pih or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
            max_no = db.invoice_master.id.max()
            last_invo = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0
            inv_number = "INV-" + str(last_invo + 1).zfill(12)
            # بناء بيانات الفاتورة لـ ZATCA
            customer_data = {}
            if is_standard and int(itm["customer"]) > 1:
                customar = db.customers[itm["customer"]]
                customer_data = {
                    "CustomerVAT": customar.vat or "",
                    "CustomerCRN": customar.crn or "",
                    "CustomerName": customar.name or "",
                    "CustomerStreetName": customar.address or "*",
                    "CustomerBuildingNumber": "1111",
                    "CustomerCityName": "*",
                    "CustomerDistrict": "*",
                    "CustomerPostalZone": "12345",
                }
            else:
                cust_name = "عميل"
                if int(itm["customer"]) > 1:
                    c_row = db.customers[itm["customer"]]
                    if c_row:
                        cust_name = c_row.name or "عميل"
                customer_data = {
                    "CustomerName": cust_name,
                    "CustomerStreetName": "*", "CustomerBuildingNumber": "1111",
                    "CustomerCityName": "*", "CustomerDistrict": "*", "CustomerPostalZone": "12345",
                }
            # بناء بنود الفاتورة
            inv_lines = []
            line_id = 1
            for item in itm["itm"]:
                inv_lines.append({
                    "ID": str(line_id),
                    "Quantity": float(item["item_count"]),
                    "LineExtensionAmount": round(float(item["total_price"]) - float(item["total_vat"]), 2),
                    "TaxAmount": round(float(item["total_vat"]), 2),
                    "RoundingAmount": round(float(item["total_price"]), 2),
                    "Name": item["item_dis"],
                    "TaxPercent": 15.00,
                    "PriceAmount": round(float(item["item_price"]), 2),
                })
                line_id += 1
            tax_inclusive = round(float(itm["total_all"]), 2)
            tax_amount = round(float(itm["vat"]), 2)
            tax_exclusive = round(tax_inclusive - tax_amount, 2)
            inv_data = {
                "ID": inv_number, "UUID": uuid,
                "IssueDate": now.strftime("%Y-%m-%d"), "IssueTime": now.strftime("%H:%M:%S"),
                "InvoiceTypeCode": "388", "ICV": icv_value, "PIH": pih_value,
                "PaymentMeansCode": "10",
                "TaxAmount": tax_amount, "TaxableAmount": tax_exclusive, "TaxInclusiveAmount": tax_inclusive,
                "InvoiceLines": inv_lines,
                **customer_data,
            }
            # استدعاء دالة الإرسال المباشر من zatca_direct
            # استيراد الدوال من zatca_direct
            import types
            _zd_path = os.path.join(request.folder, "controllers", "zatca_direct.py")
            with open(_zd_path, "r", encoding="utf-8") as _zf:
                _zd_code = _zf.read()
            _zd_mod = types.ModuleType("zatca_direct_funcs")
            _zd_mod.__dict__.update(globals())
            exec(compile(_zd_code, _zd_path, "exec"), _zd_mod.__dict__)
            zatca_result = _zd_mod._process_and_send(inv_data, csr_config, inv_type)
            if zatca_result["success"]:
                itm.send_to_zatca = True
                itm.pih_txt = zatca_result["invoice_hash"]
                itm.qr_code = zatca_result.get("qr_code", "")
                itm.zatca_res = json.dumps(zatca_result["zatca_response"], ensure_ascii=False)
                n_icv = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=n_icv, pih=itm.pih_txt)
                db.commit()
            else:
                itm.send_to_zatca = False
                itm.zatca_res = json.dumps(zatca_result["zatca_response"], ensure_ascii=False)
                itm.pih_txt = ""
                itm.qr_code = ""
                ret = {"err": 9, "invno": 0, "mess": itm.zatca_res}
                return response.json(ret)
            # ================================================
            for i in itm["itm"]:
                db.invoice_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.invoice_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce = sim_invoce ,
                send_to_zatca = itm.send_to_zatca,
                zatca_res = itm.zatca_res,
                pih_txt = itm.pih_txt,
                qr_code = itm.qr_code
            )
            db.commit()
            itm.inove_no = invno
            if configuration.send_sms:
                costmer = db.customers[itm["customer"]]
                if costmer.mobile:
                    if len(costmer.mobile) == 10:
                        p = sms.SMS()
                        ms = (
                            "شكرا لزيارتك "
                            + configuration.name
                            + "تم اصدار فاتورة بمبلغ"
                            + itm["total_all"]
                        )
                        p.send("+966" + costmer.mobile[1:], ms)
            # update_invoce = db.invoice_master[invno]
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
        else:
            # توليد QR المرحلة الأولى (بدون ربط مع الهيئة)
            import struct
            def _tlv(tag, val):
                v = val.encode("utf-8") if isinstance(val, str) else val
                return struct.pack("BB", tag, len(v)) + v
            phase1_qr_data = (
                _tlv(1, configuration.name or "")
                + _tlv(2, configuration.vat or "")
                + _tlv(3, datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"))
                + _tlv(4, str(itm["total_all"]))
                + _tlv(5, str(itm["vat"]))
            )
            phase1_qr = b64encode(phase1_qr_data).decode("utf-8")
            for i in itm["itm"]:
                db.invoice_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.invoice_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce=sim_invoce,
                qr_code=phase1_qr,
            )
            db.commit()
            itm.inove_no = invno
            ret = {"err": 0, "invno": invno, "mess": "0"}
            if configuration.send_sms:
                costmer = db.customers[itm["customer"]]
                if costmer.mobile:
                    if len(costmer.mobile) == 10:
                        p = sms.SMS()
                        ms = (
                            "شكرا لزيارتك "
                            + configuration.name
                            + "تم اصدار فاتورة بمبلغ"
                            + itm["total_all"]
                        )
                        p.send("+966" + costmer.mobile[1:], ms)
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)

# مرتجع البيع
@can_access(4002)
def inv_return():
    return dict()


# @can_access(4002)
# def inv_return_save():
#     try:
#         ret = {"err": 3, "invno": 0, "mess": e}
#         return gluon.contrib.simplejson.dumps(ret)
#     except Exception as e:
#         db.rollback()
#         ret = {"err": 3, "invno": 0, "mess": e}
#         return gluon.contrib.simplejson.dumps(ret)


@can_access(4002)
@can_access(4002)
def saver():
    try:
        sc = screens_rules(4002)
        if not sc or not sc.can_add:
            return response.json({"err": 1, "invno": 0, "mess": "غير مسموح بالإضافة"})
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.inv_return_master.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        sim_invoce = True
        inv_type = "SIMCN"
        if int(itm["customer"]) > 1:
            customar = db.customers[itm["customer"]]
            if customar.vat and customar.crn:
                sim_invoce = False
                inv_type = "STDCN"
        configuration = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        ## يتم هنا ارسال المرتجع مباشرة لهيئة الزكاة (بدون وسيط)
        if csr_config.pcsid_requestid:
            is_standard = (inv_type == "STDCN")
            now = datetime.now()
            icv_value = str(int(csr_config.icv or 0) + 1)
            pih_value = csr_config.pih or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
            max_no = db.inv_return_master.id.max()
            last_invo = db(db.inv_return_master.id > 0).select(max_no).first()[max_no] or 0
            inv_number = "INV-" + str(last_invo + 1).zfill(12)
            # بناء بيانات العميل
            customer_data = {}
            if is_standard and int(itm["customer"]) > 1:
                customar = db.customers[itm["customer"]]
                customer_data = {
                    "CustomerVAT": customar.vat or "",
                    "CustomerCRN": customar.crn or "",
                    "CustomerName": customar.name or "",
                    "CustomerStreetName": customar.address or "*",
                    "CustomerBuildingNumber": "1111",
                    "CustomerCityName": "*",
                    "CustomerDistrict": "*",
                    "CustomerPostalZone": "12345",
                }
            else:
                cust_name = "عميل"
                if int(itm["customer"]) > 1:
                    c_row = db.customers[itm["customer"]]
                    if c_row:
                        cust_name = c_row.name or "عميل"
                customer_data = {
                    "CustomerName": cust_name,
                    "CustomerStreetName": "*", "CustomerBuildingNumber": "1111",
                    "CustomerCityName": "*", "CustomerDistrict": "*", "CustomerPostalZone": "12345",
                }
            # بنود المرتجع
            inv_lines = []
            line_id = 1
            for item in itm["itm"]:
                inv_lines.append({
                    "ID": str(line_id),
                    "Quantity": float(item["item_count"]),
                    "LineExtensionAmount": round(float(item["total_price"]) - float(item["total_vat"]), 2),
                    "TaxAmount": round(float(item["total_vat"]), 2),
                    "RoundingAmount": round(float(item["total_price"]), 2),
                    "Name": item["item_dis"],
                    "TaxPercent": float(item["item_vat"]) * 100 if float(item["item_vat"]) < 1 and float(item["item_vat"]) > 0 else (float(item["item_vat"]) if float(item["item_vat"]) >= 1 else 0),
                    "PriceAmount": round(float(item["item_price"]), 2),
                })
                line_id += 1
            tax_inclusive = round(float(itm["total_all"]), 2)
            tax_amount = round(float(itm["vat"]), 2)
            tax_exclusive = round(tax_inclusive - tax_amount, 2)
            inv_data = {
                "ID": inv_number, "UUID": uuid,
                "IssueDate": now.strftime("%Y-%m-%d"), "IssueTime": now.strftime("%H:%M:%S"),
                "InvoiceTypeCode": "383",
                "InvoiceTypeCodeName": "0200000" if sim_invoce else "0100000",
                "ICV": icv_value, "PIH": pih_value,
                "PaymentMeansCode": "10",
                "BillingReferenceID": "مرتجع مبيعات",
                "InstructionNote": "مرتجع مبيعات",
                "TaxAmount": tax_amount, "TaxableAmount": tax_exclusive, "TaxInclusiveAmount": tax_inclusive,
                "InvoiceLines": inv_lines,
                **customer_data,
            }
            # استدعاء دالة الإرسال المباشر من zatca_direct
            import types
            _zd_path = os.path.join(request.folder, "controllers", "zatca_direct.py")
            with open(_zd_path, "r", encoding="utf-8") as _zf:
                _zd_code = _zf.read()
            _zd_mod = types.ModuleType("zatca_direct_funcs")
            _zd_mod.__dict__.update(globals())
            exec(compile(_zd_code, _zd_path, "exec"), _zd_mod.__dict__)
            zatca_result = _zd_mod._process_and_send(inv_data, csr_config, inv_type)
            if zatca_result["success"]:
                itm.send_to_zatca = True
                itm.pih_txt = zatca_result["invoice_hash"]
                itm.qr_code = zatca_result.get("qr_code", "")
                itm.zatca_res = json.dumps(zatca_result["zatca_response"], ensure_ascii=False)
                n_icv = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=n_icv, pih=itm.pih_txt)
                db.commit()
            else:
                itm.send_to_zatca = False
                itm.zatca_res = json.dumps(zatca_result["zatca_response"], ensure_ascii=False)
                itm.pih_txt = ""
                itm.qr_code = ""
                ret = {"err": 9, "invno": 0, "mess": itm.zatca_res}
                return response.json(ret)
            # ================================================
            for i in itm["itm"]:
                db.inv_return_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.inv_return_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce=sim_invoce,
                send_to_zatca=itm.send_to_zatca,
                zatca_res=itm.zatca_res,
                pih_txt=itm.pih_txt,
                qr_code=itm.qr_code,
            )
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
        else:
            # بدون ربط مع الهيئة - توليد QR المرحلة الأولى
            import struct
            def _tlv(tag, val):
                v = val.encode("utf-8") if isinstance(val, str) else val
                return struct.pack("BB", tag, len(v)) + v
            phase1_qr_data = (
                _tlv(1, configuration.name or "")
                + _tlv(2, configuration.vat or "")
                + _tlv(3, datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"))
                + _tlv(4, str(itm["total_all"]))
                + _tlv(5, str(itm["vat"]))
            )
            phase1_qr = b64encode(phase1_qr_data).decode("utf-8")
            for i in itm["itm"]:
                db.inv_return_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.inv_return_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce=sim_invoce,
                qr_code=phase1_qr,
            )
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


def show_one_invoce_r():
    return dict()


def invoice_print_min_r():
    return dict()


def invoice_print_r():
    return dict()


# ==========================================       نهاية مرتجع البيع  ==============================================================================
# تقارير الفواتير و المبيعات
# -----------------------------------------------------------------------------


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def inv_rep1():
    from datetime import date
    today = date.today()
    first_of_month = today.replace(day=1)

    # Today's stats
    today_sales = db.executesql(
        "SELECT COALESCE(SUM(total_after_discount),0), COALESCE(SUM(vat),0), COUNT(*) "
        "FROM invoice_master WHERE DATE(created_on) = %s",
        [today], as_dict=False
    )
    td_total = float(today_sales[0][0]) if today_sales else 0
    td_vat = float(today_sales[0][1]) if today_sales else 0
    td_count = int(today_sales[0][2]) if today_sales else 0

    # Month's stats
    month_sales = db.executesql(
        "SELECT COALESCE(SUM(total_after_discount),0), COALESCE(SUM(vat),0), COUNT(*) "
        "FROM invoice_master WHERE created_on >= %s AND created_on <= %s",
        [first_of_month, today], as_dict=False
    )
    mo_total = float(month_sales[0][0]) if month_sales else 0
    mo_vat = float(month_sales[0][1]) if month_sales else 0
    mo_count = int(month_sales[0][2]) if month_sales else 0

    # Today's returns
    today_returns = db.executesql(
        "SELECT COALESCE(SUM(total_after_discount),0), COUNT(*) "
        "FROM inv_return_master WHERE DATE(created_on) = %s",
        [today], as_dict=False
    )
    td_ret_total = float(today_returns[0][0]) if today_returns else 0
    td_ret_count = int(today_returns[0][1]) if today_returns else 0

    return dict(
        td_total=td_total, td_vat=td_vat, td_count=td_count,
        mo_total=mo_total, mo_vat=mo_vat, mo_count=mo_count,
        td_ret_total=td_ret_total, td_ret_count=td_ret_count,
        today=today, first_of_month=first_of_month,
    )


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.invoice_master.created_on >= request.vars.da1)
        & (db.invoice_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate2():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.inv_return_master.created_on >= request.vars.da1)
        & (db.inv_return_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate3():
    # sum = db.invoice_master.total_after_discount.sum()
    s = (
        "select EXTRACT(HOUR FROM created_on),count(*),sum(total_after_discount) "
        "from invoice_master where created_on >= timestamp %s and created_on <= timestamp %s "
        "group by EXTRACT(HOUR FROM created_on) order by EXTRACT(HOUR FROM created_on)"
    )
    custdata = db.executesql(s, placeholders=[request.vars.da1, request.vars.da2], as_dict=True)
    return response.json(custdata)


# ==============================================================  استعراض فاتورة مسجلة  =================================================================
@can_access(4003)
def inv_view():
    sc = screens_rules(4003)
    return dict(sc=sc)


@can_access(4003)
def inv_view_1():
    if request.args(0) == "1":
        qry = db.invoice_master[request.args(1)]
        if qry:
            qry.pyer = (
                (qry.created_by.first_name or "")
                + " "
                + (qry.created_by.last_name or "")
            )
            data = db(
                (db.invoice_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.invoice_details.uuid == qry.uuid)
            ).select(
                (db.invoice_details.item_number).with_alias("item_number"),
                (db.invoice_details.amount).with_alias("amount"),
                (db.invoice_details.item_count).with_alias("item_count"),
                (db.invoice_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.invoice_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""
    else:
        qry = db.inv_return_master[request.args(1)]
        if qry:
            qry.pyer = qry.created_by.first_name + " " + qry.created_by.last_name
            data = db(
                (db.inv_return_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.inv_return_details.uuid == qry.uuid)
            ).select(
                (db.inv_return_details.item_number).with_alias("item_number"),
                (db.inv_return_details.amount).with_alias("amount"),
                (db.inv_return_details.item_count).with_alias("item_count"),
                (db.inv_return_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.inv_return_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""


@can_access(4003)
def inv_view_2():
    sc = screens_rules(4003)
    if sc.can_delete:
        if request.args(0) == "1":
            qry1 = db.invoice_master[request.args(1)]
            db(db.invoice_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            db.commit()
            return "1"
        else:
            qry1 = db.inv_return_master[request.args(1)]
            db(db.inv_return_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            db.commit()
            return "1"


# بحث عن عميل
def search_c():
    # q = db.items_main[request.vars.itid]
    newstr = request.vars.itid  # .replace("'", "")
    # qry = "select * from items_main where name::text like '%"+str(newstr)+"%'  LIMIT 10 ;"
    q = db(db.customers.name.like("%" + newstr + "%")).select()
    # data = db.executesql(qry, as_dict=True)
    return response.json(q)
    # return q


# =================================================================================================================================================
@auth.requires_membership("user1")
def delete_inv():
    return dict()


@can_access(4003)
def invoice_show():
    return dict()


@auth.requires_login()
def invoice_show_list():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    where = " WHERE 1=1 "
    params = []
    if search.strip():
        where += (
            " AND (CAST(im.id AS TEXT) LIKE %s"
            " OR c.name LIKE %s"
            " OR kpm.name LIKE %s"
            " OR CAST(im.total_after_discount AS TEXT) LIKE %s) "
        )
        pattern = "%" + search + "%"
        params.extend([pattern, pattern, pattern, pattern])
    offset = pg * rc
    sql = (
        "SELECT im.id, c.name as customer_name, kpm.name as payment_method,"
        " im.total_after_discount, im.vat, im.created_on, im.send_to_zatca, im.zatca_res"
        " FROM invoice_master im"
        " LEFT JOIN customers c ON c.id = im.customer"
        " LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method"
        + where + " ORDER BY im.id DESC LIMIT %s OFFSET %s"
    )
    sql_count = (
        "SELECT COUNT(*) FROM invoice_master im"
        " LEFT JOIN customers c ON c.id = im.customer"
        " LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method"
        + where
    )
    rows = db.executesql(sql, placeholders=params + [rc, offset], as_dict=True)
    count = db.executesql(sql_count, placeholders=params)[0][0]
    return response.json({"data": rows, "count": count})


def view_xml():
    """عرض ملف XML للفاتورة - يبحث عن الملف بأي لاحقة نوع"""
    import glob
    inv_id = request.args(0) or "0"
    inv_prefix = "INV-" + str(inv_id).zfill(12)
    xml_dir = os.path.join(request.folder, "static", "xml")
    # البحث عن أي ملف يبدأ بـ INV-XXXX
    pattern = os.path.join(xml_dir, f"{inv_prefix}*.xml")
    files = glob.glob(pattern)
    if files:
        # إرجاع أول ملف موجود
        fname = os.path.basename(files[0])
        redirect(URL('static', f'xml/{fname}'))
    else:
        raise HTTP(404, f"ملف XML غير موجود للفاتورة {inv_id}")


def invoice_print():
    return dict()


def invoice_print_min():
    return dict()


def show_one_invoce():
    return dict()


@can_access(4003)
def invoice_show_r():
    return dict()


@auth.requires_login()
def invoice_show_r_list():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    where = " WHERE 1=1 "
    if search.strip():
        where += (
            f" AND (CAST(im.id AS TEXT) LIKE '%{search}%'"
            f" OR c.name LIKE '%{search}%'"
            f" OR kpm.name LIKE '%{search}%'"
            f" OR CAST(im.total_after_discount AS TEXT) LIKE '%{search}%') "
        )
    offset = pg * rc
    sql = (
        f"SELECT im.id, c.name as customer_name, kpm.name as payment_method,"
        f" im.total_after_discount, im.vat, im.created_on, im.send_to_zatca, im.zatca_res"
        f" FROM inv_return_master im"
        f" LEFT JOIN customers c ON c.id = im.customer"
        f" LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method"
        f" {where} ORDER BY im.id DESC LIMIT {rc} OFFSET {offset}"
    )
    sql_count = (
        f"SELECT COUNT(*) FROM inv_return_master im"
        f" LEFT JOIN customers c ON c.id = im.customer"
        f" LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method"
        f" {where}"
    )
    rows = db.executesql(sql, as_dict=True)
    count = db.executesql(sql_count)[0][0]
    return response.json({"data": rows, "count": count})


def invoice_edit():
    return dict()


def update_invoice():
    if request.vars.id:
        inv = db.invoice_master[request.vars.id]
        if inv:
            inv.customer = request.vars.a2
            inv.payment_method = request.vars.a1
            customer_info = (
                '{"name":"'
                + str(request.vars.a3)
                + '", "vat": "'
                + str(request.vars.a4)
                + '" }'
            )
            inv.customer_info = customer_info
            inv.update_record()
            db.commit()
            return redirect(URL("invoice", "invoice_show"))
    return "ok"


def get_sample_item():
    q = db(db.sample_item.id > 0).select()
    return response.json(q)


@can_access(3001)
def offer_price_show():
    return dict()


@can_access(3001)
def offer_price_show_list():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    where = " WHERE 1=1 "
    if search.strip():
        where += (
            f" AND (CAST(op.id AS TEXT) LIKE '%{search}%'"
            f" OR c.name LIKE '%{search}%'"
            f" OR kpm.name LIKE '%{search}%'"
            f" OR CAST(op.total_after_discount AS TEXT) LIKE '%{search}%') "
        )
    offset = pg * rc
    sql = (
        f"SELECT op.id, c.name as customer_name, kpm.name as payment_method,"
        f" op.total_after_discount, op.vat, op.created_on"
        f" FROM offer_price op"
        f" LEFT JOIN customers c ON c.id = op.customer"
        f" LEFT JOIN key_payment_method kpm ON kpm.id = op.payment_method"
        f" {where} ORDER BY op.id DESC LIMIT {rc} OFFSET {offset}"
    )
    sql_count = (
        f"SELECT COUNT(*) FROM offer_price op"
        f" LEFT JOIN customers c ON c.id = op.customer"
        f" LEFT JOIN key_payment_method kpm ON kpm.id = op.payment_method"
        f" {where}"
    )
    rows = db.executesql(sql, as_dict=True)
    count = db.executesql(sql_count)[0][0]
    return response.json({"data": rows, "count": count})


@can_access(3001)
def offer_price_print():
    return dict()


data = {
    "cert_info": {
        "privateKey": "",
        "csr": "",
        "pcsid_binarySecurityToken": "",
        "pcsid_secret": "",
        "environment": "Simulation",
        "reportingUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/reporting/single",
        "clearanceUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/clearance/single"
    },
    "input_xml": {
        "xml_template_path": "xxx.xml"
    },
    "document_type": "SIMSI",
    "invoice_number": "DOC-0001",
    "icv_start": 1,
    "pih_base64": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
    "invoice": {
        "ProfileID": "reporting:1.0",
        "ID": "SME00011",
        "UUID": "8e6000cf-1a98-4500-b3e7-b5d5954bc10d",
        "IssueDate": "2025-11-25",
        "IssueTime": "02:30:08",
        "InvoiceTypeCode": "388",
        "InvoiceTypeCodeName": "0200000",
        "Note": "",
        "DocumentCurrencyCode": "SAR",
        "TaxCurrencyCode": "SAR",
        "BillingReference": "",
        "AdditionalDocumentReferences": [
            {
                "ID": "ICV",
                "UUID": "10"
            },
            {
                "ID": "PIH",
                "Attachment": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
                "FileName": "pih.txt"
            }
        ],
        "SupplierStreetName": "1234 Street",
        "SupplierBuildingNumber": "2322",
        "SupplierCityName": "Riyadh",
        "SupplierDistrict": "Al-Murabba",
        "SupplierPostalZone": "23333",
        "SupplierCountryCode": "SA",
        "SupplierVAT": "",
        "SupplierName": "",
        "SupplierSchemeID": "CRN",
        "SupplierCRN": "",
        "CustomerStreetName": "*",
        "CustomerBuildingNumber": "1111",
        "CustomerCityName": "*",
        "CustomerDistrict": "*",
        "CustomerPostalZone": "12345",
        "CustomerCountryCode": "SA",
        "CustomerVAT": "",
        "CustomerName": "****",
        "CustomerCRN": "",
        "DeliveryDate": "2025-01-01",
        "PaymentMeansCode": "10",
        "AllowanceCharge": {
            "ChargeIndicator": "False",
            "Reason": "discount",
            "Amount": 0.00,
            "TaxCategories": [
                {"ID": "S", "Percent": 15, "SchemeID": "VAT"}
            ]
        },
        "InvoiceLines": [
            {
                "ID": "1",
                "UnitCode": "PCE",
                "Quantity": 33,
                "LineExtensionAmount": 99.00,
                "TaxAmount": 14.85,
                "RoundingAmount": 113.85,
                "Name": "book",
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": 3.00,
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00
                }
            },
            {
                "ID": "2",
                "UnitCode": "PCE",
                "Quantity": 3,
                "LineExtensionAmount": 102.00,
                "TaxAmount": 15.30,
                "RoundingAmount": 117.30,
                "Name": "قلم",
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": 34.00,
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00
                }
            }
        ],
        "TaxAmount": 30.15,
        "TaxableAmount": 201.00,
        "TaxPercent": 15.00,
        "LineExtensionAmount": 201.00,
        "TaxExclusiveAmount": 201.00,
        "TaxInclusiveAmount": 231.15,
        "AllowanceTotalAmount": 0.00,
        "PrepaidAmount": 0.00,
        "PayableAmount": 231.15
    }
}

def generate_invoice_json(invo:dict, invtype:str) :
    try :
        impo_info = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        now = datetime.now()
        environment_type = csr_config.environment
        if environment_type.lower() == "nonproduction":
            api_path = "developer-portal"
        elif environment_type.lower() == "simulation":
            api_path = "simulation"
        elif environment_type.lower() == "production":
            api_path = "core"
        last_invo = 0
        if invtype.endswith("SI") :
            max_no = db.invoice_master.id.max()
            last_invo = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0
        else :
            max_no = db.inv_return_master.id.max()
            last_invo = db(db.inv_return_master.id > 0).select(max_no).first()[max_no] or 0 
        invoce = invo
        re_data = data
        re_data["cert_info"]["privateKey"] = csr_config.privatekey
        re_data["cert_info"]["csr"] = csr_config.csr
        re_data["cert_info"]["pcsid_binarySecurityToken"] = csr_config.pcsid_binarysecuritytoken
        re_data["cert_info"]["pcsid_secret"] = csr_config.pcsid_secret
        re_data["cert_info"]["environment"] = csr_config.environment  # "Simulation"
        re_data["cert_info"]["reportingUrl"] = (
            f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
        )
        re_data["cert_info"]["clearanceUrl"] = (
            f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single"
        )
        re_data["document_type"] = invtype
        re_data["invoice_number"] = "INV-" + str(last_invo+1).zfill(12)
        re_data["invoice"]["ID"] = "INV-" + str(last_invo+1).zfill(12)
        re_data["invoice"]["UUID"] = invoce.uuid
        re_data["invoice"]["IssueDate"] = now.strftime("%Y-%m-%d") # invoce.created_on.strftime("%Y-%m-%d")
        re_data["invoice"]["IssueTime"] = now.strftime("%H:%M:%S") # invoce.created_on.strftime("%H:%M:%S")
        re_data["invoice"]["AdditionalDocumentReferences"][0]["UUID"] = str(csr_config.icv) # ICV
        re_data["invoice"]["AdditionalDocumentReferences"][1]["Attachment"] = csr_config.pih # PIH
        # معلومات المورد
        re_data["invoice"]["SupplierStreetName"] = csr_config.address_street_name
        re_data["invoice"]["SupplierBuildingNumber"] = csr_config.address_building_number
        re_data["invoice"]["SupplierCityName"] = csr_config.address_city_name
        re_data["invoice"]["SupplierDistrict"] = csr_config.address_neighborhood
        re_data["invoice"]["SupplierPostalZone"] = csr_config.address_postal_zone
        re_data["invoice"]["SupplierVAT"] = csr_config.organization_identifier
        re_data["invoice"]["SupplierName"] = csr_config.organization_name
        re_data["invoice"]["SupplierCRN"] = csr_config.company_id
        # معلومات العميل
        if invtype.startswith("STD") :
            if invoce.customer > 1:
                customer = db.customers[invoce.customer]
                re_data["invoice"]["CustomerStreetName"]=  "main"
                re_data["invoice"]["CustomerBuildingNumber"]= "1111"
                re_data["invoice"]["CustomerCityName"]= "my city"
                re_data["invoice"]["CustomerDistrict"]= "my dist"
                re_data["invoice"]["CustomerPostalZone"]= "12345"
                re_data["invoice"]["CustomerCountryCode"]= "SA"
                re_data["invoice"]["CustomerVAT"]= customer.vat
                re_data["invoice"]["CustomerName"]= customer.name
                re_data["invoice"]["CustomerCRN"]= customer.crn
        re_data["invoice"]["PaymentMeansCode"] = "1"  # غير محددة
        # تفاصيل الاصناف
        # inv_items = db(db.invoice_details.uuid == invoce.uuid).select()
        inv_lines = []
        line_id = 1
        # print("=============================================================")
        for item in invoce.itm :
            line = {
                "ID": str(line_id),
                "UnitCode": "PCE",
                "Quantity": float(item["item_count"]),
                "LineExtensionAmount": round(
                    float(item["total_price"]) - float(item["total_vat"]), 2
                ),
                "TaxAmount": round(float(item["total_vat"]), 2),
                "RoundingAmount": round(float(item["total_price"]), 2),
                "Name": item["item_dis"],
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": round(
                    (float(item["item_price"]) ), 2
                ),
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00,
                },
            }
            inv_lines.append(line)
            line_id += 1

        re_data["invoice"]["InvoiceLines"] = inv_lines
        # القيم المالية
        tax_inclusive = round(float(invoce.total_all), 2)
        tax_amount = round(float(invoce.vat), 2)
        tax_exclusive = round(tax_inclusive - tax_amount, 2)
        re_data["invoice"]["TaxAmount"] = tax_amount
        re_data["invoice"]["TaxableAmount"] = tax_exclusive
        re_data["invoice"]["TaxPercent"] = 15.00
        re_data["invoice"]["LineExtensionAmount"] = tax_exclusive
        re_data["invoice"]["TaxExclusiveAmount"] = tax_exclusive
        re_data["invoice"]["TaxInclusiveAmount"] = tax_inclusive
        re_data["invoice"]["AllowanceTotalAmount"] = 0.00
        re_data["invoice"]["PayableAmount"] = tax_inclusive
        # formatted_json = json.dumps(re_data, indent=4, ensure_ascii=False)
        # print(formatted_json)
        return re_data
    except Exception as e:
        print(f"error{e}")
        return str(e)


## ===================== ZATCA Phase 2 - إرسال مباشر =====================

def _zatca_build_invoice_xml(inv_data, csr_config):
    """بناء فاتورة UBL 2.1 XML بدون توقيع (للتجزئة)"""
    d = inv_data
    c = csr_config
    # بناء بنود الفاتورة + فئات الضريبة أولاً (قبل القالب)
    lines_xml = ""
    tax_categories = {}
    for line in d["InvoiceLines"]:
        pct = line.get("TaxPercent", 15.00)
        cat_id = "S" if pct > 0 else "O"
        key = f"{pct:.2f}"
        if key not in tax_categories:
            tax_categories[key] = {"taxable": 0.0, "tax": 0.0, "cat_id": cat_id, "pct": pct}
        tax_categories[key]["taxable"] += line["LineExtensionAmount"]
        tax_categories[key]["tax"] += line["TaxAmount"]
        lines_xml += f'''
    <cac:InvoiceLine>
        <cbc:ID>{line["ID"]}</cbc:ID>
        <cbc:InvoicedQuantity unitCode="{line.get("UnitCode","PCE")}">{line["Quantity"]:.2f}</cbc:InvoicedQuantity>
        <cbc:LineExtensionAmount currencyID="SAR">{line["LineExtensionAmount"]:.2f}</cbc:LineExtensionAmount>
        <cac:TaxTotal>
            <cbc:TaxAmount currencyID="SAR">{line["TaxAmount"]:.2f}</cbc:TaxAmount>
            <cbc:RoundingAmount currencyID="SAR">{line["RoundingAmount"]:.2f}</cbc:RoundingAmount>
        </cac:TaxTotal>
        <cac:Item>
            <cbc:Name>{line["Name"]}</cbc:Name>
            <cac:ClassifiedTaxCategory>
                <cbc:ID>{cat_id}</cbc:ID>
                <cbc:Percent>{pct:.2f}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:ClassifiedTaxCategory>
        </cac:Item>
        <cac:Price>
            <cbc:PriceAmount currencyID="SAR">{line["PriceAmount"]:.2f}</cbc:PriceAmount>
        </cac:Price>
    </cac:InvoiceLine>'''
    # BR-CO-17/14/15: إعادة حساب الإجماليات من TaxSubtotals
    subtotals_inner = ""
    calc_total_tax = 0.0
    calc_total_taxable = 0.0
    for key, cat in tax_categories.items():
        cat_taxable = round(cat["taxable"], 2)
        cat_tax = round(cat_taxable * cat["pct"] / 100.0, 2)
        calc_total_tax += cat_tax
        calc_total_taxable += cat_taxable
        subtotals_inner += f'''
        <cac:TaxSubtotal>
            <cbc:TaxableAmount currencyID="SAR">{cat_taxable:.2f}</cbc:TaxableAmount>
            <cbc:TaxAmount currencyID="SAR">{cat_tax:.2f}</cbc:TaxAmount>
            <cac:TaxCategory>
                <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5305">{cat["cat_id"]}</cbc:ID>
                <cbc:Percent>{cat["pct"]:.2f}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5153">VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>'''
    calc_total_tax = round(calc_total_tax, 2)
    calc_total_taxable = round(calc_total_taxable, 2)
    calc_total_inclusive = round(calc_total_taxable + calc_total_tax, 2)
    d["TaxAmount"] = calc_total_tax
    d["TaxableAmount"] = calc_total_taxable
    d["TaxInclusiveAmount"] = calc_total_inclusive
    tax_subtotals_xml = f'''<cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{calc_total_tax:.2f}</cbc:TaxAmount>{subtotals_inner}
    </cac:TaxTotal>'''
    # حقول إضافية للإشعارات (383/381)
    from xml.sax.saxutils import escape as _esc
    billing_ref_xml = ""
    instruction_note_xml = ""
    inv_type_code = d.get("InvoiceTypeCode", "388")
    if inv_type_code in ("383", "381"):
        ref_id = d.get("BillingReferenceID", "مرتجع")
        instruction = d.get("InstructionNote", "مرتجع")
        billing_ref_xml = f'''<cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>{_esc(str(ref_id))}</cbc:ID>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>'''
        instruction_note_xml = f'<cbc:InstructionNote>{_esc(str(instruction))}</cbc:InstructionNote>'
    xml = f'''<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
 xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
 xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
 xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">
    <ext:UBLExtensions>
        <ext:UBLExtension>
            <ext:ExtensionURI>urn:oasis:names:specification:ubl:dsig:enveloped:xades</ext:ExtensionURI>
            <ext:ExtensionContent>
                SET_SIGN_HERE
            </ext:ExtensionContent>
        </ext:UBLExtension>
    </ext:UBLExtensions>
    <cbc:ProfileID>reporting:1.0</cbc:ProfileID>
    <cbc:ID>{d["ID"]}</cbc:ID>
    <cbc:UUID>{d["UUID"]}</cbc:UUID>
    <cbc:IssueDate>{d["IssueDate"]}</cbc:IssueDate>
    <cbc:IssueTime>{d["IssueTime"]}</cbc:IssueTime>
    <cbc:InvoiceTypeCode name="{d["InvoiceTypeCodeName"]}">{d["InvoiceTypeCode"]}</cbc:InvoiceTypeCode>
    <cbc:DocumentCurrencyCode>SAR</cbc:DocumentCurrencyCode>
    <cbc:TaxCurrencyCode>SAR</cbc:TaxCurrencyCode>
    {billing_ref_xml}
    <cac:AdditionalDocumentReference>
        <cbc:ID>ICV</cbc:ID>
        <cbc:UUID>{d["ICV"]}</cbc:UUID>
    </cac:AdditionalDocumentReference>
    <cac:AdditionalDocumentReference>
        <cbc:ID>PIH</cbc:ID>
        <cac:Attachment>
            <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">{d["PIH"]}</cbc:EmbeddedDocumentBinaryObject>
        </cac:Attachment>
    </cac:AdditionalDocumentReference>
    <cac:AdditionalDocumentReference>
        <cbc:ID>QR</cbc:ID>
        <cac:Attachment>
            <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">SET_QR_HERE</cbc:EmbeddedDocumentBinaryObject>
        </cac:Attachment>
    </cac:AdditionalDocumentReference>
    <cac:Signature>
        <cbc:ID>urn:oasis:names:specification:ubl:signature:Invoice</cbc:ID>
        <cbc:SignatureMethod>urn:oasis:names:specification:ubl:dsig:enveloped:xades</cbc:SignatureMethod>
    </cac:Signature>
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="CRN">{c.company_id or ""}</cbc:ID>
            </cac:PartyIdentification>
            <cac:PostalAddress>
                <cbc:StreetName>{c.address_street_name or "main"}</cbc:StreetName>
                <cbc:BuildingNumber>{c.address_building_number or "1111"}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{c.address_neighborhood or "district"}</cbc:CitySubdivisionName>
                <cbc:CityName>{c.address_city_name or "Riyadh"}</cbc:CityName>
                <cbc:PostalZone>{c.address_postal_zone or "12345"}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{c.organization_identifier or ""}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{c.organization_name or ""}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PostalAddress>
                <cbc:StreetName>{d.get("CustomerStreetName","*")}</cbc:StreetName>
                <cbc:BuildingNumber>{d.get("CustomerBuildingNumber","1111")}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{d.get("CustomerDistrict","*")}</cbc:CitySubdivisionName>
                <cbc:CityName>{d.get("CustomerCityName","*")}</cbc:CityName>
                <cbc:PostalZone>{d.get("CustomerPostalZone","12345")}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{d.get("CustomerName","عميل")}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>
    <cac:Delivery>
        <cbc:ActualDeliveryDate>{d["IssueDate"]}</cbc:ActualDeliveryDate>
    </cac:Delivery>
    <cac:PaymentMeans>
        <cbc:PaymentMeansCode>{d.get("PaymentMeansCode","10")}</cbc:PaymentMeansCode>
        {instruction_note_xml}
    </cac:PaymentMeans>
    {tax_subtotals_xml}
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{d["TaxAmount"]:.2f}</cbc:TaxAmount>
    </cac:TaxTotal>
    <cac:LegalMonetaryTotal>
        <cbc:LineExtensionAmount currencyID="SAR">{d["TaxableAmount"]:.2f}</cbc:LineExtensionAmount>
        <cbc:TaxExclusiveAmount currencyID="SAR">{d["TaxableAmount"]:.2f}</cbc:TaxExclusiveAmount>
        <cbc:TaxInclusiveAmount currencyID="SAR">{d["TaxInclusiveAmount"]:.2f}</cbc:TaxInclusiveAmount>
        <cbc:AllowanceTotalAmount currencyID="SAR">0.00</cbc:AllowanceTotalAmount>
        <cbc:PrepaidAmount currencyID="SAR">0.00</cbc:PrepaidAmount>
        <cbc:PayableAmount currencyID="SAR">{d["TaxInclusiveAmount"]:.2f}</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>'''
    xml += lines_xml
    xml += "\n</Invoice>"
    return xml



## ===================== Helper Functions =====================

def _zatca_hash_b64(data_bytes):
    """SHA-256 -> base64(raw_bytes)"""
    import hashlib
    return b64encode(hashlib.sha256(data_bytes).digest()).decode("utf-8")


def _zatca_hash_hex_b64(data_bytes):
    """SHA-256 -> hex -> base64(hex_string) - طريقة ZATCA للشهادة و SignedProperties"""
    import hashlib
    hex_hash = hashlib.sha256(data_bytes).hexdigest()
    return b64encode(hex_hash.encode("utf-8")).decode("utf-8")


def _zatca_decode_bst(bst_b64):
    """فك BST (base64 مزدوج) -> (cert_b64_single, cert_der)"""
    cx509 = zatca_libs.cx509
    backend = zatca_libs.default_backend()
    try:
        inner = b64decode(bst_b64).decode("utf-8").strip()
        cert_der = b64decode(inner)
        cx509.load_der_x509_certificate(cert_der, backend)
        return inner, cert_der
    except Exception:
        pass
    try:
        cert_der = b64decode(bst_b64)
        cx509.load_der_x509_certificate(cert_der, backend)
        return bst_b64, cert_der
    except Exception:
        raise ValueError(f"cannot read cert: {bst_b64[:40]}...")


def _zatca_get_issuer_name(certificate):
    """استخراج اسم الجهة المصدرة بصيغة ZATCA"""
    parts = []
    issuer_dict = {}
    for attr in certificate.issuer:
        key = attr.oid._name
        if key in issuer_dict:
            if isinstance(issuer_dict[key], list):
                issuer_dict[key].append(attr.value)
            else:
                issuer_dict[key] = [issuer_dict[key], attr.value]
        else:
            issuer_dict[key] = attr.value
    if "commonName" in issuer_dict:
        parts.append(f"CN={issuer_dict['commonName']}")
    if "domainComponent" in issuer_dict:
        dc_list = issuer_dict["domainComponent"]
        if isinstance(dc_list, list):
            dc_list.reverse()
            for dc in dc_list:
                if dc:
                    parts.append(f"DC={dc}")
    return ", ".join(parts)


def _zatca_get_public_key_and_signature(cert_b64_clean):
    """استخراج المفتاح العام وتوقيع الشهادة لـ QR"""
    import tempfile
    crypto = zatca_libs.openssl_crypto
    cert_pem = "-----BEGIN CERTIFICATE-----\n"
    cert_pem += "\n".join([cert_b64_clean[i:i+64] for i in range(0, len(cert_b64_clean), 64)])
    cert_pem += "\n-----END CERTIFICATE-----\n"
    with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".pem") as f:
        f.write(cert_pem)
        tmp = f.name
    try:
        cert = crypto.load_certificate(crypto.FILETYPE_PEM, open(tmp).read())
        pub_key = crypto.dump_publickey(crypto.FILETYPE_ASN1, cert.get_pubkey())
        pub_nums = crypto.load_publickey(crypto.FILETYPE_ASN1, pub_key).to_cryptography_key().public_numbers()
        x = pub_nums.x.to_bytes(32, byteorder="big").rjust(32, b"\0")
        y = pub_nums.y.to_bytes(32, byteorder="big").rjust(32, b"\0")
        public_key_der = (
            b"\x30\x56\x30\x10\x06\x07\x2a\x86\x48\xce\x3d\x02\x01"
            b"\x06\x05\x2b\x81\x04\x00\x0a\x03\x42\x00\x04" + x + y
        )
        der_data = b64decode(cert_b64_clean)
        seq_pos = der_data.rfind(b"\x30", -72)
        signature = der_data[seq_pos:]
        return {"public_key": public_key_der, "signature": signature}
    finally:
        os.unlink(tmp)


def _zatca_get_signed_properties_hash(signing_time, cert_hash_hex_b64, issuer_name, serial_number):
    """حساب تجزئة SignedProperties: نص خام -> SHA-256 -> hex -> base64"""
    xml_string = (
        '<xades:SignedProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="xadesSignedProperties">\n'
        "                                    <xades:SignedSignatureProperties>\n"
        "                                        <xades:SigningTime>{}</xades:SigningTime>\n".format(signing_time)
        + "                                        <xades:SigningCertificate>\n"
        "                                            <xades:Cert>\n"
        "                                                <xades:CertDigest>\n"
        '                                                    <ds:DigestMethod xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>\n'
        '                                                    <ds:DigestValue xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:DigestValue>\n'.format(cert_hash_hex_b64)
        + "                                                </xades:CertDigest>\n"
        "                                                <xades:IssuerSerial>\n"
        '                                                    <ds:X509IssuerName xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:X509IssuerName>\n'.format(issuer_name)
        + '                                                    <ds:X509SerialNumber xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:X509SerialNumber>\n'.format(serial_number)
        + "                                                </xades:IssuerSerial>\n"
        "                                            </xades:Cert>\n"
        "                                        </xades:SigningCertificate>\n"
        "                                    </xades:SignedSignatureProperties>\n"
        "                                </xades:SignedProperties>"
    )
    xml_string = xml_string.replace("\r\n", "\n").strip()
    return _zatca_hash_hex_b64(xml_string.encode("utf-8"))


def _zatca_get_digital_signature(invoice_hash_b64, private_key_raw):
    """توقيع ECDSA-SHA256 باستخدام cryptography"""
    hash_bytes = b64decode(invoice_hash_b64)
    pk = private_key_raw.strip().replace("\n", "").replace("\t", "")
    if "-----BEGIN" not in pk:
        pk = f"-----BEGIN EC PRIVATE KEY-----\n{pk}\n-----END EC PRIVATE KEY-----"
    private_key = zatca_libs.load_pem_private_key(pk.encode(), password=None, backend=zatca_libs.default_backend())
    signature = private_key.sign(hash_bytes, zatca_libs.ec.ECDSA(zatca_libs.hashes.SHA256()))
    return b64encode(signature).decode("utf-8")


def _zatca_generate_qr(canonical_xml, invoice_hash_b64, signature_value_b64, ecdsa_result):
    """توليد QR بتنسيق TLV - Tags 6,7 نصوص base64, Tags 8,9 bytes خام"""
    import xml.etree.ElementTree as ET
    ns_cbc = "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}"
    ns_cac = "{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}"
    root = ET.fromstring(canonical_xml)
    seller = root.find(f".//{ns_cac}AccountingSupplierParty/{ns_cac}Party/{ns_cac}PartyLegalEntity/{ns_cbc}RegistrationName").text
    vat = root.find(f".//{ns_cac}AccountingSupplierParty/{ns_cac}Party/{ns_cac}PartyTaxScheme/{ns_cbc}CompanyID").text
    dt = root.find(f".//{ns_cbc}IssueDate").text + "T" + root.find(f".//{ns_cbc}IssueTime").text
    total = root.find(f".//{ns_cac}LegalMonetaryTotal/{ns_cbc}PayableAmount").text
    tax = root.find(f".//{ns_cac}TaxTotal/{ns_cbc}TaxAmount").text
    values = [None, seller, vat, dt, total, tax,
              invoice_hash_b64, signature_value_b64,
              ecdsa_result["public_key"], ecdsa_result["signature"]]

    def write_tag(tag):
        result = bytes()
        flag = True
        for i in range(3, -1, -1):
            num = (tag >> (8 * i)) & 0xFF
            if num != 0 or not flag or i == 0:
                result += bytes([num])
                flag = False
        return result

    def write_length(length):
        if length <= 0x7F:
            return bytes([length])
        lb = []
        while length > 0:
            lb.insert(0, length & 0xFF)
            length >>= 8
        return bytes([0x80 | len(lb)]) + bytes(lb)

    data = b""
    for key, value in enumerate(values[1:], start=1):
        if isinstance(value, str):
            value = value.encode("utf-8")
        data += write_tag(key) + write_length(len(value)) + value
    return b64encode(data).decode("utf-8")


## ===================== Main Test Function =====================

@auth.requires_login()
def test_zatca_invoice():
    """
    إنشاء فاتورة XML مطابقة لـ ZATCA المرحلة الثانية وإرسالها مباشرة
    بنفس طريقة zafa_api العاملة
    GET /light/zatca_helpers/test_zatca_invoice
    """
    import uuid as uuid_lib
    import hashlib
    etree = zatca_libs.etree

    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config:
            return response.json({"err": 4, "invno": 0, "mess": "لا يوجد إعدادات csr_config"})
        if not csr_config.pcsid_requestid:
            return response.json({"err": 4, "invno": 0, "mess": "لم يتم الربط مع الهيئة"})

        # ====== 1. الإعدادات ======
        env = (csr_config.environment or "simulation").lower()
        api_path = {"nonproduction": "developer-portal", "simulation": "simulation", "production": "core"}.get(env, "simulation")
        now = datetime.now()
        test_uuid = str(uuid_lib.uuid4())
        icv_value = str(int(csr_config.icv or 0) + 1)
        pih_value = csr_config.pih or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
        max_no = db.invoice_master.id.max()
        last_invo = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0
        inv_number = "INV-" + str(last_invo + 1).zfill(12)
        signing_time = now.strftime("%Y-%m-%dT%H:%M:%S")

        # ====== 2. فك الشهادة ======
        cert_b64_clean, cert_der = _zatca_decode_bst(csr_config.pcsid_binarysecuritytoken)
        cert = zatca_libs.cx509.load_der_x509_certificate(cert_der, zatca_libs.default_backend())
        issuer_name = _zatca_get_issuer_name(cert)
        serial_number = cert.serial_number
        cert_hash_hex_b64 = _zatca_hash_hex_b64(cert_b64_clean.encode("utf-8"))

        # ====== 3. بناء XML الفاتورة ======
        inv_data = {
            "ID": inv_number, "UUID": test_uuid,
            "IssueDate": now.strftime("%Y-%m-%d"), "IssueTime": now.strftime("%H:%M:%S"),
            "InvoiceTypeCode": "388", "InvoiceTypeCodeName": "0200000",
            "ICV": icv_value, "PIH": pih_value,
            "CustomerName": "عميل تجريبي", "PaymentMeansCode": "10",
            "CustomerStreetName": "*", "CustomerBuildingNumber": "1111",
            "CustomerCityName": "*", "CustomerDistrict": "*", "CustomerPostalZone": "12345",
            "TaxAmount": 30.00, "TaxableAmount": 200.00, "TaxInclusiveAmount": 230.00,
            "InvoiceLines": [{
                "ID": "1", "UnitCode": "PCE", "Quantity": 2.0,
                "LineExtensionAmount": 200.00, "TaxAmount": 30.00,
                "RoundingAmount": 230.00, "Name": "صنف تجريبي",
                "TaxPercent": 15.00, "PriceAmount": 100.00
            }]
        }
        xml_raw = _zatca_build_invoice_xml(inv_data, csr_config)

        # ====== 4. XSLT Transform + C14N + Hash ======
        xsl_path = os.path.join(request.folder, "private", "xslfile.xsl")
        xml_doc = etree.fromstring(xml_raw.encode("utf-8"))
        xsl = etree.parse(xsl_path)
        transform = etree.XSLT(xsl)
        transformed = transform(xml_doc)
        canonical_xml = etree.tostring(transformed, method="c14n").decode("utf-8")
        invoice_hash_b64 = b64encode(hashlib.sha256(canonical_xml.encode("utf-8")).digest()).decode()

        # ====== 5. SignedProperties hash ======
        signed_props_hash = _zatca_get_signed_properties_hash(
            signing_time, cert_hash_hex_b64, issuer_name, serial_number
        )

        # ====== 6. التوقيع الرقمي ======
        signature_value = _zatca_get_digital_signature(invoice_hash_b64, csr_config.privatekey)

        # ====== 7. استخراج public key و cert signature لـ QR ======
        ecdsa_result = _zatca_get_public_key_and_signature(cert_b64_clean)

        # ====== 8. تعبئة قالب UBL ======
        ubl_path = os.path.join(request.folder, "private", "zatca_ubl.xml")
        with open(ubl_path, "r") as f:
            ubl_content = f.read()
        ubl_content = ubl_content.replace("INVOICE_HASH", invoice_hash_b64)
        ubl_content = ubl_content.replace("SIGNED_PROPERTIES", signed_props_hash)
        ubl_content = ubl_content.replace("SIGNATURE_VALUE", signature_value)
        ubl_content = ubl_content.replace("CERTIFICATE_CONTENT", cert_b64_clean)
        ubl_content = ubl_content.replace("SIGNATURE_TIMESTAMP", signing_time)
        ubl_content = ubl_content.replace("PUBLICKEY_HASHING", cert_hash_hex_b64)
        ubl_content = ubl_content.replace("ISSUER_NAME", issuer_name)
        ubl_content = ubl_content.replace("SERIAL_NUMBER", str(serial_number))

        # ====== 9. إدراج UBL في XML (بعد أول >) ======
        insert_pos = canonical_xml.find(">") + 1
        updated_xml = canonical_xml[:insert_pos] + ubl_content + canonical_xml[insert_pos:]

        # ====== 10. توليد QR ======
        qr_b64 = _zatca_generate_qr(canonical_xml, invoice_hash_b64, signature_value, ecdsa_result)

        # ====== 11. إدراج Signature + QR قبل AccountingSupplierParty ======
        sig_path = os.path.join(request.folder, "private", "zatca_signature.xml")
        with open(sig_path, "r") as f:
            sig_content = f.read()
        sig_content = sig_content.replace("BASE64_QRCODE", qr_b64)
        insert_pos_sig = updated_xml.find("<cac:AccountingSupplierParty>")
        if insert_pos_sig != -1:
            updated_xml = updated_xml[:insert_pos_sig] + sig_content + updated_xml[insert_pos_sig:]

        # ====== 12. تجهيز وإرسال ======
        final_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + updated_xml
        invoice_b64 = b64encode(final_xml.encode("utf-8")).decode("utf-8")

        zatca_url = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
        resp = zatca_libs.requests_lib.post(
            zatca_url,
            headers={
                "accept": "application/json", "accept-language": "en",
                "Accept-Version": "V2", "Content-Type": "application/json",
            },
            data=json.dumps({"invoiceHash": invoice_hash_b64, "uuid": test_uuid, "invoice": invoice_b64}),
            auth=zatca_libs.HTTPBasicAuth(csr_config.pcsid_binarysecuritytoken, csr_config.pcsid_secret),
            timeout=60
        )
        resp_data = resp.json() if resp.status_code in (200, 202, 400) else {"error": resp.text}
        reporting_status = resp_data.get("reportingStatus", "")

        if reporting_status == "REPORTED":
            new_icv = int(csr_config.icv or 0) + 1
            csr_config.update_record(icv=new_icv, pih=invoice_hash_b64)
            db.commit()
            return response.json({
                "err": 0, "invno": 0,
                "mess": "تم إرسال الفاتورة مباشرة لهيئة الزكاة بنجاح",
                "status": "REPORTED", "uuid": test_uuid, "invoice_number": inv_number,
                "pih": invoice_hash_b64, "icv": new_icv, "qr_code": qr_b64,
                "invoice_hash": invoice_hash_b64,
                "zatca_url": zatca_url, "zatca_response": resp_data
            })
        else:
            return response.json({
                "err": 9, "invno": 0,
                "mess": "فشل الإبلاغ عن الفاتورة لدى هيئة الزكاة",
                "status": reporting_status, "http_status": resp.status_code,
                "zatca_url": zatca_url, "zatca_response": resp_data,
                "invoice_hash": invoice_hash_b64
            })

    except Exception as e:
        import traceback
        db.rollback()
        return response.json({"err": 3, "invno": 0, "mess": str(e), "trace": traceback.format_exc()})
