var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        data: [],
        dataCount: 0,
        page: 0,
        recordCount: 20,
        searchText: '',
        sortCol: 'id',
        sortAsc: true,
        selectedRow: -1,
        newRow: true,
        editRowData: {}
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.dataCount / this.recordCount) || 1;
        },
        currentPage: function () {
            return this.page + 1;
        },
        visiblePages: function () {
            var pages = [];
            var start = Math.max(1, this.page - 2);
            var end = Math.min(this.totalPages, this.page + 4);
            if (end - start < 4) {
                start = Math.max(1, end - 4);
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            return pages;
        },
        billNetAmount: function () {
            var total = parseFloat(this.editRowData.bill_total) || 0;
            var vat = parseFloat(this.editRowData.bill_vat) || 0;
            return parseFloat(total - vat).toFixed(2);
        }
    },
    created: function () {
        this.loadData();
    },
    methods: {
        loadData: function () {
            var params = 'page=' + this.page
                + '&RecordCount=' + this.recordCount
                + '&SearchText=' + encodeURIComponent(this.searchText)
                + '&SortBy=' + this.sortCol
                + '&sequence=' + this.sortAsc;
            this.$http.get(this.URL + '/../get_invoices?' + params).then(function (res) {
                this.data = res.body.data;
                this.dataCount = res.body.count;
            });
        },
        onSearch: function () {
            this.page = 0;
            this.loadData();
        },
        goToPage: function (p) {
            if (p < 0 || p >= this.totalPages || p === this.page) return;
            this.page = p;
            this.loadData();
        },
        sortBy: function (col) {
            if (this.sortCol !== col) {
                this.sortCol = col;
                this.sortAsc = true;
            } else {
                this.sortAsc = !this.sortAsc;
            }
            this.page = 0;
            this.loadData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.editRowData = Object.assign({}, row);
        },
        editRow: function () {
            this.newRow = false;
        },
        newRowClick: function () {
            this.newRow = true;
            this.editRowData = {};
        },
        cancelData: function () {
            this.newRow = true;
            this.editRowData = {};
            this.selectedRow = -1;
        },
        saveData: function () {
            if (!this.editRowData.supplier || !this.editRowData.bill_no ||
                !this.editRowData.bill_date || !this.editRowData.bill_total) {
                Swal.fire('تنبية', 'يجب ادخال [ جميع الحقول ] .', 'error');
                return;
            }
            this.editRowData.bill_net_amount = this.billNetAmount;
            var self = this;
            if (this.newRow) {
                this.$http.post(
                    this.URL + '/../new_invoice',
                    JSON.stringify(this.editRowData),
                    { emulateJSON: true }
                ).then(function (res) {
                    if (res.body.id > 0) {
                        self.editRowData = {};
                        self.selectedRow = -1;
                        hideModal('exampleModal');
                        Swal.fire('عمل رائع', 'شكرا لك لقد تمت عملية الحفظ بشكل صحيح', 'success');
                        self.page = 0;
                        self.loadData();
                    } else {
                        Swal.fire('تنبية', ' لم تتم عملية الاضافة حصل خطأ ', 'error');
                    }
                });
            } else {
                this.$http.post(
                    this.URL + '/../edit_invoice',
                    JSON.stringify(this.editRowData),
                    { emulateJSON: true }
                ).then(function (res) {
                    if (res.body.id > 0) {
                        self.editRowData = {};
                        self.selectedRow = -1;
                        hideModal('exampleModal');
                        Swal.fire('عمل رائع', 'شكرا لك لقد تمت عملية الحفظ بشكل صحيح', 'success');
                        self.loadData();
                    } else {
                        Swal.fire('تنبية', res.body.mess || 'حصل خطأ', 'error');
                    }
                });
            }
        }
    }
});
