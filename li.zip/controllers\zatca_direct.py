# type: ignore
"""
كونترولر الإرسال المباشر لهيئة الزكاة والضريبة والدخل - المرحلة الثانية
يدعم الفواتير المبسطة (B2C - Reporting) والفواتير الضريبية (B2B - Clearance)
"""
from datetime import datetime
from xml.sax.saxutils import escape
import json
import os
import hashlib
from base64 import b64decode, b64encode
import zatca_libs


## ===================== بناء XML الفاتورة =====================

def _build_invoice_xml(inv, csr, is_standard=False):
    """بناء فاتورة UBL 2.1 - تدعم B2B و B2C"""
    profile = "reporting:1.0" if not is_standard else "reporting:1.0"
    type_name = "0100000" if is_standard else "0200000"

    # بناء قسم العميل حسب النوع
    if is_standard and inv.get("CustomerVAT"):
        customer_block = f'''<cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="CRN">{escape(str(inv.get("CustomerCRN","")))}</cbc:ID>
            </cac:PartyIdentification>
            <cac:PostalAddress>
                <cbc:StreetName>{escape(inv.get("CustomerStreetName","*"))}</cbc:StreetName>
                <cbc:BuildingNumber>{escape(inv.get("CustomerBuildingNumber","1111"))}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{escape(inv.get("CustomerDistrict","*"))}</cbc:CitySubdivisionName>
                <cbc:CityName>{escape(inv.get("CustomerCityName","*"))}</cbc:CityName>
                <cbc:PostalZone>{escape(inv.get("CustomerPostalZone","12345"))}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{escape(str(inv.get("CustomerVAT","")))}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{escape(inv.get("CustomerName",""))}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>'''
    else:
        customer_block = f'''<cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PostalAddress>
                <cbc:StreetName>{escape(inv.get("CustomerStreetName","*"))}</cbc:StreetName>
                <cbc:BuildingNumber>{escape(inv.get("CustomerBuildingNumber","1111"))}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{escape(inv.get("CustomerDistrict","*"))}</cbc:CitySubdivisionName>
                <cbc:CityName>{escape(inv.get("CustomerCityName","*"))}</cbc:CityName>
                <cbc:PostalZone>{escape(inv.get("CustomerPostalZone","12345"))}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{escape(inv.get("CustomerName","عميل"))}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>'''

    # بنود الفاتورة + حساب فئات الضريبة
    lines_xml = ""
    tax_categories = {}  # {percent: {"taxable": 0, "tax": 0, "cat_id": "S"}}
    for line in inv["InvoiceLines"]:
        pct = line.get("TaxPercent", 15.00)
        if pct > 0:
            cat_id = "S"  # Standard rated
        else:
            cat_id = "O"  # Not subject to VAT
        # تجميع حسب نسبة الضريبة
        key = f"{pct:.2f}"
        if key not in tax_categories:
            tax_categories[key] = {"taxable": 0.0, "tax": 0.0, "cat_id": cat_id, "pct": pct}
        tax_categories[key]["taxable"] += line["LineExtensionAmount"]
        tax_categories[key]["tax"] += line["TaxAmount"]

        lines_xml += f'''
    <cac:InvoiceLine>
        <cbc:ID>{line["ID"]}</cbc:ID>
        <cbc:InvoicedQuantity unitCode="{line.get("UnitCode","PCE")}">{line["Quantity"]:.6f}</cbc:InvoicedQuantity>
        <cbc:LineExtensionAmount currencyID="SAR">{line["LineExtensionAmount"]:.2f}</cbc:LineExtensionAmount>
        <cac:TaxTotal>
            <cbc:TaxAmount currencyID="SAR">{line["TaxAmount"]:.2f}</cbc:TaxAmount>
            <cbc:RoundingAmount currencyID="SAR">{line["RoundingAmount"]:.2f}</cbc:RoundingAmount>
        </cac:TaxTotal>
        <cac:Item>
            <cbc:Name>{escape(line["Name"])}</cbc:Name>
            <cac:ClassifiedTaxCategory>
                <cbc:ID>{cat_id}</cbc:ID>
                <cbc:Percent>{pct:.2f}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:ClassifiedTaxCategory>
        </cac:Item>
        <cac:Price>
            <cbc:PriceAmount currencyID="SAR">{line["PriceAmount"]:.2f}</cbc:PriceAmount>
        </cac:Price>
    </cac:InvoiceLine>'''

    # بناء TaxSubtotals ديناميكياً (فئة لكل نسبة ضريبة)
    # BR-CO-17: TaxAmount = TaxableAmount × Rate / 100 مقرب لمنزلتين
    # BR-CO-14: إجمالي الضريبة = مجموع TaxSubtotal.TaxAmount
    # BR-CO-15: الإجمالي شامل = الإجمالي بدون + إجمالي الضريبة
    subtotals_xml = ""
    calc_total_tax = 0.0
    calc_total_taxable = 0.0
    for key, cat in tax_categories.items():
        cat_taxable = round(cat["taxable"], 2)
        cat_tax = round(cat_taxable * cat["pct"] / 100.0, 2)
        calc_total_tax += cat_tax
        calc_total_taxable += cat_taxable
        subtotals_xml += f'''
        <cac:TaxSubtotal>
            <cbc:TaxableAmount currencyID="SAR">{cat_taxable:.2f}</cbc:TaxableAmount>
            <cbc:TaxAmount currencyID="SAR">{cat_tax:.2f}</cbc:TaxAmount>
            <cac:TaxCategory>
                <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5305">{cat["cat_id"]}</cbc:ID>
                <cbc:Percent>{cat["pct"]:.2f}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5153">VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>'''
    # إعادة حساب الإجماليات لتطابق ZATCA rules
    calc_total_tax = round(calc_total_tax, 2)
    calc_total_taxable = round(calc_total_taxable, 2)
    calc_total_inclusive = round(calc_total_taxable + calc_total_tax, 2)
    # تحديث القيم في inv لاستخدامها في باقي XML
    inv["TaxAmount"] = calc_total_tax
    inv["TaxableAmount"] = calc_total_taxable
    inv["TaxInclusiveAmount"] = calc_total_inclusive
    tax_subtotals_xml = f'''<cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{calc_total_tax:.2f}</cbc:TaxAmount>{subtotals_xml}
    </cac:TaxTotal>'''

    # حقول إضافية للإشعارات الدائنة/المدينة (383/381)
    inv_type_code = inv.get("InvoiceTypeCode", "388")
    billing_ref_xml = ""
    instruction_note_xml = ""
    if inv_type_code in ("383", "381"):
        ref_id = inv.get("BillingReferenceID", "مرتجع")
        instruction = inv.get("InstructionNote", "مرتجع")
        billing_ref_xml = f'''<cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>{escape(str(ref_id))}</cbc:ID>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>'''
        # KSA-10: InstructionNote داخل PaymentMeans
        instruction_note_xml = f'''<cbc:InstructionNote>{escape(str(instruction))}</cbc:InstructionNote>'''

    xml = f'''<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
 xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
 xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
 xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">
    <ext:UBLExtensions>
        <ext:UBLExtension>
            <ext:ExtensionURI>urn:oasis:names:specification:ubl:dsig:enveloped:xades</ext:ExtensionURI>
            <ext:ExtensionContent>
                SET_SIGN_HERE
            </ext:ExtensionContent>
        </ext:UBLExtension>
    </ext:UBLExtensions>
    <cbc:ProfileID>{profile}</cbc:ProfileID>
    <cbc:ID>{inv["ID"]}</cbc:ID>
    <cbc:UUID>{inv["UUID"]}</cbc:UUID>
    <cbc:IssueDate>{inv["IssueDate"]}</cbc:IssueDate>
    <cbc:IssueTime>{inv["IssueTime"]}</cbc:IssueTime>
    <cbc:InvoiceTypeCode name="{type_name}">{inv["InvoiceTypeCode"]}</cbc:InvoiceTypeCode>
    <cbc:DocumentCurrencyCode>SAR</cbc:DocumentCurrencyCode>
    <cbc:TaxCurrencyCode>SAR</cbc:TaxCurrencyCode>
    {billing_ref_xml}
    <cac:AdditionalDocumentReference>
        <cbc:ID>ICV</cbc:ID>
        <cbc:UUID>{inv["ICV"]}</cbc:UUID>
    </cac:AdditionalDocumentReference>
    <cac:AdditionalDocumentReference>
        <cbc:ID>PIH</cbc:ID>
        <cac:Attachment>
            <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">{inv["PIH"]}</cbc:EmbeddedDocumentBinaryObject>
        </cac:Attachment>
    </cac:AdditionalDocumentReference>
    <cac:AdditionalDocumentReference>
        <cbc:ID>QR</cbc:ID>
        <cac:Attachment>
            <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">SET_QR_HERE</cbc:EmbeddedDocumentBinaryObject>
        </cac:Attachment>
    </cac:AdditionalDocumentReference>
    <cac:Signature>
        <cbc:ID>urn:oasis:names:specification:ubl:signature:Invoice</cbc:ID>
        <cbc:SignatureMethod>urn:oasis:names:specification:ubl:dsig:enveloped:xades</cbc:SignatureMethod>
    </cac:Signature>
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="CRN">{csr.company_id or ""}</cbc:ID>
            </cac:PartyIdentification>
            <cac:PostalAddress>
                <cbc:StreetName>{csr.address_street_name or "main"}</cbc:StreetName>
                <cbc:BuildingNumber>{csr.address_building_number or "1111"}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{csr.address_neighborhood or "district"}</cbc:CitySubdivisionName>
                <cbc:CityName>{csr.address_city_name or "Riyadh"}</cbc:CityName>
                <cbc:PostalZone>{csr.address_postal_zone or "12345"}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{csr.organization_identifier or ""}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{csr.organization_name or ""}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    {customer_block}
    <cac:Delivery>
        <cbc:ActualDeliveryDate>{inv["IssueDate"]}</cbc:ActualDeliveryDate>
    </cac:Delivery>
    <cac:PaymentMeans>
        <cbc:PaymentMeansCode>{inv.get("PaymentMeansCode","10")}</cbc:PaymentMeansCode>
        {instruction_note_xml}
    </cac:PaymentMeans>
    {tax_subtotals_xml}
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{inv["TaxAmount"]:.2f}</cbc:TaxAmount>
    </cac:TaxTotal>
    <cac:LegalMonetaryTotal>
        <cbc:LineExtensionAmount currencyID="SAR">{inv["TaxableAmount"]:.2f}</cbc:LineExtensionAmount>
        <cbc:TaxExclusiveAmount currencyID="SAR">{inv["TaxableAmount"]:.2f}</cbc:TaxExclusiveAmount>
        <cbc:TaxInclusiveAmount currencyID="SAR">{inv["TaxInclusiveAmount"]:.2f}</cbc:TaxInclusiveAmount>
        <cbc:AllowanceTotalAmount currencyID="SAR">0.00</cbc:AllowanceTotalAmount>
        <cbc:PrepaidAmount currencyID="SAR">0.00</cbc:PrepaidAmount>
        <cbc:PayableAmount currencyID="SAR">{inv["TaxInclusiveAmount"]:.2f}</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>{lines_xml}
</Invoice>'''
    return xml


## ===================== Helper Functions (من invoice.py) =====================
# نستورد الدوال المساعدة من invoice.py عبر exec في web2py
# أو ننسخها هنا - الأسهل نسخها لأن web2py لا يدعم import بين controllers

def _hash_b64(data_bytes):
    return b64encode(hashlib.sha256(data_bytes).digest()).decode("utf-8")

def _hash_hex_b64(data_bytes):
    return b64encode(hashlib.sha256(data_bytes).hexdigest().encode("utf-8")).decode("utf-8")

def _decode_bst(bst_b64):
    cx509 = zatca_libs.cx509
    backend = zatca_libs.default_backend()
    try:
        inner = b64decode(bst_b64).decode("utf-8").strip()
        cert_der = b64decode(inner)
        cx509.load_der_x509_certificate(cert_der, backend)
        return inner, cert_der
    except Exception:
        pass
    try:
        cert_der = b64decode(bst_b64)
        cx509.load_der_x509_certificate(cert_der, backend)
        return bst_b64, cert_der
    except Exception:
        raise ValueError("cannot read cert")

def _get_issuer_name(certificate):
    parts = []
    issuer_dict = {}
    for attr in certificate.issuer:
        key = attr.oid._name
        if key in issuer_dict:
            if isinstance(issuer_dict[key], list):
                issuer_dict[key].append(attr.value)
            else:
                issuer_dict[key] = [issuer_dict[key], attr.value]
        else:
            issuer_dict[key] = attr.value
    if "commonName" in issuer_dict:
        parts.append(f"CN={issuer_dict['commonName']}")
    if "domainComponent" in issuer_dict:
        dc_list = issuer_dict["domainComponent"]
        if isinstance(dc_list, list):
            dc_list.reverse()
            for dc in dc_list:
                if dc:
                    parts.append(f"DC={dc}")
    return ", ".join(parts)

def _get_public_key_and_signature(cert_b64_clean):
    import tempfile
    crypto = zatca_libs.openssl_crypto
    cert_pem = "-----BEGIN CERTIFICATE-----\n"
    cert_pem += "\n".join([cert_b64_clean[i:i+64] for i in range(0, len(cert_b64_clean), 64)])
    cert_pem += "\n-----END CERTIFICATE-----\n"
    with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".pem") as f:
        f.write(cert_pem)
        tmp = f.name
    try:
        cert = crypto.load_certificate(crypto.FILETYPE_PEM, open(tmp).read())
        pub_key = crypto.dump_publickey(crypto.FILETYPE_ASN1, cert.get_pubkey())
        pub_nums = crypto.load_publickey(crypto.FILETYPE_ASN1, pub_key).to_cryptography_key().public_numbers()
        x = pub_nums.x.to_bytes(32, byteorder="big").rjust(32, b"\0")
        y = pub_nums.y.to_bytes(32, byteorder="big").rjust(32, b"\0")
        public_key_der = (
            b"\x30\x56\x30\x10\x06\x07\x2a\x86\x48\xce\x3d\x02\x01"
            b"\x06\x05\x2b\x81\x04\x00\x0a\x03\x42\x00\x04" + x + y
        )
        der_data = b64decode(cert_b64_clean)
        seq_pos = der_data.rfind(b"\x30", -72)
        signature = der_data[seq_pos:]
        return {"public_key": public_key_der, "signature": signature}
    finally:
        os.unlink(tmp)

def _get_signed_properties_hash(signing_time, cert_hash_hex_b64, issuer_name, serial_number):
    xml_string = (
        '<xades:SignedProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="xadesSignedProperties">\n'
        "                                    <xades:SignedSignatureProperties>\n"
        "                                        <xades:SigningTime>{}</xades:SigningTime>\n".format(signing_time)
        + "                                        <xades:SigningCertificate>\n"
        "                                            <xades:Cert>\n"
        "                                                <xades:CertDigest>\n"
        '                                                    <ds:DigestMethod xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>\n'
        '                                                    <ds:DigestValue xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:DigestValue>\n'.format(cert_hash_hex_b64)
        + "                                                </xades:CertDigest>\n"
        "                                                <xades:IssuerSerial>\n"
        '                                                    <ds:X509IssuerName xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:X509IssuerName>\n'.format(issuer_name)
        + '                                                    <ds:X509SerialNumber xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:X509SerialNumber>\n'.format(serial_number)
        + "                                                </xades:IssuerSerial>\n"
        "                                            </xades:Cert>\n"
        "                                        </xades:SigningCertificate>\n"
        "                                    </xades:SignedSignatureProperties>\n"
        "                                </xades:SignedProperties>"
    )
    xml_string = xml_string.replace("\r\n", "\n").strip()
    return _hash_hex_b64(xml_string.encode("utf-8"))

def _get_digital_signature(invoice_hash_b64, private_key_raw):
    hash_bytes = b64decode(invoice_hash_b64)
    pk = private_key_raw.strip().replace("\n", "").replace("\t", "")
    if "-----BEGIN" not in pk:
        pk = f"-----BEGIN EC PRIVATE KEY-----\n{pk}\n-----END EC PRIVATE KEY-----"
    private_key = zatca_libs.load_pem_private_key(pk.encode(), password=None, backend=zatca_libs.default_backend())
    signature = private_key.sign(hash_bytes, zatca_libs.ec.ECDSA(zatca_libs.hashes.SHA256()))
    return b64encode(signature).decode("utf-8")

def _generate_qr(canonical_xml, invoice_hash_b64, signature_value_b64, ecdsa_result):
    import xml.etree.ElementTree as ET
    ns_cbc = "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}"
    ns_cac = "{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}"
    root = ET.fromstring(canonical_xml)
    seller = root.find(f".//{ns_cac}AccountingSupplierParty/{ns_cac}Party/{ns_cac}PartyLegalEntity/{ns_cbc}RegistrationName").text
    vat = root.find(f".//{ns_cac}AccountingSupplierParty/{ns_cac}Party/{ns_cac}PartyTaxScheme/{ns_cbc}CompanyID").text
    dt = root.find(f".//{ns_cbc}IssueDate").text + "T" + root.find(f".//{ns_cbc}IssueTime").text
    total = root.find(f".//{ns_cac}LegalMonetaryTotal/{ns_cbc}PayableAmount").text
    tax = root.find(f".//{ns_cac}TaxTotal/{ns_cbc}TaxAmount").text
    values = [None, seller, vat, dt, total, tax,
              invoice_hash_b64, signature_value_b64,
              ecdsa_result["public_key"], ecdsa_result["signature"]]
    def write_tag(tag):
        result = bytes()
        flag = True
        for i in range(3, -1, -1):
            num = (tag >> (8 * i)) & 0xFF
            if num != 0 or not flag or i == 0:
                result += bytes([num])
                flag = False
        return result
    def write_length(length):
        if length <= 0x7F:
            return bytes([length])
        lb = []
        while length > 0:
            lb.insert(0, length & 0xFF)
            length >>= 8
        return bytes([0x80 | len(lb)]) + bytes(lb)
    data = b""
    for key, value in enumerate(values[1:], start=1):
        if isinstance(value, str):
            value = value.encode("utf-8")
        data += write_tag(key) + write_length(len(value)) + value
    return b64encode(data).decode("utf-8")


## ===================== الدالة الأساسية: معالجة وإرسال فاتورة =====================

def _process_and_send(inv_data, csr_config, doc_type="SIMSI"):
    """
    معالجة فاتورة وإرسالها مباشرة لـ ZATCA
    doc_type: SIMSI (مبسطة) أو STDSI (ضريبية B2B)
    يرجع dict بالنتيجة
    """
    etree = zatca_libs.etree
    is_standard = doc_type.startswith("STD")
    is_simplified = not is_standard

    env = (csr_config.environment or "simulation").lower()
    api_path = {"nonproduction": "developer-portal", "simulation": "simulation", "production": "core"}.get(env, "simulation")
    signing_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

    # 1. فك الشهادة
    cert_b64_clean, cert_der = _decode_bst(csr_config.pcsid_binarysecuritytoken)
    cert = zatca_libs.cx509.load_der_x509_certificate(cert_der, zatca_libs.default_backend())
    issuer_name = _get_issuer_name(cert)
    serial_number = cert.serial_number
    cert_hash_hex_b64 = _hash_hex_b64(cert_b64_clean.encode("utf-8"))

    # 2. بناء XML
    xml_raw = _build_invoice_xml(inv_data, csr_config, is_standard=is_standard)

    # 3. XSLT Transform + C14N + Hash
    xsl_path = os.path.join(request.folder, "private", "xslfile.xsl")
    xml_doc = etree.fromstring(xml_raw.encode("utf-8"))
    xsl = etree.parse(xsl_path)
    transform = etree.XSLT(xsl)
    transformed = transform(xml_doc)
    canonical_xml = etree.tostring(transformed, method="c14n").decode("utf-8")
    invoice_hash_b64 = _hash_b64(canonical_xml.encode("utf-8"))

    if is_simplified:
        # ====== فاتورة مبسطة: توقيع محلي + QR ======
        signed_props_hash = _get_signed_properties_hash(signing_time, cert_hash_hex_b64, issuer_name, serial_number)
        signature_value = _get_digital_signature(invoice_hash_b64, csr_config.privatekey)
        ecdsa_result = _get_public_key_and_signature(cert_b64_clean)

        # تعبئة قالب UBL
        ubl_path = os.path.join(request.folder, "private", "zatca_ubl.xml")
        with open(ubl_path, "r") as f:
            ubl_content = f.read()
        ubl_content = ubl_content.replace("INVOICE_HASH", invoice_hash_b64)
        ubl_content = ubl_content.replace("SIGNED_PROPERTIES", signed_props_hash)
        ubl_content = ubl_content.replace("SIGNATURE_VALUE", signature_value)
        ubl_content = ubl_content.replace("CERTIFICATE_CONTENT", cert_b64_clean)
        ubl_content = ubl_content.replace("SIGNATURE_TIMESTAMP", signing_time)
        ubl_content = ubl_content.replace("PUBLICKEY_HASHING", cert_hash_hex_b64)
        ubl_content = ubl_content.replace("ISSUER_NAME", issuer_name)
        ubl_content = ubl_content.replace("SERIAL_NUMBER", str(serial_number))

        # إدراج UBL بعد أول >
        insert_pos = canonical_xml.find(">") + 1
        updated_xml = canonical_xml[:insert_pos] + ubl_content + canonical_xml[insert_pos:]

        # QR
        qr_b64 = _generate_qr(canonical_xml, invoice_hash_b64, signature_value, ecdsa_result)

        # إدراج Signature + QR قبل AccountingSupplierParty
        sig_path = os.path.join(request.folder, "private", "zatca_signature.xml")
        with open(sig_path, "r") as f:
            sig_content = f.read()
        sig_content = sig_content.replace("BASE64_QRCODE", qr_b64)
        insert_pos_sig = updated_xml.find("<cac:AccountingSupplierParty>")
        if insert_pos_sig != -1:
            updated_xml = updated_xml[:insert_pos_sig] + sig_content + updated_xml[insert_pos_sig:]

        final_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + updated_xml
        invoice_b64 = b64encode(final_xml.encode("utf-8")).decode("utf-8")

        # إرسال Reporting
        zatca_url = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
        headers = {"accept": "application/json", "accept-language": "en",
                   "Accept-Version": "V2", "Content-Type": "application/json"}
        success_field = "reportingStatus"
        success_value = "REPORTED"

    else:
        # ====== فاتورة ضريبية B2B: بدون توقيع محلي - ZATCA يوقعها ======
        final_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + canonical_xml
        invoice_b64 = b64encode(final_xml.encode("utf-8")).decode("utf-8")
        qr_b64 = ""

        # إرسال Clearance
        zatca_url = f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single"
        headers = {"accept": "application/json", "accept-language": "en",
                   "Clearance-Status": "1",
                   "Accept-Version": "V2", "Content-Type": "application/json"}
        success_field = "clearanceStatus"
        success_value = "CLEARED"

    # الإرسال
    body = json.dumps({"invoiceHash": invoice_hash_b64, "uuid": inv_data["UUID"], "invoice": invoice_b64})
    resp = zatca_libs.requests_lib.post(
        zatca_url, headers=headers, data=body,
        auth=zatca_libs.HTTPBasicAuth(csr_config.pcsid_binarysecuritytoken, csr_config.pcsid_secret),
        timeout=60
    )
    resp_data = resp.json() if resp.status_code in (200, 202, 400) else {"error": resp.text}
    status = resp_data.get(success_field, "")

    # استخراج QR من clearedInvoice لفواتير B2B
    if not is_simplified and status == success_value and resp_data.get("clearedInvoice"):
        import re
        try:
            cleared_xml = b64decode(resp_data["clearedInvoice"]).decode("utf-8")
            qr_match = re.search(
                r'<cbc:ID>QR</cbc:ID>.*?<cbc:EmbeddedDocumentBinaryObject[^>]*>(.*?)</cbc:EmbeddedDocumentBinaryObject>',
                cleared_xml, re.DOTALL
            )
            if qr_match:
                qr_b64 = qr_match.group(1).strip()
        except Exception:
            pass

    # حفظ XML في static/xml/ برقم الفاتورة ونوعها
    if status == success_value:
        try:
            xml_dir = os.path.join(request.folder, "static", "xml")
            os.makedirs(xml_dir, exist_ok=True)
            inv_id = inv_data.get("ID", "unknown").replace("/", "-")
            xml_filename = f"{inv_id}_{doc_type}.xml"
            xml_to_save = final_xml
            # لفواتير B2B: حفظ النسخة الموقعة من ZATCA
            if not is_simplified and resp_data.get("clearedInvoice"):
                xml_to_save = b64decode(resp_data["clearedInvoice"]).decode("utf-8")
            with open(os.path.join(xml_dir, xml_filename), "w", encoding="utf-8") as xf:
                xf.write(xml_to_save)
        except Exception:
            pass

    return {
        "success": status == success_value,
        "status": status,
        "http_status": resp.status_code,
        "invoice_hash": invoice_hash_b64,
        "qr_code": qr_b64,
        "zatca_url": zatca_url,
        "zatca_response": resp_data,
        "doc_type": doc_type,
    }


## ===================== الصفحة الرئيسية =====================

@auth.requires_login()
def index():
    """صفحة اختبار إرسال الفواتير"""
    return dict()


## ===================== إرسال فاتورة مبسطة B2C =====================

@auth.requires_login()
def send_b2c():
    """إرسال فاتورة مبسطة (B2C) تجريبية - Reporting"""
    import uuid as uuid_lib
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config or not csr_config.pcsid_requestid:
            return response.json({"err": 4, "mess": "لم يتم الربط مع الهيئة"})

        now = datetime.now()
        icv = str(int(csr_config.icv or 0) + 1)
        pih = csr_config.pih or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
        max_no = db.invoice_master.id.max()
        last = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0

        inv_data = {
            "ID": "INV-" + str(last + 1).zfill(12),
            "UUID": str(uuid_lib.uuid4()),
            "IssueDate": now.strftime("%Y-%m-%d"), "IssueTime": now.strftime("%H:%M:%S"),
            "InvoiceTypeCode": "388", "ICV": icv, "PIH": pih,
            "CustomerName": "عميل تجريبي", "PaymentMeansCode": "10",
            "CustomerStreetName": "*", "CustomerBuildingNumber": "1111",
            "CustomerCityName": "*", "CustomerDistrict": "*", "CustomerPostalZone": "12345",
            "TaxAmount": 30.00, "TaxableAmount": 200.00, "TaxInclusiveAmount": 230.00,
            "InvoiceLines": [{
                "ID": "1", "Quantity": 2.0, "LineExtensionAmount": 200.00,
                "TaxAmount": 30.00, "RoundingAmount": 230.00,
                "Name": "صنف تجريبي B2C", "TaxPercent": 15.00, "PriceAmount": 100.00
            }]
        }
        result = _process_and_send(inv_data, csr_config, "SIMSI")
        if result["success"]:
            new_icv = int(csr_config.icv or 0) + 1
            csr_config.update_record(icv=new_icv, pih=result["invoice_hash"])
            db.commit()
        return response.json({"err": 0 if result["success"] else 9, **result,
                               "uuid": inv_data["UUID"], "invoice_number": inv_data["ID"]})
    except Exception as e:
        import traceback
        db.rollback()
        return response.json({"err": 3, "mess": str(e), "trace": traceback.format_exc()})


## ===================== إرسال فاتورة ضريبية B2B =====================

@auth.requires_login()
def send_b2b():
    """إرسال فاتورة ضريبية (B2B) تجريبية - Clearance"""
    import uuid as uuid_lib
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config or not csr_config.pcsid_requestid:
            return response.json({"err": 4, "mess": "لم يتم الربط مع الهيئة"})

        now = datetime.now()
        icv = str(int(csr_config.icv or 0) + 1)
        pih = csr_config.pih or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
        max_no = db.invoice_master.id.max()
        last = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0

        inv_data = {
            "ID": "INV-" + str(last + 1).zfill(12),
            "UUID": str(uuid_lib.uuid4()),
            "IssueDate": now.strftime("%Y-%m-%d"), "IssueTime": now.strftime("%H:%M:%S"),
            "InvoiceTypeCode": "388", "ICV": icv, "PIH": pih,
            # بيانات عميل B2B (رقم ضريبي + سجل تجاري)
            "CustomerName": "شركة تجريبية للاختبار",
            "CustomerVAT": "300075588700003",
            "CustomerCRN": "1010010000",
            "CustomerStreetName": "شارع الملك فهد",
            "CustomerBuildingNumber": "1234",
            "CustomerCityName": "الرياض",
            "CustomerDistrict": "العليا",
            "CustomerPostalZone": "12244",
            "PaymentMeansCode": "10",
            "TaxAmount": 75.00, "TaxableAmount": 500.00, "TaxInclusiveAmount": 575.00,
            "InvoiceLines": [{
                "ID": "1", "Quantity": 5.0, "LineExtensionAmount": 500.00,
                "TaxAmount": 75.00, "RoundingAmount": 575.00,
                "Name": "خدمة استشارية B2B", "TaxPercent": 15.00, "PriceAmount": 100.00
            }]
        }
        result = _process_and_send(inv_data, csr_config, "STDSI")
        if result["success"]:
            new_icv = int(csr_config.icv or 0) + 1
            csr_config.update_record(icv=new_icv, pih=result["invoice_hash"])
            db.commit()
        return response.json({"err": 0 if result["success"] else 9, **result,
                               "uuid": inv_data["UUID"], "invoice_number": inv_data["ID"]})
    except Exception as e:
        import traceback
        db.rollback()
        return response.json({"err": 3, "mess": str(e), "trace": traceback.format_exc()})
