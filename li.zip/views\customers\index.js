var app = new Vue({
    el: '#app',
    data: {
            counter: 0,
            data: [],
            getData: {
                page: 0,
                RecordCount: 20,
                SearchText: '',
                SortBy: 'id',
                sortAsc: true
            },
            data_row_count: 0,
            coding: {
                supplier: [],
                Allsupplier: [],
                types: [],
                units: [],
            },
            select_obj_1: {
                serch_text: '',
                show_select: false,
                select_value: '',
                select_id: '',
            },
            select_obj_2: 0,
            showBtn: 0,
            show_model: false,
            selectedRow: -1,
            text_ltr: false,
            new_row: true,
            edit_row_data: {},
            value: '',
            options: [] ,
    },
    created() {
        fetch(window.location.href + '/../../customers_api/get_customers', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../customers_api/get_customers'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        get() {
            //
            //
        },
        open_add() {
            window.open(window.location.href + '/../new', '_self');
        },
        goToPage(p) {
            if (p < 0 || p >= this.totalPages || p === this.getData.page) return;
            this.getData.page = p;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../customers_api/get_customers'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            // if (index===0){
            //     return ;
            // }
            // console.log(index);
            // console.log(row);
            sup = {} ;
            this.options.forEach((el)=>{
                if (el.value === row.suppliers ){
                    sup = el ;
                }
            })
            if (sup == {}) {
                sup = { value: 0, label: 'اختر' };
            }
            this.edit_row_data.suppliers = sup ;
            
            if (row.flexible_price === 'T') {
                this.edit_row_data.flexible_price = true ;
            } else {
                this.edit_row_data.flexible_price = false ;
            }
        },
        edit_row() {
            this.new_row = false;
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_data() {
            //var myModalEl = document.getElementById('exampleModal');
            //var row_modal = bootstrap.Modal.getInstance(myModalEl);
            if (!this.edit_row_data.name || !this.edit_row_data.mobile  ) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [الاسم - رقم الجوال  ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../customers_api/new_customer');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.edit_row_data.name = this.edit_row_data.name.toLowerCase().trim()
                            this.data.push(this.edit_row_data);
                            this.edit_row_data = {} ;
                            this.selectedRow = -1 ;
                            //row_modal.hide();
                            hideModal('exampleModal')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../customers_api/edit_customer');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.name = this.edit_row_data.name.toLowerCase().trim()
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {} ;
                            this.selectedRow = -1 ;
                            hideModal('exampleModal')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess ,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1 ;

        },
        items_history() {
            url = window.location.href + '/../customer_status_rep/' + this.edit_row_data.id;
            window.open(url); 
        } ,
        items_sales() {
            url = window.location.href + '/../purchase/' + this.edit_row_data.id;
            window.open(url);
        },
        adjust_quantity() {
            url = window.location.href + '/../customers_pay/' + this.edit_row_data.id;
            window.open(url);
        },
    } ,
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var pages = [];
            var start = Math.max(1, this.getData.page - 2);
            var end = Math.min(this.totalPages, this.getData.page + 4);
            if (end - start < 4) {
                start = Math.max(1, end - 4);
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            return pages;
        }
    },
    watch: {
        value : function (val) {
            this.onChange() ;
        }
    }
}) ;
