# coding: utf8
# type: ignore


@can_access(2001)
def index():
    return dict()


# =====================================================
#                       API
# =====================================================


def get_invoices():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    sort_col = ReqVar.SortBy or "id"
    if sort_col not in ("id", "supplier", "bill_no", "bill_date", "bill_total", "bill_net_amount", "bill_vat"):
        sort_col = "id"
    sort_dir = "ASC" if ReqVar.sequence == "true" else "DESC"
    where = " WHERE 1=1 "
    params = []
    if search.strip():
        where += (
            " AND (supplier LIKE %s"
            " OR bill_no LIKE %s"
            " OR CAST(bill_date AS TEXT) LIKE %s"
            " OR CAST(bill_total AS TEXT) LIKE %s"
            " OR CAST(bill_net_amount AS TEXT) LIKE %s"
            " OR CAST(bill_vat AS TEXT) LIKE %s) "
        )
        pattern = "%" + search + "%"
        params.extend([pattern, pattern, pattern, pattern, pattern, pattern])
    offset = pg * rc
    sql = "SELECT * FROM purchase_invoices " + where + " ORDER BY " + sort_col + " " + sort_dir + " LIMIT %s OFFSET %s"
    sql_count = "SELECT COUNT(*) FROM purchase_invoices " + where
    rows = db.executesql(sql, placeholders=params + [rc, offset], as_dict=True)
    count = db.executesql(sql_count, placeholders=params)[0][0]
    return response.json({"data": rows, "count": count})


@can_access(2001)
def new_invoice():
    try:
        sc = screens_rules(2001)
        if not sc or not sc.can_add:
            return response.json({"err": 3, "mess": "غير مسموح بالإضافة"})
        data = request.vars
        nid = db.purchase_invoices.validate_and_insert(
            supplier=data.supplier,
            bill_no=data.bill_no,
            bill_date=data.bill_date,
            bill_total=data.bill_total,
            bill_net_amount=data.bill_net_amount,
            bill_vat=data.bill_vat,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(2001)
def edit_invoice():
    try:
        sc = screens_rules(2001)
        if not sc or not sc.can_edit:
            return response.json({"err": 3, "mess": "غير مسموح بالتعديل"})
        data = request.vars
        row = db.purchase_invoices[data.id]
        row.update_record(
            supplier=data.supplier,
            bill_no=data.bill_no,
            bill_date=data.bill_date,
            bill_total=data.bill_total,
            bill_net_amount=data.bill_net_amount,
            bill_vat=data.bill_vat,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)
