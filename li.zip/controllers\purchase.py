# coding: utf8
# type: ignore


def index():
    return dict()


# =====================================================
#                       API
# =====================================================


def get_invoices():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    sort_col = ReqVar.SortBy or "id"
    if sort_col not in ("id", "supplier", "bill_no", "bill_date", "bill_total", "bill_net_amount", "bill_vat"):
        sort_col = "id"
    sort_dir = "ASC" if ReqVar.sequence == "true" else "DESC"
    where = " WHERE 1=1 "
    if search.strip():
        where += (
            f" AND (supplier LIKE '%{search}%'"
            f" OR bill_no LIKE '%{search}%'"
            f" OR CAST(bill_date AS TEXT) LIKE '%{search}%'"
            f" OR CAST(bill_total AS TEXT) LIKE '%{search}%'"
            f" OR CAST(bill_net_amount AS TEXT) LIKE '%{search}%'"
            f" OR CAST(bill_vat AS TEXT) LIKE '%{search}%') "
        )
    offset = pg * rc
    sql = f"SELECT * FROM purchase_invoices {where} ORDER BY {sort_col} {sort_dir} LIMIT {rc} OFFSET {offset}"
    sql_count = f"SELECT COUNT(*) FROM purchase_invoices {where}"
    rows = db.executesql(sql, as_dict=True)
    count = db.executesql(sql_count)[0][0]
    return response.json({"data": rows, "count": count})


def new_invoice():
    try:
        data = request.vars
        nid = db.purchase_invoices.validate_and_insert(
            supplier=data.supplier,
            bill_no=data.bill_no,
            bill_date=data.bill_date,
            bill_total=data.bill_total,
            bill_net_amount=data.bill_net_amount,
            bill_vat=data.bill_vat,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(e)


def edit_invoice():
    try:
        data = request.vars
        row = db.purchase_invoices[data.id]
        row.update_record(
            supplier=data.supplier,
            bill_no=data.bill_no,
            bill_date=data.bill_date,
            bill_total=data.bill_total,
            bill_net_amount=data.bill_net_amount,
            bill_vat=data.bill_vat,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)
