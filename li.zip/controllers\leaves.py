# -*- coding: utf-8 -*-
#  type: ignore


@auth.requires_membership("admin")
def index():
    return dict()


def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    return response.json({"employees": employees})


def get_leaves():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( emp.emp_name LIKE %s OR CAST(lv.start_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern])

    allowed_sort_columns = {'id', 'emp_name', 'start_date', 'end_date', 'days_count', 'tickets_paid', 'allowance_paid'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'

    sort_map = {
        'id': 'lv.id',
        'emp_name': 'emp.emp_name',
        'start_date': 'lv.start_date',
        'end_date': 'lv.end_date',
        'days_count': 'lv.days_count',
        'tickets_paid': 'lv.tickets_paid',
        'allowance_paid': 'lv.allowance_paid',
    }
    sort_col = sort_map.get(sc, 'lv.id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT lv.id, lv.employee, lv.start_date, lv.end_date, lv.days_count, "
        f"lv.tickets_paid, lv.allowance_paid, "
        f"emp.emp_name "
        f"FROM emp_leaves lv "
        f"JOIN employees emp ON emp.id = lv.employee "
        f"{where} ORDER BY {sort_col} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM emp_leaves lv "
        f"JOIN employees emp ON emp.id = lv.employee "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def new_leave():
    try:
        data = request.vars

        start_date = data.start_date if data.start_date and data.start_date != '' else None
        end_date = data.end_date if data.end_date and data.end_date != '' else None

        nid = db.emp_leaves.insert(
            employee=int(data.employee),
            start_date=start_date,
            end_date=end_date,
            days_count=int(data.days_count or 0),
            tickets_paid=False,
            allowance_paid=False,
        )
        db.commit()

        inserted = db.executesql(
            "SELECT lv.id, lv.employee, lv.start_date, lv.end_date, lv.days_count, "
            "lv.tickets_paid, lv.allowance_paid, "
            "emp.emp_name "
            "FROM emp_leaves lv "
            "JOIN employees emp ON emp.id = lv.employee "
            "WHERE lv.id = %s",
            placeholders=[nid], as_dict=True
        )
        return response.json(inserted[0] if inserted else {"id": nid})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


def update_leave():
    try:
        data = request.vars
        row = db.emp_leaves[data.id]
        if not row:
            return response.json({"id": 0, "mess": "السجل غير موجود"})

        row.employee = int(data.employee)
        row.start_date = data.start_date if data.start_date and data.start_date != '' else None
        row.end_date = data.end_date if data.end_date and data.end_date != '' else None
        row.days_count = int(data.days_count or 0)
        row.tickets_paid = (data.tickets_paid == 'true' or data.tickets_paid == 'on')
        row.allowance_paid = (data.allowance_paid == 'true' or data.allowance_paid == 'on')

        row.update_record()
        db.commit()

        updated = db.executesql(
            "SELECT lv.id, lv.employee, lv.start_date, lv.end_date, lv.days_count, "
            "lv.tickets_paid, lv.allowance_paid, "
            "emp.emp_name "
            "FROM emp_leaves lv "
            "JOIN employees emp ON emp.id = lv.employee "
            "WHERE lv.id = %s",
            placeholders=[data.id], as_dict=True
        )
        return response.json(updated[0] if updated else {"id": data.id})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "mess": str(e)})


def delete_leave():
    try:
        row = db.emp_leaves[request.args(0)]
        if not row:
            return response.json({"status": 0, "mess": "السجل غير موجود"})
        row.delete_record()
        db.commit()
        return response.json({"status": 1})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"status": 0, "mess": str(e)})
