var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        data: [],
        dataCount: 0,
        page: 0,
        recordCount: 20,
        searchText: '',
        printUrl: printUrl,
        printMinUrl: printMinUrl,
        zatcaRow: null,
        zatcaParsed: null
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.dataCount / this.recordCount) || 1;
        },
        currentPage: function () {
            return this.page + 1;
        },
        visiblePages: function () {
            var pages = [];
            var start = Math.max(1, this.page - 2);
            var end = Math.min(this.totalPages, this.page + 4);
            if (end - start < 4) {
                start = Math.max(1, end - 4);
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            return pages;
        }
    },
    created: function () {
        this.loadData();
    },
    methods: {
        loadData: function () {
            var params = 'page=' + this.page + '&RecordCount=' + this.recordCount + '&SearchText=' + encodeURIComponent(this.searchText);
            this.$http.get(this.URL + '/../invoice_show_list?' + params).then(function (res) {
                this.data = res.body.data;
                this.dataCount = res.body.count;
            });
        },
        onSearch: function () {
            this.page = 0;
            this.loadData();
        },
        goToPage: function (p) {
            if (p < 0 || p >= this.totalPages || p === this.page) return;
            this.page = p;
            this.loadData();
        },
        showZatcaRes: function (row) {
            this.zatcaRow = row;
            this.zatcaParsed = null;
            if (row.zatca_res) {
                try {
                    this.zatcaParsed = typeof row.zatca_res === 'string' ? JSON.parse(row.zatca_res) : row.zatca_res;
                } catch (e) {
                    this.zatcaParsed = null;
                }
            }
            showModal('zatcaModal');
        }
    }
});
