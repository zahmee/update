var API_BASE = window.location.href + '/../../leaves/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        employees_list: [],
        loading: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    created: function () {
        this.loading = true;
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.employees_list = data.employees;
            }.bind(this));
        this.fetchData().then(function (data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
            };
            var url = new URL(API_BASE + 'get_leaves');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
            this.edit_row_data.tickets_paid = this.isTrue(row.tickets_paid);
            this.edit_row_data.allowance_paid = this.isTrue(row.allowance_paid);
        },
        edit_row: function () {
            this.new_row = false;
        },
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = { tickets_paid: false, allowance_paid: false };
        },
        calcDays: function () {
            if (this.edit_row_data.start_date && this.edit_row_data.end_date) {
                var s = new Date(this.edit_row_data.start_date);
                var e = new Date(this.edit_row_data.end_date);
                var diff = Math.ceil((e - s) / (1000 * 60 * 60 * 24));
                if (diff >= 0) {
                    this.edit_row_data.days_count = diff + 1;
                }
            }
        },
        save_data: function () {
            if (!this.edit_row_data.employee) {
                Swal.fire('تنبيه', 'يجب اختيار الموظف', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('employee', this.edit_row_data.employee);
            formData.append('start_date', this.edit_row_data.start_date || '');
            formData.append('end_date', this.edit_row_data.end_date || '');
            formData.append('days_count', this.edit_row_data.days_count || 0);
            formData.append('tickets_paid', this.edit_row_data.tickets_paid ? 'true' : 'false');
            formData.append('allowance_paid', this.edit_row_data.allowance_paid ? 'true' : 'false');

            var endpoint = this.new_row ? 'new_leave' : 'update_leave';
            if (!this.new_row) {
                formData.append('id', this.edit_row_data.id);
            }

            var self = this;
            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.id && data.id > 0) {
                        if (self.new_row) {
                            self.data.splice(0, 0, data);
                            self.data_row_count++;
                        } else {
                            self.$set(self.data, self.selectedRow, data);
                        }
                        self.edit_row_data = {};
                        self.selectedRow = -1;
                        self.new_row = true;
                        bootstrap.Modal.getInstance(document.getElementById("leaveModal")).hide();
                        Swal.fire('تم بنجاح', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        delete_leave: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف إجازة: ' + row.emp_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_leave/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ أثناء الحذف', 'error');
                            }
                        });
                }
            });
        },
        cancel_data: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        isTrue: function (val) {
            return val === 'T' || val === true;
        },
    }
});
