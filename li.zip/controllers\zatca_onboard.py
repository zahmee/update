# type: ignore
"""
كونترولر الربط مع هيئة الزكاة والضريبة والدخل - ZATCA Onboarding
الخطوات:
1. توليد المفتاح الخاص و CSR + الحصول على Compliance CSID
2. إرسال 6 فواتير تجريبية (STDSI, STDCN, STDDN, SIMSI, SIMCN, SIMDN)
3. الحصول على Production CSID
"""
from datetime import datetime
import json
import os
import uuid as uuid_lib
import subprocess
import tempfile
import random
import string
import hashlib
from base64 import b64decode, b64encode
from pathlib import Path
import zatca_libs


ZATCA_BASE = "https://gw-fatoora.zatca.gov.sa/e-invoicing"
DEFAULT_PIH = "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="


def _api_path(env):
    return {"nonproduction": "developer-portal", "simulation": "simulation", "production": "core"}.get(env.lower(), "simulation")


def _clean_pem(text):
    """إزالة headers/footers من PEM"""
    return text.replace("-----BEGIN EC PRIVATE KEY-----", "").replace(
        "-----END EC PRIVATE KEY-----", "").replace(
        "-----BEGIN CERTIFICATE REQUEST-----", "").replace(
        "-----END CERTIFICATE REQUEST-----", "").replace("\n", "").replace("\r", "").strip()


def _random_code(length=6):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))


## ===================== الصفحة الرئيسية =====================

@can_access(6001)
def index():
    csr_config = db(db.csr_config.id > 0).select().first()
    return dict(csr_config=csr_config)


@can_access(6001)
def save_config():
    """حفظ بيانات الربط"""
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config:
            return response.json({"err": 1, "mess": "لا يوجد سجل في csr_config"})
        v = request.vars
        csr_config.update_record(
            organization_name=v.organization_name or csr_config.organization_name,
            organization_identifier=v.organization_identifier or csr_config.organization_identifier,
            organization_unit_name=v.organization_unit_name or csr_config.organization_unit_name,
            country_name=v.country_name or csr_config.country_name or "SA",
            company_id=v.company_id or csr_config.company_id,
            location_address=v.location_address or csr_config.location_address,
            business_category=v.business_category or csr_config.business_category,
            address_city_name=v.address_city_name or csr_config.address_city_name,
            address_street_name=v.address_street_name or csr_config.address_street_name,
            address_postal_zone=v.address_postal_zone or csr_config.address_postal_zone,
            address_building_number=v.address_building_number or csr_config.address_building_number,
            address_neighborhood=v.address_neighborhood or csr_config.address_neighborhood,
            environment=v.environment or csr_config.environment,
            otp=v.otp or csr_config.otp,
        )
        db.commit()
        return response.json({"err": 0, "mess": "تم حفظ البيانات بنجاح"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


## ===================== تصدير / استيراد JSON =====================

@can_access(6001)
def export_json():
    """تصدير بيانات csr_config كملف JSON"""
    csr_config = db(db.csr_config.id > 0).select().first()
    if not csr_config:
        return response.json({"err": 1, "mess": "لا يوجد بيانات"})
    data = {}
    for f in db.csr_config.fields:
        if f != "id":
            data[f] = csr_config[f]
    return response.json(data)


@can_access(6001)
def import_json():
    """استيراد بيانات من ملف JSON وحفظها في csr_config"""
    try:
        raw = request.body.read()
        data = json.loads(raw)
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config:
            return response.json({"err": 1, "mess": "لا يوجد سجل csr_config"})
        update_fields = {}
        for f in db.csr_config.fields:
            if f != "id" and f in data and data[f] is not None:
                update_fields[f] = data[f]
        if update_fields:
            csr_config.update_record(**update_fields)
            db.commit()
        return response.json({"err": 0, "mess": f"تم استيراد {len(update_fields)} حقل بنجاح"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


## ===================== الربط الكامل بضغطة واحدة =====================

@can_access(6001)
def full_onboard():
    """تنفيذ الخطوات الثلاث تلقائياً: CSR → 6 فواتير → Production CSID"""
    import traceback
    results = {"steps": [], "err": 0, "mess": ""}
    try:
        # الخطوة 1
        r1 = _do_step1()
        results["steps"].append({"step": 1, "name": "Compliance CSID", **r1})
        if r1["err"] != 0:
            results["err"] = r1["err"]
            results["mess"] = f"فشل الخطوة 1: {r1['mess']}"
            return response.json(results)

        # الخطوة 2
        r2 = _do_step2()
        results["steps"].append({"step": 2, "name": "Compliance Checks", **r2})
        if r2["err"] != 0:
            results["err"] = r2["err"]
            results["mess"] = f"فشل الخطوة 2: {r2['mess']}"
            return response.json(results)

        # الخطوة 3
        r3 = _do_step3()
        results["steps"].append({"step": 3, "name": "Production CSID", **r3})
        if r3["err"] != 0:
            results["err"] = r3["err"]
            results["mess"] = f"فشل الخطوة 3: {r3['mess']}"
            return response.json(results)

        results["mess"] = "تم الربط بنجاح! جميع الخطوات نجحت."
        return response.json(results)
    except Exception as e:
        results["err"] = 3
        results["mess"] = str(e)
        results["trace"] = traceback.format_exc()
        return response.json(results)


## ===================== الخطوة 1: توليد CSR + Compliance CSID =====================

def _do_step1():
    """الخطوة 1 - منطق داخلي"""
    csr_config = db(db.csr_config.id > 0).select().first()
    otp = request.vars.otp or csr_config.otp
    env = (request.vars.environment or csr_config.environment or "simulation").lower()
    api_p = _api_path(env)
    vat = csr_config.organization_identifier or ""
    crn = csr_config.company_id or ""

    if not otp or len(str(otp)) != 6:
        return {"err": 1, "mess": "يجب إدخال OTP من 6 أرقام"}

    cn3 = _random_code()
    sn = f"1-{vat}|2-{crn}|3-{cn3}"
    cert_template = "ZATCA-Code-Signing" if env == "production" else "PREZATCA-Code-Signing"

    cnf_content = f"""
oid_section = OIDs
[OIDs]
certificateTemplateName = 1.3.6.1.4.1.311.20.2
[req]
default_bits = 2048
req_extensions = v3_req
prompt = no
default_md = sha256
req_extensions = req_ext
distinguished_name = dn
[dn]
C  = {csr_config.country_name or 'SA'}
O  = {csr_config.organization_name or ''}
OU = {csr_config.organization_unit_name or ''}
CN = {crn}
[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment
[req_ext]
certificateTemplateName = ASN1:PRINTABLESTRING:{cert_template}
subjectAltName = dirName:alt_names
[alt_names]
SN = {sn}
UID = {vat}
title = 1100
registeredAddress = {csr_config.location_address or 'Riyadh'}
businessCategory = {csr_config.business_category or 'Technology'}
"""
    egs_uuid = str(uuid_lib.uuid4())

    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        (tmp / "config.cnf").write_text(cnf_content.strip() + "\n", encoding="utf-8")
        key_path, csr_path = tmp / "key.pem", tmp / "csr.csr"
        subprocess.run(["openssl", "ecparam", "-name", "secp256k1", "-genkey", "-noout", "-out", str(key_path)], check=True, capture_output=True)
        subprocess.run(["openssl", "req", "-new", "-sha256", "-key", str(key_path), "-config", str(tmp / "config.cnf"), "-out", str(csr_path)], check=True, capture_output=True)
        pk_pem = key_path.read_text(encoding="utf-8")
        csr_bytes = csr_path.read_bytes()

    pk_clean = _clean_pem(pk_pem)
    csr_b64 = b64encode(csr_bytes).decode("utf-8")

    resp = zatca_libs.requests_lib.post(
        f"{ZATCA_BASE}/{api_p}/compliance",
        headers={"accept": "application/json", "accept-language": "en", "OTP": str(otp), "Accept-Version": "V2", "Content-Type": "application/json"},
        data=json.dumps({"csr": csr_b64}), timeout=60
    )
    if resp.status_code != 200:
        return {"err": 2, "mess": f"ZATCA رفض: {resp.status_code}", "detail": resp.text}

    zr = resp.json()
    if not zr.get("requestID"):
        return {"err": 2, "mess": "لا يوجد requestID", "detail": zr}

    csr_config.update_record(
        privatekey=pk_clean, csr=csr_b64, egs_uuid=egs_uuid, environment=env, otp=str(otp),
        ccsid_requestid=zr.get("requestID"), ccsid_binarysecuritytoken=zr.get("binarySecurityToken"),
        ccsid_secret=zr.get("secret"), icv=0, pih=DEFAULT_PIH,
    )
    db.commit()
    return {"err": 0, "mess": "Compliance CSID تم بنجاح", "requestID": zr.get("requestID")}


## ===================== الخطوة 1 (endpoint) =====================

@can_access(6001)
def step1_generate_csid():
    try:
        return response.json(_do_step1())
    except Exception as e:
        import traceback; db.rollback()
        return response.json({"err": 3, "mess": str(e), "trace": traceback.format_exc()})


## ===================== الخطوة 2: إرسال 6 فواتير تجريبية =====================

def _do_step2():
    """الخطوة 2 - منطق داخلي"""
    csr_config = db(db.csr_config.id > 0).select().first()
    if not csr_config or not csr_config.ccsid_requestid:
            return {"err": 1, "mess": "يجب تنفيذ الخطوة 1 أولاً"}

    env = (csr_config.environment or "simulation").lower()
    api_p = _api_path(env)
    compliance_checks_url = f"{ZATCA_BASE}/{api_p}/compliance/invoices"
    etree = zatca_libs.etree

    # فك الشهادة
    x509_cert = b64decode(csr_config.ccsid_binarysecuritytoken or "").decode("utf-8")
    private_key = csr_config.privatekey

    # تحميل قالب الفاتورة
    template_path = os.path.join(request.folder, "private", "zatca_test_invoice.xml")
    parser = etree.XMLParser(remove_blank_text=False)
    base_doc = etree.parse(template_path, parser)
    ns = {
        "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
        "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
    }

    # تحديث بيانات المورد في القالب
    root = base_doc.getroot()
    root.find(".//cbc:IssueDate", namespaces=ns).text = datetime.today().strftime("%Y-%m-%d")
    root.find(".//cbc:IssueTime", namespaces=ns).text = datetime.now().strftime("%H:%M:%S")
    root.find(".//cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID", namespaces=ns).text = csr_config.organization_identifier or ""
    root.find(".//cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID", namespaces=ns).text = csr_config.company_id or ""

    # 6 أنواع فواتير تجريبية
    doc_types = [
        ["STDSI", "388", "فاتورة ضريبية قياسية", ""],
        ["STDCN", "383", "إشعار دائن قياسي", "InstructionNotes for Standard CreditNote"],
        ["STDDN", "381", "إشعار مدين قياسي", "InstructionNotes for Standard DebitNote"],
        ["SIMSI", "388", "فاتورة مبسطة", ""],
        ["SIMCN", "383", "إشعار دائن مبسط", "InstructionNotes for Simplified CreditNote"],
        ["SIMDN", "381", "إشعار مدين مبسط", "InstructionNotes for Simplified DebitNote"],
    ]

    icv = 0
    pih = DEFAULT_PIH
    results = []
    xsl_path = os.path.join(request.folder, "private", "xslfile.xsl")
    ubl_path = os.path.join(request.folder, "private", "zatca_ubl.xml")
    sig_path = os.path.join(request.folder, "private", "zatca_signature.xml")

    for prefix, type_code, desc, instruction_note in doc_types:
        icv += 1
        is_simplified = prefix.startswith("SIM")
        type_name = "0200000" if is_simplified else "0100000"

        # نسخ القالب وتعديله
        new_doc = etree.ElementTree(etree.fromstring(etree.tostring(base_doc.getroot(), pretty_print=True)))
        new_ns = ns
        new_root = new_doc.getroot()

        # تعديل ID, UUID, InvoiceTypeCode, ICV, PIH
        new_root.find(".//cbc:ID", namespaces=new_ns).text = f"{prefix}-0001"
        new_root.find(".//cbc:UUID", namespaces=new_ns).text = str(uuid_lib.uuid4()).upper()
        itc = new_root.find(".//cbc:InvoiceTypeCode", namespaces=new_ns)
        itc.text = type_code
        itc.set("name", type_name)
        new_root.find(".//cac:AdditionalDocumentReference[cbc:ID='ICV']/cbc:UUID", namespaces=new_ns).text = str(icv)
        new_root.find(".//cac:AdditionalDocumentReference[cbc:ID='PIH']/cac:Attachment/cbc:EmbeddedDocumentBinaryObject", namespaces=new_ns).text = pih

        # InstructionNote / BillingReference
        if instruction_note:
            pm = new_root.find(".//cac:PaymentMeans", namespaces=new_ns)
            if pm is not None:
                note_el = etree.SubElement(pm, "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}InstructionNote")
                note_el.text = instruction_note
        else:
            for br in new_root.findall(".//cac:BillingReference", namespaces=new_ns):
                br.getparent().remove(br)

        # XSLT Transform + C14N + Hash
        xsl = etree.parse(xsl_path)
        transformed = etree.XSLT(xsl)(new_doc)
        canonical_xml = etree.tostring(transformed, method="c14n").decode("utf-8")
        invoice_hash = b64encode(hashlib.sha256(canonical_xml.encode("utf-8")).digest()).decode()

        if is_simplified:
            # === توقيع الفاتورة المبسطة ===
            # استيراد دوال التوقيع من zatca_direct
            import types
            zd_path = os.path.join(request.folder, "controllers", "zatca_direct.py")
            with open(zd_path, "r", encoding="utf-8") as f:
                zd_code = f.read()
            zd = types.ModuleType("zd")
            zd.__dict__.update(globals())
            exec(compile(zd_code, zd_path, "exec"), zd.__dict__)

            cert_b64_clean, cert_der = zd._decode_bst(csr_config.ccsid_binarysecuritytoken)
            cert = zatca_libs.cx509.load_der_x509_certificate(cert_der, zatca_libs.default_backend())
            issuer_name = zd._get_issuer_name(cert)
            serial_number = cert.serial_number
            cert_hash_hex_b64 = zd._hash_hex_b64(cert_b64_clean.encode("utf-8"))
            signing_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

            signed_props_hash = zd._get_signed_properties_hash(signing_time, cert_hash_hex_b64, issuer_name, serial_number)
            signature_value = zd._get_digital_signature(invoice_hash, private_key)
            ecdsa_result = zd._get_public_key_and_signature(cert_b64_clean)

            with open(ubl_path, "r") as f:
                ubl_content = f.read()
            ubl_content = ubl_content.replace("INVOICE_HASH", invoice_hash)
            ubl_content = ubl_content.replace("SIGNED_PROPERTIES", signed_props_hash)
            ubl_content = ubl_content.replace("SIGNATURE_VALUE", signature_value)
            ubl_content = ubl_content.replace("CERTIFICATE_CONTENT", cert_b64_clean)
            ubl_content = ubl_content.replace("SIGNATURE_TIMESTAMP", signing_time)
            ubl_content = ubl_content.replace("PUBLICKEY_HASHING", cert_hash_hex_b64)
            ubl_content = ubl_content.replace("ISSUER_NAME", issuer_name)
            ubl_content = ubl_content.replace("SERIAL_NUMBER", str(serial_number))

            ins_pos = canonical_xml.find(">") + 1
            updated_xml = canonical_xml[:ins_pos] + ubl_content + canonical_xml[ins_pos:]
            qr_b64 = zd._generate_qr(canonical_xml, invoice_hash, signature_value, ecdsa_result)
            with open(sig_path, "r") as f:
                sig_content = f.read().replace("BASE64_QRCODE", qr_b64)
            ins_sig = updated_xml.find("<cac:AccountingSupplierParty>")
            if ins_sig != -1:
                updated_xml = updated_xml[:ins_sig] + sig_content + updated_xml[ins_sig:]

            final_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + updated_xml
            invoice_b64 = b64encode(final_xml.encode("utf-8")).decode("utf-8")
        else:
            # === فاتورة قياسية: بدون توقيع محلي ===
            final_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + canonical_xml
            invoice_b64 = b64encode(final_xml.encode("utf-8")).decode("utf-8")

        # إرسال لفحص الامتثال
        payload = json.dumps({"invoiceHash": invoice_hash, "uuid": new_root.find(".//cbc:UUID", namespaces=new_ns).text, "invoice": invoice_b64})
        resp = zatca_libs.requests_lib.post(
            compliance_checks_url,
            headers={"accept": "application/json", "accept-language": "en", "Accept-Version": "V2", "Content-Type": "application/json"},
            data=payload,
            auth=zatca_libs.HTTPBasicAuth(csr_config.ccsid_binarysecuritytoken, csr_config.ccsid_secret),
            timeout=60
        )

        resp_data = resp.json() if resp.status_code in (200, 202, 400) else {"error": resp.text}
        status = resp_data.get("reportingStatus") if is_simplified else resp_data.get("clearanceStatus")
        success = status and ("REPORTED" in status or "CLEARED" in status)

        if success:
            pih = invoice_hash

        results.append({
            "type": prefix, "desc": desc, "status": status or "FAILED",
            "success": success, "http": resp.status_code,
            "validation": resp_data.get("validationResults", {}).get("status", ""),
            "errors": [m["message"] for m in resp_data.get("validationResults", {}).get("errorMessages", [])],
            "warnings": [m["message"] for m in resp_data.get("validationResults", {}).get("warningMessages", [])],
        })

        if not success:
            return ({"err": 9, "mess": f"فشل {desc}", "results": results, "last_response": resp_data})

    return {"err": 0, "mess": "نجحت جميع الفواتير التجريبية الست!", "results": results}


## ===================== الخطوة 2 (endpoint) =====================

@can_access(6001)
def step2_compliance_checks():
    try:
        return response.json(_do_step2())
    except Exception as e:
        import traceback; db.rollback()
        return response.json({"err": 3, "mess": str(e), "trace": traceback.format_exc()})


## ===================== الخطوة 3 =====================

def _do_step3():
    """الخطوة 3 - منطق داخلي"""
    csr_config = db(db.csr_config.id > 0).select().first()
    if not csr_config or not csr_config.ccsid_requestid:
        return {"err": 1, "mess": "يجب تنفيذ الخطوة 1 أولاً"}
    env = (csr_config.environment or "simulation").lower()
    api_p = _api_path(env)
    resp = zatca_libs.requests_lib.post(
        f"{ZATCA_BASE}/{api_p}/production/csids",
        headers={"accept": "application/json", "accept-language": "en", "Accept-Version": "V2", "Content-Type": "application/json"},
        data=json.dumps({"compliance_request_id": csr_config.ccsid_requestid}),
        auth=zatca_libs.HTTPBasicAuth(csr_config.ccsid_binarysecuritytoken, csr_config.ccsid_secret),
        timeout=60
    )
    if resp.status_code != 200:
        return {"err": 2, "mess": f"ZATCA رفض: {resp.status_code}", "detail": resp.text}
    pcsid = resp.json()
    if not pcsid.get("requestID"):
        return {"err": 2, "mess": "لا يوجد requestID", "detail": pcsid}
    csr_config.update_record(
        pcsid_requestid=pcsid.get("requestID"),
        pcsid_binarysecuritytoken=pcsid.get("binarySecurityToken"),
        pcsid_secret=pcsid.get("secret"),
        icv=0, pih=DEFAULT_PIH,
    )
    db.commit()
    return {"err": 0, "mess": "Production CSID تم بنجاح!", "requestID": pcsid.get("requestID")}


@can_access(6001)
def step3_production_csid():
    try:
        return response.json(_do_step3())
    except Exception as e:
        import traceback; db.rollback()
        return response.json({"err": 3, "mess": str(e), "trace": traceback.format_exc()})
