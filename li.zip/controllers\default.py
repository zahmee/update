# -*- coding: utf-8 -*-
# type: ignore
import httpx
import pathlib
from datetime import datetime

# ---- example index page ----
def index():
    # ck_row = db(db.public_msg.msg_id == 101).select()
    # .isempty() == True:
    # " http://aseerkayan.net/update/static/li.zip "
    # csr_config = db(db.csr_config.id>0).select().first()
    Headers = {}
    url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/li_ver.txt"
    resp = httpx.get(url, headers=Headers)
    site_ver = float(resp.text)
    app_path = pathlib.Path(__file__).resolve().parent.parent
    local_file = app_path / "li_ver.txt"
    stats = local_file.stat()
    modification_time = datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
    with open(local_file, "r") as f:
        local_ver = float(f.read())
    if site_ver > local_ver:
        redirect(URL("_t", "up"))
    # remote_ver = None
    # try:
    #     url = csr_config.api_site
    #     resp = httpx.get(url, headers=Headers )
    #     if resp.status_code == 200  :
    #         remote_ver = float(resp.json()["running_version"])
    # except Exception:
    #     remote_ver = 0
    ck_row = {}
    msg_id = 103
    if auth.is_logged_in():
        if db(db.public_msg.msg_id == msg_id).isempty() == True:
            db.public_msg.insert(
                msg_id=msg_id,
                msg_text="""
    النظام جاهز للربط ب هيئة الزكاة والضريبة والجمارك
                                """,
                msg_count=0,
                msg_max=20,
            )
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
        else:
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
            if ck_row.msg_count < ck_row.msg_max:
                ck_row.msg_count = 1 + ck_row.msg_count
                ck_row.update_record()
            else:
                ck_row.msg_text = ""
        db.commit()
    return dict(msg=ck_row, local_ver=local_ver,modification_time=modification_time )


def server_version():
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        Headers = {}
        url = csr_config.api_site + "/"
        resp = httpx.get(url, headers=Headers)
        # server_ver = float(resp.json()["running_version"])
        return response.json(resp.json())
    except Exception:
        return response.json({"running_version": 0})


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Embedded wiki (example) ----
def wiki():
    auth.wikimenu()  # add the wiki to the menu
    return auth.wiki()


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


# ---- action to server uploaded static content (required) ---


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


@auth.requires_login()
def my_documents():
    return dict()


@auth.requires_login()
def my_documents_list():
    rows = db(db.my_documents.created_by == auth.user.id).select(
        db.my_documents.id,
        db.my_documents.doc_type,
        db.my_documents.doc_description,
        db.my_documents.expiry_date,
        db.my_documents.notes,
        orderby=~db.my_documents.id,
    )
    return response.json(rows)


@auth.requires_login()
def my_documents_save():
    try:
        doc_id = request.vars.get("id")
        data = dict(
            doc_type=request.vars.doc_type,
            doc_description=request.vars.doc_description,
            expiry_date=request.vars.expiry_date or None,
            notes=request.vars.notes,
        )
        if doc_id:
            rec = db(
                (db.my_documents.id == doc_id)
                & (db.my_documents.created_by == auth.user.id)
            ).select().first()
            if not rec:
                return response.json({"err": 1, "mess": "غير مسموح"})
            rec.update_record(**data)
            db.commit()
            return response.json({"err": 0, "mess": "تم التعديل بنجاح", "id": int(doc_id)})
        else:
            new_id = db.my_documents.insert(**data)
            db.commit()
            return response.json({"err": 0, "mess": "تم الحفظ بنجاح", "id": int(new_id)})
    except Exception as e:
        db.rollback()
        return response.json({"err": 1, "mess": str(e)})


@auth.requires_login()
def my_documents_expiring():
    from datetime import timedelta
    today = datetime.now().date()
    limit_date = today + timedelta(days=35)
    rows = db(
        (db.my_documents.created_by == auth.user.id)
        & (db.my_documents.expiry_date != None)
        & (db.my_documents.expiry_date <= limit_date)
        & (db.my_documents.expiry_date >= today)
    ).select(
        db.my_documents.id,
        db.my_documents.doc_type,
        db.my_documents.expiry_date,
        orderby=db.my_documents.expiry_date,
    )
    result = []
    for r in rows:
        days_left = (r.expiry_date - today).days
        result.append(dict(
            id=r.id,
            doc_type=r.doc_type,
            expiry_date=str(r.expiry_date),
            days_left=days_left,
        ))
    return response.json(result)


@auth.requires_login()
def my_documents_delete():
    try:
        doc_id = request.args(0)
        if not doc_id:
            return response.json({"err": 1, "mess": "معرف غير صحيح"})
        deleted = db(
            (db.my_documents.id == doc_id)
            & (db.my_documents.created_by == auth.user.id)
        ).delete()
        db.commit()
        if deleted:
            return response.json({"err": 0, "mess": "تم الحذف بنجاح"})
        else:
            return response.json({"err": 1, "mess": "غير مسموح"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 1, "mess": str(e)})


def not_allow():
    return dict()


def about():
    return dict()


def history():
    return dict()
