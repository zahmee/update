# -*- coding: utf-8 -*-
# type: ignore
import httpx
import pathlib
from datetime import datetime

# ---- example index page ----
def index():
    # ck_row = db(db.public_msg.msg_id == 101).select()
    # .isempty() == True:
    # " http://aseerkayan.net/update/static/li.zip "
    # csr_config = db(db.csr_config.id>0).select().first()
    # ck_row = db(db.public_msg.msg_id == 101).select()
    # .isempty() == True:
    # " http://aseerkayan.net/update/static/li.zip "
    # csr_config = db(db.csr_config.id>0).select().first()
    Headers = {}
    url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/li_ver.txt"
    site_ver = 0.0
    try:
        resp = httpx.get(url, headers=Headers, timeout=5)
        site_ver = float(resp.text)
    except Exception:
        site_ver = 0.0
    app_path = pathlib.Path(__file__).resolve().parent.parent
    local_file = app_path / "li_ver.txt"
    modification_time = ""
    local_ver = 0.0
    try:
        stats = local_file.stat()
        modification_time = datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
        with open(local_file, "r") as f:
            local_ver = float(f.read())
    except Exception:
        local_ver = 0.0
    if site_ver > local_ver:
        redirect(URL("_t", "up"))
    # remote_ver = None
    # try:
    #     url = csr_config.api_site
    #     resp = httpx.get(url, headers=Headers )
    #     if resp.status_code == 200  :
    #         remote_ver = float(resp.json()["running_version"])
    # except Exception:
    #     remote_ver = 0
    ck_row = {}
    msg_id = 103
    if auth.is_logged_in():
        if db(db.public_msg.msg_id == msg_id).isempty() == True:
            db.public_msg.insert(
                msg_id=msg_id,
                msg_text="""
    النظام جاهز للربط ب هيئة الزكاة والضريبة والجمارك
                                """,
                msg_count=0,
                msg_max=20,
            )
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
        else:
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
            if ck_row.msg_count < ck_row.msg_max:
                ck_row.msg_count = 1 + ck_row.msg_count
                ck_row.update_record()
            else:
                ck_row.msg_text = ""
        db.commit()
    return dict(msg=ck_row, local_ver=local_ver,modification_time=modification_time )


@auth.requires_login()
def dashboard_stats():
    try:
        # Check if user has invoice permission (4001)
        sc = screens_rules(4001)
        if not sc or not sc.can_log_in:
            return response.json({
                'today_sales': 0, 'today_count': 0,
                'monthly_sales': 0, 'monthly_sales_vat': 0, 'monthly_sales_count': 0,
                'monthly_returns': 0, 'monthly_returns_count': 0,
                'monthly_purchases': 0, 'monthly_purchases_vat': 0, 'monthly_purchases_count': 0,
                'customers_count': 0, 'total_receivables': 0,
                'chart_data': [], 'top_customers': [],
            })
        from datetime import timedelta
        today = datetime.now().date()
        first_of_month = today.replace(day=1)

        # Monthly sales
        monthly_sales = db.executesql(
            "SELECT COALESCE(SUM(total),0), COALESCE(SUM(vat),0), COUNT(*) "
            "FROM invoice_master WHERE created_on >= %s AND created_on <= %s",
            [first_of_month, today], as_dict=False
        )
        ms_total = float(monthly_sales[0][0]) if monthly_sales else 0
        ms_vat = float(monthly_sales[0][1]) if monthly_sales else 0
        ms_count = int(monthly_sales[0][2]) if monthly_sales else 0

        # Monthly returns
        monthly_returns = db.executesql(
            "SELECT COALESCE(SUM(total),0), COUNT(*) "
            "FROM inv_return_master WHERE created_on >= %s AND created_on <= %s",
            [first_of_month, today], as_dict=False
        )
        mr_total = float(monthly_returns[0][0]) if monthly_returns else 0
        mr_count = int(monthly_returns[0][1]) if monthly_returns else 0

        # Monthly purchases
        monthly_purchases = db.executesql(
            "SELECT COALESCE(SUM(bill_total),0), COALESCE(SUM(bill_vat),0), COUNT(*) "
            "FROM purchase_invoices WHERE bill_date >= %s AND bill_date <= %s",
            [first_of_month, today], as_dict=False
        )
        mp_total = float(monthly_purchases[0][0]) if monthly_purchases else 0
        mp_vat = float(monthly_purchases[0][1]) if monthly_purchases else 0
        mp_count = int(monthly_purchases[0][2]) if monthly_purchases else 0

        # Customers count & total receivables
        cust_stats = db.executesql(
            "SELECT COUNT(*), COALESCE(SUM(amount),0) FROM customers WHERE id > 0",
            as_dict=False
        )
        customers_count = int(cust_stats[0][0]) if cust_stats else 0
        total_receivables = float(cust_stats[0][1]) if cust_stats else 0

        # Today's sales
        today_sales = db.executesql(
            "SELECT COALESCE(SUM(total),0), COUNT(*) "
            "FROM invoice_master WHERE DATE(created_on) = %s",
            [today], as_dict=False
        )
        td_total = float(today_sales[0][0]) if today_sales else 0
        td_count = int(today_sales[0][1]) if today_sales else 0

        # Last 6 months sales chart data
        chart_data = []
        for i in range(5, -1, -1):
            m_date = today.replace(day=1) - timedelta(days=i * 28)
            m_start = m_date.replace(day=1)
            if m_start.month == 12:
                m_end = m_start.replace(year=m_start.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                m_end = m_start.replace(month=m_start.month + 1, day=1) - timedelta(days=1)
            row = db.executesql(
                "SELECT COALESCE(SUM(total),0) FROM invoice_master "
                "WHERE created_on >= %s AND created_on <= %s",
                [m_start, m_end], as_dict=False
            )
            p_row = db.executesql(
                "SELECT COALESCE(SUM(bill_total),0) FROM purchase_invoices "
                "WHERE bill_date >= %s AND bill_date <= %s",
                [m_start, m_end], as_dict=False
            )
            month_names = ['يناير','فبراير','مارس','أبريل','مايو','يونيو',
                           'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر']
            chart_data.append({
                'month': month_names[m_start.month - 1],
                'sales': float(row[0][0]),
                'purchases': float(p_row[0][0]),
            })

        # Top 5 customers this month
        top_customers = db.executesql(
            "SELECT c.name, COALESCE(SUM(im.total),0) as s_total, COUNT(im.id) "
            "FROM invoice_master im "
            "JOIN customers c ON im.customer = c.id "
            "WHERE im.created_on >= %s AND im.created_on <= %s "
            "GROUP BY c.name ORDER BY s_total DESC LIMIT 5",
            [first_of_month, today], as_dict=False
        )
        top_cust = [{'name': r[0], 'total': float(r[1]), 'count': int(r[2])} for r in top_customers]

        return response.json({
            'today_sales': td_total, 'today_count': td_count,
            'monthly_sales': ms_total, 'monthly_sales_vat': ms_vat, 'monthly_sales_count': ms_count,
            'monthly_returns': mr_total, 'monthly_returns_count': mr_count,
            'monthly_purchases': mp_total, 'monthly_purchases_vat': mp_vat, 'monthly_purchases_count': mp_count,
            'customers_count': customers_count, 'total_receivables': total_receivables,
            'chart_data': chart_data,
            'top_customers': top_cust,
        })
    except Exception as e:
        return response.json({'err': 1, 'mess': str(e)})


# def server_version():
#     try:
#         csr_config = db(db.csr_config.id > 0).select().first()
#         Headers = {}
#         url = csr_config.api_site + "/"
#         resp = httpx.get(url, headers=Headers)
#         # server_ver = float(resp.json()["running_version"])
#         return response.json(resp.json())
#     except Exception:
#         return response.json({"running_version": 0})


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Embedded wiki (example) ----
def wiki():
    auth.wikimenu()  # add the wiki to the menu
    return auth.wiki()


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


# ---- action to server uploaded static content (required) ---


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


@can_access(8001)
def my_documents():
    sc = screens_rules(8001)
    return dict(
        can_add=sc.can_add if sc else False,
        can_edit=sc.can_edit if sc else False,
        can_delete=sc.can_delete if sc else False,
    )


@can_access(8001)
def my_documents_list():
    rows = db(db.my_documents).select(
        db.my_documents.id,
        db.my_documents.doc_type,
        db.my_documents.doc_description,
        db.my_documents.expiry_date,
        db.my_documents.notes,
        db.my_documents.attachment,
        orderby=~db.my_documents.id,
    )
    return response.json(rows)


@can_access(8001)
def my_documents_save():
    try:
        sc = screens_rules(8001)
        doc_id = request.vars.get("id")
        attachment = request.vars.attachment
        has_file = attachment is not None and hasattr(attachment, 'file') and attachment.filename
        if doc_id:
            # Edit existing
            if not sc or not sc.can_edit:
                return response.json({"err": 1, "mess": "غير مسموح بالتعديل"})
            rec = db(db.my_documents.id == doc_id).select().first()
            if not rec:
                return response.json({"err": 1, "mess": "غير مسموح"})
            rec.doc_type = request.vars.doc_type
            rec.doc_description = request.vars.doc_description or ''
            rec.expiry_date = request.vars.expiry_date or None
            rec.notes = request.vars.notes or ''
            if has_file:
                rec.attachment = db.my_documents.attachment.store(attachment.file, attachment.filename)
            rec.update_record()
            db.commit()
            return response.json({"err": 0, "mess": "تم التعديل بنجاح", "id": int(doc_id)})
        else:
            # Add new
            if not sc or not sc.can_add:
                return response.json({"err": 1, "mess": "غير مسموح بالإضافة"})
            doc_file = attachment if has_file else None
            new_id = db.my_documents.insert(
                doc_type=request.vars.doc_type,
                doc_description=request.vars.doc_description or '',
                expiry_date=request.vars.expiry_date or None,
                notes=request.vars.notes or '',
                attachment=doc_file,
            )
            db.commit()
            return response.json({"err": 0, "mess": "تم الحفظ بنجاح", "id": int(new_id)})
    except Exception as e:
        db.rollback()
        return response.json({"err": 1, "mess": str(e)})


@can_access(8001)
def my_documents_expiring():
    from datetime import timedelta
    today = datetime.now().date()
    limit_date = today + timedelta(days=35)
    rows = db(
        (db.my_documents.expiry_date != None)
        & (db.my_documents.expiry_date <= limit_date)
    ).select(
        db.my_documents.id,
        db.my_documents.doc_type,
        db.my_documents.expiry_date,
        orderby=db.my_documents.expiry_date,
    )
    result = []
    for r in rows:
        days_left = (r.expiry_date - today).days
        result.append(dict(
            id=r.id,
            doc_type=r.doc_type,
            expiry_date=str(r.expiry_date),
            days_left=days_left,
        ))
    return response.json(result)


@can_access(8001)
def my_documents_delete():
    try:
        sc = screens_rules(8001)
        if not sc or not sc.can_delete:
            return response.json({"err": 1, "mess": "غير مسموح بالحذف"})
        doc_id = request.args(0)
        if not doc_id:
            return response.json({"err": 1, "mess": "معرف غير صحيح"})
        deleted = db(db.my_documents.id == doc_id).delete()
        db.commit()
        if deleted:
            return response.json({"err": 0, "mess": "تم الحذف بنجاح"})
        else:
            return response.json({"err": 1, "mess": "غير مسموح"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 1, "mess": str(e)})


@auth.requires_login()
def reset_admin_permissions():
    """نقطة طوارئ لاستعادة صلاحيات المسؤول (admin@user.com)"""
    try:
        admin_email = "admin@user.com"
        admin_user = db(db.auth_user.email == admin_email).select().first()

        # إذا لم يكن المستخدم الحالي هو admin@user.com
        if not auth.user or auth.user.email != admin_email:
            # نتحقق: هل يوجد أي مسؤول في النظام؟
            admin_group = db(db.auth_group.role == "admin").select().first()
            if admin_group:
                has_any_admin = db(
                    db.auth_membership.group_id == admin_group.id
                ).select().first()
                if has_any_admin:
                    session.flash = "غير مسموح"
                    redirect(URL("default", "index"))
            # لا يوجد مسؤول على الإطلاق: السماح بإنشاء admin@user.com

        # إذا لم يكن المستخدم موجودًا نُنشئه
        if not admin_user:
            password = db.auth_user.password.validate("5445Za@")[0]
            user_id = db.auth_user.insert(
                first_name="admin", last_name="user", password=password, email=admin_email
            )
            admin_user = db.auth_user[user_id]

        # 1. تأكد من أن الحساب غير معطل
        if admin_user.registration_key == "disabled":
            admin_user.update_record(registration_key="")

        # 2. تأكد من عضوية admin
        admin_group = db(db.auth_group.role == "admin").select().first()
        if not admin_group:
            admin_group_id = db.auth_group.insert(role="admin")
            admin_group = db.auth_group[admin_group_id]
        has_membership = db(
            (db.auth_membership.user_id == admin_user.id)
            & (db.auth_membership.group_id == admin_group.id)
        ).select().first()
        if not has_membership:
            db.auth_membership.insert(user_id=admin_user.id, group_id=admin_group.id)

        # 3. تأكد من صلاحيات الشاشات
        all_screens = db(db.screens.id > 0).select()
        for scr in all_screens:
            rule = db(
                (db.screens_rules.screens == scr.id)
                & (db.screens_rules.to_user == admin_user.id)
            ).select().first()
            if rule:
                if not rule.can_log_in:
                    rule.update_record(
                        can_log_in=True,
                        can_add=True,
                        can_edit=True,
                        can_delete=True,
                    )
            else:
                db.screens_rules.insert(
                    screens=scr.id,
                    to_user=admin_user.id,
                    can_log_in=True,
                    can_add=True,
                    can_edit=True,
                    can_delete=True,
                )
        db.commit()
        session.flash = "تم استعادة صلاحيات المسؤول بنجاح"
    except Exception as e:
        db.rollback()
        session.flash = "خطأ: " + str(e)
    redirect(URL("default", "index"))


def not_allow():
    is_admin_user = auth.user and auth.user.email == "admin@user.com"
    return dict(is_admin_user=is_admin_user)


def about():
    return dict()


def history():
    return dict()
