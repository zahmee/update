(function($, undefined) {
  $.web2py.ajax_fields = function(target) {
    /*
     *this attaches something to a newly loaded fragment/page
     * Ideally all events should be bound to the document, so we can avoid calling
     * this over and over... all will be bound to the document
     */
    /*adds btn class to buttons*/
    $('button:not([class^="btn"])', target).addClass('btn btn-default');
    $("p.w2p-autocomplete-widget input").addClass('form-control');
    $('form input[type="submit"]:not([class^="btn"]), form input[type="button"]:not([class^="btn"])', target).addClass('btn btn-default');
    /* javascript for PasswordWidget*/
    $('input[type=password][data-w2p_entropy]', target).each(function() {
      $.web2py.validate_entropy($(this));
    });
    /* javascript for ListWidget*/
    $('ul.w2p_list', target).each(function() {
      function pe(ul, e) {
        var new_line = ml(ul);
        rel(ul);
        if ($(e.target).closest('li').is(':visible')) {
          /* make sure we didn't delete the element before we insert after */
          new_line.insertAfter($(e.target).closest('li'));
        } else {
          /* the line we clicked on was deleted, just add to end of list */
          new_line.appendTo(ul);
        }
        new_line.find(":text").focus();
        return false;
      }

      function rl(ul, e) {
        if ($(ul).find('li').length > 1) {
          /* only remove if we have more than 1 item so the list is never empty */
          $(e.target).closest('li').remove();
        }
      }

      function ml(ul) {
        /* clone the first field */
        var line = $(ul).find("li:first").clone(true);
        line.find(':text').val('');
        return line;
      }

      function rel(ul) {
        /* keep only as many as needed*/
        $(ul).find("li").each(function() {
          var trimmed = $.trim($(this).find(":text").val());
          if (trimmed == '') $(this).remove();
          else $(this).find(":text").val(trimmed);
        });
      }
      var ul = this;
      $(ul).find(":text").addClass('form-control').wrap("<div class='input-group'></div>").after('<div class="input-group-append"><i class="fas fa-plus-circle"></i></div>&nbsp;<div class="input-group-append"><i class="far fa-minus-circle"></i></div>').keypress(function(e) {
        return (e.which == 13) ? pe(ul, e) : true;
      }).next().click(function(e) {
        pe(ul, e);
        e.preventDefault();
      }).next().click(function(e) {
        rl(ul, e);
        e.preventDefault();
      });
    });

        $(".icon-plus").removeClass("icon plus icon-plus glyphicon glyphicon-plus").addClass("fas fa-plus");
      $(".icon-zoom-in").removeClass("icon magnifier icon-zoom-in glyphicon glyphicon-zoom-in").addClass("far fa-search");
      $(".glyphicon-pencil").removeClass("icon pen icon-pencil glyphicon glyphicon-pencil").addClass("fas fa-pencil-alt");
      $(".glyphicon-pencil").removeClass("icon pen icon-pencil glyphicon glyphicon-pencil").addClass("fas fa-pencil-alt");
      $(".glyphicon-trash").removeClass("icon trash icon-trash glyphicon glyphicon-trash").addClass("fas fa-trash-alt");
      $(".glyphicon-arrow-left").removeClass("icon arrowleft icon-arrow-left glyphicon glyphicon-arrow-left").addClass("far fa-arrow-alt-left");


  }

  $(function() {
    $(".nav ul.dropdown-menu").each(function() {
      var toggle = jQuery(this).parent();
      if (toggle.parent().hasClass("nav")) {
        toggle.attr("data-w2pmenulevel", "l0");
        toggle.children("a")
          .addClass("dropdown-toggle")
          .append('<span class="caret"> </span>')
          .attr("data-toggle", "dropdown");
      } else {
        toggle.addClass("dropdown-submenu").removeClass("dropdown");
      };
    });
  });

})(jQuery);