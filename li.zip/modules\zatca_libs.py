"""
وسيط لاستيراد المكتبات الخارجية بتجاوز web2py custom importer
"""
import sys
import os
import builtins
import importlib

_web2py_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
_venv_sp = os.path.join(_web2py_dir, "venv", "Lib", "site-packages")
_bad_sp = os.path.join(_web2py_dir, "site-packages")
if _bad_sp in sys.path:
    sys.path.remove(_bad_sp)
if os.path.isdir(_venv_sp) and _venv_sp not in sys.path:
    sys.path.insert(0, _venv_sp)

_custom = builtins.__import__
builtins.__import__ = importlib.__import__
try:
    from lxml import etree
    from cryptography import x509 as cx509
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, load_pem_private_key
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import hashes
    from OpenSSL import crypto as openssl_crypto
    import requests as requests_lib
    from requests.auth import HTTPBasicAuth
finally:
    builtins.__import__ = _custom
