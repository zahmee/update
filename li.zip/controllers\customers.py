# -*- coding: utf-8 -*-
# type: ignore
# @auth.requires_membership("user1")
@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


@auth.requires_membership("user1")
def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(1002)
def purchase():
    customer_id = request.args(0)
    customer = db.customers[customer_id]
    return dict(
        customer_id=customer_id,
        customer_name=customer.name if customer else "",
    )


@auth.requires_login()
def purchase_list():
    customer_id = request.args(0)
    if not customer_id:
        return response.json({"data": [], "count": 0, "total_purchase": 0})
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    where = f" WHERE im.customer = {int(customer_id)} "
    if search.strip():
        where += (
            f" AND (CAST(im.id AS TEXT) LIKE '%{search}%'"
            f" OR kpm.name LIKE '%{search}%'"
            f" OR CAST(im.total_after_discount AS TEXT) LIKE '%{search}%') "
        )
    offset = pg * rc
    sql = (
        f"SELECT im.id, kpm.name as payment_method, im.total_after_discount, im.vat, im.created_on"
        f" FROM invoice_master im"
        f" LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method"
        f" {where} ORDER BY im.id DESC LIMIT {rc} OFFSET {offset}"
    )
    sql_count = (
        f"SELECT COUNT(*) FROM invoice_master im"
        f" LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method"
        f" {where}"
    )
    sql_total = f"SELECT COALESCE(SUM(total_after_discount), 0) FROM invoice_master WHERE customer = {int(customer_id)}"
    rows = db.executesql(sql, as_dict=True)
    count = db.executesql(sql_count)[0][0]
    total_purchase = db.executesql(sql_total)[0][0]
    return response.json({"data": rows, "count": count, "total_purchase": round(float(total_purchase), 2)})


@can_access(1003)
def customers_pay():
    sc = screens_rules(1003)
    customer_id = request.args(0)
    customer = db.customers[customer_id]
    return dict(
        customer_id=customer_id,
        customer_name=customer.name if customer else "",
        can_add=sc.can_add,
        can_edit=sc.can_edit,
        can_delete=sc.can_delete,
    )


@auth.requires_login()
def customers_pay_list():
    customer_id = request.args(0)
    if not customer_id:
        return response.json({"data": [], "count": 0, "total_paid": 0})
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    search = ReqVar.SearchText or ""
    where = f" WHERE customers_id = {int(customer_id)} "
    if search.strip():
        where += f" AND (CAST(id AS TEXT) LIKE '%{search}%' OR note LIKE '%{search}%' OR CAST(amount AS TEXT) LIKE '%{search}%') "
    offset = pg * rc
    sql = f"SELECT id, amount, note, created_on FROM customers_pay {where} ORDER BY id DESC LIMIT {rc} OFFSET {offset}"
    sql_count = f"SELECT COUNT(*) FROM customers_pay {where}"
    sql_total = f"SELECT COALESCE(SUM(amount), 0) FROM customers_pay WHERE customers_id = {int(customer_id)}"
    rows = db.executesql(sql, as_dict=True)
    count = db.executesql(sql_count)[0][0]
    total_paid = db.executesql(sql_total)[0][0]
    return response.json({"data": rows, "count": count, "total_paid": round(float(total_paid), 2)})


@auth.requires_login()
def customers_pay_save():
    try:
        customer_id = request.args(0)
        data = request.vars
        pay_id = data.get("id")
        if pay_id:
            rec = db.customers_pay[pay_id]
            if not rec or str(rec.customers_id) != str(customer_id):
                return response.json({"err": 1, "mess": "غير مسموح"})
            rec.update_record(
                amount=data.amount,
                note=data.note,
            )
            db.commit()
            return response.json({"err": 0, "mess": "تم التعديل بنجاح", "id": int(pay_id)})
        else:
            from datetime import datetime as dt
            new_id = db.customers_pay.insert(
                customers_id=customer_id,
                amount=data.amount,
                note=data.note,
                customers_pay_data=dt.now().strftime("%Y-%m-%d"),
            )
            db.commit()
            return response.json({"err": 0, "mess": "تم الحفظ بنجاح", "id": int(new_id)})
    except Exception as e:
        db.rollback()
        return response.json({"err": 1, "mess": str(e)})


@auth.requires_login()
def customers_pay_delete():
    try:
        customer_id = request.args(0)
        pay_id = request.args(1)
        if not pay_id:
            return response.json({"err": 1, "mess": "معرف غير صحيح"})
        rec = db.customers_pay[pay_id]
        if not rec or str(rec.customers_id) != str(customer_id):
            return response.json({"err": 1, "mess": "غير مسموح"})
        db(db.customers_pay.id == pay_id).delete()
        db.commit()
        return response.json({"err": 0, "mess": "تم الحذف بنجاح"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 1, "mess": str(e)})


@can_access(1004)
def customers_pay_all():
    sc = screens_rules(1004)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    q = db.customers_pay  # .customers_id == request.args(0)
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=can_edit,
        deletable=can_delete,
        create=can_add,
        csv=False,
        searchable=True,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("user1")
def customers_accounts_settlement():
    return dict()


@auth.requires_membership("user1")
def accounts_settlement():
    ts = db(db.customers_accounts_settlement.customers_id == request.args(0)).select()
    if ts:
        sd = ts.last().settlement_data
        qry = (
            "select sum(total_after_discount) from invoice_master where customer=%s"
            " and payment_method=3 and created_on>=%s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0), str(sd)])
        mm1 = qs[0][0]
        mm1 = (mm1) and mm1 or 0
        qry = (
            "select sum(amount) from customers_pay where customers_id=%s"
            " and created_on>=%s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0), str(sd)])
        mm2 = qs[0][0]
        mm2 = (mm2) and mm2 or 0
        if (int(mm1) == int(mm2)) and (int(mm1) == int(mm2) != 0):
            db.customers_accounts_settlement.insert(customers_id=request.args(0))
        return redirect(URL("customers", "index"))
    else:
        qry = (
            "select sum(total_after_discount) from invoice_master where payment_method=3 and customer=%s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0)])
        m1 = qs[0][0]
        qry = (
            "select sum(amount) from customers_pay where customers_id=%s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0)])
        m2 = qs[0][0]
        if int(m1) == int(m2) and (int(m1) == int(m2) != 0):
            db.customers_accounts_settlement.insert(customers_id=request.args(0))
        return redirect(URL("customers", "index"))


def customers_accounts_calc():
    cid = request.args(0)
    qry = (
        "update customers set total = (select round( CAST(COALESCE(sum(total_after_discount) ,0) as numeric) ,2) from invoice_master "
        " where payment_method=3 and customer=%s) ,  "
        " payed=( select round( CAST( COALESCE(sum(amount),0) as numeric) ,2) from customers_pay where customers_id=%s) , "
        " returns = (select round( CAST(COALESCE(sum(total_after_discount),0) as numeric) ,2) from inv_return_master where payment_method=3 and customer=%s) , "
        " amount = round( CAST((select COALESCE(sum(total_after_discount),0) from invoice_master where payment_method=3 and customer=%s) "
        " - ( select COALESCE(sum(amount),0) from customers_pay where customers_id=%s) "
        " - (select COALESCE(sum(total_after_discount),0) from inv_return_master where payment_method=3 and customer=%s) as numeric) ,2)  "
        " where id = %s"
    )
    db.executesql(qry, placeholders=[cid, cid, cid, cid, cid, cid, cid])
    return redirect(URL("customers", "index"))


## ========================= Ver 4.0 ==============================
# ===================================================================


def customer_status_rep():
    return dict()


def pay_print():
    return dict()
