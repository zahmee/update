# coding: utf8
# type: ignore
import os
import zipfile
import urllib.request
from datetime import datetime


def fix():
    qry = "PGPASSWORD='5445za' psql -h localhost -U admin -d pha -c \" GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to admin ; \" "
    s = os.popen(qry)
    preprocessed = s.read()
    s.close()
    return preprocessed


def db():
    _appPath = request.folder
    backupdir = _appPath + "/static/db.tar"
    configuration = AppConfig(reload=True)
    dbname = configuration.get("db.uri").split("/")
    script = (
        "PGPASSWORD='5445za' pg_dump -h localhost -U admin -F t "
        + dbname[-1]
        + " >  %s" % (backupdir)
    )
    s = os.popen(script)
    preprocessed = s.read()
    s.close()
    return redirect(URL("static", "db.tar"))


def _get_local_version():
    ver_file = os.path.join(request.folder, "li_ver.txt")
    if os.path.exists(ver_file):
        stats = os.stat(ver_file)
        mod_time = datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
        with open(ver_file, "r") as f:
            ver = f.read().strip()
        return ver, mod_time
    return "0", ""


def _get_remote_version():
    url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/li_ver.txt"
    req = urllib.request.urlopen(url, timeout=10)
    return req.read().decode().strip()


def up():
    local_ver, local_mod_time = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception:
        remote_ver = None

    return dict(
        local_ver=local_ver,
        local_mod_time=local_mod_time,
        remote_ver=remote_ver,
        updated=False,
        error=None,
    )


def up_do():
    github_url = "https://github.com/zahmee/update/raw/refs/heads/main/li.zip"
    app_path = request.folder
    zip_path = os.path.join(app_path, "li.zip")
    try:
        local_ver_before, _ = _get_local_version()

        urllib.request.urlretrieve(github_url, zip_path)

        file_count = 0
        with zipfile.ZipFile(zip_path, "r") as zf:
            file_count = len(zf.namelist())
            zf.extractall(app_path)

        if os.path.exists(zip_path):
            os.remove(zip_path)

        local_ver_after, local_mod_time = _get_local_version()

        return response.json(dict(
            err=0,
            mess="تمت عملية التحديث بنجاح",
            ver_before=local_ver_before,
            ver_after=local_ver_after,
            mod_time=local_mod_time,
            file_count=file_count,
        ))
    except Exception as e:
        if os.path.exists(zip_path):
            os.remove(zip_path)
        return response.json(dict(err=1, mess=str(e)))
