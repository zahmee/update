var obj  ;
var vat = 0.0 ;
var items =[] ;
var item ={} ;
$(document).ready(function() {
        $("#itid").focus()
});
function do1(){
     $.getJSON(purl+"/../getco/"+$("#cid").val() , function(data) {
     output=data[0].name  ;
     $("#con").html(output);
    });
}
function do2(){
    var textentr = $("#itid").val().replace(/[+]/g,'') ;
    var s = textentr.search("-") ; //$("#itid").val().search("-") ;
    $("#itid").attr('disabled', 'disabled');
    if  (s > 0)
    {
        id = $("#itid").val().substr($("#itid").val().search("-")+1,$("#itid").val().length)  ;
        to = $("#itid").val().substr(0,s ) ;
        $("#itcount").text(to) ;
        $("#itid").val(id) ;
        getitdata(id,to) ;
    }
    else{
        getitdata($("#itid").val(),1) ;
    }
    $("#itid").removeAttr('disabled');

}
function getitdata(itid,to){
    var id = itid ;
    $.getJSON(purl+"/../getit?itid="+itid , function(data) {
        if (data.length >0 ){
            if (!data[0].vat){
                data[0].vat  =0.0 ;
            }
            item = data[0] ;
            if (Date.parse(data[0].expiration_date)<Date.now() ){
                //sweetAlert("تاريخ الصلاحية منته") ;
                //alert('تاريخ الصلاحية منتهي ') ;
                swal({
                    title: "هذا الصنف منتهي الصلاحية. هل ترغب إضافته ؟",
                    text: "سوف يتم إضافته في الفاتورة في حالة الموافقة",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "نعم",
                    cancelButtonText: "لا",
                    closeOnConfirm: true,
                    closeOnCancel: true },
                    function(){
                                            $("#itid").val(id) ;
                                            $("#itname").html(data[0].name+' - '+ data[0].vat +"<span class='label label-danger pull-left' >  "+data[0].expiration_date+"</span>");
                                            $("#itprice").html(data[0].public_price);
                                            tomo = parseFloat(to) * (data[0].public_price).toFixed(2)  ;
                                            // vat1 = data[0].vat * tomo ;
                                            // vat = vat + vat1 ;
                                            $("#total1").html(tomo.toFixed(2));
                                            add(1) ;
                                            return false ;
                                      });

                $("#itid").val("") ;
            }
            else if (Date.parse(data[0].expiration_date)<Date.now()+7884000000)
            {
                 $("#itname").html(data[0].name+' - '+ data[0].vat +"<span class='label label-danger pull-left' >  "+data[0].expiration_date+"</span>");
                 $("#itprice").html(data[0].public_price);
                 tomo = parseFloat(to) * (data[0].public_price).toFixed(2)  ;
                 // vat1 = data[0].vat * tomo ;
                 // vat = vat + vat1 ;
                 $("#total1").html(tomo.toFixed(2));
                 add(1) ;
            }
            else
            {
                 $("#itname").html( data[0].name+' - '+ data[0].vat );
                 $("#itprice").html(data[0].public_price);
                 tomo = parseFloat(to) * (data[0].public_price).toFixed(2)  ;
                 // vat1 = data[0].vat * tomo ;
                 // vat = vat + vat1 ;
                 $("#total1").html(tomo.toFixed(2));
                 add(0) ;
            }
            /*  
            if (data[0].vat>0){
            tomo = parseFloat(to) * (data[0].public_price).toFixed(2)  ;
            vat1 = data[0].vat * tomo ;
            vat = vat + vat1 ;
            */
            //$("#vat").html(vat) ;

        //}
        //total = parseFloat($("#total1").text()) ;


        }
        else {
            swal("لم يتم العثور على الصنف المدخل الرجاء التأكد من قيمة الإدخال .") ;
            $("#itid").val("") ;
            $("#itcount").text("1") ;
        }
    });
}
function add(type){
    var gid= generateQuickGuid();
    var st = "style='background-color: rgb(235, 163, 163); '"
    if (type== 0 ) st = "" ;
    var ms = [
      "<tr id='"+gid+"' "+st+" class='items'  >",
      "<td >"+$("#itid").val().replace(/[+]/g,'')+"</td>",
      "<td >"+$("#itname").html()+"</td> " ,
      "<td >"+$("#itprice").text()+"</td>" ,
      "<td >"+$("#itcount").text()+"</td>",
      "<td >"+$("#total1").text()+"</td>",
      "<td > <span class='badge btn-danger' onclick=del('"+gid+"')  >حذف الصنف</span> </td>",
      "</tr>"].join("\n");
    total += parseFloat($("#total1").text()) ;
    item['gid'] = gid ;
    item['count'] = $("#itcount").text() ;
    item['total'] = $("#total1").text() ;
    item['id'] = $("#itid").val().replace(/[+]/g,'') ;

    items.push(item) ;
    $('#mr').before(ms) ;
    $("#itcount").text("1") ;
    $("#itname").html("");
    $("#itprice").html("");
    $("#total1").html("");
    //$("#total2").text(total.toFixed(2)) ;
    $("#itid").val("") ;
    //$("#hlal").text((Math.floor(total+1)-total.toFixed(2)).toFixed(2)) ;
    //$("#total_after_vat").text(vat+total) ;
    get_total()  ;

}
function clear(){
    $("#itcount").text("1") ;
    $("#itname").html("");
    $("#itprice").html("");
    $("#total1").html("");
    $("#itid").val("") ;
}

function del(rown){
    rindex = -1 ;
    total -= parseFloat($('#'+rown).children(':nth(4)').text()) ;
    $("#total2").text(total.toFixed(2)) ;
    $("#hlal").text((Math.floor(total+1)-total.toFixed(2)).toFixed(2)) ;
    $('#'+rown).remove() ;
    items.forEach(function(element,index) {
        if ( element.gid === rown )
            rindex = index ;
    });
    console.log(rindex);
    items.splice(rindex, 1) ;
    get_total()  ;

}

function get_total(){
    total_vat = 0.0 ;
    total_net = 0.0 ;
    items.forEach(function(el) {
        total_vat = ( el.count * el.public_price * el.vat ) + total_vat ;
        total_net = ( el.count * el.public_price  ) + total_net ;
    });
    $("#total2").text(total_net.toFixed(2)) ;
    $("#total_after_vat").text((total_net+total_vat).toFixed(2)) ;
    $("#vat").text(total_vat.toFixed(2)) ;
    return ;
}
 function createGuid()
{
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });
}
function generateQuickGuid() {
    return Math.random().toString(36).substring(2, 15) +
        Math.random().toString(36).substring(2, 15);
}
function save(){
    $("#btn_save").remove() ;
    var itm = '{ "itm" : ['  ;
      $(".items").each(function() {
            var cou = 0 ;
            $(this).children(':eq(0),:eq(3)').each(function() {
                if (cou== 0)
                    itm += ' { "id":"'+$(this).text()+'" , ' ;
                else if (cou==1)
                    itm += '"count":"'+$(this).text()+'" } ,' ;
                cou++ ;
            });
      });
      itm = itm.substring(0, itm.length -1) ;
      itm += ']'
      itm += ',"total":"'+$("#total2").text()+'"' ;
      itm += ',"cost":"'+$("#cid").val()+'"' ;
      itm += ',"method":"'+$("#method").val()+'"' ;
      itm += ',"Guid":"'+ generateQuickGuid() +'"' ;
      itm += '}' ;

      //console.log( itm );

      obj = eval ("(" + itm + ")");

      $.getJSON(purl+"/../save?itm="+itm , function(data) {
        if (data.err==1){
                //$('#page-wrap').css('width','230px') ;
                //$('#page-wrap').css('font-size','12px') ;

                console.log(data) ;
                $(".badge btn-danger").remove() ;
                $(".blank").remove() ;
                $("#hlal").remove() ;
                $("#itid").remove() ;
                $("#hiderow").remove() ;
                $("#cid").remove() ;
                $("#method").remove() ;

                $('#items tr').each(function(row, tr){
                    $(tr).find('td:eq(5)').remove() ;
                    $(tr).find('th:eq(5)').remove() ;
                });

                var D = new Date();
                var hours = D.getHours();
                var minutes = D.getMinutes();
                var seconds = D.getSeconds();
                var time = hours + ":" + minutes + ":" + seconds;

                $('#pr').css('font-size','12px') ;
                //$('#pr').css('width','220px') ;
                $('#pr').css('font-family','tahoma') ;


                $('#items').css('font-size','12px') ;
                $('#items').before("<p style='font-size:20px'>*   صيدلية اسباب الشفاء الدوائية   *</p>") ;
                $('#items').before("<p style='font-size:14px'>  الرقم الضريبي : 310086115200003   </p>") ;
                $('#items').before("<p> اسم العميل : "+$("#con").text()+"</p>") ;
                $('#items').before("<p>رقم الفاتورة : "+data.invno+" </p>") ;
                $('#items').before("<p>التاريخ :"+$("#dateid").text()+" </p>") ;
                $('#items').before("<p>الوقت :"+time+" </p>") ;
                $('#usern').after("<br/>") ;
                $('#usern').after("--------------------------------") ;
                $('#usern').after("================================") ;
                //setTimeout(function(){alert("hi")}, 1000);
                print(reload) ;

                //alert('تمت عملية حفظ الفاتورة بشكل صحيح');
                //location.reload();
            }
        else if (data==2)
            console.log(data) ;
        else if (data==3)
            console.log(data) ;
        else
            console.log(data) ;

      }) ;
    // var pets = '{"pets":[{"name":"jack"},{"name":"john"},{"name":"joe"}]}';
    // var arr = JSON.parse(pets);
    // alert(arr.pets[0].name);

    //window.print();
}



function print(callback){


        $('#pr').printThis({
          debug: false,
          importCSS: true,
          printContainer: true,
          pageTitle: "الفاتورة",
          removeInline: false
        });
        if(typeof callback == 'function')
                callback();



}

function reload(){
     setTimeout('location.reload();', 1000);
}



//   البحث عن عميل
function showDialog2()  {
    $('#item_found2').html('') ;
    $('#search_item_input2').val('') ;
    $("#dialog-form_c").dialog({
        width: 400,
        height: 400,
        modal: true,
        draggable: false,
        resizable: false,
        dialogClass: 'ui-dialog-osx',
        open: true ,
        buttons: {
       "اغلاق البحث": function() {

           $(this).dialog("close");
       }}
    });
}

function search_c(){
    $('#item_found2').html('') ;
    if ($('#search_item_input2').val().length>1)  {
    $.getJSON(purl+"/../search_c?itid="+$('#search_item_input2').val() , function(data) {
        if (data.length >0 ){
            $(data).each(function() {
                //console.log(this) ;
                $('#item_found2').append( "<button type='button'  style='text-align: right;' onclick=addc("+this.id+") ; class='btn btn-info btn-block  '>"+this.name+"</button>" );
            }) ;
        }
    });
    }
}


function addc(str_id){
    $("#cid").val(str_id) ;
    do1()  ;
}
