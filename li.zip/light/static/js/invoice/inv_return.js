var obj  ;

$(document).ready(function() {
});
function do1(){
	 $.getJSON(purl+"/../getco/"+$("#cid").val() , function(data) {
     output=data[0].name  ;
     $("#con").html(output);
    });
}
function do2(){
	var s = $("#itid").val().search("-") ;
	$("#itid").attr('disabled', 'disabled');
	if  (s > 0)
	{
		id = $("#itid").val().substr($("#itid").val().search("-")+1,$("#itid").val().length)  ;
		to = $("#itid").val().substr(0,s ) ;
		$("#itcount").text(to) ;
		$("#itid").val(id) ;
		getitdata(id,to) ;
	}
	else{
		getitdata($("#itid").val(),1) ;
	}
	$("#itid").removeAttr('disabled');

}
function getitdata(itid,to){
	$.getJSON(purl+"/../getit?itid="+itid , function(data) {
		if (data.length >0 ){			
			if (Date.parse(data[0].expiration_date)<Date.now() ){
				alert('تاريخ الصلاحية منتهي ') ;
				$("#itid").val("") ;
			}
			else if (Date.parse(data[0].expiration_date)<Date.now()+7884000000)
			{
				 $("#itname").html(data[0].name +"<span class='label label-danger pull-left' >  "+data[0].expiration_date+"</span>");
				 $("#itprice").html(data[0].public_price);
				 tomo = parseFloat(to) * (data[0].public_price).toFixed(2)  ;
				 $("#total1").html(tomo.toFixed(2));		 
				 add(1) ;
			}
			else
			{
				 $("#itname").html(data[0].name );
				 $("#itprice").html(data[0].public_price);
				 tomo = parseFloat(to) * (data[0].public_price).toFixed(2)  ;
				 $("#total1").html(tomo.toFixed(2));		 
				 add(0) ;
			}				 
		}
		else {
			alert("لم يتم العثور على الصنف المدخل الرجاء التأكد من قيمة الإدخال .") ;
			$("#itid").val("") ;
		}		 
	});	
}
function add(type){
	var gid= generateQuickGuid();
	var st = "style='background-color: rgb(235, 163, 163); '"
	if (type== 0 ) st = "" ;
	var ms = [
	  "<tr id='"+gid+"' "+st+" class='items'  >",
	  "<td >"+$("#itid").val()+"</td>",
	  "<td >"+$("#itname").html()+"</td> " ,
	  "<td >"+$("#itprice").text()+"</td>" ,
	  "<td >"+$("#itcount").text()+"</td>",
	  "<td >"+$("#total1").text()+"</td>",
	  "<td > <span class='badge btn-danger' onclick=del('"+gid+"')  >حذف الصنف</span> </td>",
	  "</tr>"].join("\n");
	total += parseFloat($("#total1").text()) ;
	$('#mr').before(ms) ;
	$("#itcount").text("1") ;
	$("#itname").html("");
	$("#itprice").html("");
	$("#total1").html("");	
	$("#total2").text(total.toFixed(2)) ;
	$("#itid").val("") ;
	$("#hlal").text((Math.floor(total+1)-total.toFixed(2)).toFixed(2)) ;
}
function clear(){
	$("#itcount").text("1") ;
	$("#itname").html("");
	$("#itprice").html("");
	$("#total1").html("");	
	$("#itid").val("") ;
}
function del(rown){
	total -= parseFloat($('#'+rown).children(':nth(4)').text()) ;
	$("#total2").text(total.toFixed(2)) ;
	$("#hlal").text((Math.floor(total+1)-total.toFixed(2)).toFixed(2)) ;
	$('#'+rown).remove() ;
}
 function createGuid()
{
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
		return v.toString(16);
	});
}
function generateQuickGuid() {
    return Math.random().toString(36).substring(2, 15) +
        Math.random().toString(36).substring(2, 15);
}
function save(){

	var itm = '{"itm":['; 
	  $(".items").each(function() {
			var cou = 0 ;
			$(this).children(':eq(0),:eq(3)').each(function() {
				if (cou== 0)
					itm += '{"id":"'+$(this).text()+'",' ;
				else if (cou==1)
					itm += '"count":"'+$(this).text()+'"},' ;
				cou++ ;
			});
      });
	  itm = itm.substring(0, itm.length -1) ;
	  itm += ']'
	  itm += ',"total":"'+$("#total2").text()+'"' ;
	  itm += ',"cost":"'+$("#cid").val()+'"' ;
	  itm += ',"method":"1"' ;
	  itm += ',"Guid":"'+ generateQuickGuid() +'"' ;	  
	  itm += '}' ;
	  
	  //console.log( itm );
	  
	  obj = eval ("(" + itm + ")");
	  
	  $.getJSON(purl+"/../saver?itm="+itm , function(data) {
		if (data.err==1){
				//$('#page-wrap').css('width','230px') ;
				//$('#page-wrap').css('font-size','12px') ;
				
				console.log(data) ;
				$(".badge btn-danger").remove() ;
				$(".blank").remove() ;
				$("#hlal").remove() ;
				$("#itid").remove() ;
				$("#hiderow").remove() ;
				$("#cid").remove() ;
				//$("#method").remove() ;			
				
				$('#items tr').each(function(row, tr){
					$(tr).find('td:eq(5)').remove() ;
					$(tr).find('th:eq(5)').remove() ;					
				});		
				
				var D = new Date();
				var hours = D.getHours();
				var minutes = D.getMinutes();
				var seconds = D.getSeconds();
				var time = hours + ":" + minutes + ":" + seconds;

				
				$('#pr').css('font-size','12px') ;
				//$('#pr').css('width','220px') ;
				$('#pr').css('font-family','tahoma') ;
				

				$('#items').css('font-size','12px') ;
				$('#items').before("<p style='font-size:20px'>*   صيدلية اسباب الشفاء الدوائية   *</p>") ;
                $('#usern').after("=======   مرتجع مبيعات   =======") ;
				$('#items').before("<p> اسم العميل : "+$("#con").text()+"</p>") ;
				$('#items').before("<p>رقم الفاتورة : "+data.invno+" </p>") ;
				$('#items').before("<p>التاريخ :"+$("#dateid").text()+" </p>") ;
				$('#items').before("<p>الوقت :"+time+" </p>") ;		
				$('#usern').after("<br/>") ;
				$('#usern').after("--------------------------------") ;
				$('#usern').after("================================") ;
                $('#usern').after("=======   مرتجع مبيعات   =======") ;
                $('#usern').after("================================") ;
				//setTimeout(function(){alert("hi")}, 1000);
				print(reload) ; 
				
				alert('تمت عملية حفظ الفاتورة بشكل صحيح');
				//location.reload();
			}
		else if (data==2)
			console.log(data) ;
		else if (data==3)
			console.log(data) ;
		else
			console.log(data) ;
		
	  }) ;
	// var pets = '{"pets":[{"name":"jack"},{"name":"john"},{"name":"joe"}]}';
	// var arr = JSON.parse(pets);
	// alert(arr.pets[0].name);

	//window.print();
}



function print(callback){
	
	
		$('#pr').printThis({
		  debug: false,               
		  importCSS: true,           
		  printContainer: true,       
		  // loadCSS: "path/to/my.css", * path to additional css file
		  pageTitle: "الفاتورة",              
		  removeInline: false         
		});	
		if(typeof callback == 'function')
				callback();
	
	
	
}

function reload(){
	 setTimeout('location.reload();', 1000);
}
