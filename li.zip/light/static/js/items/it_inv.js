var app = new Vue({
    el: '#app',
    data: {
        show_item_det: false,
        inv_history: {},
        old_public_price: [],
        old_buy_price: [],
        edit_row: false,
        edit_row_index: 0,
        item_to_add: {
            name: '',
            public_price: 0.0,
            buy_price: 0.0,
            supplier_inv: 0,
            item_idr: '',
            item_id: 0,
            expiration_date: '',
            vat: 0,
            items_count: 0,
            return_count: 0,
            inv_price: 0.0,
            id: 0,
            vat_in_public_price: false ,
        },
        NewItem: [],
        NewItem_id: 0,
        AllItems: [],
        URL: this.purl,
        invno: this.inv_no,
        NowDate: new Date(),
        itemNotFound: false,
        serchItems: {
            show: false,
            vlaue: ''
        },
        serchItemsList: [],
        VAT: 0.0,
        max: 0.0,
        min: 0.0,
        inv_items: [],
    },
    created() {
        this.$http.get(this.URL + '/../../items_qry/get_inv_items/' + this.invno).then(response => {
            if (response.body != "") {
                this.inv_items = response.body;
            }
        });
    },
    methods: {
        getitem() {
            if (!this.NewItem) {
                this.itemNotFound = true;
                return;
            }
            this.inv_items.forEach(el => {
                if (el.item_id === this.NewItem) {
                    Swal.fire(
                        'تنبية',
                        'هذا الصنف مدخل من قبل !',
                        'error'
                    );
                    return;
                }
            });
            this.$http.get(this.URL + '/../../items_qry/getit/?itid=' + this.NewItem).then(response => {
                if (response.body != "") {
                    this.item_to_add.name = response.body[0].name;
                    this.item_to_add.public_price = response.body[0].public_price;
                    this.item_to_add.buy_price = this.buy_price;
                    this.item_to_add.supplier_inv = this.invno;
                    this.item_to_add.inv_price = response.body[0].inv_price;
                    this.item_to_add.item_idr = response.body[0].id;
                    this.item_to_add.item_id = response.body[0].item_id;
                    this.item_to_add.expiration_date = response.body[0].expiration_date;
                    this.item_to_add.vat = response.body[0].vat;
                    this.old_public_price = response.body[0].old_public_price;
                    this.old_buy_price = response.body[0].old_buy_price;
                    this.item_to_add.items_count = response.body[0].items_count;
                    this.item_to_add.return_count = response.body[0].return_count;
                    this.item_to_add.vat_in_public_price = false ;
                    this.$http.get(this.URL + '/../../items_qry/gethistory?itid=' + this.NewItem).then(response => {
                        this.inv_history = response.body;
                        this.max = response.body.max[0].max;
                        this.min = response.body.min[0].min;
                        this.$refs.count.focus();
                    });
                    this.itemNotFound = false;
                } else {
                    this.NewItem = '';
                    this.itemNotFound = true;
                }
            }, response => {
                this.NewItem = '';
            });
        },
        removeItem(index) {
            Swal.fire({
                title: 'هل انت متأكد',
                text: "هل ترغب بحذف هذا السجل !",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا'
            }).then((result) => {
                if (result.value) {
                    this.$http.get(this.URL + '/../../items_qry/delitm/' + this.inv_items[index].id).then(response => {
                        if (response.body.mess === "0") {
                            this.inv_items.splice(index, 1);
                        } else {
                            Swal.fire(
                                'لم تتم العملية',
                                response.body.mess,
                                'error'
                            )
                        }
                    });
                }
            })
        },
        editItem(index) {
            this.edit_row = true;
            this.edit_row_index = index ;
            editRow = this.inv_items[index];
            this.item_to_add.name = editRow.name;
            this.item_to_add.public_price = editRow.public_price;
            this.item_to_add.buy_price = editRow.buy_price;
            this.item_to_add.supplier_inv = editRow.supplier_inv;
            this.item_to_add.item_idr = editRow.item_idr;
            this.item_to_add.item_id = editRow.item_id;
            this.item_to_add.expiration_date = editRow.expiration_date;
            this.item_to_add.vat = editRow.vat;
            this.item_to_add.items_count = editRow.items_count;
            this.item_to_add.return_count = editRow.return_count;
            this.item_to_add.inv_price = editRow.inv_price;
            this.item_to_add.id = editRow.id;
            this.item_to_add.vat_in_public_price = editRow.vat_in_public_price;
            return;
        },
        CancelEditItem() {
            this.edit_row = false;
            this.item_to_add = {
                name: '',
                public_price: 0.0,
                buy_price: 0.0,
                supplier_inv: 0,
                item_idr: '',
                item_id: 0,
                expiration_date: '',
                vat: 0,
                items_count: 0,
                return_count: 0,
                inv_price: 0.0,
                vat_in_public_price : false
            };
            return;
        },
        findItems() {
            this.serchItems.show = !this.serchItems.show;
        },
        SerchItems() {
            if (this.serchItems.value.length > 2) {
                this.$http.get(this.URL + '/../../items_qry/search_item/?itid=' + this.serchItems.value).then(response => {
                    if (response.body != "") {
                        this.serchItemsList = response.body;
                    } else {
                        this.serchItemsList = [];
                    }
                });
            } else {
                this.serchItemsList = [];
            }
        },
        selectserchItems(index) {
            this.serchItems.show = !this.serchItems.show;
            this.NewItem = this.serchItemsList[index]['item_id'];
            this.getitem();
            this.serchItemsList = [];
            this.serchItems.value = "";
            this.itemNotFound = false;
            this.NewItemCount = 1;
        },
        SaveAll() {
            var ToDate = new Date();
            if (new Date(this.item_to_add.expiration_date).getTime() <= ToDate.getTime()) {
                Swal.fire(' التاريخ المدخل غير صحيح ');
                return false;
            }
            this.item_to_add.editRow = this.edit_row;
            this.item_to_add.buy_price = this.buy_price;
            this.item_to_add['supplier_inv'] = this.invno;
            alldata = {};
            alldata['itm'] = this.item_to_add;
            this.$http.post(this.URL + '/../../items_qry/addit/', JSON.stringify(alldata), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body.id > 0) {
                        this.item_to_add['id'] = response.body.id;
                        if (this.edit_row === false) {
                            this.inv_items.push(this.item_to_add);
                        } else {
                            editRow = this.inv_items[this.edit_row_index];
                            editRow.public_price = this.item_to_add.public_price;
                            editRow.buy_price = this.item_to_add.buy_price ;
                            editRow.expiration_date = this.item_to_add.expiration_date ;
                            editRow.vat = this.item_to_add.vat ;
                            editRow.items_count = this.item_to_add.items_count ;
                            editRow.return_count = this.item_to_add.return_count ;
                            editRow.inv_price = this.item_to_add.inv_price;
                            editRow.vat_in_public_price = this.item_to_add.vat_in_public_price;
                            this.edit_row = false;
                        }
                        this.item_to_add = {
                            name: '',
                            public_price: 0.0,
                            buy_price: 0.0,
                            supplier_inv: 0,
                            item_idr: '',
                            item_id: 0,
                            expiration_date: '',
                            vat: 0,
                            items_count: 0,
                            return_count: 0,
                            inv_price: 0.0,
                            vat_in_public_price:false
                        },
                            this.NewItem = "";
                        this.$refs.search.focus();
                        return 'ok';
                    }
                } else {
                    console.log('err');
                    return;
                }
            });
        },
        show_item_history() {
            window.open(this.URL + '/../../items/itm_rep_det/' + this.item_to_add.item_idr, "_blank");
        },
        rename(){
            _app = this ;
            if (this.edit_row){
                this.NewItem = this.item_to_add.item_id ;
            }
            Swal.fire({
                title: 'تعديل اسم الصنف',
                input: 'text',
                inputValue: this.item_to_add.name ,
                inputAttributes: {
                    autocapitalize: 'on' ,
                },
                showCancelButton: true,
                confirmButtonText: 'تعديل الاسم',
                cancelButtonColor: '#d33',
                cancelButtonText: 'تراجع' ,
                showLoaderOnConfirm: true,
                preConfirm: (login) => {
                    return fetch(this.URL + '/../../items_qry/renameitm/' + this.NewItem + "?new=" + login)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(response.statusText)
                            }
                            this.item_to_add.name = login ;
                            return response
                        })
                        .catch(error => {
                            Swal.showValidationMessage(
                                `Request failed: ${error}`
                            )
                        })
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.value) {
                    Swal.fire({
                        title: "تم التعديل بنجاح",
                    })
                }
            })
        }
    },
    computed: {
        // a computed getter
        total() {
            total = 0.0;
            this.inv_items.forEach(function (element) {
                total += parseFloat(element.inv_price);
            });
            return total;
        },
        buy_price() {
            var s = (this.item_to_add.inv_price / this.item_to_add.items_count).toFixed(2);
            if (Number(s)) {
                return s;
            } else {
                return 0;
            }
        },
        FormErr() {
            //console.log(this.item_to_add);
            if (this.item_to_add.items_count && this.item_to_add.inv_price && this.item_to_add.public_price && this.item_to_add.expiration_date && this.item_to_add.item_id && this.item_to_add.return_count && (this.item_to_add.vat == 0 || this.item_to_add.vat == 0.15)) {
                /// 
                return true;
            } else {
                return false;
            }
        },
        chk_date() {
            if (this.item_to_add.expiration_date) {
                d1 = new Date(this.item_to_add.expiration_date).getTime();
                d2 = new Date().getTime() + (300 * 24 * 60 * 60 * 1000);
                if (d1 < d2) {
                    return true;
                } else {
                    return false;
                }
            }
            return false;
        } ,
        profit(){
            if (this.buy_price>0){
                //console.log('this.item_to_add.vat_in_public_price');
                if (this.item_to_add.vat_in_public_price===true) {
                    price_befor = (this.item_to_add.public_price / (1 + parseFloat(this.item_to_add.vat))) ;
                    pro = (((price_befor - this.buy_price) / this.buy_price) * 100).toFixed(2)
                } else {
                    pro = (((this.item_to_add.public_price - this.buy_price) / this.buy_price) * 100).toFixed(2)
                }
                return pro
            } else {
                return 0
            }
        } ,
        net_price() {
            //
            if (this.item_to_add.vat_in_public_price ) {
                vat = this.item_to_add.public_price - (this.item_to_add.public_price / (1 + parseFloat(this.item_to_add.vat))) ;
                price_befor = this.item_to_add.public_price - vat ;
                price_after = parseFloat(this.item_to_add.public_price);
                return [price_befor, vat, price_after]
            } else {
                vat = parseFloat(this.item_to_add.public_price) * parseFloat(this.item_to_add.vat);
                price_befor = parseFloat(this.item_to_add.public_price);
                price_after = parseFloat(price_befor)+ vat  ;
                return [price_befor, vat, price_after]                
            }

        }

    } 
});
