var obj  ;

$(document).ready(function() {

});

 function createGuid()
{
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });
}
function generateQuickGuid() {
    return Math.random().toString(36).substring(2, 15) +
        Math.random().toString(36).substring(2, 15);
}


function chkerr() {
    var q = 0;

    $('#1,#3,#4,#5,#6,#7,#8,#9').each(function (n) {
        if (this.value == '') {
            $('#' + this.id).css("background-color", "#F8E5E5");
            q = 1;
        }
    });
    if (q == 1) {
        //alert("يجب ادخال الحقول المحددة الرجاء التأكد و المحاولة مرة أخرى !");
        sweetAlert("خطأ","يجب ادخال كافة الحقول المحددة و المحاولة مرة أخرى", "error");
        return false;
    }
}

function doSuccess(o) {
    $('#' + o.id).css("background-color", "#DEF8CA");

}
function doError(o) {
    $('#' + o.id).css("background-color", "#F8E5E5");
    $('#msg').text('يجب ادخال الحقول المحددة الرجاء التأكد و المحاولة مرة أخرى');
}
//================================================================================
function add(){

    if (chkerr()!=false) {
        // الارسال للخادم 
        //if ($('#in4').val() != ''){$("#in4").val("0") ; }
        var itm = "{"
        itm += '"item_id":"'+$("#in1").val()+'"' ;
        itm += ',"supplier_inv":"'+inv_id+'"' ;
        itm += ',"public_price":"'+$("#in6").val()+'"' ;
        itm += ',"quantity":"'+$("#in3").val()+'"' ;
        itm += ',"free_quantity":"'+ $('#in4').val() +'"' ;
        itm += ',"discount_rate":"'+$("#in7").val()+'"' ;
        itm += ',"discount":"'+$("#in8").val()+'"' ;
        itm += ',"buy_price":"'+$("#in9").val()+'"' ;
        itm += ',"expiration_date":"'+$("#in5").val()+'"' ;
        itm += ',"Guid":"'+ generateQuickGuid() +'"' ;
        itm += '}' ;
        $.getJSON(purl+"/../addit?itm="+itm , function(data) {
            //************************************************************
             console.log(data) ;
             //**********************************************************
            if ((data.length > 0) & (data[0].mess==0 ) & (data[0].items_id >0 ) ){
            // الكتاب على الشاشة
                var gid= generateQuickGuid();
                var st = "style='background-color: rgb(235, 163, 163); '"
                //alert(data[0].items_id) ;
                var ms = [
                    "<tr id='"+data[0].items_id+"' "+st+"  class='items'  >",
                    "<td>"+$("#in1").val()+"<br/>"+$("#in01").text()+"</td>",
                    "<td>"+Math.abs($("#in3").val())+"</td>",
                    "<td>"+Math.abs($("#in4").val())+"</td>",
                    "<td>"+Math.abs($("#in7").val())+"</td>",
                    "<td>"+Math.abs($("#in8").val())+"</td>",
                    "<td>"+Math.abs($("#in6").val())+"</td>",
                    "<td>"+Math.abs($("#in9").val())+"</td>",
                    "<td> <a type='button' class='icon-trash' onclick=del('"+data[0].items_id+"') ></a> </td>    </tr>"].join("\n");
                $('#th').after(ms) ;
                $("#itm_c").text(data[0].itm_c) ;
                $("#inv_sum").text(data[0].inv_p) ;
                //-------------------
                $("#in1").val("")
                $("#in01").text("");
                $("#in3").val('');
                $("#in4").val('');
                $("#in6").val( "" );
                $("#in7").val( "" );
                $("#in8").val( "" );
                $("#in9").val( "" );
                $("#in4").val('');
                $("#in5").val('');
               }
               else {
                   //alert('لم تتم عملية الحفظ بشكل صحيح الرجاء المحاولة مرة أخرى و شكراً .');
                   sweetAlert("خطأ","لم تتم عملية الحفظ بشكل صحيح الرجاء المحاولة مرة أخرى و شكراً ", "error");
               }
           }) ;
       }
}

function del(rown){
    swal({
        title: "انت على وشك حذف سجل هل انت متأكد ؟",
        text: "تأكد ",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "نعم",
        cancelButtonText: "لا",
        closeOnConfirm: true,
        closeOnCancel: true },
             function(){
                 var itm = "{"
                 itm += '"item_id":"'+rown+'"' ;
                 itm += ',"supplier_inv":"'+inv_id+'"' ;
                 itm += '}' ;
                 $.getJSON(purl+"/../delitm?itm="+itm , function(data) {
                      if (data.length > 0 ){
                         // الكتاب على الشاشة
                         $('#'+rown).remove() ;
                         $("#itm_c").text(data[0].itm_c) ;
                         $("#inv_sum").text(data[0].inv_p)
                         return false ;
                     }
                     else {
                         swal('لمتتم عملية الحذف بشكل صحيح، الرجاء المحاولة مرة أخرى .');
                         return false ;
                     }
                 }) ;
             });
}

function clear(){

}

function get1(){
     $.getJSON(purl+"/../getmit/"+$("#in1").val() , function(data) {
     if (data.length > 0 ){
        var foundin = $( "tr:contains('"+$("#in1").val()+"')" );
        if (foundin.length>0){

            swal(" هذا الصنف مسجل مسبقا !")
        }
        else{
            $("#in01").text(data[0].name);
            $("#in3").text('0');
            $("#in4").text('0');
            $("#in6").val( data[0].public_price ? data[0].public_price : 0 );
            $("#in7").val( data[0].discount_rate ? data[0].discount_rate : 0 );
            $("#in8").val( data[0].discount ? data[0].discount : 0 );
            $("#in9").val( data[0].buy_price ? data[0].buy_price : 0 );
            $("#in4").text('0');
            $("#in5").text('');
        }
    }
    else {
        swal('لم يتم العثور على التصنيف المدخل الرجاء التأكد');
        $("#in1").val("") ;
    }
    });
}

function mit_srh(){
 $.getJSON(purl+"/../mit?it="+$("#mds_01").val() , function(data) {
     $("#mds01").html(' ') ;
     if (data.length >0 ){
        for (var i = 0; i < data.length; i++) {
            $("#mds01").append('<tr><td>'+data[i].item_id+'</td><td>'+data[i].name+'</td></tr>');
        }
    }
    else {
        swal('لم يتم العثور على التصنيف المدخل الرجاء التأكد');
    }
    });
}
//====================================================================================================================
//console.log(data);

     //output=data  ;
     //alert('ttttttttttt') ;
     //s = data ;
     //console.log(data);

      /*
    total += parseFloat($("#total1").text()) ;
    $('#mr').before(ms) ;
    $("#itcount").text("1") ;
    $("#itname").html("");
    $("#itprice").html("");
    $("#total1").html("");
    $("#total2").text(total.toFixed(2)) ;
    $("#itid").val("") ;
    $("#hlal").text((Math.floor(total+1)-total.toFixed(2)).toFixed(2)) ;
    */


            //console.log(data);


//------------------------------------------------------------------------------
/*
 $('#T_Id').keypress(function (event) {
        var keychar = String.fromCharCode(event.which);
        var numcheck = /[\d]/;
        return numcheck.test(keychar);
    });
*/
//-----------------------------------
/*
    $('#T_Id,#T_Name,#T_Pic,#T_Tel,#T_Sch').blur(function () {
        if (this.value != '') {
            doSuccess(this);
        } else {
            doError(this);
        };
    });
*/
//----------------------------------------------------------------------------
