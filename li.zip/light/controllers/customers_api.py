# -*- coding: utf-8 -*-
# ======================================================================================
# type: ignore

@can_access(1001)
def get_customers():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where = ""
    if ReqVar.SearchText and ReqVar.SearchText != "":
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where = (
                    f" where ( name like '%{srt[i]}%' or mobile like '%{srt[i]}%'  ) "
                )
            else:
                where = (
                    where
                    + f" and ( name like '%{srt[i]}%' or mobile like '%{srt[i]}%'  ) "
                )
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = "id"
    if ReqVar.sequence:
        if ReqVar.sequence == "true":
            sa = "ASC"
        else:
            sa = "desc"
    else:
        sa = "ASC"
    pg = int(int(pg) * int(rc))
    where = where.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("and  and", "and")
    sql = f" SELECT id,name,mobile, address,vat,crn FROM customers {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    sql = sql.replace("and  order", "order")
    sql2 = f" SELECT count(*) FROM customers  {where}  ; "
    sql2 = sql2.replace("and   ;", "; ")
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def new_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(
            db, "customers.mobile", error_message="يوجد هذا الرقم مسجل مسبقا"
        )
        nid = db.customers.validate_and_insert(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            vat=data.vat,
            crs =data.crn,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(e)


def edit_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(
            db, "customers.mobile", error_message="يوجد هذا الرقم مسجل مسبقا"
        )
        row = db.customers[data.id]
        row.update_record(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            vat=data.vat,
            crn=data.crn,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)
