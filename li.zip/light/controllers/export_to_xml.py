# type: ignore
import os
import json
from pathlib import Path
import hashlib
import base64
import time
import fnmatch
import shutil
from ecdsa import SigningKey
from hashlib import sha256
from time import gmtime, strftime
import lxml.etree as ET
import json

def sign_data(self, privatekey: str, signStr: str) -> str:
    private_key = SigningKey.from_pem(privatekey)  # uses NIST192p
    signStrLocl = bytes(signStr, 'utf-8')
    signature = private_key.sign(signStrLocl, hashfunc=sha256)
    return signature.hex()

def gethash(self, strtohash) -> str:
    a_string = strtohash
    hashed_string = hashlib.sha256(a_string.encode('utf-8')).hexdigest()
    message_bytes = hashed_string.encode('utf-8')
    base64_bytes = base64.b64encode(message_bytes)
    return str(base64_bytes.decode('utf-8'))


def replaceAll(txt, d):
    tmp_txt = txt
    for i in d:
        tmp_txt = tmp_txt.replace(i, str(d[i]))
    return (tmp_txt)


def get_certificate(company):
    ccsid = frappe.db.get_value("Company", company, "pcsid_username")
    if ccsid:
        cert = base64.b64decode(ccsid.encode("utf-8")).decode()
        return (cert)
    return (None)


def get_hash(xml):
    xml_sha256 = sha256(xml.encode('utf-8')).hexdigest()
    hash = base64.b64encode(bytes.fromhex(xml_sha256)).decode()
    return hash


def read(file):
    try:
        f = open(file, "r")
        msg = f.read()
        f.close()
        return (msg)
    except:
        return (None)


def cananolize():
    try:
        print("in")
        c_dir = os.path.dirname(__file__)
        sml_file = os.path.join(c_dir, '..', "xml_export\\2023\\01\\310232266400003_20230127T042906_105.xml")
        sml_file2 = os.path.join(c_dir, '..', "xml_export\\2023\\01\\31023.xml")
        print(sml_file)
        et = ET.parse(sml_file)
        et.write_c14n(sml_file2, exclusive=0, with_comments=0)
        f = open(sml_file2, "r")
        cananolized_xml = f.read()
        print(cananolized_xml)
        f.close()
        #os.remove(sml_file2)
        return (cananolized_xml)
    except:
        return (None)

def export():
    xml_doc_0 = """<?xml version="1.0" encoding="UTF-8"?>"""
    c_dir = os.path.dirname(__file__)
    simple_invoice_xml = read(os.path.join(c_dir, '..', 'templates', "simple_invoice.xml"))
    item_line_xml = read(os.path.join(c_dir, '..', 'templates', "item_line.xml"))
    extensions_xml = read(os.path.join(c_dir, '..', 'templates', "extensions.xml"))
    qr_code_xml = read(os.path.join(c_dir, '..', 'templates', "qr_code.xml"))
    #=================
    qr_code = ""
    tax_category = "S"
    payment_means = "10"
    country_code = "SA"
    type_code_name = "0200000"
    type_code = "388"
    crn = "company.cr_number"
    scheme_type = "CRN"
    
    replace = {
        "{id}"               : "*****",
        "{uuid}"             : "**1**",
        "{issue_date}"       : "**1**",
        "{issue_time}"       : "**1**",
        "{currency}"         : "**1**",
        "{pih}"              : "**1**",
        "{tax_currency}"     : "**1**",
        "{qr_code}"          : "**1**",
        "{company_tax_id}"   : "**1**",
        "{company_name}"     : "**1**",
        "{vat_percent}"      : "**1**",
        "{total}"            : "**1**",
        "{total_discount}"   : "**1**",
        "{tax_amount}"       : "**1**",
        "{taxable_amount}"   : "**1**",
        "{total_amount}"     : "**1**",
        "{total_advance}"    : "**1**",
        "{payable_amount}"   : "**2**",
        "{tax_category}"     : "**2**",
        "{payment_means}"    : "**2**",
        "{country_code}"     : "**2**",
        "{scheme_type}"      : "**2**",
        "{scheme_id}"        : "**2**",
        "{street_name}"      : "**2**",
        "{city_name}"        : "**2**",
        "{postal_code}"      : "**2**",
        "{building_number}"  : "**2**",
        "{city_subdivision}" :"**2**",
        "{plot}"             : "**2**"
        }
    
    xml = simple_invoice_xml.replace('{ext:UBLExtensions}', extensions_xml)
    xml = replaceAll(xml, replace)
    return str(xml)


def ddd2():
    return "o"