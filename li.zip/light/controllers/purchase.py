# coding: utf8
# type: ignore


def index():
    return dict()


# =====================================================
#                       API
# =====================================================


def get_invoices():
    print("ok")
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where = ""
    if ReqVar.SearchText and ReqVar.SearchText != "":
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where = f" where ( supplier like '%{srt[i]}%' or bill_no like '%{srt[i]}%' or CAST (bill_date  AS text) like '%{srt[i]}%' or CAST (bill_total  AS text) like '%{srt[i]}%' or CAST (bill_net_amount  AS text) like '%{srt[i]}%'  or CAST (bill_vat  AS text) like '%{srt[i]}%'  )  "
            else:
                where = (
                    where
                    + f" and ( supplier like '%{srt[i]}%' or bill_no like '%{srt[i]}%' or CAST (bill_date  AS text) like '%{srt[i]}%' or CAST (bill_total  AS text) like '%{srt[i]}%' or CAST (bill_net_amount  AS text) like '%{srt[i]}%'  or CAST (bill_vat  AS text) like '%{srt[i]}%'  )  "
                )
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = "id"
    if ReqVar.sequence:
        if ReqVar.sequence == "true":
            sa = "ASC"
        else:
            sa = "desc"
    else:
        sa = "ASC"
    pg = int(int(pg) * int(rc))
    where = where.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("and  and", "and")
    sql = f" SELECT * FROM purchase_invoices {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    sql = sql.replace("and  order", "order")
    sql2 = f" SELECT count(*) FROM purchase_invoices  {where}  ; "
    sql2 = sql2.replace("and   ;", "; ")
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def new_invoice():
    try:
        data = request.vars
        nid = db.purchase_invoices.validate_and_insert(
            supplier=data.supplier,
            bill_no=data.bill_no,
            bill_date=data.bill_date,
            bill_total=data.bill_total,
            bill_net_amount=data.bill_net_amount,
            bill_vat=data.bill_vat,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(e)


def edit_invoice():
    try:
        data = request.vars
        row = db.purchase_invoices[data.id]
        row.update_record(
            supplier=data.supplier,
            bill_no=data.bill_no,
            bill_date=data.bill_date,
            bill_total=data.bill_total,
            bill_net_amount=data.bill_net_amount,
            bill_vat=data.bill_vat,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)
