# type: ignore
# type: ignore
import os
import json
from pathlib import Path
import hashlib
import base64
import time
import fnmatch
import shutil
from ecdsa import SigningKey
from hashlib import sha256
from time import gmtime, strftime


class createXML:
    def __init__(self, invoce) -> None:
        self.invoce = {
            "invoiceSignedData": "***",
            "xadesSignedProperties": "***",
            "SignatureValue": "***",
            "X509Certificate": "***",
            "SigningTime": "***",
            "CertDigest": "***",
            "X509IssuerName": "***",
            "X509SerialNumber": "***",
            "ProfileID": "reporting:1.0",
            "cbc:ID": "***",
            "UUID": "***",
            "cbc:IssueDate": "***",
            "cbc:IssueTime": "***",
            "cbc: InvoiceTypeCode_name": "***",
            "cbc:InvoiceTypeCode": "***",
            "PIH": "***",
            "AccountingSupplierParty": {
                "ID": "5855340398",
                "StreetName": "test",
                "BuildingNumber": "3454",
                "PlotIdentification": "1234",
                "CitySubdivisionName": "test",
                "CityName": "Riyadh",
                "PostalZone": "12345",
                "CountrySubentity": "test",
                "CompanyID": "310232266400003",
                "PartyLegalEntity": "Ahmed Mohamed zahmah",
            },
            "AccountingCustomerParty": {
                "ID": "2345",
                "StreetName": "baaoun",
                "BuildingNumber": "3353",
                "PlotIdentification": "1234",
                "CitySubdivisionName": "test",
                "CityName": "Riyadh",
                "PostalZone": "12345",
                "CountrySubentity": "test",
                "CompanyID": "300075588700003",
                "PartyLegalEntity": "Ahmed Mohamed zahmah",
            },
            "ActualDeliveryDate": "2022-03-15",
            "LatestDeliveryDate": "2022-03-15",
            "PaymentMeansCode": "10",
            "AllowanceCharge": {
                "ID": "1",
                "ChargeIndicator": "false",
                "AllowanceChargeReason": "discount",
                "Amount": "2",
                "Percent": "15",
            },
            "cac:TaxTotal": {
                "TaxAmount": "144.9",
                "TaxableAmount": "966.00",
                "Percent": "15",
            },
            "LegalMonetaryTotal": {
                "LineExtensionAmount": "966.00",
                "TaxExclusiveAmount": "964.00",
                "TaxInclusiveAmount": "1108.90",
                "AllowanceTotalAmount": "2.00",
                "PrepaidAmount": "0.00",
                "PayableAmount": "1108.90",
            },
            "InvoiceLine": {
                "ID": "1",
                "InvoicedQuantity": "44.00",
                "LineExtensionAmount": "966.00",
                "TaxAmount": "144.90",
                "RoundingAmount": "1110.90",
                "Item": {
                    "Name": "******",
                    "Percent": "15",
                },
                "PriceAmount": "22.00",
                "ChargeIndicator": "false",
                "AllowanceChargeReason": "discount",
                "Amount": "2.00",
            },
        }
        self.invoce.update(invoce)

    def sign_data(self, privatekey: str, signStr: str) -> str:
        private_key = SigningKey.from_pem(privatekey)  # uses NIST192p
        signStrLocl = bytes(signStr, "utf-8")
        signature = private_key.sign(signStrLocl, hashfunc=sha256)
        return signature.hex()

    def gethash(self, strtohash) -> str:
        a_string = strtohash
        hashed_string = hashlib.sha256(a_string.encode("utf-8")).hexdigest()
        message_bytes = hashed_string.encode("utf-8")
        base64_bytes = base64.b64encode(message_bytes)
        return str(base64_bytes.decode("utf-8"))

    def exportXML(self) -> None:
        SignatureValue = "  "
        xml_doc_0 = """<?xml version="1.0" encoding="UTF-8"?>"""
        xml_doc_1 = """     <Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
            xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
            xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
            xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">"""
        xml_doc_3 = (
            """<cbc:ProfileID>reporting:1.0</cbc:ProfileID>
                <cbc:ID>"""
            + self.invoce["cbc:ID"]
            + """</cbc:ID>
                <cbc:UUID>"""
            + self.invoce["UUID"]
            + """</cbc:UUID>
                <cbc:IssueDate>"""
            + self.invoce["cbc:IssueDate"]
            + """</cbc:IssueDate>
                <cbc:IssueTime>"""
            + self.invoce["cbc:IssueTime"]
            + """</cbc:IssueTime>
                <cbc:InvoiceTypeCode name=\""""
            + self.invoce["cbc: InvoiceTypeCode_name"]
            + """\">"""
            + self.invoce["cbc:InvoiceTypeCode"]
            + """</cbc:InvoiceTypeCode>
                <cbc:DocumentCurrencyCode>SAR</cbc:DocumentCurrencyCode>
                <cbc:TaxCurrencyCode>SAR</cbc:TaxCurrencyCode>
                <cac:AdditionalDocumentReference>
                    <cbc:ID>ICV</cbc:ID>
                    <cbc:UUID>62</cbc:UUID>
                </cac:AdditionalDocumentReference>
                    <cac:AdditionalDocumentReference>
                    <cbc:ID>PIH</cbc:ID>
                    <cac:Attachment>
                        <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">"""
            + self.invoce["PIH"]
            + """</cbc:EmbeddedDocumentBinaryObject>
                    </cac:Attachment>
                </cac:AdditionalDocumentReference>
                    <cac:AdditionalDocumentReference>
                    <cbc:ID>QR</cbc:ID>
                    <cac:Attachment>
                        <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">AR5FYmRhZURldmVsb3BtZW50YW5kUHJvZ3JhbW1pbmcCDzMxMDIzMjI2NjQwMDAwMwMTMjAyMy0wMS0wMVQxMToxMToxMQQGMTE1MjQ0BQIxMAYiOThjNTM3YzljOGE2NWI3ZGMxNjQxNzExZmM2MWZiNTI3NweBgDA1ZTdlNGIyZTliMDJmZmMxZTBlZjgyOGFkOTI0MjQ1ZDYzYTI4ZmRhNTQ4MTc3NGFjZjRhMzk1NDI0NGY4YTZmNThmYjQyZTI5MDE0ZWQxYTk4YjVmYThlMjY0MWVkMmM3OTQ3OWZlNDU0MDJhODM2NjRjZDFmNTY3MTI1YzU2CDtNRFl3RUFZSEtvWkl6ajBDQVFZRks0RUVBQW9ESWdBQ1NKTzIyMitaZE1Xd3RhLzdtWEdQVVV2SlEwPQlaMzA0NjAyMjEwMGQyMzhlOGZhOTA2ZDYzODg1ZjFlOGVlNGQ2ZjEzMjcwNTlkYjAzOTNhZWFjYjgzNzZjY2FiMTc0ZTM2YmI1Y2FhZjM4OWM4MjkwZDFjMDA3</cbc:EmbeddedDocumentBinaryObject>
                    </cac:Attachment>
                </cac:AdditionalDocumentReference>
                <cac:Signature>
                    <cbc:ID>urn:oasis:names:specification:ubl:signature:Invoice</cbc:ID>
                    <cbc:SignatureMethod>urn:oasis:names:specification:ubl:dsig:enveloped:xades</cbc:SignatureMethod>
                </cac:Signature>
                <cac:AccountingSupplierParty>
                    <cac:Party>
                        <cac:PartyIdentification>
                            <cbc:ID schemeID="CRN">"""
            + self.invoce["AccountingSupplierParty"]["ID"]
            + """</cbc:ID>
                        </cac:PartyIdentification>
                        <cac:PostalAddress>
                            <cbc:StreetName>"""
            + self.invoce["AccountingSupplierParty"]["StreetName"]
            + """</cbc:StreetName>
                            <cbc:BuildingNumber>"""
            + self.invoce["AccountingSupplierParty"]["BuildingNumber"]
            + """</cbc:BuildingNumber>
                            <cbc:PlotIdentification>"""
            + self.invoce["AccountingSupplierParty"]["PlotIdentification"]
            + """</cbc:PlotIdentification>
                            <cbc:CitySubdivisionName>"""
            + self.invoce["AccountingSupplierParty"]["CitySubdivisionName"]
            + """</cbc:CitySubdivisionName>
                            <cbc:CityName>"""
            + self.invoce["AccountingSupplierParty"]["CityName"]
            + """</cbc:CityName>
                            <cbc:PostalZone>"""
            + self.invoce["AccountingSupplierParty"]["PostalZone"]
            + """</cbc:PostalZone>
                            <cbc:CountrySubentity>"""
            + self.invoce["AccountingSupplierParty"]["CountrySubentity"]
            + """</cbc:CountrySubentity>
                            <cac:Country>
                                <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                            </cac:Country>
                        </cac:PostalAddress>
                        <cac:PartyTaxScheme>
                            <cbc:CompanyID>"""
            + self.invoce["AccountingSupplierParty"]["CompanyID"]
            + """</cbc:CompanyID>
                            <cac:TaxScheme>
                                <cbc:ID>VAT</cbc:ID>
                            </cac:TaxScheme>
                        </cac:PartyTaxScheme>
                        <cac:PartyLegalEntity>
                            <cbc:RegistrationName>"""
            + self.invoce["AccountingSupplierParty"]["PartyLegalEntity"]
            + """</cbc:RegistrationName>
                        </cac:PartyLegalEntity>
                    </cac:Party>
                </cac:AccountingSupplierParty>
                <cac:AccountingCustomerParty>
                    <cac:Party>
                        <cac:PartyIdentification>
                            <cbc:ID schemeID="OTH">"""
            + self.invoce["AccountingCustomerParty"]["ID"]
            + """</cbc:ID>
                        </cac:PartyIdentification>
                        <cac:PostalAddress>
                            <cbc:StreetName>"""
            + self.invoce["AccountingCustomerParty"]["StreetName"]
            + """</cbc:StreetName>
                            <cbc:AdditionalStreetName>none</cbc:AdditionalStreetName>
                            <cbc:BuildingNumber>"""
            + self.invoce["AccountingCustomerParty"]["BuildingNumber"]
            + """</cbc:BuildingNumber>
                            <cbc:PlotIdentification>"""
            + self.invoce["AccountingCustomerParty"]["PlotIdentification"]
            + """</cbc:PlotIdentification>
                            <cbc:CitySubdivisionName>"""
            + self.invoce["AccountingCustomerParty"]["CitySubdivisionName"]
            + """</cbc:CitySubdivisionName>
                            <cbc:CityName>"""
            + self.invoce["AccountingCustomerParty"]["CityName"]
            + """</cbc:CityName>
                            <cbc:PostalZone>"""
            + self.invoce["AccountingCustomerParty"]["PostalZone"]
            + """</cbc:PostalZone>
                            <cbc:CountrySubentity>"""
            + self.invoce["AccountingCustomerParty"]["CountrySubentity"]
            + """</cbc:CountrySubentity>
                            <cac:Country>
                                <cbc:IdentificationCode>SA</cbc:IdentificationCode>
                            </cac:Country>
                        </cac:PostalAddress>
                        <cac:PartyTaxScheme>
                            <cac:TaxScheme>
                                <cbc:ID>VAT</cbc:ID>
                            </cac:TaxScheme>
                        </cac:PartyTaxScheme>
                        <cac:PartyLegalEntity>
                            <cbc:RegistrationName>"""
            + self.invoce["AccountingCustomerParty"]["PartyLegalEntity"]
            + """</cbc:RegistrationName>
                        </cac:PartyLegalEntity>
                    </cac:Party>
                </cac:AccountingCustomerParty>"""
        )
        xml_doc_4 = (
            """<cac:Delivery>
                    <cbc:ActualDeliveryDate>"""
            + self.invoce["ActualDeliveryDate"]
            + """</cbc:ActualDeliveryDate>
                    <cbc:LatestDeliveryDate>"""
            + self.invoce["LatestDeliveryDate"]
            + """</cbc:LatestDeliveryDate>
                </cac:Delivery>
                <cac:PaymentMeans>
                    <cbc:PaymentMeansCode>"""
            + self.invoce["PaymentMeansCode"]
            + """</cbc:PaymentMeansCode>
                </cac:PaymentMeans>
                <cac:AllowanceCharge>
                    <cbc:ID>"""
            + self.invoce["AllowanceCharge"]["ID"]
            + """</cbc:ID>
                    <cbc:ChargeIndicator>"""
            + self.invoce["AllowanceCharge"]["ChargeIndicator"]
            + """</cbc:ChargeIndicator>
                    <cbc:AllowanceChargeReason>"""
            + self.invoce["AllowanceCharge"]["AllowanceChargeReason"]
            + """</cbc:AllowanceChargeReason>
                    <cbc:Amount currencyID="SAR">"""
            + self.invoce["AllowanceCharge"]["Amount"]
            + """</cbc:Amount>
                    <cac:TaxCategory>
                        <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5305">S</cbc:ID>
                        <cbc:Percent>"""
            + self.invoce["AllowanceCharge"]["Percent"]
            + """</cbc:Percent>
                        <cac:TaxScheme>
                            <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5153">VAT</cbc:ID>
                        </cac:TaxScheme>
                    </cac:TaxCategory>
                </cac:AllowanceCharge>
                <cac:TaxTotal>
                    <cbc:TaxAmount currencyID="SAR">"""
            + self.invoce["cac:TaxTotal"]["TaxAmount"]
            + """</cbc:TaxAmount>
                    <cac:TaxSubtotal>
                        <cbc:TaxableAmount currencyID="SAR">"""
            + self.invoce["cac:TaxTotal"]["TaxableAmount"]
            + """</cbc:TaxableAmount>
                        <cbc:TaxAmount currencyID="SAR">"""
            + self.invoce["cac:TaxTotal"]["TaxAmount"]
            + """</cbc:TaxAmount>
                        <cac:TaxCategory>
                            <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5305">S</cbc:ID>
                            <cbc:Percent>"""
            + self.invoce["cac:TaxTotal"]["Percent"]
            + """</cbc:Percent>
                            <cac:TaxScheme>
                                <cbc:ID schemeAgencyID="6" schemeID="UN/ECE 5153">VAT</cbc:ID>
                            </cac:TaxScheme>
                        </cac:TaxCategory>
                    </cac:TaxSubtotal>
                </cac:TaxTotal>
                <cac:TaxTotal>
                    <cbc:TaxAmount currencyID="SAR">"""
            + self.invoce["cac:TaxTotal"]["TaxAmount"]
            + """</cbc:TaxAmount>
                </cac:TaxTotal>
                <cac:LegalMonetaryTotal>
                    <cbc:LineExtensionAmount currencyID="SAR">"""
            + self.invoce["LegalMonetaryTotal"]["LineExtensionAmount"]
            + """</cbc:LineExtensionAmount>
                    <cbc:TaxExclusiveAmount currencyID="SAR">"""
            + self.invoce["LegalMonetaryTotal"]["TaxExclusiveAmount"]
            + """</cbc:TaxExclusiveAmount>
                    <cbc:TaxInclusiveAmount currencyID="SAR">"""
            + self.invoce["LegalMonetaryTotal"]["TaxInclusiveAmount"]
            + """</cbc:TaxInclusiveAmount>
                    <cbc:AllowanceTotalAmount currencyID="SAR">"""
            + self.invoce["LegalMonetaryTotal"]["AllowanceTotalAmount"]
            + """</cbc:AllowanceTotalAmount>
                    <cbc:PrepaidAmount currencyID="SAR">"""
            + self.invoce["LegalMonetaryTotal"]["PrepaidAmount"]
            + """</cbc:PrepaidAmount>
                    <cbc:PayableAmount currencyID="SAR">"""
            + self.invoce["LegalMonetaryTotal"]["PayableAmount"]
            + """</cbc:PayableAmount>
                </cac:LegalMonetaryTotal>
                <cac:InvoiceLine>
                    <cbc:ID>"""
            + self.invoce["InvoiceLine"]["ID"]
            + """</cbc:ID>
                    <cbc:InvoicedQuantity unitCode="PCE">"""
            + self.invoce["InvoiceLine"]["InvoicedQuantity"]
            + """</cbc:InvoicedQuantity>
                    <cbc:LineExtensionAmount currencyID="SAR">"""
            + self.invoce["InvoiceLine"]["LineExtensionAmount"]
            + """</cbc:LineExtensionAmount>
                    <cac:TaxTotal>
                        <cbc:TaxAmount currencyID="SAR">"""
            + self.invoce["InvoiceLine"]["TaxAmount"]
            + """</cbc:TaxAmount>
                        <cbc:RoundingAmount currencyID="SAR">"""
            + self.invoce["InvoiceLine"]["RoundingAmount"]
            + """</cbc:RoundingAmount>
                    </cac:TaxTotal>
                    <cac:Item>
                        <cbc:Name>"""
            + self.invoce["InvoiceLine"]["Item"]["Name"]
            + """</cbc:Name>
                        <cac:ClassifiedTaxCategory>
                            <cbc:ID>S</cbc:ID>
                            <cbc:Percent>"""
            + self.invoce["InvoiceLine"]["Item"]["Percent"]
            + """</cbc:Percent>
                            <cac:TaxScheme>
                                <cbc:ID>VAT</cbc:ID>
                            </cac:TaxScheme>
                        </cac:ClassifiedTaxCategory>
                    </cac:Item>
                    <cac:Price>
                        <cbc:PriceAmount currencyID="SAR">"""
            + self.invoce["InvoiceLine"]["PriceAmount"]
            + """</cbc:PriceAmount>
                        <cac:AllowanceCharge>
                            <cbc:ChargeIndicator>"""
            + self.invoce["InvoiceLine"]["ChargeIndicator"]
            + """</cbc:ChargeIndicator>
                            <cbc:AllowanceChargeReason>"""
            + self.invoce["InvoiceLine"]["AllowanceChargeReason"]
            + """</cbc:AllowanceChargeReason>
                            <cbc:Amount currencyID="SAR">"""
            + self.invoce["InvoiceLine"]["Amount"]
            + """</cbc:Amount>
                        </cac:AllowanceCharge>
                    </cac:Price>
                </cac:InvoiceLine>
                </Invoice>"""
        )
        xml_invoce_hash = self.gethash(xml_doc_1 + "\n" + xml_doc_3 + "\n" + xml_doc_4)
        SignatureValue = self.sign_data(self.invoce["privatekey"], xml_invoce_hash)
        SignedProperties_hash = self.gethash(
            self.invoce["SigningTime"]
            + "\n"
            + self.invoce["CertDigest"]
            + "\n"
            + self.invoce["X509IssuerName"]
            + "\n"
            + self.invoce["X509SerialNumber"]
        )
        xml_doc_2 = (
            """            <ext:UBLExtensions>
                <ext:UBLExtension>
                    <ext:ExtensionURI>urn:oasis:names:specification:ubl:dsig:enveloped:xades</ext:ExtensionURI>
                    <ext:ExtensionContent>
                        <sig:UBLDocumentSignatures xmlns:sig="urn:oasis:names:specification:ubl:schema:xsd:CommonSignatureComponents-2"
                            xmlns:sac="urn:oasis:names:specification:ubl:schema:xsd:SignatureAggregateComponents-2"
                            xmlns:sbc="urn:oasis:names:specification:ubl:schema:xsd:SignatureBasicComponents-2">
                            <sac:SignatureInformation>
                                <cbc:ID>urn:oasis:names:specification:ubl:signature:1</cbc:ID>
                                <sbc:ReferencedSignatureID>urn:oasis:names:specification:ubl:signature:Invoice</sbc:ReferencedSignatureID>
                                <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Id="signature">
                                    <ds:SignedInfo>
                                        <ds:CanonicalizationMethod Algorithm="http://www.w3.org/2006/12/xml-c14n11"/>
                                        <ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256"/>
                                        <ds:Reference Id="invoiceSignedData" URI="">
                                            <ds:Transforms>
                                                <ds:Transform Algorithm="http://www.w3.org/TR/1999/REC-xpath-19991116">
                                                    <ds:XPath>not(//ancestor-or-self::ext:UBLExtensions)</ds:XPath>
                                                </ds:Transform>
                                                <ds:Transform Algorithm="http://www.w3.org/TR/1999/REC-xpath-19991116">
                                                    <ds:XPath>not(//ancestor-or-self::cac:Signature)</ds:XPath>
                                                </ds:Transform>
                                                <ds:Transform Algorithm="http://www.w3.org/TR/1999/REC-xpath-19991116">
                                                    <ds:XPath>not(//ancestor-or-self::cac:AdditionalDocumentReference[cbc:ID='QR'])</ds:XPath>
                                                </ds:Transform>
                                                <ds:Transform Algorithm="http://www.w3.org/2006/12/xml-c14n11"/>
                                            </ds:Transforms>
                                                <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
                                                <ds:DigestValue>"""
            + self.gethash(self.invoce["invoiceSignedData"])
            + """</ds:DigestValue>
                                            </ds:Reference>
                                            <ds:Reference Type="http://www.w3.org/2000/09/xmldsig#SignatureProperties" URI="#xadesSignedProperties">
                                                <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
                                                <ds:DigestValue>"""
            + SignedProperties_hash
            + """</ds:DigestValue>
                                            </ds:Reference>
                                        </ds:SignedInfo>
                                        <ds:SignatureValue>"""
            + SignatureValue
            + """</ds:SignatureValue>
                                        <ds:KeyInfo>
                                            <ds:X509Data>
                                                <ds:X509Certificate>"""
            + self.invoce["X509Certificate"]
            + """</ds:X509Certificate>
                                            </ds:X509Data>
                                        </ds:KeyInfo>
                                        <ds:Object>
                                            <xades:QualifyingProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Target="signature">
                                                <xades:SignedProperties Id="xadesSignedProperties">
                                                    <xades:SignedSignatureProperties>
                                                        <xades:SigningTime>"""
            + self.invoce["SigningTime"]
            + """</xades:SigningTime>
                                                        <xades:SigningCertificate>
                                                            <xades:Cert>
                                                                <xades:CertDigest>
                                                                    <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
                                                                    <ds:DigestValue>"""
            + self.invoce["CertDigest"]
            + """</ds:DigestValue>
                                                                </xades:CertDigest>
                                                                <xades:IssuerSerial>
                                                                    <ds:X509IssuerName>"""
            + self.invoce["X509IssuerName"]
            + """</ds:X509IssuerName>
                                                                    <ds:X509SerialNumber>"""
            + self.invoce["X509SerialNumber"]
            + """</ds:X509SerialNumber>
                                                                </xades:IssuerSerial>
                                                            </xades:Cert>
                                                        </xades:SigningCertificate>
                                                    </xades:SignedSignatureProperties>
                                                </xades:SignedProperties>
                                            </xades:QualifyingProperties>
                                        </ds:Object>
                                    </ds:Signature>
                                </sac:SignatureInformation>
                            </sig:UBLDocumentSignatures>
                        </ext:ExtensionContent>
                    </ext:UBLExtension>
                </ext:UBLExtensions>"""
        )
        xmlDoc = (
            xml_doc_0
            + "\n"
            + xml_doc_1
            + "\n"
            + xml_doc_2
            + "\n"
            + xml_doc_3
            + "\n"
            + xml_doc_4
        )
        script_dir = os.path.dirname(__file__)
        t = time.localtime()
        vat = self.invoce["AccountingSupplierParty"]["CompanyID"]
        timestamp = time.strftime("%Y%m%dT%H%M%S", t)
        year_str = time.strftime("%Y", t)
        month_str = time.strftime("%m", t)
        BACKUP_NAME = vat + "_" + timestamp + "_" + self.invoce["cbc:ID"] + ".xml"
        xml_export = os.path.join(script_dir, "..", "xml_export", year_str, month_str)
        isExist = os.path.exists(xml_export)
        if not isExist:
            os.makedirs(xml_export)
        xml_export = os.path.join(
            script_dir, "..", "xml_export", year_str, month_str, BACKUP_NAME
        )
        f = open(xml_export, "w+")
        # new_xml = ""
        # for line in xmlDoc.splitlines():
        #    new_xml = new_xml + line[8:] +'\n'
        # f.write(new_xml)
        # f.write(xmlDoc )
        f.write(xmlDoc.replace("  ", ""))
        f.close()


def export():
    invoce = {}
    XML = createXML(invoce)
    script_dir = os.path.dirname(__file__)
    zatca_dir = os.path.join(script_dir, "..", "private", "zatca.json")
    jsonFile = open(zatca_dir, "r")
    data = json.load(jsonFile)
    jsonFile.close()
    x509 = data["csr_zatca"]["binarySecurityToken"]
    xadesSignedProperties = data["privatekey"]
    privatekey = data["privatekey"]
    date_time_now = strftime("%Y-%m-%dT%H:%M:%S", gmtime())
    invoce = {
        "privatekey": data["privatekey"],
        "invoiceSignedData": "105",  # invoce hash
        "xadesSignedProperties": XML.gethash(xadesSignedProperties),  # sing hash
        "SignatureValue": XML.gethash(privatekey),  # private key
        "X509Certificate": x509,  # ok
        "SigningTime": date_time_now,  # <---------- ok
        "CertDigest": data[
            "certificate_hash"
        ],  # Generate Certificate Hash <---------- ok
        "X509IssuerName": data[
            "csr_organization_name"
        ],  # from config name <---------- ok
        "X509SerialNumber": data["csr_common_name"],  # from config sn <---------- ok
        "ProfileID": "reporting:1.0",
        "cbc:ID": "105",  # invoce no
        "UUID": "16e78469-6Aaf-406d-9cfd-895e724198f0",
        "cbc:IssueDate": "2022-03-13",
        "cbc:IssueTime": "14:40:40",
        "cbc: InvoiceTypeCode_name": "0200000",
        "cbc:InvoiceTypeCode": "388",
        "PIH": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
        "AccountingSupplierParty": {
            "ID": "5855340398",  # السجل التجاري
            "StreetName": "test",
            "BuildingNumber": "3454",
            "PlotIdentification": "1234",
            "CitySubdivisionName": "test",
            "CityName": "Riyadh",
            "PostalZone": "12345",
            "CountrySubentity": "test",
            "CompanyID": "310232266400003",
            "PartyLegalEntity": "EbdaeDevelopmentandProgramming",
        },
        "AccountingCustomerParty": {
            "ID": "2345",
            "StreetName": "baaoun",
            "BuildingNumber": "3353",
            "PlotIdentification": "1234",
            "CitySubdivisionName": "test",
            "CityName": "Riyadh",
            "PostalZone": "12345",
            "CountrySubentity": "test",
            "CompanyID": "300075588700003",
            "PartyLegalEntity": "EbdaeDevelopmentandProgramming",
        },
        "ActualDeliveryDate": "2023-01-10",
        "LatestDeliveryDate": "2023-01-10",
        "PaymentMeansCode": "10",
        "AllowanceCharge": {
            "ID": "1",
            "ChargeIndicator": "false",
            "AllowanceChargeReason": "discount",
            "Amount": "2",
            "Percent": "15",
        },
        "cac:TaxTotal": {
            "TaxAmount": "144.9",
            "TaxableAmount": "966.00",
            "Percent": "15",
        },
        "LegalMonetaryTotal": {
            "LineExtensionAmount": "966.00",
            "TaxExclusiveAmount": "964.00",
            "TaxInclusiveAmount": "1108.90",
            "AllowanceTotalAmount": "2.00",
            "PrepaidAmount": "0.00",
            "PayableAmount": "1108.90",
        },
        "InvoiceLine": {
            "ID": "1",
            "InvoicedQuantity": "44.00",
            "LineExtensionAmount": "966.00",
            "TaxAmount": "144.90",
            "RoundingAmount": "1110.90",
            "Item": {
                "Name": "******",
                "Percent": "15",
            },
            "PriceAmount": "22.00",
            "ChargeIndicator": "false",
            "AllowanceChargeReason": "discount",
            "Amount": "2.00",
        },
    }
    XML = createXML(invoce)
    XML.exportXML()
    return "ok"
