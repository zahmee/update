# type: ignore

from datetime import date, datetime
import send_sms as sms
import json
import os, json, hashlib
from base64 import b64decode, b64encode
from io import BytesIO
from gluon import current
from share import say_hello
import requests
import httpx

# import qrcode

payment_means_codes = {
    "10": {
        "ar": "نقدًا",
        "en": "Cash"
    },
    "20": {
        "ar": "شيك",
        "en": "Cheque"
    },
    "30": {
        "ar": "تحويل بنكي",
        "en": "Credit Transfer"
    },
    "31": {
        "ar": "إيداع لحساب بنكي",
        "en": "Payment to Bank Account"
    },
        "42": {
        "ar": "بطاقة دفع (مدى/فيزا/ماستر)",
        "en": "Payment Card"
    },
    "48": {
        "ar": "دفع عبر محفظة إلكترونية",
        "en": "Mobile Payment"
    },
    "1": {
        "ar": "وسيلة دفع غير محددة",
        "en": "Instrument Not Defined"
    },
    "97": {
        "ar": "مقاصة بين طرفين",
        "en": "Clearing Between Partners"
    },
    "ZZZ": {
        "ar": "وسيلة دفع مخصصة",
        "en": "Custom Payment Method"
    }
}

@can_access(4001)
def index():
    return dict()


def getco():
    qry = (
        "select * from customers where id="
        + request.args(0)
        + " or mobile='"
        + request.args(0)
        + "'"
    )  # db.customers[request.args(0)] #
    custdata = db.executesql(qry, as_dict=True)
    lastpay = 0
    if custdata:
        qry = (
            "update customers set total = (select sum(total_after_discount) from invoice_master "
            " where payment_method=3 and customer ="
            + str(custdata[0]["id"])
            + " ) , payed=( select sum(amount) "
            " from customers_pay where customers_id =" + str(custdata[0]["id"]) + ") , "
            " amount = (select sum(total_after_discount) from invoice_master where "
            " payment_method=3 and customer ="
            + str(custdata[0]["id"])
            + " ) -( select sum(amount) "
            " from customers_pay where customers_id ="
            + str(custdata[0]["id"])
            + ")  where "
            "id = " + str(custdata[0]["id"])
        )
        db.executesql(qry)
        cus = (
            db(db.customers_pay.customers_id == custdata[0]["id"])
            .select(
                db.customers_pay.ALL,
                orderby=~db.customers_pay.modified_on,
                limitby=(0, 1),
            )
            .first()
        )
        if cus:
            now = datetime.datetime.now()
            lastpay = (now - cus.modified_on).days
        else:
            lastpay = 0
        qry = "select * from customers where id=" + str(custdata[0]["id"])
        custdata = db.executesql(qry, as_dict=True)
        custdata[0]["lastpay"] = lastpay
        if custdata[0]["payed"] == None:
            custdata[0]["payed"] = 0
        if custdata[0]["amount"] == None:
            custdata[0]["amount"] = 0
    return response.json(custdata)


def get_payment_method():
    q = db(db.key_payment_method.id > 0).select()
    return response.json(q)


def get_key_type():
    q = db(db.key_type.id > 0).select()
    return response.json(q)


def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


def offer_price():
    return dict()


@can_access(4001)
def op_save():
    try:
        # import uuid
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.offer_price.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        for i in itm["itm"]:
            db.offer_price_details.insert(
                item_dis=i["item_dis"],
                item_count=i["item_count"],
                amount=i["item_price"],
                total=i["total_price"],
                uuid=uuid,
                total_after_discount=i["total_price"],
                vat_total=i["total_vat"],
                vat=i["item_vat"],
                key_type=i["type"],
            )
        invno = db.offer_price.insert(
            customer=itm["customer"],
            customer_info=itm["customer_info"],
            total=itm["net_total"],
            payment_method=itm["method"],
            total_after_discount=itm["total_all"],
            uuid=uuid,
            vat=itm["vat"],
            disc=itm["disc"],
        )
        db.commit()
        ret = {"err": 0, "invno": invno, "mess": "0"}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


def invoice():
    return dict()


# حفظ الفواتير و ارسالها الى الهيئة
@can_access(4001)
def save():
    try:
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        sim_invoce = True 
        inv_type = "SIMSI"
        if itm["customer"] > 1 :
            customar = db.customers[itm["customer"]]
            if customar.vat and len( customar.vat ) >0 and len( customar.crn ) >0 :
                sim_invoce = False
                inv_type = "STDSI"
        configuration = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        ## يتم هنا ارسال الفاتورة و معالجتها من هيئة الزكاة
        if csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0:
            # ========== ارسال الفاتورة الى الهيئة  ========
            headers = {}
            headers["Content-Type"] = "application/json"
            headers["accept"] = "application/json"
            json_inv = generate_invoice_json(itm, inv_type)
            # json_string = json.dumps(json_inv, ensure_ascii=False, indent=4)
            url = "http://localhost:8011/zatca/process-one"
            resp = httpx.post(url, json=json_inv, headers=headers)
            if resp.status_code == 200:
                api_response = resp.json()
                if inv_type == "SIMSI":
                    if api_response["raw_response"]["reportingStatus"] == "REPORTED":
                        itm.pih_txt = api_response["pih_base64"]
                        itm.qr_code = api_response["qr_value"]
                        itm.send_to_zatca = True
                        itm.zatca_res = json.dumps(api_response, ensure_ascii=False)
                    else:
                        itm.send_to_zatca=False
                        itm.zatca_res=json.dumps(api_response, ensure_ascii=False)
                        itm.pih_txt=""
                        itm.qr_code=""
                else:
                    if api_response["raw_response"]["clearanceStatus"] == "CLEARED":
                        api_response["raw_response"]["clearedInvoice"] = ""
                        itm.send_to_zatca=True
                        itm.zatca_res=json.dumps(api_response, ensure_ascii=False)
                        itm.pih_txt=api_response["pih_base64"]
                        itm.qr_code=api_response["qr_value"]
                    else:
                        itm.send_to_zatca=False
                        itm.zatca_res=json.dumps(api_response, ensure_ascii=False)
                        itm.pih_txt=""
                        itm.qr_code=""
            if itm.qr_code and len(itm.qr_code) > 10:
                n_icv = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=n_icv, pih=itm.pih_txt)
                db.commit()
            # ================================================
            for i in itm["itm"]:
                db.invoice_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.invoice_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce = sim_invoce ,
                send_to_zatca = itm.send_to_zatca,
                zatca_res = itm.zatca_res,
                pih_txt = itm.pih_txt,
                qr_code = itm.qr_code
            )
            db.commit()
            itm.inove_no = invno
            if configuration.send_sms:
                costmer = db.customers[itm["customer"]]
                if costmer.mobile:
                    if len(costmer.mobile) == 10:
                        p = sms.SMS()
                        ms = (
                            "شكرا لزيارتك "
                            + configuration.name
                            + "تم اصدار فاتورة بمبلغ"
                            + itm["total_all"]
                        )
                        p.send("+966" + costmer.mobile[1:], ms)
            # update_invoce = db.invoice_master[invno]
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
        else:
            for i in itm["itm"]:
                db.invoice_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.invoice_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce=sim_invoce,
            )
            db.commit()
            itm.inove_no = invno
            ret = {"err": 0, "invno": invno, "mess": "0"}
            if configuration.send_sms:
                costmer = db.customers[itm["customer"]]
                if costmer.mobile:
                    if len(costmer.mobile) == 10:
                        p = sms.SMS()
                        ms = (
                            "شكرا لزيارتك "
                            + configuration.name
                            + "تم اصدار فاتورة بمبلغ"
                            + itm["total_all"]
                        )
                        p.send("+966" + costmer.mobile[1:], ms)
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
        return response.json(
            {"err": 4, "invno": 0, "mess": "لم يتم اعداد الاتصال بالهيئة"}
        )
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)

# مرتجع البيع
@can_access(4002)
def inv_return():
    return dict()


# @can_access(4002)
# def inv_return_save():
#     try:
#         ret = {"err": 3, "invno": 0, "mess": e}
#         return gluon.contrib.simplejson.dumps(ret)
#     except Exception as e:
#         db.rollback()
#         ret = {"err": 3, "invno": 0, "mess": e}
#         return gluon.contrib.simplejson.dumps(ret)


@can_access(4002)
def saver():
    try:
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.inv_return_master.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        sim_invoce = True
        inv_type = "SIMCN"
        if itm["customer"] > 1:
            customar = db.customers[itm["customer"]]
            if customar.vat and len(customar.vat) > 0 and len(customar.crn) > 0:
                sim_invoce = False
                inv_type = "STDCN"
        configuration = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        ## يتم هنا ارسال الفاتورة و معالجتها من هيئة الزكاة
        if csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0:
            # ========== ارسال الفاتورة الى الهيئة  ========
            headers = {}
            headers["Content-Type"] = "application/json"
            headers["accept"] = "application/json"
            json_inv = generate_invoice_json(itm, inv_type)
            # json_string = json.dumps(json_inv, ensure_ascii=False, indent=4)
            url = "http://localhost:8011/zatca/process-one"
            resp = httpx.post(url, json=json_inv, headers=headers)
            if resp.status_code == 200:
                api_response = resp.json()
                if inv_type == "SIMCN":
                    if api_response["raw_response"]["reportingStatus"] == "REPORTED":
                        itm.pih_txt = api_response["pih_base64"]
                        itm.qr_code = api_response["qr_value"]
                        itm.send_to_zatca = True
                        itm.zatca_res = json.dumps(api_response, ensure_ascii=False)
                    else:
                        itm.send_to_zatca = False
                        itm.zatca_res = json.dumps(api_response, ensure_ascii=False)
                        itm.pih_txt = ""
                        itm.qr_code = ""
                else:
                    if api_response["raw_response"]["clearanceStatus"] == "CLEARED":
                        api_response["raw_response"]["clearedInvoice"] = ""
                        itm.send_to_zatca = True
                        itm.zatca_res = json.dumps(api_response, ensure_ascii=False)
                        itm.pih_txt = api_response["pih_base64"]
                        itm.qr_code = api_response["qr_value"]
                    else:
                        itm.send_to_zatca = False
                        itm.zatca_res = json.dumps(api_response, ensure_ascii=False)
                        itm.pih_txt = ""
                        itm.qr_code = ""
            if itm.qr_code and len(itm.qr_code) > 10:
                n_icv = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=n_icv, pih=itm.pih_txt)
                db.commit()
            # ================================================
            for i in itm["itm"]:
                db.inv_return_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.inv_return_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce=sim_invoce,
                send_to_zatca=itm.send_to_zatca,
                zatca_res=itm.zatca_res,
                pih_txt=itm.pih_txt,
                qr_code=itm.qr_code,
            )
            db.commit()
            itm.inove_no = invno
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
        else:
            for i in itm["itm"]:
                db.inv_return_details.insert(
                    item_dis=i["item_dis"],
                    item_count=i["item_count"],
                    amount=i["item_price"],
                    total=i["total_price"],
                    uuid=uuid,
                    total_after_discount=i["total_price"],
                    vat_total=i["total_vat"],
                    vat=i["item_vat"],
                    key_type=i["type"],
                )
            invno = db.inv_return_master.insert(
                customer=itm["customer"],
                customer_info=itm["customer_info"],
                total=itm["net_total"],
                payment_method=itm["method"],
                total_after_discount=itm["total_all"],
                uuid=uuid,
                vat=itm["vat"],
                sim_invoce=sim_invoce,
            )
            db.commit()
            itm.inove_no = invno
            ret = {"err": 0, "invno": invno, "mess": "0"}
            db.commit()
            ret = {"err": 0, "invno": invno, "mess": "0"}
            return response.json(ret)
        return response.json(
            {"err": 4, "invno": 0, "mess": "لم يتم اعداد الاتصال بالهيئة"}
        )
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


def show_one_invoce_r():
    return dict()


def invoice_print_min_r():
    return dict()


def invoice_print_r():
    return dict()


# ==========================================       نهاية مرتجع البيع  ==============================================================================
# تقارير الفواتير و المبيعات
# -----------------------------------------------------------------------------


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def inv_rep1():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.invoice_master.created_on >= request.vars.da1)
        & (db.invoice_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate2():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.inv_return_master.created_on >= request.vars.da1)
        & (db.inv_return_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate3():
    # sum = db.invoice_master.total_after_discount.sum()
    s = (
        "select EXTRACT(HOUR FROM created_on),count(*),sum(total_after_discount) from invoice_master where created_on >= timestamp '"
        + request.vars.da1
        + "' and created_on <= timestamp '"
        + request.vars.da2
        + "'  group by EXTRACT(HOUR FROM created_on) order by EXTRACT(HOUR FROM created_on) "
    )
    custdata = db.executesql(s, as_dict=True)
    return response.json(custdata)


# ==============================================================  استعراض فاتورة مسجلة  =================================================================
@can_access(4003)
def inv_view():
    sc = screens_rules(4003)
    return dict(sc=sc)


@can_access(4003)
def inv_view_1():
    if request.args(0) == "1":
        qry = db.invoice_master[request.args(1)]
        if qry:
            qry.pyer = (
                (qry.created_by.first_name or "")
                + " "
                + (qry.created_by.last_name or "")
            )
            data = db(
                (db.invoice_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.invoice_details.uuid == qry.uuid)
            ).select(
                (db.invoice_details.item_number).with_alias("item_number"),
                (db.invoice_details.amount).with_alias("amount"),
                (db.invoice_details.item_count).with_alias("item_count"),
                (db.invoice_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.invoice_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""
    else:
        qry = db.inv_return_master[request.args(1)]
        if qry:
            qry.pyer = qry.created_by.first_name + " " + qry.created_by.last_name
            data = db(
                (db.inv_return_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.inv_return_details.uuid == qry.uuid)
            ).select(
                (db.inv_return_details.item_number).with_alias("item_number"),
                (db.inv_return_details.amount).with_alias("amount"),
                (db.inv_return_details.item_count).with_alias("item_count"),
                (db.inv_return_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.inv_return_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""


@can_access(4003)
def inv_view_2():
    sc = screens_rules(4003)
    if sc.can_delete:
        if request.args(0) == "1":
            qry1 = db.invoice_master[request.args(1)]
            db(db.invoice_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"
        else:
            qry1 = db.inv_return_master[request.args(1)]
            db(db.inv_return_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"


# بحث عن عميل
def search_c():
    # q = db.items_main[request.vars.itid]
    newstr = request.vars.itid  # .replace("'", "")
    # qry = "select * from items_main where name::text like '%"+str(newstr)+"%'  LIMIT 10 ;"
    q = db(db.customers.name.like("%" + newstr + "%")).select()
    # data = db.executesql(qry, as_dict=True)
    return response.json(q)
    # return q


# =================================================================================================================================================
@auth.requires_membership("user1")
def delete_inv():
    return dict()


@can_access(4003)
def invoice_show():
    q = db.invoice_master.customer
    db.invoice_master.created_on.readable = True
    headers = {
        "invoice_master.id": "رقم الفاتورة",
        "invoice_master.customer": "العميل",
        "invoice_master.payment_method": "طريقة الدفع",
        "invoice_master.total_after_discount": "صافي الفااتورة",
        "invoice_master.vat": "الضريبة",
        "invoice_master.created_on": "تاريخ و وقت الفاتورة",
        "invoice_master.send_to_zatca": "تم الارسال",
    }
    fields = [
        db.invoice_master.id,
        db.invoice_master.customer,
        db.invoice_master.payment_method,
        db.invoice_master.total_after_discount,
        db.invoice_master.vat,
        db.invoice_master.created_on,
        db.invoice_master.send_to_zatca,
    ]
    links = [
        lambda row: A(
            IMG(_src="../static/svg/002/014-invoice.svg", _width="24px"),
            _role="button",
            _title="الفاتور المبسطة",
            _target="_self",
            _href=URL("invoice", "invoice_print_min", args=[row.id]),
        ),
        lambda row: A(
            IMG(_src="../static/svg/002/023-invoice.svg", _width="24px"),
            _role="button",
            _title="الفاتور التفصيلية",
            _target="_self",
            _href=URL("invoice", "invoice_print", args=[row.id]),
        ),
        
    ]
    #lambda row: A(
    #    IMG(_src="../static/svg/edit.svg", _width="24px"),
    #    _role="button",
    #    _title="تعديل بيانات الفاتورة",
    #    _target="_self",
    #    _href=URL("invoice", "invoice_edit", args=[row.id]),
    #),
    # lambda row: A(IMG(
    #     _src="../static/svg/002/002-tax.svg",
    #     _width="24px" ),
    #     _role="button" ,
    #     _title="تصدير الفاتورة" ,
    #     _target="_self" ,
    #     _href=URL("exportxml", "export", args=[row.id])
    # ) ,
    #             lambda row: A(IMG(
    #     _src="../static/svg/002/126-text.svg",
    #     _width="24px" ),
    #     _role="button" ,
    #     _title="تصدير الى XML" ,
    #     _target="_blank" ,
    #     _href=URL("invoice","invoice_print_xml",args=[row.id])
    # ) ,

    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.invoice_master.id,
    )
    return dict(grid=grid)


def invoice_print():
    return dict()


def invoice_print_min():
    return dict()


def show_one_invoce():
    return dict()


@can_access(4003)
def invoice_show_r():
    q = db.inv_return_master.customer
    db.inv_return_master.created_on.readable = True
    headers = {
        "inv_return_master.id": "رقم الفاتورة",
        "inv_return_master.customer": "العميل",
        "inv_return_master.payment_method": "طريقة الدفع",
        "inv_return_master.total_after_discount": "صافي الفااتورة",
        "inv_return_master.vat": "الضريبة",
        "inv_return_master.created_on": "تاريخ و وقت الفاتورة",
        "inv_return_master.send_to_zatca": "تم الارسال",
    }
    fields = [
        db.inv_return_master.id,
        db.inv_return_master.customer,
        db.inv_return_master.payment_method,
        db.inv_return_master.total_after_discount,
        db.inv_return_master.vat,
        db.inv_return_master.created_on,
        db.inv_return_master.send_to_zatca,
    ]
    links = [
        lambda row: A(
            IMG(_src="../static/svg/002/014-invoice.svg", _width="24px"),
            _role="button",
            _title="الفاتور المبسطة",
            _target="_blank",
            _href=URL("invoice", "invoice_print_min_r", args=[row.id]),
        ),
        lambda row: A(
            IMG(_src="../static/svg/002/023-invoice.svg", _width="24px"),
            _role="button",
            _title="الفاتور التفصيلية",
            _target="_blank",
            _href=URL("invoice", "invoice_print_r", args=[row.id]),
        ),
    ]
    #             lambda row: A(IMG(
    #     _src="../static/svg/002/126-text.svg",
    #     _width="24px" ),
    #     _role="button" ,
    #     _title="تصدير الى XML" ,
    #     _target="_blank" ,
    #     _href=URL("invoice","invoice_print_xml_r",args=[row.id])
    # ) ,

    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.inv_return_master.id,
    )
    return dict(grid=grid)


def invoice_edit():
    return dict()


def update_invoice():
    if request.vars.id:
        inv = db.invoice_master[request.vars.id]
        if inv:
            inv.customer = request.vars.a2
            inv.payment_method = request.vars.a1
            customer_info = (
                '{"name":"'
                + str(request.vars.a3)
                + '", "vat": "'
                + str(request.vars.a4)
                + '" }'
            )
            inv.customer_info = customer_info
            inv.update_record()
            db.commit()
            return redirect(URL("invoice", "invoice_show"))
    return "ok"


def get_sample_item():
    q = db(db.sample_item.id > 0).select()
    return response.json(q)


def offer_price_show():
    q = db.offer_price.customer
    db.offer_price.created_on.readable = True
    headers = {
        "offer_price.id": "رقم العرض",
        "offer_price.customer": "العميل",
        "offer_price.payment_method": "طريقة الدفع",
        "offer_price.total_after_discount": "صافي الفااتورة",
        "offer_price.vat": "الضريبة",
        "offer_price.created_on": "تاريخ و وقت الفاتورة",
    }
    fields = [
        db.offer_price.id,
        db.offer_price.customer,
        db.offer_price.payment_method,
        db.offer_price.total_after_discount,
        db.offer_price.vat,
        db.offer_price.created_on,
    ]
    links = [
        lambda row: A(
            IMG(_src="../static/svg/002/023-invoice.svg", _width="24px"),
            _role="button",
            _title="طباعة عرض السعر",
            _target="_self",
            _href=URL("invoice", "offer_price_print", args=[row.id]),
        ),
    ]

    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.offer_price.id,
    )
    return dict(grid=grid)


def offer_price_print():
    return dict()


"""=======================---------************--------------========================="""
def to_tlv(tag: int, value: str) -> bytes:
    value_bytes = value.encode("utf-8")
    return bytes([tag]) + bytes([len(value_bytes)]) + value_bytes


def generate_qr_base64(
    seller_name, seller_vat, invoice_datetime, total_with_vat, vat_amount, signature
):
    tlv_data = b"".join(
        [
            to_tlv(1, seller_name),
            to_tlv(2, seller_vat),
            to_tlv(3, invoice_datetime),
            to_tlv(4, f"{float(total_with_vat):.2f}"),
            to_tlv(5, f"{float(vat_amount):.2f}"),
            to_tlv(6, signature),
        ]
    )
    return b64encode(tlv_data).decode("utf-8")

data = {
    "cert_info": {
        "privateKey": "",
        "csr": "",
        "pcsid_binarySecurityToken": "",
        "pcsid_secret": "",
        "environment": "Simulation",
        "reportingUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/reporting/single",
        "clearanceUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/clearance/single"
    },
    "input_xml": {
        "xml_template_path": "xxx.xml"
    },
    "document_type": "SIMSI",
    "invoice_number": "DOC-0001",
    "icv_start": 1,
    "pih_base64": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
    "invoice": {
        "ProfileID": "reporting:1.0",
        "ID": "SME00011",
        "UUID": "8e6000cf-1a98-4500-b3e7-b5d5954bc10d",
        "IssueDate": "2025-11-25",
        "IssueTime": "02:30:08",
        "InvoiceTypeCode": "388",
        "InvoiceTypeCodeName": "0200000",
        "Note": "",
        "DocumentCurrencyCode": "SAR",
        "TaxCurrencyCode": "SAR",
        "BillingReference": "",
        "AdditionalDocumentReferences": [
            {
                "ID": "ICV",
                "UUID": "10"
            },
            {
                "ID": "PIH",
                "Attachment": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
                "FileName": "pih.txt"
            }
        ],
        "SupplierStreetName": "1234 Street",
        "SupplierBuildingNumber": "2322",
        "SupplierCityName": "Riyadh",
        "SupplierDistrict": "Al-Murabba",
        "SupplierPostalZone": "23333",
        "SupplierCountryCode": "SA",
        "SupplierVAT": "",
        "SupplierName": "",
        "SupplierSchemeID": "CRN",
        "SupplierCRN": "",
        "CustomerStreetName": "*",
        "CustomerBuildingNumber": "1111",
        "CustomerCityName": "*",
        "CustomerDistrict": "*",
        "CustomerPostalZone": "12345",
        "CustomerCountryCode": "SA",
        "CustomerVAT": "",
        "CustomerName": "****",
        "CustomerCRN": "",
        "DeliveryDate": "2025-01-01",
        "PaymentMeansCode": "10",
        "AllowanceCharge": {
            "ChargeIndicator": "False",
            "Reason": "discount",
            "Amount": 0.00,
            "TaxCategories": [
                {"ID": "S", "Percent": 15, "SchemeID": "VAT"}
            ]
        },
        "InvoiceLines": [
            {
                "ID": "1",
                "UnitCode": "PCE",
                "Quantity": 33,
                "LineExtensionAmount": 99.00,
                "TaxAmount": 14.85,
                "RoundingAmount": 113.85,
                "Name": "book",
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": 3.00,
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00
                }
            },
            {
                "ID": "2",
                "UnitCode": "PCE",
                "Quantity": 3,
                "LineExtensionAmount": 102.00,
                "TaxAmount": 15.30,
                "RoundingAmount": 117.30,
                "Name": "قلم",
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": 34.00,
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00
                }
            }
        ],
        "TaxAmount": 30.15,
        "TaxableAmount": 201.00,
        "TaxPercent": 15.00,
        "LineExtensionAmount": 201.00,
        "TaxExclusiveAmount": 201.00,
        "TaxInclusiveAmount": 231.15,
        "AllowanceTotalAmount": 0.00,
        "PrepaidAmount": 0.00,
        "PayableAmount": 231.15
    }
}

def generate_invoice_json(invo:dict, invtype:str) :
    try :
        last_invo = 0
        if invtype.endswith("SI") :
            max_no = db.invoice_master.id.max()
            last_invo = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0
        else :
            max_no = db.inv_return_master.id.max()
            last_invo = db(db.inv_return_master.id > 0).select(max_no).first()[max_no] or 0 
        impo_info = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        now = datetime.now()
        invoce = invo
        re_data = data
        re_data["cert_info"]["privateKey"] = csr_config.privatekey
        re_data["cert_info"]["csr"] = csr_config.csr
        re_data["cert_info"]["pcsid_binarySecurityToken"] = csr_config.pcsid_binarysecuritytoken
        re_data["cert_info"]["pcsid_secret"] = csr_config.pcsid_secret
        re_data["cert_info"]["environment"] = "Simulation"
        re_data["document_type"] = invtype
        re_data["invoice_number"] = "INV-" + str(last_invo+1).zfill(12)
        re_data["invoice"]["ID"] = "INV-" + str(last_invo+1).zfill(12)
        re_data["invoice"]["UUID"] = invoce.uuid
        re_data["invoice"]["IssueDate"] = now.strftime("%Y-%m-%d") # invoce.created_on.strftime("%Y-%m-%d")
        re_data["invoice"]["IssueTime"] = now.strftime("%H:%M:%S") # invoce.created_on.strftime("%H:%M:%S")
        re_data["invoice"]["AdditionalDocumentReferences"][0]["UUID"] = str(csr_config.icv) # ICV
        re_data["invoice"]["AdditionalDocumentReferences"][1]["Attachment"] = csr_config.pih # PIH
        # معلومات المورد
        re_data["invoice"]["SupplierStreetName"] = csr_config.address_street_name
        re_data["invoice"]["SupplierBuildingNumber"] = csr_config.address_building_number
        re_data["invoice"]["SupplierCityName"] = csr_config.address_city_name
        re_data["invoice"]["SupplierDistrict"] = csr_config.address_neighborhood
        re_data["invoice"]["SupplierPostalZone"] = csr_config.address_postal_zone
        re_data["invoice"]["SupplierVAT"] = csr_config.organization_identifier
        re_data["invoice"]["SupplierName"] = csr_config.organization_name
        re_data["invoice"]["SupplierCRN"] = csr_config.company_id
        # معلومات العميل
        if invtype.startswith("STD") :
            if invoce.customer > 1:
                customer = db.customers[invoce.customer]
                re_data["invoice"]["CustomerStreetName"]=  "main"
                re_data["invoice"]["CustomerBuildingNumber"]= "1111"
                re_data["invoice"]["CustomerCityName"]= "my city"
                re_data["invoice"]["CustomerDistrict"]= "my dist"
                re_data["invoice"]["CustomerPostalZone"]= "12345"
                re_data["invoice"]["CustomerCountryCode"]= "SA"
                re_data["invoice"]["CustomerVAT"]= customer.vat
                re_data["invoice"]["CustomerName"]= customer.name
                re_data["invoice"]["CustomerCRN"]= customer.crn
        re_data["invoice"]["PaymentMeansCode"] = "1"  # غير محددة
        # تفاصيل الاصناف
        # inv_items = db(db.invoice_details.uuid == invoce.uuid).select()
        inv_lines = []
        line_id = 1
        print("=============================================================")
        for item in invoce.itm :
            line = {
                "ID": str(line_id),
                "UnitCode": "PCE",
                "Quantity": float(item["item_count"]),
                "LineExtensionAmount": round(
                    (float(item["item_price"]) * float(item["item_count"])), 2
                ),
                "TaxAmount": float(item["total_vat"]),
                "RoundingAmount": round(float(item["total_price"]), 2),
                "Name": item["item_dis"],
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": round(
                    (float(item["item_price"]) ), 2
                ),
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00,
                },
            }
            inv_lines.append(line)
            line_id += 1

        re_data["invoice"]["InvoiceLines"] = inv_lines
        # القيم المالية
        re_data["invoice"]["TaxAmount"] = float(invoce.vat)
        re_data["invoice"]["TaxableAmount"] = float(invoce.net_total)
        re_data["invoice"]["TaxPercent"] = 15.00
        re_data["invoice"]["LineExtensionAmount"] = float(invoce.net_total)
        re_data["invoice"]["TaxExclusiveAmount"] = float(invoce.net_total)
        re_data["invoice"]["TaxInclusiveAmount"] = round(float(invoce.total_all), 2)
        re_data["invoice"]["AllowanceTotalAmount"] = 0.00
        re_data["invoice"]["PayableAmount"] = round(float(invoce.total_all), 2)
        # formatted_json = json.dumps(re_data, indent=4, ensure_ascii=False)
        # print(formatted_json)
        return re_data
    except Exception as e:
        print(f"error{e}")
        return str(e)
