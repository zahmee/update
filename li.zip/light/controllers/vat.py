# -*- coding: utf-8 -*-
# type: ignore

import xlsxwriter
import io
import sys

def index():
	response.title = "الرئيسية"
	return dict()

# تقرير بالاصناف
def excl_inv_det():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    if var2 == 11 :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = "
		" ( select customer from invoice_master  "
		"  where invoice_master.uuid = invoice_details.uuid ) ) as coust  , "
		"  ( select name from key_payment_method where id =  "
		"   ( select payment_method from invoice_master  "
		"    where invoice_master.uuid = invoice_details.uuid ) ) as payment_method  , "
		"    ( select id  from invoice_master  "
		" 	where invoice_master.uuid = invoice_details.uuid  ) as inv_no  , "
		" 	( select id from items_det where id = item_number ) as id_det , "
		" 	( select name from items_main where id =  "
		" 	 ( select item_idr from items_det where id = item_number ) ) as name , "
		" 	 vat , item_count ,created_on , "
		" 	  ( select public_price from items_det where id = item_number ) as price , "
		" 	   total , "
		" 	   vat_total "
		" 	 from invoice_details  where created_on > '"+sart_date+"' and created_on < '"+end_date+"'  " )
    q = db.executesql(qry, as_dict=True)
    # inf = db(db.information.id>0).select().first()
    # q = db((db.account_movement.date_year == inf.present_year ) and (db.account_movement.date_month == inf.present_month )).select()
    filename = 'excel_movment_det_ret_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()

    worksheet.write('A1', u'الفاتورة', bold  )
    worksheet.write('A1', u'الدفع', bold  )
    worksheet.write('A1', u'اسم العميل', bold  )
    worksheet.write('B1', u'رقم الصنف', bold  )
    worksheet.write('C1', u'اسم الصنف', bold  )
    worksheet.write('D1', u'VAT', bold )
    worksheet.write('E1', u' العدد', bold )
    worksheet.write('F1', u'المبلغ', bold )
    worksheet.write('G1', u'الاجمالي', bold )
    worksheet.write('H1', u'الضريبة المحصلة', bold )
    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 12)
    worksheet.set_column('E:E', 50)
    worksheet.set_column('F:F', 22)
    worksheet.set_column('G:G',12)
    worksheet.set_column('H:H', 20)
    worksheet.set_column('I:I', 20)
    worksheet.set_column('J:J', 20)
    worksheet.set_column('K:K', 20)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']         , format  )
        worksheet.write  ( row , col + 1  , r['payment_method']  , format  ) 
        worksheet.write  ( row , col + 2  , r['coust'] or '--'            , format  )
        worksheet.write  ( row , col + 3  , r['id_det']         , format  ) 
        worksheet.write  ( row , col + 4  , r['name'] or '--'            , format  )  
        worksheet.write  ( row , col + 5  , r['vat']            , format  )
        worksheet.write  ( row , col + 6  , float(r['item_count'] or 0 )    , format  )
        worksheet.write  ( row , col + 7  , float(r['price'] or 0  )        , format  )
        worksheet.write  ( row , col + 8  , float(r['total'] or 0  )        , format  )
        worksheet.write  ( row , col + 9  , float(r['vat_total'] or 0 )      , format  )
        worksheet.write  ( row , col + 10 , r['created_on']     , format2  )
        row += 1
    worksheet.add_table('A1:K'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'رقم الصنف' , 'header_format' : bold},
         {'header': u'اسم الصنف' , 'header_format' : bold },
         {'header': u'VAT', 'header_format' : bold },
         {'header': u' العدد' , 'header_format' : bold },
         {'header': u'المبلغ' , 'header_format' : bold },
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})

    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

#==============================================================================================================

def excl_inv_det_re():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    if var2 == 11 :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = "
		" ( select customer from inv_return_master  "
		"  where inv_return_master.uuid = inv_return_details.uuid ) ) as coust  , "
		"  ( select name from key_payment_method where id =  "
		"   ( select payment_method from inv_return_master  "
		"    where inv_return_master.uuid = inv_return_details.uuid ) ) as payment_method  , "
		"    ( select id  from inv_return_master  "
		" 	where inv_return_master.uuid = inv_return_details.uuid  ) as inv_no  , "
		" 	( select id from items_det where id = item_number ) as id_det , "
		" 	( select name from items_main where id =  "
		" 	 ( select item_idr from items_det where id = item_number ) ) as name , "
		" 	 vat , item_count ,created_on , "
		" 	  ( select public_price from items_det where id = item_number ) as price , "
		" 	   total , "
		" 	   vat_total "
		" 	 from inv_return_details  where created_on > '"+sart_date+"' and created_on < '"+end_date+"'  " )
    q = db.executesql(qry, as_dict=True)
    # inf = db(db.information.id>0).select().first()
    # q = db((db.account_movement.date_year == inf.present_year ) and (db.account_movement.date_month == inf.present_month )).select()
    filename = 'excel_movment_det_ret_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()

    worksheet.write('A1', u'الفاتورة', bold  )
    worksheet.write('A1', u'الدفع', bold  )
    worksheet.write('A1', u'اسم العميل', bold  )
    worksheet.write('B1', u'رقم الصنف', bold  )
    worksheet.write('C1', u'اسم الصنف', bold  )
    worksheet.write('D1', u'VAT', bold )
    worksheet.write('E1', u' العدد', bold )
    worksheet.write('F1', u'المبلغ', bold )
    worksheet.write('G1', u'الاجمالي', bold )
    worksheet.write('H1', u'الضريبة المحصلة', bold )
    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 12)
    worksheet.set_column('E:E', 50)
    worksheet.set_column('F:F', 22)
    worksheet.set_column('G:G',12)
    worksheet.set_column('H:H', 20)
    worksheet.set_column('I:I', 20)
    worksheet.set_column('J:J', 20)
    worksheet.set_column('K:K', 20)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']         , format  )
        worksheet.write  ( row , col + 3  , r['id_det']         , format  ) 
        worksheet.write  ( row , col + 1  , r['payment_method']  , format  ) 
        worksheet.write  ( row , col + 2  , r['coust']          , format  )
        worksheet.write  ( row , col + 4  , r['name']            , format  )  
        worksheet.write  ( row , col + 5  , r['vat']            , format  )
        worksheet.write  ( row , col + 6  , float(r['item_count'] or 0 )    , format  )
        worksheet.write  ( row , col + 7  , float(r['price'] or 0  )        , format  )
        worksheet.write  ( row , col + 8  , float(r['total'] or 0  )        , format  )
        worksheet.write  ( row , col + 9  , float(r['vat_total'] or 0 )      , format  )
        worksheet.write  ( row , col + 10 , r['created_on']     , format2  )
        row += 1
    worksheet.add_table('A1:K'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'رقم الصنف' , 'header_format' : bold},
         {'header': u'اسم الصنف' , 'header_format' : bold },
         {'header': u'VAT', 'header_format' : bold },
         {'header': u' العدد' , 'header_format' : bold },
         {'header': u'المبلغ' , 'header_format' : bold },
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})

    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

 #==============================================================================================================

def excl_inv_mas():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    end_date = ''
    if var2 == "12" :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = invoice_master.customer ) as coust  , "
	        " ( select name from key_payment_method where id = invoice_master.payment_method ) as payment_method  , "
	        "  id  as inv_no  , vat , created_on ,total  "
		    " from invoice_master  where created_on > '"+sart_date+"' and created_on < '"+end_date+"' " )
    q = db.executesql(qry, as_dict=True)
    filename = 'excel_movment_mas_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')
    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')
    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()
    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 20)
    worksheet.set_column('E:E', 20)
    worksheet.set_column('F:F', 22)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']  , format  )
        worksheet.write  ( row , col + 1  , r['payment_method'] or '-'  , format  )
        worksheet.write  ( row , col + 2  , r['coust'] or '-'    , format  )
        worksheet.write  ( row , col + 3  , (r['total'] or 0)  , format  )
        worksheet.write  ( row , col + 4  , (r['vat'] or 0 ) , format  )
        worksheet.write  ( row , col + 5 , r['created_on']   , format2  )
        row += 1
    worksheet.add_table('A1:F'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})

    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

 #==============================================================================================================

def excl_inv_mas_re():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    if var2 == "12" :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = inv_return_master.customer ) as coust  , "
	        " ( select name from key_payment_method where id = inv_return_master.payment_method ) as payment_method  , "
	        "  id  as inv_no  , vat , created_on ,total  "
		    " from inv_return_master  where created_on > '"+sart_date+"' and created_on < '"+end_date+"' " )
    q = db.executesql(qry, as_dict=True)
    filename = 'excel_movment_mas_ret_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()

    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 20)
    worksheet.set_column('E:E', 20)
    worksheet.set_column('F:F', 22)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']  , format  )
        worksheet.write  ( row , col + 1  , r['payment_method']  , format  )
        worksheet.write  ( row , col + 2  , r['coust']    , format  )
        worksheet.write  ( row , col + 3  , (r['total'] or 0)  , format  )
        worksheet.write  ( row , col + 4  , (r['vat'] or 0 ) , format  )
        worksheet.write  ( row , col + 5 , r['created_on']   , format2  )
        row += 1
    worksheet.add_table('A1:F'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})
    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

 #==============================================================================================================

