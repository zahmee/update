def save_inv_1():
    inv = db.invoice_master[request.args(1)]
    current_path = os.path.dirname(os.path.abspath(__file__))
    # print("\n3: Clearance & Reporting Documents\n")
    # print(current_path + "/../certificates/certificateInfo.json")
    cert_info = api_helper.load_json_from_file(
        current_path + "/../certificates/certificateInfo.json"
    )
    xml_str = inv["xml_file"]
    private_key = cert_info["privateKey"]
    x509_certificate_content = base64.b64decode(
        cert_info["pcsid_binarySecurityToken"]
    ).decode("utf-8")
    # print(x509_certificate_content)
    # print(json.dumps(cert_info, indent=4))
    parser = etree.XMLParser(remove_blank_text=False)
    base_document = etree.parse(
        StringIO(xml_str), parser
    )  # etree.fromstring(xml_str, parser)
    # print(etree.tostring(einvoice_signer.pretty_print_xml(base_document)))
    document_types = [
        ["STDSI", "388", "Standard Invoice", ""],
        [
            "STDCN",
            "383",
            "Standard CreditNote",
            "InstructionNotes for Standard CreditNote",
        ],
        [
            "STDDN",
            "381",
            "Standard DebitNote",
            "InstructionNotes for Standard DebitNote",
        ],
        ["SIMSI", "388", "Simplified Invoice", ""],
        [
            "SIMCN",
            "383",
            "Simplified CreditNote",
            "InstructionNotes for Simplified CreditNote",
        ],
        [
            "SIMDN",
            "381",
            "Simplified DebitNote",
            "InstructionNotes for Simplified DebitNote",
        ],
    ]

    icv = inv["id"]
    pih = inv["pih_txt"]

    for doc_type in document_types:
        prefix, type_code, description, instruction_note = doc_type
        icv += 1
        is_simplified = prefix.startswith("SIM")

        print(f"Processing {description}...\n")

        new_doc = invoice_helper.modify_xml(
            base_document,
            f"{prefix}-0001",
            "0200000" if is_simplified else "0100000",
            type_code,
            icv,
            pih,
            instruction_note,
        )
        json_payload = einvoice_signer.get_request_api(
            new_doc, x509_certificate_content, private_key
        )

        # print(json_payload)
        # print(cert_info["reportingUrl"])

        if einvoice_signer.is_simplified_invoice(new_doc):

            response = api_helper.invoice_reporting(cert_info, json_payload)
            request_type = "Reporting Api"
            api_url = cert_info["reportingUrl"]
        else:
            response = api_helper.invoice_clearance(cert_info, json_payload)
            request_type = "Clearance Api"
            api_url = cert_info["clearanceUrl"]

        clean_response = api_helper.clean_up_json(response, request_type, api_url)

        json_decoded_response = json.loads(response)

        if json_decoded_response:
            print(f"Reporting api Server Response: \n{clean_response}")
        else:
            print(f"Invalid JSON Response: \n{response}")
            exit(1)

        if response is None:
            print(f"Failed to process {description}: serverResult is null.\n")
            exit(1)

        status = (
            json_decoded_response["reportingStatus"]
            if is_simplified
            else json_decoded_response["clearanceStatus"]
        )

        if "REPORTED" in status or "CLEARED" in status:
            json_payload = json.loads(json_payload)
            pih = json_payload["invoiceHash"]
            print(f"\n{description} processed successfully\n\n")
        else:
            print(f"Failed to process {description}: status is {status}\n")
            exit(1)

        time.sleep(1)
    return "ok"
