# type: ignore

import os
import re
import base64
import hashlib
import json
import os
import re
import tempfile
from lxml import etree
import time
import requests
from requests.auth import HTTPBasicAuth
from cryptography.x509.oid import NameOID, ObjectIdentifier
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
from datetime import datetime
import uuid
import os
import re
import xml.etree.ElementTree as ET
from OpenSSL import crypto
from io import StringIO
import shutil
from datetime import date

class api_helper:

    @staticmethod
    def post_request_with_retries(
        url, headers, json_payload, auth=None, retries=3, backoff_factor=1
    ):
        for attempt in range(retries):
            try:
                # print(attempt)
                response = requests.post(
                    url, headers=headers, data=json_payload, auth=auth
                )
                # Check for HTTP errors
                if response.status_code != 200:
                    json_txt= json.loads(response.text)
                    #print(json.dumps(json_txt, indent=4))
                    raise Exception(
                        f"HTTP error: {response.status_code} - {response.text}"
                    ) 
                return response.text

            except requests.exceptions.ConnectionError as e:
                print(f"ConnectionError: {e}. Attempt {attempt + 1} of {retries}.")
                if attempt < retries - 1:
                    time.sleep(backoff_factor * (2**attempt))  # Exponential backoff
                else:
                    raise  # Re-raise the last exception if all retries fail

    @staticmethod
    def compliance_csid(cert_info, retries=3, backoff_factor=1):
        csr = cert_info["csr"]
        OTP = cert_info["OTP"]
        url = cert_info["complianceCsidUrl"]

        json_payload = json.dumps({"csr": csr})

        headers = {
            "accept": "application/json",
            "accept-language": "en",
            "OTP": OTP,
            "Accept-Version": "V2",
            "Content-Type": "application/json",
        }

        return api_helper.post_request_with_retries(
            url, headers, json_payload, retries=retries, backoff_factor=backoff_factor
        )

    @staticmethod
    def production_csid(cert_info, retries=3, backoff_factor=1):
        request_id = cert_info["ccsid_requestID"]
        id_token = cert_info["ccsid_binarySecurityToken"]
        secret = cert_info["ccsid_secret"]
        url = cert_info["productionCsidUrl"]
        # print("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV")
        # print(request_id)
        # print(id_token)
        # print(secret)
        # print(url)
        # print("-----------------------------------")
        json_payload = json.dumps({"compliance_request_id": request_id})

        headers = {
            "accept": "application/json",
            "accept-language": "en",
            "Accept-Version": "V2",
            "Content-Type": "application/json",
        }

        auth = HTTPBasicAuth(id_token, secret)
        return api_helper.post_request_with_retries(
            url,
            headers,
            json_payload,
            auth=auth,
            retries=retries,
            backoff_factor=backoff_factor,
        )

    @staticmethod
    def compliance_checks(cert_info, json_payload, retries=3, backoff_factor=1):
        id_token = cert_info["ccsid_binarySecurityToken"]
        secret = cert_info["ccsid_secret"]
        url = cert_info["complianceChecksUrl"]

        headers = {
            "accept": "application/json",
            "accept-language": "en",
            "Accept-Version": "V2",
            "Content-Type": "application/json",
        }

        auth = HTTPBasicAuth(id_token, secret)
        return api_helper.post_request_with_retries(
            url,
            headers,
            json_payload,
            auth=auth,
            retries=retries,
            backoff_factor=backoff_factor,
        )

    @staticmethod
    def invoice_reporting(cert_info, json_payload, retries=3, backoff_factor=1):
        id_token = cert_info["pcsid_binarySecurityToken"]
        secret = cert_info["pcsid_secret"]
        url = cert_info["reportingUrl"]

        headers = {
            "accept": "application/json",
            "accept-language": "en",
            "Accept-Version": "V2",
            "Content-Type": "application/json",
        }

        auth = HTTPBasicAuth(id_token, secret)
        return api_helper.post_request_with_retries(
            url,
            headers,
            json_payload,
            auth=auth,
            retries=retries,
            backoff_factor=backoff_factor,
        )

    @staticmethod
    def invoice_clearance(cert_info, json_payload, retries=3, backoff_factor=1):
        """
        Sends an invoice clearance request to the specified clearance URL with retries and exponential backoff.

        Args:
            cert_info (dict): A dictionary containing certificate information, including:
                - 'pcsid_binarySecurityToken' (str): The ID token for authentication.
                - 'pcsid_secret' (str): The secret key for authentication.
                - 'clearanceUrl' (str): The URL to send the clearance request to.
            json_payload (dict): The JSON payload to be sent in the request body.
            retries (int, optional): The number of retry attempts in case of failure. Defaults to 3.
            backoff_factor (int, optional): The factor by which the delay between retries increases. Defaults to 1.

        Returns:
            Response: The HTTP response object returned by the API request.

        Raises:
            Exception: If the request fails after the specified number of retries.
        """
        id_token = cert_info["pcsid_binarySecurityToken"]
        secret = cert_info["pcsid_secret"]
        url = cert_info["clearanceUrl"]

        headers = {
            "accept": "application/json",
            "accept-language": "en",
            "Clearance-Status": "1",
            "Accept-Version": "V2",
            "Content-Type": "application/json",
        }

        auth = HTTPBasicAuth(id_token, secret)
        return api_helper.post_request_with_retries(
            url,
            headers,
            json_payload,
            auth=auth,
            retries=retries,
            backoff_factor=backoff_factor,
        )

    @staticmethod
    def load_json_from_file(file_path):
        try:
            with open(file_path, "r") as file:
                return json.load(file)
        except FileNotFoundError:
            raise Exception(f"File not found: {file_path}")
        except json.JSONDecodeError as e:
            raise Exception(f"Error parsing JSON: {str(e)}")

    @staticmethod
    def save_json_to_file(file_path, data):
        try:
            with open(file_path, "w") as file:
                json.dump(
                    data, file, indent=4, ensure_ascii=False, separators=(",", ": ")
                )
        except Exception as e:
            raise Exception(f"Error saving JSON: {str(e)}")

    @staticmethod
    def clean_up_json(api_response, request_type, api_url):
        array_response = json.loads(api_response)
        array_response["requestType"] = request_type
        array_response["apiUrl"] = api_url

        array_response = {k: v for k, v in array_response.items() if v is not None}

        reordered_response = {
            "requestType": array_response.pop("requestType"),
            "apiUrl": array_response.pop("apiUrl"),
            **array_response,
        }

        return json.dumps(
            reordered_response, indent=4, ensure_ascii=False, separators=(",", ": ")
        )


class CsrGenerator:
    def __init__(self, config, environment_type):
        self.config = config
        self.environment_type = environment_type
        self.asn_template = self.get_asn_template()

    def get_asn_template(self):
        if self.environment_type == "NonProduction":
            return "TSTZATCA-Code-Signing"
        elif self.environment_type == "Simulation":
            return "PREZATCA-Code-Signing"
        elif self.environment_type == "Production":
            return "ZATCA-Code-Signing"
        else:
            raise ValueError("Invalid environment type specified.")

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP256K1(), default_backend())

    def generate_csr(self):
        private_key = self.generate_private_key()

        # Build the CSR
        csr_builder = x509.CertificateSigningRequestBuilder()
        csr_builder = csr_builder.subject_name(
            x509.Name(
                [
                    x509.NameAttribute(
                        NameOID.COUNTRY_NAME, self.config.get("csr.country.name", "SA")
                    ),
                    x509.NameAttribute(
                        NameOID.ORGANIZATIONAL_UNIT_NAME,
                        self.config.get("csr.organization.unit.name", ""),
                    ),
                    x509.NameAttribute(
                        NameOID.ORGANIZATION_NAME,
                        self.config.get("csr.organization.name", ""),
                    ),
                    x509.NameAttribute(
                        NameOID.COMMON_NAME, self.config.get("csr.common.name", "")
                    ),
                ]
            )
        )

        # Add ASN.1 extension
        print(self.asn_template)
        print(self.asn_template.encode())
        csr_builder = csr_builder.add_extension(
            x509.UnrecognizedExtension(
                ObjectIdentifier("1.3.6.1.4.1.311.20.2"), self.asn_template.encode()
            ),
            critical=False,
        )

        # Add SAN extension
        csr_builder = csr_builder.add_extension(
            x509.SubjectAlternativeName(
                [
                    x509.DirectoryName(
                        x509.Name(
                            [
                                x509.NameAttribute(
                                    ObjectIdentifier("2.5.4.4"),
                                    self.config.get("csr.serial.number", ""),
                                ),
                                x509.NameAttribute(
                                    ObjectIdentifier("0.9.2342.19200300.100.1.1"),
                                    self.config.get("csr.organization.identifier", ""),
                                ),
                                x509.NameAttribute(
                                    ObjectIdentifier("2.5.4.12"),
                                    self.config.get("csr.invoice.type", ""),
                                ),
                                x509.NameAttribute(
                                    ObjectIdentifier("2.5.4.26"),
                                    self.config.get("csr.location.address", ""),
                                ),
                                x509.NameAttribute(
                                    ObjectIdentifier("2.5.4.15"),
                                    self.config.get(
                                        "csr.industry.business.category", ""
                                    ),
                                ),
                            ]
                        )
                    )
                ]
            ),
            critical=False,
        )

        # Sign the CSR with the private key
        csr = csr_builder.sign(private_key, hashes.SHA256(), default_backend())

        # Serialize private key and CSR
        private_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
        csr_pem = csr.public_bytes(serialization.Encoding.PEM)

        # Strip header/footer from private key
        private_key_content = re.sub(
            r"-----BEGIN .* PRIVATE KEY-----|-----END .* PRIVATE KEY-----|\n",
            "",
            private_key_pem.decode("utf-8"),
        )

        # Encode CSR in Base64
        csr_base64 = base64.b64encode(csr_pem).decode("utf-8")

        return private_key_content, csr_base64

    def save_to_files(self, private_key_pem, csr_pem):
        os.makedirs("certificates", exist_ok=True)
        private_key_file = "certificates/PrivateKey.pem"
        csr_file = "certificates/taxpayer.csr"

        with open(private_key_file, "wb") as key_file:
            key_file.write(private_key_pem)

        with open(csr_file, "wb") as csr_file:
            csr_file.write(csr_pem)

        print(
            f"\nPrivate key and CSR have been saved to {private_key_file} and {csr_file}, respectively."
        )


class einvoice_signer:
    @staticmethod
    def pretty_print_xml(xml):
        """Pretty print the XML."""
        # Convert the XML to a string and then parse it again to pretty print
        xml_string = etree.tostring(xml, pretty_print=True, encoding="UTF-8").decode(
            "UTF-8"
        )
        return etree.fromstring(xml_string)

    # @staticmethod
    # def get_request_api_from_file(xml_file_path, x509_certificate_content, private_key_content):
    #     # Open XML document with preserveWhiteSpace = true
    #     parser = etree.XMLParser(remove_blank_text=False)
    #     xml = etree.parse(xml_file_path, parser)
    #     return einvoice_signer.get_request_api(xml, x509_certificate_content, private_key_content)
    @staticmethod
    def get_request_api_from_file(
        xml_file_path, x509_certificate_content, private_key_content
    ):
        # Open XML document with preserveWhiteSpace = true
        parser = etree.XMLParser(remove_blank_text=False)
        xml = etree.parse(xml_file_path, parser)

        # Pretty print the XML before transformation
        xml = einvoice_signer.pretty_print_xml(xml)

        return einvoice_signer.get_request_api(
            xml, x509_certificate_content, private_key_content
        )

    # @staticmethod
    # def get_request_api(xml, x509_certificate_content, private_key_content):
    #     """Main function to process the invoice request."""
    #     # Define resource file paths
    #     resource_paths = {
    #         "xsl_file": 'resources/xslfile.xsl',
    #         "ubl_template": 'resources/zatca_ubl.xml',
    #         "signature": 'resources/zatca_signature.xml'
    #     }

    #     xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>'

    #     # Extract UUID from XML
    #     uuid = einvoice_signer.extract_uuid(xml)

    #     # Determine if the invoice is simplified
    #     is_simplified_invoice = einvoice_signer.is_simplified_invoice(xml)

    #     # Transform the XML using XSLT
    #     transformed_xml = einvoice_signer.transform_xml(xml, resource_paths["xsl_file"])

    #     # Canonicalize the transformed XML
    #     canonical_xml = einvoice_signer.canonicalize_xml(transformed_xml)

    #     # Generate the hash and encode the invoice
    #     base64_hash = einvoice_signer.generate_base64_hash(canonical_xml)
    #     base64_invoice = einvoice_signer.encode_invoice(xml_declaration, canonical_xml)

    #     # Prepare the result for non-simplified invoices
    #     if not is_simplified_invoice:
    #         return einvoice_signer.create_result(uuid, base64_hash, base64_invoice)

    #     # Sign the simplified invoice
    #     return einvoice_signer.sign_simplified_invoice(canonical_xml, base64_hash, x509_certificate_content, private_key_content, resource_paths["ubl_template"], resource_paths["signature"], uuid)

    @staticmethod
    def get_request_api(xml, x509_certificate_content, private_key_content):
        current_path = os.path.dirname(os.path.abspath(__file__))
        """Main function to process the invoice request."""
        # Define resource file paths
        resource_paths = {
            "xsl_file": current_path + "/" + "resources/xslfile.xsl",
            "ubl_template": current_path + "/" + "resources/zatca_ubl.xml",
            "signature": current_path + "/" + "resources/zatca_signature.xml",
        }

        xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>'

        # Extract UUID from XML
        uuid = einvoice_signer.extract_uuid(xml)

        # Determine if the invoice is simplified
        is_simplified_invoice = einvoice_signer.is_simplified_invoice(xml)

        # Transform the XML using XSLT
        transformed_xml = einvoice_signer.transform_xml(
            xml, (resource_paths["xsl_file"])
        )

        # Canonicalize the transformed XML
        canonical_xml = einvoice_signer.canonicalize_xml(transformed_xml)
        # print (canonical_xml)

        # Generate the hash and encode the invoice
        base64_hash = einvoice_signer.generate_base64_hash(canonical_xml)
        base64_invoice = einvoice_signer.encode_invoice(xml_declaration, canonical_xml)

        # Prepare the result for non-simplified invoices
        if not is_simplified_invoice:
            return einvoice_signer.create_result(uuid, base64_hash, base64_invoice)

        # Sign the simplified invoice
        if  is_simplified_invoice:
            print("i am hear")
        return einvoice_signer.sign_simplified_invoice(
            canonical_xml,
            base64_hash,
            x509_certificate_content,
            private_key_content,
            resource_paths["ubl_template"],
            resource_paths["signature"],
            uuid,
        )

    @staticmethod
    def extract_uuid(xml):
        """Extract UUID from the XML document."""
        uuid_nodes = xml.xpath(
            "//cbc:UUID",
            namespaces={
                "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
            },
        )
        if not uuid_nodes:
            raise Exception("UUID not found in the XML document.")
        return uuid_nodes[0].text

    @staticmethod
    def is_simplified_invoice(xml):
        """Check if the invoice is a simplified invoice."""
        invoice_type_code_nodes = xml.xpath(
            "//cbc:InvoiceTypeCode",
            namespaces={
                "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
            },
        )
        if invoice_type_code_nodes:
            name_attribute = invoice_type_code_nodes[0].get("name")
            return name_attribute.startswith("02")
        return False

    @staticmethod
    def transform_xml(xml, xsl_file_path):
        """Apply XSL transformation to the XML."""
        xsl = etree.parse(xsl_file_path)
        transform = etree.XSLT(xsl)
        transformed_xml = transform(xml)
        if transformed_xml is None:
            raise Exception("XSL Transformation failed.")
        return transformed_xml

    @staticmethod
    def canonicalize_xml(transformed_xml):
        """Canonicalize the transformed XML."""
        return etree.tostring(transformed_xml, method="c14n").decode("utf-8")

    @staticmethod
    def generate_base64_hash(canonical_xml):
        """Generate a Base64-encoded hash of the canonical XML."""
        hash_bytes = hashlib.sha256(canonical_xml.encode("utf-8")).digest()
        return base64.b64encode(hash_bytes).decode()

    @staticmethod
    def encode_invoice(xml_declaration, canonical_xml):
        """Encode the invoice as Base64."""
        updated_xml = f"{xml_declaration}\n{canonical_xml}"
        return base64.b64encode(updated_xml.encode("utf-8")).decode("utf-8")

    @staticmethod
    def create_result(uuid, base64_hash, base64_invoice):
        """Create the result dictionary."""
        return json.dumps(
            {"invoiceHash": base64_hash, "uuid": uuid, "invoice": base64_invoice}
        )

    @staticmethod
    def sign_simplified_invoice(
        canonical_xml,
        base64_hash,
        x509_certificate_content,
        private_key_content,
        ubl_template_path,
        signature_path,
        uuid,
    ):
        """Sign the simplified invoice and return the signed invoice."""
        signature_timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        # Generate public key hashing
        public_key_hashing = einvoice_signer.generate_public_key_hashing(
            x509_certificate_content
        )

        # Parse the X.509 certificate
        pem_certificate = einvoice_signer.wrap_certificate(x509_certificate_content)
        certificate = x509.load_pem_x509_certificate(
            pem_certificate.encode(), default_backend()
        )

        # Extract certificate information
        issuer_name = einvoice_signer.get_issuer_name(certificate)
        serial_number = certificate.serial_number
        signed_properties_hash = einvoice_signer.get_signed_properties_hash(
            signature_timestamp, public_key_hashing, issuer_name, serial_number
        )
        signature_value = einvoice_signer.get_digital_signature(
            base64_hash, private_key_content
        )

        # Generate the ECDSA result
        ecdsa_result = einvoice_signer.get_public_key_and_signature(
            x509_certificate_content
        )

        # Populate UBL Template
        ubl_content = einvoice_signer.populate_ubl_template(
                ubl_template_path,
                base64_hash,
                signed_properties_hash,
                signature_value,
                x509_certificate_content,
                signature_timestamp,
                public_key_hashing,
                issuer_name,
                serial_number,
            )
        # Insert UBL into XML
        updated_xml_string = einvoice_signer.insert_ubl_into_xml(
            canonical_xml, ubl_content
        )

        # Generate QR Code, now including ecdsa_result
        qr_code = qr_code_generator.generate_qr_code(
            canonical_xml, base64_hash, signature_value, ecdsa_result
        )

        # Load and insert signature content
        updated_xml_string = einvoice_signer.insert_signature_into_xml(
            updated_xml_string, signature_path, qr_code
        )

        # Encode the final invoice
        base64_invoice = einvoice_signer.encode_invoice(
            '<?xml version="1.0" encoding="UTF-8"?>\n', updated_xml_string
        )

        # Create the result dictionary
        return json.dumps(
            {
                "invoiceHash": base64_hash,
                "uuid": uuid,
                "invoice": base64_invoice,
            }
        )

    @staticmethod
    def wrap_certificate(x509_certificate_content):
        """Wrap the certificate content with PEM headers and footers."""
        return (
            "-----BEGIN CERTIFICATE-----\n"
            + "\n".join(
                [
                    x509_certificate_content[i : i + 64]
                    for i in range(0, len(x509_certificate_content), 64)
                ]
            )
            + "\n-----END CERTIFICATE-----"
        )

    @staticmethod
    def generate_public_key_hashing(x509_certificate_content):
        """Generate public key hashing from the X.509 certificate content."""
        # Generate the SHA256 hash of the x509_certificate_content string in binary format
        hash_bytes = hashlib.sha256(x509_certificate_content.encode("utf-8")).digest()
        # Convert the hash to hex and then base64 encode the result
        hash_hex = hash_bytes.hex()
        return base64.b64encode(hash_hex.encode("utf-8")).decode("utf-8")

    @staticmethod
    def populate_ubl_template(
        ubl_template_path,
        base64_hash,
        signed_properties_hash,
        signature_value,
        x509_certificate_content,
        signature_timestamp,
        public_key_hashing,
        issuer_name,
        serial_number,
    ):
        """Populate the UBL template with necessary values."""
        with open(ubl_template_path, "r") as ubl_file:
            ubl_content = ubl_file.read()
            ubl_content = ubl_content.replace("INVOICE_HASH", base64_hash)
            ubl_content = ubl_content.replace(
                "SIGNED_PROPERTIES", signed_properties_hash
            )
            ubl_content = ubl_content.replace("SIGNATURE_VALUE", signature_value)
            ubl_content = ubl_content.replace(
                "CERTIFICATE_CONTENT", x509_certificate_content
            )
            ubl_content = ubl_content.replace(
                "SIGNATURE_TIMESTAMP", signature_timestamp
            )
            ubl_content = ubl_content.replace("PUBLICKEY_HASHING", public_key_hashing)
            ubl_content = ubl_content.replace("ISSUER_NAME", issuer_name)
            ubl_content = ubl_content.replace("SERIAL_NUMBER", str(serial_number))

        return ubl_content

    @staticmethod
    def insert_ubl_into_xml(canonical_xml, ubl_content):
        """Insert UBL content into the canonical XML."""
        insert_position = (
            canonical_xml.find(">") + 1
        )  # Find position after the first '>'
        return (
            canonical_xml[:insert_position]
            + ubl_content
            + canonical_xml[insert_position:]
        )

    @staticmethod
    def insert_signature_into_xml(updated_xml_string, signature_path, qr_code):
        """Insert the signature content into the XML."""
        with open(signature_path, "r") as signature_file:
            signature_content = signature_file.read()
            signature_content = signature_content.replace("BASE64_QRCODE", qr_code)

        # Insert signature string before <cac:AccountingSupplierParty>
        insert_position_signature = updated_xml_string.find(
            "<cac:AccountingSupplierParty>"
        )
        if insert_position_signature != -1:
            return (
                updated_xml_string[:insert_position_signature]
                + signature_content
                + updated_xml_string[insert_position_signature:]
            )
        else:
            raise Exception(
                "The <cac:AccountingSupplierParty> tag was not found in the XML."
            )

    @staticmethod
    def get_issuer_name(certificate):
        issuer = certificate.issuer
        issuer_name_parts = []

        # Convert issuer to a dictionary-like structure
        issuer_dict = {}
        for attr in issuer:
            key = attr.oid._name
            if key in issuer_dict:
                if isinstance(issuer_dict[key], list):
                    issuer_dict[key].append(attr.value)
                else:
                    issuer_dict[key] = [issuer_dict[key], attr.value]
            else:
                issuer_dict[key] = attr.value

        # Check for 'CN' and add to the issuer name parts
        if "commonName" in issuer_dict:
            issuer_name_parts.append(f"CN={issuer_dict['commonName']}")

        # Check for 'DC' (Domain Component) if it exists
        if "domainComponent" in issuer_dict:
            dc_list = issuer_dict["domainComponent"]
            if isinstance(dc_list, list):
                # Reverse the DC list to get them in the required order
                dc_list.reverse()
                for dc in dc_list:
                    if dc:  # Check if the DC is not empty
                        issuer_name_parts.append(f"DC={dc}")
            # else:
            # issuer_name_parts.append(f"DC={dc_list}")

        # Join the parts with a comma and return
        return ", ".join(issuer_name_parts)

    @staticmethod
    def get_signed_properties_hash(
        signing_time, digest_value, x509_issuer_name, x509_serial_number
    ):
        # Construct the XML string with exactly 36 spaces in front of <xades:SignedSignatureProperties>
        xml_string = (
            '<xades:SignedProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="xadesSignedProperties">\n'
            "                                    <xades:SignedSignatureProperties>\n"
            "                                        <xades:SigningTime>{}</xades:SigningTime>\n".format(
                signing_time
            )
            + "                                        <xades:SigningCertificate>\n"
            "                                            <xades:Cert>\n"
            "                                                <xades:CertDigest>\n"
            '                                                    <ds:DigestMethod xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>\n'
            '                                                    <ds:DigestValue xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:DigestValue>\n'.format(
                digest_value
            )
            + "                                                </xades:CertDigest>\n"
            "                                                <xades:IssuerSerial>\n"
            '                                                    <ds:X509IssuerName xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:X509IssuerName>\n'.format(
                x509_issuer_name
            )
            + '                                                    <ds:X509SerialNumber xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{}</ds:X509SerialNumber>\n'.format(
                x509_serial_number
            )
            + "                                                </xades:IssuerSerial>\n"
            "                                            </xades:Cert>\n"
            "                                        </xades:SigningCertificate>\n"
            "                                    </xades:SignedSignatureProperties>\n"
            "                                </xades:SignedProperties>"
        )

        # Clean up the XML string (normalize newlines and trim extra spaces)
        xml_string = xml_string.replace("\r\n", "\n").strip()

        # Generate the SHA256 hash of the XML string in binary format
        hash_bytes = hashlib.sha256(xml_string.encode("utf-8")).digest()

        # Convert the hash to hex and then base64 encode the result
        hash_hex = hash_bytes.hex()
        return base64.b64encode(hash_hex.encode("utf-8")).decode("utf-8")

    @staticmethod
    def get_digital_signature(xml_hashing, private_key_content):
        try:
            from cryptography.hazmat.primitives.asymmetric import ec
            from cryptography.hazmat.primitives.serialization import (
                load_pem_private_key,
            )

            hash_bytes = base64.b64decode(xml_hashing)
            if hash_bytes is None:
                raise Exception("Failed to decode the base64-encoded XML hashing.")

            private_key_content = private_key_content.replace("\n", "").replace(
                "\t", ""
            )
            if (
                "-----BEGIN EC PRIVATE KEY-----" not in private_key_content
                and "-----END EC PRIVATE KEY-----" not in private_key_content
            ):
                private_key_content = f"-----BEGIN EC PRIVATE KEY-----\n{private_key_content}\n-----END EC PRIVATE KEY-----"

            private_key = load_pem_private_key(
                private_key_content.encode(), password=None
            )
            # private_key = crypto.load_privatekey(crypto.FILETYPE_PEM, private_key_content)
            if private_key is None:
                raise Exception("Failed to read private key.")
            # ================
            signature = private_key.sign(hash_bytes, ec.ECDSA(hashes.SHA256()))

            # return base64.b64encode(signature).decode()
            # ===============
            # signature = crypto.sign(private_key, hash_bytes, 'sha256')
            return base64.b64encode(signature).decode()
        except Exception as e:
            raise Exception(f"Failed to process signature: {e}")

    @staticmethod
    def get_public_key_and_signature(certificate_base64):
        try:
            with tempfile.NamedTemporaryFile(
                delete=False, mode="w", suffix=".pem"
            ) as temp_file:
                cert_content = "-----BEGIN CERTIFICATE-----\n"
                cert_content += "\n".join(
                    [
                        certificate_base64[i : i + 64]
                        for i in range(0, len(certificate_base64), 64)
                    ]
                )
                cert_content += "\n-----END CERTIFICATE-----\n"
                temp_file.write(cert_content)
                temp_file_path = temp_file.name

            with open(temp_file_path, "r") as f:
                cert = crypto.load_certificate(crypto.FILETYPE_PEM, f.read())

            pub_key = crypto.dump_publickey(crypto.FILETYPE_ASN1, cert.get_pubkey())
            pub_key_details = (
                crypto.load_publickey(crypto.FILETYPE_ASN1, pub_key)
                .to_cryptography_key()
                .public_numbers()
            )

            x = pub_key_details.x.to_bytes(32, byteorder="big").rjust(32, b"\0")
            y = pub_key_details.y.to_bytes(32, byteorder="big").rjust(32, b"\0")

            public_key_der = (
                b"\x30\x56\x30\x10\x06\x07\x2a\x86\x48\xce\x3d\x02\x01\x06\x05\x2b\x81\x04\x00\x0a\x03\x42\x00\x04"
                + x
                + y
            )

            cert_pem = open(temp_file_path, "r").read()
            matches = re.search(
                r"-----BEGIN CERTIFICATE-----(.+)-----END CERTIFICATE-----",
                cert_pem,
                re.DOTALL,
            )
            if not matches:
                raise Exception("Error extracting DER data from certificate.")

            der_data = base64.b64decode(matches.group(1).replace("\n", ""))
            sequence_pos = der_data.rfind(b"\x30", -72)
            signature = der_data[sequence_pos:]

            return {"public_key": public_key_der, "signature": signature}
        except Exception as e:
            raise Exception("[Error] Failed to process certificate: " + str(e))
        finally:
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)


class invoice_helper:

    @staticmethod
    def is_simplified_invoice(xml):
        namespace = {
            "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
        }
        invoice_type_code_node = xml.find(
            ".//cbc:InvoiceTypeCode", namespaces=namespace
        )
        if invoice_type_code_node is not None:
            name_attribute = invoice_type_code_node.get("name")
            return name_attribute.startswith("02")
        return False

    @staticmethod
    def modify_xml(
        base_document,
        id,
        invoice_type_codename,
        invoice_type_code_value,
        icv,
        pih,
        instruction_note,
    ):
        try:
            # Clone the document to keep the original intact
            new_doc = etree.ElementTree(etree.fromstring(etree.tostring(base_document.getroot(), pretty_print=True)))

            # Generate a new GUID for the UUID
            guid_string = str(uuid.uuid4()).upper()

            # Define namespaces
            namespaces = {
                None: "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
                "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
                "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
                "ext": "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2",
                "ds": "http://www.w3.org/2000/09/xmldsig#",
            }

            # Print the XML for debugging
            # print("Current XML structure:")
            # print(etree.tostring(new_doc, pretty_print=True).decode())

            # Modify the ID node
            id_node = new_doc.find(".//cbc:ID", namespaces=namespaces)
            if id_node is not None:
                id_node.text = id

            # Modify the UUID node
            uuid_node = new_doc.find(".//cbc:UUID", namespaces=namespaces)
            if uuid_node is not None:
                uuid_node.text = guid_string

            # Modify InvoiceTypeCode node and set 'name' attribute
            invoice_type_code_node = new_doc.find(
                ".//cbc:InvoiceTypeCode", namespaces=namespaces
            )
            if invoice_type_code_node is not None:
                invoice_type_code_node.text = invoice_type_code_value
                invoice_type_code_node.set("name", invoice_type_codename)

            # Update AdditionalDocumentReference for ICV
            additional_reference_node = new_doc.find(
                ".//cac:AdditionalDocumentReference[cbc:ID='ICV']/cbc:UUID",
                namespaces=namespaces,
            )
            if additional_reference_node is not None:
                additional_reference_node.text = str(icv)
            else:
                print("UUID node not found for ICV.")

            # Update AdditionalDocumentReference for PIH
            pih_node = new_doc.find(
                ".//cac:AdditionalDocumentReference[cbc:ID='PIH']/cac:Attachment/cbc:EmbeddedDocumentBinaryObject",
                namespaces=namespaces,
            )
            if pih_node is not None:
                pih_node.text = pih
            else:
                print("EmbeddedDocumentBinaryObject node not found for PIH.")

            # Conditionally add InstructionNote or remove BillingReference elements
            if instruction_note:
                payment_means_node = new_doc.find(
                    ".//cac:PaymentMeans", namespaces=namespaces
                )
                if payment_means_node is not None:
                    instruction_note_element = etree.Element(
                        "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}InstructionNote"
                    )
                    instruction_note_element.text = instruction_note
                    payment_means_node.append(instruction_note_element)
            else:
                billing_reference_nodes = new_doc.findall(
                    ".//cac:BillingReference", namespaces=namespaces
                )
                for billing_reference_node in billing_reference_nodes:
                    parent_node = new_doc.find(
                        ".//cac:BillingReference/..", namespaces=namespaces
                    )
                    if parent_node is not None:
                        parent_node.remove(billing_reference_node)

            return new_doc
        except Exception as e: 
            print(e)

    @staticmethod
    def extract_invoice_hash_and_base64_qr_code(xml_input):
        if isinstance(xml_input, str):
            decoded_xml = base64.b64decode(xml_input)
            if decoded_xml is None:
                raise ValueError("Invalid Base64 string provided.")
            xml_input = decoded_xml
        elif not isinstance(xml_input, (bytes, etree._Element)):
            raise ValueError("Input must be a string or lxml.etree._Element.")

        # Load XML into an lxml Element
        if isinstance(xml_input, bytes):
            doc = etree.fromstring(xml_input)
        else:
            doc = xml_input  # Assume it's already an lxml Element

        # Initialize XPath with namespaces
        namespaces = {
            "ext": "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2",
            "ds": "http://www.w3.org/2000/09/xmldsig#",
            "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
            "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
        }

        # Extract invoiceHash
        invoice_hash_node = doc.xpath(
            "//ds:Reference[@Id='invoiceSignedData']/ds:DigestValue",
            namespaces=namespaces,
        )
        invoice_hash = invoice_hash_node[0].text if invoice_hash_node else None

        # Extract base64QRCode
        base64_qr_code_node = doc.xpath(
            "//cac:AdditionalDocumentReference[cbc:ID='QR']/cac:Attachment/cbc:EmbeddedDocumentBinaryObject",
            namespaces=namespaces,
        )
        base64_qr_code = base64_qr_code_node[0].text if base64_qr_code_node else None

        return invoice_hash, base64_qr_code


class qr_code_generator:

    @staticmethod
    def generate_qr_code(canonical_xml, invoice_hash, signature_value, ecdsa_result):
        invoice_details = qr_code_generator.get_invoice_details(
            canonical_xml
        )  # , invoice_hash, signature_value)

        # Retrieve the InvoiceTypeCode name (from position 8 in array)
        # invoice_type_code_name = invoice_details[8]
        invoice_details.append(invoice_hash)
        invoice_details.append(signature_value)
        # result = qr_code_generator.get_public_key_and_signature(x509_certificate_content)
        invoice_details.append(ecdsa_result["public_key"])
        # Only add certificateSignature if InvoiceTypeCode name starts with "02"
        # if invoice_type_code_name.startswith("02"):
        invoice_details.append(ecdsa_result["signature"])

        base64_qr_code = qr_code_generator.generate_qr_code_from_values(invoice_details)

        return base64_qr_code

    @staticmethod
    def get_invoice_details(xml):  # , invoice_hash, signature_value)
        xml_object = ET.fromstring(xml)

        # invoice_type_code = xml_object.find('.//{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}InvoiceTypeCode').text
        invoice_type_code_name = xml_object.find(
            ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}InvoiceTypeCode"
        ).get("name")

        supplier_name = xml_object.find(
            ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}AccountingSupplierParty/{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}Party/{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}PartyLegalEntity/{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}RegistrationName"
        ).text
        company_id = xml_object.find(
            ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}AccountingSupplierParty/{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}Party/{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}PartyTaxScheme/{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}CompanyID"
        ).text
        issue_date_time = (
            xml_object.find(
                ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}IssueDate"
            ).text
            + "T"
            + xml_object.find(
                ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}IssueTime"
            ).text
        )
        payable_amount = xml_object.find(
            ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}LegalMonetaryTotal/{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}PayableAmount"
        ).text
        tax_amount = xml_object.find(
            ".//{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}TaxTotal/{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}TaxAmount"
        ).text

        return [
            None,  # Index 0 is unused
            supplier_name,
            company_id,
            issue_date_time,
            payable_amount,
            tax_amount,
            # invoice_hash,
            # signature_value,
            # invoice_type_code_name
        ]

    @staticmethod
    def generate_qr_code_from_values(invoice_details):
        data = b""
        for key, value in enumerate(invoice_details[1:], start=1):
            if isinstance(value, str):
                value = value.encode("utf-8")

            tlv_data = qr_code_generator.write_tlv(key, value)
            data += tlv_data

        # Ensure to check if data is empty
        if not data:
            print("No data generated for QR code!")

        return base64.b64encode(data).decode()

    @staticmethod
    def write_length(length):
        if length <= 0x7F:
            return bytes([length])
        length_bytes = []
        while length > 0:
            length_bytes.insert(0, length & 0xFF)
            length >>= 8
        return bytes([0x80 | len(length_bytes)]) + bytes(length_bytes)

    @staticmethod
    def write_tag(tag):
        result = bytes()
        flag = True
        for i in range(3, -1, -1):
            num = (tag >> (8 * i)) & 0xFF
            if num != 0 or not flag or i == 0:
                if flag and i != 0 and (num & 0x1F) != 0x1F:
                    raise ValueError(f"Invalid tag value: {tag}")
                result += bytes([num])
                flag = False
        return result

    @staticmethod
    def write_tlv(tag, value):
        if value is None:
            raise ValueError("Please provide a value!")
        tlv = qr_code_generator.write_tag(tag)
        length = len(value)
        tlv += qr_code_generator.write_length(length)
        tlv += value
        return tlv

    @staticmethod
    def get_public_key_and_signature(certificate_base64):
        try:
            with tempfile.NamedTemporaryFile(
                delete=False, mode="w", suffix=".pem"
            ) as temp_file:
                cert_content = "-----BEGIN CERTIFICATE-----\n"
                cert_content += "\n".join(
                    [
                        certificate_base64[i : i + 64]
                        for i in range(0, len(certificate_base64), 64)
                    ]
                )
                cert_content += "\n-----END CERTIFICATE-----\n"
                temp_file.write(cert_content)
                temp_file_path = temp_file.name

            with open(temp_file_path, "r") as f:
                cert = crypto.load_certificate(crypto.FILETYPE_PEM, f.read())

            pub_key = crypto.dump_publickey(crypto.FILETYPE_ASN1, cert.get_pubkey())
            pub_key_details = (
                crypto.load_publickey(crypto.FILETYPE_ASN1, pub_key)
                .to_cryptography_key()
                .public_numbers()
            )

            x = pub_key_details.x.to_bytes(32, byteorder="big").rjust(32, b"\0")
            y = pub_key_details.y.to_bytes(32, byteorder="big").rjust(32, b"\0")

            public_key_der = (
                b"\x30\x56\x30\x10\x06\x07\x2a\x86\x48\xce\x3d\x02\x01\x06\x05\x2b\x81\x04\x00\x0a\x03\x42\x00\x04"
                + x
                + y
            )

            cert_pem = open(temp_file_path, "r").read()
            matches = re.search(
                r"-----BEGIN CERTIFICATE-----(.+)-----END CERTIFICATE-----",
                cert_pem,
                re.DOTALL,
            )
            if not matches:
                raise Exception("Error extracting DER data from certificate.")

            der_data = base64.b64decode(matches.group(1).replace("\n", ""))
            sequence_pos = der_data.rfind(b"\x30", -72)
            signature = der_data[sequence_pos:]

            return {"public_key": public_key_der, "signature": signature}
        except Exception as e:
            raise Exception("[Error] Failed to process certificate: " + str(e))
        finally:
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)


def main1():
    config = db(db.csr_config.id > 0).select().first()
    current_path = os.path.dirname(os.path.abspath(__file__))
    print("\nPYTHON CODE ONBOARDING\n")
    # print(json.dumps(config.as_dict(), indent=4))
    # Define Variable
    environment_type = "Simulation"  # "NonProduction"
    OTP = config.otp   # For Simulation and Production Get OTP from fatooraPortal
    new_uuid = str(uuid.uuid4())
    serial_number = "1-TST|2-TST|3-" + new_uuid  # config.company_uuid  #
    csr_config = {
        "csr.common.name": config.common_name,
        "csr.serial.number": serial_number,
        "csr.organization.identifier": config.organization_identifier,
        "csr.organization.unit.name": config.organization_unit_name,
        "csr.organization.name": config.organization_name,
        "csr.country.name": config.country_name,
        "csr.invoice.type": "1100",
        "csr.location.address": config.location_address,
        "csr.industry.business.category": config.business_category,
    }
    # csr_config = {
    # "csr.common.name": "TST-886431145-399999999900003",
    # "csr.serial.number": "1-TST|2-TST|3-ed22f1d8-e6a2-1118-9b58-d9a8f11e445f",
    # "csr.organization.identifier": "399999999900003",
    # "csr.organization.unit.name": "Riyadh Branch",
    # "csr.organization.name": "Maximum Speed Tech Supply LTD",
    # "csr.country.name": "SA",
    # "csr.invoice.type": "1100",
    # "csr.location.address": "RRRD2929",
    # "csr.industry.business.category": "Supply activities"
    # }

    print(json.dumps(csr_config, indent=4))
    # config_file_path = 'certificates/csr-config-example-EN.properties'

    api_path = "Production"  # Default value

    # Determine API path based on environment type
    if environment_type == "NonProduction":
        api_path = "developer-portal"
    elif environment_type == "Simulation":
        api_path = "simulation"
    elif environment_type == "Production":
        api_path = "core"

    # Prepare certificate information
    cert_info = {
        "environmentType": environment_type,
        "csr": "",
        "privateKey": "",
        "OTP": OTP ,
        "ccsid_requestID": "",
        "ccsid_binarySecurityToken": "",
        "ccsid_secret": "",
        "pcsid_requestID": "",
        "pcsid_binarySecurityToken": "",
        "pcsid_secret": "",
        "lastICV": "0",
        "lastInvoiceHash": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
        "complianceCsidUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance",
        "complianceChecksUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance/invoices",
        "productionCsidUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/production/csids",
        "reportingUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single",
        "clearanceUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single",
    }

    # 1. Generate CSR and PrivateKey
    print("\n1. Generate CSR and PrivateKey\n")

    # Generate CSR & Private Key
    csr_gen = CsrGenerator(csr_config, environment_type)
    private_key_content, csr_base64 = csr_gen.generate_csr()

    print("\nPrivate Key (without header and footer):")
    print(private_key_content)
    print("\nBase64 Encoded CSR:")
    print(csr_base64)

    cert_info["csr"] = csr_base64
    cert_info["privateKey"] = private_key_content

    api_helper.save_json_to_file(current_path+"/../certificates/certificateInfo.json", cert_info)

    # 2. Get Compliance CSID
    print("\n2. Get Compliance CSID\n")
    response = api_helper.compliance_csid(cert_info)
    request_type = "Compliance CSID"
    api_url = cert_info["complianceCsidUrl"]

    clean_response = api_helper.clean_up_json(response, request_type, api_url)

    try:
        json_decoded_response = json.loads(response)

        cert_info["ccsid_requestID"] = json_decoded_response["requestID"]
        cert_info["ccsid_binarySecurityToken"] = json_decoded_response[
            "binarySecurityToken"
        ]
        cert_info["ccsid_secret"] = json_decoded_response["secret"]

        api_helper.save_json_to_file(current_path+"/../certificates/certificateInfo.json", cert_info)

        print("\ncomplianceCSID Server Response: \n" + clean_response)

    except json.JSONDecodeError:
        print("\ncomplianceCSID Server Response: \n" + clean_response)
    # 3: Sending Sample Documents
    print("\n3: Sending Sample Documents\n")

    cert_info = api_helper.load_json_from_file(current_path+"/../certificates/certificateInfo.json")
    xml_template_path = current_path + "/templates/invoice.xml"
    # with open(xml_template_path, "r") as file:
    #     file_content = file.read()
    private_key = cert_info["privateKey"]
    x509_certificate_content = base64.b64decode(
        cert_info["ccsid_binarySecurityToken"]
    ).decode("utf-8")

    parser = etree.XMLParser(remove_blank_text=False)
    base_document = etree.parse(xml_template_path, parser)
    for issue_date in base_document.iter(
        "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}IssueDate"
    ):
        today = date.today()
        formatted_date = today.strftime("%Y-%m-%d")
        issue_date.text = formatted_date
    # parser = etree.XMLParser(remove_blank_text=False)
    # base_document = etree.parse(StringIO(file_content), parser)
    # print(etree.fromstring(base_document, parser))

    document_types = [
        ["STDSI", "388", "Standard Invoice", ""],
        [
            "STDCN",
            "383",
            "Standard CreditNote",
            "InstructionNotes for Standard CreditNote",
        ],
        [
            "STDDN",
            "381",
            "Standard DebitNote",
            "InstructionNotes for Standard DebitNote",
        ],
        ["SIMSI", "388", "Simplified Invoice", ""],
        [
            "SIMCN",
            "383",
            "Simplified CreditNote",
            "InstructionNotes for Simplified CreditNote",
        ],
        [
            "SIMDN",
            "381",
            "Simplified DebitNote",
            "InstructionNotes for Simplified DebitNote",
        ],
    ]

    icv = 0
    pih = "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="

    for doc_type in document_types:
        prefix, type_code, description, instruction_note = doc_type
        icv += 1
        is_simplified = prefix.startswith("SIM")

        print(f"Processing {description}...\n")

        new_doc = invoice_helper.modify_xml(
                base_document,
                f"{prefix}-0001",
                "0200000" if is_simplified else "0100000",
                type_code,
                icv,
                pih,
                instruction_note,
            )
        # to print the XML structure for debugging
        # print(etree.tostring(new_doc, pretty_print=True, method="html"))
        json_payload = einvoice_signer.get_request_api(
                new_doc, x509_certificate_content, private_key
            )

        # print(json_payload)

        response = api_helper.compliance_checks(cert_info, json_payload)
        request_type = "Compliance Checks"
        api_url = cert_info["complianceChecksUrl"]

        clean_response = api_helper.clean_up_json(response, request_type, api_url)

        json_decoded_response = json.loads(response)

        if json_decoded_response:
            print(f"complianceChecks Server Response: \n{clean_response}")
        else:
            print(f"Invalid JSON Response: \n{response}")
            exit(1)

        if response is None:
            print(f"Failed to process {description}: serverResult is null.\n")
            exit(1)

        status = (
            json_decoded_response["reportingStatus"]
            if is_simplified
            else json_decoded_response["clearanceStatus"]
        )

        if "REPORTED" in status or "CLEARED" in status:
            json_payload = json.loads(json_payload)
            pih = json_payload["invoiceHash"]
            print(f"\n{description} processed successfully\n\n")
        else:
            print(f"Failed to process {description}: status is {status}\n")
            exit(1)

        # time.sleep(1)

    # 4. Get Production CSID

    print(f"\n\n4. Get Production CSID\n")

    response = api_helper.production_csid(cert_info)
    request_type = "Production CSID"
    api_url = cert_info["productionCsidUrl"]
    print("======================================")
    print(response)
    print(request_type)
    print(api_url)
    print("=======================================")

    clean_response = api_helper.clean_up_json(response, request_type, api_url)

    try:
        json_decoded_response = json.loads(response)

        cert_info["pcsid_requestID"] = json_decoded_response["requestID"]
        cert_info["pcsid_binarySecurityToken"] = json_decoded_response[
            "binarySecurityToken"
        ]
        cert_info["pcsid_secret"] = json_decoded_response["secret"]

        api_helper.save_json_to_file(current_path+"/../certificates/certificateInfo.json", cert_info)

        print(f"Production CSID Server Response: \n{clean_response}")

    except json.JSONDecodeError:
        print(f"Production CSID Server Response: \n{clean_response}")

    return("ok")


def main10():
    # config = db(db.csr_config.id > 0).select().first()
    current_path = os.path.dirname(os.path.abspath(__file__))
    environment_type = "Simulation"  # "NonProduction"

    api_path = "developer-portal"  # Default value

    if environment_type == "NonProduction":
        api_path = "developer-portal"
    elif environment_type == "Simulation":
        api_path = "simulation"
    elif environment_type == "Production":
        api_path = "core"

    cert_info = api_helper.load_json_from_file(current_path+"/../certificates/certificateInfo.json")
    private_key = cert_info["privateKey"]
    x509_certificate_content = base64.b64decode(
        cert_info["ccsid_binarySecurityToken"]
    ).decode("utf-8")
    document_types = [
        ["STDSI", "388", "Standard Invoice", ""],
        [
            "STDCN",
            "383",
            "Standard CreditNote",
            "InstructionNotes for Standard CreditNote",
        ],
        [
            "STDDN",
            "381",
            "Standard DebitNote",
            "InstructionNotes for Standard DebitNote",
        ],
        ["SIMSI", "388", "Simplified Invoice", ""],
        [
            "SIMCN",
            "383",
            "Simplified CreditNote",
            "InstructionNotes for Simplified CreditNote",
        ],
        [
            "SIMDN",
            "381",
            "Simplified DebitNote",
            "InstructionNotes for Simplified DebitNote",
        ],
    ]

    icv = 0
    pih = "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="

    for doc_type in document_types:
        prefix, type_code, description, instruction_note = doc_type
        icv += 1
        xml_file = current_path + "/templates/temp_invoice.xml"
        xml_new_file = current_path + "/templates/invoice.xml"
        shutil.copyfile(xml_file, xml_new_file)
        parser = etree.XMLParser(remove_blank_text=False)
        base_document = etree.parse(xml_new_file, parser)
        is_simplified = prefix.startswith("SIM")

        print(f"Processing {description}...\n")

        new_doc = invoice_helper.modify_xml(
                base_document,
                f"{prefix}-0001",
                "0200000" if is_simplified else "0100000",
                type_code,
                icv,
                pih,
                instruction_note,
            )
        # to print the XML structure for debugging
        # print(etree.tostring(new_doc, pretty_print=True, method="html"))
        json_payload = einvoice_signer.get_request_api(
                new_doc, x509_certificate_content, private_key
            )

        # print(json_payload)

        response = api_helper.compliance_checks(cert_info, json_payload)
        request_type = "Compliance Checks"
        api_url = cert_info["complianceChecksUrl"]

        clean_response = api_helper.clean_up_json(response, request_type, api_url)

        json_decoded_response = json.loads(response)

        if json_decoded_response:
            print(f"complianceChecks Server Response: \n{clean_response}")
        else:
            print(f"Invalid JSON Response: \n{response}")
            exit(1)

        if response is None:
            print(f"Failed to process {description}: serverResult is null.\n")
            exit(1)

        status = (
            json_decoded_response["reportingStatus"]
            if is_simplified
            else json_decoded_response["clearanceStatus"]
        )

        if "REPORTED" in status or "CLEARED" in status:
            json_payload = json.loads(json_payload)
            pih = json_payload["invoiceHash"]
            print(f"\n{description} processed successfully\n\n")
        else:
            print(f"Failed to process {description}: status is {status}\n")
            exit(1)

        # time.sleep(1)

    # 4. Get Production CSID

    print(f"\n\n4. Get Production CSID\n")

    response = api_helper.production_csid(cert_info)
    request_type = "Production CSID"
    api_url = cert_info["productionCsidUrl"]
    print("======================================")
    print(response)
    print(request_type)
    print(api_url)
    print("=======================================")

    clean_response = api_helper.clean_up_json(response, request_type, api_url)

    try:
        json_decoded_response = json.loads(response)

        cert_info["pcsid_requestID"] = json_decoded_response["requestID"]
        cert_info["pcsid_binarySecurityToken"] = json_decoded_response[
            "binarySecurityToken"
        ]
        cert_info["pcsid_secret"] = json_decoded_response["secret"]

        api_helper.save_json_to_file(current_path+"/../certificates/certificateInfo.json", cert_info)

        print(f"Production CSID Server Response: \n{clean_response}")

    except json.JSONDecodeError:
        print(f"Production CSID Server Response: \n{clean_response}")

    return("ok")


def main2():
    current_path = os.path.dirname(os.path.abspath(__file__))
    print("\n3: Clearance & Reporting Documents\n")
    # print(current_path + "/../certificates/certificateInfo.json")
    cert_info = api_helper.load_json_from_file(
        current_path + "/../certificates/certificateInfo.json"
    )
    xml_template_path = current_path + "/templates/invoice.xml"
    private_key = cert_info["privateKey"]
    x509_certificate_content = base64.b64decode(
        cert_info["pcsid_binarySecurityToken"]
    ).decode("utf-8")

    print(x509_certificate_content)
    print(json.dumps(cert_info, indent=4))
    parser = etree.XMLParser(remove_blank_text=False)
    base_document = etree.parse(xml_template_path, parser)
    print(etree.tostring(einvoice_signer.pretty_print_xml(base_document)))
    document_types = [
        ["STDSI", "388", "Standard Invoice", ""],
        [
            "STDCN",
            "383",
            "Standard CreditNote",
            "InstructionNotes for Standard CreditNote",
        ],
        [
            "STDDN",
            "381",
            "Standard DebitNote",
            "InstructionNotes for Standard DebitNote",
        ],
        ["SIMSI", "388", "Simplified Invoice", ""],
        [
            "SIMCN",
            "383",
            "Simplified CreditNote",
            "InstructionNotes for Simplified CreditNote",
        ],
        [
            "SIMDN",
            "381",
            "Simplified DebitNote",
            "InstructionNotes for Simplified DebitNote",
        ],
    ]

    icv = 0
    pih = "MEUCIEWDNB6Qsq1nyN/vVFL78qjzn/JEIxQovfzslX3LNUZmAiEApFOv6/CGiE4SFhQJdypeYsDsLpOGw87MFUbxLLaSoUg="

    for doc_type in document_types:
        prefix, type_code, description, instruction_note = doc_type
        icv += 1
        is_simplified = prefix.startswith("SIM")

        print(f"Processing {description}...\n")

        new_doc = invoice_helper.modify_xml(
            base_document,
            f"{prefix}-0001",
            "0200000" if is_simplified else "0100000",
            type_code,
            icv,
            pih,
            instruction_note,
        )
        json_payload = einvoice_signer.get_request_api(
            new_doc, x509_certificate_content, private_key
        )

        # print(json_payload)
        print(cert_info["reportingUrl"])

        if einvoice_signer.is_simplified_invoice(new_doc):

            response = api_helper.invoice_reporting(cert_info, json_payload)
            request_type = "Reporting Api"
            api_url = cert_info["reportingUrl"]
        else:
            print("i am in ")
            response = api_helper.invoice_clearance(cert_info, json_payload)
            print("next step")
            request_type = "Clearance Api"
            api_url = cert_info["clearanceUrl"]

        clean_response = api_helper.clean_up_json(response, request_type, api_url)
        print("i am hear ")

        json_decoded_response = json.loads(response)

        if json_decoded_response:
            print(f"Reporting api Server Response: \n{clean_response}")
        else:
            print(f"Invalid JSON Response: \n{response}")
            exit(1)

        if response is None:
            print(f"Failed to process {description}: serverResult is null.\n")
            exit(1)

        status = (
            json_decoded_response["reportingStatus"]
            if is_simplified
            else json_decoded_response["clearanceStatus"]
        )

        if "REPORTED" in status or "CLEARED" in status:
            json_payload = json.loads(json_payload)
            pih = json_payload["invoiceHash"]
            print(f"\n{description} processed successfully\n\n")
        else:
            print(f"Failed to process {description}: status is {status}\n")
            exit(1)

        time.sleep(1)
    return "ok"


def save_inv():
    if (request.args(0)==None) :
        return "no invoce enterd"
    if request.args(1) == None:
        inv = db.invoice_master[request.args(0)]
    else :
        inv = db.inv_return_master[request.args(0)]
    if (inv==None):
        return "invoce not found "
    configuration = db(db.important_info.id > 0).select().first()
    current_path = os.path.dirname(os.path.abspath(__file__))
    cert_info = api_helper.load_json_from_file(
        current_path + "/../certificates/certificateInfo.json"
    )
    xml_str = inv["xml_file"]
    private_key = cert_info["privateKey"]
    x509_certificate_content = base64.b64decode(
        cert_info["pcsid_binarySecurityToken"]
    ).decode("utf-8")
    parser = etree.XMLParser(remove_blank_text=False)
    base_document = etree.parse(
        StringIO(xml_str), parser
    ) 
    if request.args(1) == None:
        icv = configuration["last_inv_no"] or 0
        pih = (
            configuration["last_inv_phi"]
            or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
        )  # inv["pih_txt"]
        prefix = "STDSI"
        type_code="388"
        description="Standard Invoice"
        instruction_note = ""

    else :
        icv = configuration["last_r_inv_no"] or 0
        pih = (
            configuration["last_r_inv_phi"]
            or "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="
        )  # inv["pih_txt"]
        prefix = "STDCN"
        type_code = "383"
        description = "Standard CreditNote"
        instruction_note = "InstructionNotes for Standard CreditNote"

    icv += 1
    is_simplified = prefix.startswith("SIM")
    new_doc = invoice_helper.modify_xml(
            base_document,
            f"{prefix}-0001",
            "0200000" if is_simplified else "0100000",
            type_code,
            icv,
            pih,
            instruction_note,
    )
    json_payload = einvoice_signer.get_request_api(
            new_doc, x509_certificate_content, private_key
    )
    # print(json_payload)
    # print(cert_info["reportingUrl"])
    #    if einvoice_signer.is_simplified_invoice(new_doc):
    #
    #        response = api_helper.invoice_reporting(cert_info, json_payload)
    #        request_type = "Reporting Api"
    #        api_url = cert_info["reportingUrl"]
    response = api_helper.invoice_clearance(cert_info, json_payload)
    request_type = "Clearance Api"
    api_url = cert_info["clearanceUrl"]
    clean_response = api_helper.clean_up_json(response, request_type, api_url)
    json_decoded_response = json.loads(response)
    if json_decoded_response:
        print(f"Reporting api Server Response: \n{clean_response}")
    else:
        print(f"Invalid JSON Response: \n{response}")
        exit(1)
    if response is None:
        print(f"Failed to process {description}: serverResult is null.\n")
        exit(1)
    status = (
           json_decoded_response["reportingStatus"]
           if is_simplified
           else json_decoded_response["clearanceStatus"]
    )
    if "REPORTED" in status or "CLEARED" in status:
        json_payload = json.loads(json_payload)
        pih = json_payload["invoiceHash"]
        print(f"\n{description} processed successfully\n\n")
    else:
        print(f"Failed to process {description}: status is {status}\n")
        exit(1)
    xml = base64.b64decode(json_decoded_response["clearedInvoice"])
    res = invoice_helper.extract_invoice_hash_and_base64_qr_code(xml)
    configuration.last_inv_phi = res[0]
    if request.args(1) == None:
        configuration.last_inv_phi = res[0]
        configuration.last_inv_no = icv 
    else :
        configuration.last_r_inv_phi = res[0]
        configuration.last_r_inv_no = icv
    inv.update_record(
        zatca_res=clean_response,
        qr_code=res[1],
        pih_txt=res[0],
        send_to_zatca=True,
    )
    db.commit()
    if request.args(1) == None:
        redirect(URL("invoice", "show_one_invoce/" + request.args(0)))
    else :
        redirect(URL("invoice", "show_one_invoce_r/" + request.args(0)))

def qr():
    inv = db.invoice_master[43]
    zatca = json.loads(inv.zatca_res)
    xml_content = base64.b64decode(zatca["clearedInvoice"])
    res = invoice_helper.extract_invoice_hash_and_base64_qr_code(xml_content)
    return res[1]
