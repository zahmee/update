import base64
import xml.etree.ElementTree as ET
import json


def decode_invoice_base64(base64_invoice_str, output_xml_path="invoice.xml"):
    # فك Base64 للفاتورة كاملة
    xml_data = base64_invoice_str

    # حفظها كملف XML للعرض أو الفحص
    with open(output_xml_path, "wb") as f:
        f.write(xml_data)

    return xml_data.decode("utf-8")  # return as string for parsing


def extract_qr_from_xml(xml_str):
    # تحليل XML لاستخراج QR Base64
    root = ET.fromstring(xml_str)
    ns = {"cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"}

    qr_node = root.find(".//cbc:EmbeddedDocumentBinaryObject", ns)
    if qr_node is None:
        raise Exception("QR code not found in XML.")

    qr_base64 = qr_node.text
    qr_bytes = base64.b64decode(qr_base64)

    return qr_bytes


def parse_tlv(tlv_bytes):
    i = 0
    fields = []
    while i < len(tlv_bytes):
        tag = tlv_bytes[i]
        length = tlv_bytes[i + 1]
        value = tlv_bytes[i + 2 : i + 2 + length]
        fields.append((tag, value.decode("utf-8")))
        i += 2 + length
    return fields


# ------------------------------
# مثال استخدام

def show_inv():
    print("***********************************************")
    inv = db.invoice_master[43]
    zatca = json.loads(inv.zatca_res)
    print(zatca)
    print("------------------------------")
    print(zatca["clearedInvoice"])
    xml_content = base64.b64decode(zatca["clearedInvoice"])
    print("------------------------------")
    print(xml_content)
    # xml_content = decode_invoice_base64(zatca["clearedInvoice"])
    qr_bytes = extract_qr_from_xml(xml_content)
    print("------------------------------")
    print(qr_bytes)
    qr_fields = parse_tlv(qr_bytes)
    print("------------------------------")
    print(qr_fields)
    # طباعة نتائج QR
    print("📌 TLV Decoded QR Contents:")
    for tag, value in qr_fields:
        print(f"Tag {tag}: {value}")
