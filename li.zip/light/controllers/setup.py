# type: ignore

import os
import sys
import json
from pathlib import Path
import subprocess
import uuid


def c_xml():
    return create_xml_invoce()


screens_code = [
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض فاتورة", "screen_code": 4003},
]


@auth.requires_membership("admin")
def unit_key():
    grid = SQLFORM.grid(
        db.key_unit,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def type_key():
    grid = SQLFORM.grid(
        db.key_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def payment_method_key():
    grid = SQLFORM.grid(
        db.key_payment_method.id > 3,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def update_items_det():
    qry = "update items_det set  item_id = (select item_id from items_main where id = items_det.item_idr )"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def update_items_main1():
    qry = "update items_main set  vat = 0.0 where vat is null "
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def print_report():
    grid = SQLFORM.grid(
        db.print_report,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def users():
    links = [
        lambda row: A(
            I(" ", _class="far fa-key"),
            " صلاحيات المستخدم ",
            _class="btn btn-info ",
            _title="صلاحيات المستخدم",
            _href=URL("setup", "screens_rules", args=[row.id]),
        )
    ]
    grid = SQLFORM.grid(
        db.auth_user,
        links=links,
        user_signature=True,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ====================================================================
@auth.requires(auth.has_membership("admin"))
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ===============================================
@auth.requires(auth.has_membership("admin"))
def screens():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@auth.requires(auth.has_membership("admin"))
def screens_rules():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    q = db.screens_rules.to_user == request.args(0)
    db.screens_rules.to_user.default = request.args(0)
    db.screens_rules.to_user.readable = False
    db.screens_rules.to_user.writable = False
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        orderby=db.screens_rules.screens,
        maxtextlengths={"screens_rules.screens": 250},
        args=request.args[:1],
    )
    return dict(grid=grid)


#
@auth.requires(auth.has_membership("admin"))
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@auth.requires(auth.has_membership("admin"))
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


def important_info():
    db.important_info.logo.readable = False
    db.important_info.logo.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


def important_info_2():
    db.important_info.name.readable = False
    db.important_info.name.writable = False
    db.important_info.vat.readable = False
    db.important_info.vat.writable = False
    db.important_info.tel.readable = False
    db.important_info.tel.writable = False
    db.important_info.mobile.readable = False
    db.important_info.mobile.writable = False
    db.important_info.address.readable = False
    db.important_info.address.writable = False
    db.important_info.msg1.readable = False
    db.important_info.msg1.writable = False
    db.important_info.msg2.readable = False
    db.important_info.msg2.writable = False
    db.important_info.currency.readable = False
    db.important_info.currency.writable = False
    db.important_info.send_sms.readable = False
    db.important_info.send_sms.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


def t1():
    return dict()


# ========================================================
@auth.requires_membership("admin")
def update_crus():
    qry = "CREATE EXTENSION tablefunc;"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def sample_item():
    grid = SQLFORM.grid(
        db.sample_item,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires(auth.has_membership("admin"))
def zatca_info():
    # Print the data of dictionary
    # print("\nLinux:", data['Linux'])
    # print("\nPeople2:", data['people2'])
    # data['Linux'] = ["ahmed"]
    # data['zahmee'] = "ahmed zahmah"
    # print(data)
    # f = open(zatca_dir+'/zatca.json', 'w+')
    # json.dump(data, f, indent=4)
    # f.close()
    return dict()


@auth.requires(auth.has_membership("admin"))
def get_zatca_info():
    script_dir = os.path.dirname(__file__)
    zatca_dir = os.path.join(script_dir, "..", "private", "zatca.json")
    jsonFile = open(zatca_dir, "r")
    data = json.load(jsonFile)
    data.pop("csr_zatca")
    data.pop("signStr")
    data.pop("signStrpub")
    data.pop("privatekey")
    data.pop("publickey")
    data.pop("csr")
    data.pop("csr_64")
    jsonFile.close()
    return response.json(data)


@auth.requires(auth.has_membership("admin"))
def get_zatca_info_files():
    script_dir = os.path.dirname(__file__)
    zatca_dir = os.path.join(script_dir, "..", "private")
    files = []
    for child in Path(zatca_dir).iterdir():
        files.append(child.name)
    return response.json(files)


@auth.requires(auth.has_membership("admin"))
def run_zatca_create():
    THIS_FOLDER = Path(__file__).resolve().parents[1]
    my_file = os.path.join(THIS_FOLDER, "scripts")
    my_file = os.path.join(my_file, "create.py")
    if sys.platform.startswith("win32"):
        command1 = subprocess.Popen(
            ["python", my_file],
            shell=False,
            stdin=None,
            stdout=None,
            stderr=None,
            close_fds=True,
        )
    elif sys.platform.startswith("linux"):
        command1 = subprocess.Popen(
            ["python3", my_file],
            shell=False,
            stdin=None,
            stdout=None,
            stderr=None,
            close_fds=True,
        )
    return "command1"


@auth.requires(auth.has_membership("admin"))
def update_zatca_info():
    script_dir = os.path.dirname(__file__)
    zatca_dir = os.path.join(script_dir, "..", "private", "zatca.json")
    jsonFile = open(zatca_dir, "r")
    data = json.load(jsonFile)
    jsonFile.close()
    zatcaData = request.vars
    data.update(zatcaData)
    jsonFile = open(zatca_dir, "w")
    json.dump(data, jsonFile, indent=4)
    jsonFile.close()
    return response.json(data)


@auth.requires(auth.has_membership("admin"))
def csr_config():
    # current_path = os.path.dirname(os.path.abspath(__file__))
    # my_path = Path(current_path).parent.resolve()
    # my_file = my_path.__str__()
    # with open(my_file, "r") as file:
    # j_file = json.load(file)
    return dict(csr=[])


@auth.requires(auth.has_membership("admin"))
def git_csr_config():
    q = db(db.csr_config.id > 0).select().first()
    if q:
        q.otp = ""
        return response.json(q)
    else:
        return response.json(
            {
                "otp": "",
                "serial_number": "",
                "common_name": "",
                "organization_name": "",
                "organization_identifier": "",
                "organization_unit_name": "1",
                "country_name": "SA",
                "invoice_type": "",
                "location_address": "",
                "business_category": "",
                "address_city_name": "",
                "address_street_name": "",
                "address_postal_zone": "",
                "address_building_number": "",
                "address_neighborhood":"",
                "CompanyID": "",
                "company_id": "",
            }
        )


@auth.requires(auth.has_membership("admin"))
def update_csr_config():
    try:
        data = request.vars
        q = db(db.csr_config.id > 0).select().first()
        if q:
            q.update_record(
                otp=data.otp,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.organization_name if "common_name" in data else "",
                organization_name=(
                    data.organization_name if "organization_name" in data else ""
                ),
                organization_identifier=(
                    data.organization_identifier
                    if "organization_identifier" in data
                    else ""
                ),
                organization_unit_name=(
                    data.organization_unit_name
                    if "organization_unit_name" in data
                    else ""
                ),
                country_name="SA",
                invoice_type="1100",
                location_address=(
                    data.location_address if "location_address" in data else ""
                ),
                business_category=(
                    data.business_category if "business_category" in data else ""
                ),
                address_city_name=(
                    data.address_city_name if "address_city_name" in data else ""
                ),
                address_street_name=(
                    data.address_street_name if "address_street_name" in data else ""
                ),
                address_postal_zone=(
                    data.address_postal_zone if "address_postal_zone" in data else ""
                ),
                address_building_number=(
                    data.address_building_number
                    if "address_building_number" in data
                    else ""
                ),
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=(
                    data.address_neighborhood if "address_neighborhood" in data else ""
                ),
                privatekey=data.privatekey if "privatekey" in data else privatekey,
                csr=data.csr if "csr" in data else csr,
                csr_src=data.csr_src if "csr_src" in data else csr_src,
                egs_uuid=data.egs_uuid if "egs_uuid" in data else egs_uuid,
                ccsid_requestid=(
                    data.ccsid_requestid
                    if "ccsid_requestid" in data
                    else ccsid_requestid
                ),
                ccsid_binarysecuritytoken=(
                    data.ccsid_binarysecuritytoken
                    if "ccsid_binarysecuritytoken" in data
                    else ccsid_binarysecuritytoken
                ),
                ccsid_secret=(
                    data.ccsid_secret if "ccsid_secret" in data else ccsid_secret
                ),
                pcsid_requestid=(
                    data.pcsid_requestid
                    if "pcsid_requestid" in data
                    else pcsid_requestid
                ),
                pcsid_binarysecuritytoken=(
                    data.pcsid_binarysecuritytoken
                    if "pcsid_binarysecuritytoken" in data
                    else pcsid_binarysecuritytoken
                ),
                pcsid_secret=(
                    data.pcsid_secret if "pcsid_secret" in data else pcsid_secret
                ),
            )
            db.commit()
        else:
            db.csr_config.validate_and_insert(
                otp=data.otp,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.common_name if "common_name" in data else "",
                organization_name=data.organization_name if "organization_name" in data else "",
                organization_identifier=data.organization_identifier if "organization_identifier" in data else "",
                organization_unit_name=data.organization_unit_name if "organization_unit_name" in data else "",
                country_name="SA",
                invoice_type="1100",
                location_address=data.location_address if "location_address" in data else "",
                business_category=data.business_category if "business_category" in data else "",
                address_city_name=data.address_city_name if "address_city_name" in data else "",    
                address_street_name=data.address_street_name if "address_street_name" in data else "",
                address_postal_zone=data.address_postal_zone if "address_postal_zone" in data else "",
                address_building_number=data.address_building_number if "address_building_number" in data else "",
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=data.address_neighborhood if "address_neighborhood" in data else "",
                privatekey=data.privatekey if "privatekey" in data else "",
                csr=data.csr if "csr" in data else "" ,
                csr_src=data.csr_src if "csr_src" in data else "",
                egs_uuid=data.egs_uuid if "egs_uuid" in data else "",
                ccsid_requestid=data.ccsid_requestid if "ccsid_requestid" in data else "",
                ccsid_binarysecuritytoken=data.ccsid_binarysecuritytoken if "ccsid_binarysecuritytoken" in data else "",
                ccsid_secret= data.ccsid_secret if "ccsid_secret" in data else ""  ,
                pcsid_requestid=data.pcsid_requestid if "pcsid_requestid" in data else "",
                pcsid_binarysecuritytoken=  data.pcsid_binarysecuritytoken if "pcsid_binarysecuritytoken" in data else "",
                pcsid_secret= data.pcsid_secret if "pcsid_secret" in data else "" ,

            )
            db.commit()
            # imp_info = db(db.important_info.id > 0).select().first()
            # imp_info.update_record(
            #     name=data.common_name,
            #     vat=data.organization_identifier,
            # )
            # db.commit()
        return response.json("0")
    except Exception as e:
        db.rollback()
        ret = {"mess": str(e)}
        return response.json(ret)


def create_csr():
    row = db(db.csr_config.id > 0).select().first()
    current_path = os.path.dirname(os.path.abspath(__file__))
    my_path = Path(current_path).parent.resolve()
    # print("\nPYTHON CODE ONBOARDING\n")
    # Define Variable
    environment_type = "NonProduction"
    OTP = (
        row.otp
    )  # "882134"  # For Simulation and Production Get OTP from fatooraPortal
    serial_number = "1-Pre|2-Pre|3-" + str(uuid.uuid4())
    csr_config = {
        "csr.common.name": row.common_name,
        "csr.serial.number": serial_number,
        "csr.organization.identifier": row.organization_identifier,
        "csr.organization.unit.name": row.organization_unit_name,
        "csr.organization.name": row.organization_name,
        "csr.country.name": row.country_name,
        "csr.invoice.type": "1100",
        "csr.location.address": row.location_address,
        "csr.industry.business.category": row.business_category,
    }
    # print(OTP)
    # print(csr_config)
    # config_file_path = 'certificates/csr-config-example-EN.properties'
    api_path = "simulation"  # Default value
    # Determine API path based on environment type
    if environment_type == "NonProduction":
        api_path = "developer-portal"
    elif environment_type == "Simulation":
        api_path = "simulation"
    elif environment_type == "Production":
        api_path = "core"
    # Prepare certificate information
    cert_info = {
        "environmentType": environment_type,
        "csr": "",
        "privateKey": "",
        "OTP": OTP,
        "ccsid_requestID": "",
        "ccsid_binarySecurityToken": "",
        "ccsid_secret": "",
        "pcsid_requestID": "",
        "pcsid_binarySecurityToken": "",
        "pcsid_secret": "",
        "lastICV": "0",
        "lastInvoiceHash": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
        "complianceCsidUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance",
        "complianceChecksUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/compliance/invoices",
        "productionCsidUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/production/csids",
        "reportingUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single",
        "clearanceUrl": f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single",
    }
    # 1. Generate CSR and PrivateKey
    # print("\n1. Generate CSR and PrivateKey\n")
    # Generate CSR & Private Key
    csr_gen = CsrGenerator(csr_config, environment_type)
    private_key_content, csr_base64 = csr_gen.generate_csr()
    # print("\nPrivate Key (without header and footer):")
    # print(private_key_content)
    # print("\nBase64 Encoded CSR:")
    # print(csr_base64)
    cert_info["csr"] = csr_base64
    cert_info["privateKey"] = private_key_content
    os.makedirs(my_path.__str__() + "\\certificates\\", exist_ok=True)
    my_file = my_path.__str__() + "\\certificates\\certificateInfo.json"
    api_helper.save_json_to_file(my_file, cert_info)
    # 2. Get Compliance CSID
    # print("\n2. Get Compliance CSID\n")
    response = api_helper.compliance_csid(cert_info)
    request_type = "Compliance CSID"
    api_url = cert_info["complianceCsidUrl"]
    clean_response = api_helper.clean_up_json(response, request_type, api_url)
    print(clean_response)

    # response = api_helper.production_csid(cert_info)
    # request_type = "Production CSID"
    # api_url = cert_info["productionCsidUrl"]
    # clean_response = api_helper.clean_up_json(response, request_type, api_url)
    # print(clean_response)
    try:
        json_decoded_response = json.loads(response)
        cert_info["ccsid_requestID"] = json_decoded_response["requestID"]
        cert_info["ccsid_binarySecurityToken"] = json_decoded_response[
            "binarySecurityToken"
        ]
        cert_info["ccsid_secret"] = json_decoded_response["secret"]
        json_decoded_response = json.loads(response)

        cert_info["pcsid_requestID"] = json_decoded_response["requestID"]
        cert_info["pcsid_binarySecurityToken"] = json_decoded_response["binarySecurityToken"]
        cert_info["pcsid_secret"] = json_decoded_response["secret"]

        api_helper.save_json_to_file(my_file, cert_info)
        # print("\ncomplianceCSID Server Response: \n" + clean_response)
    except json.JSONDecodeError:
        print("\ncomplianceCSID Server Response: \n" + clean_response)
    return clean_response
