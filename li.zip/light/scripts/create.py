import requests
import base64
import math
import json
import os
import uuid
import os
import sys
import json
from pathlib import Path
import subprocess
import hashlib


class createCSR():
    def __init__(self,conf={} ) -> None:
        self.conf = {
            "csr_country_name"               : "SA"                                                 ,
            "csr_organization_name"          : "sdarah"                                             ,
            "csr_organization_unit_name"     : "assir"                                              ,
            "csr_common_name"                : "EA123456789"                                        ,
            "csr_serial_number"              : "1-TST|2-TST|3-ed22f1d8-e6a2-1118-9b58-d9Zzf11e445f" ,
            "csr_organization_identifier"    : "310122393500103"                                    ,
            "csr_invoice_type"               : "1100"                                               ,
            "csr_location_address"           : "sa"                                                 ,
            "csr_industry_business_category" : "IT"                                                 ,
            "emailAddress"                   : "myEmail@gmail.com"                                  ,
            "OTP"                            : "123345"
        }
        self.conf.update( conf )

    def generate_config_cnf(self)-> None :
        try:
            config_cnf = '''oid_section = OIDs
                [ OIDs ]
                certificateTemplateName= 1.3.6.1.4.1.311.20.2
                [ req ]
                default_bits = 2048
                emailAddress = ''' + str(self.conf["emailAddress"]) + '''
                req_extensions = v3_req
                x509_extensions = v3_ca
                prompt = no
                default_md = sha256
                req_extensions = req_ext
                distinguished_name = dn
                [ dn ]
                C = ''' + str(self.conf["csr_country_name"]) + '''
                OU = ''' + str(self.conf["csr_organization_unit_name"]) + '''
                O = ''' + str(self.conf["csr_organization_name"]) + '''
                CN = ''' + str(self.conf["csr_common_name"]) + '''
                [ v3_req ]
                basicConstraints = CA:FALSE
                keyUsage = digitalSignature, nonRepudiation, keyEncipherment
                [ req_ext ]
                certificateTemplateName = ASN1:PRINTABLESTRING:ZATCA-Code-Signing
                subjectAltName = dirName:alt_names            
                [ alt_names ]
                SN = ''' + str(self.conf["csr_serial_number"]) + '''
                UID = ''' + str(self.conf["csr_organization_identifier"]) + '''
                title = ''' + str(self.conf["csr_invoice_type"]) + '''
                registeredAddress = ''' + str(self.conf["csr_location_address"]) + '''
                businessCategory = ''' + str(self.conf["csr_industry_business_category"]) + '''
            '''
            THIS_FOLDER = Path(__file__).resolve().parents[1]
            my_file = os.path.join(THIS_FOLDER, "private")
            os.chdir(my_file)
            f = open('zatca.cnf', 'w+')
            f.write(config_cnf.replace(' ', '') )
            f.close()
        except Exception as e:
            print(e) 

    def generate_zatca_certificate(self)-> None :
        THIS_FOLDER = Path(__file__).resolve().parents[1]
        my_file = os.path.join(THIS_FOLDER, "private")
        zatca_dir = os.path.join(my_file, 'zatca.json')
        jsonFile = open(zatca_dir, 'r')
        zatcaData = json.load(jsonFile)
        private_key    = 'openssl ecparam -name secp256k1 -genkey -noout -out privatekey.pem'
        public_key     = 'openssl ec -in privatekey.pem -pubout -conv_form compressed -out publickey.pem'
        public_key_bin = 'openssl base64 -d -in publickey.pem -out publickey.bin'
        csr            = 'openssl req -new -sha256 -key privatekey.pem -extensions v3_req -config zatca.cnf -out taxpayper.csr'
        csr_base64     = "openssl base64 -in taxpayper.csr -out taxpayper_64.csr"
        info           = "openssl req  -noout -in taxpayper.csr -text -out csr.info"
        os.chdir(my_file)
        os.system(private_key)
        os.system(public_key)
        os.system(public_key_bin)
        os.system(csr)
        os.system(csr_base64)
        os.system(info)
        f = open('taxpayper_64.csr', 'r')
        csr = f.read()
        data = {'csr': csr.replace('\n', '')}
        headers = {
            'accept'         :           'application/json' ,
            'OTP'            : self.conf["OTP"]             ,
            'Accept-Version' :           'V2'               ,
            'Content-Type'   :           'application/json' ,
        }
        url = 'https://gw-apic-gov.gazt.gov.sa/e-invoicing/developer-portal/compliance'
        response = requests.post( url , headers=headers, json=data)
        if response.status_code==200 :
            res = response.json()
            f = open('x509.json', 'w+')
            zatcaData['csr_zatca'] = res
            json.dump(res, f, indent=4)
            #f.write(str(x509 ))
            f.close()
        else :
            print("error: "+str(response.status_code) )
        #========================================
        f = open(os.path.join(THIS_FOLDER, "private", 'csr.info'), 'r')
        signStr = ""
        startGet = False
        for line in f.read().splitlines():
            if startGet :
                signStr = signStr + line.replace(" ", "").replace(":", "")
            if line.find('Signature Value:')>0 :
                startGet = True
        zatcaData['signStr'] = signStr
        # ===============================
        signStrpub = ""
        startGet = False
        f.seek(0)
        for line in f.read().splitlines():
            if startGet:
                if line.find('OID') > 0:
                    startGet = False
                    break
                signStrpub = signStrpub + line.replace(" ", "").replace(":", "")
            if line.find('pub:') > 0:
                startGet = True
        f.close()
        csr_file = open(os.path.join(THIS_FOLDER, "private", 'taxpayper.csr'), 'rb')
        bite = csr_file.read()
        hashed_string = hashlib.sha256(bite).hexdigest()
        csr_file.close()
        base64_bytes = base64.b64encode(hashed_string.encode('utf-8'))
        zatcaData['certificate_hash'] = str(base64_bytes.decode('utf-8'))
        zatcaData['csr_organization_name'] = self.conf["csr_organization_name"]
        zatcaData['csr_serial_number'] = self.conf["csr_serial_number"]
        zatcaData['signStrpub'] = signStrpub
        zatcaData['privatekey'] = open(os.path.join(THIS_FOLDER, "private", 'privatekey.pem'), 'r').read() # .replace('-----BEGIN EC PRIVATE KEY-----', '').replace('-----END EC PRIVATE KEY-----', '').replace('\n', '')
        zatcaData['publickey'] = open(os.path.join(
            THIS_FOLDER, "private", 'publickey.pem'), 'r').read().replace('-----BEGIN PUBLIC KEY-----', '').replace('-----END PUBLIC KEY-----', '').replace('\n', '')
        zatcaData['csr'] = open(os.path.join(
            THIS_FOLDER, "private", 'taxpayper.csr'), 'r').read().replace('-----BEGIN CERTIFICATE REQUEST-----', '').replace('-----END CERTIFICATE REQUEST-----', '').replace('\n', '')
        zatcaData['csr_64'] = open(os.path.join(
            THIS_FOLDER, "private", 'taxpayper_64.csr'), 'r').read().replace('\n', '')
        # ================================
        jsonFile.close()
        jsonFile = open(zatca_dir, 'w')
        json.dump(zatcaData, jsonFile, indent=4)
        jsonFile.close()

zatca_dir = os.path.join(os.path.dirname(__file__), '..', 'private')
jsonFile = open(zatca_dir+'/zatca.json', 'r')
data = json.load(jsonFile)
jsonFile.close()
my_uuid = uuid.uuid4()
csr_serial_number = f"1-{data['csr_common_name']}|2-{data['csr_organization_identifier']}|3-{str(my_uuid)} "
conf ={
    "csr_country_name"               : "SA" ,
    "csr_organization_name"          : data['csr_organization_name'] ,
    "csr_organization_unit_name"     : data['csr_organization_unit_name'] ,
    "csr_common_name"                : data['csr_common_name'] ,
    "csr_serial_number"              : csr_serial_number ,
    "csr_organization_identifier"    : data['csr_organization_identifier'] ,
    "csr_invoice_type"               : "1100" ,
    "csr_location_address"           : "SA" ,
    "csr_industry_business_category" : data['csr_industry_business_category'],
    "emailAddress"                   : data["emailAddress"] ,
    "OTP"                            : data["OTP"] 
    }
cr = createCSR(conf)
cr.generate_config_cnf() 
cr.generate_zatca_certificate() 