# -*- coding: utf-8 -*-
{
'den': ['dny', 'dn\\xc5\\xaf'],
'dnem': ['dny', 'dny'],
'hodina': ['hodiny', 'hodin'],
'hodinou': ['hodinami', 'hodinami'],
'minuta': ['minuty', 'minut'],
'minutou': ['minutami', 'minutami'],
'měsíc': ['m\\xc4\\x9bs\\xc3\\xadce', 'm\\xc4\\x9bs\\xc3\\xadc\\xc5\\xaf'],
'měsícem': ['m\\xc4\\x9bs\\xc3\\xadci', 'm\\xc4\\x9bs\\xc3\\xadci'],
'rok': ['roky', 'let'],
'rokem': ['roky', 'lety'],
'soubor': ['soubory', 'soubor\\xc5\\xaf'],
'týden': ['t\\xc3\\xbddny', 't\\xc3\\xbddn\\xc5\\xaf'],
'týdnem': ['t\\xc3\\xbddny', 't\\xc3\\xbddny'],
'vteřina': ['vte\\xc5\\x99iny', 'vte\\xc5\\x99in'],
'vteřinou': ['vte\\xc5\\x99inami', 'vte\\xc5\\x99inami'],
'záznam': ['z\\xc3\\xa1znamy', 'z\\xc3\\xa1znam\\xc5\\xaf'],
}
