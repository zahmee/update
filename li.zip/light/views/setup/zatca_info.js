var app = new Vue({
    el: '#app',
    data: {
        uuid1: '',
        URL: this.purl,
        zatca_info: {},
        zatca_infob: {},
        zatca_files: [] ,
        vat_no: this.vat_no,
        NowDate: new Date(),
        key_payment_method: [{
            name: '',
            id: 0
        }],
        key_type: [{
            name: '',
            id: 0
        }],
        selected_method: 1,
    },
    created() {
        this.$http.get(this.URL + '/../get_zatca_info').then(response => {
            if (response.body != "") {
                this.zatca_info = response.body;
                this.zatca_infob = { ...response.body } ;
                console.log(this.zatca_infob) ;
            }
        });
        this.$http.get(this.URL + '/../get_zatca_info_files').then(response => {
            if (response.body != "") {
                this.zatca_files= response.body ;
            }
        });
    },
    methods: {
        getcustomer() {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                this.edit_customer = false;
                this.customer_info.name = "";
                this.customer_info.vat = "";

                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                // get body data
                if (response.body != "") {
                    this.customer = response.body[0]
                    this.customer.show = true;
                    //this.selected_method = 1;
                    this.edit_customer = false;
                    this.customer_info.name = "";
                    this.customer_info.vat = "";
                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                    this.edit_customer = false;
                    this.customer_info.name = "";
                    this.customer_info.vat = "";

                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                this.edit_customer = false;
                this.customer_info.name = "";
                this.customer_info.vat = "";

            });
        },
        save_data(){
            this.$http.post(this.URL + '/../update_zatca_info/', JSON.stringify(this.zatca_info), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    Swal.fire('لقد تم حفظ التعديلات .');
                    return;
                }
            });
        } ,
        cancel_data(){
            this.zatca_info = {};
            this.zatca_info = { ...this.zatca_infob } ;
            console.log(this.zatca_infob);
            Swal.fire('لقد تم التراجع عن جميع التعديلات');
        }

    },
    computed: {
    }
});
