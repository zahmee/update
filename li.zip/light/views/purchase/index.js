var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
    },
    created() {
        fetch(window.location.href + '/../get_invoices', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../get_invoices'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        get() {
            //
            //
        },
        open_add() {
            window.open(window.location.href + '/../new', '_self');
        },
        showmoor() {
            this.getData.page++;
            var url = new URL(window.location.href + '/../../customers_api/get_customers'),
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.select_obj_1.select_id,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            // if (index===0){
            //     return ;
            // }
            // console.log(index);
            // console.log(row);
            sup = {};
            this.options.forEach((el) => {
                if (el.value === row.suppliers) {
                    sup = el;
                }
            })
            if (sup === {}) {
                sup = { value: 0, label: 'اختر' };
            }
            this.edit_row_data.suppliers = sup;

            if (row.flexible_price === 'T') {
                this.edit_row_data.flexible_price = true;
            } else {
                this.edit_row_data.flexible_price = false;
            }
        },
        edit_row() {
            this.new_row = false;
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {};
            //this.edit_row_data.bill_total = parseFloat(0.0) ;
            //this.edit_row_data.bill_vat = parseFloat(0.0) ;
        },
        save_data() {
            //var myModalEl = document.getElementById('exampleModal');
            //var row_modal = bootstrap.Modal.getInstance(myModalEl);
            if (!this.edit_row_data.supplier || !this.edit_row_data.bill_no || 
                !this.edit_row_data.bill_date || !this.edit_row_data.bill_total ) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [ جميع الحقول  ] .',
                    'error'
                );
                return;
            }
            this.edit_row_data.bill_net_amount = this.bill_net_amount ;
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../new_invoice');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.data.push(this.edit_row_data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            //row_modal.hide();
                            $('#exampleModal').modal('hide')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../edit_invoice');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            $('#exampleModal').modal('hide')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    } ,
    computed: {
        bill_net_amount() {
            bill_total =0 ;
            if (this.edit_row_data.bill_total ) {
                bill_total = this.edit_row_data.bill_total ;
            }
            bill_vat = 0 
            if (this.edit_row_data.bill_vat ) {
                bill_vat = this.edit_row_data.bill_vat;
            }
            b_net = bill_total - bill_vat
            // total += parseFloat(element.total_price);
            return parseFloat(b_net).toFixed(2);
        },
    }
});
