var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        selected_method: 1,
        inv_no : '' ,
        master : {} ,
        detail : [] ,
    },
    methods: {
        getitem() {
            if (this.inv_no=='') {
                Swal.fire('يجب ادخال رقم الفاتورة')
                return;
            }
            this.$http.get(this.URL + '/../inv_view_1/' + this.selected_method+'/'+ this.inv_no ).then(response => {
                if (response.body != "") {
                    this.master = response.body ;
                    this.detail = JSON.parse(response.body.itm) ;
                } else {
                    Swal.fire('لم يتم استرجاع بيانات')
                    this.master = {} ;
                    this.detail = [] ;                }
            });
        },
        delete_inv(){
            Swal.fire({
                title: 'هل انت متأكد ؟',
                text: "لن تكون قادر على اعادة البيانات بعد حذفها",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم' ,
                cancelButtonText: 'لا'
            }).then((result) => {
                if (result.value) {
                    this.$http.get(this.URL + '/../inv_view_2/' + this.selected_method + '/' + this.inv_no).then(response => {
                        if (response.body == "1") {
                            Swal.fire(
                                'تم الحذف !',
                                'تم حذف الفاتورة ',
                                'success'
                            )
                            this.master = {};
                            this.detail = [];
                        } else {
                            Swal.fire('لم يتم استرجاع بيانات')
                            this.master = {};
                            this.detail = [];
                        }
                    });
                    
                }
            })

        }
    },
  
});
