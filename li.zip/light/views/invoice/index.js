var app = new Vue({
    el: '#app',
    data: {
        NewItem: [],
        AllItems: [],
        uuid1: '',
        uuid2: '',
        URL: this.purl,
        seller : this.seller ,
        vat_no: this.vat_no ,
        NowDate: new Date(),
        key_payment_method: [{
            name: '',
            id: 0
        }],
        key_type :[{
            name: '',
            id: 0
        }] ,
        selected_method: 1,
        selected_type: 1,
        customer: {
            'id': 1,
            'name': 'عميل نقدي',
            'show': false,
        },
        serchCustomar: {
            show: false,
            value: ''
        },
        serchCustomarList: [],
        VAT: 0.0,
        discount: 0.0,
        invoce_no: 0,
        item_dis : '' ,
        item_count : 1 ,
        item_vat : 0.15 ,
        item_price : 0.0 ,
        new_item_price : 0.0 ,
        vat_in_price : false ,
        GivenByCustomer: 0.0,
        save_clicked: true,
        customer_info:{} ,
        edit_customer : false ,
        sample_item:[] ,
        selected_sample_item: 0 ,
    },
    created() {
        this.$http.get(this.URL + '/../get_payment_method').then(response => {
            if (response.body != "") {
                this.key_payment_method = response.body;
                this.uuid1 = this.uuidv4();
            }
        });
        this.$http.get(this.URL + '/../get_key_type').then(response => {
            if (response.body != "") {
                this.key_type = response.body;
            }
        });
        this.$http.get(this.URL + '/../get_sample_item').then(response => {
            if (response.body != "") {
                this.sample_item = response.body;
            }
        });
    },
    methods: {
        getcustomer() {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                this.edit_customer = false;
                this.customer_info.name = "";
                this.customer_info.vat = "";

                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                // get body data
                if (response.body != "") {
                    this.customer = response.body[0]
                    this.customer.show = true;
                    //this.selected_method = 1;
                    this.edit_customer = false ;
                    this.customer_info.name= "" ;
                    this.customer_info.vat="" ;
                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                    this.edit_customer = false;
                    this.customer_info.name = "";
                    this.customer_info.vat = "";

                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                this.edit_customer = false;
                this.customer_info.name = "";
                this.customer_info.vat = "";

            });
        },
        removeItem(index) {
            this.AllItems.splice(index, 1);
        },
        getcount() {
            this.NewItemCount = this.NewItem;
            this.NewItem = '';
        },
        findCustomer() {
            this.serchCustomar.show = !this.serchCustomar.show;
            //this.$refs.refsearchCustomer.focus();
            //this.$refs.searchCustomer.$el.focus()
        },
        SerchCustomer() {
            if (this.serchCustomar.value.length > 2) {
                this.$http.get(this.URL + '/../../invoice/search_c/?itid=' + this.serchCustomar.value).then(response => {
                    // get body data
                    if (response.body != "") {
                        this.serchCustomarList = response.body;
                    } else {
                        this.serchCustomarList = [];
                        this.customer.id = 1;
                        this.customer.name = 'عميل نقدي';
                    }
                }, response => {
                    //this.customer.id = 1;
                    //this.customer.name = 'عميل نقدي';
                });
            } else {
                this.serchCustomarList = [];
            }
        },
        selectSerchCustomer(index) {
            this.customer.id = this.serchCustomarList[index].id;
            this.getcustomer();
            this.serchCustomar.show = !this.serchCustomar.show;
        },
        SaveAll() {
            alldata = {};
            if (this.customer.id == 1 & this.selected_method == 3) {
                Swal.fire('المبيعات النقدية يجب ان تكون بالنقدي فقط');
                return;
            }
            if (this.uuid1 === this.uuid2) {
                Swal.fire('لقد تم حفظ هذه الفاتورة بالفعل');
                return;
            }
            if (this.AllItems.length === 0 ) {
                Swal.fire('يجب ان تضيف اصناف في الفاتورة لتحفظ');
                return;
            }
            if (this.customer.id==="" || this.customer.name===""){
                Swal.fire('يجب اختيار العميل');
                return;
            }
            this.save_clicked = false;
            alldata['itm'] = this.AllItems;
            alldata['uuid'] = this.uuid1;
            alldata['net_total'] = this.net_total_price ;
            alldata['total_all'] = this.total ;
            alldata['vat'] = this.vat ;
            alldata['customer'] = this.customer.id;
            alldata['customer_info'] = this.customer_info ;
            alldata['method'] = this.selected_method;
            this.$http.post(this.URL + '/../save/', JSON.stringify(alldata), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body.invno > 0) {
                        this.invoce_no = response.body.invno;
                        this.uuid2 = this.uuid1;
                        return 'ok';
                    } if (response.body.err === "5") {
                        Swal.fire('لقد تم حفظ هذه الفاتورة بالفعل');
                        return;
                    } else {
                        Swal.fire(' لقد حصل خطأ في حفظ الفاتورة !!!!! ');
                        console.log('err');
                        return;
                    }
                } else {
                    Swal.fire(' لقد حصل خطأ في حفظ الفاتورة !!!!! ');
                    console.log('err');
                    return;
                }
            }).then(res => {
                if (res == "ok") {
                    url = window.location.origin + this.URL+ '/../show_one_invoce/' + this.invoce_no ;
                    //url = window.location.origin + this.URL+ '/../../zatca/save_inv/' + this.invoce_no ;
                    window.open(url,"_self");
                }
            });
        },
        uuidv4() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },
        bytesToHex(bytes) {
            return Array.from(
                bytes,
                byte => byte.toString(16).padStart(2, "0")
            ).join("");
        },
        hexToBase64(str) {
            return btoa(String.fromCharCode.apply(null,
                str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" "))
            );
        },
        stringToUTF8Bytes(string) {
            return new TextEncoder().encode(string);
          } ,
        getTLV(tag, val) {
            var len = parseInt(val.length.toString(2), 2).toString(16);
            var tag = parseInt(tag.toString(2), 2).toString(16);
            var vale = this.bytesToHex(this.stringToUTF8Bytes(val));
            if (len.length == 1) {
                len = '0' + len;
            }
            if (tag.length == 1) {
                tag = '0' + tag;
            }
            return tag + len + vale
        } ,
        add_new_item(){  
            if (this.item_dis.length<5 || parseFloat(this.item_count) < 0 || parseFloat(this.item_vat)<0 || parseFloat(this.item_price)<0 ){
                Swal.fire('يجب ادخال الحقول بشكل صحيح');
                return ;
            } else {
                var ItemToAdd = {} ;
                ItemToAdd.item_dis = this.item_dis ;
                ItemToAdd.item_count = this.item_count ;
                ItemToAdd.item_vat = this.item_vat ;
                if (this.vat_in_price){
                    ItemToAdd.item_price = this.new_item_price
                } else {
                    ItemToAdd.item_price = this.item_price ;
                }
                ItemToAdd.type = this.selected_type ;
                ItemToAdd.total_vat = this.item_total[0] ;
                ItemToAdd.total_price = this.item_total[1];
                this.AllItems.push(ItemToAdd) ; 
                this.item_dis = "";
                this.item_count = 1 ;
                this.item_vat = 0.15 ;
                this.item_price = 0 ;
                this.new_item_price = 0 ;
                this.selected_type = 1 ;
                this.$refs.item_dis.focus();
            }
        } ,
        editCustomer(){
            if (this.customer.id == 1 & (this.selected_method != 3 )) {
            this.edit_customer = !this.edit_customer ;
            } else {
                Swal.fire('لا يمكن تعديل الاسم للعميل يجب ان يكون عميل نقدي ');
            }
            //return 0
        } ,
        sample_item_change(event){
            if (event.target.value==0){
                this.item_dis = '' ;
            } else {
                this.sample_item.forEach(el => {
                    if (el.id == event.target.value ){
                        this.item_dis = el.disc ;
                    }                    
                });
            }
        }
    },
    computed: {
        total() {
            total = 0.0;
            this.AllItems.forEach(function (element) {
                total += parseFloat(element.total_price);
            });
            return parseFloat(total).toFixed(2);
        },
        net_total_price() {
            total = 0.0;
            this.AllItems.forEach(function (element) {
                total += parseFloat(element.item_price * element.item_count);
            });
            return parseFloat(total).toFixed(2);
        },
        now() {
            return Date.now()
        },
        vat() {
            vat = 0.0;
            this.AllItems.forEach(function (element) {
                vat += parseFloat(element.total_vat );
            });
            return parseFloat(vat).toFixed(2);
        },
        TheRest() {
            var rest = (this.GivenByCustomer - this.total ).toFixed(2)
            return rest
        } ,
        item_total(){            
            var total = 0.0 ;
            var total_vat = 0.0 ;
            total = parseFloat(this.item_count * this.item_price)
            if (this.item_vat>0) {
                if (this.vat_in_price) {
                    vat = parseFloat(total - (total / (1 + parseFloat(this.item_vat)))).toFixed(2) ;
                    price_befor = parseFloat((total - vat) / this.item_count).toFixed(2) ;
                    price_after = parseFloat(total).toFixed(2) ;
                    this.new_item_price  = price_befor ;
                    return [vat, price_after]
                } else {
                    this.new_item_price = 0 ;
                    total_vat = total * this.item_vat ;
                    return [parseFloat(total_vat).toFixed(2), parseFloat((total + total_vat)).toFixed(2) ]
                }
            } else {
                return [0, total]
            }
        }
    }
});
