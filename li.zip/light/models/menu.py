# type: ignore

response.title = request.application.replace("_", " ").title()
response.subtitle = "نظام الصدارة"
response.meta.author = "ahmed zahmah <zahmee@gmail.com>"
response.meta.description = "نظام الصدارة"
response.meta.keywords = "web2py, python, framework"
response.meta.generator = "Web2py Web Framework"


response.google_analytics_id = None
if auth.is_logged_in():
    response.menu = [
        ("العملاء", False, URL("customers", "index"), [], "fas fa-address-card"),
        (
            "المبيعات ",
            False,
            "",
            [
                (
                    "المبيعات اليومية ",
                    False,
                    URL("invoice", "index"),
                    "fal fa-money-bill-wave",
                ),
                (
                    "مرتجع المبيعات ",
                    False,
                    URL("invoice", "inv_return"),
                    "fal fa-exchange",
                ),
                (
                    "استعراض فواتير المبيعات ",
                    False,
                    URL("invoice", "invoice_show"),
                    "fal fa-receipt",
                ),
                (
                    "استعراض فواتير المرتجعات ",
                    False,
                    URL("invoice", "invoice_show_r"),
                    "fal fa-receipt",
                ),
                (
                    "_________________________",
                    False,
                    "",
                    "",
                ),
                (
                    "عرض سعر ",
                    False,
                    URL("invoice", "offer_price"),
                    "fal fa-money-bill-wave",
                ),
                (
                    "استعراض عروض الاسعار ",
                    False,
                    URL("invoice", "offer_price_show"),
                    "fal fa-receipt",
                ),
            ],
            "fas fa-shopping-cart",
        ),
        ("المشتريات", False, URL("purchase", "index"), [], "fas fa-money-bill-wave"),
    ]
if auth.has_membership("admin"):
    response.menu += (
        (
            "التقارير",
            False,
            URL("invoice", "inv_rep1"),
            [],
            "fas fa-file-invoice-dollar",
        ),
    )
if auth.has_membership("admin"):
    response.menu += (
        (
            SPAN("الإعدادات"),
            False,
            "",
            [
                ("نماذج اصناف", False, URL("setup", "sample_item"), ""),
                ("التصنيف ", False, URL("setup", "type_key"), ""),
                ("طرق الدفع ", False, URL("setup", "payment_method_key"), ""),
                (" المستخدمين", False, URL("setup", "users"), ""),
                ("صلاحيات المستخدمين ", False, URL("setup", "membership"), ""),
                ("--------------", False, URL("", ""), ""),
                ("معلومات الفاتورة", False, URL("setup", "important_info"), ""),
                ("الشعار الرسمي", False, URL("setup", "important_info_2"), ""),
                ("--------------", False, URL("", ""), ""),
                ("معلومات الربط مع الهيئة", False, URL("setup", "csr_config"), ""),
            ],
            "fas fa-tools ",
        ),
    )
if auth.is_logged_in():
    response.menu += (
        (SPAN("حول"), False, URL("default", "about"), "", "fas fa-info "),
    )
DEVELOPMENT_MENU = True
# (
#     "المعلومات الرسمية للربط بهيئة الزكاة و الضريبة و الدخل",
#     False,
#     URL("setup", "zatca_info"),
#     "",
# ),
