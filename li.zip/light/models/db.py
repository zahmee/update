# -*- coding: utf-8 -*-
# type: ignore

from gluon.contrib.appconfig import AppConfig
from gluon.tools import Auth
from datetime import datetime

if request.global_settings.web2py_version < "2.15.5":
    raise HTTP(500, "Requires web2py 2.15.5 or newer")

configuration = AppConfig(reload=True)
c = datetime.now()
exp = configuration.get("app.exp_date")
if exp:
    d1 = datetime.strptime(c.strftime("%Y-%m-%d"), "%Y-%m-%d")
    d2 = datetime.strptime(exp, "%Y-%m-%d")
    date_def = (d2 - d1).days
    if date_def < 1:
        raise HTTP(
            400,
            (
                "<h1 style='text-align: center;' > نعتذر منك لقد انتهى اشتراكك </h1>"
                f"<h2 style='text-align: center;' > {exp} </h2>"
            ),
        )


if not request.env.web2py_runtime_gae:
    db = DAL(
        configuration.get("db.uri"),
        pool_size=configuration.get("db.pool_size"),
        migrate_enabled=configuration.get("db.migrate"),
    )  # check_reserved=['all'])
else:
    db = DAL("google:datastore+ndb")
    session.connect(request, response, db=db)

response.generic_patterns = []
if request.is_local and not configuration.get("app.production"):
    response.generic_patterns.append("*")

response.formstyle = "bootstrap4_inline"
response.form_label_separator = ""

auth = Auth(db, host_names=configuration.get("host.names"))

auth.settings.extra_fields["auth_user"] = []
auth.define_tables(username=False, signature=False)

# -------------------------------------------------------------------------
# configure email
# -------------------------------------------------------------------------
mail = auth.settings.mailer
mail.settings.server = (
    "logging" if request.is_local else configuration.get("smtp.server")
)
mail.settings.sender = configuration.get("smtp.sender")
mail.settings.login = configuration.get("smtp.login")
mail.settings.tls = configuration.get("smtp.tls") or False
mail.settings.ssl = configuration.get("smtp.ssl") or False

# -------------------------------------------------------------------------
# configure auth policy
# -------------------------------------------------------------------------
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.settings.reset_password_requires_verification = True

# -------------------------------------------------------------------------
# read more at http://dev.w3.org/html5/markup/meta.name.html
# -------------------------------------------------------------------------
response.meta.author = configuration.get("app.author")
response.meta.description = configuration.get("app.description")
response.meta.keywords = configuration.get("app.keywords")
response.meta.generator = configuration.get("app.generator")
response.show_toolbar = configuration.get("app.toolbar")

# -------------------------------------------------------------------------
# your http://google.com/analytics id
# -------------------------------------------------------------------------
response.google_analytics_id = configuration.get("google.analytics_id")

# -------------------------------------------------------------------------
# maybe use the scheduler
# -------------------------------------------------------------------------
if configuration.get("scheduler.enabled"):
    from gluon.scheduler import Scheduler

    scheduler = Scheduler(db, heartbeat=configuration.get("scheduler.heartbeat"))

# -------------------------------------------------------------------------
# Define your tables below (or better in another model file) for example
#
# >>> db.define_table('mytable', Field('myfield', 'string'))
#
# Fields can be 'string','text','password','integer','double','boolean'
#       'date','time','datetime','blob','upload', 'reference TABLENAME'
# There is an implicit 'id integer autoincrement' field
# Consult manual for more options, validators, etc.
#
# More API examples for controllers:
#
# >>> db.mytable.insert(myfield='value')
# >>> rows = db(db.mytable.myfield == 'value').select(db.mytable.ALL)
# >>> for row in rows: print row.id, row.myfield
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# after defining tables, uncomment below to enable auditing
# -------------------------------------------------------------------------
# auth.enable_record_versioning(db)
auth.settings.create_user_groups = False
auth.settings.showid = False
T.force("ar")
response.delimiters = ("{{{", "}}}")


# ============================================================================
db.define_table(
    "key_payment_method", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_method.id.label = "م"

if db(db.key_payment_method.id > 0).isempty() == True:
    db.key_payment_method.insert(name="نقدي")
    db.key_payment_method.insert(name="شبكة الكترونية")
    db.key_payment_method.insert(name="آجل")
    db.key_payment_method.insert(name="حوالة بنكية")
    db.key_payment_method.insert(name="شيك")
# =============================================================================

if db(db.auth_group.id > 0).isempty() == True:
    db.auth_group.insert(role="admin")

if db(db.auth_user.id > 0).isempty() == True:
    password = db.auth_user.password.validate("5445Za@")[0]
    user_id = db.auth_user.insert(
        first_name="admin", last_name="user", password=password, email="admin@user.com"
    )
if db(db.auth_membership.id > 0).isempty() == True:
    db.auth_membership.insert(
        user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
    )

# ==============================================================================

# جدول التصنيفات للأصناف
db.define_table("key_type", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_type.id.label = "م"

if db(db.key_type.id > 0).isempty() == True:
    db.key_type.insert(name="تصنيف 1")
    db.key_type.insert(name="تصنيف 2")
    db.key_type.insert(name="تصنيف 3")
    db.key_type.insert(name="تصنيف 4")

# ------------------------------------------------------------------------------------------------------------
#  جدول العملاء
db.define_table(
    "customers",
    Field("name", length=260, label="اسم العميل", required=True),
    Field("administrator_name", length=260, label="اسم المسؤول", readable=False),
    Field("mobile", length=20, label="رقم الجوال", readable=False, unique=True),
    Field("vat", length=15, label="الرقم الضريبي", readable=False),
    Field("crn", length=15, label="السجل التجاري", readable=False),
    Field("tel", "list:string", label="هواتف العميل"),
    Field("address", "text", label="العنوان", readable=False),
    Field("note", "text", label="ملاحظات"),
    Field("total", "double", label="المشتريات", writable=False),
    Field("payed", "double", label="المسدد", writable=False),
    Field("returns", "double", label="المرتجع", writable=False),
    Field("amount", "double", label="المطلوب", writable=False),
    auth.signature,
    format="%(name)s",
)
db.customers.id.label = "م"
if db(db.customers.id > 0).isempty() == True:
    db.customers.insert(name="عميل عام - نقدي", mobile="0", vat="", address="")
#

db.define_table(
    "customers_pay",
    Field("customers_id", "reference customers", label="العميل"),
    Field(
        "amount",
        "double",
        label="المبلغ المسدد",
        requires=IS_DECIMAL_IN_RANGE(1, 100000),
    ),
    Field("note", "text", label="البيان"),
    Field(
        "customers_pay_data",
        length=12,
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    auth.signature,
)
db.customers_pay.id.label = "م"

# Accounts settlement
db.define_table(
    "customers_accounts_settlement",
    Field(
        "customers_id",
        "reference customers",
        default=request.args(0),
        label="العميل",
        readable=False,
        writable=False,
    ),
    Field("settlement_data", "datetime", default=request.now, label="تاريخ السداد"),
    auth.signature,
)
db.customers_accounts_settlement.id.label = "م"

# ==========================================================================================================

#  جدول عرض سعر - الأب
db.define_table(
    "offer_price",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("customer_info", length=260, label="بيانات العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("disc", "text", label="وصف العرض"),
    Field("vat", "double", default=0.0, label="الضريبة"),
    auth.signature,
)
db.offer_price.id.label = "م"

#  جدول عرض سعر - الابن
db.define_table(
    "offer_price_details",
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("item_dis", "text", label="وصف الصنف"),
    Field("item_count", "double", label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="نسبة الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة الضريبة"),
    auth.signature,
)


# ==================================================

#  جدول الفاتورة - الأب
db.define_table(
    "invoice_master",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("customer_info", length=260, label="بيانات العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    Field("pih_txt", "text", label="pih"),
    Field("qr_code", "text", label="qr"),
    Field("xml_file", "text", label="xml"),
    Field("zatca_res", "text", label="zatca"),
    Field("sim_invoce", "boolean", default=True, label="فاتورة مبيعات مبسطة"),
    Field("send_to_zatca", "boolean", default=False, label="تم ارسال الفاتورة"),
    auth.signature,
)
db.invoice_master.id.label = "م"

#  جدول الفاتورة - الابن
db.define_table(
    "invoice_details",
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("item_dis", "text", label="وصف الصنف"),
    Field("item_count", "double", label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="نسبة الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة الضريبة"),
    auth.signature,
)

#  جدول مرتجع المبيعات - الأب
db.define_table(
    "inv_return_master",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("customer_info", length=260, label="بيانات العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    Field("pih_txt", "text", label="pih"),
    Field("qr_code", "text", label="qr"),
    Field("xml_file", "text", label="xml"),
    Field("zatca_res", "text", label="zatca"),
    Field("sim_invoce", "boolean", default=True, label="فاتورة مبيعات مبسطة"),
    Field("send_to_zatca", "boolean", default=False, label="تم ارسال الفاتورة"),
    auth.signature,
)

#  جدول مرتجع المبيعات - الأبن
db.define_table(
    "inv_return_details",
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("item_dis", "text", label="وصف الصنف"),
    Field("item_count", "double", label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="نسبة الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة الضريبة"),
    auth.signature,
)


# ===========================================================================================
#  جدول الانظمة
db.define_table("systems", Field("name", length=270, label="النظام"), format="%(name)s")
if db(db.systems.id > 0).isempty() == True:
    db.systems.insert(name="نظام الرئيسي")

# ===========================================================================================
#  جدول الشاشات
db.define_table(
    "screens",
    Field("systems", "reference systems", default=request.args(0), label="النظام"),
    Field("name", length=270, label="اسم الشاشة"),
    Field("screen_code", "integer", label="كود الشاشة"),
    format="%(screen_code)s - %(name)s",
)

# ===========================================================================================
#  جدول صلاحيات الشاشات
db.define_table(
    "screens_rules",
    Field("to_user", "reference auth_user", label="المستخدم"),
    Field("screens", "reference screens", label="الشاشة"),
    Field("can_log_in", "boolean", default=False, label="الدخول"),
    Field("can_add", "boolean", default=False, label="الاضافة"),
    Field("can_edit", "boolean", default=False, label="التعديل"),
    Field("can_delete", "boolean", default=False, label="الحذف"),
)
# ===========================================================================================
#  جدول معلومات الجهه
db.define_table(
    "important_info",
    Field(
        "name",
        length=370,
        label="الاسم ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
        writable=True,
        readable=True,
    ),
    Field(
        "vat",
        length=100,
        label="الرقم الضريبي ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
        writable=False,
        readable=False,
    ),
    Field(
        "tel",
        length=25,
        label="رقم الهاتف الارضي ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "mobile",
        length=25,
        label="رقم الجوال / الواتس آب ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "address",
        "text",
        default=" ",
        label="العنوان",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
        writable=False,
        readable=False,
    ),
    Field("msg1", "text", default=" ", label="رسالة للعميل"),
    Field("msg2", "text", default=" ", label="رسالة آخر الفاتورة"),
    Field("currency", length=50, default="ريال سعودي", label="العملة"),
    Field(
        "logo",
        "upload",
        autodelete=True,
        label="الشعار",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("send_sms", "boolean", default=True, label="ارسال رسائل للعميل"),
    Field("last_inv_no", "integer", default=0, writable=False, readable=False),
    Field("last_inv_phi", length=200, writable=False, readable=False),
    Field("last_r_inv_no", "integer", default=0, writable=False, readable=False),
    Field("last_r_inv_phi", length=200, writable=False, readable=False),
)
if db(db.important_info.id > 0).isempty() == True:
    db.important_info.insert(
        name=" مؤسسة ......",
        vat="0",
        tel="0",
        mobile="05",
        address="العنوان",
        msg1="----",
        msg2="----",
    )
# ===========================================================================================


def can_access(*argument):
    if auth.user:

        def decorator(function):
            def wrapper(*args, **kwargs):
                # print (argument[0])
                screen_code = db(db.screens.screen_code == argument[0]).select().first()
                if not screen_code:
                    return redirect(URL("default", "not_allow"))
                acc = (
                    db(
                        (db.screens_rules.screens == screen_code.id)
                        & (db.screens_rules.to_user == auth.user.id)
                        & (db.screens_rules.can_log_in == True)
                    )
                    .select()
                    .first()
                )
                if acc:
                    result = function(*args, **kwargs)
                    return result
                else:
                    return redirect(URL("default", "not_allow"))

            return wrapper

        return decorator
    else:
        return redirect(URL("default", "not_allow"))


def screens_rules(sc):
    screen_code = db(db.screens.screen_code == sc).select().first
    acc = (
        db(
            (db.screens_rules.screens == screen_code)
            & (db.screens_rules.to_user == auth.user.id)
        )
        .select()
        .first()
    )
    return acc


# data = db.executesql("CREATE EXTENSION IF NOT EXISTS tablefunc;")

# جدول نماذج للأصناف
db.define_table(
    "sample_item",
    Field("name", length=50, label="مختصر الاسم"),
    Field("disc", "text", label="الوصف"),
    format="%(name)s",
)
db.sample_item.id.label = "م"

# ========================================================================
#                             Purchase invoices
# ========================================================================
# -----------------------------------------------------------------------------------------
#  فواتير التوريد
db.define_table(
    "purchase_invoices",
    Field("supplier", length=150, label="المورد"),
    Field(
        "bill_no",
        length=15,
        label="رقم الفاتورة من المورد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_date",
        "date",
        label="تاريخ الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_total",
        "double",
        label="اجمالي المبلغ مع الضريبة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_net_amount",
        "double",
        label="صافي المبلغ بدون ضريبة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_vat",
        "double",
        label="صافي الضريبة من المورد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    auth.signature,
    format="%(name)s",
)
db.purchase_invoices.id.label = "م"


db.executesql("CREATE EXTENSION IF NOT EXISTS tablefunc; ")
# ===========================================================================================
#  جدول رسائل النظام
db.define_table(
    "public_msg",
    Field("msg_id", "integer", label="رقم الرسالة", unique=True),
    Field("msg_text", "text", label="الرسالة"),
    Field("msg_count", "integer"),
    Field("msg_max", "integer"),
)
# ===========================================================================================
db.define_table(
    "csr_config",
    Field("otp", length=6),
    Field("serial_number", length=55),
    Field("common_name", length=250),
    Field("organization_name", length=250),
    Field("organization_identifier", length=15),
    Field("organization_unit_name", length=250),
    Field("country_name", length=3),
    Field("invoice_type", length=4),
    Field("location_address", length=10),
    Field("business_category", length=200),
    Field("address_city_name", length=50),
    Field("address_street_name", length=50),
    Field("address_postal_zone", length=10),
    Field("address_building_number", length=5),
    Field("address_neighborhood", length=25),
    Field("company_id", length=15),
    Field("company_uuid", length=40),
    # step 1
    Field("privatekey", "text"),
    Field("csr", "text"),
    Field("csr_src", "text"),
    Field("egs_uuid", length=40),
    Field("ccsid_requestid", length=40),
    Field("ccsid_binarysecuritytoken", "text"),
    Field("ccsid_secret", "text"),
    # step 2
    Field("pcsid_requestid", length=40),
    Field("pcsid_binarysecuritytoken", "text"),
    Field("pcsid_secret", "text" ),
    # inv nombering
    Field("icv", "integer", default=1),
    Field("pih", "text" ),

)
