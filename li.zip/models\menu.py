# type: ignore

response.title = request.application.replace("_", " ").title()
response.subtitle = "نظام الصدارة"
response.meta.author = "ahmed zahmah <zahmee@gmail.com>"
response.meta.description = "نظام الصدارة"
response.meta.keywords = "web2py, python, framework"
response.meta.generator = "Web2py Web Framework"


response.google_analytics_id = None
if auth.is_logged_in():
    response.menu = [
        ("العملاء", False, URL("customers", "index"), [], "fas fa-address-card"),
        (
            "المبيعات ",
            False,
            "",
            [
                (
                    "المبيعات اليومية ",
                    False,
                    URL("invoice", "index"),
                    "fal fa-money-bill-wave",
                ),
                (
                    "مرتجع المبيعات ",
                    False,
                    URL("invoice", "inv_return"),
                    "fas fa-undo-alt",
                ),
                (
                    "استعراض فواتير المبيعات ",
                    False,
                    URL("invoice", "invoice_show"),
                    "fas fa-receipt",
                ),
                (
                    "استعراض فواتير المرتجعات ",
                    False,
                    URL("invoice", "invoice_show_r"),
                    "fas fa-file-excel",
                ),
                (
                    "_________________________",
                    False,
                    "",
                    "",
                ),
                (
                    "عرض سعر ",
                    False,
                    URL("invoice", "offer_price"),
                    "fas fa-tag",
                ),
                (
                    "استعراض عروض الاسعار ",
                    False,
                    URL("invoice", "offer_price_show"),
                    "fas fa-list-alt",
                ),
            ],
            "fas fa-shopping-cart",
        ),
        ("المشتريات", False, URL("purchase", "index"), [], "fas fa-money-bill-wave"),
        ("مستنداتي", False, URL("default", "my_documents"), [], "fas fa-folder-open"),
        ("الحضور", False, URL("attendance", "index"), [], "fas fa-fingerprint"),
    ]
if auth.has_membership("admin"):
    response.menu += (
        (
            "التقارير",
            False,
            URL("invoice", "inv_rep1"),
            [],
            "fas fa-file-invoice-dollar",
        ),
    )
if auth.has_membership("admin"):
    response.menu += (
        (
            "شؤون الموظفين",
            False,
            "",
            [
                ("الموظفين", False, URL("employees", "index"), "fas fa-users"),
                ("الرواتب", False, URL("salaries", "index"), "fas fa-money-check-alt"),
                ("السلفيات", False, URL("advances", "index"), "fas fa-hand-holding-usd"),
                ("الإجازات", False, URL("leaves", "index"), "fas fa-umbrella-beach"),
                ("--------------", False, "", ""),
                ("مسير الرواتب", False, URL("payroll", "index"), "fas fa-file-invoice-dollar"),
                ("--------------", False, "", ""),
                ("تقرير الحضور", False, URL("attendance", "report"), "fas fa-clipboard-list"),
            ],
            "fas fa-user-tie",
        ),
    )
if auth.has_membership("admin"):
    response.menu += (
        (
            SPAN("الإعدادات"),
            False,
            "",
            [
                ("نماذج اصناف", False, URL("setup", "sample_item"), "fas fa-box-open"),
                ("التصنيف ", False, URL("setup", "type_key"), "fas fa-tags"),
                (
                    "طرق الدفع ",
                    False,
                    URL("setup", "payment_method_key"),
                    "fas fa-credit-card",
                ),
                (" المستخدمين", False, URL("setup", "users"), "fas fa-users"),
                (
                    "صلاحيات المستخدمين ",
                    False,
                    URL("setup", "membership"),
                    "fas fa-user-lock",
                ),
                ("--------------", False, URL("", ""), ""),
                (
                    "معلومات الفاتورة",
                    False,
                    URL("setup", "important_info"),
                    "fas fa-file-invoice",
                ),
                ("--------------", False, URL("", ""), ""),
                (
                    "معلومات الربط مع الهيئة",
                    False,
                    URL("zatca_onboard", "index"),
                    "fas fa-plug",
                ),
            ],
            "fas fa-tools ",
        ),
    )
if auth.is_logged_in():
    response.menu += (
        (SPAN("حول"), False, URL("default", "about"), "", "fas fa-info "),
    )
DEVELOPMENT_MENU = True
#                ("الشعار الرسمي", False, URL("setup", "important_info_2"), "fas fa-image"),
# (
#     "المعلومات الرسمية للربط بهيئة الزكاة و الضريبة و الدخل",
#     False,
#     URL("setup", "zatca_info"),
#     "",
# ),
