# -*- coding: utf-8 -*-
# ======================================================================================
# type: ignore

@can_access(1001)
def get_customers():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where = ""
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != "":
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = "%" + srt[i] + "%"
            if i == 0:
                where = " where ( name like %s or mobile like %s ) "
            else:
                where += " and ( name like %s or mobile like %s ) "
            params.extend([pattern, pattern])
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = "id"
    if ReqVar.sequence:
        if ReqVar.sequence == "true":
            sa = "ASC"
        else:
            sa = "desc"
    else:
        sa = "ASC"
    pg = int(int(pg) * int(rc))
    where = where.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("and  and", "and")
    sql = " SELECT id,name,mobile, address,vat,crn FROM customers " + where + " order by " + sc + " " + sa + " limit %s OFFSET %s ; "
    sql = sql.replace("and  order", "order")
    sql2 = " SELECT count(*) FROM customers  " + where + " ; "
    sql2 = sql2.replace("and   ;", "; ")
    qry = db.executesql(sql, placeholders=params + [rc, pg], as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def new_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(
            db, "customers.mobile", error_message="يوجد هذا الرقم مسجل مسبقا"
        )
        if data.vat and len(data.vat) != 15 :
            return response.json({"err": 1, "mess": "رقم القيمة المضافة غير صحيح"})
        nid = db.customers.validate_and_insert(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            vat=data.vat,
            crn =data.crn,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


def edit_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(
            db, "customers.mobile", error_message="يوجد هذا الرقم مسجل مسبقا"
        )
        if data.vat and len(data.vat) != 15 :
            return response.json({"err": 1, "mess": "رقم القيمة المضافة غير صحيح"})
        row = db.customers[data.id]
        row.update_record(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            vat=data.vat,
            crn=data.crn,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)
