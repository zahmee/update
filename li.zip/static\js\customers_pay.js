var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        customerId: customerId,
        data: [],
        dataCount: 0,
        totalPaid: 0,
        page: 0,
        recordCount: 20,
        searchText: '',
        isEdit: false,
        form: {
            id: null,
            amount: '',
            note: ''
        },
        printUrl: printUrl
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.dataCount / this.recordCount) || 1;
        },
        currentPage: function () {
            return this.page + 1;
        },
        visiblePages: function () {
            var pages = [];
            var start = Math.max(1, this.page - 2);
            var end = Math.min(this.totalPages, this.page + 4);
            if (end - start < 4) {
                start = Math.max(1, end - 4);
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            return pages;
        },
        formTitle: function () {
            return this.isEdit ? 'تعديل سداد' : 'إضافة سداد جديد';
        }
    },
    created: function () {
        this.loadData();
    },
    methods: {
        loadData: function () {
            var params = 'page=' + this.page + '&RecordCount=' + this.recordCount + '&SearchText=' + encodeURIComponent(this.searchText);
            this.$http.get(this.URL + '/../customers_pay_list/' + this.customerId + '?' + params).then(function (res) {
                this.data = res.body.data;
                this.dataCount = res.body.count;
                this.totalPaid = res.body.total_paid;
            });
        },
        onSearch: function () {
            this.page = 0;
            this.loadData();
        },
        goToPage: function (p) {
            if (p < 0 || p >= this.totalPages || p === this.page) return;
            this.page = p;
            this.loadData();
        },
        resetForm: function () {
            this.form = { id: null, amount: '', note: '' };
            this.isEdit = false;
        },
        openAdd: function () {
            this.resetForm();
            showModal('payModal');
        },
        openEdit: function (row) {
            this.isEdit = true;
            this.form = {
                id: row.id,
                amount: row.amount,
                note: row.note || ''
            };
            showModal('payModal');
        },
        saveRow: function () {
            if (!this.form.amount || parseFloat(this.form.amount) <= 0) {
                Swal.fire('يجب ادخال مبلغ صحيح');
                return;
            }
            this.$http.post(
                this.URL + '/../customers_pay_save/' + this.customerId,
                JSON.stringify(this.form),
                { emulateJSON: true }
            ).then(function (res) {
                if (res.body.err === 0) {
                    Swal.fire({
                        title: res.body.mess,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    hideModal('payModal');
                    this.page = 0;
                    this.loadData();
                } else {
                    Swal.fire(res.body.mess);
                }
            });
        },
        deleteRow: function (id) {
            Swal.fire({
                title: 'هل انت متأكد ؟',
                text: 'سيتم حذف هذا السند',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then(function (result) {
                if (result.value) {
                    this.$http.get(this.URL + '/../customers_pay_delete/' + this.customerId + '/' + id).then(function (res) {
                        if (res.body.err === 0) {
                            Swal.fire({
                                title: 'تم الحذف',
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            });
                            this.page = 0;
                            this.loadData();
                        } else {
                            Swal.fire(res.body.mess);
                        }
                    });
                }
            }.bind(this));
        }
    }
});
