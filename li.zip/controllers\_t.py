# coding: utf8
# type: ignore
import os
import shutil
import zipfile
import subprocess
import urllib.request
from datetime import datetime


def fix():
    qry = "PGPASSWORD='5445za' psql -h localhost -U admin -d pha -c \" GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to admin ; \" "
    s = os.popen(qry)
    preprocessed = s.read()
    s.close()
    return preprocessed


def db():
    _appPath = request.folder
    backupdir = _appPath + "/static/db.tar"
    configuration = AppConfig(reload=True)
    dbname = configuration.get("db.uri").split("/")
    script = (
        "PGPASSWORD='5445za' pg_dump -h localhost -U admin -F t "
        + dbname[-1]
        + " >  %s" % (backupdir)
    )
    s = os.popen(script)
    preprocessed = s.read()
    s.close()
    return redirect(URL("static", "db.tar"))


def _get_local_version():
    ver_file = os.path.join(request.folder, "li_ver.txt")
    if os.path.exists(ver_file):
        stats = os.stat(ver_file)
        mod_time = datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
        with open(ver_file, "r") as f:
            ver = f.read().strip()
        return ver, mod_time
    return "0", ""


def _get_remote_version():
    url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/li_ver.txt"
    req = urllib.request.urlopen(url, timeout=10)
    return req.read().decode().strip()


def up():
    local_ver, local_mod_time = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception:
        remote_ver = None

    return dict(
        local_ver=local_ver,
        local_mod_time=local_mod_time,
        remote_ver=remote_ver,
        updated=False,
        error=None,
    )


def remote_version():
    """إرجاع رقم الإصدار البعيد فقط"""
    try:
        ver = _get_remote_version()
        return response.json({'version': ver, 'status': 'ok'})
    except Exception as e:
        return response.json({'version': None, 'status': 'error', 'message': str(e)})


def _clear_pycache(root_path):
    for dirpath, dirnames, _ in os.walk(root_path):
        for d in list(dirnames):
            if d == "__pycache__":
                try:
                    shutil.rmtree(os.path.join(dirpath, d), ignore_errors=True)
                except OSError:
                    pass


def up_do():
    github_url = "https://github.com/zahmee/update/raw/refs/heads/main/li.zip"
    app_path = request.folder
    zip_path = os.path.join(app_path, "li.zip")
    local_ver_before, _ = _get_local_version()

    # 1) تنزيل ملف التحديث باستخدام curl
    try:
        result = subprocess.run(
            ["curl", "-L", "--max-time", "120", "-o", zip_path, github_url],
            capture_output=True, text=True, timeout=150,
        )
        if result.returncode != 0:
            raise Exception(result.stderr or "curl download failed")
        if not os.path.exists(zip_path) or os.path.getsize(zip_path) < 100:
            raise Exception("الملف الذي تم تنزيله فارغ أو غير مكتمل")
    except subprocess.TimeoutExpired:
        if os.path.exists(zip_path):
            os.remove(zip_path)
        return response.json(dict(err=1, mess="انتهت مهلة تنزيل ملف التحديث"))
    except Exception as e:
        if os.path.exists(zip_path):
            os.remove(zip_path)
        return response.json(dict(err=1, mess="فشل تنزيل ملف التحديث: " + str(e)))

    # 2) احصِ عدد الملفات قبل الفك
    file_count = 0
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            file_count = len(zf.namelist())
    except Exception:
        pass

    # 3) فك الضغط بأوامر النظام
    try:
        if os.name == "nt":
            ps_cmd = (
                "Expand-Archive -Path '{}' -DestinationPath '{}' -Force"
                .format(zip_path.replace("'", "''"), app_path.replace("'", "''"))
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode != 0:
                raise Exception(result.stderr or "Expand-Archive failed")
        else:
            with zipfile.ZipFile(zip_path, "r") as zf:
                for info in zf.infolist():
                    info.filename = info.filename.replace("\\", "/")
                    zf.extract(info, app_path)
    except subprocess.TimeoutExpired:
        return response.json(dict(err=1, mess="انتهت مهلة فك ضغط ملف التحديث"))
    except Exception as e:
        return response.json(dict(err=1, mess="فشل فك الضغط: " + str(e)))
    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass

    # 4) ضبط الصلاحيات على لينكس (0755 للمجلدات، 0644 للملفات)
    if os.name != "nt":
        for root, dirs, files in os.walk(app_path):
            for d in dirs:
                try:
                    os.chmod(os.path.join(root, d), 0o755)
                except OSError:
                    pass
            for f in files:
                try:
                    os.chmod(os.path.join(root, f), 0o644)
                except OSError:
                    pass

    # 5) تنظيف __pycache__
    _clear_pycache(app_path)

    local_ver_after, local_mod_time = _get_local_version()

    return response.json(dict(
        err=0,
        mess="تمت عملية التحديث بنجاح",
        ver_before=local_ver_before,
        ver_after=local_ver_after,
        mod_time=local_mod_time,
        file_count=file_count,
    ))
