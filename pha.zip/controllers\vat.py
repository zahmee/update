# -*- coding: utf-8 -*-
#  type: ignore

import xlsxwriter
import datetime
import io
import re
import sys

@can_access(9001)
def index():
	response.title = "الرئيسية"
	return dict()

# تقرير بالاصناف
@can_access(9001)
def excl_inv_det():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    if var2 == 11 :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = "
		" ( select customer from invoice_master  "
		"  where invoice_master.uuid = invoice_details.uuid ) ) as coust  , "
		"  ( select name from key_payment_method where id =  "
		"   ( select payment_method from invoice_master  "
		"    where invoice_master.uuid = invoice_details.uuid ) ) as payment_method  , "
		"    ( select id  from invoice_master  "
		" 	where invoice_master.uuid = invoice_details.uuid  ) as inv_no  , "
		" 	( select id from items_det where id = item_number ) as id_det , "
		" 	( select name from items_main where id =  "
		" 	 ( select item_idr from items_det where id = item_number ) ) as name , "
		" 	 vat , item_count ,created_on , "
		" 	  ( select public_price from items_det where id = item_number ) as price , "
		" 	   total , "
		" 	   vat_total "
		" 	 from invoice_details  where created_on > %s and created_on < %s "
		"   and exists ( select 1 from invoice_master m where m.uuid = invoice_details.uuid and m.send_to_zatca = 'T' ) " )
    q = db.executesql(qry, placeholders=[sart_date, end_date], as_dict=True)
    # inf = db(db.information.id>0).select().first()
    # q = db((db.account_movement.date_year == inf.present_year ) and (db.account_movement.date_month == inf.present_month )).select()
    filename = 'excel_movment_det_ret_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()

    worksheet.write('A1', u'الفاتورة', bold  )
    worksheet.write('A1', u'الدفع', bold  )
    worksheet.write('A1', u'اسم العميل', bold  )
    worksheet.write('B1', u'رقم الصنف', bold  )
    worksheet.write('C1', u'اسم الصنف', bold  )
    worksheet.write('D1', u'VAT', bold )
    worksheet.write('E1', u' العدد', bold )
    worksheet.write('F1', u'المبلغ', bold )
    worksheet.write('G1', u'الاجمالي', bold )
    worksheet.write('H1', u'الضريبة المحصلة', bold )
    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 12)
    worksheet.set_column('E:E', 50)
    worksheet.set_column('F:F', 22)
    worksheet.set_column('G:G',12)
    worksheet.set_column('H:H', 20)
    worksheet.set_column('I:I', 20)
    worksheet.set_column('J:J', 20)
    worksheet.set_column('K:K', 20)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']         , format  )
        worksheet.write  ( row , col + 1  , r['payment_method']  , format  ) 
        worksheet.write  ( row , col + 2  , r['coust'] or '--'            , format  )
        worksheet.write  ( row , col + 3  , r['id_det']         , format  ) 
        worksheet.write  ( row , col + 4  , r['name'] or '--'            , format  )  
        worksheet.write  ( row , col + 5  , r['vat']            , format  )
        worksheet.write  ( row , col + 6  , round(float(r['item_count'] or 0 ),2)    , format  )
        worksheet.write  ( row , col + 7  , round(float(r['price'] or 0  ),2)        , format  )
        worksheet.write  ( row , col + 8  , round(float(r['total'] or 0  ),2)        , format  )
        worksheet.write  ( row , col + 9  , round(float(r['vat_total'] or 0 ),2)      , format  )
        worksheet.write  ( row , col + 10 , r['created_on']     , format2  )
        row += 1
    worksheet.add_table('A1:K'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'رقم الصنف' , 'header_format' : bold},
         {'header': u'اسم الصنف' , 'header_format' : bold },
         {'header': u'VAT', 'header_format' : bold },
         {'header': u' العدد' , 'header_format' : bold },
         {'header': u'المبلغ' , 'header_format' : bold },
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})

    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

#==============================================================================================================

@can_access(9001)
def excl_inv_det_re():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    if var2 == 11 :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = "
		" ( select customer from inv_return_master  "
		"  where inv_return_master.uuid = inv_return_details.uuid ) ) as coust  , "
		"  ( select name from key_payment_method where id =  "
		"   ( select payment_method from inv_return_master  "
		"    where inv_return_master.uuid = inv_return_details.uuid ) ) as payment_method  , "
		"    ( select id  from inv_return_master  "
		" 	where inv_return_master.uuid = inv_return_details.uuid  ) as inv_no  , "
		" 	( select id from items_det where id = item_number ) as id_det , "
		" 	( select name from items_main where id =  "
		" 	 ( select item_idr from items_det where id = item_number ) ) as name , "
		" 	 vat , item_count ,created_on , "
		" 	  ( select public_price from items_det where id = item_number ) as price , "
		" 	   total , "
		" 	   vat_total "
		" 	 from inv_return_details  where created_on > %s and created_on < %s "
		"   and exists ( select 1 from inv_return_master m where m.uuid = inv_return_details.uuid and m.send_to_zatca = 'T' ) " )
    q = db.executesql(qry, placeholders=[sart_date, end_date], as_dict=True)
    # inf = db(db.information.id>0).select().first()
    # q = db((db.account_movement.date_year == inf.present_year ) and (db.account_movement.date_month == inf.present_month )).select()
    filename = 'excel_movment_det_ret_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()

    worksheet.write('A1', u'الفاتورة', bold  )
    worksheet.write('A1', u'الدفع', bold  )
    worksheet.write('A1', u'اسم العميل', bold  )
    worksheet.write('B1', u'رقم الصنف', bold  )
    worksheet.write('C1', u'اسم الصنف', bold  )
    worksheet.write('D1', u'VAT', bold )
    worksheet.write('E1', u' العدد', bold )
    worksheet.write('F1', u'المبلغ', bold )
    worksheet.write('G1', u'الاجمالي', bold )
    worksheet.write('H1', u'الضريبة المحصلة', bold )
    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 12)
    worksheet.set_column('E:E', 50)
    worksheet.set_column('F:F', 22)
    worksheet.set_column('G:G',12)
    worksheet.set_column('H:H', 20)
    worksheet.set_column('I:I', 20)
    worksheet.set_column('J:J', 20)
    worksheet.set_column('K:K', 20)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']         , format  )
        worksheet.write  ( row , col + 3  , r['id_det']         , format  ) 
        worksheet.write  ( row , col + 1  , r['payment_method']  , format  ) 
        worksheet.write  ( row , col + 2  , r['coust']          , format  )
        worksheet.write  ( row , col + 4  , r['name']            , format  )  
        worksheet.write  ( row , col + 5  , r['vat']            , format  )
        worksheet.write  ( row , col + 6  , round(float(r['item_count'] or 0 ),2)    , format  )
        worksheet.write  ( row , col + 7  , round(float(r['price'] or 0  ),2)        , format  )
        worksheet.write  ( row , col + 8  , round(float(r['total'] or 0  ),2)        , format  )
        worksheet.write  ( row , col + 9  , round(float(r['vat_total'] or 0 ),2)      , format  )
        worksheet.write  ( row , col + 10 , r['created_on']     , format2  )
        row += 1
    worksheet.add_table('A1:K'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'رقم الصنف' , 'header_format' : bold},
         {'header': u'اسم الصنف' , 'header_format' : bold },
         {'header': u'VAT', 'header_format' : bold },
         {'header': u' العدد' , 'header_format' : bold },
         {'header': u'المبلغ' , 'header_format' : bold },
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})

    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

 #==============================================================================================================

@can_access(9001)
def excl_inv_mas():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    end_date = ''
    if var2 == "12" :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = invoice_master.customer ) as coust  , "
	        " ( select name from key_payment_method where id = invoice_master.payment_method ) as payment_method  , "
	        "  id  as inv_no  , vat , created_on ,total  "
		    " from invoice_master  where created_on > %s and created_on < %s "
		    "  and invoice_master.send_to_zatca = 'T' " )
    q = db.executesql(qry, placeholders=[sart_date, end_date], as_dict=True)
    filename = 'excel_movment_mas_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')
    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')
    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()
    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 20)
    worksheet.set_column('E:E', 20)
    worksheet.set_column('F:F', 22)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']  , format  )
        worksheet.write  ( row , col + 1  , r['payment_method'] or '-'  , format  )
        worksheet.write  ( row , col + 2  , r['coust'] or '-'    , format  )
        worksheet.write  ( row , col + 3  , round((r['total'] or 0),2)  , format  )
        worksheet.write  ( row , col + 4  , round((r['vat'] or 0 ),2) , format  )
        worksheet.write  ( row , col + 5 , r['created_on']   , format2  )
        row += 1
    worksheet.add_table('A1:F'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})

    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

 #==============================================================================================================

@can_access(9001)
def excl_inv_mas_re():
    var1 = request.args(0) 
    var2 = request.args(1)
    sart_date = str(var1)+'-'+str(var2)+'-'+'01'
    if var2 == "12" :
        end_date = str(int(var1)+1)+'-01-01'
    else :
        end_date = str(var1)+'-'+str(int(var2)+1)+'-'+'01'
    qry = ("select ( select name from customers where id = inv_return_master.customer ) as coust  , "
	        " ( select name from key_payment_method where id = inv_return_master.payment_method ) as payment_method  , "
	        "  id  as inv_no  , vat , created_on ,total  "
		    " from inv_return_master  where created_on > %s and created_on < %s "
		    "  and inv_return_master.send_to_zatca = 'T' " )
    q = db.executesql(qry, placeholders=[sart_date, end_date], as_dict=True)
    filename = 'excel_movment_mas_ret_'+var1+'_'+var2+'.xlsx'
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream , {'in_memory': True})
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align('center')
    bold.set_bold()
    bold.set_font_name('Segoe UI')

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name('Segoe UI')

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name('Segoe UI')
    memo.set_text_wrap()

    # ---------------------------------------------------------------
    worksheet.set_column('A:A', 12)
    worksheet.set_column('B:B', 30)
    worksheet.set_column('C:C', 30)
    worksheet.set_column('D:D', 20)
    worksheet.set_column('E:E', 20)
    worksheet.set_column('F:F', 22)
    format2 = workbook.add_format({'num_format': 'dd/mm/yyyy'})
    row = 1
    col = 0
    for r in (q):
        worksheet.write  ( row , col      , r['inv_no']  , format  )
        worksheet.write  ( row , col + 1  , r['payment_method']  , format  )
        worksheet.write  ( row , col + 2  , r['coust']    , format  )
        worksheet.write  ( row , col + 3  , round((r['total'] or 0),2)  , format  )
        worksheet.write  ( row , col + 4  , round((r['vat'] or 0 ),2) , format  )
        worksheet.write  ( row , col + 5 , r['created_on']   , format2  )
        row += 1
    worksheet.add_table('A1:F'+str(row ), {
     'columns':[
         {'header': u'الفاتورة' , 'header_format' : bold},
         {'header': u'الدفع' , 'header_format' : bold},
         {'header': u'اسم العميل' , 'header_format' : bold},
         {'header': u'الاجمالي' , 'header_format' : bold },
         {'header': u'الضريبة المحصلة' , 'header_format' : bold },
         {'header': u'التاريخ' , 'header_format' : bold },
        ]})
    workbook.close()
    stream.seek(0)
    response.headers['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    response.headers['Content-Type']= 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['charset'] = 'utf8'
    response.headers['content_encoding'] = 'utf8'
    return (stream.read())

 #==============================================================================================================


_REPORT_DT = re.compile(
    r"^\s*(\d{1,4})[-/](\d{1,2})[-/](\d{1,4})(?:[ T]+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?\s*$"
)


def _report_dt(value):
    """يحوّل تاريخ التقرير إلى datetime في بايثون: شهر-يوم-سنة ساعة:دقيقة كما ترسله
    شاشة الضريبة، أو سنة-شهر-يوم. لا يُمرَّر نصاً إلى PostgreSQL لأن قراءته تتبع إعداد
    DateStyle في الخادم: على 'ISO, YMD' يُرفض 7-1-2026 فيتعطل التقرير.
    يعيد (الوقت، النص المعروض، اليوم المكتوب) أو (None, None, None) إن كان غير صالح؛
    24:00 = بداية اليوم التالي، لكن اليوم المكتوب يبقى نفسه (لأعمدة التاريخ بلا وقت)."""
    m = _REPORT_DT.match(str(value or ""))
    if not m:
        return None, None, None
    a, b, c, hh, mi, ss = m.groups()
    if len(a) == 4:
        year, month, day = int(a), int(b), int(c)
    else:
        month, day, year = int(a), int(b), int(c)
    hh, mi, ss = int(hh or 0), int(mi or 0), int(ss or 0)
    try:
        day_start = datetime.datetime(year, month, day)
        if hh == 24 and mi == 0 and ss == 0:
            label = day_start.strftime("%Y-%m-%d") + " 24:00"
            return day_start + datetime.timedelta(days=1), label, day_start.date()
        dt = day_start.replace(hour=hh, minute=mi, second=ss)
    except ValueError:
        return None, None, None
    return dt, dt.strftime("%Y-%m-%d %H:%M"), dt.date()


def _report_period():
    """فترة تقارير الضريبة rep11/12/13 من da1/da2؛ الفارغ = الآن كما كان.
    da1/da2 للأعمدة ذات الوقت، وd1/d2 (الأيام المكتوبة) لأعمدة التاريخ بلا وقت:
    مقارنة bill_date بـ 24:00 كانت تُدخل فواتير اليوم التالي فتُحسب في فترتين."""
    now = datetime.datetime.now().replace(second=0, microsecond=0)
    out = {}
    for key, day_key in (("da1", "d1"), ("da2", "d2")):
        raw = request.vars[key]
        if isinstance(raw, list):
            raw = raw[-1]
        if not raw:
            dt, label, day = now, now.strftime("%Y-%m-%d %H:%M"), now.date()
        else:
            dt, label, day = _report_dt(raw)
            if dt is None:
                session.flash = "التاريخ المدخل غير صحيح !"
                redirect(URL("vat", "index"))
        out[key], out[key + "_label"], out[day_key] = dt, label, day
    return out


_VAT_RATE = 0.15

# مرتجعات المشتريات = حركات حساب المورد بتاريخ اعتمادها: النوع 3 «مرتجعات/فاتورة»
# (suppliers.return_suppliers_bills_ok) والنوع 4 «مرتجعات/اصناف» (suppliers_api.approve_RetSupInv).
# المبلغ من الحركة نفسها (ما خُصم من حساب المورد). الضريبة لا تُحفظ في الحركة والأصناف بين
# 0% و15%، فتُؤخذ من أسطر المرتجع بنسبتها إلى إجمالي الأسطر. الحركة تحمل في آخر ملاحظتها بعد «:»
# رقم المرتجع (4) أو رقم فاتورة المورد (3). حركة لا تُعرف أسطرها تُحسب في المبلغ بلا ضريبة وتُعدّ.
_PURCHASE_RETURNS_SQL = r"""
WITH p AS (
  SELECT id, payment_type, supplier, COALESCE(pay_total, 0) AS gross,
         btrim(substring(note FROM ':\s*([^:]*)$')) AS ref
  FROM suppliers_bills_pay
  WHERE payment_type IN (3, 4) AND pay_date >= %s AND pay_date <= %s
)
SELECT p.payment_type, COUNT(*),
       SUM(p.gross),
       SUM(CASE WHEN x.lg > 0 THEN p.gross * x.lv / x.lg ELSE 0 END),
       COUNT(*) FILTER (WHERE COALESCE(x.lg, 0) <= 0),
       COALESCE(SUM(p.gross) FILTER (WHERE COALESCE(x.lg, 0) <= 0), 0)
FROM p
LEFT JOIN LATERAL (
  SELECT SUM(base * (1 + rate)) AS lg, SUM(base * rate) AS lv FROM (
    SELECT COALESCE(d.total, 0) AS base, COALESCE(d.vat, 0) AS rate
    FROM returned_supply_det d
    WHERE p.payment_type = 4
      AND d.returned_supply = CASE WHEN p.ref ~ '^[0-9]{1,9}$' THEN p.ref::int END
    UNION ALL
    SELECT COALESCE(t.return_count, 0) * COALESCE(t.buy_price, 0), COALESCE(t.vat, 0)
    FROM suppliers_bills b JOIN items_det t ON t.supplier_inv = b.id
    WHERE p.payment_type = 3 AND b.supplier = p.supplier AND btrim(b.bill_no) = p.ref
      AND t.return_chked = 'T' AND t.return_count > 0
  ) z
) x ON TRUE
GROUP BY p.payment_type
"""


def _purchase_summary(p):
    """المشتريات ومرتجعاتها وصافيهما لتقريري rep11 وrep13، بالأيام المكتوبة d1..d2."""
    bills = db.executesql(
        "SELECT COALESCE(SUM(bill_total), 0), COALESCE(SUM(bill_vat), 0)"
        " FROM suppliers_bills WHERE bill_date >= %s AND bill_date <= %s",
        placeholders=[p["d1"], p["d2"]],
    )[0]
    total, vat = round(float(bills[0]), 2), round(float(bills[1]), 2)
    ret = {t: dict(n=0, total=0.0, vat=0.0, unlinked=0, unlinked_total=0.0) for t in (3, 4)}
    for ptype, n, gross, rvat, unlinked, unlinked_gross in db.executesql(
        _PURCHASE_RETURNS_SQL, placeholders=[p["d1"], p["d2"]]
    ):
        ret[int(ptype)] = dict(
            n=int(n),
            total=round(float(gross or 0), 2),
            vat=round(float(rvat or 0), 2),
            unlinked=int(unlinked),
            unlinked_total=round(float(unlinked_gross or 0), 2),
        )
    r_total = round(ret[3]["total"] + ret[4]["total"], 2)
    r_vat = round(ret[3]["vat"] + ret[4]["vat"], 2)
    return dict(
        total=total,
        vat=vat,
        base=round(vat / _VAT_RATE, 2),
        ret_bill=ret[3],
        ret_items=ret[4],
        ret_total=r_total,
        ret_vat=r_vat,
        ret_base=round(r_vat / _VAT_RATE, 2),
        unlinked=ret[3]["unlinked"] + ret[4]["unlinked"],
        unlinked_total=round(ret[3]["unlinked_total"] + ret[4]["unlinked_total"], 2),
        net_total=round(total - r_total, 2),
        net_vat=round(vat - r_vat, 2),
        net_base=round((vat - r_vat) / _VAT_RATE, 2),
    )


@can_access(9002)
def rep11():
    out = _report_period()
    out["pur"] = _purchase_summary(out)
    return out


@can_access(9003)
def rep12():
    return _report_period()


@can_access(9004)
def rep13():
    out = _report_period()
    out["pur"] = _purchase_summary(out)
    return out
