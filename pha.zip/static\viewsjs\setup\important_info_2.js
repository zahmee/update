var app = new Vue({
    el: '#app',
    data: {
        saving: false,
        currentLogoUrl: (window.INFO2_DATA && window.INFO2_DATA.logo_url) || '',
        file: null,
        previewUrl: '',
        error: '',
        dragOver: false
    },
    computed: {
        // الصورة المعروضة: المختارة حديثاً أو الحالية المحفوظة
        displayUrl: function () {
            return this.previewUrl || this.currentLogoUrl;
        },
        fileSize: function () {
            if (!this.file) return '';
            var kb = this.file.size / 1024;
            return kb > 1024 ? (kb / 1024).toFixed(1) + ' م.ب' : Math.round(kb) + ' ك.ب';
        }
    },
    methods: {
        triggerPick: function () {
            this.$refs.fileInput.click();
        },
        onPick: function (e) {
            this.handleFiles(e.target.files);
        },
        onDrop: function (e) {
            this.dragOver = false;
            this.handleFiles(e.dataTransfer.files);
        },
        handleFiles: function (files) {
            this.error = '';
            if (!files || !files.length) return;
            var f = files[0];
            var okTypes = ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/svg+xml'];
            if (okTypes.indexOf(f.type) === -1) {
                this.error = 'صيغة الصورة غير مدعومة (PNG، JPG، GIF، WEBP، SVG)';
                return;
            }
            if (f.size > 2 * 1024 * 1024) {
                this.error = 'حجم الصورة يجب ألا يتجاوز 2 ميجابايت';
                return;
            }
            this.file = f;
            if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
            this.previewUrl = URL.createObjectURL(f);
        },
        clearPick: function () {
            this.file = null;
            if (this.previewUrl) {
                URL.revokeObjectURL(this.previewUrl);
                this.previewUrl = '';
            }
            this.error = '';
            if (this.$refs.fileInput) this.$refs.fileInput.value = '';
        },
        save: function () {
            var self = this;
            if (!self.file) {
                Swal.fire('تنبيه', 'يرجى اختيار صورة الشعار', 'warning');
                return;
            }
            if (self.error) {
                Swal.fire('تنبيه', self.error, 'warning');
                return;
            }
            var body = new FormData();
            body.append('logo', self.file);

            self.saving = true;
            Api.post(window.INFO2_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    var d = Api.getData(res) || {};
                    if (d.logo_url) {
                        // كسر الكاش حتى تظهر الصورة الجديدة فوراً
                        self.currentLogoUrl = d.logo_url + '?t=' + new Date().getTime();
                    }
                    self.clearPick();
                    Api.showSuccess(res.mess || 'تم حفظ الشعار بنجاح');
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.saving = false;
            });
        }
    }
});
