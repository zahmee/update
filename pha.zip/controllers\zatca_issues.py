# -*- coding: utf-8 -*-
# type: ignore
"""سجل مشاكل إرسال الفواتير للهيئة — للمدير فقط (بطاقة في setup/index).

يعرض ما سجّله modules/zatca_sending.py: الفواتير المرفوضة، والمقبولة بملاحظات، والتي تعذّر
إرسالها وما زالت في الطابور، والمحذوفة منه يدوياً. المتابعة: تمت المعالجة / تجاهل / إعادة فتح،
وإعادة الفاتورة الخارجة من الطابور إليه. لا يرسل شيئاً للهيئة بنفسه.
"""

import json
from datetime import datetime, timedelta

import api_helpers as api
import zatca_sending as zs

_PER_PAGE = 50
_KIND_GROUPS = {
    "rejected": ("rejected",),
    "warning": ("warning",),
    "retry": zs.RETRY_KINDS,
    "removed": ("removed", "bad_data"),
}


def _actor():
    u = auth.user
    return " ".join(p for p in (u.first_name, u.last_name) if p) or u.email


def _dt(v):
    return v.strftime("%Y-%m-%d %H:%M") if v else ""


def _age(since, now):
    if not since:
        return ""
    minutes = int((now - since).total_seconds() // 60)
    if minutes < 60:
        return "%d دقيقة" % max(minutes, 0)
    hours = minutes // 60
    if hours < 48:
        return "%d ساعة" % hours
    return "%d يوم" % (hours // 24)


def _date_var(name):
    try:
        return datetime.strptime(str(request.vars[name] or "")[:10], "%Y-%m-%d")
    except ValueError:
        return None


@auth.requires_membership("admin")
def index():
    return dict()


@auth.requires_membership("admin")
def summary():
    t = db.zatca_issue
    now = datetime.now()
    open_q = t.state == "open"
    cnt = t.id.count()
    by_kind = {r.zatca_issue.kind: r[cnt] for r in
               db(open_q).select(t.kind, cnt, groupby=t.kind)}

    q = db.invoice_sending
    pending = q.send == False
    oldest = db(pending).select(q.inv_date, q.inv_time, orderby=q.id, limitby=(0, 1)).first()
    oldest_at = None
    if oldest and oldest.inv_date:
        oldest_at = datetime.combine(oldest.inv_date, oldest.inv_time or datetime.min.time())

    stats = {
        "open": sum(by_kind.values()),
        "rejected": by_kind.get("rejected", 0),
        "warning": by_kind.get("warning", 0),
        "retry": sum(by_kind.get(k, 0) for k in zs.RETRY_KINDS),
        "removed": by_kind.get("removed", 0) + by_kind.get("bad_data", 0),
        "sent_later_7d": db((t.state == "sent_later") &
                            (t.resolved_at >= now - timedelta(days=7))).count(),
        "queue": db(pending).count(),
        "queue_oldest": _dt(oldest_at),
        "queue_oldest_age": _age(oldest_at, now),
    }
    return response.json(api.api_ok(data=stats))


def _query():
    t = db.zatca_issue
    query = t.id > 0
    state = request.vars.state or "open"
    if state == "closed":
        query &= t.state.belongs(("sent_later", "resolved", "ignored"))
    elif state in zs.STATES:
        query &= t.state == state

    group = request.vars.kind or ""
    if group in _KIND_GROUPS:
        query &= t.kind.belongs(_KIND_GROUPS[group])

    if str(request.vars.inv_type or "") in ("1", "2"):
        query &= t.inv_type == int(request.vars.inv_type)

    date_from, date_to = _date_var("date_from"), _date_var("date_to")
    if date_from:
        query &= t.last_at >= date_from
    if date_to:
        query &= t.last_at < date_to + timedelta(days=1)

    search = (request.vars.q or "").strip()[:60]
    if search.isdigit():
        query &= t.inv_id == int(search)
    elif search:
        query &= (t.codes.contains(search, case_sensitive=False) |
                  t.message.contains(search, case_sensitive=False))
    return query


def _live_state(rows):
    """حالة كل فاتورة الآن: في الطابور؟ قبلتها الهيئة؟ — من الطابور والفاتورة نفسها."""
    in_queue, sent = set(), set()
    for inv_type in (1, 2):
        ids = [r.inv_id for r in rows if r.inv_type == inv_type and r.inv_id]
        if not ids:
            continue
        q = db.invoice_sending
        for r in db((q.inv_type == inv_type) & q.inv_id.belongs(ids) & (q.send == False)).select(q.inv_id):
            in_queue.add((inv_type, r.inv_id))
        m = zs._master(db, inv_type)
        for r in db(m.id.belongs(ids) & (m.send_to_zatca == True)).select(m.id):
            sent.add((inv_type, r.id))
    return in_queue, sent


def _row_dict(r, in_queue, sent):
    key = (r.inv_type, r.inv_id)
    kind = zs.KINDS.get(r.kind, {"label": r.kind or "", "tone": "muted"})
    is_sent, queued = key in sent, key in in_queue
    return {
        "id": r.id,
        "inv_type": r.inv_type,
        "inv_type_label": zs.INV_TYPES.get(r.inv_type, str(r.inv_type)),
        "inv_id": r.inv_id,
        "inv_date": str(r.inv_date or ""),
        "inv_time": str(r.inv_time or "")[:5],
        "inv_total": r.inv_total,
        "kind": r.kind,
        "kind_label": kind["label"],
        "tone": kind["tone"],
        "state": r.state,
        "state_label": zs.STATES.get(r.state, r.state or ""),
        "http_status": r.http_status,
        "zatca_status": r.zatca_status or "",
        "codes": r.codes or "",
        "message": r.message or "",
        "attempts": r.attempts or 0,
        "first_at": _dt(r.first_at),
        "last_at": _dt(r.last_at),
        "sent_at": _dt(r.sent_at),
        "in_queue": queued,
        "sent": is_sent,
        "can_requeue": bool(r.payload) and not is_sent and not queued,
    }


@auth.requires_membership("admin")
def rows():
    t = db.zatca_issue
    try:
        page = max(int(request.vars.page or 1), 1)
    except (TypeError, ValueError):
        page = 1
    query = _query()
    total = db(query).count()
    fields = [f for f in t if f.name not in ("response", "payload", "history")]
    fields.append(t.payload.len().with_alias("payload_len"))
    found = db(query).select(*fields, orderby=~t.last_at | ~t.id,
                             limitby=((page - 1) * _PER_PAGE, page * _PER_PAGE))
    items = []
    for r in found:
        rec = r.zatca_issue
        rec.payload = bool(r.payload_len)
        items.append(rec)
    in_queue, sent = _live_state(items)
    data = [_row_dict(r, in_queue, sent) for r in items]
    return response.json(api.api_list(rows=data, count=total, page=page, per_page=_PER_PAGE))


def _pretty(text):
    if not text:
        return ""
    try:
        return json.dumps(json.loads(text), ensure_ascii=False, indent=2)
    except ValueError:
        return text


@auth.requires_membership("admin")
def detail():
    rec_id = request.args(0) or request.vars.id
    r = db.zatca_issue(int(rec_id)) if str(rec_id or "").isdigit() else None
    if not r:
        return response.json(api.api_error(mess="السجل غير موجود"))
    in_queue, sent = _live_state([r])
    data = _row_dict(r, in_queue, sent)
    try:
        history = json.loads(r.history or "[]")
    except ValueError:
        history = []
    for h in history:
        k = h.get("kind")
        h["label"] = (zs.KINDS[k]["label"] if k in zs.KINDS else
                      {"sent": "قبلتها الهيئة", "requeued": "أُعيدت إلى الطابور",
                       "state": zs.STATES.get(h.get("state"), "")}.get(k, k or ""))
    resolver = ""
    if r.resolved_by:
        u = db.auth_user(r.resolved_by)
        if u:
            resolver = " ".join(p for p in (u.first_name, u.last_name) if p) or u.email
    data.update(
        response=_pretty(r.response),
        payload=_pretty(r.payload),
        history=list(reversed(history)),
        resolved_at=_dt(r.resolved_at),
        resolved_by=resolver,
        resolve_note=r.resolve_note or "",
    )
    return response.json(api.api_ok(data=data))


def _post_id():
    if request.env.request_method != "POST":
        return None, response.json(api.api_error(mess="طريقة الطلب غير صحيحة"))
    rec_id = str(request.vars.id or "")
    if not rec_id.isdigit():
        return None, response.json(api.api_error(mess="رقم السجل غير صالح"))
    return int(rec_id), None


@auth.requires_membership("admin")
def set_state():
    rec_id, err = _post_id()
    if err:
        return err
    try:
        ok, mess = zs.set_state(db, rec_id, request.vars.state or "", request.vars.note or "",
                                user_id=auth.user_id, actor=_actor())
        if not ok:
            db.rollback()
            return response.json(api.api_error(mess=mess))
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر الحفظ: %s" % e))
    return response.json(api.api_ok(mess=mess))


@auth.requires_membership("admin")
def requeue():
    rec_id, err = _post_id()
    if err:
        return err
    try:
        ok, mess = zs.requeue(db, rec_id, actor=_actor())
        if not ok:
            db.rollback()
            return response.json(api.api_error(mess=mess))
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذّرت الإعادة: %s" % e))
    return response.json(api.api_ok(mess=mess))
