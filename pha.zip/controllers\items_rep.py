# -*- coding: utf-8 -*-
#  type: ignore

import os
import urllib.parse
from datetime import datetime, timedelta

import api_helpers as api
import items_reports

@can_access(8201)
def get_key_types():
    q  = db(db.key_type.id>0).select(db.key_type.ALL)
    return response.json(q)

@can_access(8201)
def get_suppliers():
    q  = db(db.suppliers.stoped==False).select(db.suppliers.id ,db.suppliers.name , orderby=db.suppliers.id )
    return response.json(q)


# ==============================================================================
#  تحسين: عملية تحديث شاملة لمرة واحدة (تُشغل مرة في الشهر)
# ==============================================================================
@can_access(8202)
def preparation_report():
    # تحديث selling_average أولاً
    qry = """
        UPDATE items_main
        SET
            report_year = EXTRACT(year FROM CURRENT_DATE),
            report_month = EXTRACT(MONTH FROM CURRENT_DATE),
            report_date = localtimestamp,
            selling_average = COALESCE((
                SELECT SUM(item_count)
                FROM invoice_details
                WHERE item_number IN (
                    SELECT id FROM items_det WHERE item_idr = items_main.id
                )
                AND created_on > date_trunc('month', CURRENT_DATE) - INTERVAL '1 year'
            ), 0)
    """
    db.executesql(qry)

    # تحديث existing و lowest_price و quantity_reorder و quantity_order
    qry = """
        UPDATE items_main
        SET
            existing = COALESCE((
                SELECT SUM(items_count) FROM items_det WHERE item_idr = items_main.id
            ), 0),
            lowest_price = COALESCE((
                SELECT MIN(buy_price) FROM items_det WHERE item_idr = items_main.id
            ), 0),
            quantity_reorder = GREATEST(1, COALESCE(selling_average / 12, 0)),
            quantity_order = GREATEST(1, COALESCE(selling_average / 24, 0))
        WHERE COALESCE(halt, 'F') <> 'T'
    """
    db.executesql(qry)
    redirect(URL('items_rep','rep1'))


# ==============================================================================
#  تحسين: إزالة UPDATE واستخدام JOIN للسرعة
# ==============================================================================
@can_access(8201)
def rep1_api():
    # الموقوف لا يدخل التقرير، والفارغ نشط (كان "halt = 'F'" يستبعده أيضاً)
    base_qry = """
        SELECT
            im.id, im.name, im.report_year, im.report_month, im.item_type,
            im.seasonal_drug,
            im.selling_average, im.existing, im.quantity_reorder, im.quantity_order,
            (im.quantity_reorder - im.existing) as now_order, im.lowest_price,
            kt.name as key_types,
            s.name as suppliers
        FROM items_main im
        LEFT JOIN key_type kt ON kt.id = im.item_type
        LEFT JOIN suppliers s ON s.id = im.suppliers
        WHERE im.existing < im.quantity_order
          AND COALESCE(im.halt, 'F') <> 'T'
    """

    if request.args(0) == '10':
        if request.args(1) != '0':
            qry = base_qry + " AND im.item_type = %s ORDER BY im.name "
            qs = db.executesql(qry, placeholders=[request.args(1)], as_dict=True)
            return response.json(qs)
        elif request.args(1) == '0':
            qry = base_qry + " AND im.item_type IS NULL ORDER BY im.name "
            qs = db.executesql(qry, as_dict=True)
            return response.json(qs)

    elif request.args(0) == '20':
        qry = base_qry + " AND im.suppliers = %s ORDER BY im.name "
        qs = db.executesql(qry, placeholders=[request.args(2)], as_dict=True)
        return response.json(qs)

    return response.json([])


@can_access(8201)
def rep1():
    return dict()


# ==============================================================================
#  تقارير عامة: ملفات إكسل تُجهَّز عند الطلب وتُنزَّل مباشرة (modules/items_reports.py)
#  كانت تُكتب في static بعملية خلفية، فتُنزَّل لأي أحد بلا تسجيل دخول، ويُطلب من المستخدم
#  تحديث الصفحة بعد دقائق. الآن تُحمى بـ 8201 ولا يُحفظ أي ملف على الخادم.
# ==============================================================================
_LEGACY_PUBLIC_FILES = ("all_items_in_stock.xlsx", "items_sales_in_date.xlsx")


def _remove_legacy_public_files():
    """الملفات القديمة في static فيها أسعار الشراء وأسماء العملاء وتُنزَّل بلا تسجيل دخول."""
    for name in _LEGACY_PUBLIC_FILES:
        path = os.path.join(request.folder, "static", name)
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass


def _xlsx_download(data, ascii_name, arabic_name):
    response.headers["Content-Type"] = items_reports.XLSX_MIME
    response.headers["Content-Disposition"] = "attachment; filename=\"%s\"; filename*=UTF-8''%s" % (
        ascii_name, urllib.parse.quote(arabic_name))
    response.headers["Cache-Control"] = "no-store"
    return data


def _parse_minute(value):
    """قيمة حقل datetime-local (YYYY-MM-DDTHH:MM) أو تاريخ فقط، وإلا None."""
    value = str(value or "").strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


@can_access(8201)
def items_report_crate():
    _remove_legacy_public_files()
    return dict(stale_choices=items_reports.STALE_DAYS_CHOICES, max_days=items_reports.MAX_SALES_DAYS)


@can_access(8201)
def stock_report():
    """جرد وتقييم المخزون الحالي (لا يحتاج فترة)."""
    try:
        stale_days = int(request.vars.stale_days or 180)
    except (TypeError, ValueError):
        stale_days = 180
    if stale_days not in items_reports.STALE_DAYS_CHOICES:
        stale_days = 180
    try:
        data, _stats = items_reports.stock_workbook(db, stale_days=stale_days, now=request.now)
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر تجهيز التقرير: %s" % e))
    day = request.now.strftime("%Y-%m-%d")
    return _xlsx_download(data, "stock_valuation_%s.xlsx" % day.replace("-", ""),
                          "جرد_وتقييم_المخزون_%s.xlsx" % day)


@can_access(8201)
def sales_report():
    """المبيعات والمرتجعات بين تاريخين (شاملاً دقيقة النهاية)."""
    start = _parse_minute(request.vars.start)
    end = _parse_minute(request.vars.end)
    if not start or not end:
        return response.json(api.api_error(mess="حدّد تاريخ البداية والنهاية"))
    if len(str(request.vars.end).strip()) <= 10:  # تاريخ بلا وقت = حتى نهاية اليوم
        end = end.replace(hour=23, minute=59)
    end_excl = end + timedelta(minutes=1)
    if start >= end_excl:
        return response.json(api.api_error(mess="تاريخ البداية بعد تاريخ النهاية"))
    if (end_excl - start).days > items_reports.MAX_SALES_DAYS:
        return response.json(api.api_error(
            mess="الفترة أطول من %d يوماً؛ قسّمها على أكثر من ملف" % items_reports.MAX_SALES_DAYS))
    try:
        data, _stats = items_reports.sales_workbook(db, start, end_excl, now=request.now)
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر تجهيز التقرير: %s" % e))
    span = "%s_%s" % (start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"))
    return _xlsx_download(data, "sales_%s.xlsx" % span.replace("-", ""),
                          "المبيعات_والمرتجعات_%s.xlsx" % span)
