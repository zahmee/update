# -*- coding: utf-8 -*-
#  type: ignore

from pathlib import Path
import os
import time
import shlex, subprocess
import sys
import threading
_lock = threading.RLock()
import xlsxwriter

@can_access(8201)
def get_key_types():
    q  = db(db.key_type.id>0).select(db.key_type.ALL)
    return response.json(q)

@can_access(8201)
def update_h():
    #q = "update suppliers set  stoped='F'  "
    db.executesql(q)
    return 'ok'

@can_access(8201)
def get_suppliers():
    q  = db(db.suppliers.stoped==False).select(db.suppliers.id ,db.suppliers.name , orderby=db.suppliers.id )
    return response.json(q)


# ==============================================================================
#  تحسين: عملية تحديث شاملة لمرة واحدة (تُشغل مرة في الشهر)
# ==============================================================================
@can_access(8202)
def preparation_report():
    # تحديث selling_average أولاً
    qry = """
        UPDATE items_main
        SET
            report_year = EXTRACT(year FROM CURRENT_DATE),
            report_month = EXTRACT(MONTH FROM CURRENT_DATE),
            report_date = localtimestamp,
            selling_average = COALESCE((
                SELECT SUM(item_count)
                FROM invoice_details
                WHERE item_number IN (
                    SELECT id FROM items_det WHERE item_idr = items_main.id
                )
                AND created_on > date_trunc('month', CURRENT_DATE) - INTERVAL '1 year'
            ), 0)
    """
    db.executesql(qry)

    # تحديث existing و lowest_price و quantity_reorder و quantity_order
    qry = """
        UPDATE items_main
        SET
            existing = COALESCE((
                SELECT SUM(items_count) FROM items_det WHERE item_idr = items_main.id
            ), 0),
            lowest_price = COALESCE((
                SELECT MIN(buy_price) FROM items_det WHERE item_idr = items_main.id
            ), 0),
            quantity_reorder = GREATEST(1, COALESCE(selling_average / 12, 0)),
            quantity_order = GREATEST(1, COALESCE(selling_average / 24, 0))
        WHERE halt = 'F'
    """
    db.executesql(qry)
    redirect(URL('items_rep','rep1'))


# ==============================================================================
#  تحسين: إزالة UPDATE واستخدام JOIN للسرعة
# ==============================================================================
@can_access(8201)
def rep1_api():
    base_qry = """
        SELECT
            im.id, im.name, im.report_year, im.report_month, im.item_type,
            im.seasonal_drug,
            im.selling_average, im.existing, im.quantity_reorder, im.quantity_order,
            (im.quantity_reorder - im.existing) as now_order, im.lowest_price,
            kt.name as key_types,
            s.name as suppliers
        FROM items_main im
        LEFT JOIN key_type kt ON kt.id = im.item_type
        LEFT JOIN suppliers s ON s.id = im.suppliers
        WHERE im.existing < im.quantity_order
          AND im.halt = 'F'
    """

    if request.args(0) == '10':
        if request.args(1) != '0':
            qry = base_qry + " AND im.item_type = %s ORDER BY im.name "
            qs = db.executesql(qry, placeholders=[request.args(1)], as_dict=True)
            return response.json(qs)
        elif request.args(1) == '0':
            qry = base_qry + " AND im.item_type IS NULL ORDER BY im.name "
            qs = db.executesql(qry, as_dict=True)
            return response.json(qs)

    elif request.args(0) == '20':
        qry = base_qry + " AND im.suppliers = %s ORDER BY im.name "
        qs = db.executesql(qry, placeholders=[request.args(2)], as_dict=True)
        return response.json(qs)

    return response.json([])


@can_access(8201)
def rep1():
    return dict()

@can_access(8201)
def items_report_crate():
    THIS_FOLDER = Path(__file__).resolve().parents[1]
    my_file = os.path.join(THIS_FOLDER, "static", 'all_items_in_stock.xlsx')
    file1 = Path(my_file)
    if file1.is_file():
        f1_date = time.strftime('%m/%d/%Y  %H:%M:%S', time.localtime(os.path.getmtime(file1)))
    else:
        f1_date = 'الملف غير موجود'

    my_file = os.path.join(THIS_FOLDER, "static", 'items_sales_in_date.xlsx')
    file2 = Path(my_file)
    if file2.is_file():
        f2_date = time.strftime('%m/%d/%Y  %H:%M:%S', time.localtime(os.path.getmtime(file2)))
    else:
        f2_date = 'الملف غير موجود'
    return dict(f1=f1_date, f2=f2_date)

@can_access(8201)
def pre_report1():
    THIS_FOLDER = Path(__file__).resolve().parents[1]
    my_file = os.path.join(THIS_FOLDER, "scripts", 'all_items_in_stock.py')
    db_name = db._uri.split("/")[-1]
    if sys.platform.startswith('win32'):
        subprocess.Popen(['python', my_file, db_name], shell=False, stdin=None, stdout=None, stderr=None, close_fds=True)
    elif sys.platform.startswith('linux'):
        subprocess.Popen(['python3', my_file, db_name], shell=False, stdin=None, stdout=None, stderr=None, close_fds=True)
    return '0'


@can_access(8201)
def pre_report2():
    r = lambda s: str(datetime.datetime.now()) if s == '' else str(s)
    sart_date = r(request.vars.da1)
    end_date = r(request.vars.da2)
    x = threading.Thread(target=_pre_report2_1, args=(sart_date, end_date,))
    x.start()
    return '0'


# ==============================================================================
#  تحسين: استخدام JOIN بدلاً من subqueries المتكررة
# ==============================================================================
def _pre_report2_1(da1, da2):
    db._adapter.reconnect()
    try:
        THIS_FOLDER = Path(__file__).resolve().parents[1]
        my_file = os.path.join(THIS_FOLDER, "static", 'items_sales_in_date.xlsx')
        workbook = xlsxwriter.Workbook(my_file)
        sart_date = da1
        end_date = da2

        db.executesql("SET datestyle = US, MDY;")

        # استعلام محسن بـ JOIN بدلاً من subqueries
        qry = """
            SELECT
                im.id as inv_no,
                kpm.name as payment_method,
                c.name as coust,
                idet.id as id_det,
                imain.name as name,
                idet.vat,
                idet.item_count,
                idet.created_on,
                idet.created_by,
                COALESCE(au.first_name, '') || ' ' || COALESCE(au.last_name, '') as created_name,
                idet2.public_price as price,
                idet.total,
                idet.vat_total
            FROM invoice_details idet
            JOIN invoice_master im ON im.uuid = idet.uuid
            LEFT JOIN customers c ON c.id = im.customer
            LEFT JOIN key_payment_method kpm ON kpm.id = im.payment_method
            JOIN items_det idet2 ON idet2.id = idet.item_number
            JOIN items_main imain ON imain.id = idet2.item_idr
            LEFT JOIN auth_user au ON au.id = idet.created_by
            WHERE idet.created_on >= %s AND idet.created_on <= %s
        """
        q = db.executesql(qry, placeholders=[sart_date, end_date], as_dict=True)

        qry2 = """
            SELECT
                irm.id as inv_no,
                kpm.name as payment_method,
                c.name as coust,
                ird.id as id_det,
                imain.name as name,
                ird.vat,
                ird.item_count,
                ird.created_on,
                ird.created_by,
                COALESCE(au.first_name, '') || ' ' || COALESCE(au.last_name, '') as created_name,
                idet2.public_price as price,
                ird.total,
                ird.vat_total
            FROM inv_return_details ird
            JOIN inv_return_master irm ON irm.uuid = ird.uuid
            LEFT JOIN customers c ON c.id = irm.customer
            LEFT JOIN key_payment_method kpm ON kpm.id = irm.payment_method
            JOIN items_det idet2 ON idet2.id = ird.item_number
            JOIN items_main imain ON imain.id = idet2.item_idr
            LEFT JOIN auth_user au ON au.id = ird.created_by
            WHERE ird.created_on >= %s AND ird.created_on <= %s
        """
        q2 = db.executesql(qry2, placeholders=[sart_date, end_date], as_dict=True)

        worksheet = workbook.add_worksheet()
        bold = workbook.add_format()
        bold.set_font_size(12)
        bold.set_align('center')
        bold.set_bold()
        bold.set_font_name('Segoe UI')
        format_right_to_left = workbook.add_format({'reading_order': 2, 'border': 1})
        worksheet.right_to_left()
        worksheet.repeat_rows(0)
        worksheet.set_landscape()
        worksheet.set_header(f'&C&24 المبيعات التفصيلية من {sart_date} الى  {end_date}    ')
        worksheet.set_footer('&Cصفحة &P من &N     &Rطبعة في  &D   &T')
        worksheet.set_margins(0.7, 0.7, 0.7, 0.7)
        worksheet.set_paper(9)
        workbook.set_properties({
            'title':    'كشف بالاصناف',
            'subject':  'With document properties',
            'author':   'صدارة التطوير و البرمجة',
            'company':  'صدارة التطوير و البرمجة',
            'category': 'كشف',
            'keywords': 'Sample, Example, Properties',
            'comments': 'Created with Python and XlsxWriter',
            'status':   'Quo',
        })
        worksheet.fit_to_pages(1, 0)
        format = workbook.add_format()
        format.set_font_size(11)
        format.set_font_name('Segoe UI')
        memo = workbook.add_format()
        memo.set_font_size(16)
        memo.set_font_name('Segoe UI')
        memo.set_text_wrap()

        worksheet.set_column('A:A', 10)
        worksheet.set_column('B:B', 10)
        worksheet.set_column('C:C', 22)
        worksheet.set_column('D:D', 10)
        worksheet.set_column('E:E', 50)
        worksheet.set_column('F:F', 8)
        worksheet.set_column('G:G', 8)
        worksheet.set_column('H:H', 10)
        worksheet.set_column('I:I', 12)
        worksheet.set_column('J:J', 12)
        worksheet.set_column('K:K', 18)
        worksheet.set_column('L:L', 20)
        worksheet.set_column('M:M', 10)
        worksheet.set_column('N:N', 20)
        worksheet.set_column('O:O', 20)
        worksheet.set_column('P:P', 12)
        format2 = workbook.add_format({'num_format': 'dd/mm/yyyy HH:MM:ss'})
        row = 1
        col = 0

        # كاش صغير لتجنب طلبات DAL المتكررة
        type_cache = {}
        for r in (q):
            it_type = type_cache.get(r['id_det'])
            if it_type is None:
                it_det = db.items_det[r['id_det']]
                if it_det and it_det.item_idr:
                    it_type = {
                        'type_name': it_det.item_idr.item_type.name if it_det.item_idr.item_type else '-',
                        'group': it_det.item_idr.item_group or '',
                        'item_id': it_det.item_idr.item_id or '',
                    }
                else:
                    it_type = {'type_name': '-', 'group': '', 'item_id': ''}
                type_cache[r['id_det']] = it_type

            worksheet.write(row, col,      r['inv_no'],       format)
            worksheet.write(row, col + 1,  r['payment_method'] or '--', format)
            worksheet.write(row, col + 2,  r['coust'] or '--',         format)
            worksheet.write(row, col + 3,  r['id_det'],       format)
            worksheet.write(row, col + 4,  r['name'] or '--',         format)
            worksheet.write(row, col + 5,  r['vat'],          format)
            worksheet.write(row, col + 6,  float(r['item_count'] or 0), format)
            worksheet.write(row, col + 7,  float(r['price'] or 0),      format)
            worksheet.write(row, col + 8,  float(r['total'] or 0),      format)
            worksheet.write(row, col + 9,  float(r['vat_total'] or 0),  format)
            worksheet.write(row, col + 10, r['created_on'],   format2)
            worksheet.write(row, col + 11, it_type['type_name'], format)
            worksheet.write(row, col + 12, it_type['group'],    format)
            worksheet.write(row, col + 13, it_type['item_id'],  format)
            worksheet.write(row, col + 14, r['created_name'] or '', format)
            worksheet.write(row, col + 15, 'مبيعات',          format)
            row += 1

        for r in (q2):
            it_type = type_cache.get(r['id_det'])
            if it_type is None:
                it_det = db.items_det[r['id_det']]
                if it_det and it_det.item_idr:
                    it_type = {
                        'type_name': it_det.item_idr.item_type.name if it_det.item_idr.item_type else '-',
                        'group': it_det.item_idr.item_group or '',
                        'item_id': it_det.item_idr.item_id or '',
                    }
                else:
                    it_type = {'type_name': '-', 'group': '', 'item_id': ''}
                type_cache[r['id_det']] = it_type

            worksheet.write(row, col,      r['inv_no'],       format)
            worksheet.write(row, col + 1,  r['payment_method'] or '--', format)
            worksheet.write(row, col + 2,  r['coust'] or '--',         format)
            worksheet.write(row, col + 3,  r['id_det'],       format)
            worksheet.write(row, col + 4,  r['name'] or '--',         format)
            worksheet.write(row, col + 5,  r['vat'],          format)
            worksheet.write(row, col + 6,  float(r['item_count'] or 0), format)
            worksheet.write(row, col + 7,  float(r['price'] or 0),      format)
            worksheet.write(row, col + 8,  float(r['total'] or 0),      format)
            worksheet.write(row, col + 9,  float(r['vat_total'] or 0),  format)
            worksheet.write(row, col + 10, r['created_on'],   format2)
            worksheet.write(row, col + 11, it_type['type_name'], format)
            worksheet.write(row, col + 12, it_type['group'],    format)
            worksheet.write(row, col + 13, it_type['item_id'],  format)
            worksheet.write(row, col + 14, r['created_name'] or '', format)
            worksheet.write(row, col + 15, 'مرتجعات',         format)
            row += 1

        worksheet.add_table('A1:P'+str(row+1), {'total_row': True,
            'columns':[
                {'header': u'الفاتورة',           'header_format' : bold, 'total_string': 'الاجمالي'},
                {'header': u'الدفع',              'header_format' : bold, 'total_function': 'count'},
                {'header': u'اسم العميل',         'header_format' : bold, 'total_string': ' '},
                {'header': u'رقم الصنف',          'header_format' : bold, 'total_string': ' '},
                {'header': u'اسم الصنف',          'header_format' : bold, 'total_string': ' '},
                {'header': u'VAT',                  'header_format' : bold, 'total_string': ' '},
                {'header': u' العدد',              'header_format' : bold, 'total_function': 'sum'},
                {'header': u'المبلغ',              'header_format' : bold, 'total_function': 'sum'},
                {'header': u'الاجمالي',            'header_format' : bold, 'total_function': 'sum'},
                {'header': u'الضريبة ',            'header_format' : bold, 'total_function': 'sum'},
                {'header': u'التاريخ',             'header_format' : bold, 'total_string': ' '},
                {'header': u'التصنيف',             'header_format' : bold, 'total_string': ' '},
                {'header': u'المجموعة',            'header_format' : bold, 'total_string': ' '},
                {'header': u'الرقم الدولي',        'header_format' : bold, 'total_string': ' '},
                {'header': u'البائع',              'header_format' : bold, 'total_string': ' '},
                {'header': u'نوعها',               'header_format' : bold, 'total_string': ' '},
            ], 'autofilter': True, 'style': 'Table Style Light 8'})
        workbook.close()
    except Exception as e:
        print(e)
    finally:
        _lock.acquire()
        _lock.release()
        db._adapter.close()


#=================================================================================================
#=================================================================================================

@can_access(8201)
def show1():
    import pandas as pd
    import matplotlib.pyplot as plt
    import io
    import base64
    a1 = [1,5,9,5,7,3,6]
    a2 = [3,9,8,5,4,5,2]
    a3 = [9,8,1,6,2,4,8]
    plt.plot(a1,a2,a3)
    fig2  = plt

    img = io.BytesIO()
    fig2.savefig(img, format='png', bbox_inches='tight')
    img.seek(0)
    encoded = base64.b64encode(img.getvalue())
    my_html = '<img src="data:image/png;base64, {}">'.format(encoded.decode('utf-8'))
    return my_html

@can_access(8201)
def s1():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.switch_backend('agg')
    import io
    import base64
    import numpy as np
    a1 = [1,2,3,4,5,6,7]
    a2 = [3,9,8,5,4,5,2]
    a3 = [9,8,1,6,2,4,8]
    x_index = np.arange(len(a1))
    width = 0.2
    plt.barh(x_index,a2 , height=width ,label="aaaa" )
    plt.barh(x_index-width ,a3 , height=width  )
    plt.xlabel(" year ")
    plt.ylabel(" dayes ")
    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight', pad_inches = 1 )
    img.seek(0)
    encoded = base64.b64encode(img.getvalue())
    my_html = '<img src="data:image/png;base64, {}">'.format(encoded.decode('utf-8'))
    return my_html
