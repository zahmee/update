
var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        items_reorder: this.items_id,
        data: [],
        data_all: [],
        show_spinner: true,
        serch: '',
    },
    created() {

        this.$http.get(this.URL + '/../get_open_inv').then(response => {
            if (response.body != "") {
                this.data = response.body;
                this.data_all = response.body;
            }
            this.show_spinner = false;
        }, () => {
            this.show_spinner = false;
        });

    },
    mounted() {
        this.$nextTick(() => {
            var searchInput = this.$refs.searchInput || document.getElementById('invoiceSearchInput');
            if (searchInput) {
                searchInput.focus();
            }
        });
    },
    computed: {
        matchedCount() {
            return this.data.filter(row => this.isNetMatched(row) && this.isTotalMatched(row)).length;
        },
        mismatchCount() {
            return this.data.filter(row => !this.isNetMatched(row) || !this.isTotalMatched(row)).length;
        },
    },
    methods: {

        find() {
            var serc = String(this.serch || '').trim().toLowerCase();
            if (serc.length > 0) {

                this.data = this.data_all.filter(row => {
                    if (
                        (String(row['id']).toLowerCase().includes(serc)) ||
                        (String(row['bill_no']).toLowerCase().includes(serc)) ||
                        (String(row['s_n']).toLowerCase().includes(serc)) ||
                        (String(row['bill_date']).toLowerCase().includes(serc)) ||
                        (String(row['bill_net_amount']).toLowerCase().includes(serc)) ||
                        (String(row['bill_total']).toLowerCase().includes(serc)) ||
                        (String(row['bill_vat']).toLowerCase().includes(serc))
                    ) {
                        return true;
                    }
                });
            }
            else {
                this.data = this.data_all;
            }

        },
        clearSearch() {
            this.serch = '';
            this.data = this.data_all;
            this.$nextTick(() => {
                var searchInput = this.$refs.searchInput || document.getElementById('invoiceSearchInput');
                if (searchInput) {
                    searchInput.focus();
                }
            });
        },
        toNumber(value) {
            var numberValue = parseFloat(value || 0);
            if (isNaN(numberValue)) {
                return 0;
            }
            return numberValue;
        },
        formatMoney(value) {
            var numberValue = this.toNumber(value);
            return numberValue.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },
        isNetMatched(row) {
            return Math.abs(this.toNumber(row.bill_net_amount) - this.toNumber(row.inv_inp_s)) < 1;
        },
        isTotalMatched(row) {
            return Math.abs(this.toNumber(row.bill_total) - this.toNumber(row.inv_inp_s_v)) < 1;
        },
        totalDifference(row) {
            return (this.toNumber(row.bill_net_amount) - this.toNumber(row.inv_inp_s))
                + (this.toNumber(row.bill_total) - this.toNumber(row.inv_inp_s_v));
        },
        invoiceHasMismatch(row) {
            return !this.isNetMatched(row) || !this.isTotalMatched(row);
        },
        paymentInfo(name) {
            var n = String(name || '').trim();
            if (n === 'نقدي') {
                return { icon: 'fad fa-money-bill-wave', cls: 'pay-cash' };
            } else if (n === 'شبكة الكترونية') {
                return { icon: 'fad fa-credit-card', cls: 'pay-card' };
            } else if (n === 'آجل') {
                return { icon: 'fad fa-clock', cls: 'pay-credit' };
            } else if (n === 'تحويل في الحساب') {
                return { icon: 'fad fa-exchange-alt', cls: 'pay-bank' };
            } else if (n === 'شيك') {
                return { icon: 'fad fa-money-check-alt', cls: 'pay-check' };
            } else if (n === 'خصم من الرصيد') {
                return { icon: 'fad fa-wallet', cls: 'pay-balance' };
            }
            return { icon: 'fad fa-question-circle', cls: 'pay-default' };
        },
        remove_best_price() {
            this.data.forEach(function (e, index) {
                e.best_price = '';
            });
        },
        remove_supp_name() {
            this.data.forEach(function (e, index) {
                e.supplier = '';
            });
        },
        link_1(id) {
            window.open(purl + "/../../items/it_rep1/" + id, '_self');
        },
        link_2(id) {
            window.open(purl + "/../../items/it_prt.svc/" + id, '_self');
        },
        link_3(id) {
            window.open(purl + "/../../items/it_inv/" + id, '_self');
        }


    },
});

