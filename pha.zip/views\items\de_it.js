
var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        items_reorder: this.items_id,
        data: [],
        data_all: [],
        show_spinner: true,
        serch: '',
    },
    created() {

        this.$http.get(this.URL + '/../get_open_inv').then(response => {
            if (response.body != "") {
                this.data = response.body;
                this.data_all = response.body;
                //this.show_spinner = false;
            }
        });

    },
    mounted() {
        this.$nextTick(() => {
            var searchInput = this.$refs.searchInput || document.getElementById('invoiceSearchInput');
            if (searchInput) {
                searchInput.focus();
            }
        });
    },
    computed: {
        matchedCount() {
            return this.data.filter(row => this.isNetMatched(row) && this.isTotalMatched(row)).length;
        },
        mismatchCount() {
            return this.data.filter(row => !this.isNetMatched(row) || !this.isTotalMatched(row)).length;
        },
    },
    methods: {

        find() {
            var serc = String(this.serch || '').trim().toLowerCase();
            if (serc.length > 0) {

                this.data = this.data_all.filter(row => {
                    if (
                        (String(row['id']).toLowerCase().includes(serc)) ||
                        (String(row['bill_no']).toLowerCase().includes(serc)) ||
                        (String(row['s_n']).toLowerCase().includes(serc)) ||
                        (String(row['bill_date']).toLowerCase().includes(serc)) ||
                        (String(row['bill_net_amount']).toLowerCase().includes(serc)) ||
                        (String(row['bill_total']).toLowerCase().includes(serc)) ||
                        (String(row['bill_vat']).toLowerCase().includes(serc))
                    ) {
                        return true;
                    }
                });
            }
            else {
                this.data = this.data_all;
            }

        },
        formatMoney(value) {
            var numberValue = parseFloat(value || 0);
            if (isNaN(numberValue)) {
                numberValue = 0;
            }
            return numberValue.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },
        isNetMatched(row) {
            return Math.abs(parseFloat(row.bill_net_amount || 0) - parseFloat(row.inv_inp_s || 0)) < 1;
        },
        isTotalMatched(row) {
            return Math.abs(parseFloat(row.bill_total || 0) - parseFloat(row.inv_inp_s_v || 0)) < 1;
        },
        remove_best_price() {
            this.data.forEach(function (e, index) {
                e.best_price = '';
            });
        },
        remove_supp_name() {
            this.data.forEach(function (e, index) {
                e.supplier = '';
            });
        },
        link_1(id) {
            window.open(purl + "/../../items/it_rep1/" + id, '_self');
        },
        link_2(id) {
            window.open(purl + "/../../items/it_prt.svc/" + id, '_self');
        },
        link_3(id) {
            window.open(purl + "/../../items/it_inv/" + id, '_self');
        }


    },
});

