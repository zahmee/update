# -*- coding: utf-8 -*-
"""
سكريبت تطبيق @can_access على جميع Controllers
"""
import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from controller_screen_map import SCREEN_MAP

controllers_dir = os.path.join(os.path.dirname(__file__), '..', 'controllers')

# الأنماط التي يجب استبدالها
OLD_PATTERNS = [
    r'@auth\.requires_membership\("user1"\)',
    r'@auth\.requires_membership\("user2"\)',
    r'@auth\.requires_membership\("admin"\)',
    r'@auth\.requires_membership\("account"\)',
    r'@auth\.requires\(auth\.has_membership\("account"\) or auth\.has_membership\("admin"\)\)',
    r'@auth\.requires\(auth\.has_membership\("user2"\) or auth\.has_membership\("admin"\)\)',
    r'@auth\.requires\(auth\.has_membership\("admin"\)\)',
]

def process_controller(controller_name, screen_map):
    filepath = os.path.join(controllers_dir, controller_name + '.py')
    if not os.path.exists(filepath):
        print(f"  SKIP: {filepath} not found")
        return 0
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original = content
    lines = content.split('\n')
    new_lines = []
    changes = 0
    
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        # إذا كان السطر ديكوريتور قديم
        is_old_decorator = False
        for pattern in OLD_PATTERNS:
            if re.match(pattern, stripped):
                is_old_decorator = True
                break
        
        # إذا كان @auth.requires_login() - نبحث عن الدالة التالية
        if stripped == '@auth.requires_login()' or is_old_decorator:
            # ابحث عن الدالة التالية
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith('def '):
                j += 1
            
            if j < len(lines):
                func_match = re.match(r'def\s+(\w+)\s*\(', lines[j].strip())
                if func_match:
                    func_name = func_match.group(1)
                    screen_code = screen_map.get(func_name)
                    
                    if screen_code is not None:
                        # استبدل الديكوريتور
                        indent = len(line) - len(line.lstrip())
                        new_lines.append(' ' * indent + f'@can_access({screen_code})')
                        changes += 1
                        i += 1  # تخطي السطر القديم
                        continue
        
        new_lines.append(line)
        i += 1
    
    new_content = '\n'.join(new_lines)
    
    if new_content != original:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"  MODIFIED: {controller_name}.py ({changes} changes)")
        return changes
    else:
        print(f"  OK: {controller_name}.py (no changes)")
        return 0

# معالجة جميع الـ controllers
total_changes = 0
for controller_name in sorted(SCREEN_MAP.keys()):
    print(f"Processing {controller_name}...")
    changes = process_controller(controller_name, SCREEN_MAP[controller_name])
    total_changes += changes

print(f"\nTotal changes: {total_changes}")
