var API_BASE = window.location.href + '/../../attendance/';
var EMP_API = window.location.href + '/../../employees/';

// تحويل ساعات عشرية إلى صيغة س:دد
function toHM(decimalHours) {
    var neg = decimalHours < 0;
    var abs = Math.abs(decimalHours);
    var h = Math.floor(abs);
    var m = Math.round((abs - h) * 60);
    if (m === 60) { h++; m = 0; }
    return (neg ? '-' : '') + h + ':' + String(m).padStart(2, '0');
}

// حساب دقائق الوردية الأساسية من shift_start و shift_end
function shiftBasicMinutes(row) {
    if (!row.shift_start || !row.shift_end) return null;
    var start = row.shift_start.split(':');
    var end = row.shift_end.split(':');
    if (start.length < 2 || end.length < 2) return null;
    var startMin = parseInt(start[0]) * 60 + parseInt(start[1]);
    var endMin = parseInt(end[0]) * 60 + parseInt(end[1]);
    var diff = endMin - startMin;
    if (diff <= 0) diff += 24 * 60;
    return diff;
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data_count: 0,
        employees: [],
        summary: { total_shifts: 0, total_hours: 0 },
        filters: {
            employee_id: '0',
            date_from: '',
            date_to: '',
            RecordCount: 50,
            page: 0,
        },
        loading: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_count / this.filters.RecordCount) || 1;
        },
        // إجمالي دقائق الوردية الأساسية
        totalBasicMinutes: function () {
            var total = 0;
            for (var i = 0; i < this.data.length; i++) {
                var m = shiftBasicMinutes(this.data[i]);
                if (m) total += m;
            }
            return total;
        },
        totalBasicHM: function () {
            return toHM(this.totalBasicMinutes / 60);
        },
        totalActualHM: function () {
            return toHM(Number(this.summary.total_hours));
        },
        totalDiff: function () {
            var diff = Number(this.summary.total_hours) - (this.totalBasicMinutes / 60);
            if (Math.abs(diff) < 0.01) return '0:00';
            var sign = diff > 0 ? '+' : '';
            return sign + toHM(diff);
        },
        totalDiffClass: function () {
            var diff = Number(this.summary.total_hours) - (this.totalBasicMinutes / 60);
            if (Math.abs(diff) < 0.01) return 'hours-exact';
            if (diff > 0) return 'hours-positive';
            return 'hours-negative';
        },
    },
    created: function () {
        var self = this;
        fetch(EMP_API + 'get_employees?RecordCount=500&page=0&SortBy=emp_name&sequence=true')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                self.employees = data.data || [];
            });
        this.fetchData();
    },
    methods: {
        onChange: function () {
            this.filters.page = 0;
            this.fetchData();
        },
        fetchData: function () {
            var self = this;
            self.loading = true;
            var url = new URL(API_BASE + 'get_report_data');
            url.searchParams.append('page', self.filters.page);
            url.searchParams.append('RecordCount', self.filters.RecordCount);
            if (self.filters.employee_id !== '0') {
                url.searchParams.append('employee_id', self.filters.employee_id);
            }
            if (self.filters.date_from) {
                url.searchParams.append('date_from', self.filters.date_from);
            }
            if (self.filters.date_to) {
                url.searchParams.append('date_to', self.filters.date_to);
            }
            fetch(url)
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    self.data = data.data || [];
                    self.data_count = data.count || 0;
                    self.summary = data.summary || { total_shifts: 0, total_hours: 0 };
                })
                .finally(function () { self.loading = false; });
        },
        formatTime: function (dt) {
            if (!dt) return '—';
            var parts = dt.split(' ');
            if (parts.length >= 2) {
                var time = parts[1].split(':');
                return time[0] + ':' + time[1];
            }
            return dt;
        },
        calcShiftBasicHours: function (row) {
            var m = shiftBasicMinutes(row);
            if (m === null) return '—';
            return toHM(m / 60);
        },
        calcActualHM: function (row) {
            if (!row.shift_hours) return '—';
            return toHM(row.shift_hours);
        },
        calcDiff: function (row) {
            if (!row.shift_hours || !row.shift_start || !row.shift_end) return '—';
            var basicMin = shiftBasicMinutes(row);
            if (basicMin === null) return '—';
            var actualDiff = row.shift_hours - (basicMin / 60);
            if (Math.abs(actualDiff) < 0.01) return '0:00';
            var sign = actualDiff > 0 ? '+' : '';
            return sign + toHM(actualDiff);
        },
        diffClass: function (row) {
            if (!row.shift_hours || !row.shift_start || !row.shift_end) return '';
            var basicMin = shiftBasicMinutes(row);
            if (basicMin === null) return '';
            var actualDiff = row.shift_hours - (basicMin / 60);
            if (Math.abs(actualDiff) < 0.01) return 'hours-exact';
            if (actualDiff > 0) return 'hours-positive';
            return 'hours-negative';
        },
        printReport: function () {
            window.print();
        },
    }
});
