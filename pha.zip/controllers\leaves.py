# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime
import api_helpers as api

_DAYS = ("يوم", "يومان", "أيام", "يوماً")
_STATES = ("current", "upcoming", "ended")
# فلتر الصرف: التذاكر وبدل الإجازة
_DUES = {
    "tickets": "COALESCE(lv.tickets_paid, 'F') <> 'T'",
    "allowance": "COALESCE(lv.allowance_paid, 'F') <> 'T'",
    "open": "(COALESCE(lv.tickets_paid, 'F') <> 'T' OR COALESCE(lv.allowance_paid, 'F') <> 'T')",
    "done": "(lv.tickets_paid = 'T' AND lv.allowance_paid = 'T')",
}
_PAID_FIELDS = {
    "tickets": ("tickets_paid", "تم تسجيل صرف التذاكر"),
    "allowance": ("allowance_paid", "تم تسجيل استلام بدل الإجازة"),
}

# أول معامل في كل استعلام هو تاريخ اليوم (t.today)، وتُحسب منه حالة الإجازة
_FROM_SQL = (
    "FROM emp_leaves lv "
    "JOIN employees emp ON emp.id = lv.employee "
    "LEFT JOIN key_job_titles jt ON jt.id = emp.job_title "
    "CROSS JOIN (SELECT %s::date AS today) t "
)
_STATE_SQL = (
    "CASE WHEN lv.start_date IS NULL THEN 'unknown' "
    "WHEN lv.start_date > t.today THEN 'upcoming' "
    "WHEN COALESCE(lv.end_date, lv.start_date) >= t.today THEN 'current' "
    "ELSE 'ended' END"
)
_ROW_SQL = (
    "SELECT lv.id, lv.employee, lv.start_date, lv.end_date, COALESCE(lv.days_count, 0) AS days_count, "
    "COALESCE(lv.tickets_paid, 'F') = 'T' AS tickets_paid, "
    "COALESCE(lv.allowance_paid, 'F') = 'T' AS allowance_paid, "
    "emp.emp_name, jt.name AS job_title_name, " + _STATE_SQL + " AS state, "
    "COALESCE(lv.end_date, lv.start_date) - lv.start_date + 1 AS calendar_days, "
    "COALESCE(lv.end_date, lv.start_date) - t.today + 1 AS days_left, "
    "lv.start_date - t.today AS starts_in, "
    "t.today - COALESCE(lv.end_date, lv.start_date) AS ended_ago "
)


def _post_only():
    """التعديل والحذف بطلب POST فقط، فلا يُنفَّذ برابط يُفتح في المتصفح."""
    if request.env.request_method != "POST":
        raise HTTP(405)


def _days_text(n):
    """عدد الأيام بقواعد العربية: يوم، يومان، 3-10 أيام، 11 فأكثر يوماً."""
    n = int(n)
    one, two, few, many = _DAYS
    if n == 1:
        return one
    if n == 2:
        return two
    return "%d %s" % (n, few if 3 <= n <= 10 else many)


def _leave_row(leave_id):
    rows = db.executesql(_ROW_SQL + _FROM_SQL + "WHERE lv.id = %s",
                         placeholders=[request.now.date(), leave_id], as_dict=True)
    return rows[0] if rows else None


def _validate_leave_payload(data):
    errors = []
    try:
        employee = int(data.employee)
    except (TypeError, ValueError):
        employee = 0
    if not employee or not db.employees[employee]:
        errors.append("الموظف مطلوب")

    start_date = None
    end_date = None
    try:
        start_date = datetime.strptime(str(data.start_date), "%Y-%m-%d").date()
    except Exception:
        errors.append("تاريخ بداية الإجازة مطلوب وصحيح")
    try:
        end_date = datetime.strptime(str(data.end_date), "%Y-%m-%d").date()
    except Exception:
        errors.append("تاريخ نهاية الإجازة مطلوب وصحيح")

    if start_date and end_date and end_date < start_date:
        errors.append("تاريخ نهاية الإجازة لا يمكن أن يكون قبل البداية")

    try:
        days_count = int(data.days_count or 0)
    except (TypeError, ValueError):
        days_count = 0
    if days_count <= 0:
        errors.append("عدد أيام الإجازة يجب أن يكون أكبر من صفر")

    return errors, {
        "employee": employee,
        "start_date": start_date,
        "end_date": end_date,
        "days_count": days_count,
    }


def _overlap_warnings(clean, exclude_id=0):
    """إجازات أخرى للموظف نفسه تتداخل مع الفترة؛ تُعرض للتأكيد ولا تمنع الحفظ."""
    rows = db.executesql(
        "SELECT id, start_date, COALESCE(end_date, start_date) FROM emp_leaves "
        "WHERE employee = %s AND id <> %s AND start_date IS NOT NULL "
        "AND start_date <= %s AND COALESCE(end_date, start_date) >= %s ORDER BY start_date",
        placeholders=[clean["employee"], exclude_id or 0, clean["end_date"], clean["start_date"]])
    return ["تتداخل مع إجازته رقم %d (من %s إلى %s)" % (r[0], r[1], r[2]) for r in rows]


@can_access(7005)
def index():
    return dict()


@can_access(7005)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    return response.json(api.api_ok(data={"employees": employees}))


@can_access(7005)
def get_leaves():
    ReqVar = request.vars
    try:
        pg = max(int(ReqVar.page or 0), 0)
        rc = min(max(int(ReqVar.RecordCount or 20), 1), 100)
    except (TypeError, ValueError):
        pg, rc = 0, 20

    conditions = []
    params = []

    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( emp.emp_name LIKE %s OR CAST(lv.start_date AS text) LIKE %s "
                "OR CAST(lv.end_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])
    if ReqVar.state in _STATES:
        conditions.append(_STATE_SQL + " = %s")
        params.append(ReqVar.state)
    if ReqVar.dues in _DUES:
        conditions.append(_DUES[ReqVar.dues])

    sort_map = {
        'id': 'lv.id',
        'emp_name': 'emp.emp_name',
        'start_date': 'lv.start_date',
        'end_date': 'lv.end_date',
        'days_count': 'lv.days_count',
        'tickets_paid': 'lv.tickets_paid',
        'allowance_paid': 'lv.allowance_paid',
    }
    sort_col = sort_map.get(ReqVar.SortBy, 'lv.id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    today = request.now.date()
    qry = db.executesql(
        _ROW_SQL + _FROM_SQL + where
        + " ORDER BY " + sort_col + " " + sa + " NULLS LAST, lv.id " + sa + " LIMIT %s OFFSET %s",
        placeholders=[today] + params + [rc, pg * rc], as_dict=True)
    totals = db.executesql(
        "SELECT COUNT(*) AS count, "
        "COUNT(*) FILTER (WHERE st = 'current') AS current, "
        "COUNT(*) FILTER (WHERE st = 'upcoming') AS upcoming, "
        "COALESCE(SUM(days_count), 0) AS days "
        "FROM (SELECT " + _STATE_SQL + " AS st, COALESCE(lv.days_count, 0) AS days_count "
        + _FROM_SQL + where + ") q",
        placeholders=[today] + params, as_dict=True)[0]

    return response.json(api.api_list(rows=qry, count=totals["count"], totals=totals))


@can_access(7005)
def get_leave_card():
    """بطاقة الإجازة: الفترة والحالة والصرف، بيانات الموظف، سجل إجازاته، وتنبيهات المراجعة."""
    try:
        leave_id = int(request.args(0))
    except (TypeError, ValueError):
        leave_id = 0
    lv = _leave_row(leave_id) if leave_id else None
    if not lv:
        return response.json(api.api_error(mess="الإجازة غير موجودة"))
    today = request.now.date()
    emp = db.executesql(
        "SELECT e.id, e.id_number, e.mobile, e.leave_month, st.name AS status_name "
        "FROM employees e LEFT JOIN key_emp_status st ON st.id = e.emp_status WHERE e.id = %s",
        placeholders=[lv["employee"]], as_dict=True)[0]
    try:
        emp["leave_month_name"] = HR_MONTHS[int(emp["leave_month"]) - 1]
    except (TypeError, ValueError, IndexError):
        emp["leave_month_name"] = ""
    history = db.executesql(
        _ROW_SQL + _FROM_SQL + "WHERE lv.employee = %s ORDER BY lv.start_date DESC NULLS LAST, lv.id DESC",
        placeholders=[today, lv["employee"]], as_dict=True)

    alerts = []
    start = lv["start_date"]
    end = lv["end_date"] or start
    if start and lv["calendar_days"] != lv["days_count"]:
        alerts.append({"level": "info", "text": "عدد الأيام المسجل %s، وأيام الفترة من بدايتها إلى نهايتها %s" % (
            _days_text(lv["days_count"]), _days_text(lv["calendar_days"]))})
    for h in history:
        h_end = h["end_date"] or h["start_date"]
        if h["id"] != lv["id"] and start and h["start_date"] and h["start_date"] <= end and start <= h_end:
            alerts.append({"level": "warn", "text": "تتداخل مع إجازته رقم %d (من %s إلى %s)" % (
                h["id"], h["start_date"], h_end)})
    status = emp["status_name"] or ""
    if lv["state"] == "current" and status != "في إجازة":
        alerts.append({"level": "warn", "text": "الإجازة جارية، وحالته في بيانات الموظف «%s»" % (
            status or "غير محددة")})
    if start and start <= today:
        worked = db.executesql(
            "SELECT COUNT(DISTINCT att_date) FROM attendance WHERE employee = %s "
            "AND att_date BETWEEN %s AND %s AND check_in IS NOT NULL",
            placeholders=[lv["employee"], start, min(end, today)])[0][0]
        if worked:
            alerts.append({"level": "warn", "text": "سجّل حضوراً في %s خلال هذه الإجازة" % _days_text(worked)})

    return response.json(api.api_ok(data={
        "leave": lv,
        "employee": emp,
        "history": history[:8],
        "history_count": len(history),
        "year": today.year,
        "year_days": sum(h["days_count"] for h in history if h["start_date"] and h["start_date"].year == today.year),
        "alerts": alerts,
    }))


@can_access(7005)
def new_leave():
    _post_only()
    try:
        data = request.vars
        errors, clean_data = _validate_leave_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        warnings = _overlap_warnings(clean_data)
        if warnings and data.confirm_overlap != '1':
            return response.json(api.api_error(mess=" | ".join(warnings), need_confirm=True, warnings=warnings))

        nid = db.emp_leaves.insert(
            employee=clean_data["employee"],
            start_date=clean_data["start_date"],
            end_date=clean_data["end_date"],
            days_count=clean_data["days_count"],
            tickets_paid=(data.tickets_paid == 'true' or data.tickets_paid == 'on'),
            allowance_paid=(data.allowance_paid == 'true' or data.allowance_paid == 'on'),
        )
        db.commit()
        return response.json(api.api_ok(data=_leave_row(nid) or {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7005)
def update_leave():
    _post_only()
    try:
        data = request.vars
        row = db.emp_leaves[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        errors, clean_data = _validate_leave_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        warnings = _overlap_warnings(clean_data, row.id)
        if warnings and data.confirm_overlap != '1':
            return response.json(api.api_error(mess=" | ".join(warnings), need_confirm=True, warnings=warnings))

        row.employee = clean_data["employee"]
        row.start_date = clean_data["start_date"]
        row.end_date = clean_data["end_date"]
        row.days_count = clean_data["days_count"]
        row.tickets_paid = (data.tickets_paid == 'true' or data.tickets_paid == 'on')
        row.allowance_paid = (data.allowance_paid == 'true' or data.allowance_paid == 'on')

        row.update_record()
        db.commit()
        return response.json(api.api_ok(data=_leave_row(row.id) or {"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7005)
def mark_paid():
    """تسجيل صرف التذاكر أو استلام بدل الإجازة من بطاقة الإجازة (التراجع من نافذة التعديل)."""
    _post_only()
    try:
        field, mess = _PAID_FIELDS.get(request.vars.what, (None, None))
        if not field:
            return response.json(api.api_error(mess="نوع الصرف غير معروف"))
        row = db.emp_leaves[request.vars.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if not row[field]:
            row.update_record(**{field: True})
            db.commit()
        return response.json(api.api_ok(data=_leave_row(row.id), mess=mess))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7005)
def delete_leave():
    _post_only()
    try:
        row = db.emp_leaves[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
