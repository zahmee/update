# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime
import api_helpers as api


def _validate_leave_payload(data):
    errors = []
    try:
        employee = int(data.employee)
    except (TypeError, ValueError):
        employee = 0
    if not employee or not db.employees[employee]:
        errors.append("الموظف مطلوب")

    start_date = None
    end_date = None
    try:
        start_date = datetime.strptime(str(data.start_date), "%Y-%m-%d").date()
    except Exception:
        errors.append("تاريخ بداية الإجازة مطلوب وصحيح")
    try:
        end_date = datetime.strptime(str(data.end_date), "%Y-%m-%d").date()
    except Exception:
        errors.append("تاريخ نهاية الإجازة مطلوب وصحيح")

    if start_date and end_date and end_date < start_date:
        errors.append("تاريخ نهاية الإجازة لا يمكن أن يكون قبل البداية")

    try:
        days_count = int(data.days_count or 0)
    except (TypeError, ValueError):
        days_count = 0
    if days_count <= 0:
        errors.append("عدد أيام الإجازة يجب أن يكون أكبر من صفر")

    return errors, {
        "employee": employee,
        "start_date": start_date,
        "end_date": end_date,
        "days_count": days_count,
    }


@can_access(7005)
def index():
    return dict()


@can_access(7005)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    return response.json(api.api_ok(data={"employees": employees}))


@can_access(7005)
def get_leaves():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( emp.emp_name LIKE %s OR CAST(lv.start_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern])

    allowed_sort_columns = {'id', 'emp_name', 'start_date', 'end_date', 'days_count', 'tickets_paid', 'allowance_paid'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'

    sort_map = {
        'id': 'lv.id',
        'emp_name': 'emp.emp_name',
        'start_date': 'lv.start_date',
        'end_date': 'lv.end_date',
        'days_count': 'lv.days_count',
        'tickets_paid': 'lv.tickets_paid',
        'allowance_paid': 'lv.allowance_paid',
    }
    sort_col = sort_map.get(sc, 'lv.id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT lv.id, lv.employee, lv.start_date, lv.end_date, lv.days_count, "
        f"lv.tickets_paid, lv.allowance_paid, "
        f"emp.emp_name "
        f"FROM emp_leaves lv "
        f"JOIN employees emp ON emp.id = lv.employee "
        f"{where} ORDER BY {sort_col} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM emp_leaves lv "
        f"JOIN employees emp ON emp.id = lv.employee "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7005)
def new_leave():
    try:
        data = request.vars
        errors, clean_data = _validate_leave_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        nid = db.emp_leaves.insert(
            employee=clean_data["employee"],
            start_date=clean_data["start_date"],
            end_date=clean_data["end_date"],
            days_count=clean_data["days_count"],
            tickets_paid=False,
            allowance_paid=False,
        )
        db.commit()

        inserted = db.executesql(
            "SELECT lv.id, lv.employee, lv.start_date, lv.end_date, lv.days_count, "
            "lv.tickets_paid, lv.allowance_paid, "
            "emp.emp_name "
            "FROM emp_leaves lv "
            "JOIN employees emp ON emp.id = lv.employee "
            "WHERE lv.id = %s",
            placeholders=[nid], as_dict=True
        )
        return response.json(api.api_ok(data=inserted[0] if inserted else {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7005)
def update_leave():
    try:
        data = request.vars
        row = db.emp_leaves[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        errors, clean_data = _validate_leave_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        row.employee = clean_data["employee"]
        row.start_date = clean_data["start_date"]
        row.end_date = clean_data["end_date"]
        row.days_count = clean_data["days_count"]
        row.tickets_paid = (data.tickets_paid == 'true' or data.tickets_paid == 'on')
        row.allowance_paid = (data.allowance_paid == 'true' or data.allowance_paid == 'on')

        row.update_record()
        db.commit()

        updated = db.executesql(
            "SELECT lv.id, lv.employee, lv.start_date, lv.end_date, lv.days_count, "
            "lv.tickets_paid, lv.allowance_paid, "
            "emp.emp_name "
            "FROM emp_leaves lv "
            "JOIN employees emp ON emp.id = lv.employee "
            "WHERE lv.id = %s",
            placeholders=[data.id], as_dict=True
        )
        return response.json(api.api_ok(data=updated[0] if updated else {"id": data.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7005)
def delete_leave():
    try:
        row = db.emp_leaves[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
