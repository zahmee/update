# response.logo = A(B('web',SPAN(2),'py'),XML('&trade;&nbsp;'),
                  # _class="brand",_href="http://www.web2py.com/")
response.title = request.application.replace('_',' ').title()
response.subtitle = 'نظام الصدارة'
## read more at http://dev.w3.org/html5/markup/meta.name.html
response.meta.author = 'ahmed zahmah <zahmee@gmail.com>'
response.meta.description = 'نظام الصدارة'
response.meta.keywords = 'web2py, python, framework'
response.meta.generator = 'Web2py Web Framework'

## your http://google.com/analytics id
#                 ('مرتجع التوريد - جديد', False, URL('returnedSupply', 'index'),'fas fa-exchange-alt') ,
#                 ( 'التصنيف الرئيسي ' ,  False, URL('items', 'main_items'),'fas fa-pills') ,

#                ('________________________',False,'','') ,
#                ('مرتجع التوريد - الفواتير غير المعتمدة', False, URL('suppliers', 'returned_supply'),'fas fa-exchange-alt') ,
#                ('مرتجع التوريد - الفواتير المعتمدة', False, URL('suppliers', 'returned_supply_f'),'fas fa-exchange-alt') ,
#                ('________________________',False,'','') ,
#                ('__________________________',False,'','') ,
#                ( 'جرد الأصناف ' ,  False, URL('inventory', 'inventory_items'),'') ,
#                ('محاضر اتلاف اصناف منتهية الصلاحية',False, URL('items', 'damage_report'),'') ,
#                ( 'عمليات و استعلامات على الاصناف ' ,  False, URL('items_qry', 'items_qry'),'fal fa-prescription-bottle-alt') ,
#                ( 'ادخال الاصناف حسب الفواتير ' ,  False, URL('items', 'de_it'),'fas fa-notes-medical') ,
#                ( 'اقفال الاستلام' ,  False, URL('employees', 'close_period'),'fal fa-stopwatch') ,
#+++++++++++++++++++++++++++++++++
#    ( 'فواتير التوريد ' ,  False, URL('suppliers', 'supply_bills'),'far fa-file-invoice-dollar') ,
#    ('صيانة البيانات', False, URL('setup', 'update_items_det'),'') ,
#    ('2صيانة البيانات', False, URL('setup', 'update_items_main1'),'') ,
#    ('اخطاء الاعتماد', False, URL('setup', 'print_report'),'') ,
#    ( 'الادوار ' ,  False, URL('setup', 'groups'),'') ,
#    ( 'ادخال فترات الجرد ' ,  False, URL('inventory', 'inventory'),'') ,
#    ('--------------', False, URL('', ''),'') ,
#    ('الصلاحيات حسب الشاشات', False, URL('setup', 'screens_rules'),'') ,



if auth.is_logged_in():
        response.menu = [
            ( 'العملاء' , False,  URL('customers', 'index'),[], 'fas fa-address-card') ,
            ( 'الموردين ' ,  False, '', [
                ( 'استعراض الموردين' ,  False, URL('new_suppliers', 'index'),'far fa-tasks-alt') ,
                ( 'فواتير التوريد ' ,  False, URL('new_suppliers', 'suppliers_bills'),'far fa-file-invoice-dollar') ,
                ('المرتجع و التحويل ', False, URL('new_suppliers',
                 'returned_supply'), 'fas fa-exchange-alt'),
                ('سداد الموردين ', False, URL('new_suppliers',
                 'suppliers_payment'), 'fal fa-money-check-alt'),
                ('ارصدة الموردين ', False, URL('new_suppliers',
                 'opening_balance'), 'far fa-coins'),
                ('مطابقة الارصدة ', False, URL('new_suppliers',
                 'balance_reconciliation'), 'fad fa-balance-scale'),  
            ], 'fas fa-user-headset'),
            ( 'الاصناف ' ,  False, '', [
                ( 'التصنيف الرئيسي  ' ,  False, URL('V4_items', 'main'),'fas fa-pills') ,
                ( 'تفاصيل الاصناف ' ,  False, URL('V4_items', 'new_items_det'),'fad fa-tablets') ,
                ( 'دمج صنفين مع بعضهما ' ,  False, URL('items_qry', 'items_merge'),'fal fa-object-group') ,
                ( 'تقرير عن الأصناف المقاربة على الانتهاء ' ,  False, URL('items', 'rep_bydate'),'fab fa-empire') ,
                ( 'الأصناف التي بحاجة الى إعادة طلب ' ,  False, URL('items_reorder', 'index'),'far fa-sort-shapes-down-alt') ,
                ( 'الاصناف ذات الاعداد بالسالب ' ,  False, URL('items_qry', 'negative_items'),'fas fa-minus-octagon') ,
                ( 'الاصناف غير المتحركة ' ,  False, URL('items_qry', 'stop_items'),'fas fa-tachometer-slowest') ,
                ( 'ادخال الجرد ' ,  False, URL('inventory', 'inventory'),'fad fa-inventory') ,
                ],'fas fa-sitemap') ,
            ( 'المبيعات ' ,  False, '', [
                ( 'المبيعات اليومية ' ,  False, URL('invoice', 'index'),'fal fa-money-bill-wave') ,
                ( 'مرتجع المبيعات ' ,  False, URL('invoice', 'inv_return'),'fal fa-exchange') ,
                ( 'استعراض فواتير المبيعات ' ,  False, URL('invoice', 'invoice_show'),'fal fa-receipt') ,
                ( 'استعراض فاتورة ' ,  False, URL('invoice', 'inv_view'),'fal fa-receipt') ,
                ],'fas fa-shopping-cart') ,
        ]
if auth.has_membership("admin")  :
    response.menu+=('التقارير', False, '', [
           ( 'المبيعات ' ,  False,URL('invoice', 'inv_rep1'), 'fad fa-box-check') ,
           ( 'الموردين ' ,  False,URL('suppliers', 'supply_rep'), 'fad fa-industry-alt') ,
           ( 'الضريبة ' ,  False,URL('vat', 'index'), 'fad fa-money-bill-alt') ,
           ('تقارير عامة', False, URL('items_rep', 'items_report_crate'), 'fad fa-clipboard-list-check' ) ,
            ],'fas fa-file-invoice-dollar') ,
if auth.has_membership("admin"):
    response.menu+=(SPAN('الإعدادات'), False,'', [
    ( 'الوحدات ' ,  False, URL('setup', 'unit_key'),'') ,
        ('انواع الفواتير ',  False, URL('setup', 'key_invoce_type'), ''),
    ( 'التصنيف ' ,  False, URL('setup', 'type_key'),'') ,
    ( 'طريقة الدفع ' ,  False, URL('setup', 'payment_method_key'),'') ,
    (' المستخدمين', False, URL('setup', 'users'),'') ,
    ( 'صلاحيات المستخدمين ' ,  False, URL('setup', 'membership'),'') ,
    ('شاشات النظام', False, URL('setup', 'screens'),'') ,
    ('--------------', False, URL('', ''),'') ,
    ('المعلومات الرسمية', False, URL('setup', 'important_info'),'') ,
    ('الشعار الرسمي', False, URL('setup', 'important_info_2'),'') ,
    ('--------------', False, URL('', ''),'') ,
    ( 'ادخال فترات الجرد ' ,  False, URL('inventory', 'inventory'),'') ,
    ],'fal '),

if auth.is_logged_in():
	response.menu+= (SPAN('حول'), False,URL('default', 'about'), '','fas fa-info ') ,
DEVELOPMENT_MENU = True

"""
                ( 'اضافة فاتورة جديدة ' ,  False, URL('suppliers_bills', 'add_bills'),'far fa-file-invoice-dollar') ,

                ( 'توزيع كمية صنف على اكثر من صنف ' ,  False, URL('items_qry', 'items_unmerged'),'fad fa-object-ungroup') ,
"""