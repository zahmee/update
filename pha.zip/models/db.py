# -*- coding: utf-8 -*-
#  type: ignore


import datetime
from gluon.contrib.appconfig import AppConfig
from gluon.tools import Auth

if request.global_settings.web2py_version < "2.15.5":
    raise HTTP(500, "Requires web2py 2.15.5 or newer")

configuration = AppConfig(reload=True)
c = datetime.datetime.now()
exp = configuration.get("app.exp_date")
if exp:
    d1 = datetime.datetime.strptime(c.strftime("%Y-%m-%d"), "%Y-%m-%d")
    d2 = datetime.datetime.strptime(exp, "%Y-%m-%d")
    date_def = (d2 - d1).days
    if date_def < 1:
        raise HTTP(
            400,
            (
                "<h1 style='text-align: center;' > نعتذر منك لقد انتهى اشتراكك </h1>"
                f"<h2 style='text-align: center;' > {exp} </h2>"
            ),
        )


if not request.env.web2py_runtime_gae:
    # ---------------------------------------------------------------------
    # if NOT running on Google App Engine use SQLite or other DB
    # ---------------------------------------------------------------------
    db = DAL(
        configuration.get("db.uri"),
        pool_size=configuration.get("db.pool_size"),
        migrate_enabled=configuration.get("db.migrate"),
        check_reserved=["postgres"],
    )
else:
    db = DAL("google:datastore+ndb")
    session.connect(request, response, db=db)

response.generic_patterns = []
if request.is_local and not configuration.get("app.production"):
    response.generic_patterns.append("*")

response.formstyle = "bootstrap4_inline"
response.form_label_separator = ""

auth = Auth(db, host_names=configuration.get("host.names"))

auth.settings.extra_fields["auth_user"] = []
auth.define_tables(username=False, signature=False)

# -------------------------------------------------------------------------
# configure email
# -------------------------------------------------------------------------
mail = auth.settings.mailer
mail.settings.server = (
    "logging" if request.is_local else configuration.get("smtp.server")
)
mail.settings.sender = configuration.get("smtp.sender")
mail.settings.login = configuration.get("smtp.login")
mail.settings.tls = configuration.get("smtp.tls") or False
mail.settings.ssl = configuration.get("smtp.ssl") or False

# -------------------------------------------------------------------------
# configure auth policy
# -------------------------------------------------------------------------
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.settings.reset_password_requires_verification = True

# -------------------------------------------------------------------------
# read more at http://dev.w3.org/html5/markup/meta.name.html
# -------------------------------------------------------------------------
response.meta.author = configuration.get("app.author")
response.meta.description = configuration.get("app.description")
response.meta.keywords = configuration.get("app.keywords")
response.meta.generator = configuration.get("app.generator")
response.show_toolbar = configuration.get("app.toolbar")

# -------------------------------------------------------------------------
# your http://google.com/analytics id
# -------------------------------------------------------------------------
response.google_analytics_id = configuration.get("google.analytics_id")

# -------------------------------------------------------------------------
# maybe use the scheduler
# -------------------------------------------------------------------------
if configuration.get("scheduler.enabled"):
    from gluon.scheduler import Scheduler

    scheduler = Scheduler(db, heartbeat=configuration.get("scheduler.heartbeat"))

# -------------------------------------------------------------------------
# Define your tables below (or better in another model file) for example
#
# >>> db.define_table('mytable', Field('myfield', 'string'))
#
# Fields can be 'string','text','password','integer','double','boolean'
#       'date','time','datetime','blob','upload', 'reference TABLENAME'
# There is an implicit 'id integer autoincrement' field
# Consult manual for more options, validators, etc.
#
# More API examples for controllers:
#
# >>> db.mytable.insert(myfield='value')
# >>> rows = db(db.mytable.myfield == 'value').select(db.mytable.ALL)
# >>> for row in rows: print row.id, row.myfield
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# after defining tables, uncomment below to enable auditing
# -------------------------------------------------------------------------
# auth.enable_record_versioning(db)
auth.settings.create_user_groups = False
auth.settings.showid = False
T.force("ar")
response.delimiters = ("{{{", "}}}")

# ---------------------------------------------------------------------------
# جدول الوحدات للأصناف
db.define_table("key_unit", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_unit.id.label = "م"

if db(db.key_unit.id > 0).isempty() == True:
    db.key_unit.insert(name="حبة")
    db.key_unit.insert(name="علبة")
    db.key_unit.insert(name="كرتون")
    db.key_unit.insert(name="ملل")
    db.key_unit.insert(name="شنطة")
# ============================================================================
db.define_table(
    "key_payment_method", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_method.id.label = "م"

if db(db.key_payment_method.id > 0).isempty() == True:
    db.key_payment_method.insert(name="نقدي")
    db.key_payment_method.insert(name="شبكة الكترونية")
    db.key_payment_method.insert(name="آجل")
    db.key_payment_method.insert(name="تحويل في الحساب")
    db.key_payment_method.insert(name="شيك")
    db.key_payment_method.insert(name="خصم من الرصيد")
# =============================================================================
# ---------------------------------------------------------------------------
# جدول انواع العملاء
db.define_table("key_cust", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_cust.id.label = "م"

if db(db.key_cust.id > 0).isempty() == True:
    db.key_cust.insert(name="عميل عام")
    db.key_cust.insert(name="عميل جمعية البر")


if db(db.auth_group.id > 0).isempty() == True:
    db.auth_group.insert(role="admin")
    db.auth_group.insert(role="user")
    db.auth_group.insert(role="account")
    db.auth_group.insert(role="report")


if db(db.auth_user.id > 0).isempty() == True:
    password = db.auth_user.password.validate("admin")[0]
    user_id = db.auth_user.insert(
        first_name="admin", last_name="user", password=password, email="admin@user.com"
    )
if db(db.auth_membership.id > 0).isempty() == True:
    db.auth_membership.insert(
        user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
    )

# ==============================================================================

# جدول التصنيفات للأصناف
db.define_table("key_type", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_type.id.label = "م"

if db(db.key_type.id > 0).isempty() == True:
    db.key_type.insert(name="ادوات تجميل")
    db.key_type.insert(name="ادوات طبية")
    db.key_type.insert(name="ادوية")
    db.key_type.insert(name="اطفال")
    db.key_type.insert(name="اسنان")
# ==============================================================================

# جدول انواع السداد للمورد
db.define_table(
    "key_payment_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_type.id.label = "م"

if db(db.key_payment_type.id > 0).isempty() == True:
    db.key_payment_type.insert(name="سداد مستحقات")
    db.key_payment_type.insert(name="خصم مكتسب")
    db.key_payment_type.insert(name="مرتجعات/فاتورة")
    db.key_payment_type.insert(name="مرتجعات/اصناف")

# ==============================================================================
# جدول تصنيف الفواتير
db.define_table(
    "key_invoce_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_invoce_type.id.label = "م"
if db(db.key_invoce_type.id > 0).isempty() == True:
    db.key_invoce_type.insert(name="مشتريات")
    db.key_invoce_type.insert(name="تعويض")
    db.key_invoce_type.insert(name="هدايا")
# ------------------------------------------------------------------------------------
#  جدول الموردين
db.define_table(
    "suppliers",
    Field(
        "name",
        length=260,
        label="اسم المورد",
        required=True,
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("specialization", "list:string", label="مجال اختصاص المورد"),
    Field("administrator_name", "list:string", label="اسم المسؤول"),
    Field("total_amount", "double", default=0, label="المبلغ المستحق له"),
    Field("days_to_pay", "integer", label="عدد الايام لسداد"),
    Field("postpaid_discount", "double", label="خصم السداد آجل"),
    Field("discount_cash_payment", "double", label="خصم السداد كاش"),
    Field("payment_discount_for_year", "double", label="خصم السداد لعام"),
    Field("tel", "text", label="هواتف المورد"),
    Field("address", "text", label="العنوان"),
    Field("bank_account", "text", label="رقم الحساب في البنك"),
    Field("stoped", "boolean", default=False, label="موقف"),
    Field("note", "text", label="ملاحظات"),
    Field(
        "total_amount_postpaid",
        "double",
        label="اجمالي آجل",
        readable=False,
        writable=False,
    ),
    Field(
        "total_amount_cash",
        "double",
        label="اجمالي كاش",
        readable=False,
        writable=False,
    ),
    Field(
        "total_amount_payment",
        "double",
        label="اجمالي مسدد",
        readable=False,
        writable=False,
    ),
    Field("net_amount_req", "double", label="المطلوب", readable=False, writable=False),
    auth.signature,
    format="%(id)s - %(name)s",
)
db.suppliers.id.label = "م"
#
if db(db.suppliers.id > 0).isempty() == True:
    db.suppliers.insert(name="مورد عام - مورد نقدي")

db.define_table(
    "suppliers_files",
    Field(
        "suppliers_id",
        "reference suppliers",
        default=request.args(0),
        label="المورد",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.suppliers_files.id.label = "م"
# =====================================================================================


# -----------------------------------------------------------------------------------------
#  فواتير التوريد
db.define_table(
    "suppliers_bills",
    Field("supplier", "reference suppliers", label="المورد"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("invoce_type", "reference key_invoce_type", label="نوع الفاتورة"),
    Field(
        "bill_no",
        length=15,
        label="رقم الفاتورة من المورد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_date",
        "date",
        label="تاريخ الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_total",
        "double",
        label="اجمالي المبلغ مع الضريبة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_net_amount",
        "double",
        label="صافي المبلغ بدون ضريبة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_vat",
        "double",
        label="صافي الضريبة من المورد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_confirmation",
        "boolean",
        default=False,
        readable=False,
        writable=False,
        label="تم تأكيد الفاتورة",
    ),
    Field(
        "to_user",
        "reference auth_user",
        label="مسندة لـ",
        readable=False,
        writable=False,
    ),
    Field(
        "bill_by_date",
        "date",
        readable=False,
        writable=False,
        label="تاريخ سداد الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "total_from_item",
        "double",
        label="مبلغ الفواتير",
        readable=False,
        writable=False,
    ),
    Field(
        "return_confirmation",
        "boolean",
        default=False,
        label="تاكيد المرتجع",
        readable=False,
        writable=False,
    ),
    Field("note", "list:string", label="ملاحظات"),
    Field("bill_selling", "double", label="البيع", default=0.0, writable=False),
    Field(
        "bill_profit_ratio", "double", label="نسبة الربح", default=0.0, writable=False
    ),
    Field("bill_profit", "double", label="مبلغ الربح", default=0.0, writable=False),
    auth.signature,
    format="%(name)s",
)
db.suppliers_bills.id.label = "م"
#
db.define_table(
    "suppliers_bills_files",
    Field(
        "suppliers_bills_id",
        "reference suppliers_bills",
        default=request.args(0),
        label="فواتير المورد",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.suppliers_bills.id.label = "م"
# ====================================================================================


# ---------------------------------------------------------------------------------------------------------------
#  فواتير سداد الموردين
db.define_table(
    "suppliers_bills_pay",
    Field("supplier", "reference suppliers", label="المورد"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("payment_type", "reference key_payment_type", label="نوع السداد"),
    Field(
        "pay_total",
        "double",
        label="المبلغ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "pay_date",
        "date",
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.suppliers_bills_pay.id.label = "م"

# ---------------------------------------------------------------------------------------------------------------
#  ارصدة الموردين السابقة  - الارصدة الافتتاحية
db.define_table(
    "suppliers_opening_balance",
    Field("year_balance", "integer", label="السنة"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field(
        "account",
        "double",
        label="الرصيد السابق",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.suppliers_opening_balance.id.label = "م"

# ملفات فواتير سداد الموردين
db.define_table(
    "suppliers_bills_pay_files",
    Field(
        "suppliers_bills_pay_id",
        "reference suppliers_bills_pay",
        default=request.args(0),
        label="سدادات الموردين",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.suppliers_bills.id.label = "م"

# مطابقة الارصدة
db.define_table(
    "suppliers_balance_reconciliation",
    Field("supplier", "reference suppliers", label="المورد"),
    Field(
        "balance_date",
        "date",
        label="تاريخ المطابقة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "balance",
        "integer",
        label="مطابق",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("balance_def", "double", label="الفرق", default=0),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.suppliers_balance_reconciliation.id.label = "م"

# ==================================================================================================================

# جدول الأصناف الأساسي
db.define_table(
    "items_main",
    Field(
        "item_id", length=20, label="رقم الصنف", required=IS_NOT_EMPTY(), unique=True
    ),
    Field("item_reg", length=20, label="رقم التسجيل"),
    Field(
        "name",
        length=460,
        label="الاسم التجاري",
        required=True,
        requires=[IS_NOT_EMPTY(), IS_LOWER()],
    ),
    Field(
        "generic_name", length=460, readable=False, writable=False, label="الاسم العلمي"
    ),
    Field(
        "item_unit",
        "reference key_unit",
        label="الوحدة",
    ),
    Field(
        "item_type",
        "reference key_type",
        label="التصنيف",
    ),
    Field("vat", "double", readable=False, writable=False, label="VAT"),
    Field("item_group", "integer", label="المجموعة"),
    Field("public_price", "double", label="السعر للجمهور"),
    Field("buy_price", "double", readable=False, writable=False, label="سعر الشراء"),
    Field(
        "report_year",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="سنة التقرير",
    ),
    Field(
        "report_month",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="شهر التقرير",
    ),
    Field(
        "quantity_reorder",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="كمية إعادة الطلب",
    ),
    Field(
        "quantity_order",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="كمية الطلب",
    ),
    Field(
        "existing",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="الموجود",
    ),
    Field(
        "required",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="المطلوب",
    ),
    Field(
        "selling_average",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="متوسط البيع",
    ),
    Field("halt", "boolean", default=False, label=" موقوف"),
    Field("seasonal_drug", "boolean", default=False, label=" موسمي"),
    Field(
        "lowest_price", "double", readable=False, writable=False, label="اقل سعر مشترى"
    ),
    Field(
        "report_date", "datetime", readable=False, writable=False, label="تاريخ التقرير"
    ),
    Field("suppliers", "reference suppliers", label="المورد"),
    Field("flexible_price", "boolean", default=False, label=" متغير السعر"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
    format="%(name)s",
)
db.items_main.id.label = "م"
if db(db.items_main.id > 0).isempty() == True:
    db.items_main.insert(
        item_id="1", name="هلل", item_reg="1", flexible_price=True, public_price=0.01
    )


#  جدول الأصناف
db.define_table(
    "items_det",
    Field(
        "item_idr",
        "reference items_main",
        label="الصنف الأساسي",
        writable=False,
        required=IS_NOT_EMPTY(),
    ),
    Field(
        "supplier_inv", "integer", label="رقم فاتورة التوريد", required=IS_NOT_EMPTY()
    ),
    Field("item_id", length=20, label="رقم الصنف ", required=IS_NOT_EMPTY()),
    Field("public_price", "double", label="السعر للجمهور"),
    Field("quantity", "double", label="الكمية"),
    Field(
        "free_quantity",
        "double",
        default=0.0,
        writable=False,
        readable=False,
        label="مجاني",
    ),
    Field(
        "discount_rate",
        "double",
        default=0.0,
        writable=False,
        readable=False,
        label="الخصم / نسبة",
    ),
    Field(
        "discount",
        "double",
        default=0.0,
        writable=False,
        readable=False,
        label="الخصم / مبلغ",
    ),
    Field("buy_price", "double", label="سعر الشراء"),
    Field("expiration_date", "date", label="تاريخ الصلاحية"),
    Field("inv_price", "double", label="سعر الشراء الإجمالي"),
    Field("items_count", "double", label="الكمية الفعلية"),
    Field("vat", "double", label="الضريبة"),
    Field("vat_price", "double", label="مبلغ الضريبة"),
    Field("vat_in_public_price", "boolean", label="الضريبة ضمن سعر البيع"),
    Field("return_count", "double", label="المرتجع"),
    Field("item_chked", "boolean", writable=False, readable=False, label="تم تأكيد"),
    Field(
        "return_chked",
        "boolean",
        writable=False,
        readable=False,
        label="تم تأكيد المرتجع",
    ),
    Field("expired_count", "double", default=0.0, label="المنتهي الصلاحية"),
    Field(
        "expired_chked",
        "boolean",
        writable=False,
        readable=False,
        label="تم تأكيد المنتهي الصلاحية",
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.items_det.id.label = "رقم الصنف"

# ------------------------------------------------------------------------------------------------------------
#  جدول العملاء
db.define_table(
    "customers",
    Field("name", length=260, label="اسم العميل", required=True),
    Field("administrator_name", length=260, label="اسم المسؤول", readable=False),
    Field("mobile", length=10, label="رقم الجوال", readable=False, unique=True),
    Field("tel", "list:string", label="هواتف العميل"),
    Field("address", "text", label="العنوان", readable=False),
    Field("note", "text", label="ملاحظات"),
    Field("cust_type", "integer", label="نوع العميل"),
    Field("total", "double", label="المشتريات", writable=False),
    Field("payed", "double", label="المسدد", writable=False),
    Field("returns", "double", label="المرتجع", writable=False),
    Field("amount", "double", label="المطلوب", writable=False),
    auth.signature,
    format="%(name)s",
)
db.customers.id.label = "م"
if db(db.customers.id > 0).isempty() == True:
    db.customers.insert(name="عميل عام - نفدي", mobile="0")
#

#
db.define_table(
    "customers_files",
    Field(
        "customers_id",
        "reference customers",
        default=request.args(0),
        label="العميل",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.customers_files.id.label = "م"

#
db.define_table(
    "customers_pay",
    Field("customers_id", "reference customers", label="العميل"),
    Field(
        "amount",
        "double",
        label="المبلغ المسدد",
        requires=IS_DECIMAL_IN_RANGE(1, 100000),
    ),
    Field(
        "customers_pay_data",
        length=12,
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("note", length=100, label="ملاحظة"),
    Field("pay_note", length=100, label="ملاحظات السداد"),
    Field("pay_type", "integer", label="نوع السداد"),
    auth.signature,
)
db.customers_pay.id.label = "م"

# Accounts settlement
db.define_table(
    "customers_accounts_settlement",
    Field(
        "customers_id",
        "reference customers",
        default=request.args(0),
        label="العميل",
        readable=False,
        writable=False,
    ),
    Field("settlement_data", "datetime", default=request.now, label="تاريخ السداد"),
    auth.signature,
)
db.customers_accounts_settlement.id.label = "م"

# ==========================================================================================================


#  جدول الفاتورة - الأب
db.define_table(
    "invoice_master",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", default=0.0, label="صافي الفاتورة"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    auth.signature,
    format="%(name)s",
)
db.invoice_master.id.label = "م"

#  جدول الفاتورة - الابن
db.define_table(
    "invoice_details",
    Field("item_number", "reference items_det", label="رقم الصنف"),
    Field("item_idr", "integer", label="رقم الصنف الاساسي"),
    Field("item_count", "double", label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="نسبة الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة الضريبة"),
    auth.signature,
)
db.invoice_details.id.label = "م"
# db.dkey.id.default =lambda: (db().select(db.dkey.id.max()).first()[db.dkey.id.max()] or 0) +1

#  جدول مرتجع المبيعات - الأب
db.define_table(
    "inv_return_master",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", default=0.0, label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    auth.signature,
)
db.inv_return_master.id.label = "م"


#  جدول مرتجع المبيعات - الأبن
db.define_table(
    "inv_return_details",
    Field("item_number", "reference items_det", label="رقم الصنف"),
    Field("item_count", "double", default=0, label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة ةالضريبة"),
    auth.signature,
)
db.inv_return_details.id.label = "م"

# =============================================================================================================================
# جدول الجرد
db.define_table(
    "inventory",
    Field("name", length=70, label="وصف الجرد"),
    Field("inventory_date", length=16, label="تاريخ عملية الجرد"),
    Field("open", "boolean", label="عملية الجرد مفتوحة"),
    Field("to_user", "reference auth_user", label="مسندة لـ"),
    auth.signature,
    format="%(name)s",
)
db.inventory.id.label = "م"

# جدول اصناف الجرد
##sum =  db.items_det.items_count.sum()
db.define_table(
    "inventory_items",
    Field(
        "inventory",
        "reference inventory",
        default=request.args(0),
        label="وصف عملية الجرد",
    ),
    Field("items_main", "reference items_main", label="رقم الصنف "),
    Field("item_id", length=20, label="رقم الصنف "),
    Field("item_name", length=150, label="اسم الصنف"),
    Field("quantity", "double", label="الكمية الموجودة في الرف", default=0),
    Field("real_quantity", "double", label="الكمية الفعلية"),
    Field("difference", "double", label="الفرق"),
    Field("add_by_user", "reference auth_user", label="مدخل بواسطة"),
    Field("add_time", "datetime", label="وقت الادخال"),
    Field("item_row", length=4, label="الصف"),
    Field("item_column", length=4, label="العمود"),
    Field("added_later", "double", label="المضاف لاحقا"),
    Field("discounted_later", "double", label="المخصوم لاحقا"),
    Field("check_by_user", "reference auth_user", label="التشييك بواسطة"),
    Field("check_time", "datetime", label="وقت التشييك"),
    Field("check_quantity", "double", label="ادخال المراجعة"),
    Field("check_system_quantity", "double", label="كمية النظام"),
    Field("check_difference", "double", label="الفرق "),
    Field("approve", "boolean", default=False, writable=False, label="تم اعتمادة"),
    auth.signature,
)
db.inventory_items.id.label = "م"

# ==============================================================================================================================
# جدول محتضر الإتلاف
db.define_table(
    "damage_report",
    Field("name", length=270, label="وصف المحضر"),
    Field("damage_date", length=16, label="تاريخ الاتلاف"),
    Field(
        "admin_accept",
        "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدير",
    ),
    Field(
        "user_accept",
        "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدخل",
    ),
    Field("item_count", "double", default=0.0, writable=False, label="عدد الاصناف"),
    Field("item_sum", "double", default=0.0, writable=False, label="عدد المواد"),
    auth.signature,
    format="%(name)s",
)
db.damage_report.id.label = "م"
# التفاصيل
db.define_table(
    "damage_report_det",
    Field(
        "damage_report",
        "reference damage_report",
        default=request.args(0),
        label="محضر الاتلاف",
    ),
    Field("item_id", length=20, required=IS_NOT_EMPTY(), label="رقم الصنف"),
    Field(
        "item_name",
        length=270,
        writable=True,
        compute=lambda r: db.items_main[db.items_det(r["item_id"]).item_idr].name,
        label="اسم الصنف",
    ),
    Field(
        "item_count",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).items_count,
        writable=True,
        label="عدد الاصناف",
    ),
    auth.signature,
)
db.damage_report_det.id.label = "م"
# -----------------------------------------------------------------------------------------------------

# مرتجع التوريد
db.define_table(
    "returned_supply",
    Field("name", length=270, label="وصف الفاتورة"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field(
        "ret_date",
        "date",
        label="تاريخ الارجاع",
    ),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("real_total", "double", default=0, writable=False, label="الاجمالي - م"),
    Field("real_total2", "double", default=0, writable=False, label="الاجمالي - ب"),
    Field("admin_accept", "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدير",
    ),
    Field(
        "user_accept",
        "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدخل",
    ),
    Field("item_count", "double", default=0.0, writable=False, label="عدد الاصناف"),
    Field("item_sum", "double", default=0.0, writable=False, label="عدد المواد"),
    auth.signature,
    format="%(name)s",
)
db.returned_supply.id.label = "م"
# التفاصيل
db.define_table(
    "returned_supply_det",
    Field(
        "returned_supply",
        "reference returned_supply",
        default=request.args(0),
        label="وصف الفاتورة",
    ),
    Field("item_id", length=20, required=IS_NOT_EMPTY(), label="رقم الصنف"),
    Field(
        "item_name",
        length=270,
        writable=True,
        compute=lambda r: db.items_main[db.items_det(r["item_id"]).item_idr].name,
        label="اسم الصنف",
    ),
    Field(
        "vat",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).vat or 0,
        label="الضريبة",
    ),
    Field("item_count", "double", writable=True, label="عدد الاصناف"),
    Field(
        "inv_price",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).buy_price,
        label="سعر الشراء",
    ),
    Field(
        "inv_bay",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).public_price,
        label="سعر البيع",
    ),
    Field(
        "total",
        "double",
        compute=lambda r: float(r.item_count * r.inv_price),
        label="الاجمالي - م",
    ),
    Field(
        "total_2",
        "double",
        compute=lambda r: float(r.item_count * r.inv_bay),
        label="الاجمالي - ب",
    ),
    auth.signature,
)
db.returned_supply_det.id.label = "م"
# ===========================================================================================
# جدول الاخطاء و التقارير عن البررنامج

db.define_table("print_report", Field("er_dis", "text", label="وصف الخطاء"))


# ===========================================================================================
# جدول الملاحظات من المستخدمين
db.define_table(
    "memo_report",
    Field("dis", "text", label="وصف الملاحظة"),
    Field("screen", length=270, label="الشاشة"),
    Field("important", "integer", readable=False, label="مدى اهميتها"),
    Field("show", "boolean", default=False, readable=False, label="استعرضها المبرمج"),
    Field("aprove", "boolean", default=False, readable=False, label="اعتمدها المبرمج"),
    Field("date_to_do", readable=False, length=150, label="تاريخ انجازها"),
    auth.signature,
)

# ===========================================================================================
# ===========================================================================================
#  جدول اوامر الشراء
db.define_table(
    "items_reorder",
    Field("dis", "text", label="وصف العملية"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("avrg_by", "double", default=4, label="المتوسط / شهر"),
    Field("order_by", "double", default=1, label="الطلب / شهر"),
    Field("order_date", "date", default=request.now, label="تاريخ العملية"),
    Field(
        "order_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    Field(
        "jop_start_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    Field(
        "jop_end_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    Field("row_count", "double", default=0, label="عدد السجلات"),
    auth.signature,
)

#  جدول اصناف اوامر الشراء
db.define_table(
    "items_reorder_detail",
    Field("items_reorder", "reference items_reorder"),
    Field("items_main", "reference items_main"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("quantity", "double", label="الكمية الموجودة في الرف", default=0),
    Field("avrg_items", "double", default=4, label="المتوسط "),
    Field("order_items", "double", default=1, label="الطلب "),
    Field("best_price", "double", label="افضل سعر"),
    Field("best_price_supp", "integer", label="افضل مورد"),
    Field("order_date", "date", default=request.now, label="تاريخ العملية"),
    Field(
        "order_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    auth.signature,
)
# ===========================================================================================
# جدول تسليم الفترات للصندوق
db.define_table(
    "closing_shift",
    Field("pha_user", "reference auth_user", label="المستخدم"),
    Field("start_time", "datetime", label="وقت البداية"),
    Field("end_time", "datetime", label="وقت النهاية"),
    Field("app_amount_cash", "double", label="كاش / النظام"),
    Field("app_amount_atm", "double", label="صرافة / النظام"),
    Field("app_amount_delay", "double", label="آجل / النظام"),
    Field("app_total", "double", readable=False, writable=True, label="اجمالي النظام"),
    Field("kashir_amount_cash", "double", label="كاش / الصندوق"),
    Field("kashir_amount_atm", "double", label="صرافة / الصندوق"),
    Field("kashir_amount_delay", "double", label="آجل / الصندوق"),
    Field("kashir_note", length=250, label="ملاحظات"),
    Field(
        "kashir_total", "double", readable=False, writable=True, label="اجمالي الصندوق"
    ),
    Field("accountant_aprove", "boolean", default=False, label="استلام المحاسب"),
    Field("difference", "double", label="الفرق"),
    auth.signature,
)
# ===========================================================================================
# ===========================================================================================
#  جدول الانظمة
db.define_table("systems", Field("name", length=270, label="النظام"), format="%(name)s")
if db(db.systems.id > 0).isempty() == True:
    db.systems.insert(name="نظام الصيدلية")

# ===========================================================================================
#  جدول الشاشات
db.define_table(
    "screens",
    Field("systems", "reference systems", default=1, label="النظام"),
    Field("name", length=270, label="اسم الشاشة"),
    Field("screen_code", "integer", label="كود الشاشة"),
    format="%(screen_code)s - %(name)s",
)

# ===========================================================================================
#  جدول صلاحيات الشاشات
db.define_table(
    "screens_rules",
    Field("to_user", "reference auth_user", label="المستخدم"),
    Field("screens", "reference screens", label="الشاشة"),
    Field("can_log_in", "boolean", default=False, label="الدخول"),
    Field("can_add", "boolean", default=False, label="الاضافة"),
    Field("can_edit", "boolean", default=False, label="التعديل"),
    Field("can_delete", "boolean", default=False, label="الحذف"),
)
# ===========================================================================================
# ===========================================================================================
# ===========================================================================================
#  جدول معلومات الجهه
db.define_table(
    "important_info",
    Field(
        "name",
        length=370,
        label="الاسم ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "vat",
        length=100,
        label="الرقم الضريبي ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "tel",
        length=25,
        label="رقم الهاتف الارضي ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "mobile",
        length=25,
        label="رقم الجوال / الواتس آب ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "address",
        "text",
        default=" ",
        label="العنوان",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "msg1",
        "text",
        default=" ",
        label="رسالة للعميل",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "msg2",
        "text",
        default=" ",
        label="رسالة آخر الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "logo",
        "upload",
        autodelete=True,
        label="الشعار",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("change_count", "boolean", label="تعديل الكمية بالسعر"),
)
if db(db.important_info.id > 0).isempty() == True:
    db.important_info.insert(
        name="نظام ؟؟؟؟؟؟؟؟؟",
        vat="0",
        tel="0",
        mobile="05",
        address="العنوان",
        msg1="----",
        msg2="----",
    )
# ===========================================================================================
# ===========================================================================================


def can_access(*argument):
    if auth.user:
        if auth.user.first_name:

            def decorator(function):
                def wrapper(*args, **kwargs):
                    # print (argument[0])
                    screen_code = (
                        db(db.screens.screen_code == argument[0]).select().first()
                    )
                    if not screen_code:
                        return redirect(URL("default", "not_allow"))
                    acc = (
                        db(
                            (db.screens_rules.screens == screen_code.id)
                            & (db.screens_rules.to_user == auth.user.id)
                            & (db.screens_rules.can_log_in == True)
                        )
                        .select()
                        .first()
                    )
                    if acc:
                        result = function(*args, **kwargs)
                        return result
                    else:
                        return redirect(URL("default", "not_allow"))

                return wrapper

            return decorator
        else:
            return redirect(URL("default", "not_allow"))
    else:
        return redirect(URL("default", "not_allow"))


def screens_rules(sc):
    screen_code = db(db.screens.screen_code == sc).select().first
    acc = (
        db(
            (db.screens_rules.screens == screen_code)
            & (db.screens_rules.to_user == auth.user.id)
        )
        .select()
        .first()
    )
    return acc


# ===========================================================================================
#  جدول رسائل النظام
db.define_table(
    "public_msg",
    Field("msg_id", "integer", label="رقم الرسالة", unique=True),
    Field("msg_text", "text", label="الرسالة"),
    Field("msg_count", "integer"),
    Field("msg_max", "integer"),
)
# ===========================================================================================
#  جدول مصروفات الصندوق
db.define_table(
    "fund_movement",
    Field("process_date", "date"),
    Field("process_type", "integer"),
    Field("detill", "text"),
    Field("amount", "double"),
    Field("aprove", "boolean", default=False),
)
# ===========================================================================================
