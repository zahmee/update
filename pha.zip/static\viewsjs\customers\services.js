(function () {
  'use strict';
  var urls = window.CUSTOMER_SERVICES;
  if (!urls || !document.getElementById('customer-services')) return;
  function normalize(value) {
    return String(value == null ? '' : value).toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي')
      .replace(/[٠-٩]/g, function (digit) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(digit); })
      .replace(/[۰-۹]/g, function (digit) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit); });
  }
  new Vue({
    el: '#customer-services',
    data: {
      mode: 'directory', loaded: false, loading: false, loadingPreview: false, applying: false,
      error: '', receipt: null, records: [], summary: {counts:{}}, operations: [], permissions: {}, asOf: '',
      query: '', balance: '', type: '', activity: '', attention: false, sort: 'id', page: 1, pageSize: 25,
      selectedCustomerId: null, activeKey: '', preview: null, selectedIds: [], previewQuery: '', previewPage: 1
    },
    computed: {
      busy: function () { return this.loading || this.loadingPreview || this.applying; },
      selectedCustomer: function () {
        var id = this.selectedCustomerId;
        return this.records.find(function (record) { return record.id === id; });
      },
      filtered: function () {
        var vm = this, words = normalize(this.query).trim().split(/\s+/).filter(Boolean);
        var rows = this.records.filter(function (row) {
          var text = normalize([row.name, row.mobile, row.id].join(' '));
          return words.every(function (word) { return text.indexOf(word) !== -1; })
            && (!vm.balance || row.balance_state === vm.balance)
            && (!vm.type || (vm.type === 'unknown' ? row.cust_type !== 0 && row.cust_type !== 10 : row.cust_type === Number(vm.type)))
            && (!vm.activity || row.activity === vm.activity)
            && (!vm.attention || row.issues.length > 0);
        });
        return rows.sort(function (a, b) {
          if (vm.sort === 'balance') return b.account.balance - a.account.balance || a.id - b.id;
          if (vm.sort === 'name') return a.name.localeCompare(b.name, 'ar') || a.id - b.id;
          return a.id - b.id;
        });
      },
      pages: function () { return Math.max(1, Math.ceil(this.filtered.length / this.pageSize)); },
      pageRows: function () { return this.filtered.slice((this.page - 1) * this.pageSize, this.page * this.pageSize); },
      cleanupTools: function () { return this.operations.filter(function (tool) { return tool.kind === 'cleanup'; }); },
      reviewTools: function () { return this.operations.filter(function (tool) { return tool.kind === 'review'; }); },
      activeTool: function () {
        var key = this.activeKey;
        return this.operations.find(function (tool) { return tool.key === key; });
      },
      filteredPreview: function () {
        var words = normalize(this.previewQuery).trim().split(/\s+/).filter(Boolean);
        return ((this.preview && this.preview.records) || []).filter(function (row) {
          var text = normalize([row.name, row.mobile, row.id].join(' '));
          return words.every(function (word) { return text.indexOf(word) !== -1; });
        });
      },
      previewPages: function () { return Math.max(1, Math.ceil(this.filteredPreview.length / this.pageSize)); },
      previewRows: function () { return this.filteredPreview.slice((this.previewPage - 1) * this.pageSize, this.previewPage * this.pageSize); },
      allSelected: function () {
        var selected = new Set(this.selectedIds);
        return this.filteredPreview.length > 0 && this.filteredPreview.every(function (row) { return selected.has(row.id); });
      }
    },
    watch: {
      query: 'resetPage', balance: 'resetPage', type: 'resetPage', activity: 'resetPage', attention: 'resetPage', sort: 'resetPage',
      previewQuery: function () { this.previewPage = 1; }
    },
    created: function () { this.loadOverview(); },
    methods: {
      number: function (value) { return new Intl.NumberFormat('ar-SA').format(value || 0); },
      money: function (value) { return new Intl.NumberFormat('ar-SA', {minimumFractionDigits:2, maximumFractionDigits:2}).format(value || 0); },
      balanceLabel: function (state) { return {debit:'عليه مديونية', credit:'له رصيد', zero:'رصيد صفر'}[state] || 'غير محدد'; },
      activityLabel: function (state) { return {recent:'شراء خلال ٩٠ يومًا', inactive:'آخر شراء قبل أكثر من ٩٠ يومًا', never:'دون مشتريات مسجلة', unknown:'تاريخ الشراء يحتاج مراجعة'}[state]; },
      value: function (value) {
        if (value == null) return 'غير مسجل';
        if (Array.isArray(value)) return value.length ? value.map(function (item) { return '«' + item + '»'; }).join('\n') : 'قائمة فارغة';
        if (value === '') return 'فارغ';
        return String(value).trim() ? '«' + value + '»' : 'مسافات أو أسطر فارغة';
      },
      link: function (service, id) {
        if (service === 'manage') return urls.manage + '?customer_id=' + encodeURIComponent(id);
        return urls[service] + '/' + encodeURIComponent(id);
      },
      // Legacy rows hold "||" (an empty list encoding) in plain text fields; show it as not recorded,
      // exactly as the missing-data check counts it.
      shown: function (value, fallback) {
        var text = value == null ? '' : String(value);
        return text.replace(/\|/g, '').trim() ? text : fallback;
      },
      resetPage: function () { this.page = 1; },
      clearFilters: function () { this.query = ''; this.balance = ''; this.type = ''; this.activity = ''; this.attention = false; this.sort = 'id'; },
      chooseStat: function (filter) {
        if (this.busy) return;
        this.mode = 'directory'; this.clearFilters();
        if (filter === 'attention') this.attention = true;
        else if (filter) this.balance = filter;
        this.scrollTo('directory');
      },
      scrollTo: function (ref) {
        this.$nextTick(function () { if (this.$refs[ref]) this.$refs[ref].scrollIntoView({block:'start', behavior:'instant'}); });
      },
      movePage: function (page, preview) {
        if (this.busy || page < 1 || page > (preview ? this.previewPages : this.pages)) return;
        if (preview) this.previewPage = page; else this.page = page;
        this.scrollTo(preview ? 'results' : 'directory');
      },
      loadOverview: async function () {
        this.loading = true;
        try {
          var result = await Api.get(urls.overview);
          if (!Api.isOk(result)) { this.error = Api.getError(result); return false; }
          var data = Api.getData(result);
          this.records = data.records; this.summary = data.summary; this.operations = data.operations;
          this.permissions = data.permissions; this.asOf = data.as_of; this.loaded = true; this.page = 1;
          return true;
        } finally { this.loading = false; }
      },
      refresh: async function () {
        if (this.busy) return;
        this.error = ''; this.receipt = null; this.selectedIds = []; this.preview = null;
        if (await this.loadOverview() && this.activeKey) await this.openOperation(this.activeKey);
      },
      showCustomer: async function (id) {
        if (this.busy) return;
        if (!this.records.some(function (row) { return row.id === id; })) await this.loadOverview();
        this.selectedCustomerId = id;
        if (!this.selectedCustomer) { this.error = 'لم يعد هذا العميل موجودًا؛ أعد الفحص.'; return; }
        this.mode = 'directory'; this.scrollTo('profile');
      },
      inspectIssue: function (key) {
        if (this.busy) return;
        this.mode = 'maintenance'; this.openOperation(key);
      },
      openOperation: async function (key, keepReceipt) {
        if (this.busy) return;
        this.activeKey = key; this.preview = null; this.selectedIds = []; this.previewQuery = ''; this.previewPage = 1;
        this.error = ''; if (!keepReceipt) this.receipt = null;
        this.loadingPreview = true;
        try {
          var body = new FormData(); body.append('operation', key);
          var result = await Api.post(urls.preview, body);
          if (!Api.isOk(result)) { this.error = Api.getError(result); return; }
          this.preview = Api.getData(result);
          if (window.matchMedia('(max-width: 991px)').matches) this.scrollTo('results');
        } finally { this.loadingPreview = false; }
      },
      toggleFiltered: function () {
        if (this.busy || !this.permissions.edit || !this.preview || !this.preview.token) return;
        var selected = new Set(this.selectedIds), deselect = this.allSelected;
        this.filteredPreview.forEach(function (row) { if (deselect) selected.delete(row.id); else selected.add(row.id); });
        this.selectedIds = Array.from(selected);
      },
      applySelected: async function () {
        if (this.busy || !this.permissions.edit || !this.selectedIds.length || !this.preview || !this.preview.token) return;
        this.applying = true;
        var ids = this.selectedIds.slice(), key = this.activeKey, success = false;
        try {
          var confirm = await Swal.fire({title:'تطبيق التغييرات المحددة؟',
            text:this.activeTool.title + ' على ' + this.number(ids.length) + ' عميل وفق المعاينة.',
            icon:'question', showCancelButton:true, confirmButtonText:'نعم، تطبيق', cancelButtonText:'العودة للمعاينة',
            confirmButtonColor:'#12514c', focusCancel:true});
          if (!confirm.isConfirmed) return;
          this.error = ''; this.receipt = null;
          var body = new FormData(); body.append('token', this.preview.token); body.append('ids', JSON.stringify(ids));
          var result = await Api.post(urls.apply, body);
          this.preview.token = null;
          if (!Api.isOk(result)) { this.error = Api.getError(result); this.scrollTo('messages'); return; }
          this.receipt = Api.getData(result); this.selectedIds = []; success = true;
        } finally { this.applying = false; }
        if (success && await this.loadOverview()) await this.openOperation(key, true);
      }
    }
  });
})();
