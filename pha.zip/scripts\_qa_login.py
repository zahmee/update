# سكربت مؤقت لإنشاء مستخدم اختبار في مجموعة admin (للاختبار فقط)
email = "qa_tester@local.test"
pw = "Qa!23456"
u = db(db.auth_user.email == email).select().first()
hashed = db.auth_user.password.validate(pw)[0]
if u:
    u.update_record(password=hashed, first_name="QA", last_name="Tester")
    uid = u.id
else:
    uid = db.auth_user.insert(first_name="QA", last_name="Tester", email=email, password=hashed)
admin_group = db(db.auth_group.role == "admin").select().first()
exists = db((db.auth_membership.user_id == uid) & (db.auth_membership.group_id == admin_group.id)).select().first()
if not exists:
    db.auth_membership.insert(user_id=uid, group_id=admin_group.id)
db.commit()
print("QA_USER_OK", uid, email, pw)
