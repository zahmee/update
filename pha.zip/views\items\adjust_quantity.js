var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        row_id: row_id,
        data: [],
        show_spinner: true,
        sum_row: 0,
        save_clicked: false,
    },
    created: function() {
        this.loadRows();
    },
    computed: {
        total: function() {
            var total = 0;
            this.data.forEach(function(element) {
                total += this.numberValue(element.items_count);
            }.bind(this));
            return this.round2(total);
        },
        difference: function() {
            return this.round2(this.total - this.sum_row);
        },
        isBalanced: function() {
            return Math.abs(this.difference) < 0.01;
        },
        hasNegative: function() {
            return this.data.some(function(element) {
                return this.numberValue(element.items_count) < 0;
            }.bind(this));
        },
        statusIcon: function() {
            if (this.hasNegative) return 'fa-exclamation-triangle';
            return this.isBalanced ? 'fa-check-circle' : 'fa-balance-scale';
        },
        statusText: function() {
            if (this.hasNegative) return 'يوجد عدد بالسالب، صحح القيم قبل الحفظ.';
            if (this.isBalanced) return 'الإجمالي مطابق ويمكن حفظ التعديلات.';
            return 'الإجمالي غير مطابق، راجع توزيع الكميات بين الدفعات.';
        },
        savePanelTitle: function() {
            if (this.hasNegative) return 'الحفظ متوقف بسبب قيمة سالبة';
            return this.isBalanced ? 'جاهز للحفظ' : 'يحتاج مراجعة قبل الحفظ';
        },
        savePanelText: function() {
            if (this.hasNegative) return 'كل الكميات يجب أن تكون صفرًا أو أكثر.';
            if (this.isBalanced) return 'التوزيع الجديد يحافظ على نفس إجمالي كمية الصنف.';
            return 'يمكن للمدير فقط الحفظ مع وجود فرق في الإجمالي.';
        },
    },
    methods: {
        loadRows: function() {
            this.$http.get(this.URL + '/../../items_qry/get_last_10/' + this.row_id).then(function(response) {
                if (response.body !== '') {
                    this.data = (response.body || []).map(function(row) {
                        row.items_count = this.round2(this.numberValue(row.items_count));
                        return row;
                    }.bind(this));

                    this.sum_row = this.round2(this.data.reduce(function(sum, row) {
                        return sum + this.numberValue(row.items_count);
                    }.bind(this), 0));
                }
            }.bind(this)).finally(function() {
                this.show_spinner = false;
            }.bind(this));
        },
        numberValue: function(value) {
            var num = parseFloat(value);
            return isNaN(num) ? 0 : num;
        },
        round2: function(value) {
            return Math.round((this.numberValue(value) + Number.EPSILON) * 100) / 100;
        },
        formatNumber: function(value) {
            return this.numberValue(value).toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },
        adjustRow: function(index, delta) {
            var row = this.data[index];
            if (!row) return;
            var next = this.round2(this.numberValue(row.items_count) + delta);
            this.$set(row, 'items_count', Math.max(0, next));
        },
        zeroRow: function(index) {
            var row = this.data[index];
            if (!row) return;
            this.$set(row, 'items_count', 0);
        },
        SaveAll: function(forceSave) {
            if (this.hasNegative) {
                Swal.fire({
                    icon: 'error',
                    title: 'لا يمكن الحفظ',
                    text: 'يجب أن تكون جميع الأعداد بالموجب أو صفر.'
                });
                return;
            }

            if (!forceSave && !this.isBalanced) {
                Swal.fire({
                    icon: 'warning',
                    title: 'الإجمالي غير مطابق',
                    text: 'راجع توزيع الكمية حتى يصبح الفرق صفرًا.'
                });
                return;
            }

            this.save_clicked = true;

            var alldata = {};
            alldata.itm = this.data;

            this.$http.post(
                this.URL + '/../../items_qry/save_adjust_quantity/',
                JSON.stringify(alldata),
                { emulateJSON: true }
            ).then(function(response) {
                if (response.body !== '') {
                    if (response.body.mess === 0) {
                        Swal.fire({
                            icon: 'success',
                            title: 'تم الحفظ بشكل صحيح',
                            timer: 1200,
                            showConfirmButton: false
                        }).then(function() {
                            window.location.href = this.URL + '/../adjust_quantity/' + this.row_id;
                        }.bind(this));
                    } else {
                        this.save_clicked = false;
                        Swal.fire('حصل خطأ في عملية الحفظ', '', 'error');
                    }
                }
            }.bind(this)).catch(function() {
                this.save_clicked = false;
                Swal.fire('حصل خطأ في الاتصال', '', 'error');
            }.bind(this));
        },
    },
});
