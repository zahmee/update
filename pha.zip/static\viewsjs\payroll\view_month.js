// العنوان والشهر من الخادم (PM_CONFIG)، لا من location.href، فيبقى صحيحاً مع ?payroll_id=<id>
var API_BASE = PM_CONFIG.base;

function postForm(url, fields) {
    var body = new FormData();
    Object.keys(fields || {}).forEach(function (k) {
        body.append(k, fields[k] === null || fields[k] === undefined ? '' : fields[k]);
    });
    return fetch(url, { method: 'POST', body: body }).then(function (r) { return r.json(); });
}

function toast(text) {
    Swal.fire({ toast: true, position: 'top', icon: 'success', title: text, timer: 2500, showConfirmButton: false });
}

var EMPTY_TOTALS = { count: 0, basic_salary: 0, total_allowances: 0, total_deductions: 0, net_salary: 0 };

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        totals: EMPTY_TOTALS,
        period: null,
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            flag: '',
            SortBy: 'emp_name',
            sortAsc: true,
        },
        fixed_month: PM_CONFIG.month,
        fixed_year: PM_CONFIG.year,
        salariesUrl: PM_CONFIG.salaries,
        data_row_count: 0,
        listSeq: 0,
        searchTimer: null,
        loading: false,
        adding_all: false,
        employees_list: [],
        ad_types: [],
        selectedRow: -1,
        // بطاقة المسير
        card: null,
        cardId: null,
        cardLoading: false,
        cardError: '',
        cardSeq: 0,
        cardTrigger: null,
        basicEdit: { active: false, value: '', saving: false },
        itemEdit: null,
        busy: false,
        pendingCard: null,
        // إضافة موظف
        new_form: { employee: '' },
        saving: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        locked: function () {
            return !!(this.period && this.period.is_approved);
        },
        pageTotals: function () {
            var keys = ['basic_salary', 'total_allowances', 'total_deductions', 'net_salary', 'advance_deduction', 'advance_remaining'];
            var t = {};
            keys.forEach(function (k) { t[k] = 0; });
            this.data.forEach(function (r) {
                keys.forEach(function (k) { t[k] += parseFloat(r[k]) || 0; });
            });
            return t;
        },
        cardTitle: function () {
            if (this.card) return this.card.payroll.emp_name;
            var row = this.data.find(function (r) { return r.id === this.cardId; }.bind(this));
            return row ? row.emp_name : 'بطاقة المسير';
        },
        cardLocked: function () {
            return !!(this.card && this.card.payroll.approved);
        },
        cardBusy: function () {
            return this.cardLoading || this.busy || this.basicEdit.saving || !!(this.itemEdit && this.itemEdit.saving);
        },
        panels: function () {
            var items = this.card ? this.card.items : [];
            var p = this.card ? this.card.payroll : {};
            return [
                { key: 'allow', type: 'بدل', title: 'البدلات', single: 'بدل', icon: 'fad fa-plus-circle',
                  items: items.filter(function (i) { return i.ad_type === 'بدل'; }), total: p.total_allowances || 0 },
                { key: 'deduct', type: 'خصم', title: 'الخصومات', single: 'خصم', icon: 'fad fa-minus-circle',
                  items: items.filter(function (i) { return i.ad_type === 'خصم'; }), total: p.total_deductions || 0 },
            ];
        },
    },
    created: function () {
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var d = Api.getData(data) || {};
                this.employees_list = d.employees || [];
                this.ad_types = d.ad_types || [];
            }.bind(this));
        this.reload().then(function () {
            // رابط مباشر: ?payroll_id=<رقم المسير> يفتح بطاقته
            var id = parseInt(new URLSearchParams(window.location.search).get('payroll_id'), 10);
            if (id > 0) this.openCard(id);
        }.bind(this));
    },
    mounted: function () {
        document.getElementById('payrollCardModal').addEventListener('hidden.bs.modal', this.closeCard);
        document.getElementById('payrollModal').addEventListener('hidden.bs.modal', function () {
            var id = this.pendingCard;
            this.pendingCard = null;
            if (id) this.openCard(id);
        }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                flag: this.getData.flag,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                emp_filter: '0',
                month_filter: this.fixed_month,
                year_filter: this.fixed_year,
            };
            var url = new URL(API_BASE + 'get_payrolls', window.location.origin);
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, { headers: { 'Accept': 'application/json' } }).then(function (r) { return r.json(); });
        },
        reload: function (silent) {
            var seq = ++this.listSeq;
            if (!silent) this.loading = true;
            return this.fetchData().then(function (data) {
                if (seq !== this.listSeq) return;  // ردّ بحث أقدم وصل بعد الأحدث
                this.data = Api.getData(data) || [];
                this.data_row_count = data.count || 0;
                this.totals = data.totals || EMPTY_TOTALS;
                this.period = data.period || null;
                this.selectedRow = this.cardId ? this.rowIndexOf(this.cardId) : -1;
            }.bind(this)).catch(function () {
                if (seq === this.listSeq) Swal.fire('خطأ', 'تعذر تحميل المسير', 'error');
            }.bind(this)).finally(function () {
                if (seq === this.listSeq) this.loading = false;
            }.bind(this));
        },
        onChange: function () {
            this.getData.page = 0;
            this.reload();
        },
        debouncedSearch: function () {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(this.onChange, 300);
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.reload();
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowIndexOf: function (id) {
            return this.data.findIndex(function (r) { return r.id === id; });
        },
        inMonth: function (employeeId) {
            return !!(this.period && (this.period.in_month || []).indexOf(employeeId) > -1);
        },
        rowClass: function (index, row) {
            if (index === this.selectedRow) return 'pm-row-selected';
            return row.level ? 'pm-row-' + row.level : '';
        },
        // سبب لون الصف في التلميح
        rowReason: function (row) {
            var r = [];
            if (row.f_negative) r.push('الصافي سالب');
            if (row.f_excess) r.push('«خصم سلفة» أكبر من المتبقي على السلف');
            if (row.f_structure) r.push(row.structure_id ? 'الأساسي يختلف عن هيكل الراتب الحالي' : 'لا يوجد له راتب في شاشة الرواتب');
            if (row.f_no_installment) r.push('عليه سلف بلا «خصم سلفة» في المسير');
            return r.join(' · ');
        },
        money: function (n) {
            return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        showModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show();
        },
        hideModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).hide();
        },
        // رسالة داخل النافذة المفتوحة حتى لا تسحب مصيدة تركيزها أزرار الرسالة
        alertIn: function (modalId, text) {
            return Swal.fire({ title: 'تنبيه', text: text, icon: 'error', target: document.getElementById(modalId) });
        },
        cardAlert: function (text) {
            return this.alertIn('payrollCardModal', text);
        },

        // ====== بطاقة المسير ======
        rowSelect: function (index, row, event) {
            // انتظر حتى تنتهي النافذة السابقة وخلفيتها من الإغلاق
            if (document.body.classList.contains('modal-open')) return;
            this.cardTrigger = event.currentTarget.querySelector('.pm-name-button');
            this.openCard(row.id);
        },
        openCard: function (id) {
            this.cardId = id;
            this.card = null;
            this.itemEdit = null;
            this.cancelBasic();
            this.selectedRow = this.rowIndexOf(id);
            this.loadCard(id);
            this.$nextTick(function () { this.showModal('payrollCardModal'); });
        },
        loadCard: function (id) {
            var seq = ++this.cardSeq;
            this.cardLoading = true;
            this.cardError = '';
            return fetch(API_BASE + 'get_payroll_card/' + id, { headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (seq !== this.cardSeq) return;  // استجابة لبطاقة أُغلقت أو استُبدلت
                    if (Api.isOk(data)) {
                        this.card = Api.getData(data);
                    } else {
                        this.card = null;
                        this.cardError = Api.getError(data) || 'تعذر تحميل بطاقة المسير';
                    }
                }.bind(this))
                .catch(function () {
                    if (seq === this.cardSeq) this.cardError = 'تعذر الاتصال بالخادم';
                }.bind(this))
                .finally(function () {
                    if (seq === this.cardSeq) this.cardLoading = false;
                }.bind(this));
        },
        closeCard: function () {
            this.cardSeq++;
            this.card = null;
            this.cardId = null;
            this.cardLoading = false;
            this.cardError = '';
            this.itemEdit = null;
            this.cancelBasic();
            this.selectedRow = -1;
            if (this.cardTrigger && document.contains(this.cardTrigger)) this.cardTrigger.focus();
            this.cardTrigger = null;
        },
        // بعد أي حفظ: البطاقة إن بقيت مفتوحة، والجدول ومجاميع الشهر دائماً
        afterChange: function (payrollId) {
            if (this.cardId === payrollId) this.loadCard(payrollId);
            this.reload(true);
        },
        focusInCard: function (selector) {
            this.$nextTick(function () {
                var el = document.querySelector('#payrollCardModal ' + selector);
                if (el) el.focus();
            });
        },

        // ── الأساسي في هذا المسير ──
        startBasicEdit: function () {
            if (!this.card || this.cardLocked) return;
            this.itemEdit = null;
            this.basicEdit = { active: true, value: this.card.payroll.basic_salary, saving: false };
            this.focusInCard('.pm-basic-form input');
        },
        cancelBasic: function () {
            this.basicEdit = { active: false, value: '', saving: false };
        },
        saveBasic: function () {
            var edit = this.basicEdit;
            if (edit.saving || !this.card) return;
            var value = parseFloat(edit.value);
            if (isNaN(value) || value < 0) { this.cardAlert('أدخل راتباً أساسياً صحيحاً'); return; }
            var id = this.card.payroll.id;
            edit.saving = true;
            postForm(API_BASE + 'update_payroll', { id: id, basic_salary: value }).then(function (data) {
                if (Api.isOk(data)) {
                    toast('تم حفظ الأساسي لهذا المسير');
                    if (this.basicEdit === edit) this.cancelBasic();
                    this.afterChange(id);
                } else {
                    this.cardAlert(Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحفظ الأساسي');
            }.bind(this)).finally(function () { edit.saving = false; });
        },

        // ── البدلات والخصومات ──
        typeOptions: function (type) {
            return this.ad_types.filter(function (a) { return a.ad_type === type; });
        },
        panelRows: function (p) {
            var rows = p.items.slice();
            if (this.itemEdit && !this.itemEdit.id && this.itemEdit.ad_type === p.type) rows.push({ id: 0 });
            return rows;
        },
        isEditing: function (it) {
            return !!this.itemEdit && this.itemEdit.id === it.id;
        },
        startItemAdd: function (type) {
            if (this.cardLocked) return;
            this.cancelBasic();
            this.itemEdit = { id: 0, ad_type: type, allowance_deduction: '', amount: '', notes: '', saving: false };
            this.focusInCard('.pm-item-select');
        },
        startItemEdit: function (it) {
            if (this.cardLocked) return;
            this.cancelBasic();
            this.itemEdit = {
                id: it.id,
                ad_type: it.ad_type,
                allowance_deduction: it.allowance_deduction,
                amount: it.amount,
                notes: it.notes || '',
                saving: false
            };
            this.focusInCard('.pm-amount-input');
        },
        cancelItem: function () {
            this.itemEdit = null;
        },
        saveItem: function () {
            var edit = this.itemEdit;
            if (!edit || edit.saving || !this.card) return;
            if (!edit.allowance_deduction) { this.cardAlert('اختر البند'); return; }
            var amount = parseFloat(edit.amount);
            if (!(amount > 0)) { this.cardAlert('أدخل مبلغاً أكبر من صفر'); return; }
            var payrollId = this.card.payroll.id;
            var fields = {
                payroll_id: payrollId,
                allowance_deduction: edit.allowance_deduction,
                amount: amount,
                notes: (edit.notes || '').trim()
            };
            if (edit.id) fields.id = edit.id;
            edit.saving = true;
            postForm(API_BASE + (edit.id ? 'update_detail' : 'add_detail'), fields).then(function (data) {
                if (Api.isOk(data)) {
                    toast(edit.id ? 'تم تعديل البند' : 'تمت إضافة البند');
                    if (this.itemEdit === edit) this.itemEdit = null;
                    this.afterChange(payrollId);
                } else {
                    this.cardAlert(Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحفظ البند');
            }.bind(this)).finally(function () { edit.saving = false; });
        },
        deleteItem: function (it) {
            var payrollId = this.card && this.card.payroll.id;
            if (!payrollId) return;
            Swal.fire({
                title: 'حذف ' + it.ad_name,
                text: 'حذف ' + (it.ad_type === 'بدل' ? 'البدل' : 'الخصم') + ' بمبلغ ' + this.money(it.amount)
                    + ' من مسير هذا الشهر؟ لا يتغير هيكل راتبه.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('payrollCardModal')
            }).then(function (result) {
                if (!result.isConfirmed) return;
                if (this.itemEdit && this.itemEdit.id === it.id) this.itemEdit = null;
                this.busy = true;
                postForm(API_BASE + 'delete_detail/' + it.id).then(function (data) {
                    if (Api.isOk(data)) {
                        toast('تم حذف البند');
                        this.afterChange(payrollId);
                    } else {
                        this.cardAlert(Api.getError(data));
                    }
                }.bind(this)).catch(function () {
                    this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحذف البند');
                }.bind(this)).finally(function () { this.busy = false; }.bind(this));
            }.bind(this));
        },

        // ── حذف الموظف من المسير ──
        delete_payroll: function () {
            var p = this.card && this.card.payroll;
            if (!p) return;
            Swal.fire({
                title: 'حذف ' + p.emp_name + ' من المسير',
                text: 'يُحذف مسيره لهذا الشهر وبنوده (' + this.card.items.length + '). لا يتغير هيكل راتبه.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('payrollCardModal')
            }).then(function (result) {
                if (!result.isConfirmed) return;
                this.busy = true;
                postForm(API_BASE + 'delete_payroll/' + p.id).then(function (data) {
                    if (Api.isOk(data)) {
                        toast('حُذف من المسير');
                        this.hideModal('payrollCardModal');
                        this.reload(true);
                    } else {
                        this.cardAlert(Api.getError(data));
                    }
                }.bind(this)).catch(function () {
                    this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحذف المسير');
                }.bind(this)).finally(function () { this.busy = false; }.bind(this));
            }.bind(this));
        },

        // ====== إضافة موظف / الجميع ======
        new_row_click: function () {
            this.new_form = { employee: '' };
            this.showModal('payrollModal');
        },
        save_new_payroll: function () {
            if (this.saving) return;
            var emp = parseInt(this.new_form.employee, 10);
            if (!emp) { this.alertIn('payrollModal', 'يجب اختيار الموظف'); return; }
            this.saving = true;
            postForm(API_BASE + 'new_payroll', { employee: emp, pay_month: this.fixed_month, pay_year: this.fixed_year })
                .then(function (data) {
                    if (Api.isOk(data)) {
                        toast('أُضيف إلى المسير');
                        this.pendingCard = (Api.getData(data) || {}).id || null;  // تُفتح بطاقته بعد إغلاق النافذة
                        this.hideModal('payrollModal');
                        this.reload(true);
                    } else {
                        this.alertIn('payrollModal', Api.getError(data));
                    }
                }.bind(this)).catch(function () {
                    this.alertIn('payrollModal', 'تعذر الاتصال بالخادم؛ لم يُضف الموظف');
                }.bind(this)).finally(function () { this.saving = false; }.bind(this));
        },
        add_all_employees: function () {
            if (this.adding_all) return;
            var missing = this.period ? this.period.missing : 0;
            Swal.fire({
                title: 'إضافة جميع الموظفين',
                text: missing
                    ? 'يُضاف ' + missing + ' موظف غير مضاف مع بدلاتهم وخصوماتهم من شاشة الرواتب.'
                    : 'كل الموظفين مضافون إلى مسير هذا الشهر.',
                icon: missing ? 'question' : 'info',
                showCancelButton: !!missing,
                confirmButtonText: missing ? 'نعم، أضف الجميع' : 'حسناً',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (!result.isConfirmed || !missing) return;
                this.adding_all = true;
                postForm(API_BASE + 'add_all_employees', { pay_month: this.fixed_month, pay_year: this.fixed_year })
                    .then(function (data) {
                        if (Api.isOk(data)) {
                            var res = Api.getData(data) || {};
                            toast('أُضيف ' + (res.added || 0) + ' موظف' + (res.skipped ? '، وتُخطّي ' + res.skipped + ' مضاف مسبقاً' : ''));
                            this.reload(true);
                        } else {
                            Api.showError(data);
                        }
                    }.bind(this)).catch(function () {
                        Swal.fire('خطأ', 'تعذر الاتصال بالخادم', 'error');
                    }).finally(function () { this.adding_all = false; }.bind(this));
            }.bind(this));
        },
    }
});
