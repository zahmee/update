# -*- coding: utf-8 -*-
"""
سكريبت تدقيق شامل لصلاحيات الشاشات والأزرار
"""
import os
import re
from collections import defaultdict

controllers_dir = 'controllers'
views_dir = 'views'

# ============================================================
# 1. استخراج كل دوال ال controllers مع الديكوريتors
# ============================================================
controller_funcs = defaultdict(list)

for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py') or fname == '__init__.py':
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    current_decorators = []
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('@'):
            current_decorators.append(stripped)
        elif stripped.startswith('def '):
            func_match = re.match(r'def\s+(\w+)\s*\(', stripped)
            if func_match:
                func_name = func_match.group(1)
                controller_funcs[controller].append({
                    'func': func_name,
                    'decorators': current_decorators[:],
                    'line': i+1
                })
            current_decorators = []

# ============================================================
# 2. استخراج أكواد الشاشات من can_access
# ============================================================
can_access_codes = defaultdict(list)
for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py'):
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    for match in re.finditer(r'@can_access\((\d+)\)', content):
        code = int(match.group(1))
        can_access_codes[controller].append(code)

# ============================================================
# 3. استخراج أكواد الشاشات المسجلة في setup.py
# ============================================================
setup_screens = {}
with open(os.path.join(controllers_dir, 'setup.py'), 'r', encoding='utf-8') as f:
    setup_content = f.read()

for match in re.finditer(r'"screen_code":\s*(\d+)', setup_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)".*?"screen_code":\s*' + str(code), setup_content, re.DOTALL)
    if not name_match:
        name_match = re.search(r'"screen_code":\s*' + str(code) + r'.*?"name":\s*"([^"]+)"', setup_content, re.DOTALL)
    name = name_match.group(1) if name_match else "unknown"
    setup_screens[code] = name

# ============================================================
# 4. استخراج أكواد الشاشات من add_missing_screens.py
# ============================================================
add_screens = {}
with open('scripts/add_missing_screens.py', 'r', encoding='utf-8') as f:
    add_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', add_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)".*?"screen_code":\s*' + str(code), add_content, re.DOTALL)
    if not name_match:
        name_match = re.search(r'"screen_code":\s*' + str(code) + r'.*?"name":\s*"([^"]+)"', add_content, re.DOTALL)
    name = name_match.group(1) if name_match else "unknown"
    add_screens[code] = name

# ============================================================
# 5. استخراج الروابط من navbar (layout.html)
# ============================================================
navbar_links = []
with open(os.path.join(views_dir, 'layout.html'), 'r', encoding='utf-8') as f:
    layout_content = f.read()

for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", layout_content):
    ctrl, func = match.groups()
    navbar_links.append((ctrl, func))

# ============================================================
# 6. استخراج استخدام screens_rules من Views
# ============================================================
view_conditions = defaultdict(list)
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        for match in re.finditer(r'screens_rules\((\d+)\)', content):
            view_conditions[path.replace('views/', '')].append(int(match.group(1)))

# ============================================================
# 7. استخراج الأزرار المشروطة في Views (can_add, can_edit, can_delete)
# ============================================================
view_buttons = defaultdict(list)
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        for cond in ['can_add', 'can_edit', 'can_delete']:
            if cond in content:
                view_buttons[path.replace('views/', '')].append(cond)

# ============================================================
# كتابة التقرير
# ============================================================
report_lines = []
report_lines.append("=" * 80)
report_lines.append("تقرير تدقيق الصلاحيات - نظام الصدارة")
report_lines.append("=" * 80)

report_lines.append("\n【1】الشاشات المسجلة في setup.py:")
for code in sorted(setup_screens):
    report_lines.append(f"  {code}: {setup_screens[code]}")

report_lines.append("\n【2】الشاشات الإضافية في add_missing_screens.py:")
for code in sorted(add_screens):
    report_lines.append(f"  {code}: {add_screens[code]}")

report_lines.append("\n【3】أكواد can_access المستخدمة في Controllers:")
all_codes = set()
for ctrl in sorted(can_access_codes):
    codes = sorted(set(can_access_codes[ctrl]))
    all_codes.update(codes)
    report_lines.append(f"  {ctrl}: {codes}")

report_lines.append("\n【4】أكواد can_access غير مسجلة في setup.py أو add_missing_screens:")
registered = set(setup_screens.keys()) | set(add_screens.keys())
missing_codes = []
for code in sorted(all_codes):
    if code not in registered:
        missing_codes.append(code)
        report_lines.append(f"  !! {code} - غير مسجل في أي ملف تعريف شاشات!")
if not missing_codes:
    report_lines.append("  (جميع الأكواد مسجلة)")

report_lines.append("\n【5】دوال Controllers بدون حماية can_access (تستخدم auth.requires_login فقط أو لا شيء):")
unprotected = []
for ctrl in sorted(controller_funcs):
    for f in controller_funcs[ctrl]:
        decs = ' '.join(f['decorators'])
        has_can_access = '@can_access' in decs
        has_auth = '@auth.requires' in decs
        if not has_can_access:
            unprotected.append((ctrl, f['func'], f['line'], decs if decs else '(no decorators)'))
            report_lines.append(f"  !! {ctrl}.{f['func']}() @ line {f['line']} -> {decs if decs else '(no decorators)'}")

report_lines.append("\n【6】روابط navbar وهل الدالة المستهدفة محمية بـ can_access:")
for ctrl, func in navbar_links:
    protected = False
    code = None
    if ctrl in controller_funcs:
        for f in controller_funcs[ctrl]:
            if f['func'] == func:
                for d in f['decorators']:
                    m = re.search(r'@can_access\((\d+)\)', d)
                    if m:
                        protected = True
                        code = int(m.group(1))
                break
    status = "OK" if protected else "XX"
    if protected:
        report_lines.append(f"  {status} {ctrl}/{func} -> can_access({code})")
    else:
        report_lines.append(f"  {status} {ctrl}/{func} -> غير محمية بـ can_access")

report_lines.append("\n【7】الأزرار المشروطة في Views:")
for view in sorted(view_buttons):
    report_lines.append(f"  {view}: {view_buttons[view]}")

report_lines.append("\n【8】استخدام screens_rules في Views:")
for view in sorted(view_conditions):
    report_lines.append(f"  {view}: {view_conditions[view]}")

report_lines.append("\n" + "=" * 80)
report_lines.append("نهاية التقرير")
report_lines.append("=" * 80)

# كتابة التقرير
with open('scripts/audit_permissions_report.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(report_lines))

print("Done. Report written to scripts/audit_permissions_report.txt")
