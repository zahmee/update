# -*- coding: utf-8 -*-
import sys
sys.stdout = open('applications/asbab5/scripts/test_login_out.txt', 'w', encoding='utf-8')
sys.stderr = sys.stdout
try:
    # محاولة تنفيذ default/user/login
    from gluon.tools import Auth
    c = controller = locals()['controller']
    f = function = locals()['function']
    # نحاكي طلب GET لـ default/user/login
    request.controller = 'default'
    request.function = 'user'
    request.args = ['login']
    request.vars = {}
    request.env.request_method = 'GET'
    
    # import controller
    import applications.asbab5.controllers.default as ctrl
    result = ctrl.user()
    print("Result:", result)
except Exception as e:
    import traceback
    print("Error:", type(e).__name__, str(e))
    traceback.print_exc()
sys.stdout.close()
