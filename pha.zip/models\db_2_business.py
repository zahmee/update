# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الموردين والأصناف والعملاء والفواتير (Business Tables)
# ===========================================================================================

# ------------------------------------------------------------------------------------
#  جدول الموردين
db.define_table(
    "suppliers",
    Field(
        "name",
        length=260,
        label="اسم المورد",
        required=True,
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("specialization", "list:string", label="مجال اختصاص المورد"),
    Field("administrator_name", "list:string", label="اسم المسؤول"),
    Field("total_amount", "double", default=0, label="المبلغ المستحق له"),
    Field("days_to_pay", "integer", label="عدد الايام لسداد"),
    Field("postpaid_discount", "double", label="خصم السداد آجل"),
    Field("discount_cash_payment", "double", label="خصم السداد كاش"),
    Field("payment_discount_for_year", "double", label="خصم السداد لعام"),
    Field("tel", "text", label="هواتف المورد"),
    Field("address", "text", label="العنوان"),
    Field("bank_account", "text", label="رقم الحساب في البنك"),
    Field("stoped", "boolean", default=False, label="موقف"),
    Field("note", "text", label="ملاحظات"),
    Field(
        "total_amount_postpaid",
        "double",
        label="اجمالي آجل",
        readable=False,
        writable=False,
    ),
    Field(
        "total_amount_cash",
        "double",
        label="اجمالي كاش",
        readable=False,
        writable=False,
    ),
    Field(
        "total_amount_payment",
        "double",
        label="اجمالي مسدد",
        readable=False,
        writable=False,
    ),
    Field("net_amount_req", "double", label="المطلوب", readable=False, writable=False),
    auth.signature,
    format="%(id)s - %(name)s",
)
db.suppliers.id.label = "م"

db.define_table(
    "suppliers_files",
    Field(
        "suppliers_id",
        "reference suppliers",
        default=request.args(0),
        label="المورد",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.suppliers_files.id.label = "م"
# =====================================================================================


# -----------------------------------------------------------------------------------------
#  فواتير التوريد
db.define_table(
    "suppliers_bills",
    Field("supplier", "reference suppliers", label="المورد"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("invoce_type", "reference key_invoce_type", label="نوع الفاتورة"),
    Field(
        "bill_no",
        length=15,
        label="رقم الفاتورة من المورد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_date",
        "date",
        label="تاريخ الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_total",
        "double",
        label="اجمالي المبلغ مع الضريبة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_net_amount",
        "double",
        label="صافي المبلغ بدون ضريبة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_vat",
        "double",
        label="صافي الضريبة من المورد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "bill_confirmation",
        "boolean",
        default=False,
        readable=False,
        writable=False,
        label="تم تأكيد الفاتورة",
    ),
    Field(
        "to_user",
        "reference auth_user",
        label="مسندة لـ",
        readable=False,
        writable=False,
    ),
    Field(
        "bill_by_date",
        "date",
        readable=False,
        writable=False,
        label="تاريخ سداد الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "total_from_item",
        "double",
        label="مبلغ الفواتير",
        readable=False,
        writable=False,
    ),
    Field(
        "return_confirmation",
        "boolean",
        default=False,
        label="تاكيد المرتجع",
        readable=False,
        writable=False,
    ),
    Field("note", "list:string", label="ملاحظات"),
    Field("bill_selling", "double", label="البيع", default=0.0, writable=False),
    Field(
        "bill_profit_ratio", "double", label="نسبة الربح", default=0.0, writable=False
    ),
    Field("bill_profit", "double", label="مبلغ الربح", default=0.0, writable=False),
    auth.signature,
    format="%(name)s",
)
db.suppliers_bills.id.label = "م"
#
db.define_table(
    "suppliers_bills_files",
    Field(
        "suppliers_bills_id",
        "reference suppliers_bills",
        default=request.args(0),
        label="فواتير المورد",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.suppliers_bills.id.label = "م"
# ====================================================================================


# ---------------------------------------------------------------------------------------------------------------
#  فواتير سداد الموردين
db.define_table(
    "suppliers_bills_pay",
    Field("supplier", "reference suppliers", label="المورد"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("payment_type", "reference key_payment_type", label="نوع السداد"),
    Field(
        "pay_total",
        "double",
        label="المبلغ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "pay_date",
        "date",
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.suppliers_bills_pay.id.label = "م"

# ---------------------------------------------------------------------------------------------------------------
#  ارصدة الموردين السابقة  - الارصدة الافتتاحية
db.define_table(
    "suppliers_opening_balance",
    Field("year_balance", "integer", label="السنة"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field(
        "account",
        "double",
        label="الرصيد السابق",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.suppliers_opening_balance.id.label = "م"

# ملفات فواتير سداد الموردين
db.define_table(
    "suppliers_bills_pay_files",
    Field(
        "suppliers_bills_pay_id",
        "reference suppliers_bills_pay",
        default=request.args(0),
        label="سدادات الموردين",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.suppliers_bills.id.label = "م"

# مطابقة الارصدة
db.define_table(
    "suppliers_balance_reconciliation",
    Field("supplier", "reference suppliers", label="المورد"),
    Field(
        "balance_date",
        "date",
        label="تاريخ المطابقة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "balance",
        "integer",
        label="مطابق",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("balance_def", "double", label="الفرق", default=0),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.suppliers_balance_reconciliation.id.label = "م"

# ==================================================================================================================

# جدول الأصناف الأساسي
db.define_table(
    "items_main",
    Field(
        "item_id", length=20, label="رقم الصنف", required=IS_NOT_EMPTY(), unique=True
    ),
    Field("item_reg", length=20, label="رقم التسجيل"),
    Field(
        "name",
        length=460,
        label="الاسم التجاري",
        required=True,
        requires=[IS_NOT_EMPTY(), IS_LOWER()],
    ),
    Field(
        "generic_name", length=460, readable=False, writable=False, label="الاسم العلمي"
    ),
    Field(
        "item_unit",
        "reference key_unit",
        label="الوحدة",
    ),
    Field(
        "item_type",
        "reference key_type",
        label="التصنيف",
    ),
    Field("vat", "double", readable=False, writable=False, label="VAT"),
    Field("item_group", "integer", label="المجموعة"),
    Field("public_price", "double", label="السعر للجمهور"),
    Field("buy_price", "double", readable=False, writable=False, label="سعر الشراء"),
    Field(
        "report_year",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="سنة التقرير",
    ),
    Field(
        "report_month",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="شهر التقرير",
    ),
    Field(
        "quantity_reorder",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="كمية إعادة الطلب",
    ),
    Field(
        "quantity_order",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="كمية الطلب",
    ),
    Field(
        "existing",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="الموجود",
    ),
    Field(
        "required",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="المطلوب",
    ),
    Field(
        "selling_average",
        "integer",
        default=0,
        readable=False,
        writable=False,
        label="متوسط البيع",
    ),
    Field("halt", "boolean", default=False, label=" موقوف"),
    Field("seasonal_drug", "boolean", default=False, label=" موسمي"),
    Field(
        "lowest_price", "double", readable=False, writable=False, label="اقل سعر مشترى"
    ),
    Field(
        "report_date", "datetime", readable=False, writable=False, label="تاريخ التقرير"
    ),
    Field("suppliers", "reference suppliers", label="المورد"),
    Field("flexible_price", "boolean", default=False, label=" متغير السعر"),
    # أصناف خدمية/وهمية (مثل صنف "هللة" لتقريب الفواتير) لا تُتابَع كمياتها،
    # فلا يُطبَّق عليها منع البيع بدون رصيد. القيمة الفارغة تعني: تُتابَع.
    Field("track_stock", "boolean", default=True, label="متابعة المخزون"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
    format="%(name)s",
)
db.items_main.id.label = "م"

#  جدول الأصناف
db.define_table(
    "items_det",
    Field(
        "item_idr",
        "reference items_main",
        label="الصنف الأساسي",
        writable=False,
        required=IS_NOT_EMPTY(),
    ),
    Field(
        "supplier_inv", "integer", label="رقم فاتورة التوريد", required=IS_NOT_EMPTY()
    ),
    Field("item_id", length=20, label="رقم الصنف ", required=IS_NOT_EMPTY()),
    Field("public_price", "double", label="السعر للجمهور"),
    Field("quantity", "double", label="الكمية"),
    Field(
        "free_quantity",
        "double",
        default=0.0,
        writable=False,
        readable=False,
        label="مجاني",
    ),
    Field(
        "discount_rate",
        "double",
        default=0.0,
        writable=False,
        readable=False,
        label="الخصم / نسبة",
    ),
    Field(
        "discount",
        "double",
        default=0.0,
        writable=False,
        readable=False,
        label="الخصم / مبلغ",
    ),
    Field("buy_price", "double", label="سعر الشراء"),
    Field("expiration_date", "date", label="تاريخ الصلاحية"),
    Field("inv_price", "double", label="سعر الشراء الإجمالي"),
    Field("items_count", "double", label="الكمية الفعلية"),
    Field("vat", "double", label="الضريبة"),
    Field("vat_price", "double", label="مبلغ الضريبة"),
    Field("vat_in_public_price", "boolean", label="الضريبة ضمن سعر البيع"),
    Field("return_count", "double", label="المرتجع"),
    Field("item_chked", "boolean", writable=False, readable=False, label="تم تأكيد"),
    Field(
        "return_chked",
        "boolean",
        writable=False,
        readable=False,
        label="تم تأكيد المرتجع",
    ),
    Field("expired_count", "double", default=0.0, label="المنتهي الصلاحية"),
    Field(
        "expired_chked",
        "boolean",
        writable=False,
        readable=False,
        label="تم تأكيد المنتهي الصلاحية",
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.items_det.id.label = "رقم الصنف"

#  جدول وسوم البحث للأصناف (item_tags)
#  صف واحد لكل صنف، يحوي كلمات بحث عربية/إنجليزية لتحسين بحث الوكيل الذكي.
#  يُنشأ تلقائياً عبر web2py (migrate)، أما امتداد pg_trgm وفهرس gin
#  فيُنشآن مرة واحدة من شاشة الإعدادات (setup/seed_data).
db.define_table(
    "item_tags",
    Field(
        "item_idr",
        "reference items_main",
        unique=True,
        required=IS_NOT_EMPTY(),
        label="الصنف",
    ),
    Field("tags", "text", label="الوسوم"),
    Field("source", length=10, default="ai", label="المصدر"),  # ai | manual
    Field(
        "updated_on",
        "datetime",
        default=request.now,
        update=request.now,
        label="آخر تحديث",
    ),
    format="%(tags)s",
)

#  جدول الباركودات السابقة (item_barcode_alias)
#  عندما تغيّر الشركة المصنّعة الرقم الدولي لمنتج، يُستبدل باركود الصنف من
#  شاشة items/barcode_change (3014) ويُحفظ الرقم القديم هنا بدل ضياعه:
#  بحث نقطة البيع يتراجع إلى هذا الجدول فيصل للصنف الحي نفسه، فلا يبيع
#  الكاشير من ملف قديم فارغ (أحد أسباب الأرصدة السالبة) ولا يُنشأ صنف مكرر.
db.define_table(
    "item_barcode_alias",
    Field("item_idr", "reference items_main", label="الصنف", required=IS_NOT_EMPTY()),
    Field(
        "barcode",
        length=20,
        unique=True,
        label="الباركود السابق",
        required=IS_NOT_EMPTY(),
    ),
    Field("note", length=270, label="ملاحظات"),
    auth.signature,
)
db.item_barcode_alias.id.label = "م"

# ------------------------------------------------------------------------------------
#  سجل إيقاف الأصناف (item_halt_log) — قرار المالك 2026-09-18
#  علم items_main.halt أرشفة لا حذف: الموقوف يختفي من القائمة الافتراضية ومن تقرير
#  إعادة الطلب، ولا يُمنع بيعه ولا شراؤه. لا يُنقل لجدول آخر لأن حذف الصنف يمسح
#  دفعاته وأسطر فواتيره تتابعياً. كل تغيير للعلم يُسجَّل هنا بمصدره عبر
#  item_rules.set_halt وتسوية الأصناف، والقرار اليدوي لا تنقضه القواعد التلقائية.
#  الصنف رقم عادي لا reference: حذف الصنف لا يمسح سجله.
db.define_table(
    "item_halt_log",
    Field("item_idr", "integer", notnull=True, label="الصنف"),
    Field("halt", "boolean", label="موقوف"),
    # manual | dormant | review | purchase | barcode — العناوين في item_rules.HALT_SOURCES
    Field("source", length=20, label="المصدر"),
    Field("note", length=200, label="ملاحظة"),
    Field("created_on", "datetime", default=request.now, label="التاريخ"),
    Field("created_by", "integer", default=auth.user_id, label="المستخدم"),
)


def item_by_alias_barcode(code):
    """يعيد صف الصنف الحي إذا كان الرقم المُدخل باركوداً سابقاً له، وإلا None."""
    code = str(code or "").strip()
    if not code:
        return None
    al = db(db.item_barcode_alias.barcode == code).select().first()
    return db.items_main(al.item_idr) if al else None


# ------------------------------------------------------------------------------------------------------------
#  جدول العملاء
db.define_table(
    "customers",
    Field("name", length=260, label="اسم العميل", required=True),
    Field("administrator_name", length=260, label="اسم المسؤول", readable=False),
    Field("mobile", length=10, label="رقم الجوال", readable=False, unique=True),
    Field("tel", "list:string", label="هواتف العميل"),
    Field("address", "text", label="العنوان", readable=False),
    Field("note", "text", label="ملاحظات"),
    Field("cust_type", "integer", label="نوع العميل"),
    Field("total", "double", label="المشتريات", writable=False),
    Field("payed", "double", label="المسدد", writable=False),
    Field("returns", "double", label="المرتجع", writable=False),
    Field("amount", "double", label="المطلوب", writable=False),
    auth.signature,
    format="%(name)s",
)
db.customers.id.label = "م"
#

#
db.define_table(
    "customers_files",
    Field(
        "customers_id",
        "reference customers",
        default=request.args(0),
        label="العميل",
        readable=False,
        writable=False,
    ),
    Field(
        "file_dis",
        "string",
        length=300,
        label="عنوان الملف",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("file_data", "upload", label="الملف", autodelete=True),
    auth.signature,
)
db.customers_files.id.label = "م"

#
db.define_table(
    "customers_pay",
    Field("customers_id", "reference customers", label="العميل"),
    Field(
        "amount",
        "double",
        label="المبلغ المسدد",
        requires=IS_DECIMAL_IN_RANGE(1, 100000),
    ),
    Field(
        "customers_pay_data",
        length=12,
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("note", length=100, label="ملاحظة"),
    Field("pay_note", length=100, label="ملاحظات السداد"),
    Field("pay_type", "integer", label="نوع السداد"),
    auth.signature,
)
db.customers_pay.id.label = "م"

# Accounts settlement
db.define_table(
    "customers_accounts_settlement",
    Field(
        "customers_id",
        "reference customers",
        default=request.args(0),
        label="العميل",
        readable=False,
        writable=False,
    ),
    Field("settlement_data", "datetime", default=request.now, label="تاريخ السداد"),
    auth.signature,
)
db.customers_accounts_settlement.id.label = "م"

# ==========================================================================================================


#  جدول الفاتورة - الأب
db.define_table(
    "invoice_master",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", default=0.0, label="صافي الفاتورة"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    Field("pih_txt", "text", label="pih"),
    Field("qr_code", "text", label="qr"),
    Field("zatca_res", "text", label="zatca"),
    Field("sim_invoce", "boolean", default=True, label="فاتورة مبيعات مبسطة"),
    Field("send_to_zatca", "boolean", default=False, label="تم ارسال الفاتورة"),
    auth.signature,
)
db.invoice_master.id.label = "م"

#  جدول الفاتورة - الابن
db.define_table(
    "invoice_details",
    Field("item_number", "reference items_det", label="رقم الصنف"),
    Field("item_idr", "integer", label="رقم الصنف الاساسي"),
    Field("item_count", "double", label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="نسبة الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة الضريبة"),
    auth.signature,
)
db.invoice_details.id.label = "م"
# db.dkey.id.default =lambda: (db().select(db.dkey.id.max()).first()[db.dkey.id.max()] or 0) +1

#  جدول مرتجع المبيعات - الأب
db.define_table(
    "inv_return_master",
    Field("customer", "reference customers", label="اسم العميل"),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", default=0.0, label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    Field("pih_txt", "text", label="pih"),
    Field("qr_code", "text", label="qr"),
    Field("zatca_res", "text", label="zatca"),
    Field("sim_invoce", "boolean", default=True, label="فاتورة مبيعات مبسطة"),
    Field("send_to_zatca", "boolean", default=False, label="تم ارسال الفاتورة"),
    auth.signature,
)
db.inv_return_master.id.label = "م"


#  جدول مرتجع المبيعات - الأبن
db.define_table(
    "inv_return_details",
    Field("item_number", "reference items_det", label="رقم الصنف"),
    Field("item_count", "double", default=0, label="العدد"),
    Field("amount", "double", label="المبلغ"),
    Field("total", "double", label="الإجمالي"),
    Field("discount", "double", default=0.0, label="الخصم"),
    Field("total_after_discount", "double", label="الإجمالي بعد الخصم"),
    Field("uuid", length=36, required=True, readable=False),
    Field("vat", "double", default=0.0, label="الضريبة"),
    Field("vat_total", "double", default=0.0, label="قيمة ةالضريبة"),
    auth.signature,
)
db.inv_return_details.id.label = "م"
