Vue.component('v-select', VueSelect.VueSelect);

function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments;
        var ctx  = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

function escapeHtml(text) {
    return String(text == null ? '' : text).replace(/[&<>"']/g, function(ch) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
}

// بلا استعلام: الصفحة قد تُفتح بـ ?req=<رقم الطلب>، ولصق "/../../" بعد الاستعلام يكسر كل الروابط
var pageUrl = window.location.origin + window.location.pathname;
var baseUrl = pageUrl + '/../../api_1/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        // الحالة: active (الافتراضي، والبحث فيها يشمل الموقوف في آخر النتائج) | halted | all
        status: 'active',
        statusCounts: { active: 0, halted: 0 },
        haltedInSearch: 0,
        haltBusy: false,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_2: 0,
        showBtn: 0,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        field_errors: {},
        value: '',
        options: [],
        items_count: 0,
        loading: false,
        tags: '',
        tags_source: null,
        tags_loading: false,
        // بطاقة الصنف المنبثقة
        card: null,
        cardLoading: false,
        cardError: '',
        cardSeq: 0,
        pendingModal: null,
        // طلب العميل الذي تُنشأ منه نافذة "صنف جديد" (items/main?req=<id>)
        fromRequest: null,
        barcode_generating: false,
    },
    mounted() {
        var cardEl = document.getElementById('itemCardModal');
        // ضغطة أمر أثناء ظهور البطاقة يتجاهل Bootstrap إغلاقها، فنُكمل الإغلاق عند تمام الظهور
        cardEl.addEventListener('shown.bs.modal', function() {
            if (this.pendingModal) bootstrap.Modal.getOrCreateInstance(cardEl).hide();
        }.bind(this));
        cardEl.addEventListener('hidden.bs.modal', function() {
            var next = this.pendingModal;
            this.pendingModal = null;
            if (next) this.showModal(next);
        }.bind(this));
    },
    created() {
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);
        var jsonHeaders = { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } };

        this.loading = true;
        Promise.all([
            this.fetchData(),
            fetch(baseUrl + 'min_suppliers_1').then(function(r) { return r.json(); }),
            fetch(baseUrl + 'types').then(function(r) { return r.json(); }),
            fetch(baseUrl + 'units').then(function(r) { return r.json(); }),
        ]).then(function(results) {
            var itemsData = results[0];
            var suppliers = Api.getData(results[1]);
            var types = Api.getData(results[2]);
            var units = Api.getData(results[3]);

            this.applyList(itemsData);

            this.coding.supplier = suppliers;
            this.coding.Allsupplier = suppliers;
            suppliers.forEach(function(el) {
                this.options.push({ value: el.id, label: el.name });
            }.bind(this));

            this.coding.types = types;
            this.coding.units = units;
            // بعد تحميل القوائم حتى تكون خيارات النافذة جاهزة
            this.startFromRequest();
            this.startFromItemLink();
        }.bind(this)).finally(function() { this.loading = false; }.bind(this));
    },
    computed: {
        totalPages: function() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function() {
            return this.getData.page + 1;
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                types: this.select_obj_2,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                status: this.status,
            };
            if (this.value && this.value.value) {
                params.supplier = this.value.value;
            }
            var url = new URL(baseUrl + 'getMainItems2');
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); });
        },
        applyList: function(res) {
            this.data = res.data;
            this.data_row_count = res.count;
            this.statusCounts = res.status_counts || { active: 0, halted: 0 };
            this.haltedInSearch = res.halted_in_search || 0;
        },
        onChange: function() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.loading = true;
            this.fetchData().then(this.applyList.bind(this))
                .finally(function() { this.loading = false; }.bind(this));
        },
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.loading = true;
            this.fetchData().then(this.applyList.bind(this))
                .finally(function() { this.loading = false; }.bind(this));
        },
        setStatus: function(status) {
            if (this.status === status) return;
            this.status = status;
            this.onChange();
        },
        clearSearch: function() {
            this.getData.SearchText = '';
            this.onChange();
        },
        resetFilters: function() {
            this.getData.SearchText = '';
            this.value = '';
            this.select_obj_2 = 0;
            this.getData.RecordCount = 20;
            this.status = 'active';
            this.onChange();
        },
        sortBy: function(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function(index, row) {
            this.selectedRow = index;
            this.field_errors = {};
            this.edit_row_data = { ...row };
            var sup = null;
            this.options.forEach(function(el) {
                if (el.value === row.suppliers) sup = el;
            });
            this.edit_row_data.suppliers = sup || { value: 0, label: 'اختر' };
            this.edit_row_data.flexible_price = (row.flexible_price === 'T');
            if (this.edit_row_data.name) {
                this.edit_row_data.name = String(this.edit_row_data.name).trim().toUpperCase();
            }
            this.loadTags(row.id);
            this.openCard(row);
        },
        openCard: function(row) {
            // تظهر البطاقة فوراً بما في صف الجدول، ثم تكتمل من الخادم.
            // cardSeq يمنع رداً متأخراً لصنف سابق من الكتابة فوق الصنف الحالي.
            var seq = ++this.cardSeq;
            this.pendingModal = null;
            this.cardError = '';
            this.cardLoading = true;
            this.card = {
                item: {
                    id: row.id,
                    name: row.name,
                    item_id: row.item_id,
                    type_name: row.t_name || '',
                    supplier_name: row.s_name || '',
                    unit_name: '',
                    item_group: row.item_group,
                    item_reg: '',
                    note: '',
                    card_price: row.public_price,
                    halt: row.halt === 'T',
                    flexible_price: row.flexible_price === 'T',
                    seasonal: false,
                    track_stock: row.track_stock !== 'F',
                    stock: row.stock,
                    last_buy_price: row.last_buy_price,
                    sale_price: row.sale_price,
                    sale_price_ex: row.sale_price_ex,
                    sale_vat: row.sale_vat,
                    sale_price_source: row.sale_price_source,
                },
                batches: [],
                batches_open: null,
                batches_total: null,
                last_buy: null,
                margin_pct: null,
                last_sale: null,
            };
            this.$nextTick(function() { this.showModal('itemCardModal'); }.bind(this));
            fetch(baseUrl + 'getMainItemCard/' + row.id, { headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (seq !== this.cardSeq) return;
                    if (Api.isOk(data)) {
                        this.card = Api.getData(data);
                    } else {
                        this.cardError = Api.getError(data);
                    }
                }.bind(this))
                .catch(function() {
                    if (seq === this.cardSeq) this.cardError = 'تعذر تحميل بيانات الصنف، أعد المحاولة.';
                }.bind(this))
                .finally(function() {
                    if (seq === this.cardSeq) this.cardLoading = false;
                }.bind(this));
        },
        showModal: function(id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show();
        },
        // Bootstrap لا يدعم نافذتين فوق بعض: تُغلق البطاقة وتُفتح النافذة التالية
        // من مستمعي البطاقة في mounted بعد اكتمال الإغلاق
        leaveCardTo: function(modalId) {
            this.pendingModal = modalId;
            bootstrap.Modal.getOrCreateInstance(document.getElementById('itemCardModal')).hide();
        },
        cardEdit: function() {
            this.new_row = false;
            this.leaveCardTo('exampleModal');
        },
        cardCount: function() {
            this.edit_count();
            this.leaveCardTo('CountModal');
        },
        // إيقاف الصنف أو تفعيله يدوياً. الإيقاف أرشفة: لا يمنع البيع ولا الشراء،
        // والقرار اليدوي لا تنقضه تسوية الأصناف (الراكد والمراجعة)، ويرفعه أول توريد.
        toggleHalt: function() {
            var item = this.card && this.card.item;
            if (!item || this.haltBusy) return;
            var halt = !item.halt;
            Swal.fire({
                icon: 'question',
                title: halt ? 'إيقاف الصنف؟' : 'تفعيل الصنف؟',
                html: halt
                    ? 'يختفي من القائمة الافتراضية ومن تقرير إعادة الطلب.<br>لا يُمنع بيعه ولا شراؤه، ويعود نشطاً تلقائياً مع أول توريد له.'
                    : 'يعود إلى القائمة الافتراضية وإلى تقرير إعادة الطلب.',
                showCancelButton: true,
                confirmButtonText: halt ? 'إيقاف' : 'تفعيل',
                cancelButtonText: 'تراجع'
            }).then(function(r) {
                if (!r.isConfirmed) return;
                this.haltBusy = true;
                var url = new URL(baseUrl + 'setItemHalt');
                url.searchParams.append('id', item.id);
                url.searchParams.append('halt', halt ? '1' : '0');
                fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        if (!Api.isOk(data)) {
                            Swal.fire('تنبية', Api.getError(data), 'error');
                            return;
                        }
                        this.applyHalt(item.id, halt, Api.getData(data).changed);
                        this.refreshCard(item.id);
                    }.bind(this))
                    .catch(function() { Swal.fire('تنبية', 'تعذر الحفظ، أعد المحاولة.', 'error'); })
                    .finally(function() { this.haltBusy = false; }.bind(this));
            }.bind(this));
        },
        // الصف يبقى في الصفحة بعلامته حتى التحديث التالي (حذفه يربك رقم الصف المحدد)
        applyHalt: function(id, halt, changed) {
            var flag = halt ? 'T' : 'F';
            if (this.card && this.card.item.id === id) this.card.item.halt = halt;
            var row = this.data.find(function(r) { return r.id === id; });
            if (row) row.halt = flag;
            if (this.edit_row_data.id === id) this.edit_row_data.halt = flag;
            if (changed) {
                this.statusCounts.active += halt ? -1 : 1;
                this.statusCounts.halted += halt ? 1 : -1;
            }
        },
        refreshCard: function(id) {
            var seq = ++this.cardSeq;
            fetch(baseUrl + 'getMainItemCard/' + id, { headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (seq === this.cardSeq && Api.isOk(data)) this.card = Api.getData(data);
                }.bind(this));
        },
        stockClass: function(stock) {
            var n = parseFloat(stock) || 0;
            if (n < 0) return 'is-neg';
            if (n === 0) return 'is-zero';
            return '';
        },
        formatQty: function(value) {
            var num = parseFloat(value);
            if (isNaN(num)) return '0';
            return num.toLocaleString('en-US', { maximumFractionDigits: 2 });
        },
        salePriceTitle: function(row) {
            var t = row.sale_price_source === 'card'
                ? 'سعر بطاقة الصنف — لا توجد دفعة مسعّرة'
                : 'شامل الضريبة حسب أحدث دفعة توريد';
            return row.flexible_price === 'T' ? t + ' (متغير السعر)' : t;
        },
        vatPercent: function(rate) {
            return Math.round((parseFloat(rate) || 0) * 10000) / 100 + '%';
        },
        expiryTitle: function(state) {
            if (state === 'expired') return 'منتهية الصلاحية';
            if (state === 'near') return 'تنتهي خلال 90 يوماً';
            return '';
        },
        // صيغة العدد العربية: يوم / يومين / 3 أيام / 11 يوماً
        arCount: function(n, one, two, few, many) {
            if (n === 1) return one;
            if (n === 2) return two;
            if (n >= 3 && n <= 10) return n + ' ' + few;
            return n + ' ' + many;
        },
        ago: function(days) {
            if (days === null || days === undefined) return '';
            if (days < 0) return 'بتاريخ لاحق';
            if (days === 0) return 'اليوم';
            if (days === 1) return 'أمس';
            if (days < 31) return 'منذ ' + this.arCount(days, 'يوم', 'يومين', 'أيام', 'يوماً');
            if (days < 365) {
                return 'منذ ' + this.arCount(Math.round(days / 30), 'شهر', 'شهرين', 'أشهر', 'شهراً');
            }
            return 'منذ ' + this.arCount(Math.floor(days / 365), 'سنة', 'سنتين', 'سنوات', 'سنة');
        },
        edit_count: function() {
            var url = new URL(pageUrl + '/../../api_1/getCountItems/' + this.edit_row_data.id);
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) { this.items_count = Api.getData(data); }.bind(this));
        },
        new_row_click: function() {
            this.new_row = true;
            this.edit_row_data = { suppliers: {} };
            this.field_errors = {};
            this.selectedRow = -1;
            this.tags = '';
            this.tags_source = null;
            this.fromRequest = null;
        },
        // زر "تحويل" في شاشة طلبات العملاء يفتح هذه الشاشة بـ ?req=<رقم الطلب>:
        // تُفتح نافذة صنف جديد معبأة من الطلب، ويُربط الطلب بالصنف عند الحفظ.
        // شاشة جودة بيانات الأصناف تفتح هذه الشاشة بـ ?item=<رقم الصنف>: يُبحث عن الصنف
        // ويُحدَّد صفه فتُفتح بطاقته بأزرارها (ومنها التعديل الذي يحتاج بيانات الصف)
        startFromItemLink: function() {
            var itemId = parseInt(new URLSearchParams(window.location.search).get('item'), 10);
            if (!itemId) return;
            window.history.replaceState(null, '', pageUrl);
            this.getData.SearchText = String(itemId);
            this.getData.SortBy = 'id';
            this.getData.sortAsc = true;
            this.getData.page = 0;
            this.fetchData().then(function(data) {
                this.applyList(data);
                var index = this.data.findIndex(function(r) { return r.id === itemId; });
                if (index > -1) {
                    this.rowSelect(index, this.data[index]);
                } else {
                    Swal.fire('تنبية', 'الصنف رقم ' + itemId + ' غير موجود', 'error');
                }
            }.bind(this));
        },
        startFromRequest: function() {
            var reqId = new URLSearchParams(window.location.search).get('req');
            if (!reqId) return;
            // يُزال الاستعلام حتى لا يعيد تحديث الصفحة فتح النافذة
            window.history.replaceState(null, '', pageUrl);
            fetch(baseUrl + 'getItemRequestDraft/' + encodeURIComponent(reqId), { headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (!Api.isOk(data)) {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                        return;
                    }
                    var d = Api.getData(data);
                    if (d.converted_to_item) {
                        Swal.fire('الطلب مربوط بصنف',
                            'تم تحويل هذا الطلب من قبل إلى الصنف: ' + (d.converted_item_name || d.converted_to_item),
                            'info');
                        return;
                    }
                    this.new_row_click();
                    this.edit_row_data = { suppliers: {}, name: d.name, item_id: d.item_id };
                    this.fromRequest = d;
                    this.showModal('exampleModal');
                }.bind(this))
                .catch(function() {
                    Swal.fire('تنبية', 'تعذر تحميل طلب العميل', 'error');
                });
        },
        // باركود الصنف الموجود يُغيَّر من شاشته المختصة فقط، لأنها تنقل الدفعات معه
        openBarcodeChange: function() {
            window.open(pageUrl + '/../../items/barcode_change?ref=' + encodeURIComponent(this.edit_row_data.item_id || ''));
        },
        tagsUrl: function(fn) {
            return new URL(pageUrl + '/../../item_tags/' + fn);
        },
        loadTags: function(itemId) {
            this.tags = '';
            this.tags_source = null;
            if (!itemId) return;
            var url = this.tagsUrl('get_tags');
            url.searchParams.append('item_id', itemId);
            fetch(url, { headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        var d = Api.getData(data);
                        this.tags = d.tags || '';
                        this.tags_source = d.source;
                    }
                }.bind(this));
        },
        saveTags: function() {
            if (!this.edit_row_data.id) return;
            this.tags_loading = true;
            var url = this.tagsUrl('save_tags');
            var params = { item_id: this.edit_row_data.id, tags: this.tags || '' };
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        this.tags_source = 'manual';
                        Swal.fire('تم', 'تم حفظ الوسوم', 'success');
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this))
                .finally(function() { this.tags_loading = false; }.bind(this));
        },
        regenerateTags: function() {
            if (!this.edit_row_data.id) return;
            this.tags_loading = true;
            var url = this.tagsUrl('generate_one');
            url.searchParams.append('item_id', this.edit_row_data.id);
            fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        var d = Api.getData(data);
                        this.tags = d.tags || '';
                        this.tags_source = 'ai';
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this))
                .finally(function() { this.tags_loading = false; }.bind(this));
        },
        formatNum: function(value) {
            var num = parseFloat(value);
            if (isNaN(num)) return value || '0';
            return num.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },
        onNameInput: function(e) {
            var val = (e.target.value || '').toUpperCase();
            this.$set(this.edit_row_data, 'name', val);
            if (e.target.value !== val) {
                e.target.value = val;
            }
        },
        onNameBlur: function() {
            if (this.edit_row_data.name) {
                this.$set(this.edit_row_data, 'name', this.edit_row_data.name.replace(/\s+/g, ' ').trim());
            }
        },
        // لمنتج ليس له باركود: باركود داخلي غير مستخدم من الخادم (13 خانة تبدأ بـ 2990)
        generateBarcode: function() {
            var apply = function() {
                this.barcode_generating = true;
                fetch(baseUrl + 'newInternalBarcode', { headers: { 'Accept': 'application/json' } })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (Api.isOk(data)) {
                            this.$set(this.edit_row_data, 'item_id', Api.getData(data));
                        } else {
                            Swal.fire('تنبية', Api.getError(data), 'error');
                        }
                    }.bind(this))
                    .catch(function() { Swal.fire('تنبية', 'تعذر توليد الباركود', 'error'); })
                    .finally(function() { this.barcode_generating = false; }.bind(this));
            }.bind(this);
            if (!this.edit_row_data.item_id) {
                apply();
                return;
            }
            Swal.fire({
                icon: 'question',
                title: 'استبدال الباركود المكتوب؟',
                text: 'التوليد لمنتج ليس له باركود. إن كان على العلبة باركود فامسحه بدل التوليد.',
                showCancelButton: true,
                confirmButtonText: 'توليد',
                cancelButtonText: 'تراجع'
            }).then(function(r) { if (r.isConfirmed) apply(); });
        },
        save_data: function(confirmed) {
            var d = this.edit_row_data || {};
            var item_id = (d.item_id == null ? '' : String(d.item_id)).trim();
            var name = (d.name == null ? '' : String(d.name)).trim();
            var price = parseFloat(d.public_price);
            var item_group = d.item_group;
            var errors = {};
            var messages = [];

            if (!item_id) {
                errors.item_id = true;
                messages.push('رقم الصنف مطلوب');
            } else if (item_id.length > 20) {
                errors.item_id = true;
                messages.push('رقم الصنف يجب ان لا يزيد عن 20 حرف');
            }

            if (!name) {
                errors.name = true;
                messages.push('اسم الصنف مطلوب');
            } else if (name.length < 10) {
                errors.name = true;
                messages.push('اسم الصنف يجب ان لا يقل عن 10 احرف');
            } else if (name.length > 460) {
                errors.name = true;
                messages.push('اسم الصنف يجب ان لا يزيد عن 460 حرف');
            }

            if (!d.item_unit) {
                errors.item_unit = true;
                messages.push('الوحدة مطلوبة');
            }

            if (!d.item_type) {
                errors.item_type = true;
                messages.push('التصنيف مطلوب');
            }

            if (d.public_price === '' || d.public_price === null || d.public_price === undefined || isNaN(price)) {
                errors.public_price = true;
                messages.push('سعر البيع مطلوب بشكل صحيح');
            } else if (price <= 0) {
                errors.public_price = true;
                messages.push('سعر البيع يجب ان يكون اكبر من صفر');
            }

            if (item_group !== '' && item_group !== null && item_group !== undefined) {
                var grp_str = String(item_group).trim();
                if (grp_str !== '') {
                    var grp = parseInt(grp_str, 10);
                    if (isNaN(grp) || grp < 0 || String(grp) !== grp_str) {
                        errors.item_group = true;
                        messages.push('مجموعة الصنف يجب ان تكون رقم صحيح');
                    }
                }
            }

            this.field_errors = errors;

            if (messages.length > 0) {
                Swal.fire({
                    icon: 'error',
                    title: 'الحقول التالية تحتاج الى تعبئة او تصحيح',
                    html: '<ul style="text-align:right; direction:rtl; padding-right:1.5em;">' +
                          messages.map(function(m) { return '<li>' + m + '</li>'; }).join('') +
                          '</ul>'
                });
                return;
            }
            var endpoint = this.new_row ? 'newMainItem' : 'editMainItem';
            var url = new URL(pageUrl + '/../../api_1/' + endpoint);
            var payload = { ...this.edit_row_data };
            payload.suppliers = (this.edit_row_data.suppliers && this.edit_row_data.suppliers.value) ? this.edit_row_data.suppliers.value : 0;
            payload.flexible_price = payload.flexible_price ? 'T' : 'F';
            payload.name = (payload.name || '').replace(/\s+/g, ' ').toUpperCase().trim();
            if (this.new_row && this.fromRequest) {
                payload.request_id = this.fromRequest.id;
            }
            if (confirmed === true) {
                payload.confirm_warnings = '1';
            }
            Object.keys(payload).forEach(function(key) { url.searchParams.append(key, payload[key]); });
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var row = Api.getData(data);
                    if (Api.isOk(data) && row && row.id > 0) {
                        this.coding.types.forEach(function(r) {
                            if (r.id === payload.item_type) payload.t_name = r.name;
                        });
                        if (!payload.suppliers) payload.s_name = '';  // المورد اختياري
                        this.coding.supplier.forEach(function(r) {
                            if (r.id === payload.suppliers) payload.s_name = r.name;
                        });
                        if (this.new_row) {
                            payload.id = row.id;
                            this.data.splice(0, 0, { ...payload });
                            this.data_row_count = parseInt(this.data_row_count || 0, 10) + 1;
                        } else {
                            this.$set(this.data, this.selectedRow, { ...payload });
                        }
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        this.new_row = true;
                        this.field_errors = {};
                        this.fromRequest = null;
                        bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                        Swal.fire('عمل رائع',
                            data.request_linked ? 'تم حفظ الصنف وربطه بطلب العميل' : 'تمت عملية الحفظ بشكل صحيح',
                            'success');
                    } else if (data && data.need_confirm) {
                        // ملاحظات لا تمنع الحفظ (باركود غير قياسي، اسم مكرر): تأكيد ثم إعادة الإرسال
                        Swal.fire({
                            icon: 'warning',
                            title: 'تأكيد قبل الحفظ',
                            html: '<ul style="text-align:right; direction:rtl; padding-right:1.5em;">' +
                                  (data.warnings || []).map(function(m) { return '<li>' + escapeHtml(m) + '</li>'; }).join('') +
                                  '</ul>',
                            showCancelButton: true,
                            confirmButtonText: 'متابعة الحفظ',
                            cancelButtonText: 'مراجعة'
                        }).then(function(r) {
                            if (r.isConfirmed) this.save_data(true);
                        }.bind(this));
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this));
        },
        cancel_data: function() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
            this.field_errors = {};
            this.fromRequest = null;
        },
        items_history: function() {
            window.open(pageUrl + '/../../items/itm_rep_det/' + this.edit_row_data.id);
        },
        items_sales: function() {
            window.open(pageUrl + '/../../items/items_sales/' + this.edit_row_data.id);
        },
        adjust_quantity: function() {
            window.open(pageUrl + '/../../items/adjust_quantity/' + this.edit_row_data.id);
        },
        item_barcode_print: function() {
            window.open(pageUrl + '/../../items/it_prt_by_item.svc/' + this.edit_row_data.id);
        },
        save_count: function() {
            if (!this.items_count || this.items_count < 0) {
                Swal.fire('تنبية', 'يجب ادخال قيمة صحيحة في عدد الصنف.', 'error');
                return;
            }
            var url = new URL(pageUrl + '/../../api_1/editcountItem');
            var params = { item_id: this.edit_row_data.id, total_count: this.items_count };
            Object.keys(params).forEach(function(key) { url.searchParams.append(key, params[key]); });
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        // الجدول يعرض الرصيد، فيُحدَّث صف الصنف بالكمية الجديدة
                        var row = this.data[this.selectedRow];
                        if (row && row.id === this.edit_row_data.id) {
                            row.stock = parseFloat(this.items_count) || 0;
                        }
                        this.selectedRow = -1;
                        bootstrap.Modal.getInstance(document.getElementById("CountModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this));
        }
    },
    watch: {
        value: function() { this.onChange(); }
    }
});
