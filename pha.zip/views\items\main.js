Vue.component('v-select', VueSelect.VueSelect);

function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments;
        var ctx  = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

var baseUrl = window.location.href + '/../../api_1/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_2: 0,
        showBtn: 0,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        field_errors: {},
        value: '',
        options: [],
        items_count: 0,
        loading: false,
        tags: '',
        tags_source: null,
        tags_loading: false,
    },
    created() {
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);
        var jsonHeaders = { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } };

        this.loading = true;
        Promise.all([
            this.fetchData(),
            fetch(baseUrl + 'min_suppliers_1').then(function(r) { return r.json(); }),
            fetch(baseUrl + 'types').then(function(r) { return r.json(); }),
            fetch(baseUrl + 'units').then(function(r) { return r.json(); }),
        ]).then(function(results) {
            var itemsData = results[0];
            var suppliers = Api.getData(results[1]);
            var types = Api.getData(results[2]);
            var units = Api.getData(results[3]);

            this.data = itemsData.data;
            this.data_row_count = itemsData.count;

            this.coding.supplier = suppliers;
            this.coding.Allsupplier = suppliers;
            suppliers.forEach(function(el) {
                this.options.push({ value: el.id, label: el.name });
            }.bind(this));

            this.coding.types = types;
            this.coding.units = units;
        }.bind(this)).finally(function() { this.loading = false; }.bind(this));
    },
    computed: {
        totalPages: function() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function() {
            return this.getData.page + 1;
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                types: this.select_obj_2,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
            };
            if (this.value && this.value.value) {
                params.supplier = this.value.value;
            }
            var url = new URL(baseUrl + 'getMainItems2');
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); });
        },
        onChange: function() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        sortBy: function(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function(index, row) {
            this.selectedRow = index;
            this.field_errors = {};
            this.edit_row_data = { ...row };
            var sup = null;
            this.options.forEach(function(el) {
                if (el.value === row.suppliers) sup = el;
            });
            this.edit_row_data.suppliers = sup || { value: 0, label: 'اختر' };
            this.edit_row_data.flexible_price = (row.flexible_price === 'T');
            if (this.edit_row_data.name) {
                this.edit_row_data.name = String(this.edit_row_data.name).trim().toUpperCase();
            }
            this.loadTags(row.id);
        },
        edit_row: function() {
            this.new_row = false;
        },
        edit_count: function() {
            var url = new URL(window.location.href + '/../../api_1/getCountItems/' + this.edit_row_data.id);
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) { this.items_count = Api.getData(data); }.bind(this));
        },
        new_row_click: function() {
            this.new_row = true;
            this.edit_row_data = { suppliers: {} };
            this.field_errors = {};
            this.selectedRow = -1;
            this.tags = '';
            this.tags_source = null;
        },
        tagsUrl: function(fn) {
            return new URL(window.location.href + '/../../item_tags/' + fn);
        },
        loadTags: function(itemId) {
            this.tags = '';
            this.tags_source = null;
            if (!itemId) return;
            var url = this.tagsUrl('get_tags');
            url.searchParams.append('item_id', itemId);
            fetch(url, { headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        var d = Api.getData(data);
                        this.tags = d.tags || '';
                        this.tags_source = d.source;
                    }
                }.bind(this));
        },
        saveTags: function() {
            if (!this.edit_row_data.id) return;
            this.tags_loading = true;
            var url = this.tagsUrl('save_tags');
            var params = { item_id: this.edit_row_data.id, tags: this.tags || '' };
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        this.tags_source = 'manual';
                        Swal.fire('تم', 'تم حفظ الوسوم', 'success');
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this))
                .finally(function() { this.tags_loading = false; }.bind(this));
        },
        regenerateTags: function() {
            if (!this.edit_row_data.id) return;
            this.tags_loading = true;
            var url = this.tagsUrl('generate_one');
            url.searchParams.append('item_id', this.edit_row_data.id);
            fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        var d = Api.getData(data);
                        this.tags = d.tags || '';
                        this.tags_source = 'ai';
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this))
                .finally(function() { this.tags_loading = false; }.bind(this));
        },
        formatNum: function(value) {
            var num = parseFloat(value);
            if (isNaN(num)) return value || '0';
            return num.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },
        onNameInput: function(e) {
            var val = (e.target.value || '').toUpperCase();
            this.$set(this.edit_row_data, 'name', val);
            if (e.target.value !== val) {
                e.target.value = val;
            }
        },
        onNameBlur: function() {
            if (this.edit_row_data.name) {
                this.$set(this.edit_row_data, 'name', this.edit_row_data.name.trim());
            }
        },
        save_data: function() {
            var d = this.edit_row_data || {};
            var item_id = (d.item_id == null ? '' : String(d.item_id)).trim();
            var name = (d.name == null ? '' : String(d.name)).trim();
            var price = parseFloat(d.public_price);
            var item_group = d.item_group;
            var errors = {};
            var messages = [];

            if (!item_id) {
                errors.item_id = true;
                messages.push('رقم الصنف مطلوب');
            } else if (item_id.length > 20) {
                errors.item_id = true;
                messages.push('رقم الصنف يجب ان لا يزيد عن 20 حرف');
            }

            if (!name) {
                errors.name = true;
                messages.push('اسم الصنف مطلوب');
            } else if (name.length < 10) {
                errors.name = true;
                messages.push('اسم الصنف يجب ان لا يقل عن 10 احرف');
            } else if (name.length > 460) {
                errors.name = true;
                messages.push('اسم الصنف يجب ان لا يزيد عن 460 حرف');
            }

            if (!d.item_unit) {
                errors.item_unit = true;
                messages.push('الوحدة مطلوبة');
            }

            if (!d.item_type) {
                errors.item_type = true;
                messages.push('التصنيف مطلوب');
            }

            if (d.public_price === '' || d.public_price === null || d.public_price === undefined || isNaN(price)) {
                errors.public_price = true;
                messages.push('سعر البيع مطلوب بشكل صحيح');
            } else if (price <= 0) {
                errors.public_price = true;
                messages.push('سعر البيع يجب ان يكون اكبر من صفر');
            }

            if (item_group !== '' && item_group !== null && item_group !== undefined) {
                var grp_str = String(item_group).trim();
                if (grp_str !== '') {
                    var grp = parseInt(grp_str, 10);
                    if (isNaN(grp) || grp < 0 || String(grp) !== grp_str) {
                        errors.item_group = true;
                        messages.push('مجموعة الصنف يجب ان تكون رقم صحيح');
                    }
                }
            }

            this.field_errors = errors;

            if (messages.length > 0) {
                Swal.fire({
                    icon: 'error',
                    title: 'الحقول التالية تحتاج الى تعبئة او تصحيح',
                    html: '<ul style="text-align:right; direction:rtl; padding-right:1.5em;">' +
                          messages.map(function(m) { return '<li>' + m + '</li>'; }).join('') +
                          '</ul>'
                });
                return;
            }
            var endpoint = this.new_row ? 'newMainItem' : 'editMainItem';
            var url = new URL(window.location.href + '/../../api_1/' + endpoint);
            var payload = { ...this.edit_row_data };
            payload.suppliers = (this.edit_row_data.suppliers && this.edit_row_data.suppliers.value) ? this.edit_row_data.suppliers.value : 0;
            payload.flexible_price = payload.flexible_price ? 'T' : 'F';
            payload.name = (payload.name || '').toUpperCase().trim();
            Object.keys(payload).forEach(function(key) { url.searchParams.append(key, payload[key]); });
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var row = Api.getData(data);
                    if (Api.isOk(data) && row && row.id > 0) {
                        this.coding.types.forEach(function(r) {
                            if (r.id === payload.item_type) payload.t_name = r.name;
                        });
                        this.coding.supplier.forEach(function(r) {
                            if (r.id === payload.suppliers) payload.s_name = r.name;
                        });
                        if (this.new_row) {
                            payload.id = row.id;
                            this.data.splice(0, 0, { ...payload });
                            this.data_row_count = parseInt(this.data_row_count || 0, 10) + 1;
                        } else {
                            this.$set(this.data, this.selectedRow, { ...payload });
                        }
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        this.new_row = true;
                        this.field_errors = {};
                        bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this));
        },
        cancel_data: function() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
            this.field_errors = {};
        },
        items_history: function() {
            window.open(window.location.href + '/../../items/itm_rep_det/' + this.edit_row_data.id);
        },
        items_sales: function() {
            window.open(window.location.href + '/../../items/items_sales/' + this.edit_row_data.id);
        },
        adjust_quantity: function() {
            window.open(window.location.href + '/../../items/adjust_quantity/' + this.edit_row_data.id);
        },
        item_barcode_print: function() {
            window.open(window.location.href + '/../../items/it_prt_by_item.svc/' + this.edit_row_data.id);
        },
        save_count: function() {
            if (!this.items_count || this.items_count < 0) {
                Swal.fire('تنبية', 'يجب ادخال قيمة صحيحة في عدد الصنف.', 'error');
                return;
            }
            var url = new URL(window.location.href + '/../../api_1/editcountItem');
            var params = { item_id: this.edit_row_data.id, total_count: this.items_count };
            Object.keys(params).forEach(function(key) { url.searchParams.append(key, params[key]); });
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (Api.isOk(data)) {
                        this.selectedRow = -1;
                        bootstrap.Modal.getInstance(document.getElementById("CountModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', Api.getError(data), 'error');
                    }
                }.bind(this));
        }
    },
    watch: {
        value: function() { this.onChange(); }
    }
});
