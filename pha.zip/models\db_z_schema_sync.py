# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# مزامنة المخطط — مرة واحدة لكل عملية خادم، لا في كل طلب
#
# الجداول كسولة (lazy_tables=True في db.py): لا يُبنى الجدول ولا يُفحص ترحيله إلا عند أول
# استخدام له في الطلب. هذا الملف (آخر ملفات db_* ترتيباً) يضمن أن الترحيل الكامل لكل الجداول
# ثم الفهارس (modules/system_readiness.py) والأعمدة (db_6_indexes.py) تجري عند أول طلب بعد تشغيل الخادم، وكلما
# تغيّر أي ملف نماذج. فيبقى الاستعلام الخام (executesql) آمناً على عمود أُضيف حديثاً حتى لو
# لم يلمس الـ DAL جدوله بعد في ذلك الطلب.
#
# بقية الطلبات لا تنفّذ هنا أي استعلام؛ تقرأ فقط أوقات تعديل ملفات النماذج.
# الحالة في cache.ram (لكل عملية ولكل تطبيق)؛ مسحها بـ cache.ram.clear() يعيد المزامنة مرة.
# الفهرس الذي لم يُنشأ هنا (جدول كبير، تكرار uuid في فرع، امتداد ناقص) لا يُعاد في كل طلب:
# يظهر ناقصاً مع سببه في setup/seed_data، والتكرار يُصلح عبر setup/uuid_guard.
# ===========================================================================================


def _schema_stamp():
    """أحدث وقت تعديل لملفات النماذج — مصدرية (models/) أو مُجمّعة (compiled/models*)."""
    stamp = 0
    for sub, prefix in (("models", ""), ("compiled", "models")):
        try:
            with os.scandir(os.path.join(request.folder, sub)) as entries:
                for entry in entries:
                    if entry.name.startswith(prefix) and entry.is_file():
                        stamp = max(stamp, entry.stat().st_mtime)
        except OSError:
            pass
    return stamp


_schema_state = cache.ram("schema_sync_state", dict, time_expire=None)
_stamp = _schema_stamp()

if _schema_state.get("stamp") != _stamp:
    # بناء كل الجداول => web2py تجري ترحيل ما تغيّر منها (migrate) كما كانت تفعل في كل طلب
    for _t in db.tables:
        db[_t]

    # الفهارس الناقصة على الجداول الصغيرة فقط، بفحوص شاشة التهيئة نفسها (لا مكرر لفهرس قائم
    # باسم آخر، ولا فريد على بيانات مكررة). الجدول الكبير لا يُبنى هنا لأن البناء العادي يوقف
    # الكتابة فيه طوال مدته؛ يظهر ناقصاً في setup/seed_data ويُبنى منها دون إيقاف البيع.
    import system_readiness as _readiness
    _auto = _readiness.auto_apply(db)
    if _auto:
        try:
            auth.log_event("Auto index: %(names)s", dict(names=", ".join(_auto)), origin="system_readiness")
            db.commit()
        except Exception:
            db.rollback()

    # سبب هذه القائمة مشروح فوقها في db_6_indexes.py
    for _table, _column, _type in _ensure_columns:
        try:
            if not db.executesql(
                    "SELECT 1 FROM information_schema.columns WHERE table_name = %s AND column_name = %s",
                    placeholders=[_table, _column]):
                db.executesql("ALTER TABLE %s ADD COLUMN IF NOT EXISTS %s %s" % (_table, _column, _type))
                db.commit()
        except Exception:
            db.rollback()

    _schema_state["stamp"] = _stamp
