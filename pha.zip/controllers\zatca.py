# -*- coding: utf-8 -*-
# type: ignore
"""
ZATCA integration controller — direct connection to ZATCA API (no proxy).
"""

import json
import api_helpers as api


@auth.requires_membership("admin")
def step1_csid():
    """المرحلة 1: إنشاء المفاتيح والحصول على شهادة التوافق (Compliance CSID)"""
    from zatca_direct.csr import generate_keys_and_csid
    from zatca_direct.api_client import ZatcaApiError, ZatcaConnectionError
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config:
            return response.json(api.api_error(mess="يجب حفظ بيانات المنشأة أولاً"))

        otp = request.vars.otp or csr_config.otp
        if not otp or len(str(otp)) != 6:
            return response.json(api.api_error(mess="رمز OTP يجب أن يكون 6 أرقام"))

        csr_config.update_record(otp=otp)
        db.commit()

        config = {
            "environmentType": csr_config.environment,
            "C": "SA",
            "O": csr_config.organization_name,
            "OU": csr_config.organization_unit_name,
            "CN": csr_config.company_id,
            "VAT": csr_config.organization_identifier,
            "CRN": csr_config.company_id,
            "ADDRESS": csr_config.location_address,
            "CATEGORY": csr_config.business_category,
            "TITLE": "1100",
            "OTP": str(otp),
        }

        data = generate_keys_and_csid(config)

        # Save to database
        csr_config.update_record(**data)
        db.commit()

        return response.json(api.api_ok(
            data={"phase": 2, "ccsid_requestid": data["ccsid_requestid"]},
            mess="تم إنشاء المفاتيح والحصول على شهادة التوافق بنجاح"
        ))
    except ZatcaConnectionError as e:
        db.rollback()
        return response.json(api.api_error(mess=f"تعذر الاتصال بـ ZATCA: {e}"))
    except ZatcaApiError as e:
        db.rollback()
        return response.json(api.api_error(mess=f"خطأ من ZATCA ({e.status_code}): {e.detail}"))
    except FileNotFoundError as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@auth.requires_membership("admin")
def step2_onboarding():
    """المرحلة 2: اختبارات التوافق والحصول على المفتاح النهائي (Production CSID)"""
    from zatca_direct.onboarding import run_onboarding
    from zatca_direct.api_client import ZatcaApiError, ZatcaConnectionError
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        if not csr_config or not csr_config.ccsid_requestid:
            return response.json(api.api_error(mess="يجب إكمال المرحلة الأولى أولاً"))

        config = {
            "ccsid_requestid": csr_config.ccsid_requestid,
            "ccsid_binarysecuritytoken": csr_config.ccsid_binarysecuritytoken,
            "ccsid_secret": csr_config.ccsid_secret,
            "privatekey": csr_config.privatekey,
            "environmentType": csr_config.environment,
            "VAT": csr_config.organization_identifier,
            "CN": csr_config.company_id,
        }

        data = run_onboarding(config)

        # Save production CSID data
        csr_config.update_record(
            pcsid_requestid=data["pcsid_requestid"],
            pcsid_binarysecuritytoken=data["pcsid_binarysecuritytoken"],
            pcsid_secret=data["pcsid_secret"],
        )
        db.commit()

        return response.json(api.api_ok(
            data={"phase": 3, "pcsid_requestid": data["pcsid_requestid"]},
            mess="تم اجتياز اختبارات التوافق والحصول على المفتاح النهائي بنجاح"
        ))
    except ZatcaConnectionError as e:
        db.rollback()
        return response.json(api.api_error(mess=f"تعذر الاتصال بـ ZATCA: {e}"))
    except ZatcaApiError as e:
        db.rollback()
        return response.json(api.api_error(mess=f"خطأ من ZATCA ({e.status_code}): {e.detail}"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@auth.requires_membership("admin")
def zatca_status():
    """الحصول على حالة الربط الحالية"""
    csr_config = db(db.csr_config.id > 0).select().first()
    if not csr_config:
        return response.json(api.api_ok(data={"phase": 0}))

    phase = 0
    if csr_config.organization_name and csr_config.organization_identifier:
        phase = 1
    if csr_config.ccsid_requestid:
        phase = 2
    if csr_config.pcsid_requestid:
        phase = 3

    sent_count = db(db.invoice_sending.send == True).count()
    pending_count = db(db.invoice_sending.send == False).count()

    return response.json(api.api_ok(data={
        "phase": phase,
        "environment": csr_config.environment or "",
        "icv": csr_config.icv or 1,
        "has_pih": bool(csr_config.pih),
        "sent_invoices": sent_count,
        "pending_invoices": pending_count,
    }))
