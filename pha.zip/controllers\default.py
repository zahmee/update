# -*- coding: utf-8 -*-
#  type: ignore
import httpx
from datetime import datetime
"""
@can_access(1001)
"""


# ---- example index page ----
@auth.requires_login()
def index():
    # رقم النسخة وتاريخها — من المصدر الوحيد pha_ver.txt عبر models/db.py
    local_ver = app_version()
    modification_time = app_version_modified()
    ck_row = {}
    msg_id = 102
    if auth.is_logged_in():
        if db(db.public_msg.msg_id == msg_id).isempty() == True:
            db.public_msg.insert(
                msg_id=msg_id,
                msg_text="""
       تم اضافة ادخال فترات الشفت
       و تم اضافة مصروفات الصندوق 
                                """,
                msg_count=0,
                msg_max=15,
            )
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
        else:
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
            if ck_row.msg_count < ck_row.msg_max:
                ck_row.msg_count = 1 + ck_row.msg_count
                ck_row.update_record()
            else:
                ck_row.msg_text = ""
        db.commit()
    stats = {}
    if auth.is_logged_in():
        stats['open_bills'] = db(db.suppliers_bills.bill_confirmation != True).count()
        stats['pending_returns'] = db(db.returned_supply.admin_accept == False).count()

    # المستندات المقاربة على الانتهاء (خلال 30 يوم) أو المنتهية
    expiring_docs = []
    if auth.is_logged_in():
        today = datetime.now().date()
        from datetime import timedelta
        limit_date = today + timedelta(days=30)
        rows = db(
            (db.my_files.expiry_date != None) &
            (db.my_files.expiry_date <= limit_date)
        ).select(
            db.my_files.id, db.my_files.doc_name,
            db.my_files.expiry_date, db.my_files.doc_type,
            orderby=db.my_files.expiry_date
        )
        for r in rows:
            days_left = (r.expiry_date - today).days
            doc_type_name = ''
            if r.doc_type:
                dt = db.key_doc_types[r.doc_type]
                if dt:
                    doc_type_name = dt.name
            expiring_docs.append(dict(
                id=r.id,
                doc_name=r.doc_name,
                doc_type_name=doc_type_name,
                expiry_date=str(r.expiry_date),
                days_left=days_left,
            ))

    return dict(msg=ck_row, local_ver=local_ver, modification_time=modification_time, stats=stats, expiring_docs=expiring_docs)

@auth.requires_login()
def server_version():
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        Headers = {}
        url = csr_config.api_site + "/"
        resp = httpx.get(url, headers=Headers)
        # server_ver = float(resp.json()["running_version"])
        return response.json(resp.json())
    except Exception:
        return response.json({"running_version": 0})


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Embedded wiki (example) ----
@auth.requires_login()
def wiki():
    auth.wikimenu()  # add the wiki to the menu
    return auth.wiki()


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


# ---- action to server uploaded static content (required) ---
@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    try:
        return response.download(request, db)
    except Exception:
        # fallback: serve file directly when pydal fails to decode filename
        import os
        import mimetypes
        filename = request.args[-1] if request.args else None
        if not filename:
            raise HTTP(404)
        filepath = os.path.join(request.folder, 'uploads', filename)
        if not os.path.isfile(filepath):
            raise HTTP(404)
        content_type = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        response.headers['Content-Type'] = content_type
        return response.stream(open(filepath, 'rb'))


def not_allow():
    return dict()


@auth.requires_login()
def about():
    import subprocess
    from gluon.contrib.appconfig import AppConfig
    configuration = AppConfig(reload=True)
    exp = configuration.get("app.exp_date")
    date_def = None
    if exp:
        d1 = datetime.strptime(datetime.now().strftime("%Y-%m-%d"), "%Y-%m-%d")
        d2 = datetime.strptime(exp, "%Y-%m-%d")
        date_def = (d2 - d1).days

    # رقم النسخة — من المصدر الوحيد pha_ver.txt عبر models/db.py
    local_ver = app_version()

    # Remote version using curl (same as _t.py for reliability)
    remote_ver = local_ver
    has_update = False
    update_error = None
    try:
        curl_cmd = ["curl", "-sL", "--max-time", "15",
                    "https://github.com/zahmee/update/raw/refs/heads/main/pha_ver.txt"]
        result = subprocess.run(curl_cmd, capture_output=True, text=True, timeout=20)
        if result.returncode == 0 and result.stdout.strip():
            remote_ver = result.stdout.strip()
            # Compare as floats: update only if remote is strictly newer
            try:
                has_update = float(remote_ver) > app_version_float()
            except Exception:
                has_update = False
        else:
            update_error = result.stderr or "empty response"
    except Exception as e:
        update_error = str(e)

    # Company info from important_info
    info = db(db.important_info.id > 0).select().first()

    # Build WhatsApp link
    raw_mobile = info.mobile if info and info.mobile else '0502010911'
    if raw_mobile.startswith('0'):
        wa_num = '966' + raw_mobile[1:]
    else:
        wa_num = raw_mobile

    return dict(
        exp=exp,
        date_def=date_def,
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        update_error=update_error,
        info=info,
        wa_num=wa_num,
    )


@auth.requires_login()
def history():
    return dict()
