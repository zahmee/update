# -*- coding: utf-8 -*-
#  type: ignore
import httpx
import pathlib
from datetime import datetime
"""
@can_access(1001)
"""


# ---- example index page ----
def index():
    Headers = {}
    url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/pha_ver.txt"
    resp = httpx.get(url, headers=Headers)
    site_ver = float(resp.text)
    app_path = pathlib.Path(__file__).resolve().parent.parent
    local_file = app_path / "pha_ver.txt"
    stats = local_file.stat()
    modification_time = datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
    with open(local_file, "r") as f:
        local_ver = float(f.read())
    # if site_ver > local_ver:
    #     redirect(URL("_t", "up"))
    ck_row = {}
    msg_id = 102
    if auth.is_logged_in():
        if db(db.public_msg.msg_id == msg_id).isempty() == True:
            db.public_msg.insert(
                msg_id=msg_id,
                msg_text="""
       تم اضافة ادخال فترات الشفت
       و تم اضافة مصروفات الصندوق 
                                """,
                msg_count=0,
                msg_max=15,
            )
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
        else:
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
            if ck_row.msg_count < ck_row.msg_max:
                ck_row.msg_count = 1 + ck_row.msg_count
                ck_row.update_record()
            else:
                ck_row.msg_text = ""
        db.commit()
    stats = {}
    if auth.is_logged_in():
        today = datetime.now().date()
        today_start = datetime.combine(today, datetime.min.time())
        today_end = datetime.combine(today, datetime.max.time())

        stats['invoices_today_all'] = db(
            (db.invoice_master.created_on >= today_start) &
            (db.invoice_master.created_on <= today_end)
        ).count()

        stats['invoices_today_me'] = db(
            (db.invoice_master.created_on >= today_start) &
            (db.invoice_master.created_on <= today_end) &
            (db.invoice_master.created_by == auth.user.id)
        ).count()

        total_row = db(
            (db.invoice_master.created_on >= today_start) &
            (db.invoice_master.created_on <= today_end)
        ).select(db.invoice_master.total_after_discount.sum()).first()
        stats['total_today'] = round(
            total_row[db.invoice_master.total_after_discount.sum()] or 0, 2
        )

        stats['open_bills'] = db(db.suppliers_bills.bill_confirmation != True).count()
        stats['pending_returns'] = db(db.returned_supply.admin_accept == False).count()

        stats['total_items'] = db(db.items_main.id > 0).count()
        stats['total_customers'] = db(db.customers.id > 0).count()
        stats['active_suppliers'] = db(db.suppliers.stoped != True).count()

    # المستندات المقاربة على الانتهاء (خلال 30 يوم) أو المنتهية
    expiring_docs = []
    if auth.is_logged_in():
        today = datetime.now().date()
        from datetime import timedelta
        limit_date = today + timedelta(days=30)
        rows = db(
            (db.my_files.expiry_date != None) &
            (db.my_files.expiry_date <= limit_date)
        ).select(
            db.my_files.id, db.my_files.doc_name,
            db.my_files.expiry_date, db.my_files.doc_type,
            orderby=db.my_files.expiry_date
        )
        for r in rows:
            days_left = (r.expiry_date - today).days
            doc_type_name = ''
            if r.doc_type:
                dt = db.key_doc_types[r.doc_type]
                if dt:
                    doc_type_name = dt.name
            expiring_docs.append(dict(
                id=r.id,
                doc_name=r.doc_name,
                doc_type_name=doc_type_name,
                expiry_date=str(r.expiry_date),
                days_left=days_left,
            ))

    return dict(msg=ck_row, local_ver=local_ver, modification_time=modification_time, stats=stats, expiring_docs=expiring_docs)

@auth.requires_login()
def dashboard_charts():
    from datetime import timedelta
    today = datetime.now().date()

    # مبيعات آخر 7 أيام
    sales_7days = []
    day_names = ['الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد']
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        day_start = datetime.combine(day, datetime.min.time())
        day_end = datetime.combine(day, datetime.max.time())
        total_row = db(
            (db.invoice_master.created_on >= day_start) &
            (db.invoice_master.created_on <= day_end)
        ).select(db.invoice_master.total_after_discount.sum()).first()
        day_total = round(total_row[db.invoice_master.total_after_discount.sum()] or 0, 2)
        count_row = db(
            (db.invoice_master.created_on >= day_start) &
            (db.invoice_master.created_on <= day_end)
        ).count()
        sales_7days.append({
            'date': day.strftime('%m/%d'),
            'day_name': day_names[day.weekday()],
            'total': day_total,
            'count': count_row
        })

    # توزيع طرق الدفع اليوم
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    payment_methods = db(db.key_payment_method.id > 0).select()
    payment_breakdown = []
    for pm in payment_methods:
        pm_total_row = db(
            (db.invoice_master.created_on >= today_start) &
            (db.invoice_master.created_on <= today_end) &
            (db.invoice_master.payment_method == pm.id)
        ).select(db.invoice_master.total_after_discount.sum()).first()
        pm_total = round(pm_total_row[db.invoice_master.total_after_discount.sum()] or 0, 2)
        if pm_total > 0:
            payment_breakdown.append({
                'name': pm.name,
                'total': pm_total
            })

    return response.json({
        'sales_7days': sales_7days,
        'payment_breakdown': payment_breakdown
    })


def server_version():
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        Headers = {}
        url = csr_config.api_site + "/"
        resp = httpx.get(url, headers=Headers)
        # server_ver = float(resp.json()["running_version"])
        return response.json(resp.json())
    except Exception:
        return response.json({"running_version": 0})


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Embedded wiki (example) ----
def wiki():
    auth.wikimenu()  # add the wiki to the menu
    return auth.wiki()


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


# ---- action to server uploaded static content (required) ---
@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def not_allow():
    return dict()


def about():
    return dict()


def history():
    return dict()
