Vue.component('v-select', VueSelect.VueSelect);

var SUPPLIERS_BASE = new URL('./', window.location.origin + window.location.pathname);
var API_BASE = new URL('../suppliers_api/', SUPPLIERS_BASE).href;

function parseStoped(rows) {
    rows.forEach(function(el) {
        el.stoped = (el.stoped === 'T');
    });
    return rows;
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            StopStatus: 'all',
            SortBy: 'id',
            sortAsc: false
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        card: null,
        pendingModal: null,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        loading: false,
    },
    created() {
        this.loading = true;
        this.fetchData().then(function(data) {
            this.data = parseStoped(Api.getData(data));
            this.data_row_count = data.count;
        }.bind(this)).finally(function() { this.loading = false; }.bind(this));
    },
    mounted: function() {
        var cardEl = document.getElementById('supplierCardModal');
        cardEl.addEventListener('shown.bs.modal', function() {
            // Bootstrap ignores hide() during the opening transition.
            if (this.pendingModal) bootstrap.Modal.getOrCreateInstance(cardEl).hide();
        }.bind(this));
        cardEl.addEventListener('hidden.bs.modal', function() {
            var next = this.pendingModal;
            this.pendingModal = null;
            if (next) this.showModal(next);
            else this.cancel_data();
        }.bind(this));
        document.getElementById('exampleModal').addEventListener('hidden.bs.modal', function() {
            this.cancel_data();
        }.bind(this));
    },
    computed: {
        totalPages: function() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        activeSupplierCount: function() {
            return this.data.filter(function(row) { return !row.stoped; }).length;
        },
        stoppedSupplierCount: function() {
            return this.data.filter(function(row) { return row.stoped; }).length;
        },
        currentPage: function() {
            return this.getData.page + 1;
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                StopStatus: this.getData.StopStatus,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc
            };
            if (this.value && this.value.value) {
                params.supplier = this.value.value;
            }
            var url = new URL(API_BASE + 'get_supp');
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); });
        },
        onChange: function() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = parseStoped(Api.getData(data));
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = parseStoped(Api.getData(data));
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        sortBy: function(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function(index, row, event) {
            // Wait for the previous modal and its backdrop to finish closing.
            if (document.body.classList.contains('modal-open')) return;
            this.selectedRow = index;
            this.card = { ...row };
            this.cardTrigger = event.currentTarget.matches('button')
                ? event.currentTarget : event.currentTarget.querySelector('.supplier-name-button');
            this.$nextTick(function() { this.showModal('supplierCardModal'); });
        },
        showModal: function(id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show();
        },
        edit_row: function() {
            if (!this.card) return;
            this.new_row = false;
            this.edit_row_data = { ...this.card };
            this.pendingModal = 'exampleModal';
            bootstrap.Modal.getOrCreateInstance(document.getElementById('supplierCardModal')).hide();
        },
        new_row_click: function() {
            this.card = null;
            this.cardTrigger = null;
            this.selectedRow = -1;
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_data: function() {
            if (!this.edit_row_data.name) {
                Swal.fire('تنبية', 'يجب ادخال [ اسم المورد ] .', 'error');
                return;
            }
            var endpoint = this.new_row ? 'new_supplier' : 'update_supplier';
            var url = new URL(API_BASE + endpoint);
            var params = this.edit_row_data;
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); })
              .then(function(data) {
                if (Api.isOk(data)) {
                    var result = Api.getData(data);
                    if (this.new_row) {
                        this.edit_row_data.id = result.id;
                        this.data.splice(0, 0, this.edit_row_data);
                    } else {
                        this.$set(this.data, this.selectedRow, { ...this.edit_row_data, id: result.id });
                    }
                    bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                    Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                } else {
                    Api.showError(data);
                }
            }.bind(this));
        },
        cancel_data: function() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
            this.card = null;
            if (this.cardTrigger && document.contains(this.cardTrigger)) this.cardTrigger.focus();
            this.cardTrigger = null;
        },
        account_movement: function() {
            if (!this.card) return;
            window.open(new URL('account_movement/' + this.card.id, SUPPLIERS_BASE).href, '_self');
        },
        supplier_items_sales: function() {
            if (!this.card) return;
            window.open(new URL('supplier_items_sales/' + this.card.id, SUPPLIERS_BASE).href, '_self');
        },
        account_rep5: function() {
            if (!this.card) return;
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0');
            var yyyy = today.getFullYear();
            var d = dd + ',' + mm + ',' + yyyy;
            var url = new URL('rep5', SUPPLIERS_BASE);
            url.searchParams.set('da1', d);
            url.searchParams.set('da2', d);
            url.searchParams.set('sup', this.card.id);
            window.open(url.href, '_blank', 'noopener');
        }
    },
    watch: {
        value: function() { this.onChange(); }
    }
});
