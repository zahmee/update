# -*- coding: utf-8 -*-
#  type: ignore

from datetime import datetime


# ============= دوال مساعدة =============

def _get_current_qty(item_main_id):
    """جلب الكمية الحالية للصنف من مجموع items_det"""
    row = db.executesql(
        "SELECT COALESCE(SUM(items_count), 0)::double precision as qty"
        " FROM items_det WHERE item_idr = %s",
        placeholders=[item_main_id], as_dict=True
    )
    return float(row[0]["qty"]) if row else 0.0


def _calculate_delta(item_main_id, since_time):
    """حساب المبيعات والمشتريات بعد وقت اللقطة من جدول الحركات"""
    row = db.executesql(
        "SELECT"
        " COALESCE(SUM(qty_in), 0)::double precision as total_in,"
        " COALESCE(SUM(qty_out), 0)::double precision as total_out"
        " FROM items_movement"
        " WHERE item_main = %s AND move_date > %s::timestamp",
        placeholders=[item_main_id, str(since_time)], as_dict=True
    )
    if row:
        return float(row[0]["total_in"]), float(row[0]["total_out"])
    return 0.0, 0.0


def _apply_variance(item_main_id, variance):
    """تطبيق فرق الجرد على items_det وتسجيل الحركة"""
    if variance == 0:
        return

    # توزيع الفرق على أقدم SKU لديه كمية
    dets = db(db.items_det.item_idr == item_main_id).select(
        orderby=db.items_det.id
    )

    if variance > 0:
        # فرق موجب: زيادة الكمية في أول SKU
        if dets:
            det = dets.first()
            det.update_record(items_count=(det.items_count or 0) + variance)
        # تسجيل حركة جرد (وارد)
        db.items_movement.insert(
            item_main=item_main_id,
            item_det=dets.first().id if dets else 0,
            move_type="جرد",
            move_date=request.now,
            qty_in=variance, qty_out=0,
            unit_price=0,
            reference="تعديل جرد",
            ref_no="",
        )
    else:
        # فرق سالب: خصم من أقدم SKU لديه كمية
        remaining = abs(variance)
        applied_det_id = 0
        for det in dets:
            if remaining <= 0:
                break
            current = float(det.items_count or 0)
            if current <= 0:
                continue
            deduct = min(current, remaining)
            det.update_record(items_count=current - deduct)
            remaining -= deduct
            applied_det_id = det.id
        if remaining > 0 and dets:
            # إذا لم تكف الكميات، خصم من أول SKU
            det = dets.first()
            det.update_record(items_count=(det.items_count or 0) - remaining)
            applied_det_id = det.id
        # تسجيل حركة جرد (صادر)
        db.items_movement.insert(
            item_main=item_main_id,
            item_det=applied_det_id,
            move_type="جرد",
            move_date=request.now,
            qty_in=0, qty_out=abs(variance),
            unit_price=0,
            reference="تعديل جرد",
            ref_no="",
        )


# ============= الدوال الرئيسية =============

@auth.requires_login()
def index():
    """قائمة جلسات الجرد"""
    return dict()


@auth.requires_login()
def get_sessions():
    """API: جلب جلسات الجرد"""
    status_filter = request.vars.status or ""
    conditions = ["1=1"]
    params = []
    if status_filter:
        conditions.append("s.status = %s")
        params.append(status_filter)

    where = " AND ".join(conditions)
    rows = db.executesql(
        "SELECT s.id, s.name, s.started_at, s.finished_at, s.status, s.notes,"
        " u.first_name || ' ' || u.last_name as created_by_name,"
        " (SELECT COUNT(*) FROM inv_count_item WHERE session_id = s.id) as item_count,"
        " (SELECT COUNT(*) FROM inv_count_item WHERE session_id = s.id AND status = 'confirmed') as confirmed_count"
        " FROM inv_session s"
        " LEFT JOIN auth_user u ON u.id = s.created_by"
        " WHERE " + where +
        " ORDER BY s.id DESC",
        placeholders=params, as_dict=True
    )

    return response.json([{
        "id": r["id"],
        "name": r["name"],
        "started_at": str(r["started_at"])[:16] if r["started_at"] else "",
        "finished_at": str(r["finished_at"])[:16] if r["finished_at"] else "",
        "status": r["status"],
        "notes": r["notes"] or "",
        "created_by_name": r["created_by_name"] or "",
        "item_count": int(r["item_count"]),
        "confirmed_count": int(r["confirmed_count"]),
    } for r in rows])


@auth.requires_login()
def open_session():
    """فتح جلسة جرد جديدة"""
    name = request.vars.name or ""
    notes = request.vars.notes or ""
    if not name:
        return response.json({"status": "error", "message": "يجب إدخال اسم الجلسة"})

    sid = db.inv_session.insert(
        name=name,
        started_at=request.now,
        status="open",
        notes=notes,
    )
    db.commit()
    return response.json({"status": "success", "id": sid, "message": "تم فتح جلسة الجرد"})


@auth.requires_login()
def view_session():
    """عرض تفاصيل جلسة الجرد"""
    session_id = request.args(0)
    if not session_id:
        redirect(URL("inventory", "index"))
    sess = db.inv_session(session_id)
    if not sess:
        redirect(URL("inventory", "index"))
    return dict(session_id=session_id, sess=sess)


@auth.requires_login()
def get_session_items():
    """API: جلب بنود جلسة الجرد"""
    session_id = request.vars.session_id
    if not session_id:
        return response.json({"error": "يجب تحديد الجلسة"})

    rows = db.executesql(
        "SELECT c.id, c.item_main, m.name as item_name, m.item_id,"
        " c.snapshot_qty, c.snapshot_time, c.counted_qty, c.counted_at,"
        " c.sales_delta, c.purchase_delta, c.adjusted_expected,"
        " c.variance, c.variance_reason, c.status,"
        " u.first_name || ' ' || u.last_name as counted_by_name"
        " FROM inv_count_item c"
        " JOIN items_main m ON m.id = c.item_main"
        " LEFT JOIN auth_user u ON u.id = c.counted_by"
        " WHERE c.session_id = %s"
        " ORDER BY c.id DESC",
        placeholders=[session_id], as_dict=True
    )

    return response.json([{
        "id": r["id"],
        "item_main": r["item_main"],
        "item_name": r["item_name"],
        "item_id": r["item_id"],
        "snapshot_qty": float(r["snapshot_qty"] or 0),
        "snapshot_time": str(r["snapshot_time"])[:16] if r["snapshot_time"] else "",
        "counted_qty": float(r["counted_qty"]) if r["counted_qty"] is not None else None,
        "counted_at": str(r["counted_at"])[:16] if r["counted_at"] else "",
        "sales_delta": float(r["sales_delta"] or 0),
        "purchase_delta": float(r["purchase_delta"] or 0),
        "adjusted_expected": float(r["adjusted_expected"] or 0),
        "variance": float(r["variance"] or 0),
        "variance_reason": r["variance_reason"] or "",
        "status": r["status"],
        "counted_by_name": r["counted_by_name"] or "",
    } for r in rows])


@auth.requires_login()
def search_item():
    """بحث عن صنف بالاسم أو الرقم"""
    search = request.vars.q or ""
    if not search:
        return response.json([])
    srh = search.strip().split()
    if len(srh) == 1:
        qry = (
            "SELECT id, item_id, name FROM items_main"
            " WHERE LOWER(name) LIKE %s OR item_id LIKE %s"
            " ORDER BY name ASC LIMIT 10"
        )
        term = '%' + search.lower() + '%'
        data = db.executesql(qry, placeholders=[term, term], as_dict=True)
    elif len(srh) >= 2:
        qry = (
            "SELECT id, item_id, name FROM items_main"
            " WHERE LOWER(name) LIKE %s AND LOWER(name) LIKE %s"
            " ORDER BY name ASC LIMIT 10"
        )
        data = db.executesql(qry, placeholders=[
            '%' + srh[0].lower() + '%',
            '%' + srh[1].lower() + '%',
        ], as_dict=True)
    else:
        data = []
    return response.json(data)


@auth.requires_login()
def add_items():
    """إضافة صنف للجرد مع أخذ snapshot فوري"""
    session_id = request.vars.session_id
    item_main_id = request.vars.item_main_id
    if not session_id or not item_main_id:
        return response.json({"status": "error", "message": "بيانات ناقصة"})

    sess = db.inv_session(session_id)
    if not sess or sess.status != "open":
        return response.json({"status": "error", "message": "الجلسة مغلقة أو غير موجودة"})

    # التحقق من عدم إضافة الصنف مسبقاً في نفس الجلسة
    existing = db((db.inv_count_item.session_id == session_id) &
                  (db.inv_count_item.item_main == item_main_id)).count()
    if existing > 0:
        return response.json({"status": "error", "message": "الصنف مضاف مسبقاً في هذه الجلسة"})

    # أخذ اللقطة
    snapshot_qty = _get_current_qty(item_main_id)
    now = datetime.now()

    db.inv_count_item.insert(
        session_id=session_id,
        item_main=item_main_id,
        snapshot_qty=snapshot_qty,
        snapshot_time=now,
        status="pending",
    )
    db.commit()

    item = db.items_main(item_main_id)
    return response.json({
        "status": "success",
        "message": "تم إضافة الصنف - الكمية الحالية: {}".format(snapshot_qty),
        "item_name": item.name if item else "",
        "snapshot_qty": snapshot_qty,
    })


@auth.requires_login()
def enter_count():
    """إدخال الكمية المعدودة وحساب الـ Delta"""
    count_id = request.vars.count_id
    counted_qty = request.vars.counted_qty
    variance_reason = request.vars.variance_reason or ""

    if not count_id or counted_qty is None:
        return response.json({"status": "error", "message": "بيانات ناقصة"})

    try:
        counted_qty = float(counted_qty)
    except (ValueError, TypeError):
        return response.json({"status": "error", "message": "الكمية المعدودة غير صحيحة"})

    item_rec = db.inv_count_item(count_id)
    if not item_rec:
        return response.json({"status": "error", "message": "السجل غير موجود"})
    if item_rec.status == "confirmed":
        return response.json({"status": "error", "message": "تم تأكيد هذا البند مسبقاً"})

    # حساب Delta من جدول الحركات
    purchase_delta, sales_delta = _calculate_delta(
        item_rec.item_main, item_rec.snapshot_time
    )

    # الكمية المتوقعة = اللقطة + المشتريات - المبيعات
    adjusted_expected = item_rec.snapshot_qty + purchase_delta - sales_delta
    variance = counted_qty - adjusted_expected

    now = datetime.now()
    item_rec.update_record(
        counted_qty=counted_qty,
        counted_at=now,
        sales_delta=sales_delta,
        purchase_delta=purchase_delta,
        adjusted_expected=round(adjusted_expected, 2),
        variance=round(variance, 2),
        variance_reason=variance_reason,
        status="counted",
        counted_by=auth.user_id,
    )
    db.commit()

    return response.json({
        "status": "success",
        "message": "تم إدخال العد",
        "sales_delta": sales_delta,
        "purchase_delta": purchase_delta,
        "adjusted_expected": round(adjusted_expected, 2),
        "variance": round(variance, 2),
    })


@auth.requires_membership("admin")
def confirm_item():
    """تأكيد بند وتطبيق الفرق على المخزون"""
    count_id = request.vars.count_id
    if not count_id:
        return response.json({"status": "error", "message": "بيانات ناقصة"})

    item_rec = db.inv_count_item(count_id)
    if not item_rec:
        return response.json({"status": "error", "message": "السجل غير موجود"})
    if item_rec.status != "counted":
        return response.json({"status": "error", "message": "يجب إدخال العد أولاً"})

    # إعادة حساب Delta قبل التأكيد (قد تكون حدثت حركات جديدة)
    purchase_delta, sales_delta = _calculate_delta(
        item_rec.item_main, item_rec.snapshot_time
    )
    adjusted_expected = item_rec.snapshot_qty + purchase_delta - sales_delta
    variance = item_rec.counted_qty - adjusted_expected

    # تطبيق الفرق
    _apply_variance(item_rec.item_main, variance)

    item_rec.update_record(
        sales_delta=sales_delta,
        purchase_delta=purchase_delta,
        adjusted_expected=round(adjusted_expected, 2),
        variance=round(variance, 2),
        status="confirmed",
    )
    db.commit()

    return response.json({
        "status": "success",
        "message": "تم تأكيد البند وتطبيق الفرق ({})".format(round(variance, 2)),
        "variance": round(variance, 2),
    })


@auth.requires_login()
def close_session():
    """إغلاق جلسة الجرد"""
    session_id = request.vars.session_id
    if not session_id:
        return response.json({"status": "error", "message": "بيانات ناقصة"})

    sess = db.inv_session(session_id)
    if not sess:
        return response.json({"status": "error", "message": "الجلسة غير موجودة"})
    if sess.status == "closed":
        return response.json({"status": "error", "message": "الجلسة مغلقة مسبقاً"})

    # التحقق من تأكيد جميع البنود
    pending = db((db.inv_count_item.session_id == session_id) &
                 (db.inv_count_item.status != "confirmed")).count()
    if pending > 0:
        return response.json({
            "status": "error",
            "message": "يوجد {} بند لم يتم تأكيده بعد".format(pending),
        })

    sess.update_record(
        status="closed",
        finished_at=datetime.now(),
    )
    db.commit()

    return response.json({"status": "success", "message": "تم إغلاق جلسة الجرد"})
