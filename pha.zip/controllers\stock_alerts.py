# -*- coding: utf-8 -*-
#  type: ignore
"""مراجعة حالات البيع بدون رصيد.

البيع لا يُمنع عند نقص الرصيد (المنع يدفع العملية خارج الدفاتر ويفتح باب
السرقة)، لكنه يُسجَّل في stock_exception منسوباً للبائع. هذه الشاشة لمراجعته.

الدلالة في النمط لا في الحادثة: حالة واحدة قد تكون مرتجعاً لم يُسجَّل في
الزحمة، أما بائع بعشرات الحالات وزملاؤه بصفر فتلك إشارة تستحق السؤال.
"""

from datetime import datetime, timedelta
import api_helpers as api


def _range():
    """نطاق التاريخ من الطلب، والافتراضي آخر 30 يوماً."""
    today = datetime.now().date()
    try:
        d1 = datetime.strptime(request.vars.date_from, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        d1 = today - timedelta(days=30)
    try:
        d2 = datetime.strptime(request.vars.date_to, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        d2 = today
    return (datetime.combine(d1, datetime.min.time()),
            datetime.combine(d2, datetime.max.time()), d1, d2)


@can_access(5300)
def index():
    return dict()


@can_access(5300)
def list_exceptions():
    """قائمة الحالات مع فلاتر التاريخ والبائع والحالة."""
    start, end, d1, d2 = _range()
    conds = ["e.happened_on BETWEEN %s AND %s"]
    params = [start, end]

    if request.vars.cashier and str(request.vars.cashier).isdigit():
        conds.append("e.cashier = %s")
        params.append(int(request.vars.cashier))
    if request.vars.status in ("open", "reviewed"):
        conds.append("e.status = %s")
        params.append(request.vars.status)
    if request.vars.q and request.vars.q.strip():
        conds.append("(UPPER(e.item_name) LIKE UPPER(%s) OR e.item_code LIKE %s)")
        term = "%" + request.vars.q.strip() + "%"
        params += [term, term]

    where = " AND ".join(conds)
    try:
        page = max(int(request.vars.page or 0), 0)
        per = min(max(int(request.vars.per or 50), 1), 200)
    except (TypeError, ValueError):
        page, per = 0, 50

    total = db.executesql(
        "SELECT COUNT(*) FROM stock_exception e WHERE " + where,
        placeholders=params)[0][0]

    rows = db.executesql(
        "SELECT e.id, e.invoice_no, e.item_code, e.item_name,"
        "       e.qty_requested, e.qty_available, e.shortfall, e.unit_price,"
        "       e.happened_on, e.status, e.review_note,"
        "       COALESCE(u.first_name || ' ' || u.last_name, '') AS cashier_name,"
        "       e.cashier,"
        "       COALESCE(r.first_name || ' ' || r.last_name, '') AS reviewer_name,"
        "       e.reviewed_on"
        "  FROM stock_exception e"
        "  LEFT JOIN auth_user u ON u.id = e.cashier"
        "  LEFT JOIN auth_user r ON r.id = e.reviewed_by"
        " WHERE " + where +
        " ORDER BY e.happened_on DESC, e.id DESC"
        " LIMIT %s OFFSET %s",
        placeholders=params + [per, page * per], as_dict=True)

    for r in rows:
        r["happened_on"] = str(r["happened_on"])[:16] if r["happened_on"] else ""
        r["reviewed_on"] = str(r["reviewed_on"])[:16] if r["reviewed_on"] else ""
        r["value"] = round(float(r["shortfall"] or 0) * float(r["unit_price"] or 0), 2)
        for k in ("qty_requested", "qty_available", "shortfall", "unit_price"):
            r[k] = round(float(r[k] or 0), 2)

    return response.json(api.api_list(rows=rows, count=int(total)))


@can_access(5300)
def summary():
    """ملخص الحالات حسب البائع — هنا يظهر النمط."""
    start, end, d1, d2 = _range()
    rows = db.executesql(
        "SELECT e.cashier,"
        "       COALESCE(u.first_name || ' ' || u.last_name, 'غير معروف') AS cashier_name,"
        "       COUNT(*) AS cases,"
        "       COUNT(*) FILTER (WHERE e.status = 'open') AS open_cases,"
        "       COUNT(DISTINCT e.item_main) AS items,"
        "       ROUND(SUM(e.shortfall)::numeric, 2) AS units,"
        "       ROUND(SUM(e.shortfall * e.unit_price)::numeric, 2) AS value"
        "  FROM stock_exception e"
        "  LEFT JOIN auth_user u ON u.id = e.cashier"
        " WHERE e.happened_on BETWEEN %s AND %s"
        " GROUP BY e.cashier, u.first_name, u.last_name"
        " ORDER BY cases DESC",
        placeholders=[start, end], as_dict=True)

    for r in rows:
        r["units"] = float(r["units"] or 0)
        r["value"] = float(r["value"] or 0)

    totals = {
        "cases": sum(int(r["cases"]) for r in rows),
        "open_cases": sum(int(r["open_cases"]) for r in rows),
        "units": round(sum(r["units"] for r in rows), 2),
        "value": round(sum(r["value"] for r in rows), 2),
        "cashiers": len(rows),
    }
    return response.json(api.api_ok(data={
        "rows": rows, "totals": totals,
        "date_from": str(d1), "date_to": str(d2),
    }))


@can_access(5300)
def top_items():
    """الأصناف الأكثر تكراراً — تكشف الصنف الذي يحتاج جرداً لا البائع."""
    start, end, _d1, _d2 = _range()
    rows = db.executesql(
        "SELECT e.item_main, e.item_code, e.item_name, COUNT(*) AS cases,"
        "       ROUND(SUM(e.shortfall)::numeric, 2) AS units"
        "  FROM stock_exception e"
        " WHERE e.happened_on BETWEEN %s AND %s"
        " GROUP BY e.item_main, e.item_code, e.item_name"
        " ORDER BY cases DESC, units DESC LIMIT 20",
        placeholders=[start, end], as_dict=True)
    for r in rows:
        r["units"] = float(r["units"] or 0)
    return response.json(api.api_list(rows=rows, count=len(rows)))


@can_access(5301)
def mark_reviewed():
    """اعتماد مراجعة حالة أو أكثر."""
    ids = request.vars.ids
    if isinstance(ids, str):
        ids = [x for x in ids.split(",") if x.strip().isdigit()]
    if not isinstance(ids, (list, tuple)) or not ids:
        return response.json(api.api_error(mess="لم تُحدَّد أي حالة"))
    try:
        ids = [int(x) for x in ids]
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="أرقام غير صحيحة"))

    note = (request.vars.note or "").strip()
    n = db(db.stock_exception.id.belongs(ids)).update(
        status="reviewed", review_note=note,
        reviewed_by=auth.user_id, reviewed_on=datetime.now())
    db.commit()
    return response.json(api.api_ok(data={"updated": n},
                                    mess="تمت مراجعة %d حالة" % (n or 0)))


@can_access(5300)
def cashiers():
    """قائمة البائعين الذين لديهم حالات — لملء الفلتر."""
    rows = db.executesql(
        "SELECT DISTINCT e.cashier AS id,"
        "       COALESCE(u.first_name || ' ' || u.last_name, 'غير معروف') AS name"
        "  FROM stock_exception e LEFT JOIN auth_user u ON u.id = e.cashier"
        " WHERE e.cashier IS NOT NULL ORDER BY 2", as_dict=True)
    return response.json(api.api_list(rows=rows, count=len(rows)))
