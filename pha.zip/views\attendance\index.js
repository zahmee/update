var API_BASE = window.location.href + '/../../attendance/';

// تحويل ساعات عشرية إلى صيغة س:دد
function toHM(decimalHours) {
    if (!decimalHours) return '0:00';
    var neg = decimalHours < 0;
    var abs = Math.abs(decimalHours);
    var h = Math.floor(abs);
    var m = Math.round((abs - h) * 60);
    if (m === 60) { h++; m = 0; }
    return (neg ? '-' : '') + h + ':' + String(m).padStart(2, '0');
}

function shiftBasicMinutes(row) {
    if (!row.shift_start || !row.shift_end) return null;
    var start = row.shift_start.split(':');
    var end = row.shift_end.split(':');
    if (start.length < 2 || end.length < 2) return null;
    var startMin = parseInt(start[0]) * 60 + parseInt(start[1]);
    var endMin = parseInt(end[0]) * 60 + parseInt(end[1]);
    var diff = endMin - startMin;
    if (diff <= 0) diff += 24 * 60;
    return diff;
}

var app = new Vue({
    el: '#app',
    data: {
        employee: null,
        today: null,
        today_records: [],
        shift_start: '',
        shift_end: '',
        otp_code: '',
        otp_type: '',
        loading: true,
        sending: false,
        verifying: false,
        countdown: 0,
        countdownInterval: null,
        history: [],
        historyCount: 0,
        historyPage: 0,
    },
    computed: {
        statusClass: function () {
            if (this.today && this.today.check_in && !this.today.check_out) return 'status-checked-in';
            if (this.today_records.length > 0 || (this.today && this.today.check_out)) return 'status-completed';
            return 'status-not-checked';
        },
        statusIcon: function () {
            if (this.today && this.today.check_in && !this.today.check_out) return 'fa-door-open';
            if (this.today_records.length > 0 || (this.today && this.today.check_out)) return 'fa-check-circle';
            return 'fa-door-closed';
        },
        statusText: function () {
            if (this.today && this.today.check_in && !this.today.check_out) return 'تم تسجيل الحضور — في انتظار الانصراف';
            if (this.today_records.length > 0 || (this.today && this.today.check_out)) return 'آخر دورية مكتملة — يمكنك فتح دورية جديدة';
            return 'لم يتم تسجيل الحضور بعد';
        },
    },
    created: function () {
        this.loadStatus();
        this.loadHistory();
    },
    methods: {
        loadStatus: function () {
            var self = this;
            fetch(API_BASE + 'get_my_status')
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (Api.isOk(data)) {
                        var d = Api.getData(data);
                        self.employee = d.employee;
                        self.today = d.today;
                        self.today_records = d.today_records || [];
                    } else {
                        self.employee = null;
                    }
                })
                .finally(function () { self.loading = false; });
        },
        loadHistory: function () {
            var self = this;
            var url = new URL(API_BASE + 'my_attendance');
            url.searchParams.append('page', this.historyPage);
            url.searchParams.append('RecordCount', 20);
            fetch(url)
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (Api.isOk(data)) {
                        self.history = data.data;
                        self.historyCount = data.count;
                    }
                });
        },
        requestOtp: function (type) {
            var self = this;
            self.otp_type = type;
            self.otp_code = '';
            self.sending = true;

            var formData = new FormData();
            formData.append('otp_type', type);
            formData.append('shift_time', type === 'in' ? self.shift_start : self.shift_end);

            fetch(API_BASE + 'request_otp', {
                method: 'POST',
                body: formData
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    self.sending = false;
                    if (Api.isOk(data)) {
                        var modal = new bootstrap.Modal(document.getElementById('otpModal'));
                        modal.show();
                        self.startCountdown();
                    } else {
                        Api.showError(data);
                    }
                })
                .catch(function () {
                    self.sending = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال', 'error');
                });
        },
        verifyOtp: function () {
            var self = this;
            if (self.otp_code.length !== 6) return;
            self.verifying = true;

            var formData = new FormData();
            formData.append('otp_type', self.otp_type);
            formData.append('otp_code', self.otp_code);

            fetch(API_BASE + 'verify_otp', {
                method: 'POST',
                body: formData
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    self.verifying = false;
                    if (Api.isOk(data)) {
                        bootstrap.Modal.getInstance(document.getElementById('otpModal')).hide();
                        self.stopCountdown();
                        Swal.fire('تم بنجاح', data.mess, 'success');
                        self.shift_start = '';
                        self.shift_end = '';
                        self.loadStatus();
                        self.loadHistory();
                    } else {
                        Api.showError(data);
                    }
                })
                .catch(function () {
                    self.verifying = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال', 'error');
                });
        },
        resendOtp: function () {
            this.requestOtp(this.otp_type);
        },
        startCountdown: function () {
            var self = this;
            self.stopCountdown();
            self.countdown = 300;
            self.countdownInterval = setInterval(function () {
                self.countdown--;
                if (self.countdown <= 0) {
                    self.stopCountdown();
                }
            }, 1000);
        },
        stopCountdown: function () {
            if (this.countdownInterval) {
                clearInterval(this.countdownInterval);
                this.countdownInterval = null;
            }
        },
        formatTime: function (dt) {
            if (!dt) return '—';
            var parts = dt.split(' ');
            if (parts.length >= 2) {
                var time = parts[1].split(':');
                return time[0] + ':' + time[1];
            }
            return dt;
        },
        toHM: function (val) {
            return toHM(val);
        },
        calcShiftBasicHours: function (row) {
            var m = shiftBasicMinutes(row);
            if (m === null) return '—';
            return toHM(m / 60);
        },
        calcActualHM: function (row) {
            if (!row.shift_hours) return '—';
            return toHM(row.shift_hours);
        },
        calcDiff: function (row) {
            if (!row.shift_hours || !row.shift_start || !row.shift_end) return '—';
            var basicMin = shiftBasicMinutes(row);
            if (basicMin === null) return '—';
            var actualDiff = row.shift_hours - (basicMin / 60);
            if (Math.abs(actualDiff) < 0.01) return '0:00';
            var sign = actualDiff > 0 ? '+' : '';
            return sign + toHM(actualDiff);
        },
        diffClass: function (row) {
            if (!row.shift_hours || !row.shift_start || !row.shift_end) return '';
            var basicMin = shiftBasicMinutes(row);
            if (basicMin === null) return '';
            var actualDiff = row.shift_hours - (basicMin / 60);
            if (Math.abs(actualDiff) < 0.01) return 'hours-exact';
            if (actualDiff > 0) return 'hours-positive';
            return 'hours-negative';
        },
    }
});
