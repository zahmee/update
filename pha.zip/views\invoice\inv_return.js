var app = new Vue({
    el: '#app',
    data: {
        newTodo: '',
        NewItem: [],
        NewItemCount: 1,
        AllItems: [],
        todos: [],
        seller: this.seller,
        vat_no: this.vat_no,
        URL: this.purl,
        NowDate: new Date(),
        itemNotFound: false,
        returnData: {},
        // حارس الحفظ المزدوج: الزر يختفي أثناء الإرسال ويعود عند الفشل فقط
        save_clicked: true,
        // رقم مميز واحد للمرتجع كله: تُولَّد مرة، وتُعاد المحاولة بها نفسها
        // حتى يستطيع القيد الفريد في قاعدة البيانات رفض التكرار. توليد رقم
        // جديد مع كل ضغطة يجعل النسختين تبدوان مرتجعين مختلفين فيمران معاً.
        uuid1: '',
        key_payment_method: [{
            name: '',
            id: 0
        }],
        selected_method: 1,
        customer: {
            'id': 1,
            'name': 'عميل نقدي',
            'show': false,
        },
        serchCustomar: {
            show: false,
            value: ''
        },
        serchCustomarList: [],
        serchItems: {
            show: false,
            vlaue: ''
        },
        serchItemsListDet: [],
        serchItemsListMaster: [],
        VAT: 0.0,
        discount: 0.0,
        invoce_no: 0,
        GivenByCustomer: 0.0,
    },
    created: function () {
        this.$http.get(this.URL + '/../get_payment_method').then(response => {
            // get body data
            if (Api.isOk(response.body)) {
                this.key_payment_method = Api.getData(response.body);
            }
        }, response => {
            //
        });
    },
    methods: {
        getitem: function () {
            if (!this.NewItem) {
                this.itemNotFound = true;
                this.NewItemCount = 1;
                return;
            }
            var itm_in = String(this.NewItem);
            var n_item = itm_in.split("*");
            if (n_item.length > 1) {
                this.NewItemCount = n_item[0];
                this.NewItem = n_item.slice(1).join("*");
            }
            this.$http.get(this.URL + '/../../invoice/getit/?itid=' + this.NewItem).then(response => {
                // get body data
                var items = Api.getData(response.body);
                if (Api.isOk(response.body) && items && items.length > 0) {
                    itm = items[0];
                    if (itm.flexible_price === "T") {
                        items[0]['count'] = 1;
                        items[0]['public_price'] = (parseFloat(itm.public_price) * parseFloat(this.NewItemCount));
                        this.NewItemCount = 1;
                        items[0]['total'] = parseFloat(items[0]['public_price'] * this.NewItemCount).toFixed(2);
                        vat_mount = (items[0]['public_price'] * this.NewItemCount * items[0]['vat']).toFixed(2);
                        items[0]['vat_mount'] = vat_mount;
                        items[0]['way'] = this.way;
                        this.AllItems.push(items[0]);
                        this.NewItem = '';
                        this.way = '';
                        this.itemNotFound = false;
                        this.NewItemCount = 1;
                    } else {
                        //this.beep(100, 520, 200) ;
                        items[0]['count'] = this.NewItemCount;
                        items[0]['total'] = parseFloat(items[0]['public_price'] * this.NewItemCount).toFixed(2);
                        vat_mount = (items[0]['public_price'] * this.NewItemCount * items[0]['vat']).toFixed(2);
                        items[0]['vat_mount'] = vat_mount;
                        items[0]['way'] = this.way;
                        this.AllItems.push(items[0]);
                        this.NewItem = '';
                        this.way = '';
                        this.itemNotFound = false;
                        this.NewItemCount = 1;
                    }
                } else {
                    this.NewItem = '';
                    this.itemNotFound = true;
                    this.NewItemCount = 1;
                }
            }, response => {
                this.NewItem = '';
            });
        },
        getcustomer: function () {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                // get body data
                var customers = Api.getData(response.body);
                if (Api.isOk(response.body) && customers && customers.length > 0) {
                    this.customer = customers[0]
                    this.customer.show = true;
                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
            });
        },
        removeItem: function (index) {
            this.AllItems.splice(index, 1);
        },
        getcount: function () {
            this.NewItemCount = this.NewItem;
            this.NewItem = '';
        },
        discountFun: function () {
            newval = this.total * 0.1;
            if (this.discount > newval) {
                this.discount = 0;
            }
        },
        findCustomer: function () {
            this.serchCustomar.show = !this.serchCustomar.show;
            //this.$refs.refsearchCustomer.focus();
            //this.$refs.searchCustomer.$el.focus()
        },
        SerchCustomer: function () {
            if (this.serchCustomar.value.length > 2) {
                this.$http.get(this.URL + '/../../invoice/search_c/?itid=' + this.serchCustomar.value).then(response => {
                    // get body data
                    var results = Api.getData(response.body);
                    if (Api.isOk(response.body) && results) {
                        this.serchCustomarList = results;
                    } else {
                        this.serchCustomarList = [];
                        this.customer.id = 1;
                        this.customer.name = 'عميل نقدي';
                    }
                }, response => {
                    //this.customer.id = 1;
                    //this.customer.name = 'عميل نقدي';
                });
            } else {
                this.serchCustomarList = [];
            }
        },
        selectSerchCustomer: function (index) {
            this.customer.id = this.serchCustomarList[index].id;
            this.getcustomer();
            this.serchCustomar.show = !this.serchCustomar.show;
        },
        findItems: function () {
            this.serchItems.show = !this.serchItems.show;
        },
        SerchItems: function () {
            if (this.serchItems.value.length > 2) {
                this.$http.get(this.URL + '/../../items_qry/search_item/?itid=' + this.serchItems.value).then(response => {
                    if (response.body != "") {
                        this.serchItemsListMaster = response.body;
                    } else {
                        this.serchItemsListMaster = [];
                    }
                });
            } else {
                this.serchItemsListMaster = [];
            }
        },
        selectserchItems: function (index) {
            serch_item_det = this.serchItemsListMaster[index];
            this.$http.get(this.URL + '/../../items_qry/search_item_det/?itid=' + serch_item_det.id).then(response => {
                if (response.body != "") {
                    this.serchItemsListDet = response.body;
                } else {
                    this.serchItemsListMaster = [];
                }
            });
            /*
            newiteml = this.serchItemsList[index];
            newiteml['count'] = this.NewItemCount ;
            newiteml['total'] = newiteml['public_price'] * this.NewItemCount  ;
            this.AllItems.push(newiteml);
            console.log(newiteml);
            console.log(this.AllItems);
            */
        },
        selectserchItemsDet: function (index) {
            this.NewItem = this.serchItemsListDet[index]['id']
            this.getitem();
            this.serchItemsListMaster = [];
            this.serchItemsListDet = [];
            this.serchItems.value = '';
            this.NewItem = '';
            this.itemNotFound = false;
            this.NewItemCount = 1;
            this.serchItems.show = !this.serchItems.show;

        },
        SaveAll: function () {
            var self = this;
            if (!this.save_clicked) {
                return;
            }
            if (this.AllItems.length == 0) {
                Swal.fire('لا يوجد منتجات في المرتجع');
                return;
            }
            if (!this.uuid1) {
                this.uuid1 = this.uuidv4();
            }
            this.save_clicked = false;
            alldata = {};
            alldata['itm'] = this.AllItems;
            alldata['uuid'] = this.uuid1;
            alldata['total'] = this.total.toFixed(2);
            alldata['discount'] = this.discount;
            alldata['totalAfterDiscount'] = this.totalAfterDiscount.toFixed(2);
            alldata['vat'] = this.vat.toFixed(2);
            alldata['totalAfterAll'] = this.totalAfterAll.toFixed(2);
            alldata['customer'] = this.customer.id;
            alldata['method'] = this.selected_method;

            this.$http.post(this.URL + '/../saver/', JSON.stringify(alldata), { emulateJSON: true }).then(function (response) {
                var d = response.body;
                if (Api.isOk(d) && d.invno > 0) {
                    self.invoce_no = d.invno;
                    self.returnData = d;
                    if (d.mess && d.mess.length > 0) {
                        Swal.fire('تم حفظ المرتجع و لكن يوجد خطأ التالي :\n\n' + d.mess);
                    }
                    self.$nextTick(function () {
                        self.printReturn();
                        self.resetReturn();
                    });
                } else {
                    // الفشل يعيد الزر ليتمكن الكاشير من المحاولة — وبنفس
                    // الرقم المميز، فإن كانت المحاولة الأولى قد وصلت فعلاً
                    // رفضت قاعدة البيانات الثانية بدل حفظ مرتجع مكرر.
                    self.save_clicked = true;
                    Api.showError(d);
                }
            }, function () {
                self.save_clicked = true;
                Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
            });
        },
        printReturn: function () {
            try {
                var elem = document.getElementById("pr");
                var newpr = elem.innerHTML;
                var a = window.open('', 'PRINT', 'height=600, width=600');
                if (!a) {
                    Swal.fire('تنبيه', 'يرجى السماح بالنوافذ المنبثقة لطباعة المرتجع', 'warning');
                    return;
                }
                var now_date = new Date().toLocaleString("en-GB");
                qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
                var a1 = this.getTLV(1, this.seller);
                var a2 = this.getTLV(2, this.vat_no);
                var a3 = this.getTLV(3, now_date);
                var a4 = this.getTLV(4, this.totalAfterDiscount.toString());
                var a5 = this.getTLV(5, this.vat.toString());
                var aa = a1 + a2 + a3 + a4 + a5;
                var qr = qrcode(0, 'L');
                if (this.returnData.qr && this.returnData.qr !== '') {
                    qr.addData(this.returnData.qr);
                } else {
                    qr.addData(this.hexToBase64(aa));
                }
                qr.make();
                a.document.write('<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=0.8"><title>طباعة مرتجع</title><style>* { margin: 0; padding: 0; box-sizing: border-box; }</style></head><body>');
                a.document.write('<div style="text-align: center">');
                a.document.write('</div>');
                a.document.write(newpr);
                a.document.write('<div style="text-align: center">');
                a.document.write(qr.createSvgTag(5, 2));
                a.document.write('</div>');
                a.document.write('</body></html>');
                a.document.close();
                a.focus();
                a.onafterprint = function () { a.close(); };
                a.print();
            } catch (e) {
                console.error('print error:', e);
            }
        },
        resetReturn: function () {
            // مرتجع جديد = رقم مميز جديد وزر حفظ فعّال
            this.uuid1 = '';
            this.save_clicked = true;
            this.AllItems = [];
            this.discount = 0;
            this.customer.id = 1;
            this.customer.name = "مبيعات نقدية";
            this.selected_method = 1;
            this.customer.show = false;
            this.GivenByCustomer = 0;
        },
        AddHalal: function () {
            var me = this;
            this.AllItems.forEach(function (el, index) {
                if (el.id === 1) {
                    me.AllItems.splice(index, 1);
                }
            });
            var baqee = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            this.NewItem = 1;
            this.NewItemCount = Math.floor(baqee * 100).toFixed(0);
            this.getitem();
            // alert (baqee) ;
        },
        uuidv4() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },

        bytesToHex(bytes) {
            return Array.from(
                bytes,
                byte => byte.toString(16).padStart(2, "0")
            ).join("");
        },
        hexToBase64(str) {
            return btoa(String.fromCharCode.apply(null,
                str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" "))
            );
        },
        stringToUTF8Bytes(string) {
            return new TextEncoder().encode(string);
        },
        isDoubleByte(str) {
            for (var i = 0, n = str.length; i < n; i++) {
                if (str.charCodeAt(i) > 255) { return true; }
            }
            return false;
        },
        getTLV(tag, val) {
            var len = parseInt(val.length.toString(2), 2).toString(16);
            var spaceCount = (val.split(" ").length - 1);
            if ((tag == 1) && (this.isDoubleByte(val) == true)) {
                len = parseInt(((val.length * 2) - spaceCount).toString(2), 2).toString(16);
            }
            var tag = parseInt(tag.toString(2), 2).toString(16);
            var vale = this.bytesToHex(this.stringToUTF8Bytes(val));
            if (len.length == 1) {
                len = '0' + len;
            }
            if (tag.length == 1) {
                tag = '0' + tag;
            }
            return tag + len + vale
        },

    },
    computed: {
        // a computed getter
        total: function () {
            total = 0.0;
            this.AllItems.forEach(function (element) {
                element.total = (element.public_price * element.count) + (element.public_price * element.count * element.vat)
                total += (element.public_price * element.count);
            });
            return total;
        },
        now: function () {
            return Date.now()
        },
        vat: function () {
            vat = 0.0;
            this.AllItems.forEach(function (element) {
                el_vat = element.public_price * element.count * element.vat;
                vat += el_vat;
            });
            return vat;
        },
        totalAfterDiscount: function () {
            return this.total - this.discount;
        },
        totalAfterAll: function () {
            return this.totalAfterDiscount + this.vat;
        },
        BaqeeHalal: function () {
            var halal = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            if (halal < 1)
                return halal
            else
                return 0.0
        },
        TheRest: function () {
            var rest = (this.GivenByCustomer - this.totalAfterAll.toFixed(2)).toFixed(2)
            return rest
        }

    }
});
