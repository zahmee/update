# -*- coding: utf-8 -*-
import sys
sys.stdout = open('applications/asbab5/scripts/test_auth_out.txt', 'w', encoding='utf-8')
print("auth.user:", auth.user)
print("auth.has_membership('admin'):", auth.has_membership("admin"))
print("screens_rules(7001):", screens_rules(7001))
sys.stdout.close()
