(function () {
    var urls = window.PERIODS_REPORT_URLS || {};
    var emptyTotals = {
        count: 0,
        kashir_amount_cash: 0,
        kashir_amount_atm: 0,
        kashir_amount_delay: 0,
        kashir_amount_customer_pay: 0,
        kashir_total: 0,
        app_amount_cash: 0,
        app_amount_atm: 0,
        app_amount_delay: 0,
        app_amount_customer_pay: 0,
        app_total: 0,
        diff_cash: 0,
        diff_atm: 0,
        diff_delay: 0,
        diff_customer_pay: 0,
        difference: 0
    };

    new Vue({
        el: '#app',
        data: {
            date_from: '',
            date_to: '',
            employee_id: 'all',
            employees: [],
            rows: [],
            totals: Object.assign({}, emptyTotals),
            loading: false,
            searched: false
        },
        computed: {
            employeeLabel: function () {
                if (!this.employee_id || this.employee_id === 'all') {
                    return 'جميع الموظفين';
                }
                var selected = this.employees.find(function (emp) {
                    return String(emp.id) === String(this.employee_id);
                }, this);
                return selected ? selected.name : '-';
            },
            printedOn: function () {
                var d = new Date();
                return this.pad(d.getFullYear()) + '-' + this.pad(d.getMonth() + 1) + '-' + this.pad(d.getDate()) +
                    ' ' + this.pad(d.getHours()) + ':' + this.pad(d.getMinutes());
            },
            approvedCount: function () {
                return this.rows.filter(function (row) { return row.accountant_aprove; }).length;
            },
            pendingCount: function () {
                return this.rows.filter(function (row) { return !row.accountant_aprove; }).length;
            }
        },
        created: function () {
            this.setToday();
            this.loadEmployees();
            this.loadData();
        },
        methods: {
            setToday: function () {
                var today = new Date();
                this.date_from = this.toDateInput(today);
                this.date_to = this.toDateInput(today);
            },
            toDateInput: function (date) {
                return date.getFullYear() + '-' + this.pad(date.getMonth() + 1) + '-' + this.pad(date.getDate());
            },
            pad: function (value) {
                return String(value).padStart(2, '0');
            },
            loadEmployees: function () {
                var self = this;
                fetch(urls.employees, { headers: { Accept: 'application/json' } })
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (payload.ok) {
                            self.employees = payload.employees || [];
                        }
                    })
                    .catch(function () {
                        self.employees = [];
                    });
            },
            loadData: function () {
                var self = this;
                if (!self.date_from || !self.date_to) {
                    Swal.fire('تنبيه', 'يجب تحديد التاريخين', 'warning');
                    return;
                }

                self.loading = true;
                self.searched = true;

                var url = new URL(urls.data, window.location.origin);
                url.searchParams.set('date_from', self.date_from);
                url.searchParams.set('date_to', self.date_to);
                if (self.employee_id && self.employee_id !== 'all') {
                    url.searchParams.set('employee_id', self.employee_id);
                }

                fetch(url, { headers: { Accept: 'application/json' } })
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (payload.ok) {
                            self.rows = payload.data || [];
                            self.totals = Object.assign({}, emptyTotals, payload.totals || {});
                        } else {
                            Swal.fire('خطأ', payload.mess || 'حدث خطأ أثناء تحميل التقرير', 'error');
                        }
                    })
                    .catch(function (error) {
                        Swal.fire('خطأ', String(error), 'error');
                    })
                    .finally(function () {
                        self.loading = false;
                    });
            },
            fmt: function (value) {
                if (value === null || value === undefined || value === '') {
                    return '-';
                }
                return Number(value || 0).toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            },
            fmtTime: function (value) {
                if (!value) {
                    return '-';
                }
                var parts = String(value).split(' ');
                if (parts.length >= 2) {
                    return parts[1].substring(0, 5);
                }
                return value;
            },
            moneyClass: function (value) {
                var number = Number(value || 0);
                if (number < 0) {
                    return 'is-negative';
                }
                if (number > 0) {
                    return 'is-positive';
                }
                return '';
            },
            printPage: function () {
                window.print();
            }
        }
    });
})();
