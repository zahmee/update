# -*- coding: utf-8 -*-
#  type: ignore

from datetime import date, datetime, timedelta
import json
import os
import sys
import send_sms as sms
import httpx
import uuid
from decimal import Decimal, ROUND_HALF_UP
import invoice_zatca
import api_helpers as api

@can_access(4001)
def index():
    return dict()


# ! important to edit
# todo : crate new one
# ? => لازم نجربها بشكل اكبر
@can_access(4001, 4002, 4006)
def getco():
    arg = request.args(0)
    qry = "select * from customers where id=%s or mobile=%s"
    custdata = db.executesql(qry, placeholders=[arg, arg], as_dict=True)
    lastpay = 0
    if custdata:
        cust_id = int(custdata[0]["id"])
        qry = (
            "update customers set total = (select sum(total_after_discount) from invoice_master "
            " where payment_method=3 and customer = %s ) , "
            " payed=( select sum(amount) from customers_pay where customers_id = %s) , "
            " amount = (select sum(total_after_discount) from invoice_master where "
            " payment_method=3 and customer = %s ) "
            " -( select sum(amount) from customers_pay where customers_id = %s) "
            " where id = %s"
        )
        db.executesql(qry, placeholders=[cust_id, cust_id, cust_id, cust_id, cust_id])
        cus = (
            db(db.customers_pay.customers_id == cust_id)
            .select(
                db.customers_pay.ALL,
                orderby=~db.customers_pay.modified_on,
                limitby=(0, 1),
            )
            .first()
        )
        if cus:
            now = datetime.now()
            lastpay = (now - cus.modified_on).days
        else:
            lastpay = 0
        qry = "select * from customers where id=%s"
        custdata = db.executesql(qry, placeholders=[cust_id], as_dict=True)
        custdata[0]["lastpay"] = lastpay
        if custdata[0]["payed"] == None:
            custdata[0]["payed"] = 0
        if custdata[0]["amount"] == None:
            custdata[0]["amount"] = custdata[0]["payed"] * -1
    return response.json(api.api_ok(data=custdata))


@can_access(4001, 4002)
def get_payment_method():
    q = db(db.key_payment_method.id > 0).select()
    return response.json(api.api_ok(data=q))


@can_access(4001, 4002)
def getit():
    try:
        # qry = "select (select name from items_main where item_id= items_det.item_id limit 1) as name,* from items_det where id=" + request.vars.itid +" and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
        itid = request.vars.itid
        qry = (
            "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
            " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
            " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
            " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
            " supplier_inv  from items_det where id=" + itid 
        )
        data = db.executesql(qry, as_dict=True)
        if data:
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id="
                    + str(qr.id)
                    + " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json(api.api_ok(data=[]))
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        else:
            qry = (
                "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
                " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
                " supplier_inv  from items_det where item_id='"+itid+"' order by id desc  limit 1 "
            )
            data = db.executesql(qry, as_dict=True)
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id="
                    + str(qr.id)
                    + " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json(api.api_ok(data=[]))
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        return response.json(api.api_ok(data=data))
    except Exception as e:
        db.rollback()
        return response.json(api.api_ok(data=[]))


@can_access(4001)
def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(4001)
def invoice():
    return dict()


'''
    p = sms.SMS()
    ms = """
    halooooooo
    احمد بن محمد
    كيفك
    """
    print(p.send('966557565667', ms))
    print(p.getbalance())

'''
round_up = invoice_zatca.round_up

@can_access(4001)
def save():
    try:
        itm = request.vars
        qr = ""
        uuid = itm["uuid"]
        messg = ""
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            return response.json(api.api_error(mess="تم حفظ هذه الفاتورة من", err="5", invno="0"))
        to = 0.0
        vat_to = 0.0
        TaxableAmount =0.0
        to_lien_sum = 0.0
        csr_config = db(db.csr_config.id > 0).select().first()
        for i in itm["itm"]:
            it = db.items_det(i["id"])
            if it.items_count != None:
                db.items_det[i["id"]] = dict(
                    items_count=it.items_count - float(i["count"])
                )
            i["name"] = i["name"] if i["name"] else "صنف عام تجميل"
            count = round_up(i["count"])
            public_price = round_up(i["public_price"])
            vat = round_up(i["vat"])
            vat_str = (vat * (count * public_price))
            vat_total = round_up(vat_str)
            total_str = vat_total + (count * public_price )
            total = round_up(total_str)
            if vat  > 0 :
                TaxableAmount = TaxableAmount + float(count * public_price)
            db.invoice_details.insert(
                item_number=i["id"],
                item_count=count,
                uuid=uuid,
                vat=vat,
                amount=public_price,
                total=total ,
                discount=0.0,
                total_after_discount=total ,
                vat_total=vat_total ,
            )
            # تسجيل حركة بيع
            db.items_movement.insert(
                item_main=it.item_idr,
                item_det=int(i["id"]),
                move_type="بيع",
                move_date=request.now,
                qty_in=0, qty_out=count,
                unit_price=public_price,
                reference="فاتورة بيع",
                ref_no=uuid,
            )
            i["total"] = total
            i["vat_mount"] = vat_total
            i["count"] = count
            i["public_price"] = public_price
            i["vat"] = vat
            to += float(total)
            vat_to += float(vat_total)
            line_str = (float(i["count"]) * float(i["public_price"]))
            to_line = round_up(line_str)
            to_lien_sum += float(to_line)
            i["LineExtensionAmount"] =  round_up(to_line)
        invno = db.invoice_master.insert(
            customer=itm["customer"],
            total=round_up(to)  ,
            payment_method=itm["method"],
            total_after_discount=round_up(to) ,
            uuid=uuid,
            vat=round_up(vat_to),
        )
        itm["total"] = to
        itm["vat"] = vat_to
        itm["LineExtensionAmount"] = to_lien_sum
        itm["TaxableAmount"] = round_up(TaxableAmount)
        itm["totalAfterAll"] = to
        db.commit()
        costmer = db.customers[itm["customer"]]
        re_ms = {}
        if costmer.mobile:
            if len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS(sms_authorization, sms_sender)
                ms = (
                    "شكرا لزيارتك "
                    + configuration.name
                    + " تم شراء فاتورة بمبلغ "
                    + str(itm["totalAfterAll"] or "0.0")
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)

        ##---------------  توقيع الفاتورة محلياً + تسجيلها في الجدول الوسيط
        if csr_config and csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0:
            inv_type = "SIMSI"
            itm["invoice_number"] = str(invno)
            json_inv = invoice_zatca.generate_invoice_json(db, itm, inv_type)
            json_inv_dict = json_inv if isinstance(json_inv, dict) else json.loads(json_inv)
            json_inv_dict["icv_start"] = int(csr_config.icv or 1)
            json_inv_dict["pih_base64"] = csr_config.pih or ""
            try:
                from zatca_direct.invoice_processor import sign_only
                sign_result = sign_only(json_inv_dict)
                qr = sign_result.get("qr_value", "")
                pih_txt = sign_result.get("pih_base64", "")
                inv_update = db.invoice_master[invno]
                inv_update.update_record(pih_txt=pih_txt, qr_code=qr)
                icv_new = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=icv_new, pih=pih_txt)
            except Exception as exc:
                messg = str(exc)
            json_inv_str = json.dumps(json_inv_dict, ensure_ascii=False)
            db.invoice_sending.insert(
                inv_type=1,
                inv_id=invno,
                inv_date=datetime.now().strftime("%Y-%m-%d"),
                inv_time=datetime.now().strftime("%H:%M:%S"),
                inv_data=json_inv_str,
                send=False
            )
        db.commit()
        return response.json(api.api_ok(data={"invno": invno, "sms": re_ms, "qr": qr}, mess=messg, invno=invno, err=1, sms=re_ms, qr=qr))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


# =================================================================================================================================================
# مرتجع البيع
@can_access(4002)
def inv_return():
    return dict()


@can_access(4002)
def inv_return_save():
    try:
        return response.json(api.api_error(mess="not implemented", err=3, invno=0))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


@can_access(4002)
def saver():
    try:
        itm = request.vars
        qr = ""
        uuid = itm["uuid"]
        messg = ""
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            return response.json(api.api_error(mess="تم حفظ هذه الفاتورة من", err="5", invno="0"))
        to = 0.0
        vat_to = 0.0
        TaxableAmount =0.0
        to_lien_sum = 0.0
        csr_config = db(db.csr_config.id > 0).select().first()
        for i in itm["itm"]:
            it = db.items_det(i["id"])
            if it.items_count != None:
                db.items_det[i["id"]] = dict(
                    items_count=it.items_count - float(i["count"])
                )
            i["name"] = i["name"] if i["name"] else "صنف عام تجميل"
            count = round_up(i["count"])
            public_price = round_up(i["public_price"])
            vat = round_up(i["vat"])
            vat_str = (vat * (count * public_price))
            vat_total = round_up(vat_str)
            total_str = vat_total + (count * public_price )
            total = round_up(total_str)
            if vat  > 0 :
                TaxableAmount = TaxableAmount + float(count * public_price)
            db.inv_return_details.insert(
                item_number=i["id"],
                item_count=count,
                uuid=uuid,
                vat=vat,
                amount=public_price,
                total=total ,
                discount=0.0,
                total_after_discount=total ,
                vat_total=vat_total ,
            )
            # تسجيل حركة مرتجع بيع
            db.items_movement.insert(
                item_main=it.item_idr,
                item_det=int(i["id"]),
                move_type="مرتجع بيع",
                move_date=request.now,
                qty_in=count, qty_out=0,
                unit_price=public_price,
                reference="مرتجع بيع",
                ref_no=uuid,
            )
            i["total"] = total
            i["vat_mount"] = vat_total
            i["count"] = count
            i["public_price"] = public_price
            i["vat"] = vat
            to += float(total)
            vat_to += float(vat_total)
            line_str = (float(i["count"]) * float(i["public_price"]))
            to_line = round_up(line_str)
            to_lien_sum += float(to_line)
            i["LineExtensionAmount"] =  round_up(to_line)
            invno = db.inv_return_master.insert(
                customer=itm["customer"],
                total=round_up(to)  ,
                payment_method=itm["method"],
                total_after_discount=round_up(to) ,
                uuid=uuid,
                vat=round_up(vat_to),
            )
        itm["total"] = to
        itm["vat"] = vat_to
        itm["LineExtensionAmount"] = to_lien_sum
        itm["TaxableAmount"] = round_up(TaxableAmount)
        itm["totalAfterAll"] = to
        db.commit()
        #=============================================  توقيع المرتجع محلياً + تسجيله في الجدول الوسيط
        if csr_config and csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0:
            inv_type = "SIMCN"
            itm["invoice_number"] = str(invno)
            json_inv = invoice_zatca.generate_invoice_json(db, itm, inv_type)
            json_inv_dict = json_inv if isinstance(json_inv, dict) else json.loads(json_inv)
            json_inv_dict["icv_start"] = int(csr_config.icv or 1)
            json_inv_dict["pih_base64"] = csr_config.pih or ""
            try:
                from zatca_direct.invoice_processor import sign_only
                sign_result = sign_only(json_inv_dict)
                qr = sign_result.get("qr_value", "")
                pih_txt = sign_result.get("pih_base64", "")
                inv_update = db.inv_return_master[invno]
                inv_update.update_record(pih_txt=pih_txt, qr_code=qr)
                icv_new = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=icv_new, pih=pih_txt)
            except Exception as exc:
                messg = str(exc)
            json_inv_str = json.dumps(json_inv_dict, ensure_ascii=False)
            db.invoice_sending.insert(
                inv_type=2,
                inv_id=invno,
                inv_date=datetime.now().strftime("%Y-%m-%d"),
                inv_time=datetime.now().strftime("%H:%M:%S"),
                inv_data=json_inv_str,
                send=False
            )
        db.commit()
        return response.json(api.api_ok(data={"invno": invno, "qr": qr}, mess=messg, invno=invno, err=1, qr=qr))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


# ==========================================       نهاية مرتجع البيع  ==============================================================================
# تقارير الفواتير و المبيعات
# -----------------------------------------------------------------------------


@can_access(8101)
def inv_rep1():
    return dict()


@can_access(8102)
def rep_bydate():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.invoice_master.created_on >= request.vars.da1)
        & (db.invoice_master.created_on <= request.vars.da2)
    ).select()
    return response.json(api.api_ok(data=s))


@can_access(8103)
def rep_bydate2():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.inv_return_master.created_on >= request.vars.da1)
        & (db.inv_return_master.created_on <= request.vars.da2)
    ).select()
    return response.json(api.api_ok(data=s))


@can_access(8104)
def rep_bydate3():
    # sum = db.invoice_master.total_after_discount.sum()
    s = (
        "select EXTRACT(HOUR FROM created_on),count(*),sum(total_after_discount) from invoice_master "
        " where created_on >= %s::timestamp and created_on <= %s::timestamp "
        " group by EXTRACT(HOUR FROM created_on) order by EXTRACT(HOUR FROM created_on) "
    )
    custdata = db.executesql(s, placeholders=[request.vars.da1, request.vars.da2], as_dict=True)
    return response.json(api.api_ok(data=custdata))


# ==============================================================  استعراض فاتورة مسجلة  =================================================================
@can_access(4003)
def inv_view():
    sc = screens_rules(4003)
    return dict(sc=sc)


@can_access(4003, 4006)
def inv_view_1():
    if request.args(0) == "1":
        qry = db.invoice_master[request.args(1)]
        if qry:
            qry.pyer = (
                (qry.created_by.first_name or "")
                + " "
                + (qry.created_by.last_name or "")
            )
            data = db(
                (db.invoice_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.invoice_details.uuid == qry.uuid)
            ).select(
                (db.invoice_details.item_number).with_alias("item_number"),
                (db.invoice_details.amount).with_alias("amount"),
                (db.invoice_details.item_count).with_alias("item_count"),
                (db.invoice_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.invoice_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""
    else:
        qry = db.inv_return_master[request.args(1)]
        if qry:
            qry.pyer = qry.created_by.first_name + " " + qry.created_by.last_name
            data = db(
                (db.inv_return_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.inv_return_details.uuid == qry.uuid)
            ).select(
                (db.inv_return_details.item_number).with_alias("item_number"),
                (db.inv_return_details.amount).with_alias("amount"),
                (db.inv_return_details.item_count).with_alias("item_count"),
                (db.inv_return_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.inv_return_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""


@can_access(4003, 4006)
def inv_view_2():
    sc = screens_rules(4003)
    if sc.can_delete:
        if request.args(0) == "1":
            qry1 = db.invoice_master[request.args(1)]
            db(db.invoice_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"
        else:
            qry1 = db.inv_return_master[request.args(1)]
            db(db.inv_return_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"


# بحث عن عميل
@can_access(4001, 4002)
def search_c():
    # q = db.items_main[request.vars.itid]
    newstr = request.vars.itid  # .replace("'", "")
    # qry = "select * from items_main where name::text like '%"+str(newstr)+"%'  LIMIT 10 ;"
    q = db(db.customers.name.like("%" + newstr + "%")).select()
    return response.json(api.api_ok(data=q))


# =================================================================================================================================================
@can_access(4006)
def delete_inv():
    return dict()


@can_access(4004)
def invoice_show():
    q = db.invoice_master.customer
    db.invoice_master.created_on.readable = True
    headers = {
        "invoice_master.id": "رقم الفاتورة",
        "invoice_master.customer": "العميل",
        "invoice_master.payment_method": "طريقة الدفع",
        "invoice_master.total_after_discount": "صافي الفااتورة",
        "invoice_master.vat": "الضريبة",
        "invoice_master.created_on": "تاريخ و وقت الفاتورة",
        "invoice_master.send_to_zatca": "تم الارسال",
    }
    fields = [
        db.invoice_master.id,
        db.invoice_master.customer,
        db.invoice_master.payment_method,
        db.invoice_master.total_after_discount,
        db.invoice_master.vat,
        db.invoice_master.created_on,
        db.invoice_master.send_to_zatca,
    ]
    links = [
        lambda row: A(
            SPAN(_class="fad fa-print fa-lg"),
            _role="button",
            _title="طباعة الفاتورة",
            _target="_blank",
            _href=URL("invoice", "invoice_print", args=[row.id]),
        ),
        lambda row: A(
            SPAN(_class="fad fa-list fa-lg"),
            _role="button",
            _title="عرض الحالة",
            _target="_blank",
            _href=URL("invoice", "show_zatca_status", args=[row.id]),
        ),
    ]
    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.invoice_master.id,
    )
    return dict(grid=grid)


@can_access(4004)
def invoice_print():
    return dict()

@can_access(4004)
def show_zatca_status():
    get_inv = db.invoice_master(request.args(0))
    data = json.loads(get_inv.zatca_res)
    return response.json(api.api_ok(data=data))

@can_access(4005)
def invoice_show_return():
    q = db.inv_return_master.customer
    db.inv_return_master.created_on.readable = True
    headers = {
        "inv_return_master.id": "رقم الفاتورة",
        "inv_return_master.customer": "العميل",
        "inv_return_master.payment_method": "طريقة الدفع",
        "inv_return_master.total_after_discount": "صافي الفااتورة",
        "inv_return_master.vat": "الضريبة",
        "inv_return_master.created_on": "تاريخ و وقت الفاتورة",
        "inv_return_master.send_to_zatca": "تم الارسال",
    }
    fields = [
        db.inv_return_master.id,
        db.inv_return_master.customer,
        db.inv_return_master.payment_method,
        db.inv_return_master.total_after_discount,
        db.inv_return_master.vat,
        db.inv_return_master.created_on,
        db.inv_return_master.send_to_zatca,
    ]
    links = [
        lambda row: A(
            SPAN(_class="fad fa-print fa-lg"),
            _role="button",
            _title="طباعة الفاتورة",
            _target="_blank",
            _href=URL("invoice", "invoice_return_print", args=[row.id]),
        ),
        lambda row: A(
            SPAN(_class="fad fa-list fa-lg"),
            _role="button",
            _title="عرض الحالة",
            _target="_blank",
            _href=URL("invoice", "show_zatca_status", args=[row.id]),
        ),
    ]
    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.inv_return_master.id,
    )
    return dict(grid=grid)


@can_access(4005)
def invoice_return_print():
    return dict()

@can_access(4005)
def show_return_zatca_status():
    get_inv = db.inv_return_master(request.args(0))
    data = json.loads(get_inv.zatca_res)
    return response.json(api.api_ok(data=data))

