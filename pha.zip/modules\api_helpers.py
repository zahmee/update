# -*- coding: utf-8 -*-
"""
وحدة توحيد استجابات APIs
Unified API Response Helpers
"""


def api_ok(data=None, mess="", **extra):
    """
    استجابة نجاح موحدة
    api_ok(data={"id": 5})
    api_ok(data=record, mess="تم الحفظ بنجاح")
    api_ok(data={"invno": 10}, invno=10, qr="...")  # backward-compat extra fields
    """
    r = {"ok": True, "status": 1, "mess": mess, "data": data}
    r.update(extra)
    return r


def api_error(mess="", data=None, **extra):
    """
    استجابة خطأ موحدة
    api_error(mess="لم يتم العثور على السجل")
    api_error(mess=e)  # Exception object — auto str()
    api_error(mess="خطأ", err=3, invno=0)  # backward-compat
    """
    r = {"ok": False, "status": 0, "mess": str(mess), "data": data}
    r.update(extra)
    return r


def api_list(rows, count, **extra):
    """
    استجابة قائمة مع عدد (pagination)
    api_list(rows=qry, count=total)
    """
    r = {"ok": True, "status": 1, "mess": "", "data": rows, "count": count}
    r.update(extra)
    return r


def api_safe(db_conn=None):
    """
    ديكوريتر لمعالجة الأخطاء تلقائياً مع db.rollback()

    Usage:
        import api_helpers as api

        def my_endpoint():
            @api.api_safe(db_conn=db)
            def _do():
                # business logic ...
                return api.api_ok(data=result)
            return response.json(_do())
    """
    def decorator(fn):
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except Exception as e:
                if db_conn is not None:
                    db_conn.rollback()
                return api_error(mess=e)
        return wrapper
    return decorator
