# -*- coding: utf-8 -*-
"""Conservative supplier cleanup, preview snapshots and atomic selective application.

No application globals or financial calculations. Missing values and supplier status
are review findings, never inferred defaults. All writes are restricted to the
fields explicitly owned by the selected operation.
"""

import hashlib
import json
import re
import secrets
import time
from collections import Counter


PREVIEW_TTL = 15 * 60
MAX_BATCH = 500
FIELDS = ("id", "name", "tel", "address", "note", "bank_account", "stoped", "modified_on")
FIELD_LABELS = {"name": "اسم المورد", "tel": "هواتف المورد", "address": "العنوان",
                "note": "الملاحظات", "bank_account": "البيانات البنكية"}
OPERATIONS = (
    dict(key="names", title="تنسيق الأسماء", icon="text", kind="cleanup",
         description="إزالة المسافات الزائدة مع الحفاظ على الاسم وحالة الأحرف.", fields=("name",)),
    dict(key="phones", title="تنظيم الهواتف", icon="phone-alt", kind="cleanup",
         description="فصل القيم القديمة إلى أسطر وإزالة الأسطر المكررة تمامًا.", fields=("tel",)),
    dict(key="texts", title="العناوين والملاحظات", icon="align-right", kind="cleanup",
         description="ترتيب المسافات والأسطر مع الحفاظ على الكلمات والفقرات.", fields=("address", "note")),
    dict(key="bank", title="تنظيم البيانات البنكية", icon="university", kind="cleanup",
         description="فصل القيم وتنظيف أطراف الأسطر دون تغيير أرقام الحسابات.", fields=("bank_account",)),
    dict(key="missing", title="فحص البيانات الناقصة", icon="clipboard-list", kind="review",
         description="مراجعة الأسماء والهواتف والعناوين الناقصة وحالات الإيقاف غير المحددة.", fields=()),
    dict(key="duplicates", title="مراجعة الأسماء المتكررة", icon="clone", kind="review",
         description="اكتشاف الأسماء المتطابقة بعد تنسيق المسافات وحالة الأحرف، للمراجعة.", fields=()),
)
OPERATION_MAP = {operation["key"]: operation for operation in OPERATIONS}


class MaintenanceError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def operation_for(key):
    if not isinstance(key, str) or key not in OPERATION_MAP:
        raise MaintenanceError("اختر أداة صيانة صحيحة.")
    return OPERATION_MAP[key]


def _name(value):
    if value is None:
        return None
    cleaned = re.sub(r"\s+", " ", value).strip()
    # Do not replace an unknown/blank name with another empty representation.
    return cleaned if cleaned else value


def _lines(value, *, collapse_spaces=False, deduplicate=False):
    if value is None:
        return None
    # A delimiter is a boundary, not permission to join phone/account numbers.
    lines = value.replace("\r\n", "\n").replace("\r", "\n").replace("|", "\n").split("\n")
    result = []
    seen = set()
    for line in lines:
        line = re.sub(r"[^\S\n]+", " ", line).strip() if collapse_spaces else line.strip()
        if deduplicate:
            if not line or line in seen:
                continue
            seen.add(line)
        elif not line and (not result or not result[-1]):
            continue
        result.append(line)
    return "\n".join(result).strip()


def proposed_changes(row, operation):
    config = operation_for(operation)
    changes = []
    for field in config["fields"]:
        before = row[field]
        if operation == "names":
            after = _name(before)
        elif operation == "phones":
            after = _lines(before, deduplicate=True)
        else:
            after = _lines(before, collapse_spaces=(operation == "texts"))
        if after != before:
            changes.append(dict(field=field, label=FIELD_LABELS[field], before=before, after=after))
    return changes


def _name_key(row):
    return (_name(row["name"]) or "").strip().casefold()


def _missing(row):
    issues = [FIELD_LABELS[field] + " غير مسجل" for field in ("name", "tel", "address")
              if not (row[field] or "").replace("|", "").strip()]
    if row["stoped"] is None:
        issues.append("حالة إيقاف المورد غير محددة")
    return issues


def load_rows(db, ids=None, lock=False):
    table = db.suppliers
    query = table.id > 0 if ids is None else table.id.belongs(ids)
    options = dict(orderby=table.id)
    if lock and db._adapter.dbengine == "postgres":
        options["for_update"] = True
    return [row.as_dict() for row in db(query).select(*[table[field] for field in FIELDS], **options)]


def summarize(rows):
    counts = {}
    cleanup_ids = set()
    for operation in OPERATIONS:
        if operation["kind"] == "cleanup":
            affected = {row["id"] for row in rows if proposed_changes(row, operation["key"])}
            counts[operation["key"]] = len(affected)
            cleanup_ids.update(affected)
    counts["missing"] = sum(bool(_missing(row)) for row in rows)
    duplicates = Counter(_name_key(row) for row in rows if _name_key(row))
    counts["duplicates"] = sum(duplicates[_name_key(row)] > 1 for row in rows if _name_key(row))
    return dict(total=len(rows), cleanup=len(cleanup_ids), missing=counts["missing"],
                duplicate_groups=sum(count > 1 for count in duplicates.values()), counts=counts)


def _fingerprint(row, operation):
    snapshot = dict(row={field: row[field] for field in FIELDS}, changes=proposed_changes(row, operation))
    encoded = json.dumps(snapshot,
                         ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def preview(rows, operation, user_id, now=None):
    config = operation_for(operation)
    now = time.time() if now is None else now
    name_counts = Counter(_name_key(row) for row in rows if _name_key(row))
    records = []
    fingerprints = {}
    total = 0
    for row in rows:
        changes = proposed_changes(row, operation)
        issues = []
        if operation == "missing":
            issues = _missing(row)
        elif operation == "duplicates" and _name_key(row) and name_counts[_name_key(row)] > 1:
            issues = ["الاسم مطابق بعد التنسيق لدى %s موردين؛ تحقّق من هوية كل مورد قبل أي تعديل." % name_counts[_name_key(row)]]
        if not changes and not issues:
            continue
        total += 1
        if config["kind"] == "cleanup" and len(records) >= MAX_BATCH:
            continue
        records.append(dict(id=row["id"], name=row["name"] or "مورد بلا اسم",
                            stopped=row["stoped"], changes=changes, issues=issues))
        if changes:
            fingerprints[str(row["id"])] = _fingerprint(row, operation)
    plan = None
    if fingerprints:
        plan = dict(token=secrets.token_urlsafe(32), operation=operation, user_id=user_id,
                    created_at=now, fingerprints=fingerprints)
    return dict(operation=operation, kind=config["kind"], records=records, total=total,
                truncated=total > len(records), token=plan["token"] if plan else None), plan


def apply(db, plan, token, selected_ids, user_id, now=None):
    """Apply only reviewed fields. Caller commits with its audit event or rolls back."""
    now = time.time() if now is None else now
    if not isinstance(plan, dict) or plan.get("user_id") != user_id:
        raise MaintenanceError("أعد المعاينة قبل تطبيق التغييرات.", 409)
    if not isinstance(token, str) or not secrets.compare_digest(plan.get("token", ""), token):
        raise MaintenanceError("المعاينة غير صالحة؛ أعد تحميلها ثم حاول مجددًا.", 409)
    if not 0 <= now - plan["created_at"] <= PREVIEW_TTL:
        raise MaintenanceError("انتهت صلاحية المعاينة؛ أعد الفحص لعرض البيانات الحالية.", 409)
    operation = plan["operation"]
    config = operation_for(operation)
    if config["kind"] != "cleanup":
        raise MaintenanceError("هذه الأداة مخصصة للمراجعة فقط.")
    if (not isinstance(selected_ids, list) or not selected_ids or len(selected_ids) > MAX_BATCH
            or any(type(value) is not int or value <= 0 for value in selected_ids)
            or len(set(selected_ids)) != len(selected_ids)):
        raise MaintenanceError("اختر موردًا واحدًا على الأقل من نتائج المعاينة، دون تكرار.")
    if any(str(value) not in plan["fingerprints"] for value in selected_ids):
        raise MaintenanceError("يتضمن الاختيار موردًا لم تتم معاينته؛ أعد الفحص.", 409)

    rows = load_rows(db, sorted(selected_ids), lock=True)
    if len(rows) != len(selected_ids) or any(
            _fingerprint(row, operation) != plan["fingerprints"][str(row["id"])] for row in rows):
        raise MaintenanceError("تغيّرت بيانات أحد الموردين منذ المعاينة. لم تُطبَّق العملية؛ أعد الفحص.", 409)

    updated_fields = 0
    for row in rows:
        changes = proposed_changes(row, operation)
        # Compare-and-set is a second guard, including on adapters without row locks.
        query = db.suppliers.id == row["id"]
        for field in FIELDS[1:]:
            query &= db.suppliers[field] == row[field]
        updates = {change["field"]: change["after"] for change in changes}
        if not updates or db(query).update(**updates) != 1:
            raise MaintenanceError("تغيّرت البيانات أثناء التنفيذ. أعد المعاينة قبل المحاولة مجددًا.", 409)
        updated_fields += len(updates)
    return dict(updated=len(rows), fields=updated_fields, operation=operation)
