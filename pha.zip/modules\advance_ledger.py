# -*- coding: utf-8 -*-
"""سجل سداد السلف — المصدر الوحيد لتغيير emp_advances.paid_amount.

كل سداد صف في emp_advance_payment، ثم يُعاد حساب المسدد والحالة من مجموع السجل (recompute):
- payroll:  «خصم سلفة» في مسير معتمد، يوزَّع على سلف الموظف المفتوحة الأقدم أولاً.
- reversal: عكسه بالسالب عند إلغاء اعتماد الفترة، فتعود السلفة مفتوحة بما كانت عليه.
- cash:     سداد مباشر من الموظف دون خصم من الراتب.
- settle:   تسوية (إعفاء من المتبقي أو جزء منه)؛ للمدير فقط، وسببها إلزامي.
- opening:  ما سُدِّد قبل تفعيل السجل ولم يمكن نسبته إلى مسير.

خصم المسير مفتاحه الموظف + شهر المسير وسنته، ولا يُطبَّق منه إلا ما لم يُسجَّل بعد؛ لذلك لا تخصم
إعادة الاعتماد مرتين (كانت تفعل قبل السجل). الدوال لا تنفّذ commit؛ المستدعي يفعل.
"""

from collections import defaultdict
from datetime import date, datetime

DEDUCTION_NAME = "خصم سلفة"
EPS = 0.005

SOURCES = {
    "payroll": "خصم من الراتب",
    "reversal": "عكس اعتماد المسير",
    "cash": "سداد مباشر",
    "settle": "تسوية",
    "opening": "مسدد سابق",
}
MANUAL = ("cash", "settle")
_PAYROLL = ("payroll", "reversal")
_BACKFILL_LOCK = "emp_advance_payment_backfill"
_BACKFILL_NOTE = "ترحيل آلي من مسير معتمد سابق"


class LedgerError(ValueError):
    """رفض بسبب البيانات؛ رسالته عربية تُعرض للمستخدم كما هي."""


def _pg(db):
    return getattr(db._adapter, "dbengine", "") == "postgres"


def _money(value):
    return round(float(value or 0), 2)


def _day(value):
    return value.date() if isinstance(value, datetime) else value


def deduction_item_id(db):
    """بند «خصم سلفة» في key_allowance_deduction، أو None إن لم يُعرَّف في الفرع."""
    t = db.key_allowance_deduction
    row = db((t.name == DEDUCTION_NAME) & (t.ad_type == "خصم")).select(
        t.id, orderby=t.id, limitby=(0, 1)).first()
    return row.id if row else None


def lock_advances(db, ids=None, employees=None):
    """يقفل صفوف السلف حتى نهاية المعاملة بترتيب المعرّف، فلا يتعارض مساران على السلفة نفسها."""
    if not _pg(db):
        return
    if employees:
        db.executesql("SELECT id FROM emp_advances WHERE employee = ANY(%s) ORDER BY id FOR UPDATE",
                      placeholders=[sorted({int(e) for e in employees})])
    if ids:
        db.executesql("SELECT id FROM emp_advances WHERE id = ANY(%s) ORDER BY id FOR UPDATE",
                      placeholders=[sorted({int(i) for i in ids})])


def ledger_total(db, advance_id):
    t = db.emp_advance_payment
    total = t.amount.sum()
    return _money(db(t.advance == advance_id).select(total).first()[total])


def recompute(db, advance_id, when=None):
    """يكتب المسدد = مجموع السجل، والحالة منه. تاريخ الإقفال تاريخ الدفعة التي أكملت السلفة."""
    adv = db.emp_advances(advance_id)
    if not adv:
        return None
    paid = ledger_total(db, advance_id)
    closed = _money(adv.amount) > 0 and paid >= _money(adv.amount) - EPS
    closed_date = None
    if closed:
        closed_date = adv.closed_date if (adv.is_closed and adv.closed_date) else (_day(when) or date.today())
    adv.update_record(paid_amount=paid, is_closed=closed, closed_date=closed_date)
    return paid


def _open_advances(db, employee):
    a = db.emp_advances
    rows = db(a.employee == employee).select(orderby=a.advance_date | a.id)
    return [r for r in rows if not r.is_closed and _money(r.amount) - _money(r.paid_amount) > EPS]


def _period_targets(db, month, year, deduction_id):
    """[(الموظف، أول مسير له في الشهر، مجموع «خصم سلفة»)] لمسيرات الشهر."""
    p, d = db.payroll, db.payroll_detail
    first, total = p.id.min(), d.amount.sum()
    rows = db((p.pay_month == month) & (p.pay_year == year) & (d.payroll_id == p.id)
              & (d.allowance_deduction == deduction_id)).select(
        p.employee, first, total, groupby=p.employee, orderby=p.employee)
    return [(r.payroll.employee, r[first], _money(r[total])) for r in rows if _money(r[total]) > EPS]


def _applied(db, employee, month, year):
    t = db.emp_advance_payment
    total = t.amount.sum()
    return _money(db((t.employee == employee) & (t.pay_month == month) & (t.pay_year == year)
                     & t.source.belongs(_PAYROLL)).select(total).first()[total])


def apply_period(db, period, today=None):
    """اعتماد فترة: يخصم «خصم سلفة» لكل موظف من سلفه المفتوحة (الأقدم أولاً) بقدر ما لم يُسجَّل
    له بعد في هذا الشهر. excess: خصم في المسير يزيد عن المتبقي على الموظف [(الموظف، المبلغ)]."""
    today = today or date.today()
    ensure_backfill(db, today)
    out = {"rows": 0, "amount": 0.0, "excess": []}
    deduction_id = deduction_item_id(db)
    if not deduction_id:
        return out
    targets = _period_targets(db, period.pay_month, period.pay_year, deduction_id)
    if not targets:
        return out
    lock_advances(db, employees=[t[0] for t in targets])
    touched = set()
    for employee, payroll_id, target in targets:
        need = _money(target - _applied(db, employee, period.pay_month, period.pay_year))
        for adv in _open_advances(db, employee) if need > EPS else ():
            take = _money(min(need, _money(adv.amount) - _money(adv.paid_amount)))
            db.emp_advance_payment.insert(
                advance=adv.id, employee=employee, amount=take, pay_date=today, source="payroll",
                pay_month=period.pay_month, pay_year=period.pay_year, period_id=period.id,
                payroll_id=payroll_id, note="")
            touched.add(adv.id)
            out["rows"] += 1
            out["amount"] += take
            need = _money(need - take)
            if need <= EPS:
                break
        if need > EPS:
            out["excess"].append((employee, need))
    for adv_id in sorted(touched):
        recompute(db, adv_id, today)
    out["amount"] = _money(out["amount"])
    return out


def reverse_period(db, period, today=None):
    """إلغاء اعتماد فترة: يعكس بالسالب صافي ما خُصم لكل سلفة في هذا الشهر، فتعود مفتوحة."""
    today = today or date.today()
    ensure_backfill(db, today)
    t = db.emp_advance_payment
    total = t.amount.sum()
    rows = db((t.pay_month == period.pay_month) & (t.pay_year == period.pay_year)
              & t.source.belongs(_PAYROLL)).select(
        t.advance, t.employee, total, groupby=t.advance | t.employee, orderby=t.advance)
    nets = [(r.emp_advance_payment.advance, r.emp_advance_payment.employee, _money(r[total]))
            for r in rows if _money(r[total]) > EPS]
    out = {"rows": 0, "amount": 0.0}
    if not nets:
        return out
    lock_advances(db, ids=[n[0] for n in nets])
    note = "إلغاء اعتماد مسير %d/%d" % (period.pay_month, period.pay_year)
    for adv_id, employee, net in nets:
        t.insert(advance=adv_id, employee=employee, amount=-net, pay_date=today, source="reversal",
                 pay_month=period.pay_month, pay_year=period.pay_year, period_id=period.id, note=note)
        recompute(db, adv_id, today)
        out["rows"] += 1
        out["amount"] += net
    out["amount"] = _money(out["amount"])
    return out


def add_manual(db, advance_id, amount, pay_date, source, note="", today=None, expected_paid=None):
    """سداد مباشر من الموظف (cash) أو تسوية (settle). expected_paid: المسدد الذي رآه المستخدم؛
    يُرفض الحفظ إن تغيّر منذ فتح النافذة (خصم مسير أو سداد آخر في الأثناء)."""
    today = today or date.today()
    if source not in MANUAL:
        raise LedgerError("نوع السداد غير معروف")
    ensure_backfill(db, today)
    lock_advances(db, ids=[advance_id])
    adv = db.emp_advances(advance_id)
    if not adv:
        raise LedgerError("السلفة غير موجودة")
    paid = _money(adv.paid_amount)
    if expected_paid is not None and abs(_money(expected_paid) - paid) > EPS:
        raise LedgerError("تغيّر المسدد من هذه السلفة منذ فتح النافذة؛ أعد فتح البطاقة وراجع المتبقي")
    remaining = _money(_money(adv.amount) - paid)
    if adv.is_closed or remaining <= EPS:
        raise LedgerError("السلفة مسددة بالكامل")
    amount = _money(amount)
    if amount <= 0:
        raise LedgerError("المبلغ يجب أن يكون أكبر من صفر")
    if amount > remaining + EPS:
        raise LedgerError("المبلغ %.2f أكبر من المتبقي على السلفة %.2f" % (amount, remaining))
    pay_date = _day(pay_date) or today
    if pay_date > today:
        raise LedgerError("تاريخ السداد لا يمكن أن يكون مستقبلياً")
    if adv.advance_date and pay_date < adv.advance_date:
        raise LedgerError("تاريخ السداد قبل تاريخ السلفة")
    note = (note or "").strip()[:255]
    if source == "settle" and not note:
        raise LedgerError("اكتب سبب التسوية")
    pid = db.emp_advance_payment.insert(advance=adv.id, employee=adv.employee, amount=amount,
                                        pay_date=pay_date, source=source, note=note)
    recompute(db, adv.id, pay_date)
    return pid


def delete_manual(db, payment_id, today=None):
    """يحذف سداداً مباشراً أو تسوية ويعيد حساب السلفة. خصم المسير لا يُحذف؛ يُعكس بإلغاء الاعتماد."""
    t = db.emp_advance_payment
    row = t(payment_id)
    if not row:
        raise LedgerError("الدفعة غير موجودة")
    if row.source not in MANUAL:
        raise LedgerError("خصم المسير لا يُحذف من هنا؛ يُعكس بإلغاء اعتماد فترته")
    lock_advances(db, ids=[row.advance])
    if not t(row.id):
        raise LedgerError("الدفعة غير موجودة")
    db(t.id == row.id).delete()
    recompute(db, row.advance, today)
    return row


def ensure_backfill(db, today=None):
    """يملأ السجل من المسيرات المعتمدة مرة واحدة لكل فرع، قبل أول كتابة فيه.

    لا يعمل إلا والسجل فارغ. لا يغيّر المسدد إلا لسلفة أُقفلت يدوياً وعليها متبقٍّ، فتُسجَّل
    بالمتبقي تسوية؛ فيصير مجموع السجل = paid_amount لكل سلفة. يعيد الخطة إن كتب، وإلا None.
    """
    t, a = db.emp_advance_payment, db.emp_advances
    if not db(t.id > 0).isempty():
        return None
    if db((a.paid_amount > EPS) | (a.is_closed == True)).isempty():
        return None
    if _pg(db):
        db.executesql("SELECT pg_advisory_xact_lock(hashtext(%s))", placeholders=[_BACKFILL_LOCK])
        if not db(t.id > 0).isempty():  # سبقه طلب آخر
            return None
    plan = backfill_plan(db, today)
    for row in plan["rows"]:
        t.insert(**row)
    for adv_id, when in plan["settled"]:
        recompute(db, adv_id, when)
    return plan


def backfill_plan(db, today=None):
    """يعيد تشغيل اعتماد المسيرات المعتمدة بالترتيب الزمني بالقاعدة نفسها (الأقدم أولاً)، مع
    استبعاد سلفة سُجِّلت بعد اعتماد الفترة. سلفة يطابق فيها الناتج مسددَها تأخذ صفوف المسيرات؛
    الأقل تأخذها ومعها «مسدد سابق» بالفرق؛ الأكثر (تعديل يدوي سابق) تأخذ «مسدد سابق» واحداً."""
    today = today or date.today()
    a = db.emp_advances
    advances = db(a.id > 0).select(orderby=a.advance_date | a.id)
    by_employee = defaultdict(list)
    for adv in advances:
        by_employee[adv.employee].append(adv)
    replayed = defaultdict(float)
    replay_rows = defaultdict(list)
    deduction_id = deduction_item_id(db)
    if deduction_id:
        pp = db.payroll_period
        for period in db(pp.is_approved == True).select(orderby=pp.pay_year | pp.pay_month | pp.id):
            approved_at = period.modified_on or period.created_on
            for employee, payroll_id, need in _period_targets(db, period.pay_month, period.pay_year,
                                                             deduction_id):
                for adv in by_employee.get(employee, ()):
                    if need <= EPS:
                        break
                    if approved_at and adv.created_on and adv.created_on > approved_at:
                        continue
                    left = _money(_money(adv.amount) - replayed[adv.id])
                    if left <= EPS:
                        continue
                    take = _money(min(need, left))
                    replayed[adv.id] = _money(replayed[adv.id] + take)
                    need = _money(need - take)
                    replay_rows[adv.id].append(dict(
                        advance=adv.id, employee=employee, amount=take, pay_date=_day(approved_at) or today,
                        source="payroll", pay_month=period.pay_month, pay_year=period.pay_year,
                        period_id=period.id, payroll_id=payroll_id, note=_BACKFILL_NOTE))

    rows, settled = [], []
    report = {"advances": len(advances), "matched": 0, "partial": 0, "unmatched": 0, "settled": 0}
    for adv in advances:
        paid, got = _money(adv.paid_amount), _money(replayed[adv.id])
        day = adv.closed_date or _day(adv.modified_on) or adv.advance_date or today

        def opening(value):
            return dict(advance=adv.id, employee=adv.employee, amount=_money(value), pay_date=day,
                        source="opening", note="سُدِّد قبل تفعيل السجل ولم يُعرف مصدره")

        own = []
        if paid <= EPS:
            if got > EPS:
                report["unmatched"] += 1
        elif abs(got - paid) <= 0.01:
            own = replay_rows[adv.id]
            own[-1]["amount"] = _money(own[-1]["amount"] + paid - got)
            report["matched"] += 1
        elif got < paid:
            own = replay_rows[adv.id] + [opening(paid - got)]
            report["partial"] += 1
        else:
            own = [opening(paid)]
            report["unmatched"] += 1
        remainder = _money(_money(adv.amount) - paid)
        if adv.is_closed and remainder > EPS:
            own.append(dict(advance=adv.id, employee=adv.employee, amount=remainder, pay_date=day,
                            source="settle", note="أُقفلت يدوياً قبل تفعيل السجل وعليها هذا المتبقي"))
            settled.append((adv.id, day))
            report["settled"] += 1
        rows.extend(own)
    return {"rows": rows, "settled": settled, "report": report}
