# -*- coding: utf-8 -*-
"""تسوية بيانات الأصناف — المنطق المشترك بين سطر الأوامر وشاشة جودة البيانات.

مصدر واحد يستدعيه:
  scripts/item_supplier_backfill.py   (مورد الصنف)
  scripts/item_data_cleanup.py        (الأسماء، الضريبة، الباركود، الدفعات، الراكد)
  controllers/item_quality.py         (زر التسوية في الشاشة)

لا يغيّر بنية القاعدة: لا إنشاء جدول ولا تعديل عمود ولا حذف صف. كل ما يكتبه
تحديث قيم في أعمدة قائمة (المورد، الاسم، الضريبة، الباركود، علم الإيقاف)
وإضافة صفوف في دفتر الباركود السابق وسجل الإيقاف. ولا يمس الكميات ولا دفتر الحركات:
قبل الالتزام يتحقق أن إجمالي الأرصدة وعدد الحركات كما كانا، وإلا تراجع عن كل شيء.
كل تنفيذ يحفظ القيم القديمة في ملف تراجع داخل private/.
"""
import json
import os
import re

import item_rules

HALALA_ID = 1  # صنف "هلله" الوهمي: باركوده "1" مقصود، ورقم دفعته الأولى 1 أيضاً
LOCK_KEY = 918273645  # قفل استشاري يمنع تشغيلين متزامنين

ACTIONS = [
    dict(key="supplier", title="مورد الصنف من آخر توريد",
         detail="الصنف بلا مورد أو مورده موقوف يأخذ مورد آخر توريد له من مورد نشط. "
                "الصنف الذي له مورد نشط لا يُمس."),
    dict(key="names", title="توحيد مسافات الأسماء",
         detail="إزالة المسافات الزائدة من أسماء الأصناف دون تغيير الحروف."),
    dict(key="vat", title="نسبة ضريبة للدفعات الفارغة",
         detail="الدفعة التي فيها رصيد بلا نسبة ضريبة تأخذ نسبة آخر دفعة للصنف نفسه، "
                "بدل النسبة القديمة المخزنة في بطاقة الصنف."),
    dict(key="barcodes", title="استبدال الباركود الخطر",
         detail="الباركود الرقمي الأقصر من 8 خانات أو الوهمي يُستبدل بباركود داخلي 2990، "
                "وتنتقل دفعات الصنف معه ويُحفظ القديم كباركود سابق. يُنتج ملف إكسل للملصقات."),
    dict(key="realign", title="إعادة ربط الدفعات المنفصلة",
         detail="الدفعة التي اختلف نص باركودها عن باركود صنفها تأخذ باركود الصنف، "
                "فتظهر باسمها في نقطة البيع."),
    dict(key="dormant", title="إيقاف الأصناف الراكدة",
         detail="الصنف المُنشأ قبل سنتين بلا رصيد وبلا شراء أو بيع منذ سنتين يُوقف، "
                "إلا إذا فعّله مستخدم يدوياً خلال السنتين. "
                "الإيقاف يُخرجه من إعادة الطلب ولا يمنع بيعه."),
    dict(key="reactivate", title="رفع الإيقاف عن الأصناف النشطة",
         detail="الصنف الموقوف الذي عليه رصيد، أو اشتُري أو بيع خلال السنة الأخيرة، يُرفع إيقافه. "
                "يصحح الإيقاف القديم غير المقصود، ولا يمس صنفاً أوقفه مستخدم يدوياً."),
]
ACTION_KEYS = [a["key"] for a in ACTIONS]

VAT_SOURCE = """
    SELECT DISTINCT ON (item_idr) item_idr, vat FROM items_det
    WHERE vat IS NOT NULL ORDER BY item_idr, id DESC
"""
LAST_ACTIVE_CTE = """
WITH last_active AS (
    SELECT DISTINCT ON (d.item_idr) d.item_idr, sb.supplier
    FROM items_det d
    JOIN suppliers_bills sb ON sb.id = d.supplier_inv
    JOIN suppliers s ON s.id = sb.supplier AND COALESCE(s.stoped, 'F') <> 'T'
    ORDER BY d.item_idr, d.id DESC
),
last_any AS (
    SELECT DISTINCT ON (d.item_idr) d.item_idr, sb.supplier
    FROM items_det d
    JOIN suppliers_bills sb ON sb.id = d.supplier_inv
    WHERE sb.supplier IS NOT NULL
    ORDER BY d.item_idr, d.id DESC
)
"""
# القرار اليدوي (زر الإيقاف/التفعيل في بطاقة الصنف) لا تنقضه القواعد التلقائية:
# الراكد لا يوقف صنفاً فعّله مستخدم خلال مدة الركود، والمراجعة لا ترفع إيقافاً
# آخرُ أحداثه قرار يدوي بالإيقاف (صنف أُوقف عمداً وما زال يُصرَّف رصيده).
DORMANT_WHERE = """
    COALESCE(im.halt, 'F') <> 'T' AND im.id <> %s AND COALESCE(im.track_stock, 'T') <> 'F'
    AND (im.created_on IS NULL OR im.created_on < now() - interval '730 days')
    AND ABS(COALESCE((SELECT SUM(items_count) FROM items_det d WHERE d.item_idr = im.id), 0)) <= 0.000001
    AND NOT EXISTS (SELECT 1 FROM items_det d WHERE d.item_idr = im.id AND d.created_on >= now() - interval '730 days')
    AND NOT EXISTS (SELECT 1 FROM items_det d JOIN invoice_details x ON x.item_number = d.id
                    WHERE d.item_idr = im.id AND x.created_on >= now() - interval '730 days')
    AND NOT EXISTS (SELECT 1 FROM item_halt_log hl WHERE hl.item_idr = im.id AND hl.source = 'manual'
                    AND hl.halt = 'F' AND hl.created_on >= now() - interval '730 days')
"""
# النشط = عليه رصيد (موجب أو سالب) أو له توريد أو بيع خلال السنة الأخيرة (قرار المالك
# 2026-09-18: الإيقاف القديم لم يكن مقصوداً). لا يتقاطع مع الراكد: ذاك بلا رصيد ولا حركة سنتين.
REACTIVATE_WHERE = """
    im.halt = 'T' AND im.id <> %s AND COALESCE(im.track_stock, 'T') <> 'F'
    AND (
        ABS(COALESCE((SELECT SUM(items_count) FROM items_det d WHERE d.item_idr = im.id), 0)) > 0.000001
        OR EXISTS (SELECT 1 FROM items_det d WHERE d.item_idr = im.id AND d.created_on >= now() - interval '365 days')
        OR EXISTS (SELECT 1 FROM items_det d JOIN invoice_details x ON x.item_number = d.id
                   WHERE d.item_idr = im.id AND x.created_on >= now() - interval '365 days')
    )
    AND NOT EXISTS (SELECT 1 FROM item_halt_log hl WHERE hl.item_idr = im.id AND hl.source = 'manual'
                    AND hl.halt = 'T'
                    AND hl.id = (SELECT MAX(h2.id) FROM item_halt_log h2 WHERE h2.item_idr = im.id))
"""


# ------------------------------------------------------------------ التخطيط
def plan_supplier(db):
    return db.executesql(
        LAST_ACTIVE_CTE + """
        SELECT im.id, im.suppliers AS old_sup, la.supplier AS new_sup,
               (lany.supplier = la.supplier) AS from_latest
        FROM items_main im
        LEFT JOIN last_active la ON la.item_idr = im.id
        LEFT JOIN last_any lany ON lany.item_idr = im.id
        WHERE """ + item_rules.NO_ACTIVE_SUPPLIER_SQL,
        as_dict=True,
    )


def plan_names(db):
    return db.executesql(
        "SELECT id, name, REGEXP_REPLACE(TRIM(name), '\\s+', ' ', 'g') AS new_name FROM items_main"
        " WHERE name <> TRIM(name) OR name ~ '\\s{2,}'",
        as_dict=True,
    )


def plan_vat(db):
    return db.executesql(
        "SELECT d.id, d.item_idr, lv.vat AS new_vat FROM items_det d"
        " LEFT JOIN (" + VAT_SOURCE + ") lv ON lv.item_idr = d.item_idr"
        " WHERE d.vat IS NULL AND d.items_count > 0",
        as_dict=True,
    )


def plan_barcodes(db):
    det_owner = dict(db.executesql("SELECT id, item_idr FROM items_det"))
    rows = db.executesql(
        "SELECT im.id, im.item_id, UPPER(im.name) AS name, COALESCE(im.halt, 'F') AS halt,"
        " COALESCE((SELECT SUM(items_count) FROM items_det d WHERE d.item_idr = im.id), 0) AS stock"
        " FROM items_main im"
        " WHERE im.id <> %s AND COALESCE(im.track_stock, 'T') <> 'F'",
        placeholders=[HALALA_ID],
        as_dict=True,
    )
    out = []
    for r in rows:
        code = (r["item_id"] or "").strip()
        if not re.fullmatch(r"[0-9]+", code):
            continue  # غير الرقمي (ومنه رقم التسجيل كباركود) يُترك للمراجعة اليدوية
        short = len(code) < item_rules.MIN_DIGITS
        fake = item_rules.is_placeholder(code)
        if not (short or fake):
            continue
        owner = det_owner.get(int(code)) if len(code) <= 9 else None
        collides = owner is not None and owner != r["id"]
        if fake:
            reason = "باركود وهمي"
        elif collides:
            reason = "قصير ويطابق رقم دفعة صنف آخر (م %s): يُباع الصنف الخطأ عند إدخاله" % owner
        else:
            reason = "قصير (أقل من 8 خانات): سيتعارض مع أرقام الدفعات"
        r.update(reason=reason, fake=fake, collides=collides)
        out.append(r)
    return out


def plan_realign(db):
    return db.executesql(
        "SELECT d.id, d.item_idr, d.item_id AS old_code, im.item_id AS new_code,"
        " EXISTS (SELECT 1 FROM items_main o WHERE o.item_id = d.item_id AND o.id <> im.id) AS other_live"
        " FROM items_det d JOIN items_main im ON im.id = d.item_idr"
        " WHERE COALESCE(d.item_id, '') <> COALESCE(im.item_id, '')",
        as_dict=True,
    )


def plan_dormant(db):
    return [r[0] for r in db.executesql("SELECT im.id FROM items_main im WHERE " + DORMANT_WHERE,
                                        placeholders=[HALALA_ID])]


def plan_reactivate(db):
    return [r[0] for r in db.executesql("SELECT im.id FROM items_main im WHERE " + REACTIVATE_WHERE,
                                        placeholders=[HALALA_ID])]


def plan(db, actions=None):
    """تقرير فقط: عدد ما سيتغير في كل إصلاح ونبذة عنه. لا يكتب شيئاً."""
    actions = [a for a in (actions or ACTION_KEYS) if a in ACTION_KEYS]
    out = {}
    if "supplier" in actions:
        rows = plan_supplier(db)
        ready = [r for r in rows if r["new_sup"]]
        out["supplier"] = dict(count=len(ready), rows=rows, note=(
            "%d صنفاً بلا مورد نشط، منها %d له توريد من مورد نشط يؤخذ منه، و%d ينتظر أول توريد."
            % (len(rows), len(ready), len(rows) - len(ready))))
    if "names" in actions:
        rows = plan_names(db)
        out["names"] = dict(count=len(rows), rows=rows, note="%d اسماً فيه مسافات زائدة." % len(rows))
    if "vat" in actions:
        rows = plan_vat(db)
        fill = [r for r in rows if r["new_vat"] is not None]
        out["vat"] = dict(count=len(fill), rows=rows, note=(
            "%d دفعة فيها رصيد بلا نسبة ضريبة، تُعبأ %d ويبقى %d بلا مصدر في صنفه."
            % (len(rows), len(fill), len(rows) - len(fill))))
    if "barcodes" in actions:
        rows = plan_barcodes(db)
        out["barcodes"] = dict(count=len(rows), rows=rows, note=(
            "%d باركوداً: %d يطابق رقم دفعة صنف آخر، %d قصير، %d وهمي."
            % (len(rows), sum(1 for r in rows if r["collides"]),
               sum(1 for r in rows if not r["collides"] and not r["fake"]),
               sum(1 for r in rows if r["fake"]))))
    if "realign" in actions:
        rows = plan_realign(db)
        out["realign"] = dict(count=len(rows), rows=rows, note=(
            "%d دفعة في %d صنفاً، منها %d باركودها مسجل لصنف آخر."
            % (len(rows), len({r["item_idr"] for r in rows}), sum(1 for r in rows if r["other_live"]))))
    if "dormant" in actions:
        ids = plan_dormant(db)
        out["dormant"] = dict(count=len(ids), rows=ids, note="%d صنفاً راكداً يُوقف." % len(ids))
    if "reactivate" in actions:
        ids = plan_reactivate(db)
        out["reactivate"] = dict(count=len(ids), rows=ids, note=(
            "%d صنفاً موقوفاً عليه رصيد أو تحرّك خلال السنة الأخيرة يُرفع إيقافه." % len(ids)))
    return out


# ------------------------------------------------------------------ التنفيذ
def _invariants(db):
    """ما يجب ألا يتغير: إجمالي الأرصدة وعدد حركات المخزون."""
    return (
        round(float(db.executesql("SELECT COALESCE(SUM(items_count), 0) FROM items_det")[0][0]), 6),
        db.executesql("SELECT COUNT(*) FROM items_movement")[0][0],
    )


def _active_snapshot(db):
    return set(db.executesql(
        "SELECT im.id, im.suppliers FROM items_main im WHERE NOT (" + item_rules.NO_ACTIVE_SUPPLIER_SQL + ")"))


def _do_supplier(db, rows, backup):
    backup["supplier"] = [{"id": r["id"], "old_supplier": r["old_sup"], "new_supplier": r["new_sup"]}
                          for r in rows if r["new_sup"]]
    db.executesql(
        LAST_ACTIVE_CTE + """
        UPDATE items_main im SET suppliers = la.supplier
        FROM last_active la
        WHERE la.item_idr = im.id AND """ + item_rules.NO_ACTIVE_SUPPLIER_SQL
    )
    return len(backup["supplier"])


def _do_names(db, rows, backup):
    backup["names"] = [{"id": r["id"], "old": r["name"]} for r in rows]
    db.executesql(
        "UPDATE items_main SET name = REGEXP_REPLACE(TRIM(name), '\\s+', ' ', 'g')"
        " WHERE name <> TRIM(name) OR name ~ '\\s{2,}'"
    )
    return len(rows)


def _do_vat(db, rows, backup):
    fill = [r for r in rows if r["new_vat"] is not None]
    backup["vat"] = [{"batch": r["id"], "new_vat": r["new_vat"]} for r in fill]
    if fill:
        db.executesql(
            "UPDATE items_det d SET vat = lv.vat FROM (" + VAT_SOURCE + ") lv"
            " WHERE lv.item_idr = d.item_idr AND d.vat IS NULL AND d.items_count > 0"
        )
    return len(fill)


def _do_barcodes(db, rows, backup, stamp):
    done = []
    for r in rows:
        old_code = r["item_id"]
        new_code = item_rules.next_internal_barcode(db)
        batch_ids = [b[0] for b in db.executesql(
            "SELECT id FROM items_det WHERE item_idr = %s", placeholders=[r["id"]])]
        db.executesql("UPDATE items_main SET item_id = %s WHERE id = %s",
                      placeholders=[new_code, r["id"]])
        # بالصنف لا بالنص: الرقم الوهمي/القصير قد يتكرر نصاً في دفعات أصناف أخرى
        db.executesql("UPDATE items_det SET item_id = %s WHERE item_idr = %s",
                      placeholders=[new_code, r["id"]])
        alias = None
        stripped = old_code.strip()[:20]
        if not r["fake"] and stripped and not db.executesql(
            "SELECT 1 FROM item_barcode_alias WHERE barcode = %s", placeholders=[stripped]
        ):
            db.item_barcode_alias.insert(
                item_idr=r["id"], barcode=stripped,
                note="تسوية %s: باركود قصير استُبدل بـ %s" % (stamp[:8], new_code))
            alias = stripped
        done.append(dict(id=r["id"], name=r["name"], old=old_code, new=new_code, alias=alias,
                         batches=batch_ids, reason=r["reason"], stock=float(r["stock"] or 0),
                         halt=r["halt"]))
    backup["barcodes"] = done
    return done


def _do_realign(db, rows, backup, stamp):
    aliases, seen = [], set()
    for r in rows:
        old = (r["old_code"] or "").strip()[:20]
        key = (r["item_idr"], old)
        if key in seen or not old or r["other_live"]:
            continue
        seen.add(key)
        if item_rules.barcode_errors(old):
            continue  # لا يُحفظ رقم قصير أو وهمي كباركود سابق
        if db.executesql("SELECT 1 FROM item_barcode_alias WHERE barcode = %s", placeholders=[old]):
            continue
        if item_rules.barcode_owner(db, old, exclude_id=r["item_idr"]):
            continue
        db.item_barcode_alias.insert(item_idr=r["item_idr"], barcode=old,
                                     note="تسوية %s: باركود دفعات منفصلة" % stamp[:8])
        aliases.append({"item": r["item_idr"], "barcode": old})
    backup["realign"] = {"batches": [{"batch": r["id"], "old": r["old_code"]} for r in rows],
                         "aliases": aliases}
    db.executesql(
        "UPDATE items_det d SET item_id = im.item_id FROM items_main im"
        " WHERE im.id = d.item_idr AND COALESCE(d.item_id, '') <> COALESCE(im.item_id, '')"
    )
    return len(rows), aliases


def _log_halt(db, ids, halt, source, now, user_id):
    """صف في سجل الإيقاف لكل صنف تغيّر علمه (كما يكتب item_rules.set_halt للصنف الواحد)."""
    if ids:
        db.executesql(
            "INSERT INTO item_halt_log (item_idr, halt, source, note, created_on, created_by)"
            " SELECT unnest(%s::int[]), %s, %s, %s, %s, %s",
            placeholders=[ids, "T" if halt else "F", source, "تسوية الأصناف", now, user_id],
        )


def _do_dormant(db, backup, now, user_id):
    ids = [r[0] for r in db.executesql(
        "UPDATE items_main im SET halt = 'T' WHERE " + DORMANT_WHERE + " RETURNING im.id",
        placeholders=[HALALA_ID])]
    backup["dormant"] = ids
    _log_halt(db, ids, True, "dormant", now, user_id)
    return len(ids)


def _do_reactivate(db, backup, now, user_id):
    ids = [r[0] for r in db.executesql(
        "UPDATE items_main im SET halt = 'F' WHERE " + REACTIVATE_WHERE + " RETURNING im.id",
        placeholders=[HALALA_ID])]
    backup["reactivate"] = ids
    _log_halt(db, ids, False, "review", now, user_id)
    return len(ids)


def write_barcode_excel(db, folder, stamp, done):
    """ملف الأصناف التي استُبدل باركودها: لإعادة طباعة ملصقاتها ولمسح الباركود الحقيقي لاحقاً."""
    import xlsxwriter

    last_sale = dict(db.executesql(
        "SELECT d.item_idr, MAX(x.created_on)::date FROM invoice_details x"
        " JOIN items_det d ON d.id = x.item_number WHERE d.item_idr = ANY(%s) GROUP BY d.item_idr",
        placeholders=[[d["id"] for d in done]],
    )) if done else {}
    name = "item_barcode_review_%s.xlsx" % stamp
    path = os.path.join(folder, "private", name)
    wb = xlsxwriter.Workbook(path)
    ws = wb.add_worksheet("باركود مستبدل")
    ws.right_to_left()
    head = wb.add_format({"bold": True, "bg_color": "#176b52", "font_color": "#ffffff", "border": 1})
    cell = wb.add_format({"border": 1})
    code = wb.add_format({"border": 1, "num_format": "@"})
    danger = wb.add_format({"border": 1, "font_color": "#b91c1c", "bold": True})
    cols = ["م", "اسم الصنف", "الباركود القديم", "الباركود الداخلي الجديد", "السبب", "الرصيد",
            "آخر بيع", "موقوف", "الباركود الحقيقي من العلبة (يُكتب يدوياً)", "ملاحظة"]
    widths = [8, 42, 16, 18, 48, 10, 12, 8, 30, 20]
    for c, (t, w) in enumerate(zip(cols, widths)):
        ws.write(0, c, t, head)
        ws.set_column(c, c, w)
    ordered = sorted(done, key=lambda x: (not x["reason"].startswith("قصير ويطابق"), -abs(x["stock"])))
    for i, d in enumerate(ordered, start=1):
        ws.write(i, 0, d["id"], cell)
        ws.write(i, 1, d["name"], cell)
        ws.write_string(i, 2, d["old"], code)
        ws.write_string(i, 3, d["new"], code)
        ws.write(i, 4, d["reason"], danger if d["reason"].startswith("قصير ويطابق") else cell)
        ws.write(i, 5, round(d["stock"], 2), cell)
        ws.write(i, 6, str(last_sale.get(d["id"]) or ""), cell)
        ws.write(i, 7, "نعم" if d["halt"] == "T" else "", cell)
        ws.write(i, 8, "", cell)
        ws.write(i, 9, "", cell)
    ws.freeze_panes(1, 0)
    ws.autofilter(0, 0, max(len(done), 1), len(cols) - 1)
    wb.close()
    return name


def apply(db, folder, now, actions, user_id=None):
    """ينفّذ الإصلاحات المختارة في معاملة واحدة.

    يعيد dict فيه: applied (عدد كل إصلاح)، backup (اسم ملف التراجع)،
    excel (اسم ملف الباركود إن وُجد)، problems (إن فشل التحقق فلا يُكتب شيء).
    user_id يُسجَّل في سجل الإيقاف (فارغ من سطر الأوامر).
    """
    actions = [a for a in (actions or []) if a in ACTION_KEYS]
    if not actions:
        return dict(applied={}, problems=["لم يُحدَّد أي إصلاح."], backup=None, excel=None)
    # قفل استشاري: تشغيلان متزامنان على نفس القاعدة يتعارضان
    if not db.executesql("SELECT pg_try_advisory_xact_lock(%s)", placeholders=[LOCK_KEY])[0][0]:
        return dict(applied={}, problems=["التسوية قيد التشغيل الآن من جلسة أخرى."],
                    backup=None, excel=None)

    stamp = now.strftime("%Y%m%d_%H%M%S")
    backup = {"stamp": stamp, "actions": actions}
    before = _invariants(db)
    before_active = _active_snapshot(db) if "supplier" in actions else None
    plans = plan(db, actions)
    applied, excel, barcode_done = {}, None, []
    try:
        if "supplier" in actions:
            applied["supplier"] = _do_supplier(db, plans["supplier"]["rows"], backup)
        if "names" in actions:
            applied["names"] = _do_names(db, plans["names"]["rows"], backup)
        if "vat" in actions:
            applied["vat"] = _do_vat(db, plans["vat"]["rows"], backup)
        if "barcodes" in actions:
            barcode_done = _do_barcodes(db, plans["barcodes"]["rows"], backup, stamp)
            applied["barcodes"] = len(barcode_done)
        if "realign" in actions:
            rows = plan_realign(db)  # بعد الباركود: القائمة تتغير
            applied["realign"] = _do_realign(db, rows, backup, stamp)[0] if rows else 0
        if "dormant" in actions:
            applied["dormant"] = _do_dormant(db, backup, now, user_id)
        if "reactivate" in actions:
            applied["reactivate"] = _do_reactivate(db, backup, now, user_id)

        problems = []
        after = _invariants(db)
        if before != after:
            problems.append("تغيّر إجمالي الأرصدة أو عدد الحركات: %s ← %s" % (before, after))
        if before_active is not None and not before_active <= _active_snapshot(db):
            problems.append("تغيّر مورد صنف كان له مورد نشط")
        left = plan(db, actions)
        for key in actions:
            if key in ("supplier", "vat"):
                continue  # يبقى ما لا مصدر له (بلا توريد نشط أو بلا نسبة في أي دفعة)
            if left[key]["count"]:
                problems.append("بقي %d في «%s»" % (left[key]["count"],
                                                    [a["title"] for a in ACTIONS if a["key"] == key][0]))
        if problems:
            db.rollback()
            return dict(applied={}, problems=problems, backup=None, excel=None)

        backup_name = "item_data_cleanup_%s.json" % stamp
        with open(os.path.join(folder, "private", backup_name), "w", encoding="utf-8") as f:
            json.dump(backup, f, ensure_ascii=False, default=str)
        if barcode_done:
            excel = write_barcode_excel(db, folder, stamp, barcode_done)
        db.commit()
        return dict(applied=applied, problems=[], backup=backup_name, excel=excel,
                    aliases=len(backup.get("realign", {}).get("aliases", [])))
    except Exception:
        db.rollback()
        raise
