# -*- coding: utf-8 -*-
"""ترميز باركود الملصقات (بلا web2py): يعيد سلسلة وحدات 1/0 يرسمها المتصفح مستطيلات.

يعتمد على حزمة python-barcode (أُضيفت بـ uv add python-barcode في جذر web2py).
الرقم الدولي يُرمَّز EAN-13 / EAN-8 / UPC-A فقط إذا كانت خانة التحقق صحيحة، لأن
الحزمة تعيد حساب خانة التحقق بصمت فيخرج رقم مختلف عن المخزَّن ولا تجده نقطة البيع.
وإلا يُرمَّز النص كما هو Code128 (يقبل الأرقام والحروف اللاتينية والرموز فقط).
رقم الدفعة يُرمَّز دائماً Code128 (المجموعة C للأرقام: مضغوط وقابل للمسح).
"""
import re

QUIET = {"EAN13": (11, 7), "EAN8": (7, 7), "UPCA": (9, 9), "CODE128": (10, 10)}
_SYMBOLOGY = {13: ("EAN13", "ean13"), 8: ("EAN8", "ean8"), 12: ("UPCA", "upca")}
_CODE128_RE = re.compile(r"^[\x20-\x7e]+$")


class BarcodeUnavailable(Exception):
    """حزمة python-barcode غير مثبتة."""


def gs1_check_digit(body):
    """خانة التحقق وفق GS1 لأرقام الجسم (الخانات عدا الأخيرة)."""
    total = 0
    for i, ch in enumerate(reversed(body)):
        total += int(ch) * (3 if i % 2 == 0 else 1)
    return str((10 - total % 10) % 10)


def gs1_check_ok(code):
    """هل الرقم بطول قياسي وخانة تحقق صحيحة؟"""
    return (
        bool(code)
        and code.isdigit()
        and len(code) in (8, 12, 13, 14)
        and gs1_check_digit(code[:-1]) == code[-1]
    )


def _modules(symbology, data):
    try:
        import barcode
    except ImportError:
        raise BarcodeUnavailable("حزمة python-barcode غير مثبتة على الخادم")
    return barcode.get(symbology, data).build()[0]


def _pad(sym, bars):
    left, right = QUIET[sym]
    bars = "0" * left + bars + "0" * right
    return {"sym": sym, "bars": bars, "modules": len(bars)}


def encode_code128(text):
    """ترميز نص (رقم الدفعة أو باركود غير قياسي) Code128، أو None إن تعذّر."""
    text = (text or "").strip()
    if not text or not _CODE128_RE.match(text):
        return None
    out = _pad("CODE128", _modules("code128", text))
    out["text"] = text
    out["note"] = None
    return out


def encode_item_code(code):
    """ترميز باركود الصنف: EAN/UPC إن صحّت خانة التحقق، وإلا Code128 بالنص كما هو.

    يعيد None إذا كان النص فارغاً أو فيه حروف لا يقبلها Code128 (مثل العربية)."""
    code = (code or "").strip()
    if not code:
        return None
    if code.isdigit() and len(code) in _SYMBOLOGY and gs1_check_ok(code):
        sym, name = _SYMBOLOGY[len(code)]
        out = _pad(sym, _modules(name, code))
        out["text"] = code
        out["note"] = None
        return out
    out = encode_code128(code)
    if out and code.isdigit() and len(code) in (8, 12, 13, 14):
        out["note"] = "خانة التحقق غير صحيحة؛ رُمِّز الرقم كما هو"
    return out


def rects(bars):
    """مستطيلات الخطوط [(x, width), ...] من سلسلة الوحدات — للاختبار ولأي رسم خادمي."""
    out = []
    start = None
    for i, ch in enumerate(bars + "0"):
        if ch == "1" and start is None:
            start = i
        elif ch != "1" and start is not None:
            out.append((start, i - start))
            start = None
    return out
