# -*- coding: utf-8 -*-
#  type: ignore
"""
طلبات الأصناف الجديدة — للأصناف غير الموجودة في النظام
Screen code: 6001
"""

from datetime import datetime
import re
import api_helpers as api
import send_sms as sms


def _valid_mobile(value):
    if not value:
        return True
    return bool(re.match(r"^(05\d{8}|9665\d{8}|\+9665\d{8})$", value))


# ===========================================================================================
# صفحة الواجهة
# ===========================================================================================
@can_access(6001)
def index():
    sc = screens_rules(6001)
    can_add = bool(sc and sc.can_add)
    can_edit = bool(sc and sc.can_edit)
    can_delete = bool(sc and sc.can_delete)
    return dict(can_add=can_add, can_edit=can_edit, can_delete=can_delete)


# ===========================================================================================
# بحث سريع — هل الصنف موجود في النظام أو في الطلبات؟
# ===========================================================================================
@can_access(6001)
def search():
    q = (request.vars.q or "").strip()
    if not q:
        return response.json(api.api_ok(data={"existing": [], "requested": []}))

    # البحث في items_main (الأصناف الموجودة)
    existing = [
        {"id": r.id, "name": r.name, "item_id": r.item_id}
        for r in db(db.items_main.name.contains(q)).select(
            db.items_main.id, db.items_main.name, db.items_main.item_id, limitby=(0, 5)
        )
    ]

    # البحث في item_requests
    requested = [r.as_dict() for r in db(db.item_requests.name.contains(q)).select(
        db.item_requests.ALL, limitby=(0, 5)
    )]

    return response.json(
        api.api_ok(
            data={
                "existing": existing,
                "requested": requested,
            }
        )
    )


# ===========================================================================================
# حفظ طلب جديد أو زيادة عدد طلب موجود
# ===========================================================================================
@can_access(6001)
def save():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        name = (data.name or "").strip()
        if not name:
            return api.api_error(mess="اسم الصنف مطلوب")

        item_id_val = (data.item_id or "").strip() or None
        customer_mobile = (data.customer_mobile or "").strip() or None
        if customer_mobile and not _valid_mobile(customer_mobile):
            return api.api_error(mess="رقم جوال العميل غير صحيح")

        # البحث عن طلب موجود بنفس الباركود أو الاسم (غير ملغي)
        existing_request = None
        if item_id_val:
            existing_request = (
                db(
                    (db.item_requests.item_id == item_id_val)
                    & (db.item_requests.status != "rejected")
                )
                .select()
                .first()
            )
        if not existing_request:
            existing_request = (
                db(
                    (db.item_requests.name == name)
                    & (db.item_requests.status != "rejected")
                )
                .select()
                .first()
            )

        if existing_request:
            # زيادة العداد وتحديث بيانات العميل (الأحدث تفوز)
            existing_request.update_record(
                request_count=existing_request.request_count + 1,
                last_request_date=datetime.now(),
                customer_name=(data.customer_name or "").strip() or existing_request.customer_name or None,
                customer_mobile=customer_mobile or existing_request.customer_mobile or None,
                notes=(data.notes or "").strip() or existing_request.notes or None,
                supplier_name=(data.supplier_name or "").strip() or existing_request.supplier_name or None,
                generic_name=(data.generic_name or "").strip() or existing_request.generic_name or None,
            )
            db.commit()
            return api.api_ok(
                data={"id": existing_request.id, "is_new": False, "request_count": existing_request.request_count},
                mess="تم تسجيل الطلب مرة أخرى (العدد: %d)" % existing_request.request_count
            )

        # إنشاء طلب جديد
        rid = db.item_requests.insert(
            name=name,
            item_id=item_id_val,
            generic_name=(data.generic_name or "").strip() or None,
            supplier_name=(data.supplier_name or "").strip() or None,
            notes=(data.notes or "").strip() or None,
            customer_name=(data.customer_name or "").strip() or None,
            customer_mobile=customer_mobile,
            request_count=1,
            last_request_date=datetime.now(),
            status="new",
        )
        db.commit()
        return api.api_ok(data={"id": rid, "is_new": True}, mess="تم تسجيل الطلب بنجاح")

    return response.json(_do())


# ===========================================================================================
# قائمة الطلبات مع فلاتر
# ===========================================================================================
@can_access(6001)
def get_list():
    try:
        ReqVar = request.vars
        pg = int(ReqVar.page or 0)
        rc = int(ReqVar.RecordCount or 20)
        status = ReqVar.status or "all"

        query = db.item_requests.id > 0
        if status != "all":
            query &= db.item_requests.status == status

        if ReqVar.SearchText and ReqVar.SearchText.strip():
            q = ReqVar.SearchText.strip()
            query &= db.item_requests.name.contains(q)

        total = db(query).count()

        rows = db(query).select(
            db.item_requests.ALL,
            orderby=~db.item_requests.request_count
            | ~db.item_requests.last_request_date,
            limitby=(pg * rc, (pg + 1) * rc),
        )

        result = []
        for r in rows:
            d = r.as_dict()
            if r.converted_to_item:
                item = db.items_main[r.converted_to_item]
                d["converted_item_name"] = item.name if item else None
            result.append(d)

        return response.json(api.api_list(rows=result, count=total))
    except Exception as e:
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# تحديث حالة الطلب
# ===========================================================================================
@can_access(6001)
def update_status():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        row = db.item_requests[data.id]
        if not row:
            return api.api_error(mess="الطلب غير موجود")

        new_status = data.status
        allowed = {"new", "ordered", "available", "notified", "rejected"}
        if new_status not in allowed:
            return api.api_error(mess="حالة غير صالحة")

        # SMS تلقائي عند available لو فيه جوال
        if new_status == "available" and row.customer_mobile:
            try:
                msg = (
                    "عزيزي العميل، الصنف '%s' أصبح متوفراً الآن في صيدليتنا." % row.name
                )
                sms.SMS(sms_authorization, sms_sender).send(row.customer_mobile, msg)
            except Exception as e:
                print("SMS auto error:", e)

        row.update_record(status=new_status)
        db.commit()
        return api.api_ok(data={"id": row.id, "status": new_status})

    return response.json(_do())


# ===========================================================================================
# تحويل طلب لصنف: لا يُنشأ هنا (2026-09-17). زر "تحويل" يفتح شاشة المواد على نافذة
# صنف جديد معبأة من الطلب (items/main?req=<id>) فيكمل الموظف التصنيف والوحدة والمورد
# والسعر، ويُربط الطلب عند الحفظ (api_1.newMainItem). الدالة القديمة convert_to_item
# كانت تُدرج صنفاً بلا تصنيف ولا وحدة ولا مورد وبسعر صفر وضريبة 15 بدل 0.15.
# ===========================================================================================


# ===========================================================================================
# إرسال SMS يدوي
# ===========================================================================================
@can_access(6001)
def send_sms_manual():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        row = db.item_requests[data.id]
        if not row or not row.customer_mobile:
            return api.api_error(mess="لا يوجد جوال مسجل لهذا الطلب")
        if not _valid_mobile(row.customer_mobile):
            return api.api_error(mess="رقم جوال العميل غير صحيح")

        msg = data.message or (
            "عزيزي العميل، الصنف '%s' أصبح متوفراً الآن في صيدليتنا." % row.name
        )
        sms.SMS(sms_authorization, sms_sender).send(row.customer_mobile, msg)
        return api.api_ok(mess="تم إرسال الرسالة")

    return response.json(_do())


# ===========================================================================================
# زيادة عدد الطلبات (+)
# ===========================================================================================
@can_access(6001)
def increment_request():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        row = db.item_requests[data.id]
        if not row:
            return api.api_error(mess="الطلب غير موجود")
        row.update_record(
            request_count=row.request_count + 1,
            last_request_date=datetime.now()
        )
        db.commit()
        return api.api_ok(data={"request_count": row.request_count})
    return response.json(_do())


# ===========================================================================================
# إنقاص عدد الطلبات (-)
# ===========================================================================================
@can_access(6001)
def decrement_request():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        row = db.item_requests[data.id]
        if not row:
            return api.api_error(mess="الطلب غير موجود")
        new_count = max(1, row.request_count - 1)
        row.update_record(request_count=new_count)
        db.commit()
        return api.api_ok(data={"request_count": new_count})
    return response.json(_do())


# ===========================================================================================
# حذف طلب
# ===========================================================================================
@can_access(6001)
def delete_request():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        row = db.item_requests[data.id]
        if not row:
            return api.api_error(mess="الطلب غير موجود")
        db(db.item_requests.id == data.id).delete()
        db.commit()
        return api.api_ok(mess="تم الحذف")

    return response.json(_do())
