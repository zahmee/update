var app = new Vue({
    el: '#app',
    data: {
        rows: [],
        stats: { pending: 0, sent: 0 },
        loading: false,
        deletingId: null,
        sendingId: null,
        filter: 'all',
        search: '',
        searchTimer: null,
        page: 1,
        perPage: 50,
        total: 0
    },
    computed: {
        totalPages: function () {
            return Math.max(Math.ceil(this.total / this.perPage), 1);
        }
    },
    mounted: function () {
        this.loadList();
    },
    methods: {
        money: function (v) {
            var n = Number(v) || 0;
            return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        loadList: function () {
            var self = this;
            self.loading = true;
            var url = window.INV_SENDING_URLS.list +
                '?filter=' + encodeURIComponent(self.filter) +
                '&page=' + self.page;
            if (self.search) url += '&q=' + encodeURIComponent(self.search);
            Api.get(url).then(function (res) {
                if (Api.isOk(res)) {
                    self.rows = Api.getData(res) || [];
                    self.total = res.count || 0;
                    self.perPage = res.per_page || self.perPage;
                    if (res.stats) self.stats = res.stats;
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.loading = false;
            });
        },
        setFilter: function (f) {
            if (this.filter === f) return;
            this.filter = f;
            this.page = 1;
            this.loadList();
        },
        onSearch: function () {
            var self = this;
            clearTimeout(self.searchTimer);
            self.searchTimer = setTimeout(function () {
                self.page = 1;
                self.loadList();
            }, 300);
        },
        goPage: function (p) {
            if (p < 1 || p > this.totalPages || p === this.page) return;
            this.page = p;
            this.loadList();
        },
        // إرسال فاتورة واحدة فقط إلى ZATCA
        sendOne: function (row) {
            var self = this;
            if (self.sendingId || self.deletingId) return;
            self.sendingId = row.id;
            var body = new FormData();
            body.append('id', row.id);
            Api.post(window.INV_SENDING_URLS.sendOne, body).then(function (res) {
                if (Api.isOk(res)) {
                    Api.showSuccess(res.mess || 'تم إرسال الفاتورة بنجاح');
                } else {
                    Api.showError(res);
                }
                self.loadList();
            }).finally(function () {
                self.sendingId = null;
            });
        },
        // حذف فوري بدون رسالة تحذير/تأكيد
        remove: function (row) {
            var self = this;
            if (self.deletingId) return;
            self.deletingId = row.id;
            var body = new FormData();
            body.append('id', row.id);
            Api.post(window.INV_SENDING_URLS.delete, body).then(function (res) {
                if (Api.isOk(res)) {
                    self.loadList();
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.deletingId = null;
            });
        }
    }
});
