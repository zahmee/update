var app = new Vue({
    el: '#app',
    data: {
        rows: [],
        stats: { pending: 0, sent: 0 },
        loading: false,
        deletingId: null,
        sendingId: null,
        filter: 'all',
        search: '',
        searchTimer: null,
        page: 1,
        perPage: 50,
        total: 0,
        ctl: null,
        ctlBusy: false
    },
    computed: {
        totalPages: function () {
            return Math.max(Math.ceil(this.total / this.perPage), 1);
        },
        ctlTitle: function () {
            var c = this.ctl;
            if (!c.paused) return 'الإرسال التلقائي يعمل';
            return c.open_ended ? 'الإرسال التلقائي موقوف حتى تستأنفه'
                                : 'الإرسال التلقائي موقوف حتى ' + c.until_label;
        },
        deadlineText: function () {
            var o = this.ctl.oldest, limit = this.digits(this.ctl.deadline_hours) + ' ساعة';
            var head = 'أقدم فاتورة منتظرة صدرت ' + o.issued_label + ' (منذ ' + this.hoursText(o.hours) + ')';
            if (o.tone === 'danger') return head + '، وتجاوزت مهلة إبلاغ الهيئة (' + limit + ').';
            if (o.tone === 'warn') return head + '، وتقترب من مهلة إبلاغ الهيئة (' + limit + ').';
            return head + '، ضمن مهلة إبلاغ الهيئة (' + limit + ').';
        }
    },
    mounted: function () {
        this.loadList();
        this.loadControl();
    },
    methods: {
        money: function (v) {
            var n = Number(v) || 0;
            return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        loadList: function () {
            var self = this;
            self.loading = true;
            var url = window.INV_SENDING_URLS.list +
                '?filter=' + encodeURIComponent(self.filter) +
                '&page=' + self.page;
            if (self.search) url += '&q=' + encodeURIComponent(self.search);
            Api.get(url).then(function (res) {
                if (Api.isOk(res)) {
                    self.rows = Api.getData(res) || [];
                    self.total = res.count || 0;
                    self.perPage = res.per_page || self.perPage;
                    if (res.stats) self.stats = res.stats;
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.loading = false;
            });
        },
        setFilter: function (f) {
            if (this.filter === f) return;
            this.filter = f;
            this.page = 1;
            this.loadList();
        },
        onSearch: function () {
            var self = this;
            clearTimeout(self.searchTimer);
            self.searchTimer = setTimeout(function () {
                self.page = 1;
                self.loadList();
            }, 300);
        },
        goPage: function (p) {
            if (p < 1 || p > this.totalPages || p === this.page) return;
            this.page = p;
            this.loadList();
        },
        // ---- التحكم في الإرسال التلقائي ----
        digits: function (v) {
            return String(v).replace(/[0-9]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.charAt(+d); });
        },
        hoursText: function (h) {
            var n = Math.floor(Number(h) || 0);
            if (n < 1) return 'أقل من ساعة';
            if (n === 1) return 'ساعة واحدة';
            if (n === 2) return 'ساعتين';
            return this.digits(n) + (n <= 10 ? ' ساعات' : ' ساعة');
        },
        historyText: function (h) {
            if (h.action === 'pause') {
                return 'إيقاف ' + (h.until_label ? 'حتى ' + h.until_label : 'حتى الاستئناف اليدوي') + ': ' + (h.msg || '');
            }
            if (h.action === 'resume') return 'استئناف يدوي';
            if (h.action === 'auto_resume') return 'استئناف تلقائي بعد انتهاء المدة';
            return h.msg || '';
        },
        loadControl: function () {
            var self = this;
            Api.get(window.INV_SENDING_URLS.control).then(function (res) {
                if (Api.isOk(res)) self.ctl = Api.getData(res);
            });
        },
        postControl: function (url, body) {
            var self = this;
            self.ctlBusy = true;
            return Api.post(url, body).then(function (res) {
                if (Api.isOk(res)) Api.showSuccess(res.mess);
                else Api.showError(res);
                self.loadControl();
            }).finally(function () {
                self.ctlBusy = false;
            });
        },
        openPause: function () {
            var self = this;
            if (self.ctlBusy) return;
            var form = document.createElement('div');
            form.className = 'pause-form';
            form.setAttribute('dir', 'rtl');
            form.innerHTML =
                '<fieldset><legend>مدة الإيقاف</legend>' +
                '<label class="opt"><input type="radio" name="pause-preset" value="1h" checked> ساعة واحدة</label>' +
                '<label class="opt"><input type="radio" name="pause-preset" value="3h"> ثلاث ساعات</label>' +
                '<label class="opt"><input type="radio" name="pause-preset" value="morning"> حتى الساعة ٦ صباحاً</label>' +
                '<label class="opt"><input type="radio" name="pause-preset" value="until"> حتى وقت أحدده' +
                ' <input type="datetime-local" id="pause-until"></label>' +
                '<label class="opt"><input type="radio" name="pause-preset" value="open"> حتى أستأنفه يدوياً</label>' +
                '</fieldset>' +
                '<p class="open-warn" id="pause-open-warn" hidden>يبقى الإرسال موقوفاً حتى تستأنفه بنفسك. مهلة إبلاغ الهيئة ٢٤ ساعة لكل فاتورة، وستظهر في الشاشة أقدم فاتورة منتظرة.</p>' +
                '<label class="reason">سبب الإيقاف<textarea id="pause-reason" maxlength="255" placeholder="مثال: صيانة في منصة الهيئة"></textarea></label>';
            var until = form.querySelector('#pause-until'), warn = form.querySelector('#pause-open-warn');
            form.addEventListener('change', function (e) {
                if (e.target.name === 'pause-preset') warn.hidden = e.target.value !== 'open';
            });
            until.addEventListener('focus', function () {
                form.querySelector('input[value="until"]').checked = true;
                warn.hidden = true;
            });
            Swal.fire({
                title: self.ctl && self.ctl.paused ? 'تعديل إيقاف الإرسال' : 'إيقاف الإرسال التلقائي',
                html: form, showCancelButton: true, confirmButtonText: 'إيقاف', cancelButtonText: 'رجوع',
                confirmButtonColor: '#b45309', focusConfirm: false,
                preConfirm: function () {
                    var preset = form.querySelector('input[name="pause-preset"]:checked').value;
                    var reason = form.querySelector('#pause-reason').value.trim();
                    if (preset === 'until' && !until.value) return Swal.showValidationMessage('حدد تاريخ ووقت الاستئناف');
                    if (reason.length < 3) return Swal.showValidationMessage('اكتب سبب الإيقاف');
                    return { preset: preset, until: until.value, reason: reason };
                }
            }).then(function (r) {
                if (!r.isConfirmed || !r.value) return;
                var body = new FormData();
                body.append('preset', r.value.preset);
                body.append('until', r.value.until);
                body.append('reason', r.value.reason);
                self.postControl(window.INV_SENDING_URLS.pause, body);
            });
        },
        resume: function () {
            var self = this;
            if (self.ctlBusy) return;
            Swal.fire({
                title: 'استئناف الإرسال التلقائي؟',
                text: 'تُرسل الفواتير المنتظرة بترتيبها في زيارة الجدولة القادمة.',
                icon: 'question', showCancelButton: true, confirmButtonText: 'استئناف', cancelButtonText: 'رجوع',
                confirmButtonColor: '#0f766e'
            }).then(function (r) {
                if (r.isConfirmed) self.postControl(window.INV_SENDING_URLS.resume, new FormData());
            });
        },
        // إرسال فاتورة واحدة فقط إلى ZATCA
        sendOne: function (row) {
            var self = this;
            if (self.sendingId || self.deletingId) return;
            self.sendingId = row.id;
            var body = new FormData();
            body.append('id', row.id);
            Api.post(window.INV_SENDING_URLS.sendOne, body).then(function (res) {
                if (Api.isOk(res)) {
                    Api.showSuccess(res.mess || 'تم إرسال الفاتورة بنجاح');
                } else {
                    Api.showError(res);
                }
                self.loadList();
                self.loadControl();
            }).finally(function () {
                self.sendingId = null;
            });
        },
        // حذف فوري بدون رسالة تحذير/تأكيد
        remove: function (row) {
            var self = this;
            if (self.deletingId) return;
            self.deletingId = row.id;
            var body = new FormData();
            body.append('id', row.id);
            Api.post(window.INV_SENDING_URLS.delete, body).then(function (res) {
                if (Api.isOk(res)) {
                    Api.showSuccess(res.mess);
                    self.loadList();
                    self.loadControl();
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.deletingId = null;
            });
        }
    }
});
