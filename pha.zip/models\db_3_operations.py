# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول العمليات: الجرد، الإتلاف، المرتجعات، أوامر الشراء، الصندوق، ZATCA، حركة الأصناف
# ===========================================================================================

# =============================================================================================================================
# جدول الجرد
db.define_table(
    "inventory",
    Field("name", length=70, label="وصف الجرد"),
    Field("inventory_date", length=16, label="تاريخ عملية الجرد"),
    Field("open", "boolean", label="عملية الجرد مفتوحة"),
    Field("to_user", "reference auth_user", label="مسندة لـ"),
    auth.signature,
    format="%(name)s",
)
db.inventory.id.label = "م"

# جدول اصناف الجرد
##sum =  db.items_det.items_count.sum()
db.define_table(
    "inventory_items",
    Field(
        "inventory",
        "reference inventory",
        default=request.args(0),
        label="وصف عملية الجرد",
    ),
    Field("items_main", "reference items_main", label="رقم الصنف "),
    Field("item_id", length=20, label="رقم الصنف "),
    Field("item_name", length=150, label="اسم الصنف"),
    Field("quantity", "double", label="الكمية الموجودة في الرف", default=0),
    Field("real_quantity", "double", label="الكمية الفعلية"),
    Field("difference", "double", label="الفرق"),
    Field("add_by_user", "reference auth_user", label="مدخل بواسطة"),
    Field("add_time", "datetime", label="وقت الادخال"),
    Field("item_row", length=4, label="الصف"),
    Field("item_column", length=4, label="العمود"),
    Field("added_later", "double", label="المضاف لاحقا"),
    Field("discounted_later", "double", label="المخصوم لاحقا"),
    Field("check_by_user", "reference auth_user", label="التشييك بواسطة"),
    Field("check_time", "datetime", label="وقت التشييك"),
    Field("check_quantity", "double", label="ادخال المراجعة"),
    Field("check_system_quantity", "double", label="كمية النظام"),
    Field("check_difference", "double", label="الفرق "),
    Field("approve", "boolean", default=False, writable=False, label="تم اعتمادة"),
    auth.signature,
)
db.inventory_items.id.label = "م"

# ==============================================================================================================================
# جدول محتضر الإتلاف
db.define_table(
    "damage_report",
    Field("name", length=270, label="وصف المحضر"),
    Field("damage_date", length=16, label="تاريخ الاتلاف"),
    Field(
        "admin_accept",
        "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدير",
    ),
    Field(
        "user_accept",
        "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدخل",
    ),
    Field("item_count", "double", default=0.0, writable=False, label="عدد الاصناف"),
    Field("item_sum", "double", default=0.0, writable=False, label="عدد المواد"),
    auth.signature,
    format="%(name)s",
)
db.damage_report.id.label = "م"
# التفاصيل
db.define_table(
    "damage_report_det",
    Field(
        "damage_report",
        "reference damage_report",
        default=request.args(0),
        label="محضر الاتلاف",
    ),
    Field("item_id", length=20, required=IS_NOT_EMPTY(), label="رقم الصنف"),
    Field(
        "item_name",
        length=270,
        writable=True,
        compute=lambda r: db.items_main[db.items_det(r["item_id"]).item_idr].name,
        label="اسم الصنف",
    ),
    Field(
        "item_count",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).items_count,
        writable=True,
        label="عدد الاصناف",
    ),
    auth.signature,
)
db.damage_report_det.id.label = "م"
# -----------------------------------------------------------------------------------------------------

# مرتجع التوريد
db.define_table(
    "returned_supply",
    Field("name", length=270, label="وصف الفاتورة"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field(
        "ret_date",
        "date",
        label="تاريخ الارجاع",
    ),
    Field("total", "double", default=0, label="الاجمالي"),
    Field("real_total", "double", default=0, writable=False, label="الاجمالي - م"),
    Field("real_total2", "double", default=0, writable=False, label="الاجمالي - ب"),
    Field("admin_accept", "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدير",
    ),
    Field(
        "user_accept",
        "boolean",
        default=False,
        readable=False,
        writable=True,
        label="معتمد من المدخل",
    ),
    Field("item_count", "double", default=0.0, writable=False, label="عدد الاصناف"),
    Field("item_sum", "double", default=0.0, writable=False, label="عدد المواد"),
    auth.signature,
    format="%(name)s",
)
db.returned_supply.id.label = "م"
# التفاصيل
db.define_table(
    "returned_supply_det",
    Field(
        "returned_supply",
        "reference returned_supply",
        default=request.args(0),
        label="وصف الفاتورة",
    ),
    Field("item_id", length=20, required=IS_NOT_EMPTY(), label="رقم الصنف"),
    Field(
        "item_name",
        length=270,
        writable=True,
        compute=lambda r: db.items_main[db.items_det(r["item_id"]).item_idr].name,
        label="اسم الصنف",
    ),
    Field(
        "vat",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).vat or 0,
        label="الضريبة",
    ),
    Field("item_count", "double", writable=True, label="عدد الاصناف"),
    Field(
        "inv_price",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).buy_price,
        label="سعر الشراء",
    ),
    Field(
        "inv_bay",
        "double",
        compute=lambda r: db.items_det(r["item_id"]).public_price,
        label="سعر البيع",
    ),
    Field(
        "total",
        "double",
        compute=lambda r: float(r.item_count * r.inv_price),
        label="الاجمالي - م",
    ),
    Field(
        "total_2",
        "double",
        compute=lambda r: float(r.item_count * r.inv_bay),
        label="الاجمالي - ب",
    ),
    auth.signature,
)
db.returned_supply_det.id.label = "م"
# ===========================================================================================
# جدول الاخطاء و التقارير عن البررنامج

db.define_table("print_report", Field("er_dis", "text", label="وصف الخطاء"))


# ===========================================================================================
# جدول الملاحظات من المستخدمين
db.define_table(
    "memo_report",
    Field("dis", "text", label="وصف الملاحظة"),
    Field("screen", length=270, label="الشاشة"),
    Field("important", "integer", readable=False, label="مدى اهميتها"),
    Field("show", "boolean", default=False, readable=False, label="استعرضها المبرمج"),
    Field("aprove", "boolean", default=False, readable=False, label="اعتمدها المبرمج"),
    Field("date_to_do", readable=False, length=150, label="تاريخ انجازها"),
    auth.signature,
)

# ===========================================================================================
# ===========================================================================================
#  جدول اوامر الشراء
db.define_table(
    "items_reorder",
    Field("dis", "text", label="وصف العملية"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("avrg_by", "double", default=4, label="المتوسط / شهر"),
    Field("order_by", "double", default=1, label="الطلب / شهر"),
    Field("order_date", "date", default=request.now, label="تاريخ العملية"),
    Field(
        "order_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    Field(
        "jop_start_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    Field(
        "jop_end_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    Field("row_count", "double", default=0, label="عدد السجلات"),
    auth.signature,
)

#  جدول اصناف اوامر الشراء
db.define_table(
    "items_reorder_detail",
    Field("items_reorder", "reference items_reorder"),
    Field("items_main", "reference items_main"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field("key_type", "reference key_type", label="التصنيف"),
    Field("quantity", "double", label="الكمية الموجودة في الرف", default=0),
    Field("avrg_items", "double", default=4, label="المتوسط "),
    Field("order_items", "double", default=1, label="الطلب "),
    Field("best_price", "double", label="افضل سعر"),
    Field("best_price_supp", "integer", label="افضل مورد"),
    Field("order_date", "date", default=request.now, label="تاريخ العملية"),
    Field(
        "order_time",
        "time",
        default=request.now.strftime("%H:%M:%S"),
        label="وقت العملية",
    ),
    auth.signature,
)
# ===========================================================================================
# جدول تسليم الفترات للصندوق
db.define_table(
    "closing_shift",
    Field("pha_user", "reference auth_user", label="المستخدم"),
    Field("start_time", "datetime", label="وقت البداية"),
    Field("end_time", "datetime", label="وقت النهاية"),
    Field("app_amount_cash", "double", label="كاش / النظام"),
    Field("app_amount_atm", "double", label="صرافة / النظام"),
    Field("app_amount_delay", "double", label="آجل / النظام"),
    Field("app_amount_customer_pay", "double", default=0, label="سداد العملاء / النظام"),
    Field("app_total", "double", readable=False, writable=True, label="اجمالي النظام"),
    Field("kashir_amount_cash", "double", label="كاش / الصندوق"),
    Field("kashir_amount_atm", "double", label="صرافة / الصندوق"),
    Field("kashir_amount_delay", "double", label="آجل / الصندوق"),
    Field("kashir_amount_customer_pay", "double", default=0, label="سداد العملاء / الصندوق"),
    Field("kashir_note", length=250, label="ملاحظات"),
    Field(
        "kashir_total", "double", readable=False, writable=True, label="اجمالي الصندوق"
    ),
    Field("accountant_aprove", "boolean", default=False, label="استلام المحاسب"),
    Field("difference", "double", label="الفرق"),
    auth.signature,
)
# ===========================================================================================
# ===========================================================================================
#  جدول الانظمة
db.define_table("systems", Field("name", length=270, label="النظام"), format="%(name)s")

# ===========================================================================================
#  جدول رسائل النظام
db.define_table(
    "public_msg",
    Field("msg_id", "integer", label="رقم الرسالة", unique=True),
    Field("msg_text", "text", label="الرسالة"),
    Field("msg_count", "integer"),
    Field("msg_max", "integer"),
)
# ===========================================================================================
#  جدول مصروفات الصندوق (قديم - محفوظ حتى يتم الترحيل فقط)
db.define_table(
    "fund_movement",
    Field("process_date", "date"),
    Field("process_type", "integer"),
    Field("detill", "text"),
    Field("amount", "double"),
    Field("aprove", "boolean", default=False),
)
# ===========================================================================================
#  جدول تصنيف حركات الصندوق (مصروفات/إيداعات)
db.define_table(
    "key_fund_category",
    Field("name_ar", length=150, label="التصنيف"),
    Field("code", length=30, label="الرمز", unique=True),
    Field("kind", length=10, default="expense", label="النوع"),  # expense | deposit
    Field("is_active", "boolean", default=True, label="فعّال"),
    auth.signature,
    format="%(name_ar)s",
)
db.key_fund_category.id.label = "م"

# ===========================================================================================
#  جدول حركات الصندوق الجديد — مصروفات وإيداعات بنموذج رقابي كامل
db.define_table(
    "fund_entry",
    Field("entry_date", "date", label="تاريخ العملية"),
    Field("kind", length=10, default="expense", label="النوع"),  # expense | deposit
    Field("category_id", "reference key_fund_category", label="التصنيف"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("amount", "double", default=0.0, label="المبلغ"),
    Field("beneficiary", length=250, label="المستفيد"),
    Field("ref_type", length=30, default="manual", label="نوع المرجع"),
    Field("ref_id", "integer", label="رقم المرجع"),
    Field("document_no", length=80, label="رقم السند"),
    Field("attachment", "upload", label="المرفق"),
    Field("description", "text", label="الوصف/الملاحظات"),
    Field("status", length=20, default="draft", label="الحالة"),  # draft | submitted | approved | rejected
    Field("submitted_by", "reference auth_user", label="مُقدِّم الطلب"),
    Field("submitted_at", "datetime", label="وقت التقديم"),
    Field("approved_by", "reference auth_user", label="المعتمد"),
    Field("approved_at", "datetime", label="وقت الاعتماد"),
    Field("rejected_reason", "text", label="سبب الرفض"),
    auth.signature,
)
db.fund_entry.id.label = "م"
# ===========================================================================================
# ===========================================================================================
db.define_table(
    "csr_config",
    Field("otp", length=6),
    Field("serial_number", length=55),
    Field("common_name", length=250),
    Field("organization_name", length=250),
    Field("organization_identifier", length=15),
    Field("organization_unit_name", length=250),
    Field("country_name", length=3),
    Field("invoice_type", length=4),
    Field("location_address", length=10),
    Field("business_category", length=200),
    Field("address_city_name", length=50),
    Field("address_street_name", length=50),
    Field("address_postal_zone", length=10),
    Field("address_building_number", length=5),
    Field("address_neighborhood", length=25),
    Field("company_id", length=15),
    Field("company_uuid", length=40),
    # step 1
    Field("privatekey", "text"),
    Field("csr", "text"),
    Field("csr_src", "text"),
    Field("egs_uuid", length=40),
    Field("ccsid_requestid", length=40),
    Field("ccsid_binarysecuritytoken", "text"),
    Field("ccsid_secret", "text"),
    # step 2
    Field("pcsid_requestid", length=40),
    Field("pcsid_binarysecuritytoken", "text"),
    Field("pcsid_secret", "text"),
    # inv nombering
    Field("icv", "integer", default=1),
    Field("pih", "text"),
    Field("api_site", "text", default="http://localhost:8011"),
    Field("environment", length=40, default="production")
)

# ===========================================================================================
#  جدول ارسال الفواتير
db.define_table(
    "invoice_sending",
    Field("inv_id", "integer"),
    Field("inv_type", "integer", default=1),
    Field("inv_date", "date"),
    Field("inv_time", "time"),
    Field("inv_data", "text"),
    Field("send", "boolean", default=False),
    # المجموع التراكمي لمبالغ الفواتير في نفس اليوم (يبدأ كل يوم بصفر)
    Field("total_sum", "double", default=0),
)

# ===========================================================================================
#  جدول حركة الأصناف
db.define_table(
    "items_movement",
    Field("item_main", "reference items_main", label="الصنف",
          requires=IS_IN_DB(db, "items_main.id", "%(name)s")),
    Field("item_det", "integer", default=0, label="تفصيل الصنف"),
    Field("move_type", length=20, label="نوع الحركة"),
    Field("move_date", "datetime", label="تاريخ الحركة"),
    Field("qty_in", "double", default=0, label="وارد"),
    Field("qty_out", "double", default=0, label="صادر"),
    Field("unit_price", "double", default=0, label="سعر الوحدة"),
    Field("reference", length=270, label="المرجع"),
    Field("ref_no", length=50, label="رقم المرجع"),
    auth.signature,
)
db.items_movement.id.label = "م"

# ============= نظام الجرد (Snapshot + Delta) =============

db.define_table(
    "inv_session",
    Field("name", length=100, notnull=True, label="اسم الجلسة"),
    Field("started_at", "datetime", default=request.now, label="وقت البدء"),
    Field("finished_at", "datetime", label="وقت الانتهاء"),
    Field("status", length=20, default="open",
          requires=IS_IN_SET(["open", "closed"]), label="الحالة"),
    Field("notes", "text", label="ملاحظات"),
    auth.signature,
    format="%(name)s",
)

db.define_table(
    "inv_count_item",
    Field("session_id", "reference inv_session", notnull=True, label="الجلسة"),
    Field("item_main", "reference items_main", notnull=True, label="الصنف",
          requires=IS_IN_DB(db, "items_main.id", "%(name)s")),
    Field("snapshot_qty", "double", default=0, label="كمية اللقطة"),
    Field("snapshot_time", "datetime", label="وقت اللقطة"),
    Field("counted_qty", "double", label="الكمية المعدودة"),
    Field("counted_at", "datetime", label="وقت إدخال العد"),
    Field("sales_delta", "double", default=0, label="مبيعات بعد اللقطة"),
    Field("purchase_delta", "double", default=0, label="مشتريات بعد اللقطة"),
    Field("adjusted_expected", "double", default=0, label="الكمية المتوقعة"),
    Field("variance", "double", default=0, label="الفرق"),
    Field("variance_reason", "text", label="سبب الفرق"),
    Field("status", length=20, default="pending",
          requires=IS_IN_SET(["pending", "counted", "confirmed"]), label="الحالة"),
    Field("counted_by", "reference auth_user", label="عدّها"),
    auth.signature,
)


# ===========================================================================================
# جدول طلبات الأصناف الجديدة (من العملاء — غير موجودة في النظام)
# ===========================================================================================
db.define_table(
    "item_requests",
    Field("name", length=200, required=True, label="اسم الصنف"),
    Field("item_id", length=50, label="الباركود / الرقم"),
    Field("generic_name", length=200, label="الاسم العلمي"),
    Field("supplier_name", length=200, label="الشركة المصنعة"),
    Field("notes", "text", label="ملاحظات (تركيز، نوع...)"),
    Field("customer_name", length=100, label="اسم العميل"),
    Field("customer_mobile", length=20, label="جوال العميل"),
    Field("request_count", "integer", default=1, writable=False, label="عدد مرات الطلب"),
    Field("last_request_date", "datetime", writable=False, label="آخر طلب"),
    Field("status", length=20, default="new", writable=False, label="الحالة",
          requires=IS_IN_SET([
              ("new", "جديد"),
              ("ordered", "تم الطلب"),
              ("available", "متاح"),
              ("notified", "تم الإبلاغ"),
              ("rejected", "ملغي")
          ])),
    Field("converted_to_item", "reference items_main", writable=False, label="تم تحويله لصنف",
          requires=IS_EMPTY_OR(IS_IN_DB(db, "items_main.id", "%(name)s"))),
    auth.signature,
    format="%(name)s",
)
db.item_requests.id.label = "م"
