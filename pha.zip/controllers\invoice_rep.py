# -*- coding: utf-8 -*-
#  type: ignore

# try something like
#   تقارير المبيعات
import xlsxwriter
import io
import sys
from datetime import datetime, timedelta


def _parse_report_datetime(value, is_end=False):
    value = (value or "").strip()
    if not value:
        now = datetime.now()
        return datetime.combine(now.date(), datetime.max.time() if is_end else datetime.min.time())

    date_part = value.split(" ")[0]
    time_part = value.split(" ")[1] if " " in value else ("23:59:59" if is_end else "00:00:00")

    date_value = None
    for fmt in ("%Y-%m-%d", "%m-%d-%Y", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            date_value = datetime.strptime(date_part, fmt).date()
            break
        except ValueError:
            continue
    if date_value is None:
        date_value = datetime.now().date()

    if time_part.startswith("24:"):
        return datetime.combine(date_value + timedelta(days=1), datetime.min.time())

    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            return datetime.combine(date_value, datetime.strptime(time_part, fmt).time())
        except ValueError:
            continue

    return datetime.combine(date_value, datetime.max.time() if is_end else datetime.min.time())


@can_access(8101)
def rep1():
    return dict()


@can_access(8101)
def rep1_data():
    """API: بيانات تقرير المبيعات مع صفحات وفلتر"""
    try:
        da1            = request.vars.da1 or ''
        da2            = request.vars.da2 or ''
        page           = int(request.vars.page or 1)
        per_page       = int(request.vars.per_page or 25)
        pay_method_id  = request.vars.pay_method or ''
        cust_q         = (request.vars.customer or '').strip()

        qry = (db.invoice_master.created_on >= da1) & (db.invoice_master.created_on <= da2)
        if pay_method_id and pay_method_id != '0':
            qry &= (db.invoice_master.payment_method == int(pay_method_id))
        if cust_q:
            cust_ids = db(db.customers.name.contains(cust_q))._select(db.customers.id)
            qry &= db.invoice_master.customer.belongs(cust_ids)

        total_count = db(qry).count()
        total_pages = max(1, (total_count + per_page - 1) // per_page)

        gt = db(qry).select(db.invoice_master.total.sum()).first()
        grand_total = round(float(gt[db.invoice_master.total.sum()] or 0), 2)

        offset = (page - 1) * per_page
        rows = db(qry).select(orderby=~db.invoice_master.id, limitby=(offset, offset + per_page))

        result = []
        page_total = 0.0
        for row in rows:
            cust = db.customers[row.customer]
            pm   = db.key_payment_method[row.payment_method]
            usr  = db.auth_user[row.created_by]
            dets = db(db.invoice_details.uuid == row.uuid).select()
            details = []
            for d in dets:
                det  = db.items_det[d.item_number]
                name = ''
                if det:
                    main = db.items_main[det.item_idr]
                    name = main.name if main else ''
                price = float(det.public_price or 0) if det else 0
                details.append({
                    'name': name,
                    'count': d.item_count,
                    'price': round(price, 2),
                    'total': round(d.item_count * price, 2),
                })
            total_val = round(float(row.total or 0), 2)
            result.append({
                'id':             row.id,
                'customer':       cust.name if cust else '',
                'payment_method': pm.name if pm else '',
                'created_on':     str(row.created_on)[:16] if row.created_on else '',
                'created_by':     ((usr.first_name or '') + ' ' + (usr.last_name or '')).strip() if usr else '',
                'total':          total_val,
                'details':        details,
            })
            page_total += total_val

        pay_methods = db(db.key_payment_method.id > 0).select()

        return response.json({
            'ok':          True,
            'data':        result,
            'total_count': total_count,
            'total_pages': total_pages,
            'page':        page,
            'per_page':    per_page,
            'page_total':  round(page_total, 2),
            'grand_total': grand_total,
            'pay_methods': [{'id': m.id, 'name': m.name} for m in pay_methods],
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        return response.json({'ok': False, 'mess': str(e), 'data': []})


@can_access(8102)
def rep2():
    da1_dt = _parse_report_datetime(request.vars.da1, is_end=False)
    da2_dt = _parse_report_datetime(request.vars.da2, is_end=True)
    da1 = da1_dt.strftime("%Y-%m-%d %H:%M:%S")
    da2 = da2_dt.strftime("%Y-%m-%d %H:%M:%S")
    return dict(da1=da1, da2=da2)


@can_access(8103)
def rep3():
    return dict()


@can_access(8104)
def rep4():
    return dict()


@can_access(8105)
def rep5():
    import datetime

    r = lambda s: str(datetime.datetime.now()) if not s else str(s)
    da1 = r(request.vars.da1)
    da2 = r(request.vars.da2)

    def parse_date(s):
        if not s:
            return str(datetime.datetime.now().date())
        d = s.split(' ')[0]
        p = d.split('-')
        if len(p) == 3:
            return (p[2]+'-'+p[0].zfill(2)+'-'+p[1].zfill(2)) if len(p[2])==4 else d[:10]
        return str(datetime.datetime.now().date())

    da1_date = parse_date(da1)
    da2_date = parse_date(da2)

    s_sales = """
        SELECT DATE(created_on) AS sale_date,
               COUNT(*) AS inv_cnt,
               ROUND(SUM(total_after_discount)::numeric, 2) AS sales_total,
               ROUND(SUM(vat)::numeric, 2) AS vat_total
        FROM invoice_master
        WHERE created_on >= %s AND created_on <= %s
        GROUP BY DATE(created_on)
        ORDER BY DATE(created_on)
    """
    s_cost = """
        SELECT DATE(im.created_on) AS sale_date,
               COUNT(*) AS item_cnt,
               ROUND(COALESCE(SUM(
                   COALESCE((SELECT it.buy_price FROM items_det it WHERE it.id = id2.item_number), 0)
                   * id2.item_count
               ), 0)::numeric, 2) AS cost_total,
               ROUND(COALESCE(SUM(id2.vat_total), 0)::numeric, 2) AS vat_items
        FROM invoice_details id2
        JOIN invoice_master im ON im.uuid = id2.uuid
        WHERE im.created_on >= %s AND im.created_on <= %s
        GROUP BY DATE(im.created_on)
    """
    sales_raw = db.executesql(s_sales, placeholders=[da1, da2], as_dict=True)
    cost_raw  = db.executesql(s_cost,  placeholders=[da1, da2], as_dict=True)
    cost_map = {}
    for c in cost_raw:
        cost_map[str(c['sale_date'])] = c

    rows = []
    t_inv = t_items = 0
    t_sales = t_cost = t_profit = t_vat = 0.0
    for rec in sales_raw:
        ds       = str(rec['sale_date'])
        cr       = cost_map.get(ds, {})
        sales    = float(rec['sales_total'] or 0)
        cost     = float(cr.get('cost_total') or 0)
        vat      = float(cr.get('vat_items')  or 0)
        profit   = round(sales - cost, 2)
        pct      = round(profit / cost * 100, 1) if cost else 0
        inv_cnt  = int(rec['inv_cnt'] or 0)
        item_cnt = int(cr.get('item_cnt') or 0)
        rows.append({'date': ds, 'inv_cnt': inv_cnt, 'item_cnt': item_cnt,
                     'sales': sales, 'cost': cost, 'profit': profit, 'pct': pct, 'vat': vat})
        t_inv    += inv_cnt
        t_items  += item_cnt
        t_sales   = round(t_sales  + sales,  2)
        t_cost    = round(t_cost   + cost,   2)
        t_profit  = round(t_profit + profit, 2)
        t_vat     = round(t_vat    + vat,    2)

    t_net_profit = round(t_profit - t_vat, 2)
    t_profit_pct = round(t_net_profit / t_cost * 100, 1) if t_cost else 0

    return dict(da1=da1, da2=da2, da1_date=da1_date, da2_date=da2_date,
                rows=rows, t_inv=t_inv, t_items=t_items, t_sales=t_sales,
                t_cost=t_cost, t_profit=t_profit, t_vat=t_vat,
                t_net_profit=t_net_profit, t_profit_pct=t_profit_pct)


@can_access(8106)
def rep6():
    da1_raw = request.vars.da1 or ""
    da2_raw = request.vars.da2 or ""
    da1_dt = _parse_report_datetime(da1_raw, is_end=False)
    da2_dt = _parse_report_datetime(da2_raw, is_end=True)

    s = """
        SELECT EXTRACT(DAY FROM created_on)::int AS fday,
               EXTRACT(MONTH FROM created_on)::int AS fmonth,
               ROUND(SUM(total_after_discount)::numeric, 0)::bigint AS total
        FROM invoice_master
        WHERE created_on >= %s AND created_on <= %s
        GROUP BY EXTRACT(DAY FROM created_on), EXTRACT(MONTH FROM created_on)
        ORDER BY fday, fmonth
    """
    raw = db.executesql(s, placeholders=[da1_dt, da2_dt], as_dict=True)

    month_names = {
        1: "يناير", 2: "فبراير", 3: "مارس", 4: "أبريل", 5: "مايو", 6: "يونيو",
        7: "يوليو", 8: "أغسطس", 9: "سبتمبر", 10: "أكتوبر", 11: "نوفمبر", 12: "ديسمبر"
    }

    pivot = {}
    month_totals = {}
    active_months = set()
    for rec in raw:
        day = rec["fday"]
        month = rec["fmonth"]
        val = int(rec["total"] or 0)
        pivot.setdefault(day, {})[month] = val
        month_totals[month] = month_totals.get(month, 0) + val
        active_months.add(month)

    pivot_rows = sorted(pivot.items())
    active_list = sorted(active_months)
    grand_total = sum(month_totals.get(m, 0) for m in active_list)

    return dict(
        da1=da1_dt.strftime("%Y-%m-%d %H:%M:%S"),
        da2=da2_dt.strftime("%Y-%m-%d %H:%M:%S"),
        da1_date=da1_dt.strftime("%Y-%m-%d"),
        da2_date=(da2_dt - timedelta(seconds=1)).strftime("%Y-%m-%d") if da2_raw and "24:" in da2_raw else da2_dt.strftime("%Y-%m-%d"),
        month_names=month_names,
        pivot_rows=pivot_rows,
        active_list=active_list,
        month_totals=month_totals,
        grand_total=grand_total,
        total_days=len(pivot_rows),
    )


@can_access(8107)
def rep7():
    return dict()


@can_access(8108)
def rep8():
    return dict()


@can_access(8110)
def rep10():
    da1_raw = request.vars.da1 or ""
    da2_raw = request.vars.da2 or ""
    da1_dt = _parse_report_datetime(da1_raw, is_end=False)
    da2_dt = _parse_report_datetime(da2_raw, is_end=True)

    rows = []
    total_sales = 0.0
    total_returns = 0.0

    types = db(db.key_type.id > 0).select(orderby=db.key_type.name)
    for item_type in types:
        sales_sql = """
            SELECT COALESCE(SUM(CAST(id.total_after_discount AS decimal)), 0) AS total
            FROM invoice_details id
            JOIN items_det det ON det.id = id.item_number
            JOIN items_main main ON main.id = det.item_idr
            WHERE id.created_on >= %s
              AND id.created_on <= %s
              AND main.item_type = %s
        """
        returns_sql = """
            SELECT COALESCE(SUM(CAST(rd.total_after_discount AS decimal)), 0) AS total
            FROM inv_return_details rd
            JOIN items_det det ON det.id = rd.item_number
            JOIN items_main main ON main.id = det.item_idr
            WHERE rd.created_on >= %s
              AND rd.created_on <= %s
              AND main.item_type = %s
        """
        sales_data = db.executesql(sales_sql, placeholders=[da1_dt, da2_dt, item_type.id], as_dict=True)
        returns_data = db.executesql(returns_sql, placeholders=[da1_dt, da2_dt, item_type.id], as_dict=True)
        sales_total = round(float(sales_data[0]["total"] or 0), 2)
        returns_total = round(float(returns_data[0]["total"] or 0), 2)
        net_total = round(sales_total - returns_total, 2)

        rows.append({
            "name": item_type.name,
            "sales": sales_total,
            "returns": returns_total,
            "net": net_total,
        })
        total_sales = round(total_sales + sales_total, 2)
        total_returns = round(total_returns + returns_total, 2)

    total_net = round(total_sales - total_returns, 2)
    active_rows = [row for row in rows if row["sales"] or row["returns"]]
    for row in rows:
        row["share"] = round((row["net"] / total_net) * 100, 1) if total_net else 0
        row["return_rate"] = round((row["returns"] / row["sales"]) * 100, 1) if row["sales"] else 0
        row["bar"] = abs(row["share"]) if abs(row["share"]) <= 100 else 100

    return dict(
        da1=da1_dt.strftime("%Y-%m-%d %H:%M:%S"),
        da2=da2_dt.strftime("%Y-%m-%d %H:%M:%S"),
        da1_date=da1_dt.strftime("%Y-%m-%d"),
        da2_date=(da2_dt - timedelta(seconds=1)).strftime("%Y-%m-%d") if da2_raw and "24:" in da2_raw else da2_dt.strftime("%Y-%m-%d"),
        rows=rows,
        active_count=len(active_rows),
        total_sales=total_sales,
        total_returns=total_returns,
        total_net=total_net,
        avg_return_rate=round((total_returns / total_sales) * 100, 1) if total_sales else 0,
    )


@can_access(8111)
def rep11():
    return dict()


@can_access(8112)
def rep12():
    da1_raw = request.vars.da1 or ""
    da2_raw = request.vars.da2 or ""
    da1_dt = _parse_report_datetime(da1_raw, is_end=False)
    da2_dt = _parse_report_datetime(da2_raw, is_end=True)

    def money(value):
        return round(float(value or 0), 2)

    data = db(
        (db.closing_shift.end_time >= da1_dt)
        & (db.closing_shift.end_time <= da2_dt)
    ).select(orderby=db.closing_shift.end_time)

    rows = []
    totals = dict(
        app_cash=0.0,
        app_atm=0.0,
        app_delay=0.0,
        app_total=0.0,
        cashier_cash=0.0,
        cashier_atm=0.0,
        cashier_delay=0.0,
        cashier_total=0.0,
        difference=0.0,
    )
    approved_count = 0
    pending_count = 0

    for row in data:
        user = db.auth_user[row.pha_user] if row.pha_user else None
        approved = row.accountant_aprove in (True, "T", "true", "True", 1)
        if approved:
            approved_count += 1
        else:
            pending_count += 1

        app_cash = money(row.app_amount_cash)
        app_atm = money(row.app_amount_atm)
        app_delay = money(row.app_amount_delay)
        app_total = money(row.app_total or (app_cash + app_atm + app_delay))
        cashier_cash = money(row.kashir_amount_cash)
        cashier_atm = money(row.kashir_amount_atm)
        cashier_delay = money(row.kashir_amount_delay)
        cashier_total = money(row.kashir_total or (cashier_cash + cashier_atm + cashier_delay))
        difference = money(row.difference if row.difference is not None else cashier_total - app_total)

        totals["app_cash"] = round(totals["app_cash"] + app_cash, 2)
        totals["app_atm"] = round(totals["app_atm"] + app_atm, 2)
        totals["app_delay"] = round(totals["app_delay"] + app_delay, 2)
        totals["app_total"] = round(totals["app_total"] + app_total, 2)
        totals["cashier_cash"] = round(totals["cashier_cash"] + cashier_cash, 2)
        totals["cashier_atm"] = round(totals["cashier_atm"] + cashier_atm, 2)
        totals["cashier_delay"] = round(totals["cashier_delay"] + cashier_delay, 2)
        totals["cashier_total"] = round(totals["cashier_total"] + cashier_total, 2)
        totals["difference"] = round(totals["difference"] + difference, 2)

        rows.append(dict(
            start_time=str(row.start_time)[:16] if row.start_time else "",
            end_time=str(row.end_time)[:16] if row.end_time else "",
            user_name=((user.first_name or "") + " " + (user.last_name or "")).strip() if user else "غير معروف",
            app_cash=app_cash,
            app_atm=app_atm,
            app_delay=app_delay,
            app_total=app_total,
            cashier_cash=cashier_cash,
            cashier_atm=cashier_atm,
            cashier_delay=cashier_delay,
            cashier_total=cashier_total,
            difference=difference,
            approved=approved,
            note=row.kashir_note or "",
        ))

    return dict(
        da1=da1_dt.strftime("%Y-%m-%d %H:%M:%S"),
        da2=da2_dt.strftime("%Y-%m-%d %H:%M:%S"),
        da1_date=da1_dt.strftime("%Y-%m-%d"),
        da2_date=(da2_dt - timedelta(seconds=1)).strftime("%Y-%m-%d") if da2_raw and "24:" in da2_raw else da2_dt.strftime("%Y-%m-%d"),
        rows=rows,
        totals=totals,
        shift_count=len(rows),
        approved_count=approved_count,
        pending_count=pending_count,
    )


# ==============================================================================================================
