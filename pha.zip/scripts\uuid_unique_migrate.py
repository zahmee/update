# -*- coding: utf-8 -*-
"""قيد فريد على الرقم المميز للفواتير (uuid) — تسوية فرع.

الرقم المميز هو حارس التكرار: العميل يولّده مرة واحدة للفاتورة ويرسله مع كل
محاولة حفظ، والخادم يرفض ما سبق حفظه. لكن الفحص في الخادم "ابحث ثم أدرج"،
وبين الخطوتين فجوة يمكن أن يمر منها طلبان متزامنان معاً. القيد الفريد في
قاعدة البيانات يغلق الفجوة نهائياً لأن الرفض يصير جزءاً من الكتابة نفسها.

يعالج هذا السكربت أمرين لكل فرع:
  1) حذف صفوف الرأس الوهمية التي تمنع إنشاء القيد.
     مصدرها خلل قديم كان يُدرج رأس المرتجع **داخل** حلقة الأصناف بدل ما
     بعدها، فينتج رأس لكل صنف والمبلغ يتراكم. الكود الحالي يُدرجه مرة واحدة.
     العلامة المميزة: نفس الثانية + مبالغ تصاعدية + عدد الرؤوس = عدد الأصناف.
     يُبقى في كل مجموعة الصف الأخير (المبلغ الكامل وعلامة الإرسال).
  2) إنشاء القيد الفريد على جدولي البيع والمرتجعات، **والتحقق** من إنشائه.

  الوضع الافتراضي: تقرير فقط، لا يكتب حرفاً في القاعدة.
  للتنفيذ الفعلي أضف الوسيط: apply

التشغيل من مجلد web2py:
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/uuid_unique_migrate.py
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/uuid_unique_migrate.py -A apply

آمن للإعادة: تشغيله مرتين لا يغيّر شيئاً في المرة الثانية.

قبل الحذف تُحفَظ نسخة كاملة من الصفوف المحذوفة في مجلد private بصيغة JSON،
سطر لكل صف، حتى تبقى قابلة للاسترجاع اليدوي.

المنطق نفسه تستخدمه الشاشة الإدارية setup/uuid_guard — المصدر واحد في
modules/uuid_guard.py فلا يفترق التنفيذان.
"""
import os
import sys

import uuid_guard

APPLY = any(str(a).strip().lower() == "apply" for a in sys.argv[1:])


def hr(t=""):
    print("\n" + "=" * 62)
    if t:
        print(t)
        print("=" * 62)


hr("قيد فريد على الرقم المميز للفواتير")
print("الوضع: " + ("تنفيذ فعلي (apply)" if APPLY else "تقرير فقط — لا كتابة"))

for st in uuid_guard.status(db):
    hr("%s  (%s)" % (st["label"], st["table"]))
    if st["protected"]:
        print("  محمي ✓ — القيد الفريد موجود.")
        if st["redundant"]:
            print("  فهارس زائدة ستُحذف: %s" % ", ".join(st["redundant"]))
        else:
            print("  لا فهارس زائدة.")
        continue
    print("  إجمالي السجلات   : %s" % st["total"])
    print("  أرقام فارغة      : %s" % st["blanks"])
    print("  مجموعات مكررة    : %s" % st["dup_groups"])
    print("  صفوف ستُحذف      : %s" % st["extra_rows"])
    if st["extra_rows"]:
        print("  مبلغها المجمّع   : %s" % st["extra_amount"])
        print("  منها مُرسل للهيئة: %s" % st["extra_sent"])
    if st["redundant"]:
        print("  فهارس زائدة      : %s" % ", ".join(st["redundant"]))
    print("  الحالة           : %s" % st["note"])

if not APPLY:
    hr("انتهى التقرير — لم تتغير أي بيانات")
    print("للتنفيذ الفعلي أعد التشغيل مع الوسيط: -A apply")
else:
    hr("التنفيذ")
    for r in uuid_guard.apply_all(db, os.path.join(request.folder, "private")):
        print("\n%s:" % r["label"])
        if r["backup"]:
            print("  نسخة احتياطية : %s" % r["backup"])
        if r["deleted"]:
            print("  حُذف          : %s صف" % r["deleted"])
        if r["dropped"]:
            print("  فهارس محذوفة  : %s" % ", ".join(r["dropped"]))
        print("  %s %s" % ("✓" if r["ok"] else "!", r["mess"]))

hr("النتيجة النهائية")
for st in uuid_guard.status(db):
    print("  %-22s %s" % (st["label"], "محمي ✓" if st["protected"] else "غير محمي ✗"))
db.rollback()
