# -*- coding: utf-8 -*-
"""تسوية قاعدة بيانات فرع بعد الترقية إلى 5.66.

الكود الجديد يبقي المخزون ودفتر الحركات متطابقين **من الآن فصاعداً**، لكنه لا
يعالج ما تراكم قبله. هذا السكربت يعالج التراكم، ويُشغَّل مرة واحدة لكل فرع.

  الوضع الافتراضي: تقرير فقط، لا يكتب حرفاً في القاعدة.
  للتنفيذ الفعلي أضف الوسيط: apply

التشغيل من مجلد web2py:
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/branch_migrate_5_66.py
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/branch_migrate_5_66.py -A apply

آمن للإعادة: تشغيله مرتين لا يغيّر شيئاً في المرة الثانية.

ضمانة السلامة: الكمية القابلة للبيع لا تتغيّر إطلاقاً.
  - الخطوتان 2 و 4 تكتبان في دفتر الحركات فقط.
  - الخطوة 3 تعيد التوزيع داخل دفعات الصنف الواحد دون تغيير إجماليه.
"""
import sys

APPLY = any(str(a).strip().lower() == "apply" for a in sys.argv[1:])
EPS = 1e-9


def hr(t=""):
    print("\n" + "=" * 62)
    if t:
        print(t)
        print("=" * 62)


def one(sql, ph=None):
    r = db.executesql(sql, placeholders=ph)
    return r[0] if r else None


def total_stock():
    return round(float(one("SELECT COALESCE(SUM(items_count),0) FROM items_det")[0] or 0), 4)


def total_ledger():
    return round(float(one("SELECT COALESCE(SUM(qty_in),0)-COALESCE(SUM(qty_out),0)"
                           " FROM items_movement")[0] or 0), 4)


hr("تسوية فرع — النسخة 5.66")
print("الوضع: " + ("تنفيذ فعلي (apply)" if APPLY else "تقرير فقط — لا كتابة"))
STOCK0, LEDGER0 = total_stock(), total_ledger()
print("المخزون الحالي: %s      الدفتر: %s      الفارق: %s"
      % (STOCK0, LEDGER0, round(STOCK0 - LEDGER0, 2)))

# ===================================================================
hr("1) الأصناف الخدمية (رصيدها سالب بطبيعتها)")
# ===================================================================
# صنف "هللة" وأمثاله يُباع ولا يُشترى أبداً. بلا تعليمه تمتلئ شاشة
# «حالات البيع بدون رصيد» بضجيج لا معنى له.
pseudo = db.executesql(
    "SELECT m.id, m.item_id, m.name, COALESCE(SUM(d.items_count),0) AS qty,"
    "       COALESCE(m.track_stock,'T') AS tracked"
    "  FROM items_main m LEFT JOIN items_det d ON d.item_idr = m.id"
    " WHERE m.name LIKE '%هلل%' OR m.item_id = '1'"
    " GROUP BY m.id, m.item_id, m.name, m.track_stock ORDER BY qty", as_dict=True)
if not pseudo:
    print("  لا توجد أصناف بهذا الوصف.")
for p in pseudo:
    state = "غير متابَع (سليم)" if p["tracked"] == "F" else "متابَع — يحتاج تعليماً"
    print("  #%-6s %-14s %-22s رصيد %-12s %s"
          % (p["id"], p["item_id"], (p["name"] or "")[:22], round(float(p["qty"]), 1), state))
    if APPLY and p["tracked"] != "F":
        db(db.items_main.id == p["id"]).update(track_stock=False)
        print("        -> عُلّم كصنف خدمي")
if APPLY:
    db.commit()

# مرشّحون آخرون للمراجعة اليدوية — لا يُعلَّمون تلقائياً
cand = db.executesql(
    "SELECT m.id, m.item_id, LEFT(m.name,34) AS name, SUM(d.items_count) AS qty"
    "  FROM items_main m JOIN items_det d ON d.item_idr = m.id"
    " WHERE COALESCE(m.track_stock,'T') = 'T'"
    " GROUP BY m.id, m.item_id, m.name"
    " HAVING SUM(d.items_count) < -500 ORDER BY 4 LIMIT 10", as_dict=True)
if cand:
    print("\n  مرشّحون للمراجعة (رصيد سالب كبير) — قرّر بنفسك إن كانوا خدميين:")
    for c in cand:
        print("     #%-6s %-14s %-34s %s"
              % (c["id"], c["item_id"], c["name"], round(float(c["qty"]), 1)))

# ===================================================================
hr("2) أسطر توريد لم تُسجَّل في الدفتر")
# ===================================================================
# ضرورية حتى لا يعيد conf_inv تسجيلها لاحقاً فيختل الدفتر من جديد.
legacy = db.executesql(
    "SELECT d.id, d.item_idr, d.quantity, d.buy_price, d.supplier_inv,"
    "       COALESCE(b.bill_no,'') AS bill_no, d.created_on"
    "  FROM items_det d JOIN suppliers_bills b ON b.id = d.supplier_inv"
    " WHERE (b.bill_confirmation IS NULL OR b.bill_confirmation='F')"
    "   AND NOT EXISTS (SELECT 1 FROM items_movement m"
    "                    WHERE m.item_det = d.id AND m.move_type = 'شراء')",
    as_dict=True)
print("  عدد الأسطر: %d" % len(legacy))
if APPLY and legacy:
    for r in legacy:
        db.items_movement.insert(
            item_main=r["item_idr"], item_det=r["id"], move_type="شراء",
            move_date=r["created_on"] or request.now,
            qty_in=float(r["quantity"] or 0), qty_out=0,
            unit_price=float(r["buy_price"] or 0),
            reference=r["bill_no"], ref_no=str(r["supplier_inv"]))
    db.commit()
    print("  -> سُجّلت.")

# ===================================================================
hr("3) الأرصدة السالبة داخل الدفعات (إعادة توزيع محايدة)")
# ===================================================================
neg = db.executesql(
    "SELECT item_idr FROM items_det WHERE items_count < 0"
    " GROUP BY item_idr ORDER BY item_idr", as_dict=True)
# التمييز مهم: القابل للإصلاح فقط هو ما تغطّي دفعاته الموجبة سالبَه.
fixable = db.executesql(
    "WITH n AS (SELECT item_idr, SUM(items_count) neg FROM items_det"
    "            WHERE items_count<0 GROUP BY item_idr),"
    "     p AS (SELECT item_idr, SUM(items_count) pos FROM items_det"
    "            WHERE items_count>0 GROUP BY item_idr)"
    " SELECT COUNT(*), COALESCE(ROUND(SUM(-n.neg)::numeric,2),0)"
    "   FROM n LEFT JOIN p USING(item_idr)"
    "  WHERE COALESCE(p.pos,0) >= -n.neg")[0]
print("  أصناف بها دفعات سالبة        : %d" % len(neg))
print("  منها قابل للإصلاح هنا        : %s صنف (%s وحدة تُعاد توزيعها)"
      % (fixable[0], fixable[1]))
print("  غير قابل (إجماليه سالب)      : %d صنف — يحتاج شراء أو جرد"
      % (len(neg) - int(fixable[0])))
if APPLY and neg:
    fixed = skipped = 0
    units = 0.0
    for i, row in enumerate(neg, 1):
        b = float(one("SELECT COALESCE(SUM(items_count),0) FROM items_det WHERE item_idr=%s",
                      [row["item_idr"]])[0] or 0)
        ok, amount = stock_repair_item(row["item_idr"])
        a = float(one("SELECT COALESCE(SUM(items_count),0) FROM items_det WHERE item_idr=%s",
                      [row["item_idr"]])[0] or 0)
        if abs(b - a) > 1e-6:
            db.rollback()
            raise SystemExit("توقّف: تغيّر إجمالي الصنف %s من %s إلى %s"
                             % (row["item_idr"], b, a))
        if ok:
            fixed += 1
            units += amount
        else:
            skipped += 1
        if i % 300 == 0:
            db.commit()
            print("     ... %d / %d" % (i, len(neg)))
    db.commit()
    print("  -> أُصلح %d صنفاً (%s وحدة أُعيد توزيعها)" % (fixed, round(units, 2)))
    print("  -> تعذّر %d صنفاً (إجمالي رصيدها سالب — تحتاج شراء أو جرد)" % skipped)

# ===================================================================
hr("4) مطابقة الدفتر مع المخزون الفعلي")
# ===================================================================
# اتجاه المطابقة: الدفتر يتبع items_det، لأنه ما يبيع منه النظام.
# هذه الخطوة تكتب في items_movement فقط ولا تغيّر أي كمية قابلة للبيع.
GAP_SQL = (
    "WITH s AS (SELECT item_idr AS im, SUM(items_count) qty FROM items_det GROUP BY 1),"
    "     m AS (SELECT item_main AS im, SUM(qty_in)-SUM(qty_out) bal"
    "             FROM items_movement GROUP BY 1)"
    " SELECT im, COALESCE(s.qty,0) qty, COALESCE(m.bal,0) bal"
    "   FROM s FULL JOIN m USING(im)"
    "  WHERE im IS NOT NULL AND ABS(COALESCE(s.qty,0)-COALESCE(m.bal,0)) > 0.001")
gaps = db.executesql(GAP_SQL, as_dict=True)
gap_units = round(sum(abs(float(g["qty"] or 0) - float(g["bal"] or 0)) for g in gaps), 2)
print("  أصناف متباعدة: %d   (فجوة مطلقة %s وحدة)" % (len(gaps), gap_units))
if APPLY and gaps:
    for i, g in enumerate(gaps, 1):
        d = round(float(g["qty"] or 0) - float(g["bal"] or 0), 6)
        if abs(d) < 0.001:
            continue
        db.items_movement.insert(
            item_main=g["im"], item_det=0, move_type="تسوية دفتر",
            move_date=request.now, qty_in=d if d > 0 else 0,
            qty_out=(-d) if d < 0 else 0, unit_price=0,
            reference="مطابقة الدفتر مع المخزون الفعلي", ref_no="")
        if i % 300 == 0:
            db.commit()
    db.commit()
    print("  -> تمت المطابقة.")

# ===================================================================
hr("5) الشاشة 4003 المحذوفة (استعراض فاتورة)")
# ===================================================================
scr = db(db.screens.screen_code == 4003).select().first()
if not scr:
    print("  غير موجودة — سليم.")
else:
    n = db(db.screens_rules.screens == scr.id).count()
    print("  موجودة مع %d صف صلاحيات (شاشة معطّلة بلا وظيفة)" % n)
    if APPLY:
        db(db.screens_rules.screens == scr.id).delete()
        db(db.screens.id == scr.id).delete()
        db.commit()
        print("  -> حُذفت.")

# ===================================================================
hr("النتيجة")
# ===================================================================
S1, L1 = total_stock(), total_ledger()
print("المخزون: %s  ->  %s     (يجب ألا يتغيّر)" % (STOCK0, S1))
print("الدفتر : %s  ->  %s" % (LEDGER0, L1))
print("الفارق : %s  ->  %s" % (round(STOCK0 - LEDGER0, 2), round(S1 - L1, 2)))

still_neg = one("SELECT COUNT(*) FROM (SELECT item_idr FROM items_det"
                " WHERE item_idr IN (SELECT id FROM items_main"
                "                     WHERE COALESCE(track_stock,'T')='T')"
                " GROUP BY item_idr HAVING SUM(items_count) < 0) t")[0]
print("\nأصناف إجمالي رصيدها سالب: %s" % still_neg)
print("  هذه لا تُصلَح برمجياً (إصلاحها = اختراع كمية) — تحتاج فاتورة شراء أو جرد فعلي.")
print("  لكشف جرد بها:  scripts/negative_stock_report.py")

if APPLY:
    safe = abs(S1 - STOCK0) < 0.01 and abs(S1 - L1) < 0.01
    print("\nRESULT: " + ("OK — المخزون لم يتأثر والدفتر مطابق" if safe
                          else "PROBLEM — راجع الأرقام أعلاه"))
else:
    print("\nلم يُكتب شيء. للتنفيذ أعد التشغيل مع الوسيط:  -A apply")
