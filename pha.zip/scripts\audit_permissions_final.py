# -*- coding: utf-8 -*-
"""
تقرير تدقيق نهائي لصلاحيات الشاشات والأزرار
"""
import os
import re
from collections import defaultdict

controllers_dir = 'controllers'
views_dir = 'views'
static_dir = 'static'

# ============================================================
# 1. استخراج كل دوال ال controllers مع الديكوريتors
# ============================================================
controller_funcs = defaultdict(list)

for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py') or fname == '__init__.py':
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    current_decorators = []
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('@'):
            current_decorators.append(stripped)
        elif stripped.startswith('def '):
            func_match = re.match(r'def\s+(\w+)\s*\(', stripped)
            if func_match:
                func_name = func_match.group(1)
                controller_funcs[controller].append({
                    'func': func_name,
                    'decorators': current_decorators[:],
                    'line': i+1
                })
            current_decorators = []

# ============================================================
# 2. استخراج أكواد الشاشات من can_access
# ============================================================
can_access_codes = defaultdict(list)
for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py'):
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    for match in re.finditer(r'@can_access\((\d+)\)', content):
        code = int(match.group(1))
        can_access_codes[controller].append(code)

# ============================================================
# 3. استخراج أكواد الشاشات المسجلة
# ============================================================
setup_screens = {}
with open(os.path.join(controllers_dir, 'setup.py'), 'r', encoding='utf-8') as f:
    setup_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', setup_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)".*?"screen_code":\s*' + str(code), setup_content, re.DOTALL)
    if not name_match:
        name_match = re.search(r'"screen_code":\s*' + str(code) + r'.*?"name":\s*"([^"]+)"', setup_content, re.DOTALL)
    name = name_match.group(1) if name_match else "unknown"
    setup_screens[code] = name

add_screens = {}
with open('scripts/add_missing_screens.py', 'r', encoding='utf-8') as f:
    add_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', add_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)".*?"screen_code":\s*' + str(code), add_content, re.DOTALL)
    if not name_match:
        name_match = re.search(r'"screen_code":\s*' + str(code) + r'.*?"name":\s*"([^"]+)"', add_content, re.DOTALL)
    name = name_match.group(1) if name_match else "unknown"
    add_screens[code] = name

all_registered_screens = {**setup_screens, **add_screens}

# ============================================================
# 4. استخراج الروابط من navbar (layout.html)
# ============================================================
navbar_links = []
with open(os.path.join(views_dir, 'layout.html'), 'r', encoding='utf-8') as f:
    layout_content = f.read()

for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", layout_content):
    ctrl, func = match.groups()
    if ctrl == 'static':
        continue
    navbar_links.append((ctrl, func))

# ============================================================
# 5. فحص Views للروابط غير المحمية
# ============================================================
view_issues = []
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace('views/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", content):
            ctrl, func = match.groups()
            if ctrl == 'static':
                continue
            if ctrl == 'default' and func.startswith('user/'):
                continue
            if ctrl == 'default' and func == 'download':
                continue
            if func.endswith('.js') or func.endswith('.css'):
                continue
            if ctrl not in controller_funcs:
                continue  # controller غير موجود
            
            protected = False
            if ctrl in controller_funcs:
                for cf in controller_funcs[ctrl]:
                    if cf['func'] == func:
                        for d in cf['decorators']:
                            if '@can_access' in d or '@auth.requires' in d:
                                protected = True
                        break
            
            if not protected:
                view_issues.append((rel_path, ctrl, func))

# ============================================================
# 6. فحص Vue.js files
# ============================================================
vue_issues = []
for root, dirs, files in os.walk(os.path.join(static_dir, 'viewsjs')):
    for fname in files:
        if not fname.endswith('.js'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace(static_dir + '/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        for match in re.finditer(r"['\"](/asbab5/([^/'\"]+)/([^/'\"\s]+))['\"]", content):
            url = match.group(1)
            ctrl = match.group(2)
            func = match.group(3)
            
            if ctrl not in controller_funcs:
                continue
            
            protected = False
            for cf in controller_funcs[ctrl]:
                if cf['func'] == func:
                    for d in cf['decorators']:
                        if '@can_access' in d or '@auth.requires' in d:
                            protected = True
                    break
            
            if not protected:
                vue_issues.append((rel_path, ctrl, func, url))

# ============================================================
# 7. تحديد المشاكل في navbar
# ============================================================
navbar_issues = []
for ctrl, func in navbar_links:
    if ctrl == 'static':
        continue
    if ctrl == 'default' and func.startswith('user/'):
        continue
    if ctrl == 'default' and func in ['about', 'not_allow']:
        continue
    
    has_can_access = False
    has_auth = False
    if ctrl in controller_funcs:
        for cf in controller_funcs[ctrl]:
            if cf['func'] == func:
                for d in cf['decorators']:
                    if '@can_access' in d:
                        has_can_access = True
                    if '@auth.requires' in d:
                        has_auth = True
                break
    
    if not has_can_access:
        navbar_issues.append((ctrl, func, has_auth))

# ============================================================
# 8. دوال حساسة بدون حماية
# ============================================================
sensitive_unprotected = []
for ctrl in sorted(controller_funcs):
    for f in controller_funcs[ctrl]:
        decs = ' '.join(f['decorators'])
        has_can_access = '@can_access' in decs
        has_auth = '@auth.requires' in decs
        
        if ctrl == 'appadmin':
            continue
        if f['func'].startswith('_'):
            continue
        if ctrl == 'default' and f['func'] in ['user', 'not_allow', 'about', 'download']:
            continue
        if ctrl == 'send_invoice' and f['func'] == 'index':
            continue
        if ctrl == '_t':
            continue
        
        if not has_can_access and not has_auth:
            sensitive_unprotected.append((ctrl, f['func'], f['line']))

# ============================================================
# 9. الشاشات المسجلة vs المستخدمة
# ============================================================
all_codes = set()
for codes in can_access_codes.values():
    all_codes.update(codes)
registered_codes = set(all_registered_screens.keys())
unused_registered = sorted(registered_codes - all_codes)

# ============================================================
# 10. controllers تستخدم أدوار قديمة
# ============================================================
old_roles = []
for ctrl in sorted(controller_funcs):
    for f in controller_funcs[ctrl]:
        decs = ' '.join(f['decorators'])
        if 'user1' in decs or 'user2' in decs:
            old_roles.append((ctrl, f['func'], f['line'], decs))

# ============================================================
# كتابة التقرير
# ============================================================
report_lines = []
report_lines.append("=" * 90)
report_lines.append("                    تقرير تدقيق شامل لصلاحيات النظام")
report_lines.append("                              نظام الصدارة (asbab5)")
report_lines.append("=" * 90)
report_lines.append("")

# الملخص
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│                           الملخص التنفيذي                                │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
report_lines.append(f"  • إجمالي دوال Controllers المحللة: {sum(len(v) for v in controller_funcs.values())}")
report_lines.append(f"  • عدد أكواد can_access المستخدمة: {len(all_codes)}")
report_lines.append(f"  • عدد الشاشات المسجلة: {len(all_registered_screens)}")
report_lines.append(f"  • عدد روابط navbar: {len(navbar_links)}")
report_lines.append(f"  • مشاكل navbar: {len(navbar_issues)}")
report_lines.append(f"  • مشاكل Views: {len(view_issues)}")
report_lines.append(f"  • مشاكل Vue.js: {len(vue_issues)}")
report_lines.append(f"  • دوال حساسة بدون حماية: {len(sensitive_unprotected)}")
report_lines.append(f"  • دوال تستخدم أدوار قديمة (user1/user2): {len(old_roles)}")
report_lines.append("")

# المشاكل في navbar
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【1】روابط navbar غير المحمية بصلاحيات شاشة                              │")
report_lines.append("│     (يمكن الوصول للشاشة مباشرة عبر الرابط حتى بدون صلاحية)             │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
for ctrl, func, has_auth in sorted(navbar_issues):
    status = "@auth.requires_login فقط" if has_auth else "بدون أي حماية"
    report_lines.append(f"  ⚠️  {ctrl}/{func} -> {status}")
report_lines.append("")

# المشاكل في Views
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【2】روابط داخل Views تؤدي لدوال غير محمية                               │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
seen = set()
for view, ctrl, func in sorted(view_issues):
    key = (view, ctrl, func)
    if key in seen:
        continue
    seen.add(key)
    report_lines.append(f"  ⚠️  {view} -> {ctrl}/{func}")
report_lines.append("")

# المشاكل في Vue.js
if vue_issues:
    report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
    report_lines.append("│ 【3】روابط API في Vue.js غير محمية                                       │")
    report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
    for vue, ctrl, func, url in sorted(vue_issues):
        report_lines.append(f"  ⚠️  {vue} -> {url}")
    report_lines.append("")

# الدوال الحساسة غير المحمية
if sensitive_unprotected:
    report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
    report_lines.append("│ 【4】دوال Controllers حساسة بدون أي حماية                                │")
    report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
    for ctrl, func, line in sorted(sensitive_unprotected):
        report_lines.append(f"  ⚠️  {ctrl}.{func}() @ line {line}")
    report_lines.append("")

# الأدوار القديمة
if old_roles:
    report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
    report_lines.append("│ 【5】دوال تستخدم أدوار قديمة (user1, user2) بدلاً من can_access          │")
    report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
    for ctrl, func, line, decs in sorted(old_roles):
        report_lines.append(f"  ⚠️  {ctrl}.{func}() @ line {line} -> {decs}")
    report_lines.append("")

# الشاشات غير المستخدمة
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【6】شاشات مسجلة لكن لا توجد can_access لها                              │")
report_lines.append("│     (قد تكون محمية بـ auth.requires_login أو أدوار أخرى فقط)            │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
for code in unused_registered:
    name = all_registered_screens.get(code, 'unknown')
    report_lines.append(f"  ℹ️  {code}: {name}")
report_lines.append("")

# الأزرار المشروطة
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【7】الأزرار المشروطة في Views (can_add, can_edit, can_delete)          │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
button_checks = []
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace('views/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        flags = []
        if 'can_add' in content: flags.append('can_add')
        if 'can_edit' in content: flags.append('can_edit')
        if 'can_delete' in content: flags.append('can_delete')
        if flags:
            button_checks.append((rel_path, flags))

for view, flags in sorted(button_checks):
    report_lines.append(f"  ✓ {view}: {', '.join(flags)}")
report_lines.append("")

# التوصيات
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│                              التوصيات                                    │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
report_lines.append("""
1. 【خطيرة】روابط navbar غير المحمية:
   - يجب إضافة @can_access لجميع روابط navbar التي لا تحتوي عليه.
   - أو إخفاء الروابط حسب الصلاحيات باستخدام screens_rules().

2. 【خطيرة】دوال Controllers بدون حماية:
   - يجب حماية جميع الدوال الحساسة إما بـ @can_access أو @auth.requires.
   - الدوال المساعدة (التي تبدأ بـ _) يجب ألا تُستدعى مباشرة.

3. 【متوسطة】استخدام أدوار قديمة (user1, user2):
   - يجب استبدال @auth.requires_membership("user1") بـ @can_access(كود_الشاشة).
   - هذا يتيح التحكم الدقيق في الصلاحيات من شاشة إدارة المستخدمين.

4. 【متوسطة】الأزرار في Views:
   - يجب إضافة فحص can_add/can_edit/can_delete في المزيد من Views.
   - خاصة في شاشات: الموردين، الأصناف، المبيعات، الصندوق.

5. 【منخفضة】الشاشات المسجلة غير المستخدمة:
   - مراجعة إذا كانت هذه الشاشات مطلوبة فعلياً.
   - إذا كانت كذلك، يجب تفعيل @can_access لها في controllers.
""")

report_lines.append("=" * 90)
report_lines.append("                              نهاية التقرير")
report_lines.append("=" * 90)

with open('scripts/audit_permissions_final_report.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(report_lines))

print("Done. Report written to scripts/audit_permissions_final_report.txt")
