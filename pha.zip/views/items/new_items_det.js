
var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
    },
    created() {
        fetch(window.location.href + '/../../api_1/getItemsDet', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            })
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../api_1/getItemsDet'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        showmoor() {
            this.getData.page++;
            var url = new URL(window.location.href + '/../../api_1/getItemsDet'),
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.select_obj_1.select_id,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            if (row.vat_in_public_price === 'T') {
                this.edit_row_data.vat_in_public_price = true;
            } else {
                this.edit_row_data.vat_in_public_price = false;
            }
        },
        edit_row() {
            this.new_row = false;
        },
        save_data() {
            if (!this.edit_row_data.public_price < 0  ||  !this.edit_row_data.vat < 0  ||
                this.edit_row_data.items_count < 0) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [اسم الصنف - رقم الصنف - الوحدة - التصنيف - سعر البيع ] .',
                    'error'
                );
                return;
            }
            // تعديل 
            //
            var url = new URL(window.location.href + '/../../api_1/editItemsDet');
            params = this.edit_row_data;
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    if (data.id > 0) {
                        if (this.edit_row_data.vat_in_public_price === true) {
                            this.edit_row_data.vat_in_public_price = 'T';
                        } else {
                            this.edit_row_data.vat_in_public_price = 'F';
                        }
                        this.data[this.selectedRow] = this.edit_row_data;
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        const elem = document.getElementById("exampleModal");
                        const modal = bootstrap.Modal.getInstance(elem);
                        modal.hide();

                        Swal.fire(
                            'عمل رائع',
                            'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                            'success'
                        );
                    } else {
                        Swal.fire(
                            'تنبية',
                            data.mess,
                            'error'
                        );
                    }
                });
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        items_history() {
            url = window.location.href + '/../../items/itm_rep_det/' + this.edit_row_data.item_idr;
            window.open(url); //items_qry/items_sales
        },
        items_sales() {
            url = window.location.href + '/../../items/items_sales/' + this.edit_row_data.item_idr;
            window.open(url);
        },
        adjust_quantity() {
            url = window.location.href + '/../../items/adjust_quantity/' + this.edit_row_data.item_idr;
            window.open(url);
        },
        item_barcode_print() {
            url = window.location.href + '/../../items_qry/it_prt_by_item.svc/' + this.edit_row_data.item_id;
            window.open(url);
        }
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    }
});
