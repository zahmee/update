
// debounce helper — يمنع إرسال طلب API عند كل ضغطة مفتاح
function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments;
        var ctx  = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        select_obj_2: 0,
        showBtn: 0,
        selectedRow: -1,
        text_ltr: false,
        edit_row_data: {},
        value: '',
        options: [],
    },
    created() {
        // نسخة مؤجلة من onChange للبحث (400ms)
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);

        const baseUrl = window.location.href + '/../../api_1/';
        fetch(baseUrl + 'getItemsDet', {
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        }).then(r => r.json())
          .then(data => {
              this.data           = data.data;
              this.data_row_count = data.count;
          });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            const params = {
                page:        this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText:  this.getData.SearchText,
                SortBy:      this.getData.SortBy,
                sequence:    this.getData.sortAsc,
            };
            const url = new URL(window.location.href + '/../../api_1/getItemsDet');
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    this.data           = data.data;
                    this.data_row_count = data.count;
                    this.selectedRow    = -1;
                    this.edit_row_data  = {};
                });
        },
        showmoor() {
            this.getData.page++;
            const params = {
                page:        this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText:  this.getData.SearchText,
                SortBy:      this.getData.SortBy,
                sequence:    this.getData.sortAsc,
            };
            const url = new URL(window.location.href + '/../../api_1/getItemsDet');
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => { data.data.forEach(el => this.data.push(el)); });
        },
        sortBy(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy  = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow              = index;
            this.edit_row_data            = { ...row };
            this.edit_row_data.vat_in_public_price = (row.vat_in_public_price === 'T');
        },
        edit_row() { /* يُستدعى عند الضغط على أيقونة التعديل */ },
        // ── تلوين الصفوف حسب تاريخ الصلاحية ──────────────────────────────
        rowClass(row) {
            if (!row.expiration_date) return '';
            const exp    = new Date(row.expiration_date);
            const today  = new Date();
            const days90 = new Date(today.getTime() + 90 * 24 * 60 * 60 * 1000);
            if (exp < today)   return 'table-danger';   // منتهي الصلاحية
            if (exp < days90)  return 'table-warning';  // ينتهي خلال 90 يوم
            return '';
        },
        save_data() {
            // إصلاح: الشرط الأصلي كان مكسوراً ولا يعمل أبداً
            if (parseFloat(this.edit_row_data.public_price) < 0 ||
                parseFloat(this.edit_row_data.vat)          < 0 ||
                parseFloat(this.edit_row_data.items_count)  < 0) {
                Swal.fire('تنبية', 'القيم يجب أن تكون أكبر من أو تساوي صفر.', 'error');
                return;
            }
            const payload = {
                id:                  this.edit_row_data.id,
                public_price:        this.edit_row_data.public_price,
                items_count:         this.edit_row_data.items_count,
                vat:                 this.edit_row_data.vat,
                vat_in_public_price: this.edit_row_data.vat_in_public_price ? 'T' : 'F',
                return_count:        this.edit_row_data.return_count,
            };
            const url = new URL(window.location.href + '/../../api_1/editItemsDet');
            Object.keys(payload).forEach(key => url.searchParams.append(key, payload[key]));
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (data.id > 0) {
                        // إصلاح: Vue 2 لا تتتبع تعديل index مباشرة — يجب استخدام $set
                        const updated = { ...this.edit_row_data,
                            vat_in_public_price: payload.vat_in_public_price };
                        this.$set(this.data, this.selectedRow, updated);
                        this.edit_row_data = {};
                        this.selectedRow   = -1;
                        bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        cancel_data() {
            this.edit_row_data = {};
            this.selectedRow   = -1;
        },
        items_history() {
            window.open(window.location.href + '/../../items/itm_rep_det/' + this.edit_row_data.item_idr);
        },
        items_sales() {
            window.open(window.location.href + '/../../items/items_sales/' + this.edit_row_data.item_idr);
        },
        adjust_quantity() {
            window.open(window.location.href + '/../../items/adjust_quantity/' + this.edit_row_data.item_idr);
        },
        item_barcode_print() {
            window.open(window.location.href + '/../../items_qry/it_prt_by_item.svc/' + this.edit_row_data.item_id);
        }
    },
    watch: {
        value: function(val) { this.onChange(); }
    }
});
