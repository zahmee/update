
function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments;
        var ctx  = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

var baseUrl = window.location.href + '/../../api_1/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        text_ltr: false,
        edit_row_data: {},
        loading: false,
    },
    created: function() {
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);
        this.loading = true;
        this.fetchData().then(function(data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function() { this.loading = false; }.bind(this));
    },
    computed: {
        totalPages: function() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function() {
            return this.getData.page + 1;
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
            };
            var url = new URL(baseUrl + 'getItemsDet');
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); });
        },
        onChange: function() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        sortBy: function(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            this.edit_row_data.vat_in_public_price = (row.vat_in_public_price === 'T');
        },
        edit_row: function() {},
        rowClass: function(row) {
            if (!row.expiration_date) return '';
            var exp = new Date(row.expiration_date);
            var today = new Date();
            var days90 = new Date(today.getTime() + 90 * 24 * 60 * 60 * 1000);
            if (exp < today) return 'table-danger';
            if (exp < days90) return 'table-warning';
            return '';
        },
        save_data: function() {
            if (parseFloat(this.edit_row_data.public_price) < 0 ||
                parseFloat(this.edit_row_data.vat) < 0 ||
                parseFloat(this.edit_row_data.items_count) < 0) {
                Swal.fire('تنبية', 'القيم يجب أن تكون أكبر من أو تساوي صفر.', 'error');
                return;
            }
            var payload = {
                id: this.edit_row_data.id,
                public_price: this.edit_row_data.public_price,
                items_count: this.edit_row_data.items_count,
                vat: this.edit_row_data.vat,
                vat_in_public_price: this.edit_row_data.vat_in_public_price ? 'T' : 'F',
                return_count: this.edit_row_data.return_count,
            };
            var url = new URL(window.location.href + '/../../api_1/editItemsDet');
            Object.keys(payload).forEach(function(key) { url.searchParams.append(key, payload[key]); });
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.id > 0) {
                        var updated = { ...this.edit_row_data, vat_in_public_price: payload.vat_in_public_price };
                        this.$set(this.data, this.selectedRow, updated);
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', data.mess || 'حصل خطأ', 'error');
                    }
                }.bind(this));
        },
        cancel_data: function() {
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        items_history: function() {
            window.open(window.location.href + '/../../items/itm_rep_det/' + this.edit_row_data.item_idr);
        },
        items_sales: function() {
            window.open(window.location.href + '/../../items/items_sales/' + this.edit_row_data.item_idr);
        },
        adjust_quantity: function() {
            window.open(window.location.href + '/../../items/adjust_quantity/' + this.edit_row_data.item_idr);
        },
        item_barcode_print: function() {
            window.open(window.location.href + '/../../items_qry/it_prt_by_item.svc/' + this.edit_row_data.item_id);
        }
    }
});
