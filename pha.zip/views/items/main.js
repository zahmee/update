Vue.component('v-select', VueSelect.VueSelect);

// debounce helper — يمنع إرسال طلب API عند كل ضغطة مفتاح
function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments;
        var ctx  = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

var app = new Vue({
    el: '#app',
    data: {
            counter: 0,
            data: [],
            getData: {
                page: 0,
                RecordCount: 20,
                SearchText: '',
                SortBy: 'id',
                sortAsc: true
            },
            data_row_count: 0,
            coding: {
                supplier: [],
                Allsupplier: [],
                types: [],
                units: [],
            },
            select_obj_2: 0,
            showBtn: 0,
            show_model: false,
            selectedRow: -1,
            text_ltr: false,
            new_row: true,
            edit_row_data: {},
            value: '',
            options: [],
            items_count: 0
    },
    created() {
        // إنشاء نسخة مؤجلة من onChange للبحث (400ms debounce)
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);

        const baseUrl     = window.location.href + '/../../api_1/';
        const jsonHeaders = { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } };

        // تحميل جميع البيانات بالتوازي بدلاً من التسلسل
        Promise.all([
            fetch(baseUrl + 'getMainItems2', jsonHeaders).then(r => r.json()),
            fetch(baseUrl + 'min_suppliers_1').then(r => r.json()),
            fetch(baseUrl + 'types').then(r => r.json()),
            fetch(baseUrl + 'units').then(r => r.json()),
        ]).then(([itemsData, suppliers, types, units]) => {
            this.data           = itemsData.data;
            this.data_row_count = itemsData.count;

            this.coding.supplier    = suppliers;
            this.coding.Allsupplier = suppliers;
            suppliers.forEach(el => {
                this.options.push({ value: el.id, label: el.name });
            });

            this.coding.types = types;
            this.coding.units = units;
        });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            const params = {
                page:        this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText:  this.getData.SearchText,
                types:       this.select_obj_2,
                SortBy:      this.getData.SortBy,
                sequence:    this.getData.sortAsc,
            };
            if (this.value) {
                params.supplier = this.value.value;
            }
            this.cancel_data();
            var url = new URL(baseUrl + 'getMainItems2');
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    this.data           = data.data;
                    this.data_row_count = data.count;
                });
        },
        showmoor() {
            this.getData.page++;
            const params = {
                page:        this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText:  this.getData.SearchText,
                supplier:    this.value ? this.value.value : '',  // إصلاح: كان يستخدم select_obj_1.select_id المهجور
                types:       this.select_obj_2,
                SortBy:      this.getData.SortBy,
                sequence:    this.getData.sortAsc,
            };
            var url = new URL(baseUrl + 'getMainItems2');
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    data.data.forEach(el => this.data.push(el));
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy  = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow   = index;
            this.edit_row_data = { ...row };

            let sup = null;
            this.options.forEach(el => {
                if (el.value === row.suppliers) {
                    sup = el;
                }
            });
            // إصلاح: كان `if (sup == {})` وهو دائماً false في JavaScript
            this.edit_row_data.suppliers    = sup || { value: 0, label: 'اختر' };
            this.edit_row_data.flexible_price = (row.flexible_price === 'T');
        },
        edit_row() {
            this.new_row = false;
        },
        edit_count() {
            var url = new URL(window.location.href + '/../../api_1/getCountItems/' + this.edit_row_data.id);
            fetch(url, { headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => { this.items_count = data; });
        },
        new_row_click() {
            this.new_row       = true;
            this.edit_row_data = { suppliers: {} };
        },
        save_data() {
            if (!this.edit_row_data.name || !this.edit_row_data.item_id ||
                !this.edit_row_data.item_unit || !this.edit_row_data.item_type ||
                !this.edit_row_data.suppliers.value || this.edit_row_data.public_price < 0) {
                Swal.fire('تنبية', 'يجب ادخال [اسم الصنف - رقم الصنف - الوحدة - التصنيف - سعر البيع ] .', 'error');
                return;
            }

            const endpoint = this.new_row ? 'newMainItem' : 'editMainItem';
            var url        = new URL(window.location.href + '/../../api_1/' + endpoint);

            const payload  = { ...this.edit_row_data };
            payload.suppliers     = this.edit_row_data.suppliers.value;
            payload.flexible_price = payload.flexible_price ? 'T' : 'F';
            payload.name          = (payload.name || '').toUpperCase().trim();

            Object.keys(payload).forEach(key => url.searchParams.append(key, payload[key]));

            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (data.id > 0) {
                        // تحديث أسماء التصنيف والمورد في الصف
                        this.coding.types.forEach(row => {
                            if (row.id === payload.item_type) payload.t_name = row.name;
                        });
                        this.coding.supplier.forEach(row => {
                            if (row.id === payload.suppliers) payload.s_name = row.name;
                        });

                        if (this.new_row) {
                            payload.id = data.id;
                            this.data.push({ ...payload });
                        } else {
                            // إصلاح: Vue 2 لا تتتبع تعديل index مباشرة — يجب استخدام $set
                            this.$set(this.data, this.selectedRow, { ...payload });
                        }

                        this.edit_row_data = {};
                        this.selectedRow   = -1;
                        const modal = bootstrap.Modal.getInstance(document.getElementById("exampleModal"));
                        modal.hide();
                        Swal.fire('عمل رائع', 'شكرا لك لقد تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        cancel_data() {
            this.new_row       = true;
            this.edit_row_data = {};
            this.selectedRow   = -1;
        },
        items_history() {
            window.open(window.location.href + '/../../items/itm_rep_det/' + this.edit_row_data.id);
        },
        items_sales() {
            window.open(window.location.href + '/../../items/items_sales/' + this.edit_row_data.id);
        },
        adjust_quantity() {
            window.open(window.location.href + '/../../items/adjust_quantity/' + this.edit_row_data.id);
        },
        item_barcode_print() {
            window.open(window.location.href + '/../../items/it_prt_by_item.svc/' + this.edit_row_data.id);
        },
        save_count() {
            if (!this.items_count || this.items_count < 0) {
                Swal.fire('تنبية', 'يجب ادخال قيمة صحيحة في عدد الصنف.', 'error');
                return;
            }
            var url = new URL(window.location.href + '/../../api_1/editcountItem');
            const params = { item_id: this.edit_row_data.id, total_count: this.items_count };
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (data == 1) {
                        this.selectedRow = -1;
                        const modal = bootstrap.Modal.getInstance(document.getElementById("CountModal"));
                        modal.hide();
                        Swal.fire('عمل رائع', 'شكرا لك لقد تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', data.mess, 'error');
                    }
                });
        }
    },
    watch: {
        value: function(val) {
            this.onChange();
        }
    }
});

// متغير عام للـ URL الأساسي (يُستخدم في onChange)
var baseUrl = window.location.href + '/../../api_1/';
