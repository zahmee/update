Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
            counter: 0,
            data: [],
            getData: {
                page: 0,
                RecordCount: 20,
                SearchText: '',
                SortBy: 'id',
                sortAsc: true
            },
            data_row_count: 0,
            coding: {
                supplier: [],
                Allsupplier: [],
                types: [],
                units: [],
            },
            select_obj_1: {
                serch_text: '',
                show_select: false,
                select_value: '',
                select_id: '',
            },
            select_obj_2: 0,
            showBtn: 0,
            show_model: false,
            selectedRow: -1,
            text_ltr: false,
            new_row: true,
            edit_row_data: {},
            value: '',
            options: [] ,
            items_count : 0 
    },
    created() {
        fetch(window.location.href + '/../../api_1/getMainItems2', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
                fetch(window.location.href + '/../../api_1/min_suppliers_1')
                    .then(response => response.json())
                    .then(data => {
                        this.coding.supplier = data;
                        this.coding.Allsupplier = data;
                        op = this.options ;
                        data.forEach(function(el){
                            new_el ={
                                value: el.id ,
                                label: el.name
                            }
                            op.push(new_el);
                        });

                    })
                fetch(window.location.href + '/../../api_1/types')
                    .then(response => response.json())
                    .then(data => {
                        this.coding.types = data;
                    })
                fetch(window.location.href + '/../../api_1/units')
                    .then(response => response.json())
                    .then(data => {
                        this.coding.units = data;
                    })
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            this.cancel_data() ;
            var url = new URL(window.location.href + '/../../api_1/getMainItems2'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        get() {
            //
            //
        },
        open_add() {
            window.open(window.location.href + '/../new', '_self');
        },
        showmoor() {
            this.getData.page++;
            var url = new URL(window.location.href + '/../../api_1/getMainItems2'),
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.select_obj_1.select_id,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            sup = {} ;
            this.options.forEach((el)=>{
                if (el.value === row.suppliers ){
                    sup = el ;
                }
            })
            if (sup == {}) {
                sup = { value: 0, label: 'اختر' };
            }
            this.edit_row_data.suppliers = sup ;
            
            if (row.flexible_price === 'T') {
                this.edit_row_data.flexible_price = true ;
            } else {
                this.edit_row_data.flexible_price = false ;
            }
        },
        edit_row() {
            this.new_row = false;
        },
        edit_count(){
            //
            params = this.edit_row_data;
            var url = new URL(window.location.href + '/../../api_1/getCountItems/' + params['id']);
            fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    this.items_count =  data  ;
                });


        } ,
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {
                suppliers : {} ,
            };
        },
        save_data() {
            if (!this.edit_row_data.name || !this.edit_row_data.item_id ||
                !this.edit_row_data.item_unit || !this.edit_row_data.item_type || !this.edit_row_data.suppliers.value ||
                this.edit_row_data.public_price < 0) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [اسم الصنف - رقم الصنف - الوحدة - التصنيف - سعر البيع ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../api_1/newMainItem');
                this.edit_row_data.suppliers = this.edit_row_data.suppliers.value ;
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.coding.types.forEach(row => {
                                if (row.id === this.edit_row_data.item_type) {
                                    this.edit_row_data.t_name = row.name;
                                }
                            });
                            this.coding.supplier.forEach(row => {
                                if (row.id === this.edit_row_data.suppliers) {
                                    this.edit_row_data.s_name = row.name;
                                }
                            });
                            this.edit_row_data.name = this.edit_row_data.name.toUpperCase().trim()
                            if (this.edit_row_data.flexible_price === true) {
                                this.edit_row_data.flexible_price = 'T' ;
                            } else {
                                this.edit_row_data.flexible_price = 'F' ;
                            }
                            this.data.push(this.edit_row_data);
                            this.edit_row_data = {} ;
                            this.selectedRow = -1 ;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../api_1/editMainItem');
                this.edit_row_data.suppliers = this.edit_row_data.suppliers.value;
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.coding.types.forEach(row => {
                                if (row.id === this.edit_row_data.item_type) {
                                    this.edit_row_data.t_name = row.name;
                                }
                            });
                            this.coding.supplier.forEach(row => {
                                if (row.id === this.edit_row_data.suppliers) {
                                    this.edit_row_data.s_name = row.name;
                                }
                            });
                            this.edit_row_data.name = this.edit_row_data.name.toUpperCase().trim()
                            if (this.edit_row_data.flexible_price === true) {
                                this.edit_row_data.flexible_price = 'T' ;
                            } else {
                                this.edit_row_data.flexible_price = 'F' ;
                            }
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess ,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1 ;

        },
        items_history() {
            url = window.location.href + '/../../items/itm_rep_det/' + this.edit_row_data.id;
            window.open(url); //items_qry/items_sales
        } ,
        items_sales() {
            url = window.location.href + '/../../items/items_sales/' + this.edit_row_data.id;
            window.open(url);
        },
        adjust_quantity() {
            url = window.location.href + '/../../items/adjust_quantity/' + this.edit_row_data.id;
            window.open(url);
        },
        item_barcode_print(){
            url = window.location.href + '/../../items/it_prt_by_item.svc/' + this.edit_row_data.id;
            window.open(url);
        } ,
        save_count(){
            if (!this.items_count || this.items_count < 0) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال قيمة صحيحة في عدد الصنف.',
                    'error'
                );
                return;
            }
            var url = new URL(window.location.href + '/../../api_1/editcountItem');
            this.edit_row_data.suppliers = this.edit_row_data.suppliers.value;
            params = {
                'item_id': this.edit_row_data.id, 'total_count': this.items_count 
            }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    if (data==1 ) {
                        this.selectedRow = -1;
                        //$('#CountModal').modal('hide')
                        const elem = document.getElementById("CountModal");
                        const modal = bootstrap.Modal.getInstance(elem);
                        modal.hide();
                        Swal.fire(
                            'عمل رائع',
                            'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                            'success'
                        );
                    } else {
                        Swal.fire(
                            'تنبية',
                            data.mess,
                            'error'
                        );
                    }
                });
        }
    } ,
    watch: {
        value : function (val) {
            this.onChange() ;
        }
    }
}) ;
