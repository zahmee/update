
var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        items_reorder: this.items_id,
        data: [],
        data_all: [],
        show_spinner: true,
        serch: '',
    },
    created() {

        this.$http.get(this.URL + '/../get_open_inv').then(response => {
            if (response.body != "") {
                this.data = response.body;
                this.data_all = response.body;
                //this.show_spinner = false;
            }
        });

    },
    methods: {

        find() {
            serc = this.serch;
            if (serc.length > 0) {

                this.data = this.data_all.filter(row => {
                    if (
                        (String(row['id']).includes(serc)) ||
                        (String(row['bill_no']).includes(serc)) ||
                        (String(row['bill_date']).includes(serc)) ||
                        (String(row['bill_net_amount']).includes(serc)) ||
                        (String(row['bill_total']).includes(serc)) ||
                        (String(row['bill_vat']).includes(serc))  
                    ) {
                        return true;
                    } 
                });
            }
            else {
                this.data = this.data_all ;
            }

        },
        remove_best_price() {
            this.data.forEach(function (e, index) {
                e.best_price = '';
            });
        },
        remove_supp_name() {
            this.data.forEach(function (e, index) {
                e.supplier = '';
            });
        },
        link_1(id) {
            window.open(purl + "/../../items/it_rep1/" + id, '_self');
        },
        link_2(id) {
            window.open(purl + "/../../items/it_prt.svc/" + id, '_self');
        },
        link_3(id) {
            window.open(purl + "/../../items/it_inv/" + id, '_self');
        }


    },
});

