
var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        row_id: this.row_id ,
        data: [],
        clicked: true,
        show_spinner: true ,
        sum_row : 0 ,
        save_clicked:false ,
    },
    created() {
        app = this ;
        this.$http.get(this.URL + '/../../items_qry/get_last_10/' + this.row_id ).then(response => {
            // get body data
            if (response.body != "") {
                this.data = response.body ;
                this.show_spinner = false ;
            }
        }).then( re=>{
             this.data.forEach(function (element) {
                 app.sum_row += (element.items_count * 1) ;
                });
            this.sum_row = this.sum_row.toFixed(2)
        }) ;
    },
    methods: {
        remove_count() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.quantity === 0) {
                    return e;
                }
            });
        },
        sort_order_items() {
            app.data = _.orderBy(app.data, ['order_items'], ['asc']);
        },
        SaveAll() {
            this.data.forEach(function (element) {
                if (element.items_count < 0 ){
                    Swal.fire(' يجب ان تكون جميع الاعداد بالموجب ');
                    return;
                }
            });
            //this.save_clicked = true;
            alldata = {};
            alldata['itm'] = this.data;
            this.$http.post(this.URL + '/../../items_qry/save_adjust_quantity/', JSON.stringify(alldata), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body.mess===0 ) {
                        Swal.fire(' تم الحفظ بشكل صحيح ');
                        window.location.href = this.URL + "/../adjust_quantity/"+this.row_id;
                    } else {
                        Swal.fire(' حصل خطأ في عملية الحفظ ');
                    }
                }
            }) ;
        },
    } ,
    computed: {
        total() {
            total = 0.0;
            this.data.forEach(function (element) {
                total += (element.items_count*1);
            });
            return total.toFixed(2) ;
        },
    }
});

