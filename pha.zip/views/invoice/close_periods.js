var app = new Vue({
    el: '#app',
    data: {
        data: [],
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {
            start_time: '',
            end_time: '',
            kashir_amount_cash: '',
            kashir_amount_atm: '',
            kashir_amount_delay: '',
            kashir_note: ''
        },
        value: '',
        start_date: {
            s_y: 2020,
            s_m: 1,
            s_d: 1,
            st_h: 12,
            st_m: 0,
        },
        end_date: {
            e_y: 2020,
            e_m: 1,
            e_d: 1,
            et_h: 22,
            et_m: 0,
        },
        shift_time: "00:00",
        options: [],
    },
    created() {
        fetch(window.location.href + '/../close_periods_get', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data;
            }).then(() => {
            });
        now_date = new Date();
        this.start_date.s_y = now_date.getFullYear();
        this.start_date.s_m = now_date.getMonth() + 1;
        this.start_date.s_d = now_date.getDate();
        this.end_date.e_y = now_date.getFullYear();
        this.end_date.e_m = now_date.getMonth() + 1;
        this.end_date.e_d = now_date.getDate();
        this.end_date.et_h = now_date.getHours();
        this.end_date.et_m = now_date.getMinutes();
        this.date_def() ;
    },
    methods: {
        /*
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../customers_api/get_customers'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },*/
        date_def(){
            const date1 = new Date(this.end_date.e_y, this.end_date.e_m - 1, this.end_date.e_d, this.end_date.et_h, this.end_date.et_m);
            const date2 = new Date(this.start_date.s_y, this.start_date.s_m - 1, this.start_date.s_d, this.start_date.st_h, this.start_date.st_m);
            const diffTime = (date1 - date2);
            if (diffTime<0 ){
            this.shift_time = "فترات التاريخ غير صحيحة"
            } else {
                de_h = Math.floor(diffTime / (1000 * 60 * 60));
                de_m =  Math.floor(diffTime / (1000 * 60 )) - (de_h * 60) ;
                this.shift_time = "( "+de_h + ") ساعة  : ( " + de_m +" ) دقيقة";
            }
        } ,
        get() {
            //
            //
        },
        open_add() {
            window.open(window.location.href + '/../new', '_self');
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            start_date = new Date(row.start_time) ;
            end_date = new Date(row.end_time) ;

            this.start_date.s_y = start_date.getFullYear();
            this.start_date.s_m = start_date.getMonth() + 1;
            this.start_date.s_d = start_date.getDate();
            this.start_date.st_h = start_date.getHours();
            this.start_date.st_m = start_date.getMinutes();

            this.end_date.e_y = end_date.getFullYear();
            this.end_date.e_m = end_date.getMonth() + 1;
            this.end_date.e_d = end_date.getDate();
            this.end_date.et_h = end_date.getHours();
            this.end_date.et_m = end_date.getMinutes();

            this.edit_row_data = { ...row };
        },
        edit_row() {
            this.new_row = false;
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {};
            /*
            start_time: new Date().toLocaleString(),
            end_time: new Date().toLocaleString(),
            kashir_amount_cash: 0,
            kashir_amount_atm: 0,
            kashir_amount_delay: 0,
            kashir_note: '' 
        };*/
        },
        save_data() {
            //var myModalEl = document.getElementById('exampleModal');
            //var row_modal = bootstrap.Modal.getInstance(myModalEl);
            if (!this.end_date.e_y || !this.end_date.e_m  || !this.end_date.e_d  
                 || !this.start_date.s_y || !this.start_date.s_m || !this.start_date.s_d   ){
                Swal.fire(
                    'تنبية',
                    'يجب ادخال كافة الحقول',
                    'error'
                );
                return;
            }
            if (String(this.start_date.st_m).length < 2) {
                this.start_date.st_m = "0" + this.start_date.st_m;
            }
            if (String(this.start_date.st_h).length < 2) {
                this.start_date.st_h = "0" + this.start_date.st_h;
            }
            if (String(this.end_date.et_m).length < 2) {
                this.end_date.et_m = "0" + this.end_date.et_m;
            }
            if (String(this.end_date.et_h).length < 2) {
                this.end_date.et_h = "0" + this.end_date.et_h;
            }
            const date1 = String(this.end_date.e_y) + "-" + String(this.end_date.e_m) + "-" + String(this.end_date.e_d) + " " + String(this.end_date.et_h) + ":" + String(this.end_date.et_m) + ":00";
            const date2 = String(this.start_date.s_y) + "-" + String(this.start_date.s_m) + "-" + String(this.start_date.s_d) + " " + String(this.start_date.st_h) + ":" + String(this.start_date.st_m) + ":00";
            this.edit_row_data.start_time = date2 ;
            this.edit_row_data.end_time = date1;

            const s_date = new Date(this.end_date.e_y, this.end_date.e_m - 1, this.end_date.e_d, this.end_date.et_h, this.end_date.et_m);
            const e_date = new Date(this.start_date.s_y, this.start_date.s_m - 1, this.start_date.s_d, this.start_date.st_h, this.start_date.st_m);

            const diffTime = (s_date - e_date);
            if (diffTime < 0) {
                Swal.fire(
                    'تنبية',
                    'ادخال غير صحيح للوقت',
                    'error'
                );
                return;
            }


            if (!this.edit_row_data.start_time || !this.edit_row_data.end_time ||
                !this.edit_row_data.kashir_amount_cash || !this.edit_row_data.kashir_amount_atm ||
                !this.edit_row_data.kashir_amount_delay) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال كافة الحقول',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../close_periods_add');
                params = this.edit_row_data;
                params.kashir_total = Number(this.edit_row_data.kashir_amount_cash) +
                    Number(this.edit_row_data.kashir_amount_atm) + Number(this.edit_row_data.kashir_amount_delay)
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.data.push(this.edit_row_data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            this.new_row = true;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../close_periods_edit');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data[this.selectedRow] = data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        delete_row() {
            Swal.fire({
                title: 'هل انت متأكد',
                text: "هل ترغب بحذف هذا السجل !",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا'
            }).then((result) => {
                if (result.value) {
                    this.$http.get(this.URL + '/../close_periods_delete/' + this.edit_row_data.id).then(response => {
                        if (response.body.mess === 1) {
                            this.data.splice(this.selectedRow, 1);
                            Swal.fire({
                                title: "تم الحذف بنجاح",
                            })
                        } else {
                            Swal.fire(
                                'لم تتم العملية',
                                response.body.mess,
                                'error'
                            )
                        }
                    });
                }
            })
        },
        acc_row() {
            //
        },
        acc_save_data() {
            //
            if (this.edit_row_data.accountant_aprove == true ) {
                Swal.fire(
                    'تنبية',
                    `
                     لقد تم حفظ هذا الشفت `,
                    'error'
                );
                return;
            }
            if (this.edit_row_data.kashir_amount_cash != this.edit_row_data.cash) {
                Swal.fire(
                    'تنبية',
                    `يوجد خطأ 
                    <br>
                    لا يتطابق المبلغ المستلم مع المبلغ المسلم من قبل الكاشير`,
                    'error'
                );
                return;
            }
            var url = new URL(window.location.href + '/../close_periods_edit');
            params = this.edit_row_data;
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    if (data.id > 0) {
                        this.data.splice(this.selectedRow, 1);
                        this.selectedRow = -1;
                        const elem = document.getElementById("accModal");
                        const modal = bootstrap.Modal.getInstance(elem);
                        modal.hide();
                        Swal.fire(
                            'عمل رائع',
                            'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                            'success'
                        );
                    } else {
                        Swal.fire(
                            'تنبية',
                            data.mess,
                            'error'
                        );
                    }
                });

        } ,
        link_1() {
            //this.edit_row_data.id
            console.log(this.edit_row_data);
            window.open(this.URL + "/../print_close_period/" + this.edit_row_data.id);
        },
    }
});
