var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        invno: 0,
        inv_type: 1,
        inv_master: [],
        inv_deteal: [],
    },
    methods: {
        get_inv: function () {
            this.$http.get(this.URL + '/../inv_view_1/' + this.inv_type+'/' + this.invno).then(response => {
                if (response.body != "") {
                    this.inv_master = response.body ;
                    return '0' ;
                } 
            }).then(res=>{
                if (res == "0") {
                    this.$http.get(this.URL + '/../inv_view_2/' + this.inv_type + '/'+ this.invno).then(response => {
                        if (response.body != "") {
                            this.inv_deteal = response.body;
                        }
                    }) ;
                }
            });
        },
        getcustomer: function () {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                // get body data
                if (response.body != "") {
                    this.customer = response.body[0]
                    this.customer.show = true;
                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
            });
        },
        removeItem: function (index) {
            this.AllItems.splice(index, 1);
        },

    },
});
