var app = new Vue({
    el: '#app',
    data: {
        newTodo: '',
        NewItem: [] ,
        NewItemCount: 1,
        AllItems: [],
        todos: [],
        uuid1: '',
        uuid2: '',
        URL: this.purl,
        seller : this.seller ,
        vat_no: this.vat_no ,
        comp_name : this.comp_name ,
        way : '' ,
        NowDate: new Date(),
        itemNotFound: false,
        key_payment_method: [{
            name: '',
            id: 0
        }],
        selected_method: 1,
        customer: {
            'id': 1,
            'name': 'عميل نقدي',
            'show': false,
        },
        serchCustomar: {
            show: false,
            value: ''
        },
        serchCustomarList: [],
        serchItems: {
            show: false,
            vlaue: ''
        },
        serchItemsListDet: [],
        serchItemsListMaster: [],
        VAT: 0.0,
        discount: 0.0,
        invoce_no: 0,
        GivenByCustomer: 0.0,
        save_clicked: true,
        aux: new AudioContext(),
        coust_pay: {
            coust: 0,
            mount: 0.0,
            note: '',
            type: 0,
            pay_note: '',

        },

    },
    created() {
        // var qr = qrcode(0, 'L');
        this.$http.get(this.URL + '/../get_payment_method').then(response => {
            // get body data
            if (response.body != "") {
                this.key_payment_method = response.body;
                this.uuid1 = this.uuidv4();
            }
        }, response => {
            //
        });
    },
    methods: {
        getitem() {
            if (!this.NewItem) {
                this.itemNotFound = true;
                this.NewItemCount = 1;
                this.beep(100, 520, 200);
                return;
            }
            itm = toString(this.NewItem) ;
            n_item = itm.split("*")  ;
            if (n_item.length>1 ) {
                this.NewItemCount = this.NewItem.split("*")[0];
                this.NewItem = this.NewItem.split("*")[1] ;
            }
            this.$http.get(this.URL + '/../../invoice/getit/?itid=' + this.NewItem).then(response => {
                // get body data
                if (response.body != "") {
                    itm = response.body[0];
                    if (itm.flexible_price === "T") {
                        response.body[0]['count'] = 1;
                        response.body[0]['public_price'] = (parseFloat(itm.public_price) * parseFloat(this.NewItemCount));
                        this.NewItemCount = 1;
                        response.body[0]['total'] = parseFloat(response.body[0]['public_price'] * this.NewItemCount).toFixed(2);
                        vat_mount = (response.body[0]['public_price'] * this.NewItemCount * response.body[0]['vat']).toFixed(2);
                        response.body[0]['vat_mount'] = vat_mount;
                        response.body[0]['way'] = this.way ;                        
                        this.AllItems.push(response.body[0]);
                        this.NewItem = '';
                        this.way = '' ;
                        this.itemNotFound = false;
                        this.NewItemCount = 1;
                    } else {
                        //this.beep(100, 520, 200) ;
                        response.body[0]['count'] = this.NewItemCount;
                        response.body[0]['total'] = parseFloat(response.body[0]['public_price'] * this.NewItemCount).toFixed(2);
                        vat_mount = (response.body[0]['public_price'] * this.NewItemCount * response.body[0]['vat']).toFixed(2);
                        response.body[0]['vat_mount'] = vat_mount;
                        response.body[0]['way'] = this.way;      
                        this.AllItems.push(response.body[0]);
                        this.NewItem = '';
                        this.way = '';
                        this.itemNotFound = false;
                        this.NewItemCount = 1;
                    }
                } else {
                    this.beep(100, 520, 200);
                    this.NewItem = '';
                    this.itemNotFound = true;
                    this.NewItemCount = 1;
                }
            }, response => {
                this.NewItem = '';
            });
        },
        getcustomer() {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                // get body data
                if (response.body != "") {
                    this.customer = response.body[0]
                    this.customer.show = true;
                    this.selected_method = 3;
                    if (this.customer.amount<0){
                        this.GivenByCustomer = this.customer.amount.toFixed(2)*-1 ;
                    }

                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                    this.selected_method = 1;
                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
            });
        },
        removeItem(index) {
            this.AllItems.splice(index, 1);
        },
        getcount() {
            this.NewItemCount = this.NewItem;
            this.NewItem = '';
        },
        discountFun() {
            newval = this.total * 0.1;
            if (this.discount > newval) {
                this.discount = 0;
            }
        },
        findCustomer() {
            this.serchCustomar.show = !this.serchCustomar.show;
            //this.$refs.refsearchCustomer.focus();
            //this.$refs.searchCustomer.$el.focus()
        },
        SerchCustomer() {
            if (this.serchCustomar.value.length > 2) {
                this.$http.get(this.URL + '/../../invoice/search_c/?itid=' + this.serchCustomar.value).then(response => {
                    // get body data
                    if (response.body != "") {
                        this.serchCustomarList = response.body;
                    } else {
                        this.serchCustomarList = [];
                        this.customer.id = 1;
                        this.customer.name = 'عميل نقدي';
                    }
                }, response => {
                    //this.customer.id = 1;
                    //this.customer.name = 'عميل نقدي';
                });
            } else {
                this.serchCustomarList = [];
            }
        },
        selectSerchCustomer(index) {
            this.customer.id = this.serchCustomarList[index].id;
            this.getcustomer();
            this.serchCustomar.show = !this.serchCustomar.show;
            //this.GivenByCustomer
        },
        findItems() {
            this.serchItems.show = !this.serchItems.show;
        },
        SerchItems() {
            if (this.serchItems.value.length > 2) {
                this.$http.get(this.URL + '/../../items_qry/search_item/?itid=' + this.serchItems.value).then(response => {
                    if (response.body != "") {
                        this.serchItemsListMaster = response.body;
                    } else {
                        this.serchItemsListMaster = [];
                    }
                });
            } else {
                this.serchItemsListMaster = [];
            }
        },
        selectserchItems(index) {
            serch_item_det = this.serchItemsListMaster[index];
            this.$http.get(this.URL + '/../../items_qry/search_item_det/?itid=' + serch_item_det.id).then(response => {
                if (response.body != "") {
                    //this.serchItemsListDet = response.body[0] ;
                    this.NewItem = response.body[0]['id'].toString()
                    this.getitem();
                    this.serchItemsListMaster = [];
                    this.serchItemsListDet = [];
                    this.serchItems.value = '';
                    this.NewItem = '';
                    this.itemNotFound = false;
                    this.NewItemCount = 1;
                    this.serchItems.show = !this.serchItems.show;

                } else {
                    this.serchItemsListMaster = [];
                }
            });

            /*
            newiteml = this.serchItemsList[index];
            newiteml['count'] = this.NewItemCount ;
            newiteml['total'] = newiteml['public_price'] * this.NewItemCount  ;
            this.AllItems.push(newiteml);
            console.log(newiteml);
            console.log(this.AllItems);
            */
        },
        selectserchItemsDet(index) {

        },
        SaveAll() {
            alldata = {};
            if (this.customer.id == 1 & this.selected_method == 3) {
                Swal.fire('المبيعات النقدية يجب ان تكون بالنقدي فقط');
                return;
            }
            if (this.uuid1 === this.uuid2) {
                Swal.fire('لقد تم حفظ هذه الفاتورة بالفعل');
                return;
            }
            this.save_clicked = false;
            alldata['itm'] = this.AllItems;
            alldata['uuid'] = this.uuid1;
            alldata['total'] = parseFloat(this.total).toFixed(2);
            alldata['discount'] = this.discount;
            alldata['totalAfterDiscount'] = this.totalAfterDiscount.toFixed(2);
            alldata['vat'] = parseFloat(this.vat).toFixed(2);
            alldata['totalAfterAll'] = this.totalAfterAll.toFixed(2);
            alldata['customer'] = this.customer.id;
            alldata['method'] = this.selected_method;



            this.$http.post(this.URL + '/../save/', JSON.stringify(alldata), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body.invno > 0) {
                        this.invoce_no = response.body.invno;
                        this.uuid2 = this.uuid1;
                        return 'ok';
                    } if (response.body.err === "5") {
                        Swal.fire('لقد تم حفظ هذه الفاتورة بالفعل');
                        return;
                    } else {
                        Swal.fire(' لقد حصل خطأ في حفظ الفاتورة !!!!! ');
                        console.log('err');
                        return;
                    }
                } else {
                    Swal.fire(' لقد حصل خطأ في حفظ الفاتورة !!!!! ');
                    console.log('err');
                    return;
                }
            }, response => {
                //this.customer.id = 1;
                //this.customer.name = 'عميل نقدي';
            }).then(res => {
                if (res == "ok") {
                    myapp = this;
                    const elem = document.getElementById("pr");
                    var newpr = elem.innerHTML ;
                    var a = window.open('', 'PRINT', 'height=600, width=600');
                    //var typeNumber = 4;
                    //var errorCorrectionLevel = 'L';
                    //url =  ;
                    // المبلغ: ${ this.totalAfterDiscount.toFixed(2) }
                    // الضريبة: ${ parseFloat(this.vat).toFixed(2) }
                    now_date = new Date().toLocaleString("en-GB") ;
                    qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
                    var a1 = this.getTLV(1, this.seller ) ;
                    var a2 = this.getTLV(2, this.vat_no ) ;
                    var a3 = this.getTLV(3, now_date ) ;
                    var a4 = this.getTLV(4, this.totalAfterDiscount.toString() ) ;
                    var a5 = this.getTLV(5, this.vat.toString() ) ;
                    var aa = a1+a2+a3+a4+a5
                    var qr = qrcode(0, 'L');
                    qr.addData(this.hexToBase64(aa));
                    qr.make();
                    a.document.write(`<html>
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=0.8">
                        <meta http-equiv="X-UA-Compatible" >
                        <title>طباعة فاتورة</title>
                        <style>
                            * {
                                margin: 0;
                                padding: 0;
                                box-sizing: border-box;
                            }
                        </style>
                    </head>
                    <body >`);
                    a.document.write('<div style="text-align: center">');
                    //a.document.write(' <img src="{{{=URL("static","images/head_img.png")}}}"  width="300" > ');
                    a.document.write('</div>');
                    a.document.write(newpr);
                    a.document.write('<div style="text-align: center">');
                    a.document.write(qr.createSvgTag());
                    a.document.write('</div>');
                    a.document.write('</body></html>');
                    a.document.close();
                    a.onafterprint = () => { a.close(); }
                    // console.log(a);
                    a.print();
                    return 'ok';
                }
            }).then(res => {
                if (res == "ok") {
                    this.uuid1 = this.uuidv4();
                    this.save_clicked = true;
                    this.$refs.NewItem.focus();
                    this.AllItems = [];
                    this.discount = 0;
                    this.customer.id = 1;
                    this.customer.name = "مبيعات نقدية";
                    this.selected_method = 1;
                    this.customer.show = false;
                    this.GivenByCustomer = 0;
                    this.$refs.NewItem.focus();
                }
            });

        },
        AddHalal() {
            var me = this;
            this.AllItems.forEach(function (el, index) {
                if (el.id === 1) {
                    me.AllItems.splice(index, 1);
                }
            });
            var baqee = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            this.NewItem = 1;
            this.NewItemCount = Math.floor(baqee * 100).toFixed(0);
            this.getitem();
            // alert (baqee) ;
        },
        uuidv4() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },
        bytesToHex(bytes) {
            return Array.from(
                bytes,
                byte => byte.toString(16).padStart(2, "0")
            ).join("");
        },
        hexToBase64(str) {
            return btoa(String.fromCharCode.apply(null,
                str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" "))
            );
        },
        stringToUTF8Bytes(string) {
            return new TextEncoder().encode(string);
          } ,
        isDoubleByte(str) {
            for (var i = 0, n = str.length; i < n; i++) {
                if (str.charCodeAt(i) > 255) { return true; }
            }
            return false;
        } ,
        getTLV(tag, val) {
            var len = parseInt(val.length.toString(2), 2).toString(16);
            var spaceCount = (val.split(" ").length - 1);
            if ((tag == 1) && (this.isDoubleByte(val) == true)) {
                len = parseInt(((val.length * 2) - spaceCount).toString(2), 2).toString(16);
            }
            var tag = parseInt(tag.toString(2), 2).toString(16);
            var vale = this.bytesToHex(this.stringToUTF8Bytes(val));
            if (len.length == 1) {
                len = '0' + len;
            }
            if (tag.length == 1) {
                tag = '0' + tag;
            }
            return tag + len + vale
        } ,
        beep(vol, freq, duration) { 
            aux = this.aux ;           
            v = aux.createOscillator()
            u = aux.createGain()
            v.connect(u)
            v.frequency.value = freq
            v.type = "square"
            u.connect(aux.destination)
            u.gain.value = vol * 0.01
            v.start(aux.currentTime)
            v.stop(aux.currentTime + duration * 0.001)
        },
        printOne(index){
            var a = window.open('', 'PRINT', 'height=600, width=600');
            a.document.write(`<html>
                    <head  >
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=0.8">
                        <meta http-equiv="X-UA-Compatible" >
                        <title>طباعة فاتورة</title>
                        <style>
                            * {
                                margin: 0;
                                padding: 0;
                                box-sizing: border-box;
                            }
                        </style>
                    </head>
                    <body style="text-align: center ;font-size: 14px ;" >`);
            a.document.write('<div> ' + comp_name +' </div>');
            a.document.write('<div> '+this.customer.name +' </div>');
            a.document.write('<div> ' + this.AllItems[index].name +' </div>');
            a.document.write('<div> ' + this.AllItems[index].way +' </div>');
            a.document.write('</body></html>');
            a.document.close();
            a.onafterprint = () => { a.close(); }
            // console.log(a);
            a.print();
        },
        cancel_data() {
            //this.new_row = true;
            //this.edit_row_data = {};
            //this.selectedRow = -1;

        },
        save_pay_data() {
            //-----------
            this.coust_pay.coust = this.customer.id
            // اضافة جديد
            var url = new URL(window.location.href + '/../../customers_api/save_coust_pay');
            params = this.coust_pay;
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    if (data.id > 0) {
                        const elem = document.getElementById("pay_Modal");
                        const modal = bootstrap.Modal.getInstance(elem);
                        modal.hide();
                        Swal.fire(
                            'عمل رائع',
                            'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                            'success'
                        );
                    } else {
                        Swal.fire(
                            'تنبية',
                            " لم تتم عملية الاضافة حصل خطأ ",
                            'error'
                        );
                    }
                });
        },
    },
    computed: {
        // a computed getter
        total() {
            total = 0.0;
            this.AllItems.forEach(function (element) {
                element.total = (
                    (parseFloat(element.public_price) * parseFloat(element.count))
                    +
                    (parseFloat((element.public_price) * parseFloat((element.count) * parseFloat(element.vat))))
                ).toFixed(2)
                total += parseFloat(element.public_price) * parseFloat(element.count);
                // total += parseFloat(element.total) ;
            });
            return parseFloat(total).toFixed(2);
        },
        now() {
            return Date.now()
        },
        vat() {
            //vat_mount
            vat = 0.0;
            this.AllItems.forEach(function (element) {
                el_vat = ((element.public_price * element.vat) * element.count);
                vat += parseFloat(el_vat);
            });
            return parseFloat(vat).toFixed(2);
        },
        totalAfterDiscount() {
            return parseFloat(this.total) - parseFloat(this.discount);
        },
        totalAfterAll() {
            return parseFloat(this.totalAfterDiscount) + parseFloat(this.vat);
        },
        BaqeeHalal() {
            var halal = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            if (halal < 1)
                return halal
            else
                return 0.0
        },
        TheRest() {
            var rest = (this.GivenByCustomer - this.totalAfterAll.toFixed(2)).toFixed(2)
            return rest
        }

    }
});
