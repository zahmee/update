Vue.component('v-select', VueSelect.VueSelect);

var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        err: '',
        account: '',
        day_date: {
            day: 01,
            month: 01,
            year: 2019
        },
        suppliers: [],
        payment_methods: [],
        payment_method: 0,
        vat_inp:''  ,
        total_vat:'' ,
        bill_no: '',
        memo: '',

    },
    created() {
        var today = new Date();
        this.day_date.year = today.getFullYear()
        this.day_date.month = today.getMonth() + 1
        this.day_date.day = today.getDate()
        this.$http.get(this.URL + '/../../suppliers_bills_api/get_supp').then(response => {
            if (response.body != "") {
                this.suppliers = response.body;
            }
        }).then(res => {
            this.$http.get(this.URL + '/../../suppliers_bills_api/get_payment_method').then(response => {
                if (response.body != "") {
                    this.payment_methods = response.body;
                }
            });
        });
    },
    methods: {
        SaveAll() {
            data = {
                day : this.day_date ,
                payment_method : this.payment_method ,
                suppliers : this.account.id ,
                bill_no : this.bill_no ,
                vat_inp : parseFloat(this.vat_inp).toFixed(2)  ,
                total_vat : parseFloat(this.total_vat).toFixed(2)  ,
                total_no_vat: this.total_no_vat.toFixed(2),
                memo: this.memo ,
            }
            this.$http.post(this.URL + '/../../suppliers_bills_api/new_bill/', JSON.stringify(data), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body === '0') {
                        window.open(purl + "/../..", '_self');
                    }
                } else {
                    console.log('err');
                }
            });
        },
        chk_date() {
            var today = new Date();
            if (this.day_date.day > 31 || this.day_date.day < 1) {
                this.day_date.day = today.getDate()
            }
            if (this.day_date.month > 12 || this.day_date.month < 1) {
                this.day_date.month = today.getMonth() + 1
            }
            if (this.day_date.year > 2030 || this.day_date.year < 2020) {
                this.day_date.year = today.getFullYear()
            }
        },
    },
    computed: {
        FormErr() {
            if (this.account && this.payment_method > 0 && parseFloat(this.vat_inp) > -1 && parseFloat(this.total_vat) > -1 && this.bill_no) {
                return true;
            } else {
                return false;
            }
        },
        total_no_vat(){
            if (parseFloat(this.total_vat) > 0 && parseFloat(this.vat_inp)>-1){
                return parseFloat(this.total_vat) - parseFloat(this.vat_inp) ;
            } else {
                return 0
            }
        }
    },
});
