Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true,
            userType: 0,
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        cust_in: [],
        cust_out: [],
        coust_pay: {
            coust: 0,
            mount: 0.0,
            note: '',
            type: 0,
            pay_note: '',

        },
    },
    created() {
        fetch(window.location.href + '/../../customers_api/get_customers', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc,
                    userType: this.getData.userType
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc,
                    userType: this.getData.userType

                }
            }

            var url = new URL(window.location.href + '/../../customers_api/get_customers'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        get() {
            //
            //
        },
        open_add() {
            window.open(window.location.href + '/../new', '_self');
        },
        showmoor() {
            this.getData.page++;
            var url = new URL(window.location.href + '/../../customers_api/get_customers'),
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.select_obj_1.select_id,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            sup = {};
            this.options.forEach((el) => {
                if (el.value === row.suppliers) {
                    sup = el;
                }
            })
            if (sup == {}) {
                sup = { value: 0, label: 'اختر' };
            }
            this.edit_row_data.suppliers = sup;

            if (row.flexible_price === 'T') {
                this.edit_row_data.flexible_price = true;
            } else {
                this.edit_row_data.flexible_price = false;
            }
        },
        edit_row() {
            this.new_row = false;
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_data() {
            //var myModalEl = document.getElementById('exampleModal');
            //var row_modal = bootstrap.Modal.getInstance(myModalEl);
            if (!this.edit_row_data.name || !this.edit_row_data.mobile) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [الاسم - رقم الجوال  ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../customers_api/new_customer');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.edit_row_data.name = this.edit_row_data.name.toLowerCase().trim()
                            this.data.push(this.edit_row_data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            this.new_row = true;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../customers_api/edit_customer');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.name = this.edit_row_data.name.toLowerCase().trim()
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        items_history() {
            url = window.location.href + '/../customer_status_rep/' + this.edit_row_data.id;
            window.open(url);
        },
        items_sales() {
            url = window.location.href + '/../purchase/' + this.edit_row_data.id;
            window.open(url);
        },
        adjust_quantity() {
            url = window.location.href + '/../customers_pay/' + this.edit_row_data.id;
            window.open(url);
        },
        items_history2() {
            // ================
            fetch(window.location.href + '/../../customers_api/get_fast_data/' + this.edit_row_data.id, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
                .then(data => {
                    this.cust_in = data.in;
                    this.cust_out = data.out;


                })
        },
        save_pay_data() {
            //-----------
            console.log(this.coust_pay);
            this.coust_pay.coust = this.edit_row_data.id
            // اضافة جديد
            var url = new URL(window.location.href + '/../../customers_api/save_coust_pay');
            params = this.coust_pay;
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    if (data.id > 0) {
                        const elem = document.getElementById("pay_Modal");
                        const modal = bootstrap.Modal.getInstance(elem);
                        modal.hide();
                        Swal.fire(
                            'عمل رائع',
                            'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                            'success'
                        );
                    } else {
                        Swal.fire(
                            'تنبية',
                            " لم تتم عملية الاضافة حصل خطأ ",
                            'error'
                        );
                    }
                });
        },
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    }
});
