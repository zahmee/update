Vue.component('v-select', VueSelect.VueSelect);

function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments, ctx = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

var API_BASE = window.location.href + '/../../customers_api/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true,
            userType: 0,
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        cust_in:  [],
        cust_out: [],
        coust_pay: { coust: 0, mount: 0.0, note: '', type: 0, pay_note: '' },
        loading: false,
    },
    created() {
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);
        this.loading = true;
        fetch(API_BASE + 'get_customers', {
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        }).then(r => r.json())
          .then(data => {
              this.data           = data.data;
              this.data_row_count = data.count;
          }).finally(() => { this.loading = false; });
    },
    computed: {
        // مجاميع ظاهرة في الصفحة الحالية فقط
        totalInv() {
            return this.data.reduce((s, r) => s + parseFloat(r.cus_inv || 0), 0).toFixed(2);
        },
        totalPay() {
            return this.data.reduce((s, r) => s + parseFloat(r.cus_pay || 0), 0).toFixed(2);
        },
        totalBal() {
            return (parseFloat(this.totalInv) - parseFloat(this.totalPay)).toFixed(2);
        },
        totalPages() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage() {
            return this.getData.page + 1;
        },
        visiblePages() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData(extraParams) {
            const params = {
                page:        this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText:  this.getData.SearchText,
                SortBy:      this.getData.SortBy,
                sequence:    this.getData.sortAsc,
                userType:    this.getData.userType,
                ...extraParams,
            };
            const url = new URL(API_BASE + 'get_customers');
            Object.keys(params).forEach(k => url.searchParams.append(k, params[k]));
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(r => r.json());
        },
        onChange() {
            this.getData.page = 0;
            this.selectedRow  = -1;
            this.loading = true;
            this.fetchData().then(data => {
                this.data           = data.data;
                this.data_row_count = data.count;
            }).finally(() => { this.loading = false; });
        },
        goToPage(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).finally(() => { this.loading = false; });
        },
        sortBy(field) {
            this.getData.SortBy  = (this.getData.SortBy === field)
                ? field : field;
            this.getData.sortAsc = (this.getData.SortBy !== field) ? true
                : !this.getData.sortAsc;
            this.getData.SortBy  = field;
            this.onChange();
        },
        rowClass(row) {
            if (selectedRow === this.data.indexOf(row)) return '';
            const bal = parseFloat(row.cus_inv || 0) - parseFloat(row.cus_pay || 0);
            if (bal > 500)  return 'table-danger';   // مديونية عالية
            if (bal > 0)    return 'table-warning';  // مديونية بسيطة
            return '';
        },
        rowSelect(index, row) {
            this.selectedRow   = index;
            this.edit_row_data = { ...row };
        },
        edit_row() { this.new_row = false; },
        new_row_click() {
            this.new_row       = true;
            this.edit_row_data = {};
        },
        save_data() {
            if (!this.edit_row_data.name || !this.edit_row_data.mobile) {
                Swal.fire('تنبية', 'يجب ادخال [الاسم - رقم الجوال].', 'error');
                return;
            }
            const endpoint = this.new_row ? 'new_customer' : 'edit_customer';
            const url = new URL(API_BASE + endpoint);
            Object.keys(this.edit_row_data).forEach(k =>
                url.searchParams.append(k, this.edit_row_data[k]));
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (data.id > 0) {
                        const saved = { ...this.edit_row_data, id: data.id };
                        saved.name = saved.name.trim();
                        if (this.new_row) {
                            this.data.push(saved);
                        } else {
                            // إصلاح: Vue 2 reactivity — يجب استخدام $set
                            this.$set(this.data, this.selectedRow, saved);
                        }
                        this.edit_row_data = {};
                        this.selectedRow   = -1;
                        this.new_row       = true;
                        bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', data.mess || 'حصل خطأ', 'error');
                    }
                });
        },
        cancel_data() {
            this.edit_row_data = {};
            this.selectedRow   = -1;
            this.new_row       = true;
        },
        items_history() {
            window.open(window.location.href + '/../customer_status_rep/' + this.edit_row_data.id);
        },
        items_sales() {
            window.open(window.location.href + '/../purchase/' + this.edit_row_data.id);
        },
        adjust_quantity() {
            window.open(window.location.href + '/../customers_pay/' + this.edit_row_data.id);
        },
        items_history2() {
            fetch(API_BASE + 'get_fast_data/' + this.edit_row_data.id, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(r => r.json())
              .then(data => {
                  this.cust_in  = data.in;
                  this.cust_out = data.out;
              });
        },
        coust_pay_click() {
            this.coust_pay = { coust: 0, mount: 0.0, note: '', type: 0, pay_note: '' };
        },
        save_pay_data() {
            if (!this.coust_pay.mount || parseFloat(this.coust_pay.mount) <= 0) {
                Swal.fire('تنبية', 'يجب إدخال مبلغ صحيح أكبر من صفر.', 'error');
                return;
            }
            this.coust_pay.coust = this.edit_row_data.id;
            const url = new URL(API_BASE + 'save_coust_pay');
            Object.keys(this.coust_pay).forEach(k =>
                url.searchParams.append(k, this.coust_pay[k]));
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (data.id > 0) {
                        bootstrap.Modal.getInstance(document.getElementById("pay_Modal")).hide();
                        // تحديث رصيد العميل في الجدول
                        if (this.selectedRow >= 0) {
                            const row = { ...this.data[this.selectedRow] };
                            row.cus_pay = (parseFloat(row.cus_pay || 0) + parseFloat(this.coust_pay.mount)).toFixed(2);
                            this.$set(this.data, this.selectedRow, row);
                        }
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبية', 'لم تتم عملية الإضافة. حصل خطأ.', 'error');
                    }
                });
        },
    },
    watch: {
        'getData.userType': function() { this.onChange(); }
    }
});
