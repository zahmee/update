var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        sum_total: 0,
    },
    created() {
        fetch(window.location.href + '/../get_movment', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
                this.sum_total = 0;
                this.data.forEach((el) => {
                    if (el.process_type == '1') {
                        this.sum_total = el.amount + this.sum_total;
                    } else {
                        this.sum_total = this.sum_total - el.amount;
                    }
                    el['sum_total'] = this.sum_total.toFixed(2);;
                })
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../get_movment'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    }).then(() => {
                        this.sum_total = 0;
                        this.data.forEach((el) => {
                            if (el.process_type == '1') {
                                this.sum_total = el.amount + this.sum_total;
                            } else {
                                this.sum_total = this.sum_total - el.amount;
                            }
                            el['sum_total'] = this.sum_total.toFixed(2);;
                        })
                    });
        },
        get() {
            //
            //
        },
        open_add() {
            window.open(window.location.href + '/../new', '_self');
        },
        showmoor() {
            this.getData.page++;
            var url = new URL(window.location.href + '/../get_movment'),
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.select_obj_1.select_id,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                }).then(() => {
                    this.data.forEach((el) => {
                        if (el.sum_total === 0) {
                            if (el.process_type == '1') {
                                this.sum_total = el.amount + this.sum_total;
                            } else {
                                this.sum_total = this.sum_total - el.amount;
                            }
                            el['sum_total'] = this.sum_total.toFixed(2);;
                        }
                    })
                })
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
        },
        edit_row() {
            this.new_row = false;
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {};
            this.edit_row_data.aprove = false;
        },
        save_data() {
            if (!this.edit_row_data.process_date || !this.edit_row_data.process_type
                || !this.edit_row_data.detill || !this.edit_row_data.amount) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال  جميع الحقول للحفظ .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../new_movment');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.data.push(this.edit_row_data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            this.new_row = true;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../edit_movment');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        delete_row() {
            Swal.fire({
                title: 'هل انت متأكد',
                text: "هل ترغب بحذف هذا السجل !",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا'
            }).then((result) => {
                if (result.value) {
                    this.$http.get(this.URL + '/../del_movment/' + this.edit_row_data.id).then(response => {
                        if (response.body.mess === 1) {
                            this.data.splice(this.selectedRow, 1);
                            Swal.fire({
                                title: "تم الحذف بنجاح",
                            })
                        } else {
                            Swal.fire(
                                'لم تتم العملية',
                                response.body.mess,
                                'error'
                            )
                        }
                    });
                }
            })
        },
        aprove_row() {
            this.$http.get(this.URL + '/../aprove_movment/' + this.edit_row_data.id).then(response => {
                if (response.body.id > 1) {
                    this.data[this.selectedRow] = response.body;
                    this.edit_row_data = {};
                    this.selectedRow = -1;
                } else {
                    Swal.fire(
                        'لم تتم العملية',
                        response.body.mess,
                        'error'
                    )
                }
            });
        },
        link_1() {
            //this.edit_row_data.id
            console.log(this.edit_row_data);
            window.open(this.URL + "/../../fund/print/" + this.edit_row_data.id);
        },
    },
    

    watch: {
        value: function (val) {
            this.onChange();
        }
    }
});
