
var app = new Vue({
    el: '#app',
    data: {
        options: [],
        da11: 1,
        da12: 0,
        da13: 0,
        da1_1: '00',
        da1_2: '00',
        da21: 0,
        da22: 0,
        da23: 0,
        da2_1: '24',
        da2_2: '00',

    },
    created() {
        var today = new Date();
        var d = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
        this.da12 = today.getMonth() + 1;
        this.da13 = today.getFullYear();
        this.da21 = d;
        this.da22 = today.getMonth() + 1;
        this.da23 = today.getFullYear();
    },
    methods: {
        createRep1() {
            fetch(window.location.href + '/../pre_report1', {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
                .then(data => {
                    Swal.fire(
                        'يتم التجهيز',
                        ' يتم تجهيز ملف التقرير في الخلفية <br> الرجاء تحديث الصفحة بعد بضع دقائق ،،',
                        'success'
                    );

                })
        },
        isValidDate(dateString) {
            // First check for the pattern
            if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString))
                return false;
            // Parse the date parts to integers
            var parts = dateString.split("/");
            var day = parseInt(parts[1], 10);
            var month = parseInt(parts[0], 10);
            var year = parseInt(parts[2], 10);
            // Check the ranges of month and year
            if (year < 1000 || year > 3000 || month == 0 || month > 12)
                return false;
            var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            // Adjust for leap years
            if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
                monthLength[1] = 29;
            // Check the range of the day
            return day > 0 && day <= monthLength[month - 1];
        },
        createRep2() {

            var da1 = this.da12 + '-' + this.da11 + '-' + this.da13 + ' ' + this.da1_1 + ':' + this.da1_2;
            var da2 = this.da22 + '-' + this.da21 + '-' + this.da23 + ' ' + this.da2_1 + ':' + this.da2_2;
            if (!this.isValidDate(this.da12 + '/' + this.da11 + '/' + this.da13) || 
                !this.isValidDate(this.da22 + '/' + this.da21 + '/' + this.da23)) {
                Swal.fire(
                    'تنبية',
                    'التاريخ المدخل غير صحيح !',
                    'error'
                );
                return;
            }
            var url = new URL(window.location.href + '/../pre_report2'),
                params = {
                    da1: da1,
                    da2: da2,
                }
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
                .then(data => {
                    Swal.fire(
                        'يتم التجهيز',
                        ' يتم تجهيز ملف التقرير في الخلفية <br> الرجاء تحديث الصفحة بعد بضع دقائق ،،',
                        'success'
                    );

                })

        },
    }
});
