Vue.component('v-select', VueSelect.VueSelect);
var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        supplier:[] ,
        Allsupplier:[] ,

    },
    created() {
        this.getData.SortBy = 'id';
        this.getData.sortAsc = false;

        fetch(window.location.href + '/../../suppliers_api/get_opening_balance', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
                fetch(window.location.href + '/../../api_1/min_suppliers_1')
                    .then(response => response.json())
                    .then(data => {
                        this.supplier = data;
                        this.Allsupplier = data;
                        op = this.options;
                        data.forEach(function (el) {
                            new_el = {
                                value: el.id,
                                label: '[' + el.id + '] - ' + el.name
                            }
                            //
                            op.push(new_el);
                        });
                    })
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../suppliers_api/get_opening_balance'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;

                    });
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined') {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/get_supp'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })

                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
        },
        on_change_select() {
            this.$forceUpdate();
        },

        edit_row() {
            this.new_row = false;
            this.edit_row_data.supplier = { value: this.edit_row_data.supplier, label: this.edit_row_data.supplier_n }
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {
            };
        },
        save_data() {
            if (!this.edit_row_data.supplier || !this.edit_row_data.year_balance 
                || !this.edit_row_data.account   ) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [ المورد - السنة - المبلغ ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_o_b');
                params = this.edit_row_data;
                params.supplier = JSON.stringify(this.edit_row_data.supplier);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.data.splice(0, 0, data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.err,
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/edit_o_b');
                params = this.edit_row_data;
                params.supplier = JSON.stringify(this.edit_row_data.supplier);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            //this.edit_row_data.id = data.id;
                            this.data[this.selectedRow] = data ;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.err,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        account_movement() {
            url = window.location.href + '/../../suppliers_report/account_movement/' + this.edit_row_data.id;
            window.open(url, "_self"); //items_qry/items_sales
        },
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    },
    computed: {
        total_no_vat() {
            if (parseFloat(this.edit_row_data.bill_total) > 0 && parseFloat(this.edit_row_data.bill_vat) > -1) {
                return (parseFloat(this.edit_row_data.bill_total) - parseFloat(this.edit_row_data.bill_vat)).toFixed(2);
            } else {
                return 0
            }
        }
    },

});
