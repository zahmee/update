Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
            counter: 0,
            data: [],
            day_date: {
                day: 01,
                month: 01,
                year: 2019
            },  
            getData: {
                page: 0,
                RecordCount: 20,
                SearchText: '',
                SortBy: 'id',
                sortAsc: true
            },
            data_row_count: 0,
            coding: {
                supplier: [],
                Allsupplier: [],
            },
            select_obj_1: {
                serch_text: '',
                show_select: false,
                select_value: '',
                select_id: '',
            },
            select_obj_2: 0,
            showBtn: 0,
            show_model: false,
            selectedRow: -1,
            text_ltr: false,
            new_row: true,
            edit_row_data: {},
            value: '',
            options: [] ,
    },
    created() {
        this.getData.SortBy=  'id' ;
        this.getData.sortAsc = false ;
        fetch(window.location.href + '/../../suppliers_api/getRetSuppInvoce', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
                fetch(window.location.href + '/../../api_1/min_suppliers_1')
                    .then(response => response.json())
                    .then(data => {
                        this.coding.supplier = data;
                        this.coding.Allsupplier = data;
                        op = this.options ;
                        data.forEach(function(el){
                            new_el ={
                                value: el.id ,
                                label: "["+el.id+"]  -  " + el.name
                            }
                            op.push(new_el);
                        });

                    }) 
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../suppliers_api/getRetSuppInvoce'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined' ){
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/getRetSuppInvoce'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            sup = {} ;
            this.options.forEach((el)=>{
                if (el.value === row.supplier ){
                    sup.value = el.value;
                    sup.label = el.label;
                }
            })
            this.edit_row_data.suppliers = sup ;
        },
        edit_row() {
            this.new_row = false;
            var today = new Date(this.edit_row_data.ret_date);
            this.day_date.year = today.getFullYear()
            this.day_date.month = today.getMonth() + 1
            this.day_date.day = today.getDate()
        },
        on_change_select(){
            this.$forceUpdate();
        } ,
        new_row_click() {
            this.new_row = true;
            var today = new Date();
            this.day_date.year = today.getFullYear() ;
            this.day_date.month = today.getMonth() + 1 ;
            this.day_date.day = today.getDate() ;
            this.edit_row_data = {
                suppliers : '' ,
            };
        },
        chk_date() {
            var today = new Date();
            if (this.day_date.day > 31 || this.day_date.day < 1) {
                this.day_date.day = today.getDate()
            }
            if (this.day_date.month > 12 || this.day_date.month < 1) {
                this.day_date.month = today.getMonth() + 1
            }
            if (this.day_date.year > 2030 || this.day_date.year < 2020) {
                this.day_date.year = today.getFullYear()
            }
        },

        save_data() {
            if ( !this.day_date.year || !this.day_date.month || 
                !this.edit_row_data.name || !this.edit_row_data.suppliers.value || !this.day_date.day ) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [كافة الحقول لكي تحفظ ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_RetSupInv');
                params =this.edit_row_data ;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.suppliers);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id ;
                            this.coding.supplier.forEach(row => {
                                if (row.id === data.supplier ) {
                                    this.edit_row_data.s_name = row.name;
                                }
                            });
                            this.edit_row_data.ret_date = data.ret_date ;
                            this.edit_row_data.itm_r_count = 0;
                            this.edit_row_data.itm_count = 0;
                            this.edit_row_data.admin_accept = 'F';
                            this.edit_row_data.total = 0.0;
                            this.edit_row_data.real_total = 0.0;                             
                            this.data.splice(0, 0,this.edit_row_data);
                            this.edit_row_data = {} ;
                            this.selectedRow = -1 ;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/edit_RetSupInv');
                params = this.edit_row_data;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.suppliers);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.coding.supplier.forEach(row => {
                                if (row.id === data.supplier) {
                                    this.edit_row_data.s_name = row.name;
                                }
                            });
                            this.edit_row_data.ret_date = data.ret_date.substring(0, 10);;
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess ,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1 ;

        },
        invoce_insert_items(){
            url = window.location.href + '/../../suppliers/returned_supply_det/' + this.edit_row_data.id;
            window.open(url, "_self");
        } ,
        invoce_print_report() {
            url = window.location.href + '/../../suppliers/returned_supply_print/' + this.edit_row_data.id;
            window.open(url, "_self"); //items_qry/items_sales
        } ,
        invoce_barcode_print() {
            url = window.location.href + '/../../suppliers/returned_supply_count/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_print_return() {
            url = window.location.href + '/../../suppliers/return_suppliers_bills_print/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_print_sales(){
            url = window.location.href + '/../../suppliers/returned_supply_approving/' + this.edit_row_data.id;
            window.open(url, "_self");
        } ,
    } ,
    watch: {
        value : function (val) {
            this.onChange() ;
            //this.$forceUpdate();
        }
    } ,
    /*
    computed: {
        total_no_vat() {
            if (parseFloat(this.edit_row_data.bill_total) > 0 && parseFloat(this.edit_row_data.bill_vat) > -1) {
                return (parseFloat(this.edit_row_data.bill_total) - parseFloat(this.edit_row_data.bill_vat)).toFixed(2) ;
            } else {
                return 0
            }
        }
    },
    */

}) ;
