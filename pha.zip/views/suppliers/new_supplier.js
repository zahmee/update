var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        id: this.id,
        data: [],
        err: '',
        administrator_name:[] ,
        data :{
            name :'' ,
            administrator_name : [] ,
            total_amount : 0 ,
            tel : [] ,
            address : '' 
        }
    },
    methods: {
        SaveAll(){
            this.data.administrator_name = this.administrator_name ;
            this.$http.post(this.URL + '/../../new_suppliers_api/new_supplier/', JSON.stringify(this.data), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body === '0' ) {
                        window.open(purl + "/../" , '_self');
                    }
                } else {
                    console.log('err');
                }
            });
        } ,
    } ,
    computed: {
        FormErr() {
            if (this.data.name!="" ||  this.data.total_amount!="" ) {
                return true;
            } else {
                return false;
            }
        },

    },

});
