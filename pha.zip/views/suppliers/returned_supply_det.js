var app = new Vue({
    el: '#app',
    data: {
        new_and_edit_row: {},
        edit_row_index: 0,
        item_to_add: {},
        NewItem: [],
        AllItems: [],
        invno: this.inv_no,
        inv_items: [],
        SerchItem : '' ,
        new_row: true,
        data :[] ,
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
    },
    created() {
        fetch(window.location.href + '/../../../suppliers_api/getRetSuppInvoceDet/' + this.invno, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data;
                //this.inv_items = data ;
            });
    },
    methods: {
        getitem() {
            if (!this.SerchItem ) {
                return;
            }
            this.inv_items.forEach(el => {
                if (el.item_id === this.SerchItem) {
                    Swal.fire(
                        'تنبية',
                        'هذا الصنف مدخل من قبل !',
                        'error'
                    );
                    return;
                }
            });
            //*************************************** */
            head = {
                'Content-Type': 'application/json',
                    'Accept': 'application/json'
            }
            fetch(window.location.href + '/../../../suppliers_api/getit/' + this.SerchItem, {
                headers: head
            }).then(response => response.json())
                .then(data => {
                    this.new_and_edit_row.expiration_date = data[0].expiration_date;
                    this.new_and_edit_row.it_name = data[0].it_name;
                    this.new_and_edit_row.item_idr = data[0].item_idr;
                    this.new_and_edit_row.supplier_inv = data[0].supplier_inv;
                    this.new_and_edit_row.vat = data[0].vat;
                    this.new_and_edit_row.s_name = data[0].s_name;
                    this.new_and_edit_row.item_name = data[0].it_name;
                    this.new_and_edit_row.item_id = this.SerchItem ;
                    app.$forceUpdate();
                    this.$refs.count.focus();

                });
        },
        DeleteRow() {
            Swal.fire({
                title: 'هل انت متأكد',
                text: "هل ترغب بحذف هذا السجل !",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا'
            }).then((result) => {
                if (result.value) {
                    head = {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                    this.SerchItem = '';
                    fetch(window.location.href + '/../../../suppliers_api/delete_RetSupInvDet/' + this.new_and_edit_row.id, {
                        headers: head
                    }).then(response => response.json())
                        .then((data) => {
                            if (data==='0'){
                                this.data.splice(this.edit_row_index, 1);
                                this.CancelEditItem() ;
                            } else {
                                Swal.fire(
                                    'لم تتم العملية',
                                    data ,
                                    'error'
                                )
                            }
                        });
                }
            })
        },
        editItem(index) {
            this.edit_row = true;
            this.edit_row_index = index ;
            editRow = this.inv_items[index];
            this.item_to_add.name = editRow.name;
            this.item_to_add.public_price = editRow.public_price;
            this.item_to_add.buy_price = editRow.buy_price;
            this.item_to_add.supplier_inv = editRow.supplier_inv;
            this.item_to_add.item_idr = editRow.item_idr;
            this.item_to_add.item_id = editRow.item_id;
            this.item_to_add.expiration_date = editRow.expiration_date;
            this.item_to_add.vat = editRow.vat;
            this.item_to_add.item_count = editRow.item_count;
            this.item_to_add.return_count = editRow.return_count;
            this.item_to_add.inv_price = editRow.inv_price;
            this.item_to_add.id = editRow.id;
            this.item_to_add.vat_in_public_price = editRow.vat_in_public_price;
            return;
        },
        CancelEditItem() {
            this.new_row = true;
            this.SerchItem = '' ;
            this.new_and_edit_row = {};
            this.selectedRow = -1;
            return;
        },
        rowSelect(index, row) {
            this.new_row = false;
            this.edit_row_index = index;
            head = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            this.SerchItem = row.item_id ;
            fetch(window.location.href + '/../../../suppliers_api/getit/' + this.SerchItem, {
                headers: head
            }).then(response => response.json())
                .then(data => {
                    this.new_and_edit_row = { ...row };
                    this.new_and_edit_row.expiration_date = data[0].expiration_date;
                    this.new_and_edit_row.it_name = data[0].it_name;
                    this.new_and_edit_row.item_idr = data[0].item_idr;
                    this.new_and_edit_row.supplier_inv = data[0].supplier_inv;
                    this.new_and_edit_row.vat = data[0].vat;
                    this.new_and_edit_row.s_name = data[0].s_name;
                    this.selectedRow = index;
                    this.new_and_edit_row.id = row.id;
                    if (row.item_count){
                        this.new_and_edit_row.item_count = row.item_count;
                    } else {
                        row.item_count = 0 ;
                        this.new_and_edit_row.item_count = 0 ;
                    }
                });
        },
        SaveAll() {
            this.new_and_edit_row.returned_supply = inv_no;
            head = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../../suppliers_api/new_RetSupInvDet');
                params = this.new_and_edit_row;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: head 
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data.push(data);
                            this.new_and_edit_row = {};
                            this.selectedRow = -1;
                            this.SerchItem = '';
                            document.getElementById("SerchItem").focus();
                            //$('#exampleModal').modal('hide')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../../suppliers_api/edit_RetSupInvDet');
                params = this.new_and_edit_row;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: head
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data[this.selectedRow] = data;
                            this.new_and_edit_row = {};
                            this.selectedRow = -1;
                            this.SerchItem = '';
                            document.getElementById("SerchItem").focus();
                            //row_modal.hide();
                            //$('#exampleModal').modal('hide')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            }
        },
    },
    computed: {
        FormErr() {
            if (this.new_and_edit_row.item_count && this.new_and_edit_row.it_name && this.SerchItem ) {
                return true;
            } else {
                return false;
            }
        },
    } 
});
