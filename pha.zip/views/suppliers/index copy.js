var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        data: [],
        final_account: [],
        err: '',
        account: '',
        start_balance: '',
        suppliers: [],
        find_string: '',
        select_index: -1,
        select_row: {} ,
    },
    created() {
        this.$http.get(this.URL + '/../../new_suppliers_api/get_supp').then(response => {
            if (response.body != "") {
                this.suppliers = response.body;
                this.data = response.body;
                this.data.forEach(el=>{
                    console.log(el);
                    if (el.stoped==='T') {
                        el.stoped = true ;
                    } else {
                        el.stoped = false ;
                    }
                })
                
            }
        });
    },
    methods: {
        select_row_data(index) {
            if (index === this.select_index) {
                this.select_index = -1;
            } else {
                this.select_index = index;
                this.select_row = this.data[this.select_index] ;
            }
        },
        get_report_data() {
            var report_data = {};

        },
        find_data() {
            if (this.find_string.length > 1) {
                this.select_index = -1;
                app = this;
                this.data = [];
                this.suppliers.forEach(function (element) {
                    var s1 = element.name.indexOf(app.find_string);
                    if (s1 > -1) {
                        app.data.push(element);
                    }
                });

            } else {
                this.data = this.suppliers;
            }
        },
        account_movement() {
            row = this.data[this.select_index]
            window.open(purl + "/../../suppliers_report/account_movement/" + row.id, '_blank');
        },
        supply_bills(){
            row = this.data[this.select_index]
            window.open(purl + "/../../suppliers/supply_bills2/" + row.id, '_blank');
        },
        account_lock() {
            row = this.data[this.select_index]
            this.$http.get(this.URL + '/../../new_suppliers_api/supply_lock/' + row.id ).then(response => {
                if (response.body == "0") {
                    row.stoped = !row.stoped ;
                }
            });
        },
        edit() {
            row = this.data[this.select_index]
            window.open(purl + "/../edit_supplier?supp=" + row.id,'_self');
        },
        new_suppl(){
            window.open(purl + "/../new_supplier" , '_self');
        } ,
        delete_row(){
            row = this.data[this.select_index]
            Swal.fire({
                title: 'هل انت متأكد',
                text: "انت على وشك حذف هذا السجل  !!!!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا',
            }).then((result) => {
                if (result.value) {
                    this.$http.post(this.URL + '/../../new_suppliers_api/delete_supplier/', JSON.stringify(row), { emulateJSON: true }).then(response => {
                        if (response.body != "") {
                            if (response.body === '0') {
                                this.data.splice(this.select_index, 1);
                                Swal.fire(
                                    'تمت العملية',
                                    'تم حذف السجل بنجاح',
                                    'success'
                                );
                                return 'ok';
                            }
                        } else {
                            console.log('err');
                            return 'not';
                        }
                    }).then(res => {
                        if (res == "ok") {
                            this.select_index = -1;
                        }
                    });
                }
            })
        }

    },
    computed: {

    }
});
