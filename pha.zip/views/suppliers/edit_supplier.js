var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        id: this.id,
        data: [],
        err: '',
        administrator_name:[] ,
    },
    created() {

        this.$http.get(this.URL + '/../../new_suppliers_api/get_supp_id/'+this.id ).then(response => {
            if (response.body != "") {
                this.data = response.body;
                this.administrator_name = response.body.administrator_name
            }
        });

    },
    methods: {
        get_report_data() {
            var report_data = {};

        },
        SaveAll(){
            this.$http.post(this.URL + '/../../new_suppliers_api/update_supplier/', JSON.stringify(this.data), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body === '0' ) {
                        window.open(purl + "/../" , '_self');
                    }
                } else {
                    console.log('err');
                }
            });
        } ,
    } ,
    computed: {
        FormErr() {
            if (this.data.name != "" || this.data.total_amount != "") {
                return true;
            } else {
                return false;
            }
        },

    },

});
