Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        day_date: {
        day: 01,
        month: 01,
        year: 2019
        },
        getData: {
        page: 0,
        RecordCount: 20,
        SearchText: '',
        SortBy: 'id',
        sortAsc: true
        },
        data_row_count: 0,
        coding: {
        supplier: [],
        Allsupplier: [],
        types: [],
        units: [],
        },
        select_obj_1: {
        serch_text: '',
        show_select: false,
        select_value: '',
        select_id: '',
        },
        select_obj_2 : 0 ,
        showBtn : 0 ,
        show_model : false,
        selectedRow : -1 ,
        text_ltr : false,
        new_row : true ,
        edit_row_data: {} ,
        value : '' ,
        options : [] ,
    },
    created() {
        this.getData.SortBy = 'id';
        this.getData.sortAsc = false;
        fetch(window.location.href + '/../../suppliers_api/getSuppPyment', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
            }).then(() => {
                fetch(window.location.href + '/../../api_1/min_suppliers_1')
                    .then(response => response.json())
                    .then(data => {
                        this.coding.supplier = data;
                        this.coding.Allsupplier = data;
                        op = this.options;
                        data.forEach(function (el) {
                            new_el = {
                                value: el.id,
                                label: '[' + el.id + '] - ' + el.name
                            }
                            //
                            op.push(new_el);
                        });

                    })
                fetch(window.location.href + '/../../suppliers_api/get_payment_type' )
                    .then(response => response.json())
                    .then(data => {
                        this.coding.types = data;
                    })
                fetch(window.location.href + '/../../suppliers_bills_api/get_payment_method')
                    .then(response => response.json())
                    .then(data => {
                        this.coding.payment_method = data;
                    })
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../suppliers_api/getSuppPyment'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                    });
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined') {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/getSuppPyment'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };

            // sup = {};
            // this.options.forEach((el) => {
            //     if (el.value === row.supplier) {
            //         sup = el;
            //     }
            // })
            // if (sup === {}) {
            //     sup = { value: 0, label: 'اختر' };
            // }
            // this.edit_row_data.suppliers = sup ;
            //console.log(this.edit_row_data);
            //this.edit_row_data.suppliers = sup ;
        },
        on_change_select() {
            this.$forceUpdate();
        },

        edit_row() {
            this.new_row = false;
            var today = new Date(this.edit_row_data.pay_date);
            this.day_date.year = today.getFullYear()
            this.day_date.month = today.getMonth() + 1
            this.day_date.day = today.getDate()
            this.edit_row_data.supplier = { value: this.edit_row_data.supplier, label: this.edit_row_data.s_name } ;
            //console.log(this.edit_row_data);

        },
        new_row_click() {
            this.new_row = true;
            var today = new Date();
            this.day_date.year = today.getFullYear()
            this.day_date.month = today.getMonth() + 1
            this.day_date.day = today.getDate()
            // this.edit_row_data = {
            //     suppliers: {
            //         value: '',
            //         label: ''
            //     },
            // };
        },
        chk_date() {
            var today = new Date();
            if (this.day_date.day > 31 || this.day_date.day < 1) {
                this.day_date.day = today.getDate()
            }
            if (this.day_date.month > 12 || this.day_date.month < 1) {
                this.day_date.month = today.getMonth() + 1
            }
            if (this.day_date.year > 2030 || this.day_date.year < 2020) {
                this.day_date.year = today.getFullYear()
            }
        },

        save_data() {
            if (!this.edit_row_data.supplier || !this.edit_row_data.payment_method || !this.day_date.year || !this.day_date.month ||
                !this.edit_row_data.payment_type || !this.edit_row_data.pay_total ||  !this.day_date.day  ) {
                console.log(this.edit_row_data);
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [كافة الحقول لكي تحفظ ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_SP');
                params = this.edit_row_data;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.supplier);
                params.supplier = this.edit_row_data.supplier.value ;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data.splice(0, 0, data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-start',
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            })
                            Toast.fire({
                                icon: 'success',
                                title: 'شكرا لك لقد تمت عملية الحفظ بشكل صحيح'
                            })

                        } else {
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-start',
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            })
                            Toast.fire({
                                icon: 'error',
                                title: 'لم تتم عملية الاضافة حصل خطأ'
                            }) 

                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/edit_SP');
                params = this.edit_row_data;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.supplier);
                params.supplier = this.edit_row_data.supplier.value;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.data[this.selectedRow] = data ;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-start',
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            });
                            Toast.fire({
                                icon: 'success',
                                title: ' لقد تمت عملية الحفظ بشكل صحيح'
                            }) ;
                        } else {
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-start',
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            });
                            Toast.fire({
                                icon: 'error',
                                title: data.mess
                            });

                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        invoce_print_report() {
            url = window.location.href + '/../../items/it_rep1/' + this.edit_row_data.id;
            window.open(url, "_self"); //items_qry/items_sales
        },
        invoce_barcode_print() {
            url = window.location.href + '/../../items/it_prt.svc/' + this.edit_row_data.id;
            window.open(url);
        },
        invoce_print_return() {
            url = window.location.href + '/../../suppliers/return_suppliers_bills_print/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_print_sales() {
            url = window.location.href + '/../../items/it_rep2/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_insert_items() {
            url = window.location.href + '/../../items/it_inv/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_print_files() {
            url = window.location.href + '/../../suppliers/suppliers_bills_files/' + this.edit_row_data.id;
            window.open(url, "_self");
        } ,
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    },
    computed: {
        total_no_vat() {
            if (parseFloat(this.edit_row_data.bill_total) > 0 && parseFloat(this.edit_row_data.bill_vat) > -1) {
                return (parseFloat(this.edit_row_data.bill_total) - parseFloat(this.edit_row_data.bill_vat)).toFixed(2);
            } else {
                return 0
            }
        }
    },

});
