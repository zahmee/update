Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
    },
    created() {
        this.getData.SortBy = 'id';
        this.getData.sortAsc = false;

        fetch(window.location.href + '/../../suppliers_api/get_supp', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = data.data;
                this.data_row_count = data.count;
                this.data.forEach(el => {
                    if (el.stoped === 'T') {
                        el.stoped = true;
                    } else {
                        el.stoped = false;
                    }
                })
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../suppliers_api/get_supp'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = data.data;
                        this.data_row_count = data.count;
                        this.data.forEach(el => {
                            if (el.stoped === 'T') {
                                el.stoped = true;
                            } else {
                                el.stoped = false;
                            }
                        })

                    });
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined') {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/get_supp'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    data.data.forEach(el => {
                        if (el.stoped === 'T') {
                            el.stoped = true;
                        } else {
                            el.stoped = false;
                        }
                    })
                    data.data.forEach(el => {
                        this.data.push(el);
                    })

                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
        },
        on_change_select() {
            this.$forceUpdate();
        },

        edit_row() {
            this.new_row = false;
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {
            };
        },
        save_data() {
            if (!this.edit_row_data.name) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [ اسم المورد ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_supplier');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.data.splice(0, 0, this.edit_row_data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                " لم تتم عملية الاضافة حصل خطأ ",
                                'error'
                            );
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/update_supplier');
                params = this.edit_row_data;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (data.id > 0) {
                            this.edit_row_data.id = data.id;
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'تنبية',
                                data.mess,
                                'error'
                            );
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        account_movement() {
            url = window.location.href + '/../../suppliers/account_movement/' + this.edit_row_data.id;
            window.open(url, "_self"); //items_qry/items_sales
        },
        account_rep5(){
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();
            today1 = dd + ',' + mm + ',' + yyyy;
            today2 = dd + ',' + mm + ',' + yyyy;
            url = window.location.href + '/../../suppliers/rep5?da1=' + today1 + '&da2=' + today2+'&sup=' + this.edit_row_data.id;
            window.open(url, "_blank"); 
        }
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    },
    computed: {
        total_no_vat() {
            if (parseFloat(this.edit_row_data.bill_total) > 0 && parseFloat(this.edit_row_data.bill_vat) > -1) {
                return (parseFloat(this.edit_row_data.bill_total) - parseFloat(this.edit_row_data.bill_vat)).toFixed(2);
            } else {
                return 0
            }
        }
    },

});
