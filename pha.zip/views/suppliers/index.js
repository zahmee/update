Vue.component('v-select', VueSelect.VueSelect);

var API_BASE = window.location.href + '/../../suppliers_api/';

function parseStoped(rows) {
    rows.forEach(function(el) {
        el.stoped = (el.stoped === 'T');
    });
    return rows;
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        loading: false,
    },
    created() {
        this.loading = true;
        this.fetchData().then(function(data) {
            this.data = parseStoped(data.data);
            this.data_row_count = data.count;
        }.bind(this)).finally(function() { this.loading = false; }.bind(this));
    },
    computed: {
        totalPages: function() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function() {
            return this.getData.page + 1;
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc
            };
            if (this.value && this.value.value) {
                params.supplier = this.value.value;
            }
            var url = new URL(API_BASE + 'get_supp');
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); });
        },
        onChange: function() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = parseStoped(data.data);
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = parseStoped(data.data);
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        sortBy: function(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
        },
        edit_row: function() {
            this.new_row = false;
        },
        new_row_click: function() {
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_data: function() {
            if (!this.edit_row_data.name) {
                Swal.fire('تنبية', 'يجب ادخال [ اسم المورد ] .', 'error');
                return;
            }
            var endpoint = this.new_row ? 'new_supplier' : 'update_supplier';
            var url = new URL(API_BASE + endpoint);
            var params = this.edit_row_data;
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); })
              .then(function(data) {
                if (data.id > 0) {
                    if (this.new_row) {
                        this.edit_row_data.id = data.id;
                        this.data.splice(0, 0, this.edit_row_data);
                    } else {
                        this.$set(this.data, this.selectedRow, { ...this.edit_row_data, id: data.id });
                    }
                    this.edit_row_data = {};
                    this.selectedRow = -1;
                    this.new_row = true;
                    bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                    Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                } else {
                    Swal.fire('تنبية', data.mess || 'حصل خطأ', 'error');
                }
            }.bind(this));
        },
        cancel_data: function() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        account_movement: function() {
            window.open(window.location.href + '/../../suppliers/account_movement/' + this.edit_row_data.id, '_self');
        },
        account_rep5: function() {
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0');
            var yyyy = today.getFullYear();
            var d = dd + ',' + mm + ',' + yyyy;
            window.open(window.location.href + '/../../suppliers/rep5?da1=' + d + '&da2=' + d + '&sup=' + this.edit_row_data.id, '_blank');
        }
    },
    watch: {
        value: function() { this.onChange(); }
    }
});
