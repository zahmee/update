Vue.component('v-select', VueSelect.VueSelect);

var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        data: [],
        data2: [],
        accounting_tree: [],
        branches: [],
        final_account: [],
        branch_select: -1,
        page_no: 0,
        err: '',
        account: '',
        start_balance: '',
        start_date: {
            day: 1,
            month: 1 ,
            year: 2019
        },
        end_date: {
            day: 31,
            month: 12,
            year: 2019
        },
        suppliers: [],

    },
    created: function () {
        var start = new Date();
        var end = new Date(start.getFullYear()  , start.getMonth() + 1 , 0);
        this.start_date.month = start.getMonth() + 1
        this.start_date.year = start.getFullYear() 
        this.end_date.month = start.getMonth() + 1
        this.end_date.year = start.getFullYear() 
        this.end_date.day = end.getDate()  
        
        this.$http.get(this.URL + '/../../api_1/min_suppliers_1').then(response => {
            if (response.body != "") {
                this.suppliers = response.body;
                return 'ok';
            }
        });
    },
    methods: {
        onChange() {
            /*
            if (this.branch_select > 0) {
                this.$http.get(this.URL + '/../../setting_api/get_accounting_tree/' + this.branch_select).then(response => {
                    if (response.body != "") {
                        this.accounting_tree = response.body;
                        this.accounting_tree.forEach(el => {
                            el.account_name = el.account_no + " - " + el.account_name_ar;
                        });

                    } else {
                        this.data = [];
                        this.page_data = [];
                    }
                });

            }
            */
        },
        get_report_data() {
            var report_data = {};
            report_data.branch_select = this.branch_select;
            report_data.account = this.account;
            report_data.start_balance = this.start_balance;
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];

            //console.log(report_data);
            this.$http.post(this.URL + '/../../reports_api/acount_balanc_2/', JSON.stringify(report_data), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    this.data = response.body.data;
                    this.data2 = response.body.data2;
                } else {
                    this.data = [];
                }
            });

        },
        show4(){
            var report_data = {};
            report_data.branch_select = this.branch_select;
            report_data.account = this.account;
            report_data.start_balance = this.start_balance;
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep4?da1=" + report_data.start_date + "&da2=" + report_data.end_date , '_blank');
        } ,
        show3() {
            if (this.account){
            var report_data = {};
            report_data.branch_select = this.branch_select;
            report_data.account = this.account;
            report_data.start_balance = this.start_balance;
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep3?da1=" + report_data.start_date + "&da2=" + report_data.end_date + "&sup=" + report_data.account.id, '_blank');
            } else {
                Swal.fire(
                    'تنبية',
                    'يجب اختيار المورد لعرض التقرير !!',
                    'error'
                );

            }
        },
        show2() {
            if (this.account) {
            var report_data = {};
            report_data.branch_select = this.branch_select;
            report_data.account = this.account;
            report_data.start_balance = this.start_balance;
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep2?da1=" + report_data.start_date + "&da2=" + report_data.end_date + "&sup=" + report_data.account.id, '_blank');
            } else {
                Swal.fire(
                    'تنبية',
                    'يجب اختيار المورد لعرض التقرير !!',
                    'error'
                );

            }

        },
        show5() {
            if (this.account) {
                var report_data = {};
                report_data.branch_select = this.branch_select;
                report_data.account = this.account;
                report_data.start_balance = this.start_balance;
                report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
                report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
                window.open(purl + "/../rep5?da1=" + report_data.start_date + "&da2=" + report_data.end_date + "&sup=" + report_data.account.id, '_blank');
            } else {
                Swal.fire(
                    'تنبية',
                    'يجب اختيار المورد لعرض التقرير !!',
                    'error'
                );

            }
        },
    },
    computed: {
        total_dep: function () {
            total = 0.0;
            this.data2.forEach(function (element) {
                if (element.tag1 == 0) {
                    total += element.start_debit;
                }
            });
            this.data.forEach(function (element) {
                total += element.debit;
            });
            return total.toFixed(2);
        },
        total_cre: function () {
            total = 0.0;
            this.data2.forEach(function (element) {
                if (element.tag1 == 0) {
                    total += element.start_credit;
                }
            });
            this.data.forEach(function (element) {
                total += element.credit;
            });
            return total.toFixed(2);
        },
        is_dep: function () {
            if (parseFloat(this.total_dep) > parseFloat(this.total_cre)) {
                return 0;
            } else if (parseFloat(this.total_dep) < parseFloat(this.total_cre)) {
                return 1;
            } else {
                return 2;
            }
        }
    }


});

