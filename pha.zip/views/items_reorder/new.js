Vue.component('v-select', VueSelect.VueSelect);

var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        data: [],
        err: '',
        new_row: {
            dis: '',
            supp_id: 0 ,
            type_id: 0 ,
            avrg_by : 4 ,
            order_by : 1
        },
        suppliers: [],
        type_data:[] ,

    },
    created() {
        this.$http.get(this.URL + '/../get_key_types').then(response => {
            if (response.body != "") {
                 this.type_data = response.body;
            }
        }).then(response => {
            this.$http.get(this.URL + '/../get_suppliers').then(response => {
                if (response.body != "") {
                    this.suppliers = response.body;
                    this.suppliers.unshift({ name: "بدون اختيار", id: -1 });
                }
            });
        });

    },
    methods: {
        SaveAll() {
            this.$http.post(this.URL + '/../addit/', JSON.stringify(this.new_row), { emulateJSON: true }).then(response => {
                if (response.body != "") {
                    if (response.body === '0') {
                        window.open(purl + "/../", '_self');
                    }
                } else {
                    console.log('err');
                }
            });
        },
    },
    computed: {
        FormErr() {
            if (this.new_row.dis != "" &&  this.new_row.avrg_by > 0  && this.new_row.order_by > 0  ) {
                if (this.new_row.supp_id.id === -1 && this.new_row.type_id === "-1" ){
                    return false;
                }
                return true;
            } else {
                return false;
            }
        },
        total_no_vat(){
            return parseFloat(this.total_vat) - parseFloat(this.vat_inp) ;
        }
    },
      
});
