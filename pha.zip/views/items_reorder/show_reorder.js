var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        items_reorder: this.items_reorder_id ,
        data: [],
        data_all: [],
        type_data: [],
        type_select: -1,
        supplier_select: "",
        suppliers: [],
        picked: '10',
        clicked: true,
        find_string: '',
        show_spinner: true ,
        show_best_price: false ,
        show_supp_name: true,
        show_best_price_supp: false,
        show_type: false ,
        show_count : true,
        show_avreg : true,
        show_row: true,
        show_id: true,
        show_important:true ,
        item_id:true ,
        text_ltr:false ,
        new_need : 0.0 ,
    },
    created() {
        this.$http.get(this.URL + '/../get_items_reorder_detail/' + this.items_reorder).then(response => {
            // get body data
            if (response.body != "") {
                this.data = response.body ;
                this.data.forEach(function (e, index) {
                    e.show_row = true ;
                    if (e.order_items === 0 ){
                        e.important = Number(0) ;
                    } else if (e.quantity === 0 && e.order_items > 0 ) {
                        e.important = Number(9999) ;
                    } else {
                        e.important = Number((((e.order_items / e.quantity) * 100) / this.order_by ).toFixed(0))
                    }
                });
                this.data_all =  [...this.data] ;
                this.data_all.forEach(function (e, index) {
                    e.order_items_back = e.order_items ;
                });
                this.show_spinner = false ;
            }
        }) ;
    },
    methods: {
        restore_data(){            
            this.data = [] ;
            this.data_all.forEach(row=> {
                row["order_items"] = row["order_items_back"];
            });
            this.data = this.data_all ;
        }, 
        remove_z() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.order_items > 0) {
                    return e;
                }
            });
        },
        add_avreg_0() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.avrg_items === 0) {
                    return e;
                }
            });
        },
        remove_count() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.quantity <1) {
                    return e;
                }
            });
        },
        delete_reorder(index) {
            Swal.fire({
                title: 'هل انت متأكد',
                text: "انت على وشك حذف  طلبية هذه العملية لا يمكن التراجع عنها ",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا',
            }).then((result) => {
                if (result.value) {
                    window.open(purl + "/../delete_order/" + index, '_self');
                }
            })
        },
        sort_name(){
            app.data = _.orderBy(app.data, ['items_main_name'], ['asc']) ;
        },
        sort_supp() {
            app.data = _.orderBy(app.data, ['supplier'], ['asc']);
        } ,
        sort_type() {
            app.data = _.orderBy(app.data, ['key_type'], ['asc']);
        },
        sort_items_main() {
            app.data = _.orderBy(app.data, ['items_main'], ['asc']);
        },
        sort_quantity() {
            app.data = _.orderBy(app.data, ['quantity'], ['asc']);
        },
        sort_avrg_items() {
            app.data = _.orderBy(app.data, ['avrg_items'], ['asc']);
        },
        sort_order_items() {
            app.data = _.orderBy(app.data, ['order_items'], ['asc']);
        },
        sort_best_price_supp(){
            app.data = _.orderBy(app.data, ['best_price_supp_n'], ['asc']);
        } ,
        sort_important() {
            app.data = _.orderBy(app.data, ['important'], ['asc']);
        },
        remove_supplier(sup){
            //console.log(sup);
            this.data = this.data.filter(function (e, index, arr) {
                if (e.supplier != sup ) {
                    return e;
                }
            });
        } ,
        remove_best_price(){
            this.show_best_price = !this.show_best_price ;
            /*
            this.data.forEach(function (e, index ) {
                e.best_price = '' ;
            });
            */
        },
        remove_supp_name(){
            this.show_supp_name = !this.show_supp_name;
            /*
            this.data.forEach(function (e, index) {
                e.supplier = '';
            });
            */
        } ,
        remove_best_price_supp() {
            this.show_best_price_supp = !this.show_best_price_supp;
            /*
            this.data.forEach(function (e, index) {
                e.best_price_supp_n = '';
            });
            */
        },
        remove_type() {
            this.show_type = !this.show_type;
        },
        remove_count_coul() {
            this.show_count = !this.show_count;
        },
        remove_avg() {
            this.show_avreg = !this.show_avreg;
        },
        remove_item(row){
            this.data.splice(row, 1);
        } ,
        remove_important(){
            this.show_important = !this.show_important;
        } ,
        show_items_main(id){
            window.open(purl + "/../../items/itm_rep_det/" + id );
        } ,
        change_need(){
            //            
            this.data.forEach(row => {
                row['order_items'] = row['order_items'] * this.new_need ;
            });
        }
    } ,
});
