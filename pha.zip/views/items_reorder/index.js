var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        data: [],
        type_data: [],
        type_select: -1,
        supplier_select: "",
        suppliers: [],
        picked: '10',
        clicked: true,
        find_string: '',
    },
    created() {
        this.$http.get(this.URL + '/../get_items_reorder').then(response => {
            // get body data
            if (response.body != "") {
                this.data = response.body;
            }
        }) ;
    },
    methods: {
        onChange() {
            this.clicked = false;
            this.data = [];
            this.$http.get(this.URL + '/../get_items_reorder' ).then(response => {
                if (response.body != "") {
                    this.data = response.body;
                    this.clicked = true;
                }
            });
        },
        new_reorder() {
            window.open(purl + "/../new", '_self');
        },
        delete_reorder(index) {
            Swal.fire({
                title: 'هل انت متأكد',
                text: "انت على وشك حذف  طلبية هذه العملية لا يمكن التراجع عنها ",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا',
            }).then((result) => {
                if (result.value) {
                   this.data.splice(index, 1);
                   console.log("ok");
                   // window.open(purl + "/../delete_order/" + index, '_self');
                }
            })

            
        },
        preparation_reorder(id) {
            window.open(purl + "/../preparation_reorder/" + id , '_self');
        },
        show_reorder(id) {
            window.open(purl + "/../show_reorder/" + id, '_self');
        },
        delete2_reorder() {
            window.open(purl + "/../new", '_self');
        },
    } ,
});

