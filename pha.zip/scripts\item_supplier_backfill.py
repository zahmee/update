# -*- coding: utf-8 -*-
"""مورد الصنف من آخر توريد — تسوية فرع (قرار المالك 2026-09-17).

الأصناف المربوطة بمورد موقوف (مثل "المستودع الرئيسي" الذي كانت أداة "صيانة بيانات
الاصناف" المحذوفة تضعه تلقائياً) تظهر تحت مورد لا يُتعامل معه وتسقط من قوائم إعادة
الطلب حسب المورد. القاعدة: الصنف بلا مورد أو مورده موقوف يأخذ مورد آخر توريد له من
مورد نشط، والصنف الذي له مورد نشط لا يُمس. ما لا توريد له ينتظر أول توريد قادم
(items_qry.addit ← item_rules.fill_supplier_if_missing).

المنطق نفسه الذي ينفّذه زر التسوية في شاشة جودة بيانات الأصناف (modules/item_cleanup.py).

  الوضع الافتراضي: تقرير فقط، لا يكتب حرفاً في القاعدة.
  للتنفيذ الفعلي أضف الوسيط: apply

التشغيل من مجلد web2py:
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/item_supplier_backfill.py
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/item_supplier_backfill.py -A apply

قبل الكتابة تُحفظ القيم القديمة في private/item_data_cleanup_<الوقت>.json للتراجع.
آمن للإعادة: التشغيل الثاني لا يجد ما يحدّثه.
"""
import sys

import item_cleanup

APPLY = any(str(a).strip().lower() == "apply" for a in sys.argv[1:])

rows = item_cleanup.plan_supplier(db)
ready = [r for r in rows if r["new_sup"]]
names = dict(db.executesql("SELECT id, name FROM suppliers"))

print("\n" + "=" * 62)
print("مورد الصنف من آخر توريد — %s" % ("تنفيذ" if APPLY else "تقرير فقط"))
print("=" * 62)
print("أصناف بلا مورد نشط (فارغ أو موقوف): %d" % len(rows))
print("  سيأخذ مورد آخر توريد من مورد نشط:  %d" % len(ready))
print("     منها آخر توريد لها فعلاً:         %d" % sum(1 for r in ready if r["from_latest"]))
print("     ومنها آخر توريد نشط سابق لتوريد من مورد موقوف: %d"
      % sum(1 for r in ready if not r["from_latest"]))
print("  يبقى كما هو حتى أول توريد قادم:     %d" % (len(rows) - len(ready)))

top = {}
for r in ready:
    top[r["new_sup"]] = top.get(r["new_sup"], 0) + 1
if top:
    print("\nأكثر الموردين الجدد:")
    for sid, cnt in sorted(top.items(), key=lambda x: -x[1])[:8]:
        print("  %5d  %s" % (cnt, names.get(sid, sid)))
old_top = {}
for r in rows:
    old_top[r["old_sup"]] = old_top.get(r["old_sup"], 0) + 1
if old_top:
    print("\nالمورد الحالي لهذه الأصناف:")
    for sid, cnt in sorted(old_top.items(), key=lambda x: -x[1])[:5]:
        print("  %5d  %s" % (cnt, names.get(sid, "(فارغ)") if sid else "(فارغ)"))

if not APPLY:
    print("\nلم يُكتب شيء. للتنفيذ: أضف -A apply")
    db.rollback()
elif not ready:
    print("\nلا يوجد ما يُحدَّث (سبق التنفيذ أو لا توريد من مورد نشط).")
    db.rollback()
else:
    res = item_cleanup.apply(db, request.folder, request.now, ["supplier"])
    if res["problems"]:
        print("\nأُلغي التنفيذ: " + " | ".join(res["problems"]))
    else:
        print("\nتم: حُدِّث %d صنفاً. لم يُمس أي صنف له مورد نشط." % res["applied"]["supplier"])
        print("نسخة التراجع: private/%s" % res["backup"])
