# -*- coding: utf-8 -*-
#  type: ignore


import os
import datetime
from gluon.contrib.appconfig import AppConfig
from gluon.tools import Auth

if request.global_settings.web2py_version < "2.15.5":
    raise HTTP(500, "Requires web2py 2.15.5 or newer")

# تطوير محلي فقط: إعادة تحميل وحدات modules/ تلقائياً عند تعديلها (بلا إعادة تشغيل)
if request.is_local:
    from gluon.custom_import import track_changes
    track_changes(True)

configuration = AppConfig(reload=True)
sms_authorization = configuration.get("sms.authorization")
sms_sender = configuration.get("sms.sender")
agent_api_key = configuration.get("agent.api_key")
agent_base_url = configuration.get("agent.base_url")
ai_provider = (configuration.get("ai.provider") or "auto").lower()
ai_anthropic_key = configuration.get("ai.anthropic_api_key")
ai_anthropic_model = configuration.get("ai.anthropic_model") or "claude-haiku-4-5-20251001"
ai_openai_key = configuration.get("ai.openai_api_key")
ai_openai_base_url = configuration.get("ai.openai_base_url") or "https://api.deepseek.com"
ai_openai_model = configuration.get("ai.openai_model") or "deepseek-v4-flash"
ai_batch_items = int(configuration.get("ai.batch_items") or 50)
ai_concurrency = int(configuration.get("ai.concurrency") or 8)

# ===========================================================================================
# رقم إصدار التطبيق — المصدر الوحيد للحقيقة: ملف pha_ver.txt في جذر التطبيق.
#
# لا تكتب رقم الإصدار يدوياً في أي مكان آخر: لا في متحكم، ولا في قالب، ولا في توثيق.
# أي جهة تحتاج الرقم تناديه من هنا. الدوال متاحة تلقائياً في كل المتحكمات والقوالب:
#
#     {{{=app_version()}}}          -> رقم النسخة نصاً        مثل "5.70"
#     app_version_float()           -> نفس الرقم عدداً عشرياً   (للمقارنة مع نسخة الخادم)
#     app_version_modified()        -> تاريخ تركيب النسخة       مثل "2026-08-24 21:10:03"
#
# ملف pha_ver.txt هو نفسه ما يقارنه المحدّث التلقائي (_t.py) مع نسخة GitHub،
# ولذلك يبقى هو المرجع بدل أي ثابت في الكود.
# ===========================================================================================
APP_VERSION_FILE = os.path.join(request.folder, "pha_ver.txt")


def app_version(default="0"):
    """رقم النسخة المحلية كنص، مقروءاً من pha_ver.txt."""
    try:
        with open(APP_VERSION_FILE, "r") as f:
            return f.read().strip() or default
    except Exception:
        return default


def app_version_float(default=0.0):
    """رقم النسخة كعدد عشري — للمقارنة مع النسخة المتاحة على الخادم."""
    try:
        return float(app_version())
    except Exception:
        return default


def app_version_modified(fmt="%Y-%m-%d %H:%M:%S"):
    """تاريخ تركيب النسخة الحالية = وقت آخر تعديل لملف pha_ver.txt."""
    try:
        return datetime.datetime.fromtimestamp(
            os.path.getmtime(APP_VERSION_FILE)
        ).strftime(fmt)
    except Exception:
        return ""


c = datetime.datetime.now()
exp = configuration.get("app.exp_date")
if exp:
    d1 = datetime.datetime.strptime(c.strftime("%Y-%m-%d"), "%Y-%m-%d")
    d2 = datetime.datetime.strptime(exp, "%Y-%m-%d")
    date_def = (d2 - d1).days
    if date_def < 1:
        raise HTTP(
            400,
            (
                "<h1 style='text-align: center;' > نعتذر منك لقد انتهى اشتراكك </h1>"
                f"<h2 style='text-align: center;' > {exp} </h2>"
            ),
        )


if not request.env.web2py_runtime_gae:
    # ---------------------------------------------------------------------
    # if NOT running on Google App Engine use SQLite or other DB
    # ---------------------------------------------------------------------
    db = DAL(
        configuration.get("db.uri"),
        pool_size=configuration.get("db.pool_size"),
        migrate_enabled=configuration.get("db.migrate"),
        check_reserved=["postgres"],
    )
else:
    db = DAL("google:datastore+ndb")
    session.connect(request, response, db=db)

response.generic_patterns = []
if request.is_local and not configuration.get("app.production"):
    response.generic_patterns.append("*")

response.formstyle = "bootstrap4_inline"
response.form_label_separator = ""

auth = Auth(db, host_names=configuration.get("host.names"))

auth.settings.extra_fields["auth_user"] = []
auth.define_tables(username=False, signature=False)

# -------------------------------------------------------------------------
# configure email
# -------------------------------------------------------------------------
mail = auth.settings.mailer
mail.settings.server = (
    "logging" if request.is_local else configuration.get("smtp.server")
)
mail.settings.sender = configuration.get("smtp.sender")
mail.settings.login = configuration.get("smtp.login")
mail.settings.tls = configuration.get("smtp.tls") or False
mail.settings.ssl = configuration.get("smtp.ssl") or False

# -------------------------------------------------------------------------
# configure auth policy
# -------------------------------------------------------------------------
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.settings.reset_password_requires_verification = True
auth.settings.actions_disabled = ['register', 'bulk_register']

# -------------------------------------------------------------------------
# read more at http://dev.w3.org/html5/markup/meta.name.html
# -------------------------------------------------------------------------
response.meta.author = configuration.get("app.author")
response.meta.description = configuration.get("app.description")
response.meta.keywords = configuration.get("app.keywords")
response.meta.generator = configuration.get("app.generator")
response.show_toolbar = configuration.get("app.toolbar")

# -------------------------------------------------------------------------
# your http://google.com/analytics id
# -------------------------------------------------------------------------
response.google_analytics_id = configuration.get("google.analytics_id")

# -------------------------------------------------------------------------
# maybe use the scheduler
# -------------------------------------------------------------------------
if configuration.get("scheduler.enabled"):
    from gluon.scheduler import Scheduler

    scheduler = Scheduler(db, heartbeat=configuration.get("scheduler.heartbeat"))

# -------------------------------------------------------------------------
# Define your tables below (or better in another model file) for example
#
# >>> db.define_table('mytable', Field('myfield', 'string'))
#
# Fields can be 'string','text','password','integer','double','boolean'
#       'date','time','datetime','blob','upload', 'reference TABLENAME'
# There is an implicit 'id integer autoincrement' field
# Consult manual for more options, validators, etc.
#
# More API examples for controllers:
#
# >>> db.mytable.insert(myfield='value')
# >>> rows = db(db.mytable.myfield == 'value').select(db.mytable.ALL)
# >>> for row in rows: print row.id, row.myfield
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# after defining tables, uncomment below to enable auditing
# -------------------------------------------------------------------------
# auth.enable_record_versioning(db)
auth.settings.create_user_groups = False
auth.settings.showid = False
T.force("ar")
response.delimiters = ("{{{", "}}}")

# ===========================================================================================
# Table definitions are split into separate model files:
#   db_1_keys.py       - Lookup/key tables (key_unit, key_payment_method, etc.)
#   db_2_business.py   - Suppliers, Items, Customers, Invoices
#   db_3_operations.py - Inventory, damage, returns, reorder, fund, ZATCA, movement
#   db_4_access.py     - Screens, screen_rules, important_info, can_access(), screens_rules()
#   db_5_hr.py         - HR: employees, salaries, payroll, documents, attendance
# ===========================================================================================
