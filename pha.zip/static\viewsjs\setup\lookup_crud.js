var app = new Vue({
    el: '#app',
    data: {
        cfg: window.LOOKUP_CFG || {},
        key: window.LOOKUP_KEY || '',
        rows: [],
        loading: false,
        saving: false,
        search: '',
        searchTimer: null,
        form: { id: null, name: '', extra: '' },
        error: '',
        modal: null
    },
    mounted: function () {
        this.modal = new bootstrap.Modal(document.getElementById('rowModal'));
        this.loadList();
    },
    methods: {
        loadList: function () {
            var self = this;
            self.loading = true;
            var url = window.LOOKUP_URLS.list + '?key=' + encodeURIComponent(self.key);
            if (self.search) url += '&q=' + encodeURIComponent(self.search);
            Api.get(url).then(function (res) {
                if (Api.isOk(res)) {
                    self.rows = Api.getData(res) || [];
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.loading = false;
            });
        },
        onSearch: function () {
            var self = this;
            clearTimeout(self.searchTimer);
            self.searchTimer = setTimeout(function () { self.loadList(); }, 300);
        },
        defaultExtra: function () {
            return this.cfg.extra ? (this.cfg.extra.default || this.cfg.extra.options[0]) : '';
        },
        openAdd: function () {
            this.form = { id: null, name: '', extra: this.defaultExtra() };
            this.error = '';
            this.modal.show();
            this.focusInput();
        },
        openEdit: function (row) {
            this.form = { id: row.id, name: row.name, extra: row.extra || this.defaultExtra() };
            this.error = '';
            this.modal.show();
            this.focusInput();
        },
        focusInput: function () {
            var self = this;
            this.$nextTick(function () {
                if (self.$refs.nameInput) self.$refs.nameInput.focus();
            });
        },
        save: function () {
            var self = this;
            if (!self.form.name) {
                self.error = 'يجب إدخال ' + (self.cfg.field_label || 'القيمة');
                return;
            }
            var body = new FormData();
            body.append('key', self.key);
            if (self.form.id) body.append('id', self.form.id);
            body.append('name', self.form.name);
            if (self.cfg.extra) body.append('extra', self.form.extra);

            self.saving = true;
            Api.post(window.LOOKUP_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    self.modal.hide();
                    self.loadList();
                    Api.showSuccess(res.mess || 'تم الحفظ');
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.saving = false;
            });
        },
        remove: function (row) {
            var self = this;
            Swal.fire({
                title: 'حذف السجل؟',
                text: '«' + row.name + '»',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b42318'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                var body = new FormData();
                body.append('key', self.key);
                body.append('id', row.id);
                Api.post(window.LOOKUP_URLS.delete, body).then(function (res) {
                    if (Api.isOk(res)) {
                        self.loadList();
                        Swal.fire({ icon: 'success', title: 'تم الحذف', showConfirmButton: false, timer: 1200 });
                    } else {
                        Api.showError(res);
                    }
                });
            });
        }
    }
});
