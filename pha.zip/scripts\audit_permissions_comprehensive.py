# -*- coding: utf-8 -*-
"""
تقرير تدقيق شامل ونهائي لصلاحيات الشاشات والأزرار
"""
import os
import re
from collections import defaultdict

controllers_dir = 'controllers'
views_dir = 'views'
static_dir = 'static'

# ============================================================
# 1. استخراج كل دوال ال controllers مع الديكوريتors
# ============================================================
controller_funcs = defaultdict(list)

for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py') or fname == '__init__.py':
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    current_decorators = []
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('@'):
            current_decorators.append(stripped)
        elif stripped.startswith('def '):
            func_match = re.match(r'def\s+(\w+)\s*\(', stripped)
            if func_match:
                func_name = func_match.group(1)
                controller_funcs[controller].append({
                    'func': func_name,
                    'decorators': current_decorators[:],
                    'line': i+1
                })
            current_decorators = []

# ============================================================
# 2. استخراج أكواد الشاشات
# ============================================================
can_access_codes = defaultdict(list)
for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py'):
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    for match in re.finditer(r'@can_access\((\d+)\)', content):
        code = int(match.group(1))
        can_access_codes[controller].append(code)

setup_screens = {}
with open(os.path.join(controllers_dir, 'setup.py'), 'r', encoding='utf-8') as f:
    setup_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', setup_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)"', setup_content[:match.start()])
    if not name_match:
        name_match = re.search(r'"name":\s*"([^"]+)"', setup_content[match.start():match.start()+500])
    name = name_match.group(1) if name_match else "unknown"
    setup_screens[code] = name

add_screens = {}
with open('scripts/add_missing_screens.py', 'r', encoding='utf-8') as f:
    add_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', add_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)"', add_content[:match.start()])
    if not name_match:
        name_match = re.search(r'"name":\s*"([^"]+)"', add_content[match.start():match.start()+500])
    name = name_match.group(1) if name_match else "unknown"
    add_screens[code] = name

all_registered_screens = {**setup_screens, **add_screens}

# ============================================================
# 3. تصنيف حماية كل دالة
# ============================================================
def get_protection_level(decorators):
    decs = ' '.join(decorators)
    if '@can_access' in decs:
        return 'can_access'
    if '@auth.requires_membership' in decs or 'auth.has_membership' in decs:
        return 'membership'
    if '@auth.requires_login' in decs or '@auth.requires' in decs:
        return 'login'
    return 'none'

# ============================================================
# 4. روابط navbar
# ============================================================
navbar_links = []
with open(os.path.join(views_dir, 'layout.html'), 'r', encoding='utf-8') as f:
    layout_content = f.read()
for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", layout_content):
    ctrl, func = match.groups()
    if ctrl == 'static':
        continue
    navbar_links.append((ctrl, func))

# ============================================================
# 5. فحص Views للأزرار والروابط
# ============================================================
view_issues = []
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace('views/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", content):
            ctrl, func = match.groups()
            if ctrl == 'static':
                continue
            if ctrl == 'default' and func.startswith('user/'):
                continue
            if func.endswith('.js') or func.endswith('.css'):
                continue
            if ctrl not in controller_funcs:
                continue
            
            prot = 'unknown'
            for cf in controller_funcs[ctrl]:
                if cf['func'] == func:
                    prot = get_protection_level(cf['decorators'])
                    break
            
            if prot in ['none', 'login']:
                view_issues.append((rel_path, ctrl, func, prot))

# ============================================================
# 6. فحص Vue.js
# ============================================================
vue_issues = []
for root, dirs, files in os.walk(os.path.join(static_dir, 'viewsjs')):
    for fname in files:
        if not fname.endswith('.js'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace(static_dir + '/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        for match in re.finditer(r"['\"](/asbab5/([^/'\"]+)/([^/'\"\s]+))['\"]", content):
            url = match.group(1)
            ctrl = match.group(2)
            func = match.group(3)
            
            if ctrl not in controller_funcs:
                continue
            
            prot = 'unknown'
            for cf in controller_funcs[ctrl]:
                if cf['func'] == func:
                    prot = get_protection_level(cf['decorators'])
                    break
            
            if prot in ['none', 'login']:
                vue_issues.append((rel_path, ctrl, func, url, prot))

# ============================================================
# 7. مشاكل navbar
# ============================================================
navbar_issues = []
for ctrl, func in navbar_links:
    if ctrl == 'default' and func.startswith('user/'):
        continue
    if ctrl == 'default' and func in ['about', 'not_allow']:
        continue
    
    prot = 'unknown'
    if ctrl in controller_funcs:
        for cf in controller_funcs[ctrl]:
            if cf['func'] == func:
                prot = get_protection_level(cf['decorators'])
                break
    
    if prot != 'can_access':
        navbar_issues.append((ctrl, func, prot))

# ============================================================
# 8. دوال حساسة بدون حماية
# ============================================================
sensitive_unprotected = []
old_role_funcs = []
for ctrl in sorted(controller_funcs):
    for f in controller_funcs[ctrl]:
        if ctrl == 'appadmin':
            continue
        if f['func'].startswith('_'):
            continue
        if ctrl == 'default' and f['func'] in ['user', 'not_allow', 'about', 'download']:
            continue
        if ctrl == 'send_invoice' and f['func'] == 'index':
            continue
        if ctrl == '_t':
            continue
        
        prot = get_protection_level(f['decorators'])
        if prot == 'none':
            sensitive_unprotected.append((ctrl, f['func'], f['line']))
        elif prot == 'membership':
            decs = ' '.join(f['decorators'])
            old_role_funcs.append((ctrl, f['func'], f['line'], decs))

# ============================================================
# 9. الأزرار في Views
# ============================================================
view_buttons = []
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace('views/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # البحث عن أزرار أو روابط محتملة
        buttons = []
        for cond in ['can_add', 'can_edit', 'can_delete']:
            if cond in content:
                buttons.append(cond)
        
        # البحث عن أزرار submit أو روابط CRUD بدون شرط
        if '<button' in content or '<a ' in content:
            has_crud = False
            if 'can_add' not in content and ('اضافة' in content or 'جديد' in content or 'add' in content.lower()):
                has_crud = True
            if 'can_edit' not in content and ('تعديل' in content or 'edit' in content.lower()):
                has_crud = True
            if 'can_delete' not in content and ('حذف' in content or 'delete' in content.lower()):
                has_crud = True
            if has_crud:
                view_buttons.append((rel_path, buttons, True))
            elif buttons:
                view_buttons.append((rel_path, buttons, False))

# ============================================================
# 10. الشاشات المسجلة vs المستخدمة
# ============================================================
all_codes = set()
for codes in can_access_codes.values():
    all_codes.update(codes)
registered_codes = set(all_registered_screens.keys())
unused_registered = sorted(registered_codes - all_codes)

# ============================================================
# كتابة التقرير
# ============================================================
report_lines = []
report_lines.append("=" * 90)
report_lines.append("                    تقرير تدقيق شامل لصلاحيات النظام")
report_lines.append("                              نظام الصدارة (asbab5)")
report_lines.append("=" * 90)
report_lines.append("")

# الملخص
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│                           الملخص التنفيذي                                │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
report_lines.append(f"  • إجمالي دوال Controllers المحللة: {sum(len(v) for v in controller_funcs.values())}")
report_lines.append(f"  • عدد أكواد can_access المستخدمة: {len(all_codes)}")
report_lines.append(f"  • عدد الشاشات المسجلة: {len(all_registered_screens)}")
report_lines.append(f"  • عدد روابط navbar: {len(navbar_links)}")
report_lines.append(f"  • مشاكل navbar (لا can_access): {len(navbar_issues)}")
report_lines.append(f"  • مشاكل Views (روابط لدوال بدون حماية): {len(view_issues)}")
report_lines.append(f"  • مشاكل Vue.js: {len(vue_issues)}")
report_lines.append(f"  • دوال حساسة بدون أي حماية: {len(sensitive_unprotected)}")
report_lines.append(f"  • دوال تستخدم أدوار قديمة (user1/user2): {len(old_role_funcs)}")
report_lines.append("")

# المشاكل في navbar
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【1】روابط navbar بدون can_access                                        │")
report_lines.append("│     (يمكن الوصول للشاشة بدون صلاحية شاشة محددة)                        │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
for ctrl, func, prot in sorted(navbar_issues):
    status = {"none": "بدون حماية", "login": "@auth.requires_login فقط", 
              "membership": "membership فقط"}.get(prot, prot)
    report_lines.append(f"  ⚠️  {ctrl}/{func} -> {status}")
report_lines.append("")

# المشاكل في Views
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【2】روابط داخل Views تؤدي لدوال غير محمية بـ can_access               │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
seen = set()
for view, ctrl, func, prot in sorted(view_issues):
    key = (view, ctrl, func)
    if key in seen:
        continue
    seen.add(key)
    status = {"none": "بدون حماية", "login": "@auth.requires_login"}.get(prot, prot)
    report_lines.append(f"  ⚠️  {view} -> {ctrl}/{func} ({status})")
report_lines.append("")

# المشاكل في Vue.js
if vue_issues:
    report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
    report_lines.append("│ 【3】روابط API في Vue.js غير محمية بـ can_access                       │")
    report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
    for vue, ctrl, func, url, prot in sorted(vue_issues):
        status = {"none": "بدون حماية", "login": "@auth.requires_login"}.get(prot, prot)
        report_lines.append(f"  ⚠️  {vue} -> {url} ({status})")
    report_lines.append("")

# الدوال الحساسة غير المحمية
if sensitive_unprotected:
    report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
    report_lines.append("│ 【4】دوال Controllers حساسة بدون أي حماية                                │")
    report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
    for ctrl, func, line in sorted(sensitive_unprotected):
        report_lines.append(f"  ⚠️  {ctrl}.{func}() @ line {line}")
    report_lines.append("")

# الأدوار القديمة
if old_role_funcs:
    report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
    report_lines.append("│ 【5】دوال تستخدم أدوار قديمة (user1, user2) بدلاً من can_access          │")
    report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
    for ctrl, func, line, decs in sorted(old_role_funcs):
        report_lines.append(f"  ⚠️  {ctrl}.{func}() @ line {line}")
        report_lines.append(f"      -> {decs}")
    report_lines.append("")

# الشاشات غير المستخدمة
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【6】شاشات مسجلة لكن لا توجد can_access لها                              │")
report_lines.append("│     (قد تكون محمية بـ auth.requires_login أو أدوار أخرى فقط)            │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
for code in unused_registered:
    name = all_registered_screens.get(code, 'unknown')
    report_lines.append(f"  ℹ️  {code}: {name}")
report_lines.append("")

# الأزرار المشروطة
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│ 【7】الأزرار المشروطة في Views (can_add, can_edit, can_delete)          │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
for view, buttons, has_unconditional in sorted(view_buttons):
    if buttons:
        report_lines.append(f"  ✓ {view}: {', '.join(buttons)}")
    elif has_unconditional:
        report_lines.append(f"  ⚠️  {view}: أزرار CRUD بدون فحص صلاحيات")
report_lines.append("")

# التوصيات
report_lines.append("┌──────────────────────────────────────────────────────────────────────────┐")
report_lines.append("│                              التوصيات                                    │")
report_lines.append("└──────────────────────────────────────────────────────────────────────────┘")
report_lines.append("""
1. 【خطيرة - أولوية قصوى】روابط navbar:
   يجب إضافة @can_access لجميع روابط navbar أو إخفاؤها بـ screens_rules().
   الشاشات المتأثرة:
   • شؤون الموظفين (employees, salaries, advances, leaves, payroll)
   • الحضور والانصراف (attendance)
   • الموردين (suppliers_bills, returned_supply, supply_rep)
   • الأصناف (stop_items, inventory)
   • المبيعات (invoice_show, invoice_show_return, inv_rep1)
   • التقارير (items_rep, vat)
   • الصندوق (fund - يظهر فقط لـ account لكن الداخل محمي بـ login فقط)
   • الإعدادات (setup)

2. 【خطيرة】دوال Controllers بدون حماية:
   • customers.month_total(), row_sum()
   • items.diff_class(), fmt()
   يجب حمايتها أو تحويلها لدوال داخلية (تبدأ بـ _).

3. 【متوسطة】استبدال الأدوار القديمة:
   • استبدال @auth.requires_membership("user1") بـ @can_access(كود_الشاشة)
   • استبدال @auth.requires_membership("user2") بـ @can_access(كود_الشاشة)
   • هذا يتيح التحكم الدقيق من شاشة إدارة المستخدمين.

4. 【متوسطة】الأزرار في Views:
   • إضافة فحص can_add/can_edit/can_delete في شاشات:
     - الموردين
     - الأصناف
     - المبيعات
     - الصندوق
     - شؤون الموظفين

5. 【منخفضة】تفعيل الشاشات المسجلة غير المستخدمة:
   • 7001-7007: شؤون الموظفين
   • 8001: إقفال الفترات
   • 8101-8112: تقارير المبيعات
   • 8201-8202: تقارير الأصناف
   • 9001-9004: الضريبة
   • 9101-9103: زاتكا
""")

report_lines.append("=" * 90)
report_lines.append("                              نهاية التقرير")
report_lines.append("=" * 90)

with open('scripts/audit_permissions_comprehensive_report.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(report_lines))

print("Done. Report written to scripts/audit_permissions_comprehensive_report.txt")
