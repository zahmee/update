# -*- coding: utf-8 -*-
"""
تقرير تدقيق شامل لصلاحيات الشاشات والأزرار - النسخة المحسنة
"""
import os
import re
from collections import defaultdict

controllers_dir = 'controllers'
views_dir = 'views'
static_dir = 'static'

# ============================================================
# 1. استخراج كل دوال ال controllers مع الديكوريتors
# ============================================================
controller_funcs = defaultdict(list)

for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py') or fname == '__init__.py':
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    current_decorators = []
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('@'):
            current_decorators.append(stripped)
        elif stripped.startswith('def '):
            func_match = re.match(r'def\s+(\w+)\s*\(', stripped)
            if func_match:
                func_name = func_match.group(1)
                controller_funcs[controller].append({
                    'func': func_name,
                    'decorators': current_decorators[:],
                    'line': i+1
                })
            current_decorators = []

# ============================================================
# 2. استخراج أكواد الشاشات من can_access
# ============================================================
can_access_codes = defaultdict(list)
for fname in os.listdir(controllers_dir):
    if not fname.endswith('.py'):
        continue
    controller = fname[:-3]
    with open(os.path.join(controllers_dir, fname), 'r', encoding='utf-8') as f:
        content = f.read()
    for match in re.finditer(r'@can_access\((\d+)\)', content):
        code = int(match.group(1))
        can_access_codes[controller].append(code)

# ============================================================
# 3. استخراج أكواد الشاشات المسجلة
# ============================================================
setup_screens = {}
with open(os.path.join(controllers_dir, 'setup.py'), 'r', encoding='utf-8') as f:
    setup_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', setup_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)".*?"screen_code":\s*' + str(code), setup_content, re.DOTALL)
    if not name_match:
        name_match = re.search(r'"screen_code":\s*' + str(code) + r'.*?"name":\s*"([^"]+)"', setup_content, re.DOTALL)
    name = name_match.group(1) if name_match else "unknown"
    setup_screens[code] = name

add_screens = {}
with open('scripts/add_missing_screens.py', 'r', encoding='utf-8') as f:
    add_content = f.read()
for match in re.finditer(r'"screen_code":\s*(\d+)', add_content):
    code = int(match.group(1))
    name_match = re.search(r'"name":\s*"([^"]+)".*?"screen_code":\s*' + str(code), add_content, re.DOTALL)
    if not name_match:
        name_match = re.search(r'"screen_code":\s*' + str(code) + r'.*?"name":\s*"([^"]+)"', add_content, re.DOTALL)
    name = name_match.group(1) if name_match else "unknown"
    add_screens[code] = name

all_registered_screens = {**setup_screens, **add_screens}

# ============================================================
# 4. استخراج الروابط من navbar (layout.html)
# ============================================================
navbar_links = []
with open(os.path.join(views_dir, 'layout.html'), 'r', encoding='utf-8') as f:
    layout_content = f.read()

for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", layout_content):
    ctrl, func = match.groups()
    if ctrl == 'static':
        continue
    navbar_links.append((ctrl, func))

# ============================================================
# 5. فحص كل Views للأزرار و الروابط
# ============================================================
view_issues = []
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace('views/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # استخراج روابط URL داخل الـ view
        for match in re.finditer(r"URL\('([^']+)'\s*,\s*'([^']+)'\)", content):
            ctrl, func = match.groups()
            if ctrl == 'static' or ctrl == 'default' and func.startswith('user/'):
                continue
            
            # تحقق هل الدالة محمية بـ can_access
            protected = False
            code = None
            if ctrl in controller_funcs:
                for cf in controller_funcs[ctrl]:
                    if cf['func'] == func:
                        for d in cf['decorators']:
                            m = re.search(r'@can_access\((\d+)\)', d)
                            if m:
                                protected = True
                                code = int(m.group(1))
                        break
            
            if not protected:
                view_issues.append((rel_path, ctrl, func))

# ============================================================
# 6. فحص Vue.js files
# ============================================================
vue_issues = []
for root, dirs, files in os.walk(os.path.join(static_dir, 'viewsjs')):
    for fname in files:
        if not fname.endswith('.js'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace(static_dir + '/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # استخراج روابط API
        for match in re.finditer(r"['\"](/asbab5/([^/'\"]+)/([^/'\"\s]+))['\"]", content):
            url = match.group(1)
            ctrl = match.group(2)
            func = match.group(3)
            
            protected = False
            code = None
            if ctrl in controller_funcs:
                for cf in controller_funcs[ctrl]:
                    if cf['func'] == func:
                        for d in cf['decorators']:
                            m = re.search(r'@can_access\((\d+)\)', d)
                            if m:
                                protected = True
                                code = int(m.group(1))
                        break
            
            if not protected:
                vue_issues.append((rel_path, ctrl, func, url))

# ============================================================
# 7. تحديد المشاكل الحقيقية في navbar
# ============================================================
navbar_issues = []
for ctrl, func in navbar_links:
    if ctrl == 'static':
        continue
    protected = False
    code = None
    if ctrl in controller_funcs:
        for cf in controller_funcs[ctrl]:
            if cf['func'] == func:
                for d in cf['decorators']:
                    m = re.search(r'@can_access\((\d+)\)', d)
                    if m:
                        protected = True
                        code = int(m.group(1))
                break
    
    # استثناءات: صفحات المصادقة وملفات الشخصي
    if ctrl == 'default' and func.startswith('user/'):
        continue
    if ctrl == 'default' and func in ['about', 'not_allow']:
        continue
    
    if not protected:
        navbar_issues.append((ctrl, func))

# ============================================================
# 8. فحص الأزرار المشروطة في Views
# ============================================================
button_checks = []
for root, dirs, files in os.walk(views_dir):
    for fname in files:
        if not fname.endswith('.html'):
            continue
        path = os.path.join(root, fname)
        rel_path = path.replace('views/', '')
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_can_add = 'can_add' in content
        has_can_edit = 'can_edit' in content
        has_can_delete = 'can_delete' in content
        
        if has_can_add or has_can_edit or has_can_delete:
            button_checks.append((rel_path, has_can_add, has_can_edit, has_can_delete))

# ============================================================
# 9. تحديد الثغرات المحتملة
# ============================================================
all_codes = set()
for codes in can_access_codes.values():
    all_codes.update(codes)

# دوال controllers حساسة بدون حماية
sensitive_unprotected = []
for ctrl in sorted(controller_funcs):
    for f in controller_funcs[ctrl]:
        decs = ' '.join(f['decorators'])
        has_can_access = '@can_access' in decs
        has_auth = '@auth.requires' in decs
        
        if ctrl == 'appadmin':
            continue  # controller مدمج
        if f['func'].startswith('_'):
            continue  # دوال داخلية
        if ctrl == 'default' and f['func'] in ['user', 'not_allow', 'about', 'download']:
            continue
        if ctrl == 'send_invoice' and f['func'] == 'index':
            continue  # قد يُستدعى من cron
        if ctrl == '_t' and f['func'] in ['_get_local_version', '_get_remote_version', '_clear_pycache']:
            continue  # دوال داخلية
        
        if not has_can_access and not has_auth:
            sensitive_unprotected.append((ctrl, f['func'], f['line']))

# ============================================================
# كتابة التقرير
# ============================================================
report_lines = []
report_lines.append("=" * 80)
report_lines.append("تقرير تدقيق شامل لصلاحيات الشاشات والأزرار")
report_lines.append("=" * 80)
report_lines.append("")

# الملخص
report_lines.append("─" * 80)
report_lines.append("الملخص التنفيذي")
report_lines.append("─" * 80)
report_lines.append(f"إجمالي دوال Controllers المحللة: {sum(len(v) for v in controller_funcs.values())}")
report_lines.append(f"عدد أكواد can_access المستخدمة: {len(all_codes)}")
report_lines.append(f"عدد الشاشات المسجلة: {len(all_registered_screens)}")
report_lines.append(f"عدد روابط navbar: {len(navbar_links)}")
report_lines.append(f"عدد المشاكل في navbar: {len(navbar_issues)}")
report_lines.append(f"عدد المشاكل في Views: {len(view_issues)}")
report_lines.append(f"عدد المشاكل في Vue.js: {len(vue_issues)}")
report_lines.append(f"عدد الدوال الحساسة غير المحمية: {len(sensitive_unprotected)}")
report_lines.append("")

# المشاكل في navbar
report_lines.append("─" * 80)
report_lines.append("【1】روابط navbar غير المحمية بـ can_access (يمكن الوصول لها بدون صلاحية شاشة)")
report_lines.append("─" * 80)
for ctrl, func in sorted(navbar_issues):
    report_lines.append(f"  !! {ctrl}/{func} - لا يوجد can_access")
report_lines.append("")

# المشاكل في Views
report_lines.append("─" * 80)
report_lines.append("【2】روابط داخل Views تؤدي لدوال غير محمية بـ can_access")
report_lines.append("─" * 80)
for view, ctrl, func in sorted(view_issues):
    report_lines.append(f"  !! في {view}: URL('{ctrl}', '{func}') - غير محمية")
report_lines.append("")

# المشاكل في Vue.js
report_lines.append("─" * 80)
report_lines.append("【3】روابط API في Vue.js تؤدي لدوال غير محمية بـ can_access")
report_lines.append("─" * 80)
for vue, ctrl, func, url in sorted(vue_issues):
    report_lines.append(f"  !! في {vue}: {url} - غير محمية")
report_lines.append("")

# الدوال الحساسة غير المحمية
report_lines.append("─" * 80)
report_lines.append("【4】دوال Controllers حساسة بدون أي حماية (لا can_access ولا auth.requires)")
report_lines.append("─" * 80)
for ctrl, func, line in sorted(sensitive_unprotected):
    report_lines.append(f"  !! {ctrl}.{func}() @ line {line}")
report_lines.append("")

# الأزرار المشروطة
report_lines.append("─" * 80)
report_lines.append("【5】الأزرار المشروطة في Views (can_add, can_edit, can_delete)")
report_lines.append("─" * 80)
for view, add, edit, delete in sorted(button_checks):
    flags = []
    if add: flags.append("can_add")
    if edit: flags.append("can_edit")
    if delete: flags.append("can_delete")
    report_lines.append(f"  {view}: {', '.join(flags)}")
report_lines.append("")

# المقارنة بين أكواد can_access والشاشات المسجلة
report_lines.append("─" * 80)
report_lines.append("【6】أكواد can_access غير مسجلة في جدول الشاشات")
report_lines.append("─" * 80)
all_codes = set()
for codes in can_access_codes.values():
    all_codes.update(codes)
registered_codes = set(all_registered_screens.keys())
missing = sorted(all_codes - registered_codes)
if missing:
    for code in missing:
        report_lines.append(f"  !! {code} - غير مسجل")
else:
    report_lines.append("  جميع الأكواد مسجلة ✓")
report_lines.append("")

# الشاشات المسجلة غير المستخدمة
report_lines.append("─" * 80)
report_lines.append("【7】شاشات مسجلة لكن لا توجد can_access لها في أي Controller")
report_lines.append("─" * 80)
unused = sorted(registered_codes - all_codes)
if unused:
    for code in unused:
        report_lines.append(f"  !! {code}: {all_registered_screens.get(code, 'unknown')} - غير مستخدم")
else:
    report_lines.append("  جميع الشاشات المسجلة مستخدمة ✓")
report_lines.append("")

# التوصيات
report_lines.append("─" * 80)
report_lines.append("【8】التوصيات")
report_lines.append("─" * 80)
report_lines.append("""
1. يجب إضافة @can_access لجميع روابط navbar التي لا تحتوي عليه حالياً.
2. يجب مراجعة جميع دوال controllers التي تستخدم @auth.requires_login فقط
   وتحديد ما إذا كانت تحتاج لـ can_access أم لا.
3. يجب حماية جميع API endpoints في Vue.js بـ can_access.
4. يجب إضافة فحص can_add/can_edit/can_delete في Views أكثر.
5. يجب مراجعة الأدوار (user1, user2, account, admin) وتوحيدها مع can_access.
""")

report_lines.append("=" * 80)
report_lines.append("نهاية التقرير")
report_lines.append("=" * 80)

with open('scripts/audit_permissions_report2.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(report_lines))

print("Done. Report written to scripts/audit_permissions_report2.txt")
