(function () {
    "use strict";

    var form = document.getElementById("mergeForm");
    if (!form) return;

    var sourceInput = document.getElementById("source_item");
    var targetInput = document.getElementById("target_item");
    var confirmInput = document.getElementById("merge_confirm");
    var sourcePreview = document.getElementById("sourcePreview");
    var targetPreview = document.getElementById("targetPreview");
    var sourceError = document.getElementById("sourceError");
    var targetError = document.getElementById("targetError");
    var status = document.getElementById("mergeStatus");
    var submitButton = document.getElementById("mergeSubmit");
    var resetButton = document.getElementById("mergeReset");
    var submitting = false;

    function readId(input) {
        var value = input.value.trim().replace(/[\u0660-\u0669\u06f0-\u06f9]/g, function (digit) {
            var code = digit.charCodeAt(0);
            return String(code - (code >= 0x06f0 ? 0x06f0 : 0x0660));
        });
        // Keep IDs as strings: do not silently drop invalid characters or round long IDs.
        if (!/^[0-9]+$/.test(value)) return "";
        return value.replace(/^0+/, "");
    }

    function showFieldError(input, element, message) {
        input.setAttribute("aria-invalid", message ? "true" : "false");
        element.textContent = message;
        element.hidden = !message;
    }

    function sync() {
        var sourceId = readId(sourceInput);
        var targetId = readId(targetInput);
        var sourceInvalid = sourceInput.value.trim() && !sourceId;
        var targetInvalid = targetInput.value.trim() && !targetId;
        var sameId = sourceId && sourceId === targetId;
        var pairValid = sourceId && targetId && !sameId;

        showFieldError(sourceInput, sourceError, sourceInvalid ? "أدخل رقمًا صحيحًا أكبر من صفر." : "");
        showFieldError(targetInput, targetError, targetInvalid ? "أدخل رقمًا صحيحًا أكبر من صفر." :
            (sameId ? "اختر صنفًا أساسيًا مختلفًا عن الصنف المكرر." : ""));
        sourcePreview.textContent = sourceId || "—";
        targetPreview.textContent = targetId || "—";

        confirmInput.disabled = !pairValid || submitting;
        if (!pairValid) confirmInput.checked = false;
        submitButton.disabled = !pairValid || !confirmInput.checked || submitting;
        resetButton.disabled = submitting || !(sourceInput.value || targetInput.value);

        var state = "empty";
        var message = "أدخل رقمي الصنفين لبدء المراجعة.";
        if (submitting) {
            state = "submitting";
            message = "جارٍ الانتقال لتنفيذ الدمج…";
        } else if (sameId || sourceInvalid || targetInvalid) {
            state = "invalid";
            message = sameId ? "لا يمكن دمج الصنف مع نفسه." : "صحّح الرقم المميز بالحقل قبل المتابعة.";
        } else if (pairValid && confirmInput.checked) {
            state = "ready";
            message = "تم التأكيد. زر التنفيذ ينقل البيانات ويحذف سجل الصنف المكرر.";
        } else if (pairValid) {
            state = "review";
            message = "راجع الرقمين واتجاه النقل، ثم فعّل التأكيد.";
        }
        form.dataset.state = state;
        status.textContent = message;
    }

    function onSelectionChange() {
        confirmInput.checked = false;
        sync();
    }

    [sourceInput, targetInput].forEach(function (input) {
        input.addEventListener("input", onSelectionChange);
        input.addEventListener("change", onSelectionChange);
    });
    confirmInput.addEventListener("change", sync);

    form.addEventListener("reset", function (event) {
        event.preventDefault();
        if (submitting) return;
        sourceInput.value = "";
        targetInput.value = "";
        confirmInput.checked = false;
        sync();
        sourceInput.focus();
    });

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        sync();
        if (submitButton.disabled) return;
        var targetId = readId(targetInput);
        var sourceId = readId(sourceInput);
        submitting = true;
        sync();
        // Preserve the existing endpoint's order: surviving target, then merged source.
        window.location.href = form.dataset.actionUrl + "/" + targetId + "/" + sourceId;
    });

    var params = new URLSearchParams(window.location.search);
    targetInput.value = params.get("target") || "";
    sourceInput.value = params.get("source") || "";
    confirmInput.checked = false;
    sync();

    window.addEventListener("pageshow", function (event) {
        if (!event.persisted) return;
        submitting = false;
        confirmInput.checked = false;
        sync();
    });
}());
