# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الموارد البشرية: الموظفين، الرواتب، السلف، الإجازات، الحضور، المستندات
# ===========================================================================================

# ===========================================================================================
#  جدول أنواع المستندات
db.define_table(
    "key_doc_types",
    Field("name", length=200, label="نوع المستند"),
    format="%(name)s",
)
db.key_doc_types.id.label = "م"

# ===========================================================================================
#  ترميزات الموظفين
db.define_table(
    "key_job_titles",
    Field("name", length=200, label="المسمى الوظيفي"),
    format="%(name)s",
)
db.key_job_titles.id.label = "م"

db.define_table(
    "key_nationalities",
    Field("name", length=200, label="الجنسية"),
    format="%(name)s",
)
db.key_nationalities.id.label = "م"

db.define_table(
    "key_advance_types",
    Field("name", length=200, label="نوع السلفة"),
    format="%(name)s",
)
db.key_advance_types.id.label = "م"

db.define_table(
    "key_allowance_deduction",
    Field("name", length=200, label="الاسم"),
    Field("ad_type", length=20, default="بدل", label="النوع",
          requires=IS_IN_SET(["بدل", "خصم"], zero=None)),
    format="%(name)s",
)
db.key_allowance_deduction.id.label = "م"

#  ترميز حالة الموظف
db.define_table(
    "key_emp_status",
    Field("name", length=200, label="حالة الموظف"),
    format="%(name)s",
)
db.key_emp_status.id.label = "م"

#  جدول الموظفين
db.define_table(
    "employees",
    Field("emp_name", length=300, label="اسم الموظف",
          requires=IS_NOT_EMPTY(error_message="يجب إدخال اسم الموظف")),
    Field("job_title", "reference key_job_titles", label="الوظيفة",
          requires=IS_IN_DB(db, "key_job_titles.id", "%(name)s")),
    Field("id_number", length=20, label="رقم الهوية"),
    Field("start_date", "date", label="تاريخ المباشرة"),
    Field("nationality", "reference key_nationalities", label="الجنسية",
          requires=IS_IN_DB(db, "key_nationalities.id", "%(name)s")),
    Field("emp_status", "reference key_emp_status", label="حالة الموظف",
          requires=IS_IN_DB(db, "key_emp_status.id", "%(name)s")),
    Field("mobile", length=20, label="رقم الجوال"),
    Field("user_id", "reference auth_user", label="حساب المستخدم",
          requires=IS_EMPTY_OR(IS_IN_DB(db, "auth_user.id", "%(first_name)s %(last_name)s")),
          unique=True),
    auth.signature,
    format="%(emp_name)s",
)
db.employees.id.label = "م"

#  جدول الراتب الأساسي
db.define_table(
    "emp_salary",
    Field("employee", "reference employees", unique=True, label="الموظف",
          requires=IS_IN_DB(db, "employees.id", "%(emp_name)s")),
    Field("basic_salary", "double", default=0, label="الراتب الأساسي"),
    auth.signature,
)
db.emp_salary.id.label = "م"

#  جدول بدلات وخصومات الموظف
db.define_table(
    "emp_salary_detail",
    Field("employee", "reference employees", label="الموظف",
          requires=IS_IN_DB(db, "employees.id", "%(emp_name)s")),
    Field("allowance_deduction", "reference key_allowance_deduction", label="البدل/الخصم",
          requires=IS_IN_DB(db, "key_allowance_deduction.id", "%(name)s")),
    Field("amount", "double", default=0, label="المبلغ"),
    Field("notes", length=300, default="", label="ملاحظات"),
    auth.signature,
)
db.emp_salary_detail.id.label = "م"

#  جدول سلفيات الموظفين
db.define_table(
    "emp_advances",
    Field("employee", "reference employees", label="الموظف",
          requires=IS_IN_DB(db, "employees.id", "%(emp_name)s")),
    Field("advance_type", "reference key_advance_types", label="نوع السلفة",
          requires=IS_IN_DB(db, "key_advance_types.id", "%(name)s")),
    Field("amount", "double", default=0, label="المبلغ"),
    Field("paid_amount", "double", default=0, label="المبلغ المسدد"),
    Field("advance_date", "date", label="تاريخ السلفة"),
    Field("is_closed", "boolean", default=False, label="مقفلة"),
    Field("closed_date", "date", label="تاريخ الإقفال"),
    auth.signature,
)
db.emp_advances.id.label = "م"

#  جدول إجازات الموظفين
db.define_table(
    "emp_leaves",
    Field("employee", "reference employees", label="الموظف",
          requires=IS_IN_DB(db, "employees.id", "%(emp_name)s")),
    Field("start_date", "date", label="تاريخ بداية الإجازة"),
    Field("end_date", "date", label="تاريخ نهاية الإجازة"),
    Field("days_count", "integer", default=0, label="عدد الأيام"),
    Field("tickets_paid", "boolean", default=False, label="تم صرف التذاكر"),
    Field("allowance_paid", "boolean", default=False, label="تم استلام بدل الإجازة"),
    auth.signature,
)
db.emp_leaves.id.label = "م"

#  جدول مسير الرواتب
db.define_table(
    "payroll",
    Field("employee", "reference employees", label="الموظف",
          requires=IS_IN_DB(db, "employees.id", "%(emp_name)s")),
    Field("pay_month", "integer", label="الشهر",
          requires=IS_IN_SET(list(range(1, 13)), zero=None)),
    Field("pay_year", "integer", label="السنة"),
    Field("basic_salary", "double", default=0, label="الراتب الأساسي"),
    Field("net_salary", "double", default=0, label="إجمالي الراتب"),
    auth.signature,
)
db.payroll.id.label = "م"

#  فترات مسير الرواتب (ملخص شهري)
db.define_table(
    "payroll_period",
    Field("pay_month", "integer", label="الشهر",
          requires=IS_IN_SET(list(range(1, 13)), zero=None)),
    Field("pay_year", "integer", label="السنة"),
    Field("is_approved", "boolean", default=False, label="معتمد"),
    auth.signature,
)
db.payroll_period.id.label = "م"

#  تفاصيل مسير الرواتب (بدلات/خصومات)
db.define_table(
    "payroll_detail",
    Field("payroll_id", "reference payroll", label="المسير",
          requires=IS_IN_DB(db, "payroll.id")),
    Field("allowance_deduction", "reference key_allowance_deduction", label="البدل/الخصم",
          requires=IS_IN_DB(db, "key_allowance_deduction.id", "%(name)s")),
    Field("amount", "double", default=0, label="المبلغ"),
    Field("notes", length=300, default="", label="ملاحظات"),
    auth.signature,
)
db.payroll_detail.id.label = "م"

# ===========================================================================================
#  جدول مستنداتي
db.define_table(
    "my_files",
    Field("doc_type", "reference key_doc_types", label="نوع المستند",
          requires=IS_IN_DB(db, "key_doc_types.id", "%(name)s")),
    Field("doc_name", length=300, label="اسم المستند",
          requires=IS_NOT_EMPTY(error_message="يجب ادخال اسم المستند")),
    Field("description", "text", label="الوصف"),
    Field("expiry_date", "date", label="تاريخ نهاية المستند"),
    Field("doc_file", "upload", label="ملف المستند", autodelete=True),
    auth.signature,
    format="%(doc_name)s",
)
db.my_files.id.label = "م"

# ============= نظام الحضور والانصراف =============

db.define_table(
    "attendance_otp",
    Field("employee", "reference employees", notnull=True, label="الموظف"),
    Field("otp_code", length=6, notnull=True, label="رمز التحقق"),
    Field("otp_type", length=10, notnull=True, label="نوع العملية",
          requires=IS_IN_SET(["in", "out"])),
    Field("shift_time", "time", label="وقت الوردية"),
    Field("created_on", "datetime", default=request.now, label="وقت الإنشاء"),
    Field("is_used", "boolean", default=False, label="مستخدم"),
)

db.define_table(
    "attendance",
    Field("employee", "reference employees", notnull=True, label="الموظف",
          requires=IS_IN_DB(db, "employees.id", "%(emp_name)s")),
    Field("att_date", "date", notnull=True, label="التاريخ"),
    Field("check_in", "datetime", label="وقت الحضور"),
    Field("check_out", "datetime", label="وقت الانصراف"),
    Field("shift_start", "time", label="بداية الوردية"),
    Field("shift_end", "time", label="نهاية الوردية"),
    Field("shift_hours", "double", default=0, label="ساعات العمل"),
    Field("notes", "text", label="ملاحظات"),
    auth.signature,
)
db.attendance.id.label = "م"
