/* طباعة ملصقات الباركود من المتصفح — items/labels (شاشة 3015)
   المعاينة والطباعة من المكوّن نفسه (bc-label) فما يظهر هو ما يُطبع.
   الباركود يصل من الخادم سلسلة وحدات 1/0 (modules/label_barcodes.py) ويُرسم هنا
   مستطيلات داخل <symbol> واحد لكل رمز، وكل ملصق يشير إليه بـ <use> فلا تثقل آلاف
   الملصقات الصفحة. الإعدادات تُحفظ محلياً على الجهاز، والقوالب في قاعدة البيانات. */
(function () {
    'use strict';

    var CFG = window.LABELS_CFG || {};
    var STORE_KEY = 'asbab5_labels_settings_v1';
    var MAX_LABELS = 5000;

    var ROLL_SIZES = [
        { key: '40x20', label: '40 × 20', w: 40, h: 20 },
        { key: '38x25', label: '38 × 25', w: 38, h: 25 },
        { key: '40x30', label: '40 × 30', w: 40, h: 30 },
        { key: '50x30', label: '50 × 30', w: 50, h: 30 },
        { key: '58x40', label: '58 × 40', w: 58, h: 40 },
        { key: '100x50', label: '100 × 50', w: 100, h: 50 }
    ];
    var SHEET_SIZES = [
        { key: 'a4_65', label: '65 ملصقاً (38.1 × 21.2)', w: 38.1, h: 21.2, cols: 5, rows: 13, top: 10.7, left: 4.65, gapX: 2.5, gapY: 0 },
        { key: 'a4_40', label: '40 ملصقاً (52.5 × 29.7)', w: 52.5, h: 29.7, cols: 4, rows: 10, top: 0, left: 0, gapX: 0, gapY: 0 },
        { key: 'a4_24', label: '24 ملصقاً (70 × 37)', w: 70, h: 37, cols: 3, rows: 8, top: 0.5, left: 0, gapX: 0, gapY: 0 }
    ];

    // الافتراضي 40 × 20 مم (الملصق الأساسي عند المالك) بخطوط تدخل في 18 مم داخل الحاشية
    function defaults() {
        return {
            paper: 'roll',
            width: 40,
            height: 20,
            padding: 1,
            sheet: { cols: 5, rows: 13, top: 10.7, left: 4.65, gapX: 2.5, gapY: 0 },
            barcode: { content: 'batch', height: 6, width: 0, showText: true, textSize: 6, align: 'center' },
            org: { show: 'top', text: '', size: 6, bold: true },
            name: { show: true, size: 6, lines: 1, bold: false },
            price: { show: true, size: 9, bold: true, suffix: 'ر.س', vatNote: true, place: 'line', boxed: false },
            expiry: { show: false, size: 5.5, format: 'ym' },
            batchText: { show: false, size: 5 },
            zoom: 200
        };
    }

    function isObj(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }

    // دمج إعدادات محفوظة فوق الافتراضية: المفاتيح المعروفة فقط، فلا يكسر قالب قديم الصفحة
    function merge(base, extra) {
        if (!isObj(extra)) { return base; }
        Object.keys(extra).forEach(function (k) {
            if (!(k in base)) { return; }
            if (isObj(base[k]) && isObj(extra[k])) { merge(base[k], extra[k]); }
            else if (!isObj(base[k])) { base[k] = extra[k]; }
        });
        return base;
    }

    function num(v, fallback) {
        v = Number(v);
        return isFinite(v) && v >= 0 ? v : fallback;
    }

    function pt(v, fallback) { return num(v, fallback) + 'pt'; }

    function rects(bars) {
        var out = [], start = null, i, ch;
        for (i = 0; i <= bars.length; i++) {
            ch = bars.charAt(i);
            if (ch === '1' && start === null) { start = i; }
            else if (ch !== '1' && start !== null) { out.push([start, i - start]); start = null; }
        }
        return out;
    }

    function loadLocal() {
        try { return JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); } catch (e) { return null; }
    }

    function saveLocal(s) {
        try { localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch (e) { /* خاص/ممتلئ */ }
    }

    function clearLocal() {
        try { localStorage.removeItem(STORE_KEY); } catch (e) { /* تجاهل */ }
    }

    Vue.component('bc-defs', {
        props: ['symbols'],
        template: '#bc-defs-tpl'
    });

    Vue.component('bc-label', {
        props: ['row', 'code', 's', 'org', 'last'],
        template: '#bc-label-tpl',
        computed: {
            style: function () {
                var s = this.s;
                return { width: num(s.width, 40) + 'mm', height: num(s.height, 30) + 'mm', padding: num(s.padding, 1.5) + 'mm' };
            },
            orgStyle: function () {
                return { fontSize: pt(this.s.org.size, 7), fontWeight: this.s.org.bold ? 700 : 400 };
            },
            nameStyle: function () {
                var lines = Math.max(1, Math.min(3, Math.round(num(this.s.name.lines, 2)) || 2));
                return { fontSize: pt(this.s.name.size, 7), fontWeight: this.s.name.bold ? 700 : 400, WebkitLineClamp: String(lines) };
            },
            priceStyle: function () {
                return { fontSize: pt(this.s.price.size, 11), fontWeight: this.s.price.bold ? 700 : 400 };
            },
            expStyle: function () { return { fontSize: pt(this.s.expiry.size, 6) }; },
            digitsStyle: function () { return { fontSize: pt(this.s.barcode.textSize, 7) }; },
            batchStyle: function () { return { fontSize: pt(this.s.batchText.size, 5.5) }; },
            // اسم المنشأة طولياً: شريط ضيق على اليمين أو اليسار يُدار النص فيه 90 درجة
            orgSide: function () {
                var v = this.s.org.show;
                return (v === 'left' || v === 'right') ? v : '';
            },
            sideWidth: function () {
                return Math.max(3, num(this.s.org.size, 7) * 0.3528 * 1.45);
            },
            sideStyle: function () {
                var w = this.sideWidth.toFixed(2);
                return { width: w + 'mm', flex: '0 0 ' + w + 'mm' };
            },
            sideTextStyle: function () {
                var s = this.s;
                var innerH = Math.max(5, num(s.height, 30) - 2 * num(s.padding, 1.5));
                return {
                    width: innerH + 'mm',
                    fontSize: pt(s.org.size, 7),
                    fontWeight: s.org.bold ? 700 : 400,
                    transform: 'translate(-50%, -50%) rotate(' + (this.orgSide === 'right' ? -90 : 90) + 'deg)'
                };
            },
            // السعر: سطر مستقل، أو مربع عائم في زاوية سفلية (موضع مطلق فوق الملصق، لا يحاذي أي عنصر)
            priceCorner: function () {
                var p = this.s.price;
                return !!p.show && (p.place === 'br' || p.place === 'bl');
            },
            priceLine: function () { return !!this.s.price.show && !this.priceCorner; },
            bottomStyle: function () {
                var a = this.s.barcode.align;
                // الملصق rtl: بداية الصف يمين
                return { justifyContent: a === 'right' ? 'flex-start' : (a === 'left' ? 'flex-end' : 'center') };
            },
            codeStyle: function () {
                var s = this.s;
                var inner = Math.max(5, num(s.width, 40) - 2 * num(s.padding, 1.5) - (this.orgSide ? this.sideWidth + 0.8 : 0));
                var w = num(s.barcode.width, 0);
                if (!w || w > inner) { w = inner; }
                return { width: w + 'mm', height: num(s.barcode.height, 10) + 'mm' };
            },
            price: function () {
                var p = this.row.price;
                return (p === null || p === undefined) ? '—' : Number(p).toFixed(2);
            },
            expiry: function () {
                var d = this.row.expiry || '';
                return this.s.expiry.format === 'ymd' ? d : d.slice(0, 7);
            }
        }
    });

    var hasLocal = !!loadLocal();

    new Vue({
        el: '#app',
        data: {
            cfg: CFG,
            loading: true,
            error: '',
            source: {},
            rows: [],
            s: merge(defaults(), loadLocal()),
            presets: [],
            presetId: 0,
            selectedOnly: false,
            rollSizes: ROLL_SIZES,
            sheetSizes: SHEET_SIZES,
            maxLabels: MAX_LABELS,
            persistTimer: null
        },
        computed: {
            orgText: function () { return (this.s.org.text || CFG.org_name || '').trim(); },
            activeRows: function () {
                var sel = this.selectedOnly;
                return this.rows.filter(function (r) { return num(r.count, 0) > 0 && (!sel || r.checked); });
            },
            codes: function () {
                var map = {}, self = this;
                this.rows.forEach(function (r) { map[r.det_id] = self.codeFor(r); });
                return map;
            },
            rawTotal: function () {
                return this.activeRows.reduce(function (t, r) { return t + Math.floor(num(r.count, 0)); }, 0);
            },
            truncated: function () { return this.rawTotal > MAX_LABELS; },
            groups: function () {
                var codes = this.codes, out = [], total = 0;
                this.activeRows.forEach(function (r) {
                    var c = codes[r.det_id];
                    if (!c) { return; }
                    var n = Math.min(Math.floor(num(r.count, 0)), MAX_LABELS - total);
                    if (n > 0) { out.push({ row: r, code: c, count: n, last: false }); total += n; }
                });
                if (out.length) { out[out.length - 1].last = true; }
                return out;
            },
            total: function () {
                return this.groups.reduce(function (t, g) { return t + g.count; }, 0);
            },
            symbols: function () {
                var seen = {}, out = [];
                this.groups.forEach(function (g) {
                    if (!seen[g.code.id]) { seen[g.code.id] = 1; out.push({ id: g.code.id, modules: g.code.modules, rects: rects(g.code.bars) }); }
                });
                return out;
            },
            perSheet: function () {
                return Math.max(1, Math.round(num(this.s.sheet.cols, 5)) || 1) * Math.max(1, Math.round(num(this.s.sheet.rows, 13)) || 1);
            },
            sheets: function () {
                if (this.s.paper !== 'sheet') { return []; }
                var copies = [], pages = [], per = this.perSheet, i;
                this.groups.forEach(function (g) {
                    for (i = 0; i < g.count; i++) { copies.push({ row: g.row, code: g.code }); }
                });
                for (i = 0; i < copies.length; i += per) { pages.push(copies.slice(i, i + per)); }
                return pages;
            },
            pageCount: function () { return this.s.paper === 'sheet' ? this.sheets.length : this.total; },
            allChecked: function () {
                return this.rows.length > 0 && this.rows.every(function (r) { return r.checked; });
            },
            sheetStyle: function () {
                var sh = this.s.sheet, s = this.s;
                var cols = Math.max(1, Math.round(num(sh.cols, 5)) || 1);
                return {
                    width: '210mm',
                    height: '297mm',
                    paddingTop: num(sh.top, 0) + 'mm',
                    paddingLeft: num(sh.left, 0) + 'mm',
                    gridTemplateColumns: 'repeat(' + cols + ', ' + num(s.width, 40) + 'mm)',
                    gridAutoRows: num(s.height, 30) + 'mm',
                    columnGap: num(sh.gapX, 0) + 'mm',
                    rowGap: num(sh.gapY, 0) + 'mm'
                };
            },
            pageCss: function () {
                if (this.s.paper === 'sheet') { return '@page { size: 210mm 297mm; margin: 0; }'; }
                return '@page { size: ' + num(this.s.width, 40) + 'mm ' + num(this.s.height, 30) + 'mm; margin: 0; }';
            }
        },
        watch: {
            s: {
                deep: true,
                handler: function () {
                    var self = this;
                    clearTimeout(this.persistTimer);
                    this.persistTimer = setTimeout(function () { saveLocal(self.s); }, 300);
                    this.applyPageRule();
                }
            }
        },
        created: function () {
            this.applyPageRule();
            this.load();
            this.loadPresets();
        },
        methods: {
            codeFor: function (r) {
                var useItem = this.s.barcode.content === 'item' && r.item_code;
                var c = useItem ? r.item_code : r.batch_code;
                if (!c) { return null; }
                return { id: (useItem ? 'bc-i-' : 'bc-b-') + r.det_id, modules: c.modules, bars: c.bars, text: c.text, kind: useItem ? 'item' : 'batch' };
            },
            fmtPrice: function (v) {
                return (v === null || v === undefined) ? '—' : Number(v).toFixed(2);
            },
            applyPageRule: function () {
                var el = document.getElementById('page-rule');
                if (el) { el.textContent = this.pageCss; }
            },
            load: function () {
                var self = this;
                self.loading = true;
                self.error = '';
                Api.get(CFG.data_url).then(function (d) {
                    self.loading = false;
                    if (!Api.isOk(d)) { self.error = Api.getError(d) || 'تعذر تحميل البيانات'; self.rows = []; return; }
                    var data = Api.getData(d) || {};
                    self.source = data.source || {};
                    self.rows = (data.rows || []).map(function (r) { r.count = r.qty; r.checked = false; return r; });
                });
            },
            loadPresets: function () {
                var self = this;
                Api.get(CFG.presets_url).then(function (d) {
                    if (!Api.isOk(d)) { return; }
                    self.presets = Api.getData(d) || [];
                    if (!hasLocal) {
                        var def = self.presets.filter(function (p) { return p.is_default; })[0];
                        if (def) { self.applyPreset(def); }
                    }
                });
            },
            applyPreset: function (p) {
                var zoom = this.s.zoom;
                this.s = merge(defaults(), p.settings || {});
                this.s.zoom = zoom;
                this.presetId = p.id;
            },
            applyPresetId: function () {
                var id = this.presetId;
                var p = this.presets.filter(function (x) { return x.id === id; })[0];
                if (p) { this.applyPreset(p); }
            },
            currentPreset: function () {
                var id = this.presetId;
                return this.presets.filter(function (x) { return x.id === id; })[0] || null;
            },
            resetSettings: function () {
                var zoom = this.s.zoom;
                this.s = defaults();
                this.s.zoom = zoom;
                this.presetId = 0;
                clearLocal();
            },
            settingsForSave: function () {
                var copy = JSON.parse(JSON.stringify(this.s));
                delete copy.zoom;
                return copy;
            },
            savePreset: function (asDefault, asCopy) {
                var self = this, cur = this.currentPreset();
                if (asDefault && cur) { return this.postPreset(cur.id, cur.name, true); }
                var updating = cur && !asCopy;
                Swal.fire({
                    title: updating ? 'تحديث القالب' : 'حفظ قالب جديد',
                    input: 'text',
                    inputValue: updating ? cur.name : '',
                    inputPlaceholder: 'اسم القالب (مثال: زيبرا 40×30)',
                    showCancelButton: true,
                    confirmButtonText: 'حفظ',
                    cancelButtonText: 'إلغاء',
                    inputValidator: function (v) { return (v && v.trim()) ? undefined : 'اكتب اسم القالب'; }
                }).then(function (res) {
                    if (res.isConfirmed) { self.postPreset(updating ? cur.id : 0, res.value.trim(), false); }
                });
            },
            postPreset: function (id, name, isDefault) {
                var self = this, fd = new FormData();
                fd.append('id', id || '');
                fd.append('name', name);
                fd.append('settings', JSON.stringify(this.settingsForSave()));
                fd.append('is_default', isDefault ? '1' : '0');
                Api.post(CFG.save_url, fd).then(function (d) {
                    if (!Api.isOk(d)) { Api.showError(d); return; }
                    var p = Api.getData(d);
                    var found = false;
                    self.presets = self.presets.map(function (x) {
                        if (x.id === p.id) { found = true; return p; }
                        if (p.is_default) { x.is_default = false; }
                        return x;
                    });
                    if (!found) { self.presets.push(p); }
                    self.presetId = p.id;
                    Api.showSuccess(isDefault ? 'صار هذا القالب الافتراضي' : 'تم حفظ القالب');
                });
            },
            deletePreset: function () {
                var self = this, cur = this.currentPreset();
                if (!cur) { return; }
                Swal.fire({
                    title: 'حذف القالب؟', text: cur.name, icon: 'warning', showCancelButton: true,
                    confirmButtonText: 'حذف', cancelButtonText: 'إلغاء', confirmButtonColor: '#b02a37'
                }).then(function (res) {
                    if (!res.isConfirmed) { return; }
                    var fd = new FormData();
                    fd.append('id', cur.id);
                    Api.post(CFG.delete_url, fd).then(function (d) {
                        if (!Api.isOk(d)) { Api.showError(d); return; }
                        self.presets = self.presets.filter(function (x) { return x.id !== cur.id; });
                        self.presetId = 0;
                    });
                });
            },
            applyRoll: function (z) {
                this.s.paper = 'roll';
                this.s.width = z.w;
                this.s.height = z.h;
            },
            applySheet: function (z) {
                this.s.paper = 'sheet';
                this.s.width = z.w;
                this.s.height = z.h;
                this.s.sheet = { cols: z.cols, rows: z.rows, top: z.top, left: z.left, gapX: z.gapX, gapY: z.gapY };
            },
            setCounts: function (mode) {
                this.rows.forEach(function (r) { r.count = mode === 'qty' ? r.qty : (mode === 'one' ? 1 : 0); });
            },
            toggleAll: function (checked) {
                this.rows.forEach(function (r) { r.checked = checked; });
            },
            printOnly: function (r) {
                this.rows.forEach(function (x) { x.checked = (x === r); });
                if (!(num(r.count, 0) > 0)) { r.count = 1; }
                this.selectedOnly = true;
                this.print();
            },
            print: function () {
                var self = this;
                if (!this.total) { Swal.fire('تنبيه', 'لا توجد ملصقات للطباعة: حدد عدداً أكبر من صفر.', 'info'); return; }
                this.applyPageRule();
                this.$nextTick(function () {
                    var ready = (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
                    ready.then(function () { window.print(); });
                });
            }
        }
    });
})();
