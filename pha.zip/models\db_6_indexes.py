# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# فهارس قاعدة البيانات للحقول المستعلمة بكثرة
# تستخدم CREATE INDEX IF NOT EXISTS لتجنب الأخطاء عند إعادة التشغيل
# ===========================================================================================

_indexes = [
    # ── items_det ──
    # item_idr: يُستخدم في JOINs مع items_main في جميع استعلامات الأصناف والفواتير والجرد
    "CREATE INDEX IF NOT EXISTS idx_items_det_item_idr ON items_det(item_idr)",
    # supplier_inv: ربط الأصناف بفواتير التوريد
    "CREATE INDEX IF NOT EXISTS idx_items_det_supplier_inv ON items_det(supplier_inv)",

    # ── items_main ──
    # suppliers: فلترة الأصناف حسب المورد
    "CREATE INDEX IF NOT EXISTS idx_items_main_suppliers ON items_main(suppliers)",
    # item_type: فلترة الأصناف حسب التصنيف
    "CREATE INDEX IF NOT EXISTS idx_items_main_item_type ON items_main(item_type)",
    # name: بحث نصي بالاسم (upper)
    "CREATE INDEX IF NOT EXISTS idx_items_main_name_upper ON items_main(upper(name))",

    # ── items_movement ──
    # فهرس مركب: الاستعلام الأكثر تكراراً (حركة صنف + نوع + تاريخ)
    "CREATE INDEX IF NOT EXISTS idx_items_movement_composite ON items_movement(item_main, move_type, move_date DESC)",
    # item_det: ربط بتفاصيل الأصناف
    "CREATE INDEX IF NOT EXISTS idx_items_movement_item_det ON items_movement(item_det)",

    # ── invoice_master ──
    # ملاحظة: الفهرس غير الفريد idx_invoice_master_uuid حُذف من هنا لأن
    # الفهرس الفريد أدناه يخدم كل استعلام كان يخدمه (نفس العمود ونفس النوع).
    # إبقاء الاثنين يعني تحديث فهرسين مع كل فاتورة على مسار الكاشير.
    # حذفه من القاعدة يتم عبر setup/uuid_guard أو scripts/uuid_unique_migrate.
    # uuid فريد: حارس التكرار الحقيقي. فحص التطبيق "ابحث ثم أدرج" فيه فجوة
    # يمر منها طلبان متزامنان بنفس الرقم (نقر مزدوج / إعادة محاولة بعد انقطاع)
    # فتُحفظ الفاتورة مرتين ويُخصم المخزون مرتين ويصل للهيئة إقرار مضاعف.
    # القيد يغلق الفجوة لأن الرفض يصير جزءاً من الكتابة نفسها.
    # ملاحظة: لو وُجد تكرار سابق في فرع فسيفشل الإنشاء **بصمت** (انظر آخر
    # الملف). تحقّق لكل فرع بـ scripts/uuid_unique_migrate.py — هو ينظّف ويؤكد.
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_invoice_master_uuid_uniq ON invoice_master(uuid)",
    # customer: استعلامات حساب العميل
    "CREATE INDEX IF NOT EXISTS idx_invoice_master_customer ON invoice_master(customer)",
    # created_on: تقارير بنطاق تاريخ + إحصائيات لوحة التحكم
    "CREATE INDEX IF NOT EXISTS idx_invoice_master_created_on ON invoice_master(created_on DESC)",
    # created_by + created_on: إحصائيات البائع اليومية
    "CREATE INDEX IF NOT EXISTS idx_invoice_master_created_by_date ON invoice_master(created_by, created_on DESC)",
    # send_to_zatca: فلترة فواتير ZATCA
    "CREATE INDEX IF NOT EXISTS idx_invoice_master_send_to_zatca ON invoice_master(send_to_zatca) WHERE send_to_zatca = false",

    # ── invoice_details ──
    # uuid: JOIN مع invoice_master
    "CREATE INDEX IF NOT EXISTS idx_invoice_details_uuid ON invoice_details(uuid)",
    # item_number: ربط بتفاصيل الأصناف
    "CREATE INDEX IF NOT EXISTS idx_invoice_details_item_number ON invoice_details(item_number)",
    # created_on: تقارير المبيعات التفصيلية بنطاق تاريخ
    "CREATE INDEX IF NOT EXISTS idx_invoice_details_created_on ON invoice_details(created_on DESC)",

    # ── inv_return_master ──
    # (idx_inv_return_master_uuid غير الفريد حُذف — انظر ملاحظة invoice_master)
    # uuid فريد: نفس منطق فواتير البيع أعلاه — المرتجع فيه الفجوة ذاتها
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_inv_return_master_uuid_uniq ON inv_return_master(uuid)",
    # customer: استعلامات حساب العميل للمرتجعات
    "CREATE INDEX IF NOT EXISTS idx_inv_return_master_customer ON inv_return_master(customer)",
    # created_on: تقارير المرتجعات بنطاق تاريخ
    "CREATE INDEX IF NOT EXISTS idx_inv_return_master_created_on ON inv_return_master(created_on DESC)",

    # ── inv_return_details ──
    # uuid: JOIN مع inv_return_master
    "CREATE INDEX IF NOT EXISTS idx_inv_return_details_uuid ON inv_return_details(uuid)",
    # item_number: ربط بتفاصيل الأصناف
    "CREATE INDEX IF NOT EXISTS idx_inv_return_details_item_number ON inv_return_details(item_number)",
    # created_on: تقارير المرتجعات التفصيلية
    "CREATE INDEX IF NOT EXISTS idx_inv_return_details_created_on ON inv_return_details(created_on DESC)",

    # ── suppliers_bills ──
    # supplier: استعلامات فواتير المورد
    "CREATE INDEX IF NOT EXISTS idx_suppliers_bills_supplier ON suppliers_bills(supplier)",
    # bill_confirmation: فلترة الفواتير المؤكدة/غير المؤكدة
    "CREATE INDEX IF NOT EXISTS idx_suppliers_bills_confirmation ON suppliers_bills(bill_confirmation)",

    # ── suppliers_bills_pay ──
    # supplier: استعلامات سدادات المورد
    "CREATE INDEX IF NOT EXISTS idx_suppliers_bills_pay_supplier ON suppliers_bills_pay(supplier)",

    # ── customers_pay ──
    # customers_id: استعلامات سدادات العميل
    "CREATE INDEX IF NOT EXISTS idx_customers_pay_customers_id ON customers_pay(customers_id)",

    # ── screens_rules ──
    # فهرس مركب: التحقق من صلاحية المستخدم على شاشة معينة
    "CREATE INDEX IF NOT EXISTS idx_screens_rules_user_screen ON screens_rules(to_user, screens)",

    # ── invoice_sending ──
    # send: فلترة الفواتير غير المرسلة
    "CREATE INDEX IF NOT EXISTS idx_invoice_sending_send ON invoice_sending(send) WHERE send = false",

    # ── attendance ──
    # فهرس مركب: بحث حضور موظف في تاريخ محدد
    "CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON attendance(employee, att_date DESC)",

    # ── attendance_otp ──
    # employee: بحث رمز التحقق للموظف
    "CREATE INDEX IF NOT EXISTS idx_attendance_otp_employee ON attendance_otp(employee)",

    # ── emp_leaves ──
    # employee: استعلامات إجازات الموظف
    "CREATE INDEX IF NOT EXISTS idx_emp_leaves_employee ON emp_leaves(employee)",

    # ── emp_salary_detail ──
    # employee: بدلات وخصومات الموظف
    "CREATE INDEX IF NOT EXISTS idx_emp_salary_detail_employee ON emp_salary_detail(employee)",

    # ── emp_advances ──
    # employee + is_closed: السلف المفتوحة للموظف
    "CREATE INDEX IF NOT EXISTS idx_emp_advances_employee ON emp_advances(employee, is_closed)",

    # ── payroll ──
    # فهرس مركب: مسير رواتب موظف لشهر/سنة
    "CREATE INDEX IF NOT EXISTS idx_payroll_employee_period ON payroll(employee, pay_year, pay_month)",

    # ── payroll_detail ──
    # payroll_id: تفاصيل المسير
    "CREATE INDEX IF NOT EXISTS idx_payroll_detail_payroll_id ON payroll_detail(payroll_id)",

    # ── inv_count_item ──
    # session_id: أصناف جلسة الجرد
    "CREATE INDEX IF NOT EXISTS idx_inv_count_item_session ON inv_count_item(session_id)",
    # item_main: بحث صنف في الجرد
    "CREATE INDEX IF NOT EXISTS idx_inv_count_item_item_main ON inv_count_item(item_main)",

    # ── my_files ──
    # expiry_date: تنبيه المستندات المنتهية
    "CREATE INDEX IF NOT EXISTS idx_my_files_expiry_date ON my_files(expiry_date)",
    # created_by: مستندات المستخدم
    "CREATE INDEX IF NOT EXISTS idx_my_files_created_by ON my_files(created_by)",

    # ── closing_shift ──
    # pha_user: فترات المستخدم
    "CREATE INDEX IF NOT EXISTS idx_closing_shift_pha_user ON closing_shift(pha_user)",

    # ── fund_entry ──
    # entry_date: فلترة/ترتيب بالتاريخ
    "CREATE INDEX IF NOT EXISTS idx_fund_entry_entry_date ON fund_entry(entry_date DESC)",
    # status: فلترة بالحالة
    "CREATE INDEX IF NOT EXISTS idx_fund_entry_status ON fund_entry(status)",
    # category_id: فلترة/تجميع حسب التصنيف
    "CREATE INDEX IF NOT EXISTS idx_fund_entry_category ON fund_entry(category_id)",
    # kind: فصل المصروفات عن الإيداعات في التقارير
    "CREATE INDEX IF NOT EXISTS idx_fund_entry_kind ON fund_entry(kind)",
    # ref_type + ref_id: تتبع المستندات المرجعية (فواتير موردين/سلف/...)
    "CREATE INDEX IF NOT EXISTS idx_fund_entry_ref ON fund_entry(ref_type, ref_id)",
]

for _sql in _indexes:
    try:
        db.executesql(_sql)
        db.commit()
    except Exception:
        db.rollback()
