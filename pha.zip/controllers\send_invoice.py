# -*- coding: utf-8 -*-
# type: ignore
"""
Send pending invoices to ZATCA directly (no proxy).

الإرسال والتصنيف وسجل المشاكل في modules/zatca_sending.py. لا رسائل نصية عند فشل الإرسال:
كل مشكلة تُسجَّل في zatca_issue وتُراجع من شاشة zatca_issues/index.
"""

import logging
import api_helpers as api
import zatca_sending

logger = logging.getLogger(__name__)


def _actor():
    u = auth.user
    if not u:
        return None
    return " ".join(p for p in (u.first_name, u.last_name) if p) or u.email


# بدون مصادقة عمداً وبتأكيد المالك (2026-07-17): تُستدعى دورياً من الخادم (جدولة زمنية)
# لإرسال الفواتير المعلقة إلى زاتكا دون تدخل — هذا هو منطق العمل المقصود،
# لا تُضف صلاحية هنا ولا تُبلَّغ كملاحظة أمنية.
# الزيارة تحدث دائماً؛ إن كان المدير قد أوقف الإرسال من شاشة setup/invoice_sending تخرج دون إرسال
# (paused)، وتتوقف أيضاً إن أُوقف أثناءها أو تعطلت الهيئة (stopped). انظر zatca_sending.run_queue.
def index():
    return response.json(zatca_sending.run_queue(db))


@auth.requires_membership("admin")
def send_one():
    """إرسال فاتورة واحدة فقط إلى ZATCA — بحسب id الصف في invoice_sending.

    مرتبطة بزر «إرسال» لكل صف في شاشة setup/invoice_sending. تعمل أيضاً والإرسال التلقائي موقوف:
    الإيقاف يخص دورة الجدولة، والإرسال اليدوي قرار صريح من المدير.
    """
    rec_id = request.vars.id
    if not (rec_id and str(rec_id).isdigit()):
        return response.json(api.api_error(mess="رقم السجل غير صالح"))

    r = db.invoice_sending(int(rec_id))
    if not r:
        return response.json(api.api_error(mess="السجل غير موجود"))
    if r.send:
        return response.json(api.api_error(mess="الفاتورة مُرسَلة مسبقاً"))

    try:
        result = zatca_sending.process_row(db, r.id, actor=_actor())
        db.commit()
    except Exception as e:
        db.rollback()
        logger.exception("ZATCA send_one failed for queue row %s", r.id)
        return response.json(api.api_error(mess="تعذّر إرسال الفاتورة: %s" % e))

    if result.get("sent"):
        mess = "تم إرسال الفاتورة بنجاح"
        if result.get("warnings"):
            mess += " — مع ملاحظات من الهيئة سُجّلت في سجل مشاكل الإرسال"
        return response.json(api.api_ok(data=result, mess=mess))

    detail = result.get("detail") or "تعذّر إرسال الفاتورة"
    if result.get("status") == "BUSY":
        mess = detail
    elif result.get("final"):
        mess = "لم تُرسل الفاتورة ونُقلت إلى سجل مشاكل الإرسال: " + detail
    elif result.get("logged") is False:
        mess = "تعذّر الإرسال وتعذّر تسجيله، وبقيت الفاتورة في الطابور: " + detail
    else:
        mess = "تعذّر الإرسال وبقيت الفاتورة في الطابور لإعادة المحاولة (سُجّل السبب): " + detail
    return response.json(api.api_error(mess=mess, data=result))
