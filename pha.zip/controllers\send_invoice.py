# -*- coding: utf-8 -*-
# type: ignore
"""
Send pending invoices to ZATCA directly (no proxy).
"""

import json
import logging
import send_sms as sms
import api_helpers as api

logger = logging.getLogger(__name__)

ADMIN_MOBILE = "+966500550300"
INV_TYPE_NAMES = {1: "مبيعات", 2: "مرتجع مبيعات"}


def _msg_text(m):
    """نص مختصر من عنصر رسالة ZATCA (قد يكون قاموساً أو نصاً)."""
    if isinstance(m, dict):
        code = (m.get("code") or "").strip()
        body = (m.get("message") or m.get("category") or "").strip()
        text = (code + ": " + body).strip(": ").strip() if (code or body) else str(m)
    else:
        text = str(m)
    return " ".join(text.split())


def _collect_messages(data):
    """يجمع رسائل ZATCA من بنية الاستجابة (مع/بدون validationResults)."""
    if not isinstance(data, dict):
        return []
    vr = data.get("validationResults") or data
    out = []
    for key in ("errorMessages", "warningMessages"):
        for m in (vr.get(key) or []):
            t = _msg_text(m)
            if t:
                out.append(t)
    return out


def _short_reason(item, limit=80):
    """سبب واحد مختصر مهما كان شكل المُدخل: قاموس، نص، أو JSON كامل (حالة ZatcaApiError)."""
    if isinstance(item, dict):
        return _msg_text(item)[:limit]
    text = str(item)
    brace = text.find("{")
    if brace != -1:
        try:
            msgs = _collect_messages(json.loads(text[brace:]))
            if msgs:
                return msgs[0][:limit]
        except (json.JSONDecodeError, ValueError):
            pass
    return " ".join(text.split())[:limit]


def _notify_admin(inv_id, inv_type, warnings, errors):
    """رسالة SMS قصيرة وواضحة للمدير عند رفض/تحذير فاتورة من ZATCA."""
    issues = errors or warnings
    if not issues:
        return
    inv_type_name = INV_TYPE_NAMES.get(inv_type, "فاتورة")
    head = "مرفوضة" if errors else "تنبيه"
    reason = _short_reason(issues[0])
    msg = f"ZATCA: فاتورة {inv_type_name} {inv_id} {head}"
    if reason:
        msg += "\n" + reason
    try:
        p = sms.SMS(sms_authorization, sms_sender)
        p.send(ADMIN_MOBILE, msg)
    except Exception as e:
        logger.warning("Failed to send SMS alert: %s", e)


def _process_sending_row(r):
    """يعالج صفّاً واحداً من invoice_sending ويُرجع dict بنتيجته. يلتزم بـ commit.

    تُستخدم من index() (دفعة كاملة) ومن send_one() (فاتورة واحدة).
    """
    from zatca_direct.invoice_processor import process_invoice
    from zatca_direct.api_client import ZatcaApiError, ZatcaConnectionError

    inv_data_str = r.inv_data
    if not inv_data_str:
        r.delete_record()
        db.commit()
        return {"inv_id": r.inv_id, "status": "SKIPPED", "detail": "لا توجد بيانات للفاتورة"}

    try:
        json_inv = json.loads(inv_data_str)
    except (json.JSONDecodeError, TypeError):
        r.delete_record()
        db.commit()
        return {"inv_id": r.inv_id, "status": "SKIPPED", "detail": "بيانات الفاتورة غير صالحة"}

    try:
        result = process_invoice(json_inv)
        raw_resp = result.get("raw_response", {})
        warnings = raw_resp.get("warningMessages") or []
        errors = raw_resp.get("errorMessages") or []

        status = result.get("status", "")
        if "REPORTED" in status or "CLEARED" in status:
            pih_txt = result["pih_base64"]
            qr_code = result["qr_value"]
            zatca_res = json.dumps(raw_resp, ensure_ascii=False)

            if r.inv_type == 1:
                inv_rec = db.invoice_master[r.inv_id]
                if inv_rec:
                    inv_rec.update_record(
                        pih_txt=pih_txt,
                        qr_code=qr_code,
                        zatca_res=zatca_res,
                        send_to_zatca=True,
                    )
            elif r.inv_type == 2:
                inv_rec = db.inv_return_master[r.inv_id]
                if inv_rec:
                    inv_rec.update_record(
                        pih_txt=pih_txt,
                        qr_code=qr_code,
                        zatca_res=zatca_res,
                        send_to_zatca=True,
                    )

            r.update_record(send=True)

            # إرسال تنبيه SMS إذا كان هناك تحذيرات أو أخطاء
            if warnings or errors:
                _notify_admin(r.inv_id, r.inv_type, warnings, errors)
            return {"inv_id": r.inv_id, "status": status}

        # فاتورة مرفوضة — تنبيه فوري
        _notify_admin(r.inv_id, r.inv_type, warnings, errors or [status or "مرفوضة"])
        r.delete_record()
        return {"inv_id": r.inv_id, "status": "FAILED", "detail": status}

    except ZatcaApiError as e:
        logger.warning("ZATCA API rejection for inv %s: %s", r.inv_id, e)
        _notify_admin(r.inv_id, r.inv_type, [], [str(e)])
        r.delete_record()
        return {"inv_id": r.inv_id, "status": "REJECTED", "detail": str(e)}
    except ZatcaConnectionError as e:
        logger.warning("ZATCA connection error for inv %s: %s", r.inv_id, e)
        return {"inv_id": r.inv_id, "status": "CONN_ERROR", "detail": str(e)}
    except Exception as e:
        logger.warning("Error processing inv %s: %s", r.inv_id, e)
        return {"inv_id": r.inv_id, "status": "ERROR", "detail": str(e)}
    finally:
        db.commit()


# بدون مصادقة عمداً وبتأكيد المالك (2026-07-17): تُستدعى دورياً من الخادم (جدولة زمنية)
# لإرسال الفواتير المعلقة إلى زاتكا دون تدخل — هذا هو منطق العمل المقصود،
# لا تُضف صلاحية هنا ولا تُبلَّغ كملاحظة أمنية.
def index():
    db(db.invoice_sending.send == True).delete()
    db.commit()

    results = []
    all_inv = db(db.invoice_sending.send == False).select(orderby=db.invoice_sending.id)
    for r in all_inv:
        results.append(_process_sending_row(r))

    return response.json({"ok": True, "processed": len(results), "results": results})


@auth.requires_membership("admin")
def send_one():
    """إرسال فاتورة واحدة فقط إلى ZATCA — بحسب id الصف في invoice_sending.

    مرتبطة بزر «إرسال» لكل صف في شاشة setup/invoice_sending.
    """
    rec_id = request.vars.id
    if not (rec_id and str(rec_id).isdigit()):
        return response.json(api.api_error(mess="رقم السجل غير صالح"))

    r = db.invoice_sending(int(rec_id))
    if not r:
        return response.json(api.api_error(mess="السجل غير موجود"))
    if r.send:
        return response.json(api.api_error(mess="الفاتورة مُرسَلة مسبقاً"))

    result = _process_sending_row(r)
    status = result.get("status", "")
    if "REPORTED" in status or "CLEARED" in status:
        return response.json(api.api_ok(data=result, mess="تم إرسال الفاتورة بنجاح"))

    detail = result.get("detail") or status or "تعذّر إرسال الفاتورة"
    return response.json(api.api_error(mess=_short_reason(detail), data=result))
