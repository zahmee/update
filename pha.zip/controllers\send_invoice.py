# -*- coding: utf-8 -*-
# type: ignore
"""
Send pending invoices to ZATCA directly (no proxy).
"""

import json
import logging
import send_sms as sms

logger = logging.getLogger(__name__)

ADMIN_MOBILE = "+966500550300"
INV_TYPE_NAMES = {1: "مبيعات", 2: "مرتجع مبيعات"}


def _notify_admin(inv_id, inv_type, warnings, errors):
    """إرسال رسالة نصية للمدير عند وجود تحذيرات أو أخطاء من ZATCA"""
    inv_type_name = INV_TYPE_NAMES.get(inv_type, "فاتورة")
    parts = [f"تنبيه ZATCA - فاتورة {inv_type_name} رقم {inv_id}:"]
    if errors:
        parts.append("أخطاء: " + " | ".join(str(e) for e in errors[:3]))
    if warnings:
        parts.append("تحذيرات: " + " | ".join(str(w) for w in warnings[:3]))
    msg = "\n".join(parts)
    try:
        p = sms.SMS(sms_authorization, sms_sender)
        p.send(ADMIN_MOBILE, msg)
    except Exception as e:
        logger.warning("Failed to send SMS alert: %s", e)


@auth.requires_login()
def index():
    from zatca_direct.invoice_processor import process_invoice
    from zatca_direct.api_client import ZatcaApiError, ZatcaConnectionError

    db(db.invoice_sending.send == True).delete()
    db.commit()

    results = []
    all_inv = db(db.invoice_sending.send == False).select(orderby=db.invoice_sending.id)
    for r in all_inv:
        inv_data_str = r.inv_data
        if not inv_data_str:
            r.delete_record()
            db.commit()
            continue

        try:
            json_inv = json.loads(inv_data_str)
        except (json.JSONDecodeError, TypeError):
            r.delete_record()
            db.commit()
            continue

        try:
            result = process_invoice(json_inv)
            raw_resp = result.get("raw_response", {})
            warnings = raw_resp.get("warningMessages") or []
            errors = raw_resp.get("errorMessages") or []

            status = result.get("status", "")
            if "REPORTED" in status or "CLEARED" in status:
                pih_txt = result["pih_base64"]
                qr_code = result["qr_value"]
                zatca_res = json.dumps(raw_resp, ensure_ascii=False)

                if r.inv_type == 1:
                    inv_rec = db.invoice_master[r.inv_id]
                    if inv_rec:
                        inv_rec.update_record(
                            pih_txt=pih_txt,
                            qr_code=qr_code,
                            zatca_res=zatca_res,
                            send_to_zatca=True,
                        )
                elif r.inv_type == 2:
                    inv_rec = db.inv_return_master[r.inv_id]
                    if inv_rec:
                        inv_rec.update_record(
                            pih_txt=pih_txt,
                            qr_code=qr_code,
                            zatca_res=zatca_res,
                            send_to_zatca=True,
                        )

                r.update_record(send=True)
                results.append({"inv_id": r.inv_id, "status": status})

                # إرسال تنبيه SMS إذا كان هناك تحذيرات أو أخطاء
                if warnings or errors:
                    _notify_admin(r.inv_id, r.inv_type, warnings, errors)
            else:
                # فاتورة مرفوضة — تنبيه فوري
                _notify_admin(r.inv_id, r.inv_type, warnings, errors or [status or "مرفوضة"])
                r.delete_record()
                results.append({"inv_id": r.inv_id, "status": "FAILED", "detail": status})

        except (ZatcaApiError, ZatcaConnectionError) as e:
            logger.warning("ZATCA error for inv %s: %s", r.inv_id, e)
            _notify_admin(r.inv_id, r.inv_type, [], [str(e)])
            results.append({"inv_id": r.inv_id, "status": "ERROR", "detail": str(e)})
        except Exception as e:
            logger.warning("Error processing inv %s: %s", r.inv_id, e)
            results.append({"inv_id": r.inv_id, "status": "ERROR", "detail": str(e)})
        finally:
            db.commit()

    return response.json({"ok": True, "processed": len(results), "results": results})
