# -*- coding: utf-8 -*-
"""قواعد إدخال بيانات الصنف المشتركة: الباركود والاسم.

مصدر واحد تستخدمه كل مسارات الكتابة حتى لا تختلف القواعد بينها:
إنشاء الصنف (api_1.newMainItem)، وتعديله (api_1.editMainItem)،
وشاشة تغيير الباركود (items._barcode_change_state).

قرار المالك 2026-09-17: يُرفض ما يُفسد البيع أو البيانات، ويُحذَّر من المشكوك
فيه مع السماح بالمتابعة. الدوال التي تحتاج القاعدة تستقبل db معاملاً.
"""
import re

# نقطة البيع (invoice.getit) تقرأ أي إدخال رقمي كرقم دفعة أولاً، فالباركود
# الأقصر من 8 خانات قد يطابق دفعة صنف آخر فيُباع ذلك الصنف بدل المقصود.
MIN_DIGITS = 8
MAX_LENGTH = 20  # طول حقل items_main.item_id
STANDARD_LENGTHS = (8, 12, 13, 14)  # EAN-8 / UPC-A / EAN-13 / GTIN-14
# نطاق GS1 المخصص للاستخدام الداخلي 20–29، ويُولَّد منه باركود المنتج الذي لا باركود له.
# البادئة 2990 لا 29 وحدها: موزعون يطبعون أكواداً داخلية تبدأ بـ 29 (مثل 2961544500921
# لمعجون سنسوداين)، فمتابعة تسلسلهم تتعارض مع منتجاتهم القادمة. 2990 غير مستخدمة (2026-09-17).
INTERNAL_PREFIX = "2990"
INTERNAL_SEQ_DIGITS = 8  # 4 + 8 + خانة تحقق = 13
NAME_MIN = 10
NAME_MAX = 460

_ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_ASCENDING = "1234567890" * 3
_DESCENDING = "9876543210" * 3


# ------------------------------------------------------------------ الباركود
def normalize_barcode(code):
    """حذف المسافات الطرفية وتحويل الأرقام العربية إلى إنجليزية."""
    return str(code or "").strip().translate(_ARABIC_DIGITS)


def barcode_key(code):
    """مفتاح المقارنة: الرقم بلا أصفار بادئة، لأن UPC-A و EAN-13 للمنتج نفسه
    يختلفان بصفر في أولهما حسب إعداد الماسح."""
    return normalize_barcode(code).lstrip("0")


def check_digit(body):
    """خانة التحقق وفق GS1 لأرقام الجسم (كل الخانات عدا الأخيرة)."""
    total = 0
    for i, ch in enumerate(reversed(body)):
        total += int(ch) * (3 if i % 2 == 0 else 1)
    return str((10 - total % 10) % 10)


def is_placeholder(code):
    """باركود وهمي: أصفار، أو رقم واحد مكرر، أو تسلسل مثل 123 أو 987."""
    key = barcode_key(code)
    if not key or len(set(key)) == 1:
        return True
    return len(key) >= 3 and (_ASCENDING.startswith(key) or _DESCENDING.startswith(key))


def barcode_errors(code):
    """أخطاء الصيغة التي تمنع الحفظ (بلا قاعدة البيانات)."""
    code = normalize_barcode(code)
    if not code:
        return ["الباركود مطلوب."]
    if not re.fullmatch(r"[0-9]+", code):
        return ["الباركود أرقام فقط، بلا مسافات أو حروف أو شرطات."]
    if len(code) > MAX_LENGTH:
        return ["الباركود أطول من %d خانة." % MAX_LENGTH]
    if len(code) < MIN_DIGITS:
        return [
            "الباركود أقل من %d خانات، ونقطة البيع تقرأ الرقم القصير كرقم دفعة فقد تبيع صنفاً آخر. "
            "إن لم يكن للمنتج باركود فاستخدم زر «توليد»." % MIN_DIGITS
        ]
    if is_placeholder(code):
        return ["باركود وهمي (أصفار أو رقم مكرر أو أرقام متسلسلة). امسح الباركود من العلبة أو استخدم زر «توليد»."]
    return []


def barcode_warnings(code):
    """ملاحظات لا تمنع الحفظ لكنها تستدعي تأكيد المستخدم."""
    code = normalize_barcode(code)
    if barcode_errors(code):
        return []
    if len(code) not in STANDARD_LENGTHS:
        return ["طول الباركود غير قياسي (%d خانة)، والمعتاد 8 أو 12 أو 13 أو 14." % len(code)]
    if check_digit(code[:-1]) != code[-1]:
        return ["خانة التحقق في الباركود غير صحيحة، وغالباً سببها خطأ في الكتابة. تأكد بمسح العلبة."]
    return []


def barcode_owner(db, code, exclude_id=0):
    """صنف آخر يملك الباركود نفسه (مع تجاهل الأصفار البادئة) حالياً أو كباركود سابق.
    يعيد dict(kind, id, item_id, name) أو None."""
    key = barcode_key(code)
    if not key:
        return None
    rows = db.executesql(
        "SELECT id, item_id, UPPER(name) AS name FROM items_main"
        " WHERE LTRIM(TRIM(item_id), '0') = %s AND id <> %s ORDER BY id LIMIT 1",
        placeholders=[key, int(exclude_id or 0)],
        as_dict=True,
    )
    if rows:
        return dict(rows[0], kind="item")
    rows = db.executesql(
        "SELECT im.id, al.barcode AS item_id, UPPER(im.name) AS name"
        " FROM item_barcode_alias al JOIN items_main im ON im.id = al.item_idr"
        " WHERE LTRIM(TRIM(al.barcode), '0') = %s AND im.id <> %s ORDER BY al.id LIMIT 1",
        placeholders=[key, int(exclude_id or 0)],
        as_dict=True,
    )
    return dict(rows[0], kind="alias") if rows else None


def owner_message(owner):
    if owner["kind"] == "alias":
        return "الباركود مسجل كباركود سابق للصنف: %s (م %s)." % (owner["name"], owner["id"])
    return "الباركود مستخدم للصنف: %s (م %s، الباركود %s)." % (owner["name"], owner["id"], owner["item_id"])


def next_internal_barcode(db):
    """أول باركود داخلي غير مستخدم: 2990 + تسلسل من 8 خانات + خانة تحقق = 13 خانة."""
    pattern = "^%s[0-9]{%d}$" % (INTERNAL_PREFIX, INTERNAL_SEQ_DIGITS + 1)
    start = len(INTERNAL_PREFIX) + 1
    last = db.executesql(
        "SELECT MAX(s) FROM ("
        " SELECT SUBSTRING(item_id FROM %s FOR %s)::bigint AS s FROM items_main WHERE item_id ~ %s"
        " UNION ALL"
        " SELECT SUBSTRING(barcode FROM %s FOR %s)::bigint FROM item_barcode_alias WHERE barcode ~ %s"
        ") t",
        placeholders=[start, INTERNAL_SEQ_DIGITS, pattern, start, INTERNAL_SEQ_DIGITS, pattern],
    )[0][0]
    seq = int(last or 0) + 1
    while True:
        body = INTERNAL_PREFIX + str(seq).zfill(INTERNAL_SEQ_DIGITS)
        code = body + check_digit(body)
        if not barcode_owner(db, code):
            return code
        seq += 1


# ------------------------------------------------------------------ سعر البيع
def _is_true(value):
    return str(value) in ("T", "True", "true", "t", "1")


def sale_price(det_price, det_vat, det_vat_incl, card_price):
    """سعر البيع كما تحتسبه نقطة البيع: سعر أحدث دفعة مسعّرة، وتُضاف الضريبة
    إلا إذا كانت الدفعة موسومة "الضريبة ضمن سعر البيع". إن لم توجد دفعة مسعّرة
    يُستخدم سعر بطاقة الصنف. يعيد (شامل الضريبة، قبل الضريبة، النسبة، المصدر)."""
    try:
        price = float(det_price or 0)
    except (TypeError, ValueError):
        price = 0.0
    if price > 0:
        try:
            vat = float(det_vat or 0)
        except (TypeError, ValueError):
            vat = 0.0
        if _is_true(det_vat_incl):
            return round(price, 2), round(price / (1 + vat), 2), vat, "batch"
        return round(price * (1 + vat), 2), round(price, 2), vat, "batch"
    try:
        card = float(card_price or 0)
    except (TypeError, ValueError):
        card = 0.0
    if card > 0:
        return round(card, 2), round(card, 2), 0.0, "card"
    return None, None, 0.0, None


# ------------------------------------------------------------------ المورد
# الصنف "بلا مورد" = خانته فارغة أو مورده موقوف (مثل "المستودع الرئيسي" الذي
# كانت أداة الصيانة المحذوفة تضعه تلقائياً). الشرط نفسه في التعبئة والتسوية.
NO_ACTIVE_SUPPLIER_SQL = (
    "NOT EXISTS (SELECT 1 FROM suppliers s_act"
    " WHERE s_act.id = im.suppliers AND COALESCE(s_act.stoped, 'F') <> 'T')"
)


def fill_supplier_if_missing(db, item_idr, supplier_id):
    """يُعبئ مورد الصنف من فاتورة التوريد إن لم يكن له مورد نشط (قرار المالك
    2026-09-17). الصنف الذي له مورد نشط لا يتغير أبداً، ومورد الفاتورة الموقوف لا يُعتمد."""
    if not item_idr or not supplier_id:
        return
    db.executesql(
        "UPDATE items_main im SET suppliers = %s"
        " WHERE im.id = %s AND " + NO_ACTIVE_SUPPLIER_SQL +
        " AND EXISTS (SELECT 1 FROM suppliers s WHERE s.id = %s AND COALESCE(s.stoped, 'F') <> 'T')",
        placeholders=[int(supplier_id), int(item_idr), int(supplier_id)],
    )


# ------------------------------------------------------------------ الاسم
def normalize_name(name):
    """مسافة واحدة بين الكلمات، بلا مسافات طرفية، وبحروف كبيرة."""
    return re.sub(r"\s+", " ", str(name or "")).strip().upper()


def name_errors(name):
    name = normalize_name(name)
    if not name:
        return ["اسم الصنف مطلوب."]
    if len(name) < NAME_MIN:
        return ["اسم الصنف يجب ألا يقل عن %d أحرف." % NAME_MIN]
    if len(name) > NAME_MAX:
        return ["اسم الصنف يجب ألا يزيد عن %d حرفاً." % NAME_MAX]
    if not re.search(r"[A-Za-zء-ي]", name):
        return ["اسم الصنف يجب أن يحتوي على حروف."]
    return []


def same_name_items(db, name, exclude_id=0):
    """أصناف أخرى بالاسم نفسه بعد توحيد المسافات والحروف (للتحذير لا للمنع)."""
    return db.executesql(
        "SELECT id, item_id, UPPER(name) AS name FROM items_main"
        " WHERE UPPER(REGEXP_REPLACE(TRIM(name), '\\s+', ' ', 'g')) = %s AND id <> %s"
        " ORDER BY id LIMIT 3",
        placeholders=[normalize_name(name), int(exclude_id or 0)],
        as_dict=True,
    )
