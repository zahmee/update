/* مقارنة المبيعات الشهرية بين السنوات — invoice_rep/rep13
 * البيانات والحساب كلها من invoice_rep/rep13_data (modules/sales_compare.py)؛ هنا العرض والرسم فقط. */
(function () {
    "use strict";

    var CFG = window.SC_CONFIG || {};
    var MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
    var SHORT = { sales: "المبيعات", net: "الصافي", returns: "المرتجعات", count: "عدد الفواتير", avg: "متوسط الفاتورة" };
    // ألوان مُتحقَّق منها (فرق لوني كافٍ لعمى الألوان): السنة المبرزة، والتي قبلها، والبقية رمادي
    var COLOR = { focus: "#0d9488", compare: "#c2410c", other: "#c3c9d2" };
    var compact = new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 });

    function niceTicks(min, max, count) {
        if (!(max > min)) { max = min + 1; }
        var raw = (max - min) / count;
        var mag = Math.pow(10, Math.floor(Math.log10(raw)));
        var n = raw / mag;
        var step = (n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10) * mag;
        var lo = Math.floor(min / step) * step;
        var hi = Math.ceil(max / step) * step;
        var out = [];
        for (var v = lo; v <= hi + step / 2; v += step) out.push(Math.round(v * 100) / 100);
        return out;
    }

    function readQuery() {
        var q = new URLSearchParams(window.location.search);
        return {
            measure: q.get("measure"), vat: q.get("vat"),
            y1: parseInt(q.get("y1"), 10) || null, y2: parseInt(q.get("y2"), 10) || null,
            focus: parseInt(q.get("focus"), 10) || null,
        };
    }

    var init = readQuery();
    var measureKeys = (CFG.measures || []).map(function (m) { return m.key; });

    window.vm = new Vue({
        el: "#salesCompareApp",
        data: {
            measures: CFG.measures || [],
            measure: measureKeys.indexOf(init.measure) >= 0 ? init.measure : "sales",
            vat: init.vat === "ex" ? "ex" : "in",
            y1: init.y1,
            y2: init.y2,
            bounds: null,
            res: null,
            loading: false,
            downloading: false,
            error: "",
            focusYear: init.focus,
            hoverMonth: null,
            chartW: 900,
            seq: 0,
            ctrl: null,
        },
        computed: {
            yearOptions: function () {
                var out = [];
                if (!this.bounds) return this.y1 ? [this.y1, this.y2] : [];
                for (var y = this.bounds.first; y <= this.bounds.last; y++) out.push(y);
                return out;
            },
            years: function () { return this.res ? this.res.years : []; },
            yearsDesc: function () { return this.years.slice().reverse(); },
            compareYear: function () {
                return this.years.indexOf(this.focusYear - 1) >= 0 ? this.focusYear - 1 : null;
            },
            focusTotal: function () {
                var y = this.focusYear;
                return this.res ? this.res.totals.find(function (t) { return t.y === y; }) || null : null;
            },
            bestTotal: function () {
                var b = this.res && this.res.best_year;
                return b ? this.res.totals.find(function (t) { return t.y === b; }) : null;
            },
            measureName: function () { return SHORT[this.measure] || ""; },
            chart: function () {
                var W = Math.max(320, this.chartW), narrow = W < 640;
                var H = narrow ? 230 : 280;
                var left = 34, right = W - (narrow ? 44 : 58), top = 12, bottom = H - 26;
                var step = (right - left) / 12;
                // الأشهر من اليمين إلى اليسار (اتجاه القراءة العربية)
                var xs = [];
                for (var m = 1; m <= 12; m++) xs.push(right - (m - 0.5) * step);
                var empty = { W: W, H: H, left: left, right: right, top: top, bottom: bottom, step: step,
                    xs: xs, ticks: [], series: [], labels: [], narrow: narrow };
                if (!this.res) return empty;

                // الشهر الجاري لا يُرسم: قيمته ناقصة فتبدو هبوطاً وتمطّ المحور؛ هو في التلميح والجدول
                var vals = [];
                this.res.rows.forEach(function (r) {
                    r.cells.forEach(function (c) { if (c.v !== null && !c.partial) vals.push(c.v); });
                });
                if (!vals.length) return empty;
                var tv = niceTicks(Math.max(0, Math.min.apply(null, vals)), Math.max.apply(null, vals), narrow ? 4 : 5);
                var lo = tv[0], hi = tv[tv.length - 1];
                var yOf = function (v) { return bottom - (v - lo) / (hi - lo) * (bottom - top); };
                var ticks = tv.map(function (v) { return { v: v, y: yOf(v), label: compact.format(v) }; });

                var self = this, series = [];
                this.years.forEach(function (year, idx) {
                    var role = year === self.focusYear ? "focus" : (year === self.compareYear ? "compare" : "other");
                    var pts = [];
                    self.res.rows.forEach(function (r) {
                        var c = r.cells[idx];
                        if (c.v !== null && !c.partial) pts.push({ m: r.m, x: xs[r.m - 1], y: yOf(c.v), v: c.v });
                    });
                    var path = "", prev = null;
                    pts.forEach(function (p) {
                        path += (prev && prev.m === p.m - 1 ? "L" : "M") + p.x + "," + p.y;
                        prev = p;
                    });
                    series.push({
                        year: year, role: role, points: pts, path: path,
                        color: COLOR[role],
                        width: role === "focus" ? 2.5 : (role === "compare" ? 2 : 1.5),
                        dash: role === "compare" ? "6 4" : null,
                    });
                });
                var order = { other: 0, compare: 1, focus: 2 };
                series.sort(function (a, b) { return order[a.role] - order[b.role]; });

                // اسم السنة عند نهاية خطّي المقارنة، مع إبعاد المتقاربين
                var labels = series.filter(function (s) { return s.role !== "other" && s.points.length; })
                    .map(function (s) {
                        var p = s.points[s.points.length - 1];
                        return { year: s.year, x: p.x - 7, y: p.y + 4 };
                    });
                if (labels.length === 2 && Math.abs(labels[0].x - labels[1].x) < 40
                        && Math.abs(labels[0].y - labels[1].y) < 13) {
                    var up = labels[0].y <= labels[1].y ? 0 : 1;
                    labels[up].y -= 7;
                    labels[1 - up].y += 7;
                }
                return { W: W, H: H, left: left, right: right, top: top, bottom: bottom, step: step,
                    xs: xs, ticks: ticks, series: series, labels: labels, narrow: narrow };
            },
            tip: function () {
                if (!this.res || !this.hoverMonth) return null;
                var m = this.hoverMonth, self = this;
                var row = this.res.rows[m - 1];
                var rows = row.cells.filter(function (c) { return c.v !== null; }).map(function (c) {
                    var role = c.y === self.focusYear ? "focus" : (c.y === self.compareYear ? "compare" : "other");
                    return { y: c.y, v: c.v, g: c.g, partial: c.partial, role: role, color: COLOR[role] };
                }).reverse();
                if (!rows.length) return null;
                // 8 = حشوة صندوق الرسم
                var x = this.chart.xs[m - 1];
                var style = x > this.chart.W / 2
                    ? { right: (this.chart.W - x + 22) + "px" }
                    : { left: (x + 22) + "px" };
                return { rows: rows, style: style };
            },
        },
        mounted: function () {
            var self = this;
            this.measureChart();
            window.addEventListener("resize", function () { self.measureChart(); });
            this.load();
        },
        methods: {
            measureChart: function () {
                var box = this.$refs.chartBox;
                if (box) this.chartW = Math.floor(box.clientWidth - 16);
            },
            query: function (withFocus) {
                var q = new URLSearchParams();
                q.set("measure", this.measure);
                q.set("vat", this.vat);
                if (this.y1) q.set("y1", this.y1);
                if (this.y2) q.set("y2", this.y2);
                if (withFocus && this.focusYear) q.set("focus", this.focusYear);
                return q.toString();
            },
            syncUrl: function () {
                try {
                    history.replaceState(null, "", window.location.pathname + "?" + this.query(true));
                } catch (e) { /* عرض فقط */ }
            },
            load: function () {
                var self = this, seq = ++this.seq;
                if (this.ctrl) this.ctrl.abort();
                var ctrl = new AbortController();
                this.ctrl = ctrl;
                this.loading = true;
                this.error = "";
                fetch(CFG.data + "?" + this.query(false), {
                    signal: ctrl.signal, credentials: "same-origin", headers: { Accept: "application/json" },
                }).then(function (r) {
                    if (!r.ok) throw new Error("HTTP " + r.status);
                    var ct = r.headers.get("Content-Type") || "";
                    if (ct.indexOf("json") < 0) throw new Error("انتهت الجلسة؛ أعد تحميل الصفحة");
                    return r.json();
                }).then(function (d) {
                    if (seq !== self.seq) return;
                    if (!Api.isOk(d)) { self.error = Api.getError(d); if (self.res) Api.showError(d); return; }
                    var data = Api.getData(d);
                    self.res = data;
                    self.bounds = data.bounds;
                    self.y1 = data.years[0];
                    self.y2 = data.years[data.years.length - 1];
                    if (data.years.indexOf(self.focusYear) < 0) self.focusYear = self.y2;
                    self.syncUrl();
                    self.$nextTick(function () {
                        self.measureChart();
                        // على الشاشات الضيقة يُفتح الجدول على أحدث السنوات (يسار الجدول في RTL)
                        var w = self.$refs.tableWrap;
                        if (w && w.scrollWidth > w.clientWidth) w.scrollLeft = -w.scrollWidth;
                    });
                }).catch(function (e) {
                    if (e.name === "AbortError" || seq !== self.seq) return;
                    self.error = "تعذّر تحميل التقرير: " + e.message;
                    if (self.res) Swal.fire("تنبيه", self.error, "error");
                }).finally(function () {
                    if (seq === self.seq) self.loading = false;
                });
            },
            setMeasure: function (key) {
                if (this.measure === key) return;
                this.measure = key;
                this.load();
            },
            setVat: function (v) {
                if (this.vat === v) return;
                this.vat = v;
                this.load();
            },
            setFocus: function (y) {
                this.focusYear = y;
                this.syncUrl();
            },
            downloadExcel: function () {
                var self = this;
                if (this.downloading || !this.res) return;
                this.downloading = true;
                fetch(CFG.excel + "?" + this.query(false), { credentials: "same-origin" }).then(function (r) {
                    var ct = r.headers.get("Content-Type") || "";
                    if (ct.indexOf("json") >= 0) {
                        return r.json().then(function (d) { throw new Error(Api.getError(d)); });
                    }
                    if (!r.ok || ct.indexOf("spreadsheet") < 0) throw new Error("انتهت الجلسة؛ أعد تحميل الصفحة");
                    var cd = r.headers.get("Content-Disposition") || "";
                    var m = /filename\*=UTF-8''([^;]+)/i.exec(cd);
                    var name = m ? decodeURIComponent(m[1]) : "sales_monthly.xlsx";
                    return r.blob().then(function (blob) {
                        var a = document.createElement("a");
                        a.href = URL.createObjectURL(blob);
                        a.download = name;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
                    });
                }).catch(function (e) {
                    Swal.fire("تنبيه", e.message, "error");
                }).finally(function () {
                    self.downloading = false;
                });
            },
            shortName: function (key) { return SHORT[key] || key; },
            monthName: function (m) { return MONTHS[m - 1]; },
            fmt: function (v) {
                if (v === null || v === undefined) return "—";
                var d = this.res && this.res.measure === "avg" ? 2 : 0;
                return Number(v).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
            },
            pct: function (g) {
                if (g === null || g === undefined) return "—";
                return (g > 0 ? "+" : "") + g.toFixed(1) + "%";
            },
            gClass: function (g) {
                if (g === null || g === undefined) return "sc-flat";
                return g > 0 ? "sc-up" : (g < 0 ? "sc-down" : "sc-flat");
            },
            colClass: function (y) {
                return { "sc-col-focus": y === this.focusYear, "sc-col-compare": y === this.compareYear };
            },
            growthTitle: function (t) {
                if (!t) return "";
                if (t.g === null) return "لا توجد سنة سابقة للمقارنة";
                var txt = "مقارنة بـ " + (t.y - 1) + " على " + t.shared + " شهر مشترك";
                return t.current ? txt + "، حتى تاريخه" : txt;
            },
            cellTitle: function (row, c) {
                if (c.v === null) return "لا مبيعات مسجلة";
                if (!c.partial) return row.name + " " + c.y;
                var n = this.res.now;
                return row.name + " " + c.y + ": شهر جارٍ، يقارَن حتى يوم " + n.day + " بالفترة نفسها من " + (c.y - 1);
            },
        },
    });
})();
