# -*- coding: utf-8 -*-
"""سجل سداد السلف (modules/advance_ledger.py) على قاعدة DAL معزولة في الذاكرة.

Run from the app root: python -B scripts/test_advance_ledger.py
لا تُحمَّل نماذج التطبيق ولا قاعدته التشغيلية.
"""

import sys
import unittest
from datetime import date, datetime
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP.parents[1]))
sys.path.insert(0, str(APP / "modules"))

from gluon import DAL, Field
import advance_ledger as lg

TODAY = date(2026, 9, 24)


def make_db():
    db = DAL("sqlite:memory")
    sig = [Field("created_on", "datetime", default=datetime(2026, 1, 1)),
           Field("modified_on", "datetime", default=datetime(2026, 1, 1)),
           Field("created_by", "integer"), Field("modified_by", "integer")]
    db.define_table("key_allowance_deduction", Field("name"), Field("ad_type"))
    db.define_table("emp_advances", Field("employee", "integer"), Field("advance_type", "integer"),
                    Field("amount", "double", default=0), Field("paid_amount", "double", default=0),
                    Field("advance_date", "date"), Field("is_closed", "boolean", default=False),
                    Field("closed_date", "date"), *[f.clone() for f in sig])
    db.define_table("payroll_period", Field("pay_month", "integer"), Field("pay_year", "integer"),
                    Field("is_approved", "boolean", default=False), *[f.clone() for f in sig])
    db.define_table("payroll", Field("employee", "integer"), Field("pay_month", "integer"),
                    Field("pay_year", "integer"))
    db.define_table("payroll_detail", Field("payroll_id", "integer"),
                    Field("allowance_deduction", "integer"), Field("amount", "double"))
    # نفس تعريف models/db_5_hr.py
    db.define_table("emp_advance_payment", Field("advance", "integer"), Field("employee", "integer"),
                    Field("amount", "double", default=0), Field("pay_date", "date"),
                    Field("source", length=12), Field("pay_month", "integer"),
                    Field("pay_year", "integer"), Field("period_id", "integer"),
                    Field("payroll_id", "integer"), Field("note", length=255, default=""),
                    *[f.clone() for f in sig])
    db.key_allowance_deduction.insert(name="بدل سكن", ad_type="بدل")
    db.key_allowance_deduction.insert(name=lg.DEDUCTION_NAME, ad_type="خصم")
    return db


class Base(unittest.TestCase):
    def setUp(self):
        self.db = make_db()
        self.ded = lg.deduction_item_id(self.db)

    def advance(self, employee, amount, day, paid=0, closed=False, created=datetime(2026, 1, 1)):
        return self.db.emp_advances.insert(employee=employee, amount=amount, advance_date=day,
                                           paid_amount=paid, is_closed=closed, created_on=created)

    def period(self, month, year, deductions, approved=False, modified=None):
        pid = self.db.payroll_period.insert(pay_month=month, pay_year=year, is_approved=approved,
                                            modified_on=modified or datetime(year, month, 28))
        for employee, amount in deductions.items():
            p = self.db.payroll.insert(employee=employee, pay_month=month, pay_year=year)
            self.db.payroll_detail.insert(payroll_id=p, allowance_deduction=self.ded, amount=amount)
        return self.db.payroll_period(pid)

    def adv(self, advance_id):
        return self.db.emp_advances(advance_id)

    def assert_invariant(self):
        for a in self.db(self.db.emp_advances).select():
            self.assertAlmostEqual(lg.ledger_total(self.db, a.id), a.paid_amount or 0, places=2)


class PayrollTests(Base):
    def test_fifo_and_close(self):
        old = self.advance(5, 1000, date(2026, 1, 10))
        new = self.advance(5, 3000, date(2026, 2, 1))
        res = lg.apply_period(self.db, self.period(3, 2026, {5: 1500}), TODAY)
        self.assertEqual(res["amount"], 1500)
        self.assertTrue(self.adv(old).is_closed)
        self.assertEqual(self.adv(old).closed_date, TODAY)
        self.assertEqual(self.adv(new).paid_amount, 500)
        self.assertFalse(self.adv(new).is_closed)
        self.assert_invariant()

    def test_reapprove_does_not_deduct_twice(self):
        a = self.advance(5, 3000, date(2026, 1, 10))
        p = self.period(3, 2026, {5: 1000})
        lg.apply_period(self.db, p, TODAY)
        again = lg.apply_period(self.db, p, TODAY)
        self.assertEqual(again["rows"], 0)
        self.assertEqual(self.adv(a).paid_amount, 1000)

    def test_unapprove_reverses_and_reapprove_applies(self):
        a = self.advance(5, 1000, date(2026, 1, 10))
        p = self.period(3, 2026, {5: 1000})
        lg.apply_period(self.db, p, TODAY)
        self.assertTrue(self.adv(a).is_closed)
        res = lg.reverse_period(self.db, p, TODAY)
        self.assertEqual(res["amount"], 1000)
        self.assertEqual(self.adv(a).paid_amount, 0)
        self.assertFalse(self.adv(a).is_closed)
        self.assertIsNone(self.adv(a).closed_date)
        self.assertEqual(lg.reverse_period(self.db, p, TODAY)["rows"], 0)  # لا عكس مرتين
        lg.apply_period(self.db, p, TODAY)
        self.assertEqual(self.adv(a).paid_amount, 1000)
        sources = [r.source for r in self.db(self.db.emp_advance_payment).select(orderby=self.db.emp_advance_payment.id)]
        self.assertEqual(sources, ["payroll", "reversal", "payroll"])
        self.assert_invariant()

    def test_excess_reported(self):
        self.advance(5, 300, date(2026, 1, 10))
        res = lg.apply_period(self.db, self.period(3, 2026, {5: 500, 6: 200}), TODAY)
        self.assertEqual(res["amount"], 300)
        self.assertEqual(sorted(res["excess"]), [(5, 200.0), (6, 200.0)])

    def test_recreated_period_same_month_not_deducted_twice(self):
        a = self.advance(5, 3000, date(2026, 1, 10))
        first = self.period(3, 2026, {5: 1000})
        lg.apply_period(self.db, first, TODAY)
        # فترة حُذفت (قبل منع حذف المعتمدة) ثم أُنشئت للشهر نفسه
        self.db(self.db.payroll.pay_month == 3).delete()
        first.delete_record()
        lg.apply_period(self.db, self.period(3, 2026, {5: 1000}), TODAY)
        self.assertEqual(self.adv(a).paid_amount, 1000)


class ManualTests(Base):
    def test_cash_payment_closes_and_delete_reopens(self):
        a = self.advance(5, 1000, date(2026, 1, 10))
        lg.apply_period(self.db, self.period(3, 2026, {5: 400}), TODAY)
        pid = lg.add_manual(self.db, a, 600, date(2026, 9, 20), "cash", "", TODAY, expected_paid=400)
        self.assertTrue(self.adv(a).is_closed)
        self.assertEqual(self.adv(a).closed_date, date(2026, 9, 20))
        lg.delete_manual(self.db, pid, TODAY)
        self.assertEqual(self.adv(a).paid_amount, 400)
        self.assertFalse(self.adv(a).is_closed)
        self.assert_invariant()

    def test_guards(self):
        a = self.advance(5, 1000, date(2026, 5, 1))
        cases = [
            dict(amount=1200, pay_date=TODAY, source="cash"),           # أكبر من المتبقي
            dict(amount=0, pay_date=TODAY, source="cash"),
            dict(amount=100, pay_date=date(2026, 9, 25), source="cash"),  # مستقبلي
            dict(amount=100, pay_date=date(2026, 4, 30), source="cash"),  # قبل السلفة
            dict(amount=100, pay_date=TODAY, source="settle"),          # تسوية بلا سبب
            dict(amount=100, pay_date=TODAY, source="payroll"),         # ليس يدوياً
            dict(amount=100, pay_date=TODAY, source="cash", expected_paid=50),  # تغيّر المسدد
        ]
        for case in cases:
            expected = case.pop("expected_paid", None)
            with self.assertRaises(lg.LedgerError, msg=case):
                lg.add_manual(self.db, a, today=TODAY, expected_paid=expected, **case)
        self.assertEqual(self.adv(a).paid_amount, 0)

    def test_payroll_row_not_deletable(self):
        self.advance(5, 1000, date(2026, 1, 10))
        lg.apply_period(self.db, self.period(3, 2026, {5: 400}), TODAY)
        row = self.db(self.db.emp_advance_payment).select().first()
        with self.assertRaises(lg.LedgerError):
            lg.delete_manual(self.db, row.id, TODAY)

    def test_closed_advance_rejects_payment(self):
        a = self.advance(5, 500, date(2026, 1, 10))
        lg.add_manual(self.db, a, 500, TODAY, "cash", "", TODAY)
        with self.assertRaises(lg.LedgerError):
            lg.add_manual(self.db, a, 1, TODAY, "cash", "", TODAY)


class BackfillTests(Base):
    def test_matches_legacy_paid_amounts(self):
        # حالة القاعدة المحلية: موظف 5 بسلفتين، والثانية سُجلت بعد اعتماد مارس
        a1 = self.advance(5, 1000, date(2025, 10, 10), paid=1000, closed=True)
        a2 = self.advance(5, 16000, date(2026, 5, 19), paid=4000, created=datetime(2026, 5, 21))
        a3 = self.advance(10, 4000, date(2026, 9, 22), paid=0, created=datetime(2026, 9, 22))
        self.period(3, 2026, {5: 1000}, approved=True, modified=datetime(2026, 3, 29))
        self.period(6, 2026, {5: 2000}, approved=True, modified=datetime(2026, 7, 19))
        self.period(7, 2026, {5: 2000, 10: 500}, approved=True, modified=datetime(2026, 8, 19))
        self.period(9, 2026, {5: 2000}, approved=False)
        plan = lg.ensure_backfill(self.db, TODAY)
        self.assertEqual(plan["report"]["matched"], 2)
        self.assertEqual(plan["report"]["unmatched"], 0)  # a3 أحدث من اعتماد يوليو فلم تأخذ خصمه
        self.assertEqual(self.adv(a1).paid_amount, 1000)
        self.assertEqual(self.adv(a2).paid_amount, 4000)
        self.assertEqual(lg.ledger_total(self.db, a3), 0)
        t = self.db.emp_advance_payment
        self.assertEqual([r.pay_month for r in self.db(t.advance == a2).select(orderby=t.id)], [6, 7])
        self.assertIsNone(lg.ensure_backfill(self.db, TODAY))  # مرة واحدة فقط
        self.assert_invariant()

    def test_partial_unmatched_and_manual_close(self):
        partial = self.advance(5, 3000, date(2026, 1, 1), paid=1500)   # مسير 1000 + يدوي 500
        manual = self.advance(6, 2000, date(2026, 1, 1), paid=100)     # المسير أكثر من المسدد
        waived = self.advance(7, 900, date(2026, 1, 1), paid=600, closed=True)
        self.period(3, 2026, {5: 1000, 6: 500}, approved=True)
        plan = lg.ensure_backfill(self.db, TODAY)
        self.assertEqual(plan["report"]["partial"], 2)  # partial و waived (لا مسير لها)
        self.assertEqual(plan["report"]["unmatched"], 1)
        self.assertEqual(plan["report"]["settled"], 1)
        t = self.db.emp_advance_payment
        self.assertEqual(sorted(r.source for r in self.db(t.advance == partial).select()), ["opening", "payroll"])
        self.assertEqual([r.source for r in self.db(t.advance == manual).select()], ["opening"])
        self.assertEqual(self.adv(waived).paid_amount, 900)
        self.assertTrue(self.adv(waived).is_closed)
        self.assert_invariant()

    def test_first_write_backfills_before_applying(self):
        a = self.advance(5, 3000, date(2026, 1, 1), paid=1000)
        self.period(3, 2026, {5: 1000}, approved=True)
        p4 = self.period(4, 2026, {5: 1000})
        lg.apply_period(self.db, p4, TODAY)
        self.assertEqual(self.adv(a).paid_amount, 2000)
        t = self.db.emp_advance_payment
        self.assertEqual([r.pay_month for r in self.db(t.advance == a).select(orderby=t.id)], [3, 4])
        self.assert_invariant()


if __name__ == "__main__":
    unittest.main(verbosity=1)
