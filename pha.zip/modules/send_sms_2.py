# -*- coding: utf-8 -*-
# import requests
import httpx

class SMS:
    def __init__(self):
        self.username = "zahmee"
        self.password = "987987za"
        self.sender = "EBDAE"
        self.ret = "string"
        self.url = "http://www.oursms.net/api/sendsms.php?"

    def getbalance(self)-> str :
        url = f"http://www.oursms.net/api/getbalance.php?username={self.username}&password={self.password}"
        resp = httpx.post(url)
        return resp.text

    def send(self, mobile,  mess) -> str:
        message = mess
        mobile = mobile
        m_str = (
            f"http://www.oursms.net/api/sendsms.php?username={self.username}&password={self.password}"
            f"&numbers={mobile}&sender={self.sender}&unicode=E&return={self.ret}&message={message}"
        )
        resp = httpx.post(m_str)
        return resp.text
