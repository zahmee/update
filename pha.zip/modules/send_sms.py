# -*- coding: utf-8 -*- 
import httpx

class SMS:
    def __init__(self):
        self.sender = "EBDAE"
        self.Authorization = "PsRTAlMV9OaSGo2G-6jr"

    def getbalance(self)-> str :
        Headers = { "Authorization" : "Bearer "+self.Authorization  }
        url = "https://api.oursms.com/billing/credits"
        resp = httpx.get(url, headers= Headers )
        return resp.text

    def send(self, mobile,  mess) -> str:
        Headers = { "Authorization" : "Bearer "+self.Authorization  }
        data = {
            "src": self.sender ,
            "dests": [ mobile ],
            "body": mess ,
            "priority": 0,
            "delay": 0,
            "validity": 0,
            "maxParts": 0,
            "dlr": 0,
            "prevDups": 0,
            "msgClass": "promotional"
        }
        url ="https://api.oursms.com/msgs/sms"        
        resp = httpx.post(url , json=data ,headers= Headers  )
        return resp.text
