# -*- coding: utf-8 -*-
#  type: ignore

from datetime import datetime
import api_helpers as api


@can_access(7007)
def index():
    return dict()


@can_access(7007)
def get_doc_types():
    q = db(db.key_doc_types.id > 0).select(
        db.key_doc_types.id, db.key_doc_types.name,
        orderby=db.key_doc_types.name
    )
    return response.json(api.api_ok(data=q))


@can_access(7007)
def get_docs():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( mf.doc_name LIKE %s OR mf.description LIKE %s "
                "OR CAST(mf.expiry_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])

    # فلتر نوع المستند
    if ReqVar.doc_type and ReqVar.doc_type != '' and ReqVar.doc_type != '0':
        conditions.append("( mf.doc_type = %s )")
        params.append(int(ReqVar.doc_type))

    # ترتيب
    allowed_sort_columns = {'id', 'doc_name', 'doc_type', 'expiry_date', 'created_on'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    # ترقيم
    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT mf.id, mf.doc_type, mf.doc_name, mf.description, "
        f"mf.expiry_date, mf.doc_file, mf.created_on, "
        f"dt.name AS doc_type_name "
        f"FROM my_files mf "
        f"LEFT JOIN key_doc_types dt ON dt.id = mf.doc_type "
        f"{where} ORDER BY mf.{sc} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = f"SELECT count(*) FROM my_files mf {where}"

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7007)
def new_doc():
    try:
        data = request.vars

        expiry_date = None
        if data.expiry_date and data.expiry_date != '':
            try:
                expiry_date = datetime.strptime(str(data.expiry_date), "%Y-%m-%d").date()
            except Exception:
                return response.json(api.api_error(mess="تاريخ نهاية المستند غير صحيح"))

        try:
            doc_type = int(data.doc_type)
        except (TypeError, ValueError):
            doc_type = 0
        if not doc_type or not db.key_doc_types[doc_type]:
            return response.json(api.api_error(mess="نوع المستند مطلوب"))

        doc_name = (data.doc_name or "").strip()
        if not doc_name:
            return response.json(api.api_error(mess="اسم المستند مطلوب"))

        # pass FieldStorage directly to DAL — it calls store() internally
        doc_file = data.doc_file if data.doc_file is not None and hasattr(data.doc_file, 'file') else None

        nid = db.my_files.insert(
            doc_type=doc_type,
            doc_name=doc_name,
            description=data.description or '',
            expiry_date=expiry_date,
            doc_file=doc_file,
        )
        db.commit()

        inserted = db.executesql(
            "SELECT mf.id, mf.doc_type, mf.doc_name, mf.description, "
            "mf.expiry_date, mf.doc_file, mf.created_on, "
            "dt.name AS doc_type_name "
            "FROM my_files mf LEFT JOIN key_doc_types dt ON dt.id = mf.doc_type "
            "WHERE mf.id = %s",
            placeholders=[nid], as_dict=True
        )
        return response.json(api.api_ok(data=inserted[0] if inserted else {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7007)
def update_doc():
    try:
        data = request.vars
        row = db.my_files[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        try:
            doc_type = int(data.doc_type)
        except (TypeError, ValueError):
            doc_type = 0
        if not doc_type or not db.key_doc_types[doc_type]:
            return response.json(api.api_error(mess="نوع المستند مطلوب"))

        doc_name = (data.doc_name or "").strip()
        if not doc_name:
            return response.json(api.api_error(mess="اسم المستند مطلوب"))

        row.doc_type = doc_type
        row.doc_name = doc_name
        row.description = data.description or ''

        if data.expiry_date and data.expiry_date != '':
            try:
                row.expiry_date = datetime.strptime(str(data.expiry_date), "%Y-%m-%d").date()
            except Exception:
                return response.json(api.api_error(mess="تاريخ نهاية المستند غير صحيح"))
        else:
            row.expiry_date = None

        # تحديث الملف إذا تم رفع ملف جديد
        if data.doc_file is not None and hasattr(data.doc_file, 'file'):
            row.doc_file = db.my_files.doc_file.store(data.doc_file.file, data.doc_file.filename)

        row.update_record()
        db.commit()

        updated = db.executesql(
            "SELECT mf.id, mf.doc_type, mf.doc_name, mf.description, "
            "mf.expiry_date, mf.doc_file, mf.created_on, "
            "dt.name AS doc_type_name "
            "FROM my_files mf LEFT JOIN key_doc_types dt ON dt.id = mf.doc_type "
            "WHERE mf.id = %s",
            placeholders=[data.id], as_dict=True
        )
        return response.json(api.api_ok(data=updated[0] if updated else {"id": data.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7007)
def delete_doc():
    try:
        row = db.my_files[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
