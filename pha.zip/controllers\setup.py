# -*- coding: utf-8 -*-
#  type: ignore


@can_access(9301)
def index():
    return dict()


@can_access(9301)
def unit_key():
    grid = SQLFORM.grid(
        db.key_unit,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def key_invoce_type():
    grid = SQLFORM.grid(
        db.key_invoce_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def type_key():
    grid = SQLFORM.grid(
        db.key_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def payment_method_key():
    grid = SQLFORM.grid(
        db.key_payment_method,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def sectors():
    grid = SQLFORM.grid(
        db.sectors,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
        fields=[db.sectors.id, db.sectors.sector_name, db.sectors.manager_name, db.sectors.locations_count],
    )
    return dict(grid=grid)


@can_access(9301)
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def update_items_det():
    qry = "update items_det set  item_id = (select item_id from items_main where id = items_det.item_idr )"
    data = db.executesql(qry)
    return "تمت العملية"


@can_access(9301)
def update_items_main1():
    qry = "update items_main set  vat = 0.0 where vat is null "
    data = db.executesql(qry)
    return "تمت العملية"


@can_access(9301)
def print_report():
    grid = SQLFORM.grid(
        db.print_report,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9302)
def users():
    links = [
        lambda row: A(
            I(" ", _class="far fa-key"),
            " صلاحيات المستخدم ",
            _class="btn btn-info ",
            _title="صلاحيات المستخدم",
            _href=URL("setup", "screens_rules", args=[row.id]),
        )
    ]
    grid = SQLFORM.grid(
        db.auth_user,
        links=links,
        user_signature=True,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ====================================================================
@can_access(9302)
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ===============================================
@can_access(9302)
def screens():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@can_access(9302)
def screens_rules():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    q = db.screens_rules.to_user == request.args(0)
    db.screens_rules.to_user.default = request.args(0)
    db.screens_rules.to_user.readable = False
    db.screens_rules.to_user.writable = False
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        orderby=db.screens_rules.screens,
        maxtextlengths={"screens_rules.screens": 250},
        args=request.args[:1],
    )
    return dict(grid=grid)


screens_code = [
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    {"systems": 1, "name": "الموردين - استعراض الموردين", "screen_code": 2001},
    {"systems": 1, "name": "الموردين - اضافة مورد جديد", "screen_code": 2002},
    {"systems": 1, "name": "الموردين - تعديل بيانات مورد", "screen_code": 2003},
    {"systems": 1, "name": "الموردين - حذف مورد", "screen_code": 2004},
    {"systems": 1, "name": "الموردين - اقفال مورد", "screen_code": 2005},
    {"systems": 1, "name": "الموردين - حركة مشتريات المورد", "screen_code": 2006},
    {"systems": 1, "name": "الموردين - كشف حساب مورد", "screen_code": 2106},
    {"systems": 1, "name": "الموردين - سدادات الموردين", "screen_code": 2107},
    {"systems": 1, "name": "الموردين - ارصدة الموردين", "screen_code": 2108},
    {"systems": 1, "name": "الموردين - مطابقات كشف الحساب", "screen_code": 2109},
    {"systems": 1, "name": "الموردين - فواتير مورد محدد", "screen_code": 2007},
    {"systems": 1, "name": "الموردين - طباعة مرتجع فاتورة", "screen_code": 2008},
    {"systems": 1, "name": "الموردين - اعتماد مرتجع فاتورة", "screen_code": 2009},
    {"systems": 1, "name": "الموردين - اضافة فاتورة جديدة", "screen_code": 2010},
    {"systems": 1, "name": "الموردين - استعراض فواتير التوريد", "screen_code": 2011},
    {"systems": 1, "name": "الموردين - طباعة الأصناف المدخلة", "screen_code": 2012},
    {"systems": 1, "name": "الموردين - طباعة الباركود للفاتورة", "screen_code": 2013},
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - الفواتير غير المعتمدة",
        "screen_code": 2014,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - ادخال اصناف - فاتورة مرتجع",
        "screen_code": 2015,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - اعتماد فاتورة مرتجع",
        "screen_code": 2016,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - الفواتير المعتمدة",
        "screen_code": 2017,
    },
    {"systems": 1, "name": "الاصناف - التصنيف الرئيسي", "screen_code": 3001},
    {"systems": 1, "name": "الاصناف - حركة الصنف", "screen_code": 3002},
    {
        "systems": 1,
        "name": "الاصناف - تعديل كمية صنف بين اكثر من فاتورة",
        "screen_code": 3003,
    },
    {"systems": 1, "name": "الاصناف - ادخال الاصناف حسب الفواتير", "screen_code": 3004},
    {
        "systems": 1,
        "name": "الاصناف - ادخال الاصناف حسب الفواتير - ادخال الاصناف",
        "screen_code": 3005,
    },
    {"systems": 1, "name": "الاصناف - تفاصيل الاصناف", "screen_code": 3006},
    {"systems": 1, "name": "الاصناف - عمليات على الاصناف", "screen_code": 3007},
    {"systems": 1, "name": "الاصناف - دمج صنفين مع بعضها", "screen_code": 3008},
    {
        "systems": 1,
        "name": "الاصناف - تقرير بالاصناف المقاربة على الانتهاء",
        "screen_code": 3009,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف التي بحاجة اعادة طلب",
        "screen_code": 3010,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف ذات الاعداد بالسالب",
        "screen_code": 3011,
    },
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض فاتورة", "screen_code": 4003},
    {"systems": 1, "name": "المبيعات - استعراض قائمة الفواتير", "screen_code": 4004},
    {"systems": 1, "name": "المبيعات - استعراض قائمة المرتجع", "screen_code": 4005},
    {"systems": 1, "name": "المبيعات - حذف فاتورة", "screen_code": 4006},
    {"systems": 1, "name": "الصندوق - مراقبة مصروفات الصندوق", "screen_code": 5001},
    {"systems": 1, "name": "الصندوق - اعتماد حركات الصندوق", "screen_code": 5002},
    {"systems": 1, "name": "طلبات الأصناف الجديدة", "screen_code": 6001},
    # شؤون الموظفين
    {"systems": 1, "name": "الحضور والانصراف", "screen_code": 7001},
    {"systems": 1, "name": "استعراض الموظفين", "screen_code": 7002},
    {"systems": 1, "name": "المرتبات", "screen_code": 7003},
    {"systems": 1, "name": "السلف", "screen_code": 7004},
    {"systems": 1, "name": "الإجازات", "screen_code": 7005},
    {"systems": 1, "name": "كشف الرواتب", "screen_code": 7006},
    {"systems": 1, "name": "ملفاتي", "screen_code": 7007},
    # إقفال الفترات
    {"systems": 1, "name": "إقفال الفترات", "screen_code": 8001},
    # تقارير المبيعات
    {"systems": 1, "name": "تقارير المبيعات - التقرير 1", "screen_code": 8101},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 2", "screen_code": 8102},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 3", "screen_code": 8103},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 4", "screen_code": 8104},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 5", "screen_code": 8105},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 6", "screen_code": 8106},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 7", "screen_code": 8107},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 8", "screen_code": 8108},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 10", "screen_code": 8110},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 11", "screen_code": 8111},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 12", "screen_code": 8112},
    # تقارير الأصناف
    {"systems": 1, "name": "تقارير الأصناف - التقرير 1", "screen_code": 8201},
    {"systems": 1, "name": "تقارير الأصناف - تقرير التجهيز", "screen_code": 8202},
    # الضريبة
    {"systems": 1, "name": "الضريبة - التقرير الرئيسي", "screen_code": 9001},
    {"systems": 1, "name": "الضريبة - تقرير 11", "screen_code": 9002},
    {"systems": 1, "name": "الضريبة - تقرير 12", "screen_code": 9003},
    {"systems": 1, "name": "الضريبة - تقرير 13", "screen_code": 9004},
    # زاتكا
    {"systems": 1, "name": "زاتكا - حالة الربط", "screen_code": 9101},
    {"systems": 1, "name": "زاتكا - توليد CSR وطلب CSID", "screen_code": 9102},
    {"systems": 1, "name": "زاتكا - التسجيل الإنتاجي", "screen_code": 9103},
]


#
@can_access(9302)
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@can_access(9302)
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@can_access(9301)
def important_info():
    db.important_info.logo.readable = False
    db.important_info.logo.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False,
        upload=URL('default', 'download')
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


@can_access(9301)
def important_info_2():
    db.important_info.name.readable = False
    db.important_info.name.writable = False
    db.important_info.vat.readable = False
    db.important_info.vat.writable = False
    db.important_info.tel.readable = False
    db.important_info.tel.writable = False
    db.important_info.mobile.readable = False
    db.important_info.mobile.writable = False
    db.important_info.address.readable = False
    db.important_info.address.writable = False
    db.important_info.msg1.readable = False
    db.important_info.msg1.writable = False
    db.important_info.msg2.readable = False
    db.important_info.msg2.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False,
        upload=URL('default', 'download')
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


@can_access(9301)
def t1():
    return dict()


@can_access(9301)
def util():
    return dict()


# ========================================================
@can_access(9301)
def update_crus():
    qry = "CREATE EXTENSION tablefunc;"
    data = db.executesql(qry)
    return "تمت العملية"


@can_access(9301)
def util_1():
    data = db().select(db.items_main.ALL, orderby=db.items_main.id)
    key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.item_reg:
            item_reg = row.item_reg.strip().upper()
        else:
            item_reg = row.id

        if row.item_type == None:
            item_type = key_type.id
        else:
            item_type = row.item_type
        if row.item_group == None:
            item_group = 0
        else:
            item_group = row.item_group
        if row.suppliers == None:
            suppliers = key_suppliers.id
        else:
            suppliers = row.suppliers

        name = row.name.strip().upper()
        row.update_record(
            name=name,
            item_reg=item_reg,
            flexible_price=False,
            item_type=item_type,
            item_group=item_group,
            suppliers=suppliers,
        )
    db.commit()
    redirect(URL("setup", "util"))


@can_access(9301)
def util_2():
    data = db().select(db.suppliers.ALL, orderby=db.suppliers.id)
    # key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    # key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.name:
            name = row.name.strip().upper()
        else:
            name = row.name
        if row.address:
            address = row.address.replace("|", "")
        else:
            address = ""
        if row.tel:
            tel = row.tel.replace("|", "")
        else:
            tel = ""
        if row.note:
            note = row.note.replace("|", "")
        else:
            note = ""
        if row.bank_account:
            bank_account = row.bank_account.replace("|", "")
        else:
            bank_account = ""

        if row.stoped:
            stoped = row.stoped
        else:
            stoped = False

        row.update_record(
            name=name,
            address=address,
            tel=tel,
            note=note,
            bank_account=bank_account,
            stoped=stoped,
        )
    db.commit()
    redirect(URL("setup", "util"))
#===============================================
@can_access(9301)
def csr_config():
    return dict(csr=[])


@can_access(9301)
def git_csr_config():
    q = db(db.csr_config.id > 0).select().first()
    if q:
        q.otp = ""
        return response.json(q)
    else:
        return response.json(
            {
                "otp": "",
                "serial_number": "",
                "common_name": "",
                "organization_name": "",
                "organization_identifier": "",
                "organization_unit_name": "1",
                "country_name": "SA",
                "invoice_type": "1100",
                "location_address": "",
                "business_category": "",
                "address_city_name": "",
                "address_street_name": "",
                "address_postal_zone": "",
                "address_building_number": "",
                "address_neighborhood": "",
                "company_id": "",
                "environment": "nonproduction",
                "api_site": "http://localhost:8011",
                "privatekey": "",
                "csr": "",
                "egs_uuid": "",
                "ccsid_requestid": "",
                "ccsid_binarysecuritytoken": "",
                "ccsid_secret": "",
                "pcsid_requestid": "",
                "pcsid_binarysecuritytoken": "",
                "pcsid_secret": "",
                "icv": 1,
                "pih": "",
            }
        )


@can_access(9301)
def update_csr_config():
    try:
        data = request.vars
        q = db(db.csr_config.id > 0).select().first()
        if q:
            q.update_record(
                otp=data.otp,
                environment = data.environment ,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.organization_name if "common_name" in data else "",
                organization_name=(
                    data.organization_name if "organization_name" in data else ""
                ),
                organization_identifier=(
                    data.organization_identifier
                    if "organization_identifier" in data
                    else ""
                ),
                organization_unit_name=(
                    data.organization_unit_name
                    if "organization_unit_name" in data
                    else ""
                ),
                country_name="SA",
                invoice_type="1100",
                location_address=(
                    data.location_address if "location_address" in data else ""
                ),
                business_category=(
                    data.business_category if "business_category" in data else ""
                ),
                address_city_name=(
                    data.address_city_name if "address_city_name" in data else ""
                ),
                address_street_name=(
                    data.address_street_name if "address_street_name" in data else ""
                ),
                address_postal_zone=(
                    data.address_postal_zone if "address_postal_zone" in data else ""
                ),
                address_building_number=(
                    data.address_building_number
                    if "address_building_number" in data
                    else ""
                ),
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=(
                    data.address_neighborhood if "address_neighborhood" in data else ""
                ),
                privatekey=data.privatekey if "privatekey" in data else privatekey,
                csr=data.csr if "csr" in data else csr,
                csr_src=data.csr_src if "csr_src" in data else csr_src,
                egs_uuid=data.egs_uuid if "egs_uuid" in data else egs_uuid,
                ccsid_requestid=(
                    data.ccsid_requestid
                    if "ccsid_requestid" in data
                    else ccsid_requestid
                ),
                ccsid_binarysecuritytoken=(
                    data.ccsid_binarysecuritytoken
                    if "ccsid_binarysecuritytoken" in data
                    else ccsid_binarysecuritytoken
                ),
                ccsid_secret=(
                    data.ccsid_secret if "ccsid_secret" in data else ccsid_secret
                ),
                pcsid_requestid=(
                    data.pcsid_requestid
                    if "pcsid_requestid" in data
                    else pcsid_requestid
                ),
                pcsid_binarysecuritytoken=(
                    data.pcsid_binarysecuritytoken
                    if "pcsid_binarysecuritytoken" in data
                    else pcsid_binarysecuritytoken
                ),
                pcsid_secret=(
                    data.pcsid_secret if "pcsid_secret" in data else pcsid_secret
                ),
                api_site=data.api_site if "api_site" in data else "https://api.aseerkayan.net/",
            )
            db.commit()
        else:
            db.csr_config.validate_and_insert(
                otp=data.otp,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.common_name if "common_name" in data else "",
                organization_name=data.organization_name if "organization_name" in data else "",
                organization_identifier=data.organization_identifier if "organization_identifier" in data else "",
                organization_unit_name=data.organization_unit_name if "organization_unit_name" in data else "",
                country_name="SA",
                invoice_type="1100",
                location_address=data.location_address if "location_address" in data else "",
                business_category=data.business_category if "business_category" in data else "",
                address_city_name=data.address_city_name if "address_city_name" in data else "",    
                address_street_name=data.address_street_name if "address_street_name" in data else "",
                address_postal_zone=data.address_postal_zone if "address_postal_zone" in data else "",
                address_building_number=data.address_building_number if "address_building_number" in data else "",
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=data.address_neighborhood if "address_neighborhood" in data else "",
                privatekey=data.privatekey if "privatekey" in data else "",
                csr=data.csr if "csr" in data else "" ,
                csr_src=data.csr_src if "csr_src" in data else "",
                egs_uuid=data.egs_uuid if "egs_uuid" in data else "",
                ccsid_requestid=data.ccsid_requestid if "ccsid_requestid" in data else "",
                ccsid_binarysecuritytoken=data.ccsid_binarysecuritytoken if "ccsid_binarysecuritytoken" in data else "",
                ccsid_secret= data.ccsid_secret if "ccsid_secret" in data else ""  ,
                pcsid_requestid=data.pcsid_requestid if "pcsid_requestid" in data else "",
                pcsid_binarysecuritytoken=  data.pcsid_binarysecuritytoken if "pcsid_binarysecuritytoken" in data else "",
                pcsid_secret= data.pcsid_secret if "pcsid_secret" in data else "" ,

            )
            db.commit()
            # imp_info = db(db.important_info.id > 0).select().first()
            # imp_info.update_record(
            #     name=data.common_name,
            #     vat=data.organization_identifier,
            # )
            # db.commit()
        return response.json("0")
    except Exception as e:
        db.rollback()
        ret = {"mess": str(e)}
        return response.json(ret)


@can_access(9301)
def doc_types():
    grid = SQLFORM.grid(
        db.key_doc_types,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def job_titles():
    grid = SQLFORM.grid(
        db.key_job_titles,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def nationalities():
    grid = SQLFORM.grid(
        db.key_nationalities,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def advance_types():
    grid = SQLFORM.grid(
        db.key_advance_types,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def allowance_deduction():
    grid = SQLFORM.grid(
        db.key_allowance_deduction,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def seed_data():
    return dict()


@can_access(9301)
def run_seed_data():
    """API: تشغيل التهيئة وإرجاع النتائج"""
    results = []

    # 1) الترميزات الأساسية
    if db(db.key_unit.id > 0).isempty():
        for n in ["حبة", "علبة", "كرتون", "ملل", "شنطة"]:
            db.key_unit.insert(name=n)
        results.append("الوحدات")

    if db(db.key_payment_method.id > 0).isempty():
        for n in ["نقدي", "شبكة الكترونية", "آجل", "تحويل في الحساب", "شيك", "خصم من الرصيد"]:
            db.key_payment_method.insert(name=n)
        results.append("طرق الدفع")

    if db(db.key_cust.id > 0).isempty():
        for n in ["عميل عام", "عميل جمعية البر"]:
            db.key_cust.insert(name=n)
        results.append("أنواع العملاء")

    if db(db.auth_group.id > 0).isempty():
        for r in ["admin", "user", "account", "report"]:
            db.auth_group.insert(role=r)
        results.append("مجموعات الصلاحيات")

    if db(db.auth_user.id > 0).isempty():
        password = db.auth_user.password.validate("admin")[0]
        user_id = db.auth_user.insert(
            first_name="admin", last_name="user", password=password, email="admin@user.com"
        )
        results.append("المستخدم الافتراضي (admin)")
        if db(db.auth_membership.id > 0).isempty():
            db.auth_membership.insert(
                user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
            )
            results.append("ربط المستخدم بالصلاحيات")

    if db(db.key_type.id > 0).isempty():
        for n in ["ادوات تجميل", "ادوات طبية", "ادوية", "اطفال", "اسنان"]:
            db.key_type.insert(name=n)
        results.append("التصنيفات")

    if db(db.key_payment_type.id > 0).isempty():
        for n in ["سداد مستحقات", "خصم مكتسب", "مرتجعات/فاتورة", "مرتجعات/اصناف"]:
            db.key_payment_type.insert(name=n)
        results.append("أنواع سداد المورد")

    if db(db.key_invoce_type.id > 0).isempty():
        for n in ["مشتريات", "تعويض", "هدايا"]:
            db.key_invoce_type.insert(name=n)
        results.append("تصنيف الفواتير")

    # 2) البيانات الافتتاحية للأعمال
    if db(db.suppliers.id > 0).isempty():
        db.suppliers.insert(name="مورد عام - مورد نقدي")
        results.append("المورد الافتراضي")

    if db(db.items_main.id > 0).isempty():
        db.items_main.insert(
            item_id="1", name="هلل", item_reg="1", flexible_price=True, public_price=0.01
        )
        results.append("الصنف الافتراضي")

    if db(db.customers.id > 0).isempty():
        db.customers.insert(name="عميل عام - نفدي", mobile="0")
        results.append("العميل الافتراضي")

    # 3) بيانات التشغيل
    if db(db.systems.id > 0).isempty():
        db.systems.insert(name="نظام الصيدلية")
        results.append("النظام")

    if db(db.csr_config.id > 0).isempty():
        db.csr_config.insert(otp="123456")
        results.append("إعدادات ZATCA")

    # 4) بيانات المنشأة
    if db(db.important_info.id > 0).isempty():
        db.important_info.insert(
            name="نظام ؟؟؟؟؟؟؟؟؟", vat="0", tel="0",
            mobile="05", address="العنوان", msg1="----", msg2="----",
        )
        results.append("المعلومات الرسمية")

    # 5) ترميزات الموارد البشرية
    if db(db.key_doc_types.id > 0).isempty():
        for n in ["اوراق المؤسسة الرسمية", "اقامة", "جواز سفر", "عقد عمل", "ترخيص مزاولة مهنة"]:
            db.key_doc_types.insert(name=n)
        results.append("أنواع المستندات")

    if db(db.key_job_titles.id > 0).isempty():
        for n in ["صيدلي", "فني صيدلة", "محاسب", "مدير", "بائع"]:
            db.key_job_titles.insert(name=n)
        results.append("المسميات الوظيفية")

    if db(db.key_nationalities.id > 0).isempty():
        for n in ["سعودي", "مصري", "يمني", "سوداني", "هندي", "باكستاني", "بنغلاديشي", "فلبيني"]:
            db.key_nationalities.insert(name=n)
        results.append("الجنسيات")

    if db(db.key_advance_types.id > 0).isempty():
        for n in ["سلفة راتب", "سلفة شخصية", "سلفة طارئة"]:
            db.key_advance_types.insert(name=n)
        results.append("أنواع السلف")

    if db(db.key_allowance_deduction.id > 0).isempty():
        for n, t in [("بدل سكن", "بدل"), ("بدل نقل", "بدل"), ("بدل إضافي", "بدل"),
                     ("خصم غياب", "خصم"), ("خصم تأخير", "خصم"), ("خصم سلفة", "خصم")]:
            db.key_allowance_deduction.insert(name=n, ad_type=t)
        results.append("البدلات والخصومات")

    if db(db.key_emp_status.id > 0).isempty():
        for n in ["على رأس العمل", "في إجازة", "منقطع", "مفصول"]:
            db.key_emp_status.insert(name=n)
        results.append("حالات الموظفين")

    db.commit()
    return response.json(dict(results=results))


@can_access(9301)
def reset_zatca():
    """حذف بيانات الربط بالهيئة مع الإبقاء على بيانات المؤسسة"""
    try:
        confirm = request.vars.get("confirm")
        if confirm != "DELETE_ZATCA":
            return response.json(dict(ok=False, mess="تأكيد غير صحيح"))

        q = db(db.csr_config.id > 0).select().first()
        if not q:
            return response.json(dict(ok=False, mess="لا توجد بيانات ربط لحذفها"))

        q.update_record(
            otp="",
            privatekey="",
            csr="",
            csr_src="",
            egs_uuid="",
            ccsid_requestid="",
            ccsid_binarysecuritytoken="",
            ccsid_secret="",
            pcsid_requestid="",
            pcsid_binarysecuritytoken="",
            pcsid_secret="",
            icv=1,
            pih="",
            api_site="http://localhost:8011",
            environment="nonproduction",
        )
        db.commit()
        return response.json(dict(ok=True, mess="تم حذف بيانات الربط بالهيئة بنجاح"))
    except Exception as e:
        return response.json(dict(ok=False, mess=str(e)))


# ============================================================================
#         إدارة المستخدمين والصلاحيات - Users Management (Vue.js)
# ============================================================================

@can_access(9302)
def users_management():
    return dict()


@can_access(9302)
def get_users():
    """جلب المستخدمين مع pagination وبحث وفلتر الحالة"""
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    search = request.vars.SearchText or ""
    status_filter = request.vars.status_filter or "all"
    offset = pg * rc

    conditions = []
    params = []
    if search.strip():
        pattern = "%" + search.strip() + "%"
        conditions.append(
            "(first_name LIKE %s OR last_name LIKE %s OR email LIKE %s)"
        )
        params.extend([pattern, pattern, pattern])

    if status_filter == "active":
        conditions.append("(registration_key IS NULL OR registration_key = '')")
    elif status_filter == "disabled":
        conditions.append("(registration_key IS NOT NULL AND registration_key != '')")

    where = ""
    if conditions:
        where = "WHERE " + " AND ".join(conditions)

    sql = (
        "SELECT id, first_name, last_name, email, registration_key, "
        "COALESCE(NULLIF(first_name || ' ' || last_name, ' '), first_name, last_name, email) as full_name "
        "FROM auth_user " + where + " ORDER BY id LIMIT %s OFFSET %s"
    )
    params.extend([rc, offset])
    rows = db.executesql(sql, placeholders=params, as_dict=True)

    count_sql = "SELECT COUNT(*) FROM auth_user " + where
    if conditions:
        count_params = params[:-2]
        count_rows = db.executesql(count_sql, placeholders=count_params, as_dict=False)
    else:
        count_rows = db.executesql(count_sql, as_dict=False)
    count = count_rows[0][0]

    return response.json({"data": rows, "count": count})


@can_access(9302)
def save_user():
    """إضافة أو تعديل مستخدم"""
    try:
        data = request.vars
        user_id = data.get("id")
        if user_id:
            row = db.auth_user[user_id]
            if row:
                row.update_record(
                    first_name=data.first_name,
                    last_name=data.last_name,
                    email=data.email,
                )
                if data.password and str(data.password).strip():
                    row.update_record(password=db.auth_user.password.validate(data.password)[0])
        else:
            password = db.auth_user.password.validate(data.password or "5445Za@")[0]
            user_id = db.auth_user.insert(
                first_name=data.first_name,
                last_name=data.last_name,
                email=data.email,
                password=password,
            )
        db.commit()
        return response.json({"err": 0, "id": user_id})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def delete_user():
    """حذف/تعطيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if row:
            row.update_record(registration_key="disabled")
            db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def enable_user():
    """تفعيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if row:
            row.update_record(registration_key=None)
            db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def get_groups():
    """جلب كل المجموعات"""
    rows = db(db.auth_group.id > 0).select(db.auth_group.id, db.auth_group.role, orderby=db.auth_group.role)
    return response.json(rows.as_list())


@can_access(9302)
def get_user_membership():
    """جلب عضويات المستخدم"""
    user_id = request.args(0)
    sql = (
        "SELECT am.id, am.user_id, am.group_id, ag.role "
        "FROM auth_membership am "
        "JOIN auth_group ag ON ag.id = am.group_id "
        "WHERE am.user_id = %s"
    )
    rows = db.executesql(sql, placeholders=[user_id], as_dict=True)
    return response.json(rows)


@can_access(9302)
def save_membership():
    """حفظ أو حذف عضوية"""
    try:
        data = request.vars
        user_id = data.get("user_id")
        group_id = data.get("group_id")
        checked = data.get("checked") == "true"

        if checked:
            existing = db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).select().first()
            if not existing:
                db.auth_membership.insert(user_id=user_id, group_id=group_id)
        else:
            db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).delete()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ===================== API for screens_rules Vue.js =====================

@can_access(9302)
def get_screens_rules():
    """جلب صلاحيات الشاشات للمستخدم مع pagination"""
    user_id = request.args(0)
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    offset = pg * rc
    sql = (
        "SELECT sr.id, sr.screens, sr.can_log_in, sr.can_add, sr.can_edit, sr.can_delete, "
        "s.name as screen_name, s.screen_code "
        "FROM screens_rules sr "
        "JOIN screens s ON s.id = sr.screens "
        "WHERE sr.to_user = %s "
        "ORDER BY s.screen_code "
        "LIMIT %s OFFSET %s"
    )
    rows = db.executesql(sql, placeholders=[user_id, rc, offset], as_dict=True)
    count_sql = "SELECT COUNT(*) FROM screens_rules WHERE to_user = %s"
    count = db.executesql(count_sql, placeholders=[user_id])[0][0]
    return response.json({"data": rows, "count": count})


@can_access(9302)
def get_available_screens():
    """جلب الشاشات غير المضافة للمستخدم"""
    user_id = request.args(0)
    sql = (
        "SELECT s.id, s.name, s.screen_code "
        "FROM screens s "
        "WHERE s.id NOT IN ("
        "   SELECT screens FROM screens_rules WHERE to_user = %s"
        ") ORDER BY s.screen_code"
    )
    rows = db.executesql(sql, placeholders=[user_id], as_dict=True)
    return response.json(rows)


@can_access(9302)
def save_rule():
    """حفظ أو تحديث صلاحية"""
    try:
        data = request.vars
        rule_id = data.get("id")
        if rule_id:
            row = db.screens_rules[rule_id]
            if row:
                row.update_record(
                    can_log_in=data.get("can_log_in") == "true",
                    can_add=data.get("can_add") == "true",
                    can_edit=data.get("can_edit") == "true",
                    can_delete=data.get("can_delete") == "true",
                )
        else:
            db.screens_rules.insert(
                to_user=int(data.get("to_user")),
                screens=int(data.get("screens")),
                can_log_in=data.get("can_log_in") == "true",
                can_add=data.get("can_add") == "true",
                can_edit=data.get("can_edit") == "true",
                can_delete=data.get("can_delete") == "true",
            )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def delete_rule():
    """حذف صلاحية"""
    try:
        db(db.screens_rules.id == request.args(0)).delete()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ===================== API grant_all / delete_all for Vue.js =====================

@can_access(9302)
def api_grant_all():
    """منح جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=True, can_add=True, can_edit=True, can_delete=True
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=True,
                    can_add=True,
                    can_edit=True,
                    can_delete=True,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def api_delete_all():
    """حذف جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=False, can_add=False, can_edit=False, can_delete=False
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=False,
                    can_add=False,
                    can_edit=False,
                    can_delete=False,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
