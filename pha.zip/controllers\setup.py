# -*- coding: utf-8 -*-
#  type: ignore


@auth.requires_membership("admin")
def index():
    return dict()


@auth.requires_membership("admin")
def unit_key():
    grid = SQLFORM.grid(
        db.key_unit,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def key_invoce_type():
    grid = SQLFORM.grid(
        db.key_invoce_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def type_key():
    grid = SQLFORM.grid(
        db.key_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def payment_method_key():
    grid = SQLFORM.grid(
        db.key_payment_method,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def sectors():
    grid = SQLFORM.grid(
        db.sectors,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
        fields=[db.sectors.id, db.sectors.sector_name, db.sectors.manager_name, db.sectors.locations_count],
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def update_items_det():
    qry = "update items_det set  item_id = (select item_id from items_main where id = items_det.item_idr )"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def update_items_main1():
    qry = "update items_main set  vat = 0.0 where vat is null "
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def print_report():
    grid = SQLFORM.grid(
        db.print_report,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def users():
    links = [
        lambda row: A(
            I(" ", _class="far fa-key"),
            " صلاحيات المستخدم ",
            _class="btn btn-info ",
            _title="صلاحيات المستخدم",
            _href=URL("setup", "screens_rules", args=[row.id]),
        )
    ]
    grid = SQLFORM.grid(
        db.auth_user,
        links=links,
        user_signature=True,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ====================================================================
@auth.requires(auth.has_membership("admin"))
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ===============================================
@auth.requires(auth.has_membership("admin"))
def screens():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@auth.requires(auth.has_membership("admin"))
def screens_rules():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    q = db.screens_rules.to_user == request.args(0)
    db.screens_rules.to_user.default = request.args(0)
    db.screens_rules.to_user.readable = False
    db.screens_rules.to_user.writable = False
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        orderby=db.screens_rules.screens,
        maxtextlengths={"screens_rules.screens": 250},
        args=request.args[:1],
    )
    return dict(grid=grid)


screens_code = [
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    {"systems": 1, "name": "الموردين - استعراض الموردين", "screen_code": 2001},
    {"systems": 1, "name": "الموردين - اضافة مورد جديد", "screen_code": 2002},
    {"systems": 1, "name": "الموردين - تعديل بيانات مورد", "screen_code": 2003},
    {"systems": 1, "name": "الموردين - حذف مورد", "screen_code": 2004},
    {"systems": 1, "name": "الموردين - اقفال مورد", "screen_code": 2005},
    {"systems": 1, "name": "الموردين - حركة مشتريات المورد", "screen_code": 2006},
    {"systems": 1, "name": "الموردين - كشف حساب مورد", "screen_code": 2106},
    {"systems": 1, "name": "الموردين - سدادات الموردين", "screen_code": 2107},
    {"systems": 1, "name": "الموردين - ارصدة الموردين", "screen_code": 2108},
    {"systems": 1, "name": "الموردين - مطابقات كشف الحساب", "screen_code": 2109},
    {"systems": 1, "name": "الموردين - فواتير مورد محدد", "screen_code": 2007},
    {"systems": 1, "name": "الموردين - طباعة مرتجع فاتورة", "screen_code": 2008},
    {"systems": 1, "name": "الموردين - اعتماد مرتجع فاتورة", "screen_code": 2009},
    {"systems": 1, "name": "الموردين - اضافة فاتورة جديدة", "screen_code": 2010},
    {"systems": 1, "name": "الموردين - استعراض فواتير التوريد", "screen_code": 2011},
    {"systems": 1, "name": "الموردين - طباعة الأصناف المدخلة", "screen_code": 2012},
    {"systems": 1, "name": "الموردين - طباعة الباركود للفاتورة", "screen_code": 2013},
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - الفواتير غير المعتمدة",
        "screen_code": 2014,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - ادخال اصناف - فاتورة مرتجع",
        "screen_code": 2015,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - اعتماد فاتورة مرتجع",
        "screen_code": 2016,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - الفواتير المعتمدة",
        "screen_code": 2017,
    },
    {"systems": 1, "name": "الاصناف - التصنيف الرئيسي", "screen_code": 3001},
    {"systems": 1, "name": "الاصناف - حركة الصنف", "screen_code": 3002},
    {
        "systems": 1,
        "name": "الاصناف - تعديل كمية صنف بين اكثر من فاتورة",
        "screen_code": 3003,
    },
    {"systems": 1, "name": "الاصناف - ادخال الاصناف حسب الفواتير", "screen_code": 3004},
    {
        "systems": 1,
        "name": "الاصناف - ادخال الاصناف حسب الفواتير - ادخال الاصناف",
        "screen_code": 3005,
    },
    {"systems": 1, "name": "الاصناف - تفاصيل الاصناف", "screen_code": 3006},
    {"systems": 1, "name": "الاصناف - عمليات على الاصناف", "screen_code": 3007},
    {"systems": 1, "name": "الاصناف - دمج صنفين مع بعضها", "screen_code": 3008},
    {
        "systems": 1,
        "name": "الاصناف - تقرير بالاصناف المقاربة على الانتهاء",
        "screen_code": 3009,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف التي بحاجة اعادة طلب",
        "screen_code": 3010,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف ذات الاعداد بالسالب",
        "screen_code": 3011,
    },
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض فاتورة", "screen_code": 4003},
]


#
@auth.requires(auth.has_membership("admin"))
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@auth.requires(auth.has_membership("admin"))
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@auth.requires(auth.has_membership("admin"))
def important_info():
    db.important_info.logo.readable = False
    db.important_info.logo.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


@auth.requires(auth.has_membership("admin"))
def important_info_2():
    db.important_info.name.readable = False
    db.important_info.name.writable = False
    db.important_info.vat.readable = False
    db.important_info.vat.writable = False
    db.important_info.tel.readable = False
    db.important_info.tel.writable = False
    db.important_info.mobile.readable = False
    db.important_info.mobile.writable = False
    db.important_info.address.readable = False
    db.important_info.address.writable = False
    db.important_info.msg1.readable = False
    db.important_info.msg1.writable = False
    db.important_info.msg2.readable = False
    db.important_info.msg2.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


def t1():
    return dict()


@auth.requires(auth.has_membership("admin"))
def util():
    return dict()


# ========================================================
@auth.requires_membership("admin")
def update_crus():
    qry = "CREATE EXTENSION tablefunc;"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires(auth.has_membership("admin"))
def util_1():
    data = db().select(db.items_main.ALL, orderby=db.items_main.id)
    key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.item_reg:
            item_reg = row.item_reg.strip().upper()
        else:
            item_reg = row.id

        if row.item_type == None:
            item_type = key_type.id
        else:
            item_type = row.item_type
        if row.item_group == None:
            item_group = 0
        else:
            item_group = row.item_group
        if row.suppliers == None:
            suppliers = key_suppliers.id
        else:
            suppliers = row.suppliers

        name = row.name.strip().upper()
        row.update_record(
            name=name,
            item_reg=item_reg,
            flexible_price=False,
            item_type=item_type,
            item_group=item_group,
            suppliers=suppliers,
        )
    db.commit()
    redirect(URL("setup", "util"))


@auth.requires(auth.has_membership("admin"))
def util_2():
    data = db().select(db.suppliers.ALL, orderby=db.suppliers.id)
    # key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    # key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.name:
            name = row.name.strip().upper()
        else:
            name = row.name
        if row.address:
            address = row.address.replace("|", "")
        else:
            address = ""
        if row.tel:
            tel = row.tel.replace("|", "")
        else:
            tel = ""
        if row.note:
            note = row.note.replace("|", "")
        else:
            note = ""
        if row.bank_account:
            bank_account = row.bank_account.replace("|", "")
        else:
            bank_account = ""

        if row.stoped:
            stoped = row.stoped
        else:
            stoped = False

        row.update_record(
            name=name,
            address=address,
            tel=tel,
            note=note,
            bank_account=bank_account,
            stoped=stoped,
        )
    db.commit()
    redirect(URL("setup", "util"))
#===============================================
@auth.requires(auth.has_membership("admin"))
def csr_config():
    return dict(csr=[])


@auth.requires(auth.has_membership("admin"))
def git_csr_config():
    q = db(db.csr_config.id > 0).select().first()
    if q:
        q.otp = ""
        return response.json(q)
    else:
        return response.json(
            {
                "otp": "",
                "serial_number": "",
                "common_name": "",
                "organization_name": "",
                "organization_identifier": "",
                "organization_unit_name": "1",
                "country_name": "SA",
                "invoice_type": "",
                "location_address": "",
                "business_category": "",
                "address_city_name": "",
                "address_street_name": "",
                "address_postal_zone": "",
                "address_building_number": "",
                "address_neighborhood":"",
                "CompanyID": "",
                "company_id": "",
            }
        )


@auth.requires(auth.has_membership("admin"))
def update_csr_config():
    try:
        data = request.vars
        q = db(db.csr_config.id > 0).select().first()
        if q:
            q.update_record(
                otp=data.otp,
                environment = data.environment ,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.organization_name if "common_name" in data else "",
                organization_name=(
                    data.organization_name if "organization_name" in data else ""
                ),
                organization_identifier=(
                    data.organization_identifier
                    if "organization_identifier" in data
                    else ""
                ),
                organization_unit_name=(
                    data.organization_unit_name
                    if "organization_unit_name" in data
                    else ""
                ),
                country_name="SA",
                invoice_type="1100",
                location_address=(
                    data.location_address if "location_address" in data else ""
                ),
                business_category=(
                    data.business_category if "business_category" in data else ""
                ),
                address_city_name=(
                    data.address_city_name if "address_city_name" in data else ""
                ),
                address_street_name=(
                    data.address_street_name if "address_street_name" in data else ""
                ),
                address_postal_zone=(
                    data.address_postal_zone if "address_postal_zone" in data else ""
                ),
                address_building_number=(
                    data.address_building_number
                    if "address_building_number" in data
                    else ""
                ),
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=(
                    data.address_neighborhood if "address_neighborhood" in data else ""
                ),
                privatekey=data.privatekey if "privatekey" in data else privatekey,
                csr=data.csr if "csr" in data else csr,
                csr_src=data.csr_src if "csr_src" in data else csr_src,
                egs_uuid=data.egs_uuid if "egs_uuid" in data else egs_uuid,
                ccsid_requestid=(
                    data.ccsid_requestid
                    if "ccsid_requestid" in data
                    else ccsid_requestid
                ),
                ccsid_binarysecuritytoken=(
                    data.ccsid_binarysecuritytoken
                    if "ccsid_binarysecuritytoken" in data
                    else ccsid_binarysecuritytoken
                ),
                ccsid_secret=(
                    data.ccsid_secret if "ccsid_secret" in data else ccsid_secret
                ),
                pcsid_requestid=(
                    data.pcsid_requestid
                    if "pcsid_requestid" in data
                    else pcsid_requestid
                ),
                pcsid_binarysecuritytoken=(
                    data.pcsid_binarysecuritytoken
                    if "pcsid_binarysecuritytoken" in data
                    else pcsid_binarysecuritytoken
                ),
                pcsid_secret=(
                    data.pcsid_secret if "pcsid_secret" in data else pcsid_secret
                ),
                api_site=data.api_site if "api_site" in data else "https://api.aseerkayan.net/",
            )
            db.commit()
        else:
            db.csr_config.validate_and_insert(
                otp=data.otp,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.common_name if "common_name" in data else "",
                organization_name=data.organization_name if "organization_name" in data else "",
                organization_identifier=data.organization_identifier if "organization_identifier" in data else "",
                organization_unit_name=data.organization_unit_name if "organization_unit_name" in data else "",
                country_name="SA",
                invoice_type="1100",
                location_address=data.location_address if "location_address" in data else "",
                business_category=data.business_category if "business_category" in data else "",
                address_city_name=data.address_city_name if "address_city_name" in data else "",    
                address_street_name=data.address_street_name if "address_street_name" in data else "",
                address_postal_zone=data.address_postal_zone if "address_postal_zone" in data else "",
                address_building_number=data.address_building_number if "address_building_number" in data else "",
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=data.address_neighborhood if "address_neighborhood" in data else "",
                privatekey=data.privatekey if "privatekey" in data else "",
                csr=data.csr if "csr" in data else "" ,
                csr_src=data.csr_src if "csr_src" in data else "",
                egs_uuid=data.egs_uuid if "egs_uuid" in data else "",
                ccsid_requestid=data.ccsid_requestid if "ccsid_requestid" in data else "",
                ccsid_binarysecuritytoken=data.ccsid_binarysecuritytoken if "ccsid_binarysecuritytoken" in data else "",
                ccsid_secret= data.ccsid_secret if "ccsid_secret" in data else ""  ,
                pcsid_requestid=data.pcsid_requestid if "pcsid_requestid" in data else "",
                pcsid_binarysecuritytoken=  data.pcsid_binarysecuritytoken if "pcsid_binarysecuritytoken" in data else "",
                pcsid_secret= data.pcsid_secret if "pcsid_secret" in data else "" ,

            )
            db.commit()
            # imp_info = db(db.important_info.id > 0).select().first()
            # imp_info.update_record(
            #     name=data.common_name,
            #     vat=data.organization_identifier,
            # )
            # db.commit()
        return response.json("0")
    except Exception as e:
        db.rollback()
        ret = {"mess": str(e)}
        return response.json(ret)


@auth.requires_membership("admin")
def doc_types():
    grid = SQLFORM.grid(
        db.key_doc_types,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def job_titles():
    grid = SQLFORM.grid(
        db.key_job_titles,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def nationalities():
    grid = SQLFORM.grid(
        db.key_nationalities,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def advance_types():
    grid = SQLFORM.grid(
        db.key_advance_types,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def allowance_deduction():
    grid = SQLFORM.grid(
        db.key_allowance_deduction,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=True,
        showbuttontext=True,
    )
    return dict(grid=grid)
