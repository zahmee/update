# -*- coding: utf-8 -*-
#  type: ignore

import gluon.contrib.simplejson
import math
from datetime import datetime


# =======================================================================
@can_access(3007)
def items_qry():
    return dict()


# ========================================================================
#          عمليات شاشة ادخال الاصناف من فواتير التوريد
# ========================================================================


@can_access(3005)
def getit():
    qry = "select * from items_main  where item_id = %s"
    data = db.executesql(qry, placeholders=[str(request.vars.itid)], as_dict=True)
    if data:
        qry = (
            "SELECT public_price FROM items_det where item_idr=%s"
            " ORDER BY id DESC LIMIT 5"
        )
        data2 = db.executesql(qry, placeholders=[str(data[0]["id"])], as_dict=True)
        data[0]["old_public_price"] = data2
        if data2:
            data[0]["old_public_price"] = data2
        else:
            data[0]["old_public_price"] = [{"public_price": 0}]
        qry = (
            "SELECT buy_price FROM items_det where item_idr=%s"
            " ORDER BY id DESC LIMIT 5"
        )
        data2 = db.executesql(qry, placeholders=[str(data[0]["id"])], as_dict=True)
        if data2:
            data[0]["old_buy_price"] = data2
        else:
            data[0]["old_buy_price"] = [{"buy_price": 0}]
        qry = (
            "SELECT vat FROM items_det where item_idr=%s"
            " ORDER BY id DESC LIMIT 1"
        )
        data3 = db.executesql(qry, placeholders=[str(data[0]["id"])], as_dict=True)
        if data3:
            data[0]["last_vat"] = data3[0]["vat"]
        else:
            data[0]["last_vat"] = 0.15
        return response.json(data)
    else:
        return response.json([])


@can_access(3002)
def gethistory():
    qry = "select * from items_main  where item_id = %s"
    main_items = db.executesql(qry, placeholders=[str(request.vars.itid)], as_dict=True)
    qry = (
        "SELECT * FROM items_det where item_idr = %s"
        " order by id desc limit 10"
    )
    det_items = db.executesql(qry, placeholders=[str(main_items[0]["id"])], as_dict=True)
    for i in det_items:
        sp_info = db.suppliers_bills[i["supplier_inv"]]
        sp = db.suppliers[sp_info.supplier]
        i["supplier_inv"] = sp.name
    qry = (
        "SELECT max(buy_price) FROM items_det where item_idr = %s"
        " and buy_price!=public_price "
    )
    max_items = db.executesql(qry, placeholders=[str(main_items[0]["id"])], as_dict=True)
    qry = "SELECT min(buy_price) FROM items_det where item_idr = %s"
    min_items = db.executesql(qry, placeholders=[str(main_items[0]["id"])], as_dict=True)
    data = {"det": det_items, "max": max_items, "min": min_items}
    return response.json(data)
    # --------------------------------------


@can_access(3005, 4001, 4002)
def search_item():
    search = request.vars.itid
    srh = search.split()
    data = []
    if len(srh) == 1:
        qry = (
            "select * from items_main  where LOWER(name) like %s"
            " order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=['%' + str(request.vars.itid.lower()) + '%'], as_dict=True)
    elif len(srh) == 2:
        qry = (
            "select * from items_main  where LOWER(name) like %s"
            " and LOWER(name) like %s"
            "   order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=['%' + str(srh[0].lower()) + '%', '%' + str(srh[1].lower()) + '%'], as_dict=True)
    return response.json(data)


@can_access(3005)
def addit():
    try:
        itm = request.vars.itm
        it_inv = db.suppliers_bills(itm["supplier_inv"])
        if it_inv == None:
            return response.json({"mess": "هذه الفاتورة غير صحيحة"})
        if it_inv.bill_confirmation == True:
            return response.json({"mess": "فاتورة مغلقة"})
        buy_price = itm["buy_price"]
        supplier_inv = itm["supplier_inv"]
        item_idr = itm["item_idr"]
        item_id = itm["item_id"]
        public_price = itm["public_price"]
        expiration_date = itm["expiration_date"]
        inv_price = float(itm["inv_price"])
        vat = float(itm["vat"])
        items_count = itm["items_count"]
        return_count = itm["return_count"]
        vat_in_public_price = itm["vat_in_public_price"]
        if (buy_price is None) or (buy_price == "0"):
            buy_price = float(inv_price) / float(items_count)
        vat_price = 0.0
        # ---------------- حساب الضريبة للصنف
        if vat > 0:
            vat_price = round(inv_price - (math.fabs(float(inv_price)) / (vat + 1)), 2)
        else:
            vat_price = 0
        if itm["editRow"] == False:
            # insert() بدل validate_and_insert(): الأخير يرفض الحقول writable=False
            # (item_idr, free_quantity, discount_rate, discount) كـ "invalid" في pydal الحديثة.
            # البيانات هنا مضبوطة من الخادم، فلا حاجة لتحقق النماذج.
            new_id = db.items_det.insert(
                supplier_inv=supplier_inv,
                item_idr=item_idr,
                item_id=item_id,
                public_price=math.fabs(float(public_price)),
                items_count=math.fabs(float(items_count)),
                buy_price=math.fabs(float(buy_price)),
                expiration_date=expiration_date,
                inv_price=math.fabs(float(inv_price)),
                vat=math.fabs(float(vat)),
                return_count=math.fabs(float(return_count)),
                quantity=math.fabs(float(items_count)),
                free_quantity=0,
                discount_rate=0,
                discount=0,
                vat_price=vat_price,
                vat_in_public_price=vat_in_public_price,
            )
        else:
            items_det = db.items_det[itm["id"]]
            items_det.supplier_inv = supplier_inv
            items_det.item_idr = item_idr
            items_det.item_id = item_id
            items_det.public_price = math.fabs(float(public_price))
            items_det.items_count = math.fabs(float(items_count))
            items_det.buy_price = math.fabs(float(buy_price))
            items_det.expiration_date = expiration_date
            items_det.inv_price = math.fabs(float(inv_price))
            items_det.vat = math.fabs(float(vat))
            items_det.return_count = math.fabs(float(return_count))
            items_det.quantity = math.fabs(float(items_count))
            items_det.free_quantity = 0
            items_det.discount_rate = 0
            items_det.discount = 0
            items_det.vat_price = vat_price
            items_det.vat_in_public_price = vat_in_public_price
            items_det.update_record()
            new_id = items_det.id
        db.commit()
        ret = {"id": str(new_id)}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


@can_access(3005)
def delitm():
    try:
        row = db.items_det[request.args(0)]
        it_inv = db.suppliers_bills(row.supplier_inv)
        if it_inv == None:
            return response.json({"mess": "هذه الفاتورة غير صحيحة"})
        if it_inv.bill_confirmation == True:
            return response.json({"mess": "فاتورة مغلقة"})
        row.delete_record()
        db.commit()
        ret = {"mess": "0"}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


@can_access(3005)
def get_inv_items():
    inv = int(request.args(0))
    itm = db(db.items_det.supplier_inv == inv).select(orderby=db.items_det.id)
    for r in itm:
        r["name"] = db.items_main[r.item_idr].name
        if r.vat is None:
            r.vat = 0
        if r.return_count is None:
            r.return_count = 0
    return response.json(itm)


# <=============================    end   ===============================>


@can_access(3001)
def items_edit():
    itm = db.items_det(request.args(0))
    inv = db.suppliers_bills(itm.supplier_inv)
    if auth.has_membership("admin"):
        response.title = ""
        db.items_det.supplier_inv.readable = False
        db.items_det.item_chked.readable = False
        db.items_det.supplier_inv.writable = False
        db.items_det.item_chked.writable = False
        form = SQLFORM(db.items_det, record=itm)
        if form.process().accepted:
            response.flash = "تمت عملية الحفظ بنجاح"
            redirect(URL("items", "de_it"))
        elif form.errors:
            response.flash = "يوجد خطأ في عملية الحفظ"
        return dict(form=form)
    elif inv.bill_confirmation == False:
        response.title = ""
        db.items_det.supplier_inv.readable = False
        db.items_det.item_chked.readable = False
        db.items_det.supplier_inv.writable = False
        db.items_det.item_chked.writable = False
        form = SQLFORM(db.items_det, deletable=False, record=itm)
        if form.process().accepted:
            response.flash = "تمت عملية الحفظ بنجاح"
            redirect(URL("items", "de_it"))
        elif form.errors:
            response.flash = "يوجد خطأ في عملية الحفظ"
        return dict(form=form)
    else:
        redirect(URL("items", "de_it"))


@can_access(3002)
def rep_byid():
    return dict()


@can_access(3002)
def it_prt_by_item():
    q1 = db(db.items_main.item_id == request.args(0))
    try:
        itm1 = db(db.items_main.item_id == request.args(0)).select().first()
        itm2 = db(db.items_det.item_idr == itm1.id).select().last()
        db1 = db(
            (db.items_det.item_id == db.items_main.item_id)
            & (db.items_det.supplier_inv == itm2.supplier_inv)
            & (db.items_det.id == itm2.id)
        ).select(
            db.items_det.item_id,
            db.items_det.id,
            db.items_main.name,
            db.items_det.items_count,
            db.items_det.public_price,
        )
        return str(db1)
    except Exception as e:
        return str("رقم الصنف المدخل خطأ ، الرجاء ادخال الرقم الدولي ")
    # q1 = db(db.items_main.item_id == request.args(0))
    #
    #    db1= db((db.items_det.item_id==db.items_main.item_id) & (db.items_det.supplier_inv ==request.args(0)) ).select(
    #    db.items_det.item_id,
    #    db.items_det.id,
    #    db.items_main.name,
    #    db.items_det.items_count,
    #    db.items_det.public_price,
    #    db.items_det.vat ,
    #    db.items_det.vat_in_public_price ,
    #    db.items_det.quantity ,
    #    orderby=db.items_det.id
    #    )
    # for r in db1 :
    #    r.items_det.public_price = round((r.items_det.public_price * r.items_det.vat)+r.items_det.public_price , 2)
    #    r.items_det.items_count = r.items_det.quantity
    #    if r.items_det.vat_in_public_price == True :
    #        new_price = round((r.items_det.public_price / (r.items_det.vat+1)) , 2)
    #        r.items_det.public_price = new_price
    # return str(db1)


# ===============================================================================================


@can_access(3005, 4001, 4002)
def search_item_det():
    search = request.vars.itid
    qry = (
        "select * from items_det  where item_idr = %s"
        " order by id desc limit 1"
    )
    data = db.executesql(qry, placeholders=[str(request.vars.itid)], as_dict=True)
    return response.json(data)


@can_access(8201)
def it_rep1_count():
    inv = request.args(0)
    """
    sum = 0.0
    sum2 = 0.0
    sum3_1 = 0.0
    sum3_2 = 0.0
    itm = db(db.items_det.supplier_inv ==inv ).select()
    for i in itm :
        sum = sum + (i.inv_price or 0 ) 
        sum2 = sum2 + (i.public_price * i.quantity ) 
        sum3_1 = sum3_1 + (i.public_price * i.quantity * (i.vat or 0) ) 
        sum3_2 = sum3_2 + (i.inv_price * (i.vat or 0) ) 
    row = db.suppliers_bills[inv]
    row.update_record(
                bill_selling = sum2 , 
                bill_profit_ratio = round(( (sum2-sum)/sum  )*100 ,2) ,
                bill_profit = sum2-sum 
                )
    db.commit()
    """
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv=%s  )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv=%s  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/sum(inv_price))*100 from items_det where supplier_inv=%s  )) "
        " where id=%s"
    )
    db.executesql(qry, placeholders=[inv, inv, inv, inv])
    redirect(URL("suppliers", "supply_bills"))


@can_access(3003)
def qur():
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv=suppliers_bills.id   )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv=suppliers_bills.id  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/sum(inv_price))*100 from items_det where supplier_inv=suppliers_bills.id  )) "
    )
    db.executesql(qry)
    return "ok"


@can_access(3008)
def items_merge():
    return dict()


@can_access(3008)
def items_merge_a():
    itm_1 = request.args(0)
    itm_2 = request.args(1)
    new_itm = db.items_main[itm_1]
    old_itm = db.items_main[itm_2]
    qry = "update items_det set item_idr = %s where  item_idr = %s"
    db.executesql(qry, placeholders=[itm_1, itm_2])
    old_itm.delete_record()
    db.commit()
    mess = " تم دمج الصنفين مع بعضها "
    return dict(mess=mess)


@can_access(3008)
def items_unmerged():
    return dict()


@can_access(3011)
def negative_repair():
    qry = (
        "select  item_idr from items_det "
        " where  items_count <0 "
        " group by item_idr ORDER BY item_idr "
    )
    # print "========================="
    data = db.executesql(qry, as_dict=True)
    sum = db.items_det.items_count.sum()
    for row in data:
        # if row['item_idr']==2112 :
        sum_row_0 = (
            db(
                (db.items_det.item_idr == row["item_idr"])
                & (db.items_det.items_count < 0)
            )
            .select(sum)
            .first()[sum]
        )
        sum_row_1 = (
            db(
                (db.items_det.item_idr == row["item_idr"])
                & (db.items_det.items_count > 0)
            )
            .select(sum)
            .first()[sum]
        )
        # print sum_row_0
        # print sum_row_1
        if sum_row_1 >= (sum_row_0 * -1):
            for itm in db(db.items_det.item_idr == row["item_idr"]).select(
                orderby=db.items_det.id
            ):
                if itm.items_count == 0:
                    continue
                elif itm.items_count < 0:
                    # print "*<0"
                    itm.items_count = 0
                elif (itm.items_count > 0) & (sum_row_0 < 0):
                    # print ">0"
                    if itm.items_count >= (sum_row_0 * -1):
                        # print "---->0"
                        # print "*************"
                        # print sum_row_0
                        save_count = itm.items_count
                        itm.items_count = itm.items_count + sum_row_0
                        sum_row_0 = sum_row_0 + save_count
                        # print sum_row_0
                        # print "*************"
                itm.update_record()
        # else :
        # print "((" + str(row['item_idr'] ) +"))"
        db.commit()
        # print str(itm.id )+"--" + str(itm.items_count) +"==>" +str(sum_row_0)

    # print "========================="
    """while sum_row_0 != 0 :
                    sum_row_0 = sum_row_0 +1
                    #print '0000'
    """
    return "ok"


@can_access(3011)
def negative_items():
    qry = (
        "select  item_idr,sum(items_count) as sum ,"
        " (select name from items_main  where items_main.id= item_idr ) as name "
        " from items_det   "
        " group by item_idr  "
        " having sum(items_count) <0   "
        " ORDER BY item_idr   "
    )
    data = db.executesql(qry, as_dict=True)
    for i in data:
        itm = db.items_main(i["item_idr"])
        i["type"] = itm["item_type"].name
    return dict(data=data)


@can_access(3003)
def adjust_quantity():
    return dict()


@can_access(3002)
def get_last_10():
    # qry2 = db(db.items_det.item_idr== request.args(0) ).select(orderby=~db.items_det.id , limitby=(0,5)).first()
    qry = (
        "select * from items_det  where item_idr = %s"
        " and items_count!=0 order by id desc"
    )
    data = db.executesql(qry, placeholders=[str(request.args(0))], as_dict=True)
    # app_json = json.dumps(qry2)
    return response.json(data)


import json


@can_access(3003)
def save_adjust_quantity():
    try:
        itm = request.vars.itm
        total_0 = 0.0
        total_1 = 0.0
        for i in itm:
            total_0 = total_0 + (db.items_det[i["id"]].items_count)
            total_1 = total_1 + float(i["items_count"] or 0)
        if total_0 != total_0:
            return response.json({"mess": 1})
        for i in itm:
            itm_d = db.items_det[i["id"]]
            itm_d.items_count = float(i["items_count"] or 0)
            itm_d.update_record()
        db.commit()
        return response.json({"mess": 0})
    except Exception as e:
        db.rollback()
        # print (e)
        response.json({"mess": e})


@can_access(3005)
def renameitm():
    itm_d = db.items_main[request.args(0)]
    if itm_d:
        itm_d.name = request.vars.new
        itm_d.update_record()
        return "ok"
    else:
        itm = db(db.items_main.item_id == request.args(0)).select().first()
        itm_d = db.items_main[itm.id]
        itm_d.name = request.vars.new
        itm_d.update_record()
        return "ok"


@can_access(3003)
def items_sales():
    return dict()


@can_access(3012)
def stop_items():
    return dict()


@can_access(3012)
def rep_bystopdays():
    qry = (
        "select DISTINCT "
        "item_idr as id ,  "
        "(select name from items_main where id = itd.item_idr ) as name , "
        "(select item_type from items_main where id = itd.item_idr ) as item_type , "
        "( select name from key_type where key_type.id= "
        "(select item_type from items_main where id = itd.item_idr ) "
        ")as item_type_n  , "
        "sum(items_count) as sum "
        "from items_det as itd "
        "where "
        "itd.item_idr not in ( "
        "select DISTINCT( (select item_idr from items_det where items_det.id=invoice_details.item_number ) )   "
        "from invoice_details where created_on > ( current_date - %s ) ) "
        "and created_on < ( current_date - %s ) "
        "group by item_idr "
        "having  sum(items_count) > 0  "
    )
    qs = db.executesql(qry, placeholders=[int(request.args(0)), int(request.args(0))], as_dict=True)
    for r in qs:
        r["sum"] = round(r["sum"], 3)
    return response.json(qs)
    # ------------------------------------------------------------
    """
    qry = (
        " select id , name ,item_type , "
        " ( select name from key_type where key_type.id=items_main.item_type  )  as item_type_n "
        " from items_main  "
        " where id not in ( "
        " select DISTINCT( (select item_idr from items_det where items_det.id=invoice_details.item_number ) )   "
		" from invoice_details where created_on > ( current_date - "+str(request.args(0))+" ) ) "
		" and created_on < ( current_date - "+str(request.args(0))+" ) "
    )
    mydata = []
    for r in qs :
        qry =(
            " select sum(items_count) from items_det where "
            " item_idr= "+str(r['id']) 
        )
        sum1 = db.executesql(qry, as_dict=True)
        if sum1[0]['sum'] :
            if int(sum1[0]['sum']) > 0    :
                mydata.append(
                {'id': r['id'] , 'name': r['name'] ,
                'item_type':  r['item_type'] , 'sum':sum1[0]['sum'] ,
                'item_type_n':r['item_type_n'] } 
                )
        #r['sum'] = sum1[0]
    """


# ------------------------------------------------------


@can_access(3007)
def editcountItem():
    update_qry = "update items_det set items_count =0 where item_idr = %s"
    db.executesql(update_qry, placeholders=[request.args(0)])
    db.commit()
    redirect(URL("items", "negative_items"))


@can_access(3005)
def sels_item():
    qry = (
        "select * from invoice_details  where item_number IN  "
        " ( select id from items_det where item_idr= %s  )"
        " order by id desc limit 100 "
    )
    data1 = db.executesql(qry, placeholders=[str(request.args(0))], as_dict=True)
    qry = (
        "select * from inv_return_details  where item_number IN  "
        " ( select id from items_det where item_idr= %s  )"
        " order by id desc limit 100 "
    )
    data2 = db.executesql(qry, placeholders=[str(request.args(0))], as_dict=True)
    data = {"data1": data1, "data2": data2}
    return response.json(data)


@can_access(3003)
def quarterly_sales():
    item_id = int(request.args(0))
    import datetime as dt

    today = request.now.date()
    current_year = today.year
    prev_year = current_year - 1

    item_det_ids = [r.id for r in db(db.items_det.item_idr == item_id).select(db.items_det.id)]

    if not item_det_ids:
        return response.json({"quarters": [], "prev_year_total": 0, "prev_year_count": 0, "prev_year": prev_year})

    current_quarter = (today.month - 1) // 3 + 1

    quarters_data = []
    for i in range(4):
        q = current_quarter - i
        y = current_year
        while q <= 0:
            q += 4
            y -= 1

        start_month = (q - 1) * 3 + 1
        q_start = dt.date(y, start_month, 1)
        if q == 4:
            q_end = dt.date(y + 1, 1, 1) - dt.timedelta(days=1)
        else:
            q_end = dt.date(y, q * 3 + 1, 1) - dt.timedelta(days=1)

        qry = (
            "SELECT COALESCE(SUM(total::numeric), 0) as total_amount,"
            " COALESCE(SUM(item_count::numeric), 0) as total_count"
            " FROM invoice_details"
            " WHERE item_number = ANY(%s)"
            " AND created_on >= %s AND created_on <= %s"
        )
        row = db.executesql(qry, placeholders=[item_det_ids, str(q_start), str(q_end) + ' 23:59:59'], as_dict=True)[0]

        quarters_data.append({
            "label": "الربع %d - %d" % (q, y),
            "total_amount": float(row["total_amount"]),
            "total_count": int(row["total_count"]),
        })

    prev_start = dt.date(prev_year, 1, 1)
    prev_end = dt.date(prev_year, 12, 31)

    qry = (
        "SELECT COALESCE(SUM(total::numeric), 0) as total_amount,"
        " COALESCE(SUM(item_count::numeric), 0) as total_count"
        " FROM invoice_details"
        " WHERE item_number = ANY(%s)"
        " AND created_on >= %s AND created_on <= %s"
    )
    prev_row = db.executesql(qry, placeholders=[item_det_ids, str(prev_start), str(prev_end) + ' 23:59:59'], as_dict=True)[0]

    return response.json({
        "quarters": list(reversed(quarters_data)),
        "prev_year_total": float(prev_row["total_amount"]),
        "prev_year_count": int(prev_row["total_count"]),
        "prev_year": prev_year,
    })


@can_access(3003)
def supplier_items_quarterly():
    supplier_id = int(request.args(0))
    page = int(request.vars.get("page", 0))
    page_size = 20
    import datetime as dt

    today = request.now.date()
    current_year = today.year
    prev_year = current_year - 1

    total_items = db(db.items_main.suppliers == supplier_id).count()

    items = db(db.items_main.suppliers == supplier_id).select(
        db.items_main.id, db.items_main.name, db.items_main.item_id,
        limitby=(page * page_size, (page + 1) * page_size),
        orderby=db.items_main.name,
    )
    item_ids = [r.id for r in items]

    # Calculate last 4 quarters
    current_quarter = (today.month - 1) // 3 + 1
    quarters_info = []
    for i in range(4):
        q = current_quarter - i
        y = current_year
        while q <= 0:
            q += 4
            y -= 1
        quarters_info.append((q, y))
    quarters_info = list(reversed(quarters_info))

    if not item_ids:
        return response.json({
            "items": [], "total_items": total_items,
            "page": page, "page_size": page_size,
            "prev_year": prev_year,
            "quarters_labels": ["\u0627\u0644\u0631\u0628\u0639 %d - %d" % (q, y) for q, y in quarters_info],
        })

    # Map items_det -> items_main
    det_rows = db(db.items_det.item_idr.belongs(item_ids)).select(db.items_det.id, db.items_det.item_idr)
    det_to_main = {}
    all_det_ids = []
    for r in det_rows:
        det_to_main[r.id] = r.item_idr
        all_det_ids.append(r.id)

    # Init sales structure
    sales_data = {}
    for iid in item_ids:
        sales_data[iid] = {"prev": {"total_amount": 0, "total_count": 0}}
        for qi in quarters_info:
            sales_data[iid][qi] = {"total_amount": 0, "total_count": 0}

    if all_det_ids:
        eq, ey = quarters_info[0]
        earliest_q_start = dt.date(ey, (eq - 1) * 3 + 1, 1)
        prev_year_start = dt.date(prev_year, 1, 1)
        earliest_date = min(earliest_q_start, prev_year_start)

        qry = (
            "SELECT item_number,"
            " EXTRACT(QUARTER FROM created_on)::int as q,"
            " EXTRACT(YEAR FROM created_on)::int as y,"
            " COALESCE(SUM(total::numeric), 0) as total_amount,"
            " COALESCE(SUM(item_count::numeric), 0) as total_count"
            " FROM invoice_details"
            " WHERE item_number = ANY(%s)"
            " AND created_on >= %s"
            " GROUP BY item_number, q, y"
        )
        rows = db.executesql(qry, placeholders=[all_det_ids, str(earliest_date)], as_dict=True)

        for row in rows:
            main_id = det_to_main.get(row["item_number"])
            if not main_id or main_id not in sales_data:
                continue
            rq, ry = int(row["q"]), int(row["y"])
            amount = float(row["total_amount"])
            count = int(row["total_count"])
            if (rq, ry) in sales_data[main_id]:
                sales_data[main_id][(rq, ry)]["total_amount"] += amount
                sales_data[main_id][(rq, ry)]["total_count"] += count
            if ry == prev_year:
                sales_data[main_id]["prev"]["total_amount"] += amount
                sales_data[main_id]["prev"]["total_count"] += count

    result_items = []
    for item in items:
        sd = sales_data[item.id]
        result_items.append({
            "id": item.id,
            "name": item.name,
            "item_id": item.item_id,
            "quarters": [
                {"label": "\u0627\u0644\u0631\u0628\u0639 %d - %d" % (q, y),
                 "total_amount": sd[(q, y)]["total_amount"],
                 "total_count": sd[(q, y)]["total_count"]}
                for q, y in quarters_info
            ],
            "prev_year_total": sd["prev"]["total_amount"],
            "prev_year_count": sd["prev"]["total_count"],
        })

    return response.json({
        "items": result_items,
        "total_items": total_items,
        "page": page,
        "page_size": page_size,
        "prev_year": prev_year,
        "quarters_labels": ["\u0627\u0644\u0631\u0628\u0639 %d - %d" % (q, y) for q, y in quarters_info],
    })


# =======================================================================
#          شاشة حركة الأصناف
# =======================================================================

@can_access(3007)
def items_movement():
    return dict()


@can_access(3002)
def items_movement_api():
    """API: جلب جميع حركات صنف معين من كل الجداول"""
    item_id = request.vars.item_id
    if not item_id:
        return response.json({"error": "يجب تحديد الصنف"})

    try:
        item_id = int(item_id)
    except (ValueError, TypeError):
        return response.json({"error": "رقم صنف غير صحيح"})

    # التحقق من وجود الصنف
    item = db.items_main(item_id)
    if not item:
        return response.json({"error": "الصنف غير موجود"})

    date_from = request.vars.date_from or None
    date_to = request.vars.date_to or None
    move_type = request.vars.move_type or ""

    # بناء الاستعلامات حسب نوع الحركة
    queries = []
    placeholders = []

    # 1) شراء (وارد)
    if move_type in ("", "شراء"):
        queries.append(
            "SELECT 'شراء'::text as move_type, sb.bill_date::timestamp as move_date,"
            " id.quantity::double precision as qty_in, 0::double precision as qty_out,"
            " id.buy_price::double precision as unit_price, s.name::text as reference,"
            " sb.bill_no::text as ref_no"
            " FROM items_det id"
            " JOIN suppliers_bills sb ON id.supplier_inv = sb.id"
            " JOIN suppliers s ON sb.supplier = s.id"
            " WHERE id.item_idr = %s AND sb.bill_confirmation = 'T'"
        )
        placeholders.append(item_id)

    # 2) بيع (صادر)
    if move_type in ("", "بيع"):
        queries.append(
            "SELECT 'بيع'::text as move_type, ivd.created_on::timestamp as move_date,"
            " 0::double precision as qty_in, ivd.item_count::double precision as qty_out,"
            " ivd.amount::double precision as unit_price, 'فاتورة بيع'::text as reference,"
            " im.id::text as ref_no"
            " FROM invoice_details ivd"
            " JOIN invoice_master im ON ivd.uuid = im.uuid"
            " WHERE ivd.item_number IN (SELECT id FROM items_det WHERE item_idr = %s)"
        )
        placeholders.append(item_id)

    # 3) مرتجع بيع (وارد)
    if move_type in ("", "مرتجع بيع"):
        queries.append(
            "SELECT 'مرتجع بيع'::text as move_type, ird.created_on::timestamp as move_date,"
            " ird.item_count::double precision as qty_in, 0::double precision as qty_out,"
            " ird.amount::double precision as unit_price, 'مرتجع بيع'::text as reference,"
            " irm.id::text as ref_no"
            " FROM inv_return_details ird"
            " JOIN inv_return_master irm ON ird.uuid = irm.uuid"
            " WHERE ird.item_number IN (SELECT id FROM items_det WHERE item_idr = %s)"
        )
        placeholders.append(item_id)

    # 4) مرتجع توريد (صادر)
    if move_type in ("", "مرتجع توريد"):
        queries.append(
            "SELECT 'مرتجع توريد'::text as move_type, rs.ret_date::timestamp as move_date,"
            " 0::double precision as qty_in, rsd.item_count::double precision as qty_out,"
            " rsd.inv_price::double precision as unit_price, s.name::text as reference,"
            " rs.id::text as ref_no"
            " FROM returned_supply_det rsd"
            " JOIN returned_supply rs ON rsd.returned_supply = rs.id"
            " JOIN suppliers s ON rs.supplier = s.id"
            " WHERE rsd.item_id::integer IN (SELECT id FROM items_det WHERE item_idr = %s)"
            " AND rs.admin_accept = 'T'"
        )
        placeholders.append(item_id)

    # 5) تالف (صادر)
    if move_type in ("", "تالف"):
        queries.append(
            "SELECT 'تالف'::text as move_type, dr.damage_date::timestamp as move_date,"
            " 0::double precision as qty_in, drd.item_count::double precision as qty_out,"
            " 0::double precision as unit_price, 'تقرير تالف'::text as reference,"
            " dr.id::text as ref_no"
            " FROM damage_report_det drd"
            " JOIN damage_report dr ON drd.damage_report = dr.id"
            " WHERE drd.item_id::integer IN (SELECT id FROM items_det WHERE item_idr = %s)"
            " AND dr.admin_accept = 'T'"
        )
        placeholders.append(item_id)

    if not queries:
        return response.json({
            "movements": [],
            "summary": {"total_in": 0, "total_out": 0, "balance": 0},
            "item_info": {"id": item.id, "item_id": item.item_id, "name": item.name},
        })

    # تجميع الاستعلامات بـ UNION ALL مع فلتر التاريخ
    union_sql = " UNION ALL ".join(queries)
    full_sql = "SELECT * FROM (" + union_sql + ") sub WHERE 1=1"

    # إضافة شروط التاريخ
    all_placeholders = list(placeholders)
    if date_from and date_to:
        full_sql += " AND sub.move_date >= %s::timestamp AND sub.move_date <= %s::timestamp"
        all_placeholders.extend([str(date_from) + ' 00:00:00', str(date_to) + ' 23:59:59'])
    elif date_from:
        full_sql += " AND sub.move_date >= %s::timestamp"
        all_placeholders.append(str(date_from) + ' 00:00:00')
    elif date_to:
        full_sql += " AND sub.move_date <= %s::timestamp"
        all_placeholders.append(str(date_to) + ' 23:59:59')

    full_sql += " ORDER BY sub.move_date ASC"

    try:
        rows = db.executesql(full_sql, placeholders=all_placeholders, as_dict=True)
    except Exception as e:
        return response.json({"error": "خطأ في الاستعلام: " + str(e)})

    # حساب الرصيد التراكمي
    total_in = 0
    total_out = 0
    balance = 0
    movements = []
    for row in rows:
        qi = float(row["qty_in"] or 0)
        qo = float(row["qty_out"] or 0)
        total_in += qi
        total_out += qo
        balance += qi - qo
        movements.append({
            "move_type": row["move_type"],
            "move_date": str(row["move_date"])[:16] if row["move_date"] else "",
            "qty_in": qi,
            "qty_out": qo,
            "unit_price": float(row["unit_price"] or 0),
            "reference": row["reference"] or "",
            "ref_no": row["ref_no"] or "",
            "balance": round(balance, 2),
        })

    # عكس الترتيب لعرض الأحدث أولاً
    movements.reverse()

    return response.json({
        "movements": movements,
        "summary": {
            "total_in": round(total_in, 2),
            "total_out": round(total_out, 2),
            "balance": round(balance, 2),
        },
        "item_info": {
            "id": item.id,
            "item_id": item.item_id,
            "name": item.name,
            "public_price": float(item.public_price or 0),
        },
    })
