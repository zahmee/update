# -*- coding: utf-8 -*-
#  type: ignore
"""
طبقة مصادقة الوكيل الخارجي (AI Agent)
External AI Agent authentication layer.

تُستخدم بدلاً من can_access للواجهات التي يستدعيها وكيل خارجي (Hermes ... إلخ).
المصادقة بمفتاح ثابت يُرسل في Authorization header:

    Authorization: Bearer <api_key>

أو كحقل api_key ضمن الطلب. المفتاح مُعرّف في appconfig.ini تحت [agent] api_key.
"""

import hmac
import re
import api_helpers as api


def agent_valid_mobile(value):
    """تحقق من صيغة جوال سعودي (يقبل فراغ)."""
    if not value:
        return True
    return bool(re.match(r"^(05\d{8}|9665\d{8}|\+9665\d{8})$", value))


def agent_normalize_mobile(value):
    """توحيد صيغة الجوال إلى 05XXXXXXXX قدر الإمكان."""
    v = (value or "").strip().replace(" ", "")
    if v.startswith("+966"):
        v = "0" + v[4:]
    elif v.startswith("966"):
        v = "0" + v[3:]
    return v


def _extract_key():
    """استخراج المفتاح من الهيدر (Bearer) أو من vars."""
    provided = request.env.http_authorization or request.vars.api_key or ""
    provided = provided.strip()
    if provided.lower().startswith("bearer "):
        provided = provided[7:].strip()
    return provided


def require_agent_key(func):
    """
    ديكوريتر: يتحقق من مفتاح الوكيل قبل تنفيذ الدالة.
    يرجع 401 عند الفشل و 503 إذا لم يُهيّأ المفتاح أصلاً.
    """
    def wrapper(*args, **kwargs):
        expected = agent_api_key or ""
        if not expected:
            response.status = 503
            return response.json(api.api_error(mess="واجهة الوكيل غير مُفعّلة"))
        provided = _extract_key()
        if not provided or not hmac.compare_digest(str(provided), str(expected)):
            response.status = 401
            return response.json(api.api_error(mess="مفتاح المصادقة غير صحيح"))
        return func(*args, **kwargs)

    return wrapper
