(function () {
  'use strict';
  var urls = window.SUPPLIER_MAINTENANCE;
  if (!urls || !document.getElementById('supplier-maintenance')) return;

  function normalize(value) {
    return String(value || '').toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي')
      .replace(/[٠-٩]/g, function (digit) { return String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)); });
  }

  new Vue({
    el: '#supplier-maintenance',
    data: {
      loaded: false, loadingSummary: false, loadingPreview: false, applying: false,
      canEdit: urls.canEdit, error: '', receipt: null, operations: [], activeKey: '',
      summary: {total: 0, cleanup: 0, missing: 0, duplicate_groups: 0, counts: {}},
      preview: null, selectedIds: [], query: '', page: 1, pageSize: 25
    },
    computed: {
      busy: function () { return this.loadingSummary || this.loadingPreview || this.applying; },
      cleanupTools: function () { return this.operations.filter(function (tool) { return tool.kind === 'cleanup'; }); },
      reviewTools: function () { return this.operations.filter(function (tool) { return tool.kind === 'review'; }); },
      activeTool: function () {
        var key = this.activeKey;
        return this.operations.find(function (tool) { return tool.key === key; });
      },
      filteredRecords: function () {
        var words = normalize(this.query).trim().split(/\s+/).filter(Boolean);
        return ((this.preview && this.preview.records) || []).filter(function (record) {
          var text = normalize(record.name + ' ' + record.id);
          return words.every(function (word) { return text.indexOf(word) !== -1; });
        });
      },
      pageRecords: function () { return this.filteredRecords.slice((this.page - 1) * this.pageSize, this.page * this.pageSize); },
      totalPages: function () { return Math.max(1, Math.ceil(this.filteredRecords.length / this.pageSize)); },
      allFilteredSelected: function () {
        var selected = new Set(this.selectedIds);
        return this.filteredRecords.length > 0 && this.filteredRecords.every(function (record) { return selected.has(record.id); });
      }
    },
    watch: {query: function () { this.page = 1; }},
    created: function () { this.loadSummary(); },
    methods: {
      number: function (value) { return new Intl.NumberFormat('ar-SA').format(value || 0); },
      displayValue: function (value) {
        if (value == null) return 'غير مسجل';
        if (value === '') return 'فارغ';
        if (!String(value).trim()) return 'مسافات أو أسطر فارغة';
        // Boundary marks make a whitespace-only change visible in the preview.
        return '«' + value + '»';
      },
      loadSummary: async function () {
        this.loadingSummary = true;
        try {
          var result = await Api.get(urls.summary);
          if (!Api.isOk(result)) { this.error = Api.getError(result); return false; }
          this.summary = Api.getData(result);
          this.operations = this.summary.operations;
          this.canEdit = this.summary.can_edit;
          this.loaded = true;
          return true;
        } finally { this.loadingSummary = false; }
      },
      refresh: async function () {
        if (this.busy) return;
        this.error = ''; this.receipt = null; this.selectedIds = []; this.preview = null;
        if (await this.loadSummary() && this.activeKey) await this.openOperation(this.activeKey);
      },
      openOperation: async function (key, keepReceipt) {
        if (this.busy) return;
        this.activeKey = key; this.preview = null; this.selectedIds = []; this.query = ''; this.page = 1;
        this.error = ''; if (!keepReceipt) this.receipt = null;
        this.loadingPreview = true;
        try {
          var body = new FormData(); body.append('operation', key);
          var result = await Api.post(urls.preview, body);
          if (!Api.isOk(result)) { this.error = Api.getError(result); return; }
          this.preview = Api.getData(result);
          if (window.matchMedia('(max-width: 991px)').matches) this.scrollResults();
        } finally { this.loadingPreview = false; }
      },
      scrollResults: function () {
        this.$nextTick(function () {
          this.$refs.results.scrollIntoView({block: 'start', behavior: 'instant'});
        });
      },
      movePage: function (page) {
        if (this.busy || page < 1 || page > this.totalPages) return;
        this.page = page;
        this.scrollResults();
      },
      toggleFiltered: function () {
        if (this.busy || !this.canEdit || !this.preview || !this.preview.token) return;
        var selected = new Set(this.selectedIds);
        var deselect = this.allFilteredSelected;
        this.filteredRecords.forEach(function (record) {
          if (deselect) selected.delete(record.id); else selected.add(record.id);
        });
        this.selectedIds = Array.from(selected);
      },
      applySelected: async function () {
        if (this.busy || !this.canEdit || !this.selectedIds.length || !this.preview || !this.preview.token) return;
        this.applying = true;
        var selected = this.selectedIds.slice();
        var key = this.activeKey;
        var success = false;
        try {
          var confirm = await Swal.fire({
            title: 'تطبيق التغييرات المحددة؟',
            text: this.activeTool.title + ' على ' + this.number(selected.length) + ' مورد، وفق القيم التي عاينتها.',
            icon: 'question', showCancelButton: true, confirmButtonText: 'نعم، تطبيق',
            cancelButtonText: 'العودة للمعاينة', confirmButtonColor: '#12514c', focusCancel: true
          });
          if (!confirm.isConfirmed) return;
          this.error = ''; this.receipt = null;
          var body = new FormData();
          body.append('token', this.preview.token); body.append('ids', JSON.stringify(selected));
          var result = await Api.post(urls.apply, body);
          // Re-preview uncertain requests rather than submitting them twice.
          this.preview.token = null;
          if (!Api.isOk(result)) { this.error = Api.getError(result); return; }
          this.receipt = Api.getData(result); this.selectedIds = []; success = true;
        } finally { this.applying = false; }
        if (success && await this.loadSummary()) await this.openOperation(key, true);
      }
    }
  });
})();
