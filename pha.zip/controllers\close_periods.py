# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# تسليم الفترات للصندوق (Close Periods / Shift Closing)
# ===========================================================================================

from datetime import datetime, timedelta


@can_access(8001)
def index():
    is_accountant = auth.has_membership("account")
    is_admin = auth.has_membership("admin")
    return dict(
        is_accountant=is_accountant,
        is_admin=is_admin,
        close_periods_url=URL("close_periods", "index"),
    )


@can_access(8001)
def close_periods_add():
    try:
        row = request.vars
        k_total = (
            float(row.kashir_amount_cash)
            + float(row.kashir_amount_atm)
            + float(row.kashir_amount_delay)
        )
        k_total = round(k_total, 2)
        # نقدي وشبكة: للكاشير الحالي فقط
        s_user = """
            SELECT
              SUM(CASE WHEN payment_method = 1 THEN total_after_discount ELSE 0 END) AS app_cash,
              SUM(CASE WHEN payment_method = 2 THEN total_after_discount ELSE 0 END) AS app_atm
            FROM invoice_master
            WHERE created_on >= %s AND created_on <= %s AND created_by = %s
        """
        data_user = db.executesql(s_user, placeholders=[row.start_time, row.end_time, auth.user.id], as_dict=True)
        app_cash = float(data_user[0]["app_cash"] or 0) if data_user else 0
        app_atm  = float(data_user[0]["app_atm"]  or 0) if data_user else 0
        # آجل: جميع المستخدمين (الفواتير الآجلة لا ترتبط بكاشير محدد)
        s_delay = """
            SELECT COALESCE(SUM(total_after_discount), 0) AS app_delay
            FROM invoice_master
            WHERE created_on >= %s AND created_on <= %s
              AND payment_method NOT IN (1, 2)
        """
        data_delay = db.executesql(s_delay, placeholders=[row.start_time, row.end_time], as_dict=True)
        app_delay = float(data_delay[0]["app_delay"]) if data_delay else 0
        app_total = round(app_cash + app_atm + app_delay, 2)
        difference = round(k_total - app_total, 2)
        new_row = db.closing_shift.validate_and_insert(
            pha_user=auth.user.id,
            start_time=row.start_time,
            end_time=row.end_time,
            kashir_amount_cash=row.kashir_amount_cash,
            kashir_amount_atm=row.kashir_amount_atm,
            kashir_amount_delay=row.kashir_amount_delay,
            kashir_note=row.kashir_note,
            kashir_total=k_total,
            app_total=app_total,
            app_amount_cash=app_cash,
            app_amount_atm=app_atm,
            app_amount_delay=app_delay,
            accountant_aprove=False,
            difference=difference,
        )
        return response.json(new_row)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)


@can_access(8001)
def close_periods_get():
    """إرجاع قائمة فترات المبيعات بصيغة JSON"""
    try:
        if auth.has_membership("account"):
            # Accountant: show last 7 days with all fields
            tod = datetime.now()
            d = timedelta(days=7)
            a = tod - d
            data = db((db.closing_shift.end_time > a)).select(
                db.closing_shift.id,
                db.closing_shift.start_time,
                db.closing_shift.end_time,
                db.closing_shift.kashir_amount_cash,
                db.closing_shift.kashir_amount_atm,
                db.closing_shift.kashir_amount_delay,
                db.closing_shift.kashir_note,
                db.closing_shift.kashir_total,
                db.closing_shift.pha_user,
                db.closing_shift.accountant_aprove,
                orderby=~db.closing_shift.start_time,
            )
            result = []
            for row in data:
                uuser = db.auth_user[row.pha_user]
                result.append(dict(
                    id=row.id,
                    start_time=str(row.start_time),
                    end_time=str(row.end_time),
                    kashir_amount_cash=float(row.kashir_amount_cash or 0),
                    kashir_amount_atm=float(row.kashir_amount_atm or 0),
                    kashir_amount_delay=float(row.kashir_amount_delay or 0),
                    kashir_note=row.kashir_note or '',
                    kashir_total=float(row.kashir_total or 0),
                    user_name=uuser.first_name + ' ' + uuser.last_name if uuser else 'غير معروف',
                    accountant_aprove=bool(row.accountant_aprove),
                    cash=float(row.kashir_amount_cash or 0),
                ))
            return response.json(result)
        else:
            # Cashier: show only unapproved periods
            data = db(
                (db.closing_shift.pha_user == auth.user.id)
                & (db.closing_shift.accountant_aprove == False)
            ).select(
                db.closing_shift.id,
                db.closing_shift.start_time,
                db.closing_shift.end_time,
                db.closing_shift.kashir_amount_cash,
                db.closing_shift.kashir_amount_atm,
                db.closing_shift.kashir_amount_delay,
                db.closing_shift.kashir_note,
                db.closing_shift.kashir_total,
                db.closing_shift.pha_user,
                db.closing_shift.accountant_aprove,
                orderby=~db.closing_shift.start_time,
            )
            result = []
            for row in data:
                uuser = db.auth_user[row.pha_user]
                result.append(dict(
                    id=row.id,
                    start_time=str(row.start_time),
                    end_time=str(row.end_time),
                    kashir_amount_cash=float(row.kashir_amount_cash or 0),
                    kashir_amount_atm=float(row.kashir_amount_atm or 0),
                    kashir_amount_delay=float(row.kashir_amount_delay or 0),
                    kashir_note=row.kashir_note or '',
                    kashir_total=float(row.kashir_total or 0),
                    user_name=uuser.first_name + ' ' + uuser.last_name if uuser else 'غير معروف',
                    accountant_aprove=bool(row.accountant_aprove),
                ))
            return response.json(result)
    except Exception as e:
        import traceback
        print(f"close_periods_get error: {e}")
        traceback.print_exc()
        return response.json([])


@can_access(8001)
def close_periods_edit():
    try:
        if auth.has_membership("account"):
            row = request.vars
            if row.kashir_amount_cash == row.cash:
                edit_row = db.closing_shift[row.id]
                edit_row.accountant_aprove = True
                edit_row.update_record()
                return response.json(row)
        else :
            row = request.vars
            k_total = (
                float(row.kashir_amount_cash)
                + float(row.kashir_amount_atm)
                + float(row.kashir_amount_delay)
            )
            k_total = round(k_total, 2)
            # نقدي وشبكة: للكاشير الحالي فقط
            s_user = """
                SELECT
                  SUM(CASE WHEN payment_method = 1 THEN total_after_discount ELSE 0 END) AS app_cash,
                  SUM(CASE WHEN payment_method = 2 THEN total_after_discount ELSE 0 END) AS app_atm
                FROM invoice_master
                WHERE created_on >= %s AND created_on <= %s AND created_by = %s
            """
            data_user = db.executesql(s_user, placeholders=[row.start_time, row.end_time, auth.user.id], as_dict=True)
            app_cash = float(data_user[0]["app_cash"] or 0) if data_user else 0
            app_atm  = float(data_user[0]["app_atm"]  or 0) if data_user else 0
            # آجل: جميع المستخدمين
            s_delay = """
                SELECT COALESCE(SUM(total_after_discount), 0) AS app_delay
                FROM invoice_master
                WHERE created_on >= %s AND created_on <= %s
                  AND payment_method NOT IN (1, 2)
            """
            data_delay = db.executesql(s_delay, placeholders=[row.start_time, row.end_time], as_dict=True)
            app_delay = float(data_delay[0]["app_delay"]) if data_delay else 0
            app_total = round(app_cash + app_atm + app_delay, 2)
            edit_row = db.closing_shift[row.id]
            edit_row.pha_user = auth.user.id
            edit_row.start_time = row.start_time
            edit_row.end_time = row.end_time
            edit_row.kashir_amount_cash = row.kashir_amount_cash
            edit_row.kashir_amount_atm = row.kashir_amount_atm
            edit_row.kashir_amount_delay = row.kashir_amount_delay
            edit_row.kashir_note = row.kashir_note
            edit_row.kashir_total = k_total
            edit_row.app_total = app_total
            edit_row.app_amount_cash = app_cash
            edit_row.app_amount_atm = app_atm
            edit_row.app_amount_delay = app_delay
            edit_row.accountant_aprove = False
            edit_row.difference = round(k_total - app_total, 2)
            edit_row.update_record()
            myrecord = (
                db(db.closing_shift.id == row.id)
                .select(
                    db.closing_shift.id,
                    db.closing_shift.start_time,
                    db.closing_shift.end_time,
                    db.closing_shift.kashir_amount_cash,
                    db.closing_shift.kashir_amount_atm,
                    db.closing_shift.kashir_amount_delay,
                    db.closing_shift.kashir_note,
                    db.closing_shift.kashir_total,
                )
                .first()
            )
            return response.json(myrecord)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)


@can_access(8001)
def close_periods_delete():
    try:
        delete_row = db.closing_shift[request.args(0)]
        if delete_row:
            if (
                delete_row.pha_user == auth.user.id
                and delete_row.accountant_aprove == False
            ):
                delete_row.delete_record()
                db.commit()
                return response.json({"mess": 1})
            else:
                return response.json({"mess": 0})
        else:
            return response.json({"mess": 0})
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"mess": str(e)}
        return response.json(ret)


@can_access(8001)
def print_close_period():
    """طباعة سند تسليم وردية واحدة"""
    try:
        record_id = request.args(0)
        if not record_id:
            return dict(error="لم يتم تحديد السجل")
        
        row = db.closing_shift[record_id]
        if not row:
            return dict(error="السجل غير موجود")
        
        return dict(row=row)
    except Exception as e:
        return dict(error=str(e))


@can_access(8001)
def print_close_period_by_day():
    """طباعة تقرير يومي لفترات المبيعات"""
    try:
        from datetime import datetime, timedelta as td
        
        record_id = request.args(0)
        if not record_id:
            return dict(error="لم يتم تحديد السجل")
        
        row = db.closing_shift[record_id]
        if not row:
            return dict(error="السجل غير موجود")
        
        s_date = row.start_time.date()
        e_date = s_date + td(days=1)
        
        rows = db(
            (db.closing_shift.start_time >= s_date) & 
            (db.closing_shift.start_time < e_date)
        ).select(orderby=db.closing_shift.start_time)
        
        return dict(row=row, rows=rows, s_date=s_date)
    except Exception as e:
        return dict(error=str(e))


# ===========================================================================================
# تقرير فترات المبيعات (للمحاسب)
# ===========================================================================================

@can_access(8001)
def periods_report():
    """صفحة تقرير فترات المبيعات - تُرجع HTML أو JSON حسب نوع الطلب"""
    http_accept = request.env.http_accept or ''
    if 'application/json' in http_accept or request.ajax:
        # طلب AJAX: أرجع قائمة الموظفين
        try:
            sql = """
                SELECT DISTINCT au.id, au.first_name, au.first_name || ' ' || au.last_name AS name
                FROM closing_shift cs
                LEFT JOIN auth_user au ON cs.pha_user = au.id
                ORDER BY au.first_name ASC
            """
            employees = db.executesql(sql, as_dict=True)
            return response.json({'ok': True, 'employees': employees})
        except Exception as e:
            return response.json({'ok': False, 'employees': [], 'mess': str(e)})
    # طلب عادي: اعرض صفحة HTML
    return dict()


@can_access(8001)
def periods_report_data():
    """
    API: إرجاع بيانات فترات المبيعات بين تاريخين
    الفلتر على start_time::date و employee_id (اختياري)
    """
    try:
        date_from    = request.vars.date_from    # YYYY-MM-DD
        date_to      = request.vars.date_to      # YYYY-MM-DD
        employee_id  = request.vars.employee_id  # اختياري

        if not date_from or not date_to:
            today = datetime.now().date()
            date_from = str(today)
            date_to   = str(today)

        # بناء الاستعلام مع الفلتر الاختياري للموظف
        sql = """
            SELECT
                cs.id,
                cs.start_time,
                cs.end_time,
                cs.kashir_amount_cash,
                cs.kashir_amount_atm,
                cs.kashir_amount_delay,
                cs.kashir_total,
                cs.app_amount_cash,
                cs.app_amount_atm,
                COALESCE((
                    SELECT SUM(im.total_after_discount)
                    FROM invoice_master im
                    WHERE im.created_on >= cs.start_time
                      AND im.created_on <= cs.end_time
                      AND im.payment_method NOT IN (1, 2)
                ), 0) AS app_amount_delay,
                cs.kashir_note,
                cs.accountant_aprove,
                au.first_name || ' ' || au.last_name AS user_name,
                DATE(cs.start_time) AS shift_date
            FROM closing_shift cs
            LEFT JOIN auth_user au ON cs.pha_user = au.id
            WHERE DATE(cs.start_time) >= %s
              AND DATE(cs.start_time) <= %s
        """
        placeholders = [date_from, date_to]

        if employee_id and employee_id != 'all':
            sql += " AND cs.pha_user = %s"
            placeholders.append(employee_id)

        sql += " ORDER BY cs.start_time ASC"

        rows = db.executesql(sql, placeholders=placeholders, as_dict=True)

        # تحويل datetime إلى string لـ JSON وتقريب الأرقام
        for r in rows:
            r['start_time']  = str(r['start_time'])  if r['start_time']  else ''
            r['end_time']    = str(r['end_time'])    if r['end_time']    else ''
            r['shift_date']  = str(r['shift_date'])  if r['shift_date']  else ''
            r['kashir_amount_cash']  = round(float(r['kashir_amount_cash']  or 0), 2)
            r['kashir_amount_atm']   = round(float(r['kashir_amount_atm']   or 0), 2)
            r['kashir_amount_delay'] = round(float(r['kashir_amount_delay'] or 0), 2)
            r['kashir_total']        = round(float(r['kashir_total']        or 0), 2)
            r['app_amount_cash']     = round(float(r['app_amount_cash']     or 0), 2)
            r['app_amount_atm']      = round(float(r['app_amount_atm']      or 0), 2)
            r['app_amount_delay']    = round(float(r['app_amount_delay']    or 0), 2)
            r['app_total']           = round(r['app_amount_cash'] + r['app_amount_atm'] + r['app_amount_delay'], 2)
            r['difference']          = round(r['kashir_total'] - r['app_total'], 2)
            r['diff_cash']  = round(r['kashir_amount_cash']  - r['app_amount_cash'],  2)
            r['diff_atm']   = round(r['kashir_amount_atm']   - r['app_amount_atm'],   2)
            r['diff_delay'] = round(r['kashir_amount_delay'] - r['app_amount_delay'], 2)

        # حساب الإجماليات
        totals = {
            'kashir_amount_cash':  round(sum(r['kashir_amount_cash']  for r in rows), 2),
            'kashir_amount_atm':   round(sum(r['kashir_amount_atm']   for r in rows), 2),
            'kashir_amount_delay': round(sum(r['kashir_amount_delay'] for r in rows), 2),
            'kashir_total':        round(sum(r['kashir_total']        for r in rows), 2),
            'app_total':           round(sum(r['app_total']           for r in rows), 2),
            'app_amount_cash':     round(sum(r['app_amount_cash']     for r in rows), 2),
            'app_amount_atm':      round(sum(r['app_amount_atm']      for r in rows), 2),
            'app_amount_delay':    round(sum(r['app_amount_delay']    for r in rows), 2),
            'difference':          round(sum(r['difference']          for r in rows), 2),
            'diff_cash':           round(sum(r['diff_cash']           for r in rows), 2),
            'diff_atm':            round(sum(r['diff_atm']            for r in rows), 2),
            'diff_delay':          round(sum(r['diff_delay']          for r in rows), 2),
            'count':               len(rows),
        }

        return response.json({'ok': True, 'data': rows, 'totals': totals})
    except Exception as e:
        db.rollback()
        return response.json({'ok': False, 'mess': str(e), 'data': [], 'totals': {}})
