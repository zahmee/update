# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# تسليم الفترات للصندوق (Close Periods / Shift Closing)
# ===========================================================================================

from datetime import datetime, timedelta


@can_access(8001)
def index():
    return dict()


@can_access(8001)
def close_periods_add():
    try:
        row = request.vars
        k_total = (
            float(row.kashir_amount_cash)
            + float(row.kashir_amount_atm)
            + float(row.kashir_amount_delay)
        )
        k_total = round(k_total, 2)
        s = (
            "select sum(total_after_discount) as u_total from invoice_master "
            " where (created_on >= %s and created_on <= %s "
            " and created_by=%s ) group by created_by  "
        )
        data = db.executesql(s, placeholders=[row.start_time, row.end_time, auth.user.id], as_dict=True)
        if data:
            difference = k_total - float(data[0]["u_total"])
            app_total = data[0]["u_total"]
        else:
            app_total = 0
            difference = k_total - 0
        new_row = db.closing_shift.validate_and_insert(
            pha_user=auth.user.id,
            start_time=row.start_time,
            end_time=row.end_time,
            kashir_amount_cash=row.kashir_amount_cash,
            kashir_amount_atm=row.kashir_amount_atm,
            kashir_amount_delay=row.kashir_amount_delay,
            kashir_note=row.kashir_note,
            kashir_total=k_total,
            app_total=app_total,
            app_amount_cash=app_total,
            app_amount_atm=0,
            app_amount_delay=0,
            accountant_aprove=False,
            difference=round(difference, 2),
        )
        return response.json(new_row)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)


@can_access(8001)
def close_periods_get():
    if auth.has_membership("account"):
        tod = datetime.now()
        d = timedelta(days = 7 )
        a = tod - d
        data = db((db.closing_shift.end_time > a)).select(
            db.closing_shift.id,
            db.closing_shift.start_time,
            db.closing_shift.end_time,
            db.closing_shift.kashir_amount_cash,
            db.closing_shift.kashir_amount_atm,
            db.closing_shift.kashir_amount_delay,
            db.closing_shift.kashir_note,
            db.closing_shift.kashir_total,
            db.closing_shift.pha_user,
            db.closing_shift.accountant_aprove,
        )
        for row in data:
            uuser = db.auth_user[row.pha_user]
            row["user_name"] = uuser.first_name + " " + uuser.last_name
            row.cash = row.kashir_amount_cash
            row.kashir_amount_cash = 0
            row.kashir_amount_atm = 0
            row.kashir_amount_delay = 0
            row.kashir_total = 0

        return response.json(data)
    else:
        data = db(
            (db.closing_shift.pha_user == auth.user.id)
            & (db.closing_shift.accountant_aprove == False)
        ).select(
            db.closing_shift.id,
            db.closing_shift.start_time,
            db.closing_shift.end_time,
            db.closing_shift.kashir_amount_cash,
            db.closing_shift.kashir_amount_atm,
            db.closing_shift.kashir_amount_delay,
            db.closing_shift.kashir_note,
            db.closing_shift.kashir_total,
            db.closing_shift.pha_user,
        )
        for row in data:
            uuser = db.auth_user[row.pha_user]
            row["user_name"] = uuser.first_name + " " + uuser.last_name
        return response.json(data)


@can_access(8001)
def close_periods_edit():
    try:
        if auth.has_membership("account"):
            row = request.vars
            if row.kashir_amount_cash == row.cash:
                edit_row = db.closing_shift[row.id]
                edit_row.accountant_aprove = True
                edit_row.update_record()
                return response.json(row)
        else :
            row = request.vars
            k_total = (
                float(row.kashir_amount_cash)
                + float(row.kashir_amount_atm)
                + float(row.kashir_amount_delay)
            )
            k_total = round(k_total, 2)
            s = (
                "select sum(total_after_discount) as u_total from invoice_master "
                " where (created_on >= %s and created_on <= %s "
                " and created_by=%s ) group by created_by  "
            )
            data = db.executesql(s, placeholders=[row.start_time, row.end_time, auth.user.id], as_dict=True)
            if data:
                difference = k_total - float(data[0]["u_total"])
                app_total = data[0]["u_total"]
            else:
                app_total = 0
                difference = k_total - 0
            edit_row = db.closing_shift[row.id]
            edit_row.pha_user = auth.user.id
            edit_row.start_time = row.start_time
            edit_row.end_time = row.end_time
            edit_row.kashir_amount_cash = row.kashir_amount_cash
            edit_row.kashir_amount_atm = row.kashir_amount_atm
            edit_row.kashir_amount_delay = row.kashir_amount_delay
            edit_row.kashir_note = row.kashir_note
            edit_row.kashir_total = k_total
            edit_row.app_total = app_total
            edit_row.app_amount_cash = app_total
            edit_row.app_amount_atm = 0
            edit_row.app_amount_delay = 0
            edit_row.accountant_aprove = False
            edit_row.difference = round(difference, 2)
            edit_row.update_record()
            myrecord = (
                db(db.closing_shift.id == row.id)
                .select(
                    db.closing_shift.id,
                    db.closing_shift.start_time,
                    db.closing_shift.end_time,
                    db.closing_shift.kashir_amount_cash,
                    db.closing_shift.kashir_amount_atm,
                    db.closing_shift.kashir_amount_delay,
                    db.closing_shift.kashir_note,
                    db.closing_shift.kashir_total,
                )
                .first()
            )
            return response.json(myrecord)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)


@can_access(8001)
def close_periods_delete():
    try:
        delete_row = db.closing_shift[request.args(0)]
        if delete_row:
            if (
                delete_row.pha_user == auth.user.id
                and delete_row.accountant_aprove == False
            ):
                delete_row.delete_record()
                db.commit()
                return response.json({"mess": 1})
            else:
                return response.json({"mess": 0})
        else:
            return response.json({"mess": 0})
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"mess": str(e)}
        return response.json(ret)


@can_access(8001)
def print_close_period():
    return dict()


@can_access(8001)
def print_close_period_by_day():
    return dict()


# ===========================================================================================
# تقرير فترات المبيعات (للمحاسب)
# ===========================================================================================

@can_access(8001)
def periods_report():
    """صفحة تقرير فترات المبيعات - تُرجع HTML أو JSON حسب نوع الطلب"""
    http_accept = request.env.http_accept or ''
    if 'application/json' in http_accept or request.ajax:
        # طلب AJAX: أرجع قائمة الموظفين
        try:
            sql = """
                SELECT DISTINCT au.id, au.first_name, au.first_name || ' ' || au.last_name AS name
                FROM closing_shift cs
                LEFT JOIN auth_user au ON cs.pha_user = au.id
                ORDER BY au.first_name ASC
            """
            employees = db.executesql(sql, as_dict=True)
            return response.json({'ok': True, 'employees': employees})
        except Exception as e:
            return response.json({'ok': False, 'employees': [], 'mess': str(e)})
    # طلب عادي: اعرض صفحة HTML
    return dict()


@can_access(8001)
def periods_report_data():
    """
    API: إرجاع بيانات فترات المبيعات بين تاريخين
    الفلتر على start_time::date و employee_id (اختياري)
    """
    try:
        date_from    = request.vars.date_from    # YYYY-MM-DD
        date_to      = request.vars.date_to      # YYYY-MM-DD
        employee_id  = request.vars.employee_id  # اختياري

        if not date_from or not date_to:
            today = datetime.now().date()
            date_from = str(today)
            date_to   = str(today)

        # بناء الاستعلام مع الفلتر الاختياري للموظف
        sql = """
            SELECT
                cs.id,
                cs.start_time,
                cs.end_time,
                cs.kashir_amount_cash,
                cs.kashir_amount_atm,
                cs.kashir_amount_delay,
                cs.kashir_total,
                cs.app_total,
                cs.difference,
                cs.kashir_note,
                cs.accountant_aprove,
                au.first_name || ' ' || au.last_name AS user_name,
                DATE(cs.start_time) AS shift_date
            FROM closing_shift cs
            LEFT JOIN auth_user au ON cs.pha_user = au.id
            WHERE DATE(cs.start_time) >= %s
              AND DATE(cs.start_time) <= %s
        """
        placeholders = [date_from, date_to]

        if employee_id and employee_id != 'all':
            sql += " AND cs.pha_user = %s"
            placeholders.append(employee_id)

        sql += " ORDER BY cs.start_time ASC"

        rows = db.executesql(sql, placeholders=placeholders, as_dict=True)

        # حساب الإجماليات
        totals = {
            'kashir_amount_cash':  sum(r['kashir_amount_cash']  or 0 for r in rows),
            'kashir_amount_atm':   sum(r['kashir_amount_atm']   or 0 for r in rows),
            'kashir_amount_delay': sum(r['kashir_amount_delay'] or 0 for r in rows),
            'kashir_total':        sum(r['kashir_total']        or 0 for r in rows),
            'app_total':           sum(r['app_total']           or 0 for r in rows),
            'difference':          sum(r['difference']          or 0 for r in rows),
            'count':               len(rows),
        }

        # تحويل datetime إلى string لـ JSON
        for r in rows:
            r['start_time']  = str(r['start_time'])  if r['start_time']  else ''
            r['end_time']    = str(r['end_time'])    if r['end_time']    else ''
            r['shift_date']  = str(r['shift_date'])  if r['shift_date']  else ''
            r['kashir_amount_cash']  = round(float(r['kashir_amount_cash']  or 0), 2)
            r['kashir_amount_atm']   = round(float(r['kashir_amount_atm']   or 0), 2)
            r['kashir_amount_delay'] = round(float(r['kashir_amount_delay'] or 0), 2)
            r['kashir_total']        = round(float(r['kashir_total']        or 0), 2)
            r['app_total']           = round(float(r['app_total']           or 0), 2)
            r['difference']          = round(float(r['difference']          or 0), 2)

        totals = {k: round(float(v), 2) if isinstance(v, float) else v
                  for k, v in totals.items()}

        return response.json({'ok': True, 'data': rows, 'totals': totals})
    except Exception as e:
        db.rollback()
        return response.json({'ok': False, 'mess': str(e), 'data': [], 'totals': {}})
