var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        id: this.id,
        err: '',
        administrator_name: [''],
        data: {
            name: '',
            administrator_name: [],
            total_amount: '',
            tel: [''],
            address: ''
        }
    },
    methods: {
        cleanList(list) {
            return (list || []).map(function (value) {
                return String(value || '').trim();
            }).filter(function (value) {
                return value !== '';
            });
        },
        validateForm() {
            var errors = [];
            var amount = String(this.data.total_amount || '').trim();
            var tels = this.cleanList(this.data.tel);

            if (!String(this.data.name || '').trim()) {
                errors.push('اسم المورد مطلوب');
            }
            if (amount === '' || isNaN(Number(amount)) || Number(amount) < 0) {
                errors.push('المبلغ المستحق يجب أن يكون رقماً صحيحاً أو عشرياً ولا يقل عن صفر');
            }
            if (!String(this.data.address || '').trim()) {
                errors.push('العنوان مطلوب');
            }
            if (tels.length === 0) {
                errors.push('يجب إدخال رقم هاتف واحد على الأقل');
            } else if (tels.some(function (tel) { return !/^[0-9+ -]{7,20}$/.test(tel); })) {
                errors.push('رقم الهاتف يجب أن يحتوي أرقاماً فقط ويمكن أن يبدأ بـ +');
            }

            return errors;
        },
        showError(message) {
            if (window.Swal) {
                Swal.fire('تنبيه', message, 'error');
            } else {
                alert(message);
            }
        },
        SaveAll() {
            var errors = this.validateForm();
            if (errors.length) {
                this.showError(errors.join('\n'));
                return;
            }

            var payload = {
                name: String(this.data.name || '').trim(),
                administrator_name: JSON.stringify(this.cleanList(this.administrator_name)),
                total_amount: String(this.data.total_amount || '').trim(),
                tel: JSON.stringify(this.cleanList(this.data.tel)),
                address: String(this.data.address || '').trim()
            };

            this.$http.post(this.URL + '/../../suppliers_api/new_supplier/', payload, { emulateJSON: true }).then(response => {
                if (response.body && response.body.ok) {
                    window.open(purl + "/../", '_self');
                } else {
                    this.showError((response.body && response.body.mess) || 'تعذر حفظ المورد');
                }
            });
        },
    },
    computed: {
        FormErr() {
            return this.validateForm().length === 0;
        },

    },

});
