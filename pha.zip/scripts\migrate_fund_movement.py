# -*- coding: utf-8 -*-
# ===========================================================================================
# سكريبت ترحيل لمرة واحدة — من fund_movement القديم إلى fund_entry الجديد
# تشغيل:
#   uv run web2py.py -S asbab5 -M -R scripts/migrate_fund_movement.py
#
# سلوك السكريبت:
#   - إن كان fund_entry يحتوي بالفعل سجلات مُرحَّلة بفئة LEGACY فلن يكرر الترحيل.
#   - يحوِّل كل صف من fund_movement إلى fund_entry:
#       process_type == 1  ⇒ kind='deposit'
#       process_type == 2  ⇒ kind='expense'
#       aprove == True     ⇒ status='approved'  (مع approved_by = admin)
#       aprove == False    ⇒ status='draft'
#   - يُسنَد category_id إلى فئة LEGACY (يُنشئها إن لم توجد).
#   - payment_method يُسنَد إلى أول قيمة في key_payment_method (عادةً "نقدي").
#   - لا يحذف fund_movement — يُترك الحذف للمشغل يدويًا عبر SQL بعد التأكد.
# ===========================================================================================

print("بدء ترحيل fund_movement ➜ fund_entry ...")

# 1) فئة LEGACY (إنشاء إن لم توجد)
legacy = db(db.key_fund_category.code == "LEGACY").select().first()
if not legacy:
    lid = db.key_fund_category.insert(
        code="LEGACY",
        name_ar="مُرحَّل من النظام القديم",
        kind="expense",
        is_active=True,
    )
    legacy = db.key_fund_category[lid]
    print("  + فئة LEGACY أُنشئت.")

# 2) طريقة دفع افتراضية (أول صف)
default_pm = db(db.key_payment_method.id > 0).select(
    orderby=db.key_payment_method.id
).first()
if not default_pm:
    print("  ! لا توجد طرق دفع مُعرَّفة. أضفها من شاشة تهيئة النظام (setup/seed_data) أولًا.")
else:
    # 3) المستخدم الأدمن الأول (للاعتماد التاريخي)
    admin_group = db(db.auth_group.role == "admin").select().first()
    admin_user = None
    if admin_group:
        adm_mem = db(db.auth_membership.group_id == admin_group.id).select().first()
        if adm_mem:
            admin_user = adm_mem.user_id

    # 4) تفحّص إن كان هناك ترحيل سابق
    already_migrated = db(
        (db.fund_entry.category_id == legacy.id)
        & (db.fund_entry.ref_type == "legacy")
    ).count()
    if already_migrated > 0:
        print(f"  = يوجد ترحيل سابق: {already_migrated} سجل مُرحَّل مسبقًا. تخطّي.")
    else:
        old_rows = db(db.fund_movement.id > 0).select(orderby=db.fund_movement.id)
        migrated = 0
        for r in old_rows:
            kind = "deposit" if (r.process_type == 1) else "expense"
            status = "approved" if r.aprove else "draft"
            approved_by = admin_user if r.aprove else None
            approved_at = request.now if r.aprove else None
            db.fund_entry.insert(
                entry_date=r.process_date,
                kind=kind,
                category_id=legacy.id,
                payment_method=default_pm.id,
                amount=r.amount or 0.0,
                beneficiary="",
                ref_type="legacy",
                ref_id=r.id,
                document_no="",
                description=r.detill or "",
                status=status,
                submitted_by=admin_user,
                submitted_at=request.now,
                approved_by=approved_by,
                approved_at=approved_at,
            )
            migrated += 1
        db.commit()
        print(f"  + تم ترحيل {migrated} سجل من fund_movement إلى fund_entry.")

print("تم الترحيل. يمكنك الآن حذف جدول fund_movement يدويًا:")
print('  DROP TABLE fund_movement;')
