Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
            counter: 0,
            data: [],
            day_date: {
                day: 01,
                month: 01,
                year: 2019
            },  
            getData: {
                page: 0,
                RecordCount: 20,
                SearchText: '',
                ApprovalStatus: 'pending',
                SortBy: 'id',
                sortAsc: true
            },
            data_row_count: 0,
            coding: {
                supplier: [],
                Allsupplier: [],
            },
            select_obj_1: {
                serch_text: '',
                show_select: false,
                select_value: '',
                select_id: '',
            },
            select_obj_2: 0,
            showBtn: 0,
            show_model: false,
            selectedRow: -1,
            text_ltr: false,
            new_row: true,
            edit_row_data: {},
            value: '',
            options: [] ,
            // الترحيل إلى مستودع التالف (صلاحية 2017)
            canTransfer: typeof DS_CAN_TRANSFER !== 'undefined' && DS_CAN_TRANSFER === 1,
            transferSeq: 0,  // لا يُصفَّر: يميّز آخر طلب معاينة حتى عبر فتح النافذة لفاتورة أخرى
            transfer: {
                show: false, loading: false, saving: false,
                retId: null, invoice: {}, lines: [], totals: {}, note: '',
                mode: null  // 'deduct' | 'none' — لا افتراضي، يختاره المدير صراحةً
            },
    },
    created() {
        this.getData.SortBy=  'id' ;
        this.getData.sortAsc = false ;
        this.fetchData();
        fetch(window.location.href + '/../../api_1/min_suppliers_1')
            .then(response => response.json())
            .then(resp => {
                var data = Api.getData(resp);
                this.coding.supplier = data;
                this.coding.Allsupplier = data;
                op = this.options ;
                data.forEach(function(el){
                    new_el ={
                        value: el.id ,
                        label: "["+el.id+"]  -  " + el.name
                    }
                    op.push(new_el);
                });
            });
    },
    methods: {
        buildParams() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                ApprovalStatus: this.getData.ApprovalStatus,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc
            };
            if (this.value && typeof this.value.value !== 'undefined') {
                params.supplier = this.value.value;
            }
            return params;
        },
        fetchData() {
            var url = new URL(window.location.href + '/../../suppliers_api/getRetSuppInvoce');
            var params = this.buildParams();
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            return fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then(response => response.json())
                .then(data => {
                    this.data = Api.getData(data);
                    this.data_row_count = data.count;
                });
        },
        onChange() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.fetchData();
        },
        clearSearch() {
            this.getData.SearchText = '';
            this.onChange();
        },
        resetFilters() {
            this.getData.SearchText = '';
            this.value = '';
            this.getData.ApprovalStatus = 'pending';
            this.getData.RecordCount = 20;
            this.onChange();
        },
        goToPage(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) {
                return;
            }
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.fetchData();
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined' ){
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    ApprovalStatus: this.getData.ApprovalStatus,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    ApprovalStatus: this.getData.ApprovalStatus,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/getRetSuppInvoce'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    Api.getData(data).forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            sup = {} ;
            this.options.forEach((el)=>{
                if (el.value === row.supplier ){
                    sup.value = el.value;
                    sup.label = el.label;
                }
            })
            this.edit_row_data.suppliers = sup ;
        },
        edit_row() {
            this.new_row = false;
            var today = new Date(this.edit_row_data.ret_date);
            this.day_date.year = today.getFullYear()
            this.day_date.month = today.getMonth() + 1
            this.day_date.day = today.getDate()
        },
        on_change_select(){
            this.$forceUpdate();
        } ,
        new_row_click() {
            this.new_row = true;
            var today = new Date();
            this.day_date.year = today.getFullYear() ;
            this.day_date.month = today.getMonth() + 1 ;
            this.day_date.day = today.getDate() ;
            this.edit_row_data = {
                suppliers : '' ,
            };
        },
        chk_date() {
            var today = new Date();
            if (this.day_date.day > 31 || this.day_date.day < 1) {
                this.day_date.day = today.getDate()
            }
            if (this.day_date.month > 12 || this.day_date.month < 1) {
                this.day_date.month = today.getMonth() + 1
            }
            if (this.day_date.year > 2030 || this.day_date.year < 2020) {
                this.day_date.year = today.getFullYear()
            }
        },

        save_data() {
            if ( !this.day_date.year || !this.day_date.month || 
                !this.edit_row_data.name || !this.edit_row_data.suppliers.value || !this.day_date.day ) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [كافة الحقول لكي تحفظ ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_RetSupInv');
                params =this.edit_row_data ;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.suppliers);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (Api.isOk(data)) {
                            var result = Api.getData(data);
                            this.edit_row_data.id = result.id ;
                            this.coding.supplier.forEach(row => {
                                if (row.id === result.supplier ) {
                                    this.edit_row_data.s_name = row.name;
                                }
                            });
                            this.edit_row_data.ret_date = result.ret_date ;
                            this.edit_row_data.itm_r_count = 0;
                            this.edit_row_data.itm_count = 0;
                            this.edit_row_data.admin_accept = 'F';
                            this.edit_row_data.total = 0.0;
                            this.edit_row_data.real_total = 0.0;
                            this.data.splice(0, 0,this.edit_row_data);
                            this.edit_row_data = {} ;
                            this.selectedRow = -1 ;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();

                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Api.showError(data);
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/edit_RetSupInv');
                params = this.edit_row_data;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.suppliers);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (Api.isOk(data)) {
                            var result = Api.getData(data);
                            this.edit_row_data.id = result.id;
                            this.coding.supplier.forEach(row => {
                                if (row.id === result.supplier) {
                                    this.edit_row_data.s_name = row.name;
                                }
                            });
                            this.edit_row_data.ret_date = result.ret_date.substring(0, 10);
                            this.data[this.selectedRow] = this.edit_row_data;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Api.showError(data);
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1 ;

        },
        invoce_insert_items(){
            url = window.location.href + '/../../suppliers/returned_supply_det/' + this.edit_row_data.id;
            window.open(url, "_self");
        } ,
        invoce_print_report() {
            url = window.location.href + '/../../suppliers/returned_supply_print/' + this.edit_row_data.id;
            window.open(url, "_self"); //items_qry/items_sales
        } ,
        invoce_export_excel() {
            url = window.location.href + '/../../suppliers/returned_supply_excel/' + this.edit_row_data.id;
            window.open(url, "_blank");
        },
        invoce_barcode_print() {
            url = window.location.href + '/../../suppliers/returned_supply_count/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_print_return() {
            url = window.location.href + '/../../suppliers/return_suppliers_bills_print/' + this.edit_row_data.id;
            window.open(url, "_self");
        },
        invoce_print_sales(){
            if (!this.edit_row_data || !this.edit_row_data.id) {
                Swal.fire('تنبيه', 'اختر فاتورة أولا', 'warning');
                return;
            }
            if (this.edit_row_data.admin_accept === 'T') {
                Swal.fire('تنبيه', 'هذه الفاتورة معتمدة مسبقا', 'info');
                return;
            }
            var self = this;
            var summaryUrl = window.location.href + '/../../suppliers_api/ret_sup_approval_summary/' + this.edit_row_data.id;
            Api.get(summaryUrl).then(function(resp) {
                if (!Api.isOk(resp)) {
                    Api.showError(resp);
                    return;
                }
                var summary = Api.getData(resp);
                if (!summary.detail_count || summary.detail_count <= 0) {
                    Swal.fire('تنبيه', 'لا يمكن اعتماد فاتورة بدون أصناف', 'warning');
                    return;
                }
                var clean = function(value) {
                    return String(value === undefined || value === null ? '' : value)
                        .replace(/&/g, '&amp;')
                        .replace(/</g, '&lt;')
                        .replace(/>/g, '&gt;')
                        .replace(/"/g, '&quot;')
                        .replace(/'/g, '&#039;');
                };
                var html =
                    '<div dir="rtl" class="text-end approval-confirm">' +
                    '<div class="approval-meta mb-2"><strong>رقم المرتجع:</strong> ' + clean(summary.id) + '</div>' +
                    '<div class="approval-meta mb-2"><strong>المورد:</strong> ' + clean(summary.supplier_name) + '</div>' +
                    '<div class="approval-meta mb-2"><strong>الوصف:</strong> ' + clean(summary.name) + '</div>' +
                    '<hr>' +
                    '<table class="table table-sm table-bordered mb-2 approval-table">' +
                    '<tr><th>عدد الأصناف</th><td>' + clean(summary.detail_count) + '</td></tr>' +
                    '<tr><th>مجموع الكمية</th><td>' + self.formatNum(summary.qty_sum) + '</td></tr>' +
                    '<tr><th>الشراء بدون ضريبة</th><td>' + self.formatNum(summary.purchase_net) + '</td></tr>' +
                    '<tr><th>ضريبة الشراء</th><td>' + self.formatNum(summary.purchase_vat) + '</td></tr>' +
                    '<tr class="table-warning"><th>المبلغ على المورد</th><td class="fw-bold">' + self.formatNum(summary.purchase_total) + '</td></tr>' +
                    '</table>' +
                    '<div class="alert alert-warning py-2 mb-0">بعد الاعتماد سيتم خصم الكميات من المخزون وتسجيل حركة وسداد للمورد، ولن يمكن تعديل الفاتورة.</div>' +
                    '</div>';

                Swal.fire({
                    title: 'اعتماد نهائي للمرتجع',
                    html: html,
                    icon: 'warning',
                    customClass: {
                        popup: 'swal2-rtl-popup',
                        title: 'swal2-rtl-title',
                        htmlContainer: 'swal2-rtl-html',
                        actions: 'swal2-rtl-actions'
                    },
                    showCancelButton: true,
                    confirmButtonText: 'اعتماد نهائي',
                    cancelButtonText: 'إلغاء',
                    confirmButtonColor: '#198754',
                    cancelButtonColor: '#6c757d',
                    reverseButtons: true,
                    width: 620
                }).then(function(result) {
                    if (!result.isConfirmed) {
                        return;
                    }
                    var approveUrl = window.location.href + '/../../suppliers_api/approve_RetSupInv/' + self.edit_row_data.id;
                    Api.post(approveUrl, new FormData()).then(function(approveResp) {
                        if (!Api.isOk(approveResp)) {
                            Api.showError(approveResp);
                            return;
                        }
                        var approved = Api.getData(approveResp);
                        self.edit_row_data.admin_accept = 'T';
                        self.edit_row_data.real_total = approved.purchase_net;
                        self.edit_row_data.itm_count = approved.detail_count;
                        self.edit_row_data.itm_r_count = approved.qty_sum;
                        if (self.selectedRow > -1) {
                            self.data[self.selectedRow].admin_accept = 'T';
                            self.data[self.selectedRow].real_total = approved.purchase_net;
                            self.data[self.selectedRow].itm_count = approved.detail_count;
                            self.data[self.selectedRow].itm_r_count = approved.qty_sum;
                        }
                        Swal.fire({
                            icon: 'success',
                            title: 'تم الاعتماد',
                            text: 'تم اعتماد المرتجع وتسجيل حركة المخزون وسداد المورد.',
                            timer: 1800,
                            showConfirmButton: false
                        });
                    });
                });
            });
        } ,
        formatNum(val) {
            if (val === undefined || val === null || val === '') return '0.00';
            var num = parseFloat(val);
            if (isNaN(num)) return '0.00';
            return num.toFixed(2);
        },
        // ── الترحيل إلى مستودع التالف ──
        // الخادم هو مصدر الأرقام: كل تغيير في الاختيار يعيد طلب المعاينة، لأن خصم
        // الدفعة المكررة داخل الفاتورة يتوزع على الأسطر المختارة فقط.
        open_transfer() {
            if (!this.edit_row_data || !this.edit_row_data.id) {
                Swal.fire('تنبيه', 'اختر فاتورة أولا', 'warning');
                return;
            }
            if (this.edit_row_data.admin_accept === 'T') {
                Swal.fire('تنبيه', 'الفاتورة معتمدة ولا تُرحَّل', 'info');
                return;
            }
            this.transfer = {
                show: true, loading: false, saving: false,
                retId: this.edit_row_data.id, invoice: { id: this.edit_row_data.id },
                lines: [], totals: {}, note: '', mode: null
            };
            this.load_transfer(null);
        },
        load_transfer(lineIds) {
            var self = this, seq = ++self.transferSeq;
            // قبل الاختيار تُعرض كميات الخصم المحتملة لتساعد على القرار
            var qs = ['deduct=' + (self.transfer.mode === 'none' ? '0' : '1')];
            if (lineIds !== null) {
                qs.push('line_ids=' + lineIds.join(','));
            }
            var url = DS_URLS.preview + '/' + self.transfer.retId + '?' + qs.join('&');
            self.transfer.loading = true;
            return Api.get(url).then(function (resp) {
                if (seq !== self.transferSeq) return;  // رد قديم وصل بعد طلب أحدث
                self.transfer.loading = false;
                if (!Api.isOk(resp)) {
                    Api.showError(resp);
                    if (!self.transfer.lines.length) self.transfer.show = false;
                    return;
                }
                var d = Api.getData(resp);
                self.transfer.invoice = d.invoice;
                self.transfer.lines = d.lines;
                self.transfer.totals = d.totals;
            });
        },
        transfer_selected_ids() {
            return this.transfer.lines.filter(function (l) { return l.selected; })
                .map(function (l) { return l.id; });
        },
        toggle_transfer_line(line) {
            var ids = this.transfer_selected_ids();
            var i = ids.indexOf(line.id);
            if (i >= 0) { ids.splice(i, 1); } else { ids.push(line.id); }
            this.load_transfer(ids);
        },
        toggle_all_lines(e) {
            this.load_transfer(e.target.checked
                ? this.transfer.lines.map(function (l) { return l.id; })
                : []);
        },
        set_transfer_mode() {
            // الخصم المعروض يتغير بالاختيار، والخادم يرفض التنفيذ إن اختلف عمّا عُرض
            this.load_transfer(this.transfer_selected_ids());
        },
        close_transfer() {
            if (this.transfer.saving) return;
            this.transfer.show = false;
        },
        confirm_transfer() {
            var self = this, t = this.transfer.totals, mode = this.transfer.mode;
            var chosen = this.transfer.lines.filter(function (l) { return l.selected; });
            if (!chosen.length || this.transfer.loading) return;
            if (mode !== 'deduct' && mode !== 'none') {
                Swal.fire('تنبيه', 'اختر أولاً: هل تُخصم الأصناف من رصيد الصيدلية؟', 'warning');
                return;
            }
            var html =
                '<div dir="rtl" class="text-end">' +
                '<table class="table table-sm table-bordered mb-2 approval-table">' +
                '<tr><th>عدد الأصناف</th><td>' + chosen.length + '</td></tr>' +
                '<tr><th>الخصم من رصيد الصيدلية</th><td>' +
                (mode === 'deduct' ? 'نعم — ' + self.formatNum(t.deduct) : 'بدون خصم') + '</td></tr>' +
                '<tr><th>القيمة بسعر الشراء</th><td>' + self.formatNum(t.value) + '</td></tr>' +
                '</table>' +
                '<div class="alert alert-warning py-2 mb-0">لا يُسجَّل شيء على حساب المورد' +
                (mode === 'deduct' ? '، ولا يمكن التراجع عن الخصم من المخزون.' : '، ورصيد الصيدلية لن يتغير.') +
                '</div></div>';
            Swal.fire({
                title: 'تأكيد الترحيل إلى مستودع التالف',
                html: html,
                icon: 'warning',
                customClass: {
                    popup: 'swal2-rtl-popup',
                    title: 'swal2-rtl-title',
                    htmlContainer: 'swal2-rtl-html',
                    actions: 'swal2-rtl-actions'
                },
                showCancelButton: true,
                confirmButtonText: 'ترحيل',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#9f1239',
                cancelButtonColor: '#6c757d',
                reverseButtons: true
            }).then(function (result) {
                if (!result.isConfirmed) return;
                var expected = {};
                chosen.forEach(function (l) { expected[l.id] = l.deduct; });
                var fd = new FormData();
                fd.append('ret_id', self.transfer.retId);
                fd.append('line_ids', chosen.map(function (l) { return l.id; }).join(','));
                fd.append('expected', JSON.stringify(expected));
                fd.append('deduct', mode === 'deduct' ? '1' : '0');
                fd.append('note', self.transfer.note || '');
                self.transfer.saving = true;
                Api.post(DS_URLS.transfer, fd).then(function (resp) {
                    self.transfer.saving = false;
                    if (!Api.isOk(resp)) {
                        Api.showError(resp);
                        // الأرصدة تغيّرت أو الفاتورة لم تعد موجودة: نعرض الوضع الحالي
                        self.load_transfer(self.transfer_selected_ids());
                        return;
                    }
                    self.transfer.show = false;
                    self.edit_row_data = {};
                    self.selectedRow = -1;
                    self.fetchData();
                    Swal.fire({
                        icon: 'success',
                        title: 'تم الترحيل',
                        html: '<div dir="rtl">' + resp.mess + '<br><br>' +
                            '<a href="' + DS_URLS.store + '">فتح مستودع التالف</a></div>',
                        confirmButtonText: 'حسناً'
                    });
                });
            });
        },
    } ,
    watch: {
        value : function (val) {
            this.onChange() ;
            //this.$forceUpdate();
        }
    } ,
    computed: {
        transferAllSelected() {
            return this.transfer.lines.length > 0 &&
                this.transfer.lines.every(function (l) { return l.selected; });
        },
        currentPage() {
            return this.getData.page + 1;
        },
        totalPages() {
            var recordCount = parseInt(this.getData.RecordCount || 20);
            var rowCount = parseInt(this.data_row_count || 0);
            return Math.max(1, Math.ceil(rowCount / recordCount));
        },
        visiblePages() {
            var pages = [];
            var total = this.totalPages;
            var current = this.currentPage;
            if (total <= 7) {
                for (var i = 1; i <= total; i++) {
                    pages.push(i);
                }
                return pages;
            }
            pages.push(1);
            if (current > 4) {
                pages.push('...');
            }
            var start = Math.max(2, current - 1);
            var end = Math.min(total - 1, current + 1);
            for (var p = start; p <= end; p++) {
                pages.push(p);
            }
            if (current < total - 3) {
                pages.push('...');
            }
            pages.push(total);
            return pages;
        }
    },
    /*
    computed: {
        total_no_vat() {
            if (parseFloat(this.edit_row_data.bill_total) > 0 && parseFloat(this.edit_row_data.bill_vat) > -1) {
                return (parseFloat(this.edit_row_data.bill_total) - parseFloat(this.edit_row_data.bill_vat)).toFixed(2) ;
            } else {
                return 0
            }
        }
    },
    */

}) ;
