/* مستودع التالف — القائمة والملخص والإخراج */
new Vue({
    el: '#app',
    data: {
        urls: DS_URLS,
        canManage: DS_CAN_MANAGE === 1,
        f: { q: '', supplier: '', state: 'in', sort: 'date', short: false },
        rows: [],
        count: 0,
        page: 0,
        per: 50,
        busy: false,
        summaryRows: [],
        exits: [],
        suppliers: [],
        line: null,
        exitForm: { qty: '', reason: '', note: '' },
        saving: false,
        searchTimer: null,
        listSeq: 0
    },
    computed: {
        pages: function () {
            return Math.max(Math.ceil(this.count / this.per), 1);
        },
        // صفوف الملخص للمورد المختار فقط، أو كلها
        pickedRows: function () {
            var sup = String(this.f.supplier || '');
            if (!sup) return this.summaryRows;
            return this.summaryRows.filter(function (r) { return String(r.supplier) === sup; });
        },
        kpi: function () {
            return this.pickedRows.reduce(function (t, r) {
                t.lines += parseInt(r.lines || 0, 10);
                t.qty += parseFloat(r.qty || 0);
                t.value += parseFloat(r.value || 0);
                t.value_vat += parseFloat(r.value_vat || 0);
                t.short += parseInt(r.short || 0, 10);
                return t;
            }, { lines: 0, qty: 0, value: 0, value_vat: 0, short: 0 });
        },
        maxValue: function () {
            return this.summaryRows.reduce(function (m, r) { return Math.max(m, parseFloat(r.value || 0)); }, 0);
        },
        // ما خرج من المستودع مجمّعاً حسب السبب للمورد المختار
        exitsView: function () {
            var sup = String(this.f.supplier || ''), acc = {}, out = [];
            this.exits.forEach(function (e) {
                if (sup && String(e.supplier) !== sup) return;
                if (!acc[e.reason]) {
                    acc[e.reason] = { reason: e.reason, label: e.label, qty: 0, value: 0 };
                    out.push(acc[e.reason]);
                }
                acc[e.reason].qty += parseFloat(e.qty || 0);
                acc[e.reason].value += parseFloat(e.value || 0);
            });
            return out;
        }
    },
    mounted: function () {
        this.loadSuppliers();
        this.reload();
    },
    methods: {
        // الكميات: حتى منزلتين بلا أصفار زائدة
        fmt: function (v) {
            var n = parseFloat(v || 0);
            return (Math.round(n * 100) / 100).toLocaleString('en-US');
        },
        // المبالغ: منزلتان دائماً
        money: function (v) {
            return (parseFloat(v || 0)).toLocaleString('en-US',
                { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        pct: function (v) {
            return this.maxValue ? Math.round((parseFloat(v || 0) / this.maxValue) * 100) : 0;
        },
        query: function (extra) {
            var p = new URLSearchParams();
            p.set('q', this.f.q || '');
            p.set('supplier', this.f.supplier || '');
            p.set('state', this.f.state);
            p.set('sort', this.f.sort);
            p.set('short', this.f.short ? '1' : '');
            Object.keys(extra || {}).forEach(function (k) { p.set(k, extra[k]); });
            return p.toString();
        },
        reload: function () {
            this.loadSummary();
            this.loadLines(0);
        },
        searchLater: function () {
            var self = this;
            clearTimeout(self.searchTimer);
            self.searchTimer = setTimeout(function () { self.reload(); }, 400);
        },
        loadSuppliers: function () {
            var self = this;
            Api.get(DS_URLS.suppliers).then(function (resp) {
                if (Api.isOk(resp)) self.suppliers = Api.getData(resp) || [];
            });
        },
        loadSummary: function () {
            var self = this;
            Api.get(DS_URLS.summary + '?' + this.query()).then(function (resp) {
                if (!Api.isOk(resp)) { Api.showError(resp); return; }
                var d = Api.getData(resp) || {};
                self.summaryRows = d.rows || [];
                self.exits = d.exits || [];
            });
        },
        loadLines: function (p) {
            var self = this, seq = ++self.listSeq;
            self.page = Math.max(p || 0, 0);
            self.busy = true;
            Api.get(DS_URLS.lines + '?' + this.query({ page: self.page, per: self.per })).then(function (resp) {
                if (seq !== self.listSeq) return;  // رد قديم وصل بعد طلب أحدث
                self.busy = false;
                if (!Api.isOk(resp)) { Api.showError(resp); return; }
                self.rows = Api.getData(resp) || [];
                self.count = resp.count || 0;
            });
        },
        pickSupplier: function (id) {
            this.f.supplier = String(this.f.supplier) === String(id) ? '' : String(id);
            this.loadLines(0);
        },
        exportExcel: function () {
            window.open(DS_URLS.excel + '?' + this.query(), '_blank');
        },
        openLine: function (r) {
            var self = this;
            Api.get(DS_URLS.detail + '/' + r.id).then(function (resp) {
                if (!Api.isOk(resp)) { Api.showError(resp); return; }
                self.line = Api.getData(resp);
                self.exitForm = { qty: self.line.remaining, reason: '', note: '' };
            });
        },
        closeLine: function () {
            if (this.saving) return;
            this.line = null;
        },
        saveExit: function () {
            var self = this, line = this.line;
            var qty = parseFloat(this.exitForm.qty);
            if (!(qty > 0)) { Swal.fire('تنبيه', 'أدخل كمية أكبر من صفر', 'warning'); return; }
            if (qty > line.remaining + 1e-6) {
                Swal.fire('تنبيه', 'الكمية أكبر من المتبقي في المستودع (' + self.fmt(line.remaining) + ')', 'warning');
                return;
            }
            if (!this.exitForm.reason) { Swal.fire('تنبيه', 'اختر سبب الإخراج', 'warning'); return; }
            if (this.exitForm.reason === 'correction' && !String(this.exitForm.note || '').trim()) {
                Swal.fire('تنبيه', 'التصحيح يحتاج ملاحظة توضّح سببه', 'warning');
                return;
            }
            var fd = new FormData();
            fd.append('line_id', line.id);
            fd.append('qty', qty);
            fd.append('reason', this.exitForm.reason);
            fd.append('note', this.exitForm.note || '');
            self.saving = true;
            Api.post(DS_URLS.exit, fd).then(function (resp) {
                self.saving = false;
                if (!Api.isOk(resp)) { Api.showError(resp); return; }
                Api.showSuccess(resp.mess);
                self.line = null;
                self.reload();
            });
        }
    }
});
