# -*- coding: utf-8 -*-
"""تنظيف بيانات الأصناف — تسوية فرع (البند الرابع، قرارات المالك 2026-09-17).

المنطق كله في modules/item_cleanup.py، وهو نفسه الذي ينفّذه زر التسوية في شاشة
جودة بيانات الأصناف — فلا يختلف سطر الأوامر عن الشاشة.

الإصلاحات: names (مسافات الأسماء)، vat (نسبة الدفعات الفارغة)، barcodes (الباركود
القصير أو الوهمي يُستبدل بباركود داخلي)، realign (الدفعات المنفصلة عن صنفها)،
dormant (إيقاف الراكد)، reactivate (رفع الإيقاف عن الموقوف النشط). ويمكن تسمية
supplier لتشغيل تسوية المورد معها.

لا يغيّر بنية القاعدة ولا يحذف صفاً: تحديث قيم وإضافة باركود سابق وسجل إيقاف فقط. ولا يمس
الكميات ولا دفتر الحركات — يتحقق من ذلك قبل الالتزام ويتراجع كاملاً إن اختلّ شيء.

  الوضع الافتراضي: تقرير فقط، لا يكتب حرفاً في القاعدة.
  للتنفيذ: apply، ويمكن تحديد إصلاحات بعينها بعده.

التشغيل من مجلد web2py:
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/item_data_cleanup.py
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/item_data_cleanup.py -A apply
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/item_data_cleanup.py -A apply names vat

قبل الكتابة تُحفظ القيم القديمة في private/item_data_cleanup_<الوقت>.json للتراجع،
وملف إكسل بالأصناف التي استُبدل باركودها. آمن للإعادة.
"""
import sys

import item_cleanup

ARGS = [str(a).strip().lower() for a in sys.argv[1:]]
APPLY = "apply" in ARGS
DEFAULT = ["names", "vat", "barcodes", "realign", "dormant", "reactivate"]
ACTIONS = [a for a in item_cleanup.ACTION_KEYS if a in ARGS] or DEFAULT

plans = item_cleanup.plan(db, ACTIONS)
titles = {a["key"]: a["title"] for a in item_cleanup.ACTIONS}

print("\n" + "=" * 66)
print("تنظيف بيانات الأصناف — %s — %s" % ("تنفيذ" if APPLY else "تقرير فقط", "، ".join(ACTIONS)))
print("=" * 66)
for key in ACTIONS:
    print("%-9s %s" % (key, plans[key]["note"]))

if not APPLY:
    print("\nلم يُكتب شيء. للتنفيذ: أضف -A apply")
    db.rollback()
elif not any(plans[k]["count"] for k in ACTIONS):
    print("\nلا يوجد ما يُصلح.")
    db.rollback()
else:
    res = item_cleanup.apply(db, request.folder, request.now, ACTIONS)
    if res["problems"]:
        print("\nأُلغي التنفيذ كاملاً ولم يُكتب شيء: " + " | ".join(res["problems"]))
    else:
        print("\nتم، والأرصدة والحركات كما هي:")
        for key, n in res["applied"].items():
            print("  %-9s %d  (%s)" % (key, n, titles[key]))
        if res.get("aliases"):
            print("  باركود سابق أُضيف من الدفعات المنفصلة: %d" % res["aliases"])
        print("نسخة التراجع: private/%s" % res["backup"])
        if res["excel"]:
            print("ملف الباركود المستبدل: private/%s" % res["excel"])
