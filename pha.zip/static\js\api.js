/**
 * مساعد استجابات APIs الموحد
 * Unified API Response Helper
 *
 * يعمل مع كل الأنماط القديمة والجديدة أثناء فترة التحويل
 */
var Api = {
    /**
     * التحقق من نجاح الاستجابة
     * يدعم: ok===true, status===1, status==='success', id>0
     */
    isOk: function (d) {
        if (!d) return false;
        if (d.ok === true) return true;
        if (d.status === 1 || d.status === 'success') return true;
        if (d.id && d.id > 0 && !d.mess) return true;
        return false;
    },

    /**
     * استخراج رسالة الخطأ
     */
    getError: function (d) {
        if (!d) return 'حصل خطأ في الاتصال';
        return d.mess || d.message || d.error || 'حصل خطأ';
    },

    /**
     * استخراج البيانات (data) من الاستجابة
     */
    getData: function (d) {
        if (!d) return null;
        return d.data !== undefined ? d.data : d;
    },

    /**
     * عرض رسالة خطأ بـ SweetAlert2
     */
    showError: function (d) {
        Swal.fire('تنبيه', Api.getError(d), 'error');
    },

    /**
     * عرض رسالة نجاح بـ SweetAlert2
     */
    showSuccess: function (mess) {
        Swal.fire({ icon: 'success', title: mess || 'تمت العملية بنجاح', showConfirmButton: false, timer: 1500 });
    },

    /**
     * fetch موحد مع معالجة أخطاء تلقائية
     * Api.post(url, formData).then(function(data) { if (Api.isOk(data)) ... })
     */
    post: function (url, body) {
        return fetch(url, { method: 'POST', body: body })
            .then(function (r) { return r.json(); })
            .catch(function () {
                Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                return { ok: false, status: 0, mess: 'خطأ في الاتصال', data: null };
            });
    },

    /**
     * fetch GET موحد
     */
    get: function (url) {
        return fetch(url)
            .then(function (r) { return r.json(); })
            .catch(function () {
                Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                return { ok: false, status: 0, mess: 'خطأ في الاتصال', data: null };
            });
    }
};
