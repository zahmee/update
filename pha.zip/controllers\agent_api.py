# -*- coding: utf-8 -*-
#  type: ignore
"""
واجهة برمجية للوكيل الخارجي (AI Agent — Hermes ... إلخ) — قراءة فقط
External AI Agent API — read-only endpoints.

المصادقة: مفتاح ثابت في Authorization header (انظر models/db_7_agent.py).
عمليات الكتابة (request_item / add_customer) في controller منفصل: agent_api_write.py

نقاط النهاية (Endpoints):
  GET /asbab5/agent_api/search_item   ?q=<اسم أو باركود>&limit=10
  GET /asbab5/agent_api/item_stock    ?item_id=<باركود>  أو  ?id=<id>
  GET /asbab5/agent_api/item_alternatives ?id=<id> أو ?q=<اسم>&limit=5
  GET /asbab5/agent_api/customer_info ?mobile=05XXXXXXXX
  GET /asbab5/agent_api/tools         (مخطط الأدوات — بدون مفتاح، للاستيراد في المنصة)

الدوال المساعدة (agent_normalize_mobile / agent_valid_mobile) معرّفة في models/db_7_agent.py.
كل الاستجابات تتبع المغلّف الموحّد: {ok, status, mess, data}.
"""

import api_helpers as api


# JOIN يجلب آخر سعر/ضريبة فعليين لكل صنف من items_det (بطاقة الصنف غالباً 0)
_DET_JOIN = (
    " LEFT JOIN (SELECT DISTINCT ON (item_idr) item_idr,"
    " public_price AS det_price, vat AS det_vat, vat_in_public_price AS det_vat_incl"
    " FROM items_det"
    " WHERE public_price IS NOT NULL AND public_price > 0"
    " ORDER BY item_idr, id DESC) d ON d.item_idr = m.id"
)


def _resolve_price(det_price, main_price, det_vat, det_vat_incl):
    """يرجع (السعر الأساسي، نسبة الضريبة، مشمولة؟، السعر شامل الضريبة)."""
    base = float(det_price) if (det_price is not None and float(det_price or 0) > 0) \
        else float(main_price or 0)
    vat_rate = float(det_vat or 0)
    vat_included = str(det_vat_incl) in ("T", "True", "1", "true", "t")
    if vat_included or vat_rate <= 0:
        with_vat = round(base, 2)
    else:
        with_vat = round(base * (1 + vat_rate), 2)
    return round(base, 2), vat_rate, vat_included, with_vat


def _item_payload(row):
    stock = float(row["stock"] or 0)
    price, vat_rate, vat_included, price_with_vat = _resolve_price(
        row.get("det_price"), row.get("public_price"),
        row.get("det_vat"), row.get("det_vat_incl"),
    )
    return {
        "id": row["id"],
        "barcode": row["item_id"],
        "name": row["name"],
        "generic_name": row.get("generic_name") or "",
        "price": price,
        "vat_rate": vat_rate,
        "vat_included": vat_included,
        "price_with_vat": price_with_vat,
        "stock": round(stock, 2),
        "available": stock > 0,
        "halted": str(row["halt"]) in ("T", "True", "1", "true", "t"),
    }


# ===========================================================================
# 1) البحث عن صنف (بالاسم أو الباركود) مع السعر والتوفر
# ===========================================================================
@require_agent_key
def search_item():
    q = (request.vars.q or "").strip()
    try:
        limit = min(int(request.vars.limit or 10), 50)
    except (TypeError, ValueError):
        limit = 10

    if not q:
        return response.json(api.api_error(mess="يجب تحديد نص البحث (q)"))

    conditions = []
    params = []
    for word in q.lower().split()[:4]:
        pattern = "%" + word + "%"
        conditions.append(
            "(LOWER(COALESCE(m.name, '')) LIKE %s"
            " OR m.item_id LIKE %s"
            " OR LOWER(COALESCE(m.generic_name, '')) LIKE %s"
            " OR LOWER(COALESCE(tg.tags, '')) LIKE %s)"
        )
        params.extend([pattern, pattern, pattern, pattern])

    where = "WHERE " + " AND ".join(conditions)
    sql = (
        "SELECT m.id, m.item_id, m.name, m.generic_name, m.public_price, m.halt,"
        " COALESCE(s.stock, 0) AS stock,"
        " d.det_price, d.det_vat, d.det_vat_incl"
        " FROM items_main m"
        " LEFT JOIN (SELECT item_idr, SUM(items_count) AS stock"
        "            FROM items_det GROUP BY item_idr) s ON s.item_idr = m.id"
        " LEFT JOIN item_tags tg ON tg.item_idr = m.id"
        + _DET_JOIN +
        " " + where +
        " ORDER BY m.name ASC LIMIT %s"
    )
    params.append(limit)

    rows = db.executesql(sql, placeholders=params, as_dict=True)
    result = [_item_payload(r) for r in rows]

    return response.json(api.api_list(rows=result, count=len(result)))


# ===========================================================================
# 2) توفر المخزون لصنف محدد
# ===========================================================================
@require_agent_key
def item_stock():
    item_id = (request.vars.item_id or "").strip()
    row_id = request.vars.id

    if row_id:
        item = db.items_main(int(row_id)) if str(row_id).isdigit() else None
    elif item_id:
        item = db(db.items_main.item_id == item_id).select().first()
    else:
        return response.json(api.api_error(mess="يجب تحديد item_id (باركود) أو id"))

    if not item:
        return response.json(api.api_error(mess="الصنف غير موجود"))

    stock = db(db.items_det.item_idr == item.id).select(
        db.items_det.items_count.sum()
    ).first()[db.items_det.items_count.sum()] or 0

    # آخر سعر/ضريبة فعليين من تفاصيل التوريد
    det = db.executesql(
        "SELECT public_price, vat, vat_in_public_price FROM items_det"
        " WHERE item_idr = %s AND public_price IS NOT NULL AND public_price > 0"
        " ORDER BY id DESC LIMIT 1",
        placeholders=[item.id], as_dict=True,
    )
    det0 = det[0] if det else {}

    return response.json(api.api_ok(data=_item_payload({
        "id": item.id,
        "item_id": item.item_id,
        "name": item.name,
        "generic_name": item.generic_name,
        "public_price": item.public_price,
        "halt": item.halt,
        "stock": stock,
        "det_price": det0.get("public_price"),
        "det_vat": det0.get("vat"),
        "det_vat_incl": det0.get("vat_in_public_price"),
    })))


# ===========================================================================
# 3) بدائل / أصناف مشابهة متوفرة لصنف غير متوفر
# ===========================================================================
@require_agent_key
def item_alternatives():
    q = (request.vars.q or "").strip()
    generic_name = (request.vars.generic_name or "").strip()
    item_id = (request.vars.item_id or "").strip()
    row_id = request.vars.id
    try:
        limit = min(int(request.vars.limit or 5), 20)
    except (TypeError, ValueError):
        limit = 5

    source_item = None
    if row_id and str(row_id).isdigit():
        source_item = db.items_main(int(row_id))
    elif item_id:
        source_item = db(db.items_main.item_id == item_id).select().first()

    if source_item:
        generic_name = (source_item.generic_name or "").strip()
        if not q:
            q = source_item.name or ""

    conditions = ["COALESCE(s.stock, 0) > 0", "COALESCE(m.halt, 'F') <> 'T'"]
    params = []
    match_basis = "name"

    if generic_name:
        conditions.append("LOWER(COALESCE(m.generic_name, '')) = %s")
        params.append(generic_name.lower())
        match_basis = "generic_name"
    elif q:
        word_conditions = []
        for word in q.lower().split()[:4]:
            pattern = "%" + word + "%"
            word_conditions.append(
                "(LOWER(COALESCE(m.name, '')) LIKE %s"
                " OR LOWER(COALESCE(m.generic_name, '')) LIKE %s)"
            )
            params.extend([pattern, pattern])
        if word_conditions:
            conditions.append("(" + " AND ".join(word_conditions) + ")")
    else:
        return response.json(api.api_error(mess="يجب تحديد الصنف أو الاسم للبحث عن بدائل"))

    if source_item:
        conditions.append("m.id <> %s")
        params.append(source_item.id)

    params.append(limit)
    sql = (
        "SELECT m.id, m.item_id, m.name, m.generic_name, m.public_price, m.halt,"
        " COALESCE(s.stock, 0) AS stock,"
        " d.det_price, d.det_vat, d.det_vat_incl"
        " FROM items_main m"
        " LEFT JOIN (SELECT item_idr, SUM(items_count) AS stock"
        "            FROM items_det GROUP BY item_idr) s ON s.item_idr = m.id"
        + _DET_JOIN +
        " WHERE " + " AND ".join(conditions) +
        " ORDER BY COALESCE(s.stock, 0) DESC, m.name ASC LIMIT %s"
    )
    rows = db.executesql(sql, placeholders=params, as_dict=True)
    result = [_item_payload(r) for r in rows]
    return response.json(api.api_list(rows=result, count=len(result), match_basis=match_basis))


# ===========================================================================
# 4) بيانات العميل + رصيد الحساب (بحث بالجوال)
# ===========================================================================
@require_agent_key
def customer_info():
    mobile = agent_normalize_mobile(request.vars.mobile)
    if not mobile:
        return response.json(api.api_error(mess="يجب تحديد رقم الجوال (mobile)"))

    cust = db(db.customers.mobile == mobile).select().first()
    if not cust:
        return response.json(api.api_error(mess="لا يوجد عميل بهذا الرقم"))

    return response.json(api.api_ok(data={
        "id": cust.id,
        "name": cust.name,
        "mobile": cust.mobile,
        "total_purchases": float(cust.total or 0),
        "total_paid": float(cust.payed or 0),
        "total_returns": float(cust.returns or 0),
        "balance_due": float(cust.amount or 0),
    }))


# ===========================================================================
# 5) مخطط الأدوات (Tool schema) — بدون مفتاح، لاستيراده في منصة الوكيل
# ===========================================================================
def tools():
    # عنوان الخادم: من appconfig.ini [agent] base_url إن وُجد، وإلا من عنوان الطلب
    origin = (agent_base_url or "").strip().rstrip("/")

    def _build(controller, fn):
        if origin:
            return origin + URL(c=controller, f=fn)  # /asbab5/<c>/<fn>
        return URL(c=controller, f=fn, scheme=True, host=True)

    def _u(fn):
        return _build("agent_api", fn)

    def _uw(fn):
        return _build("agent_api_write", fn)

    schema = [
        {
            "name": "search_item",
            "description": "البحث عن صنف في الصيدلية بالاسم أو الباركود أو الاسم العلمي مع السعر والتوفر",
            "method": "GET",
            "url": _u("search_item"),
            "parameters": {
                "q": "نص البحث (اسم الصنف أو الباركود) — مطلوب",
                "limit": "عدد النتائج (اختياري، الافتراضي 10، الأقصى 50)",
            },
        },
        {
            "name": "item_stock",
            "description": "معرفة الكمية المتاحة والسعر لصنف محدد",
            "method": "GET",
            "url": _u("item_stock"),
            "parameters": {
                "item_id": "الباركود / رقم الصنف",
                "id": "المعرّف الداخلي (بديل عن item_id)",
            },
        },
        {
            "name": "item_alternatives",
            "description": "البحث عن أصناف مشابهة ومتوفرة في النظام عند عدم توفر الصنف المطلوب. ليست توصية طبية؛ يعرض فقط ما هو موجود في قاعدة البيانات.",
            "method": "GET",
            "url": _u("item_alternatives"),
            "parameters": {
                "id": "المعرّف الداخلي للصنف الأصلي (مفضل إذا كان معروفاً)",
                "item_id": "باركود الصنف الأصلي",
                "generic_name": "الاسم العلمي إن كان معروفاً",
                "q": "اسم الصنف إذا لم يتوفر id أو item_id",
                "limit": "عدد النتائج (اختياري، الافتراضي 5، الأقصى 20)",
            },
        },
        {
            "name": "customer_info",
            "description": "جلب بيانات عميل ورصيد حسابه عبر رقم الجوال",
            "method": "GET",
            "url": _u("customer_info"),
            "parameters": {"mobile": "رقم جوال العميل 05XXXXXXXX — مطلوب"},
        },
        {
            "name": "request_item",
            "description": "تسجيل طلب صنف غير متوفر حالياً في الصيدلية",
            "method": "POST",
            "url": _uw("request_item"),
            "parameters": {
                "name": "اسم الصنف المطلوب — مطلوب",
                "item_id": "الباركود (اختياري)",
                "customer_mobile": "جوال العميل لإشعاره لاحقاً (اختياري)",
                "customer_name": "اسم العميل (اختياري)",
                "notes": "ملاحظات: تركيز، نوع... (اختياري)",
            },
        },
        {
            "name": "add_customer",
            "description": "إضافة عميل جديد (الاسم + الجوال) إذا لم يكن مسجلاً مسبقاً",
            "method": "POST",
            "url": _uw("add_customer"),
            "parameters": {
                "name": "اسم العميل — مطلوب",
                "mobile": "رقم الجوال 05XXXXXXXX — مطلوب",
            },
        },
        {
            "name": "update_customer_name",
            "description": "تصحيح اسم عميل موجود عبر رقم الجوال عندما يصرّح العميل أن الاسم المسجل غير صحيح.",
            "method": "POST",
            "url": _uw("update_customer_name"),
            "parameters": {
                "mobile": "رقم جوال العميل 05XXXXXXXX — مطلوب",
                "name": "الاسم الصحيح كما ذكره العميل — مطلوب",
            },
        },
    ]
    return response.json(api.api_ok(data={
        "auth": "Authorization: Bearer <api_key>",
        "envelope": {"ok": "bool", "status": "1/0", "mess": "str", "data": "..."},
        "tools": schema,
    }))
