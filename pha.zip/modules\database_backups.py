# -*- coding: utf-8 -*-
"""Private database archives; never place a database dump under static/."""

import os
import re
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from uuid import uuid4


BACKUP_NAME = re.compile(r"db_[0-9]{8}_[0-9]{6}_[0-9a-f]{32}\.tar")


class BackupError(Exception):
    """A backup could not be completed; no partial archive is downloadable."""


def _directory(app_folder):
    return Path(app_folder).resolve() / "private" / "backups"


def _new_name(now):
    return "db_%s_%s.tar" % (now.strftime("%Y%m%d_%H%M%S"), uuid4().hex)


def migrate_public_backup(app_folder, now=None):
    """Move the exact legacy public file, preserving its contents. Idempotent."""
    old_path = Path(app_folder).resolve() / "static" / "db.tar"
    if not old_path.exists():
        return None
    if old_path.is_symlink() or not old_path.is_file():
        raise BackupError("Unexpected legacy backup path")
    directory = _directory(app_folder)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    name = _new_name(now or datetime.now())
    old_path.replace(directory / name)
    os.chmod(directory / name, 0o600)
    return name


def create_backup(app_folder, connection, now):
    """Publish an archive only after pg_dump succeeds; keep prior archives."""
    temporary_path = None
    try:
        migrate_public_backup(app_folder, now)
        directory = _directory(app_folder)
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        name = _new_name(now)
        descriptor, temporary_path = tempfile.mkstemp(
            prefix=".db_", suffix=".part", dir=str(directory)
        )
        env = {**os.environ, "PGPASSWORD": connection["password"]}
        with os.fdopen(descriptor, "wb") as output:
            result = subprocess.run(
                [
                    "pg_dump", "--no-password",
                    "-h", connection["host"], "-p", str(connection["port"]),
                    "-U", connection["user"], "-F", "t", connection["dbname"],
                ],
                env=env, stdout=output, stderr=subprocess.PIPE, timeout=900,
            )
        if result.returncode != 0 or os.path.getsize(temporary_path) == 0:
            raise BackupError("Database backup failed")
        os.replace(temporary_path, directory / name)
        return name
    except (OSError, subprocess.SubprocessError) as exc:
        raise BackupError("Database backup failed") from exc
    finally:
        if temporary_path and os.path.exists(temporary_path):
            os.remove(temporary_path)


def backup_path(app_folder, name):
    """Resolve only a completed archive name, never a caller-supplied path."""
    if not isinstance(name, str) or not BACKUP_NAME.fullmatch(name):
        raise FileNotFoundError("Backup not found")
    directory = _directory(app_folder).resolve()
    path = directory / name
    if path.is_symlink() or path.resolve().parent != directory or not path.is_file():
        raise FileNotFoundError("Backup not found")
    return str(path)
