# -*- coding: utf-8 -*-
#  type: ignore
import math
import threading

import api_helpers as api

_lock = threading.RLock()


@can_access(3001)
def main():
    sc = screens_rules(3001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


@can_access(3001)
def t1():
    return dict()


@can_access(3006)
def new_items_det():
    return dict()


# ==============================================
# ==============================================
# ==============================================
# ==============================================
# ==============================================


@can_access(3006)
def det_items():
    return dict()


# ++++++++++++++++++++++
@can_access(3006)
def get_itm_2():
    qry = (
        "select (select name from items_main where item_id= items_det.item_id limit 1) as name , (select name from suppliers where id=(select supplier from suppliers_bills where id= items_det.supplier_inv )) as supp , *  from items_det where id ="
        " %s ;"
    )
    qs = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(qs)


# ----------------------------------------------------------------------------------------------------------
@can_access(3001)
def main_it():
    headers = {"main_items.item_id": "رقم الصنف", "main_items.name": "اسم الصنف"}
    fields = [db.main_items.item_id, db.main_items.name]
    return dict(
        grid=SQLFORM.grid(
            db.main_items,
            user_signature=False,
            headers=headers,
            fields=fields,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=False,
            maxtextlengths={"main_items.name": 200},
        )
    )


@can_access(3004)
def de_it():
    return dict()


@can_access(3005)
def it_inv():
    it_inv = db.suppliers_bills(request.args(0))
    if it_inv == None:
        redirect(URL("not_inv"))
    if it_inv.bill_confirmation == True:
        redirect(URL("not_inv"))
    return dict()


@can_access(3004)
def not_inv():
    return dict(message="لا يوجد فاتورة بهذا الرقم")


@can_access(3005)
def inter():
    return dict()


# ---------------------------------------------------------------------------------------------
#    دوال شاشة اضافة الأصناف


@can_access(3005)
def mit():
    qry = (
        "select item_id,name from main_items where name like %s LIMIT 15;"
    )
    qs = db.executesql(qry, placeholders=['%' + request.vars.it + '%'], as_dict=True)
    return response.json(qs)


@can_access(3007)
def t():
    qry = "select sum(inv_price) from items_det where supplier_inv = 1 ;"
    qs = db.executesql(qry)
    # s = db(db.items_det(db.items_det.supplier_inv==1)).select()
    # inv_p = db.items_det.inv_price.sum()
    return str(qs[(0)])


# بدون صلاحية عمداً: خدمة قراءة فقط لطباعة الباركود (it_prt.svc/<رقم فاتورة التوريد>)
def it_prt():
    db1 = db(
        (db.items_det.item_id == db.items_main.item_id)
        & (db.items_det.supplier_inv == request.args(0))
    ).select(
        db.items_det.item_id,
        db.items_det.id,
        db.items_main.name,
        db.items_det.items_count,
        db.items_det.public_price,
        db.items_det.vat,
        db.items_det.vat_in_public_price,
        db.items_det.quantity,
        orderby=db.items_det.id,
    )
    for r in db1:
        r.items_det.public_price = round(
            (r.items_det.public_price * r.items_det.vat) + r.items_det.public_price, 2
        )
        r.items_det.items_count = r.items_det.quantity
        if r.items_det.vat_in_public_price == True:
            new_price = round((r.items_det.public_price / (r.items_det.vat + 1)), 2)
            r.items_det.public_price = new_price
    return str(db1)


@can_access(2012)
def it_prt_by_item():
    # q1 = db(db.items_main.item_id == request.args(0))
    try:
        itm1 = db(db.items_main.id == request.args(0)).select().first()
        itm2 = db(db.items_det.item_idr == itm1.id).select().last()
        db1 = db(
            (db.items_det.item_id == db.items_main.item_id)
            & (db.items_det.supplier_inv == itm2.supplier_inv)
            & (db.items_det.id == itm2.id)
        ).select(
            db.items_det.item_id,
            db.items_det.id,
            db.items_main.name,
            db.items_det.items_count,
            db.items_det.public_price,
        )
        return str(db1)
    except Exception as e:
        print(e)
        return str("رقم الصنف المدخل خطأ ، الرجاء ادخال الرقم الدولي ")


@can_access(2012)
def it_rep1():
    from datetime import date, timedelta

    inv_id = int(request.args(0) or 0)
    bill = db.suppliers_bills(inv_id)
    if not bill:
        return dict(message="الفاتورة غير موجودة")

    rows = db(db.items_det.supplier_inv == inv_id).select(orderby=db.items_det.id)

    items = []
    # FULL totals (based on quantity, no return deduction)
    purchase_without_vat = 0.0
    purchase_vat = 0.0
    sale_without_vat = 0.0
    sale_vat = 0.0
    public_price_before_vat = 0.0
    public_price_after_vat = 0.0
    increase_amount = 0.0

    # NET totals (after deducting returns)
    net_purchase_without_vat = 0.0
    net_purchase_vat = 0.0
    net_sale_without_vat = 0.0
    net_sale_vat = 0.0

    # RETURN totals
    return_qty_total = 0.0
    return_purchase_without_vat = 0.0
    return_purchase_vat = 0.0
    return_sale_without_vat = 0.0
    return_sale_vat = 0.0

    for idx, row in enumerate(rows, start=1):
        item_main = db.items_main(row.item_idr)
        item_name = item_main.name if item_main else ""

        # Fetch last 5 buy prices for this item (safe parameterized query)
        price_history = db.executesql(
            "SELECT buy_price FROM items_det WHERE item_idr=%s AND buy_price > 0 ORDER BY id DESC LIMIT 5",
            placeholders=[row.item_idr],
            as_dict=True,
        )

        current_buy = round(float(row.buy_price or 0), 2)
        low_price = current_buy
        for ph in price_history:
            ph_price = round(float(ph["buy_price"]), 2)
            if low_price > ph_price:
                low_price = ph_price

        # Supplier name
        supplier_name = ""
        if item_main and item_main.suppliers:
            sup = db.suppliers(item_main.suppliers)
            if sup:
                supplier_name = sup.name

        # Expiry warning
        expiry_warning = False
        if row.expiration_date and row.expiration_date <= (date.today() + timedelta(days=300)):
            expiry_warning = True

        # Buy price highlight logic
        buy_price_highlight = "danger" if (low_price != current_buy and low_price > 0) else "normal"
        price_diff = round(current_buy - low_price, 2) if buy_price_highlight == "danger" else 0.0
        price_diff_pct = round((price_diff / (low_price or 1)) * 100, 2) if price_diff else 0.0

        quantity = float(row.quantity or 0)
        return_count = float(row.return_count or 0)
        net_qty = max(quantity - return_count, 0)

        # Public price calculations
        public_price = float(row.public_price or 0)
        vat_rate = float(row.vat or 0)

        if row.vat_in_public_price:
            public_before_vat = public_price / (1 + vat_rate) if vat_rate else public_price
            public_vat_amount = public_price - public_before_vat
            public_after_vat = public_price
        else:
            public_before_vat = public_price
            public_vat_amount = public_price * vat_rate
            public_after_vat = public_price + public_vat_amount

        profit_pct = round((((public_before_vat - current_buy) / (current_buy or 1)) * 100), 2)

        # FULL line totals (based on full quantity — no return deduction)
        line_purchase = float(row.inv_price or 0)
        line_purchase_vat = line_purchase * vat_rate
        line_sale_without_vat = public_before_vat * quantity
        line_sale_with_vat = public_after_vat * quantity
        line_profit = line_sale_without_vat - line_purchase

        # NET line totals (after returns)
        net_factor = (net_qty / quantity) if quantity > 0 else 0
        net_line_purchase = line_purchase * net_factor
        net_line_purchase_vat = line_purchase_vat * net_factor
        net_line_sale_without_vat = public_before_vat * net_qty
        net_line_sale_vat = public_vat_amount * net_qty

        # RETURN line totals
        return_line_purchase = line_purchase - net_line_purchase
        return_line_purchase_vat = line_purchase_vat - net_line_purchase_vat
        return_line_sale_without_vat = public_before_vat * return_count
        return_line_sale_vat = public_vat_amount * return_count

        # Profit highlight class
        if profit_pct > 25:
            profit_class = "success"
        elif profit_pct > 16:
            profit_class = "normal"
        elif profit_pct < 1:
            profit_class = "danger"
        else:
            profit_class = "warning"

        # Return count highlight
        return_highlight = return_count > 0

        # Increase amount (price difference * full quantity)
        if buy_price_highlight == "danger":
            increase_amount += price_diff * quantity

        # FULL running totals (based on full quantity)
        purchase_without_vat += line_purchase
        purchase_vat += line_purchase_vat
        sale_without_vat += line_sale_without_vat
        sale_vat += public_vat_amount * quantity
        public_price_before_vat += public_before_vat * quantity
        public_price_after_vat += line_sale_with_vat

        # NET running totals (after returns)
        net_purchase_without_vat += net_line_purchase
        net_purchase_vat += net_line_purchase_vat
        net_sale_without_vat += net_line_sale_without_vat
        net_sale_vat += net_line_sale_vat

        # RETURN running totals
        return_qty_total += return_count
        return_purchase_without_vat += return_line_purchase
        return_purchase_vat += return_line_purchase_vat
        return_sale_without_vat += return_line_sale_without_vat
        return_sale_vat += return_line_sale_vat

        items.append({
            "no": idx,
            "id": row.id,
            "item_idr": row.item_idr,
            "name": item_name,
            "expiry_date": row.expiration_date,
            "expiry_warning": expiry_warning,
            "vat": vat_rate,
            "buy_price": current_buy,
            "low_price": low_price,
            "buy_price_highlight": buy_price_highlight,
            "price_diff": price_diff,
            "price_diff_pct": price_diff_pct,
            "public_price": public_price,
            "vat_in_public_price": row.vat_in_public_price,
            "public_before_vat": round(public_before_vat, 2),
            "public_vat_amount": round(public_vat_amount, 2),
            "public_after_vat": public_after_vat,
            "profit_pct": profit_pct,
            "profit_class": profit_class,
            "return_count": return_count,
            "return_highlight": return_highlight,
            "quantity": quantity,
            "inv_price": line_purchase,
            "line_sale_without_vat": round(line_sale_without_vat, 2),
            "line_sale_with_vat": round(line_sale_with_vat, 2),
            "profit_line": round(line_profit, 2),
            "created_by": row.created_by,
            "price_history": price_history,
            "supplier_name": supplier_name,
            "public_price_before_vat_acc": round(public_price_before_vat, 2),
            "public_price_after_vat_acc": round(public_price_after_vat, 2),
        })

    # FULL summary (based on full quantity)
    purchase_with_vat = purchase_without_vat + purchase_vat
    sale_with_vat_total = sale_without_vat + sale_vat

    profit_without_vat = sale_without_vat - purchase_without_vat
    profit_with_vat = sale_with_vat_total - purchase_with_vat
    vat_diff = sale_vat - purchase_vat

    profit_ratio = 0.0
    if purchase_without_vat > 0:
        profit_ratio = min(100.0, round((profit_without_vat / purchase_without_vat) * 100, 2))

    # NET summary (after returns)
    net_purchase_with_vat = net_purchase_without_vat + net_purchase_vat
    net_sale_with_vat = net_sale_without_vat + net_sale_vat
    net_profit_without_vat = net_sale_without_vat - net_purchase_without_vat
    net_profit_with_vat = net_sale_with_vat - net_purchase_with_vat
    net_profit_ratio = 0.0
    if net_purchase_without_vat > 0:
        net_profit_ratio = min(
            100.0, round((net_profit_without_vat / net_purchase_without_vat) * 100, 2)
        )

    # RETURN summary
    return_purchase_with_vat = return_purchase_without_vat + return_purchase_vat
    return_sale_with_vat = return_sale_without_vat + return_sale_vat

    # Bill comparison (safe parameterized query)
    inv_bill_net = float(bill.bill_net_amount or 0.0)
    inv_bill_total = float(bill.bill_total or 0.0)

    sum_inv_price = db.items_det.inv_price.sum()
    total_inv_price = (
        db(db.items_det.supplier_inv == inv_id).select(sum_inv_price).first()[sum_inv_price] or 0.0
    )

    total_vat = 0.0
    for r in db(db.items_det.supplier_inv == inv_id).select():
        total_vat += float(r.inv_price or 0) * (r.vat or 0)

    def fmt(val):
        """تنسيق الرقم إلى منزلتين عشريتين مع فاصل آلاف"""
        try:
            return "{:,.2f}".format(float(val))
        except (TypeError, ValueError):
            return "0.00"

    # Helper لتحديد لون فرق الفاتورة
    diff_without_vat = round(total_inv_price - inv_bill_net, 2)
    diff_with_vat = round((total_vat + total_inv_price) - inv_bill_total, 2)

    def diff_class(diff_val):
        if abs(diff_val) < 0.01:
            return "success"
        return "danger" if diff_val > 0 else "warning"

    return dict(
        bill=bill,
        items=items,
        item_count=len(items),
        purchase_without_vat=round(purchase_without_vat, 2),
        purchase_with_vat=round(purchase_with_vat, 2),
        purchase_vat=round(purchase_vat, 2),
        sale_without_vat=round(sale_without_vat, 2),
        sale_with_vat=round(sale_with_vat_total, 2),
        sale_vat=round(sale_vat, 2),
        profit_without_vat=round(profit_without_vat, 2),
        profit_with_vat=round(profit_with_vat, 2),
        vat_diff=round(vat_diff, 2),
        profit_ratio=profit_ratio,
        public_price_before_vat=round(public_price_before_vat, 2),
        public_price_after_vat=round(public_price_after_vat, 2),
        increase_amount=round(increase_amount, 2),
        # NET totals (after returns)
        net_purchase_without_vat=round(net_purchase_without_vat, 2),
        net_purchase_with_vat=round(net_purchase_with_vat, 2),
        net_purchase_vat=round(net_purchase_vat, 2),
        net_sale_without_vat=round(net_sale_without_vat, 2),
        net_sale_with_vat=round(net_sale_with_vat, 2),
        net_sale_vat=round(net_sale_vat, 2),
        net_profit_without_vat=round(net_profit_without_vat, 2),
        net_profit_with_vat=round(net_profit_with_vat, 2),
        net_profit_ratio=net_profit_ratio,
        # RETURN totals
        return_qty_total=round(return_qty_total, 2),
        return_purchase_without_vat=round(return_purchase_without_vat, 2),
        return_purchase_with_vat=round(return_purchase_with_vat, 2),
        return_sale_without_vat=round(return_sale_without_vat, 2),
        return_sale_with_vat=round(return_sale_with_vat, 2),
        inv_bill_net=round(inv_bill_net, 2),
        inv_bill_total=round(inv_bill_total, 2),
        total_inv_price=round(float(total_inv_price), 2),
        total_vat=round(total_vat, 2),
        diff_without_vat=diff_without_vat,
        diff_with_vat=diff_with_vat,
        diff_class=diff_class,
        fmt=fmt,
    )


@can_access(3002)
def it_rep2():
    return dict()


@can_access(3009)
def rep_bydate():
    return dict()


def _expiry_rows(days):
    """أصناف قاربت الانتهاء أو انتهت حديثاً (خلال 20 يوماً) ولها رصيد.

    مشترك بين شاشة العرض (rep_bydatej) وتصدير الإكسل (rep_bydate_excel)
    حتى لا يفترق الشيت عن الشاشة.
    """
    qry = (
        "select (select upper(trim(name)) from items_main where id= items_det.item_idr ) as name ,  "
        " ( select name from key_type where id= (select item_type from items_main where id=item_idr ) )  "
        " as item_type , *   "
        " from items_det where expiration_date < (current_date + %s) and "
        " expiration_date >(current_date -20) and  items_count>0 order by expiration_date;"
    )
    return db.executesql(qry, placeholders=[days], as_dict=True)


def _expiry_days_arg(default=90):
    try:
        return max(0, int(request.args(0)))
    except (TypeError, ValueError):
        return default


@can_access(3013)
def rep_bydatej():
    return response.json(_expiry_rows(_expiry_days_arg()))


@can_access(3013)
def rep_bydate_excel():
    """تصدير الأصناف منتهية/قاربت الصلاحية إلى Excel، مع عمودَي ملاحظات فارغين."""
    import io as _io

    import xlsxwriter

    days = _expiry_days_arg()
    rows = _expiry_rows(days)

    buf = _io.BytesIO()
    wb = xlsxwriter.Workbook(buf, {"in_memory": True})
    ws = wb.add_worksheet("منتهي الصلاحية")
    ws.right_to_left()

    title = wb.add_format({"bold": True, "font_size": 13, "align": "center"})
    sub = wb.add_format({"align": "center", "font_color": "#555555"})
    head = wb.add_format({"bold": True, "bg_color": "#D9E1F2", "align": "center",
                          "border": 1, "text_wrap": True})
    note_head = wb.add_format({"bold": True, "bg_color": "#FFF2CC", "align": "center",
                               "border": 1})
    cell = wb.add_format({"border": 1})
    cell_c = wb.add_format({"border": 1, "align": "center"})
    num = wb.add_format({"border": 1, "align": "center", "num_format": "#,##0.00"})
    note_cell = wb.add_format({"border": 1, "bg_color": "#FFFDF5"})
    expired_c = wb.add_format({"border": 1, "align": "center",
                               "font_color": "#9C0006", "bold": True})

    ws.merge_range(0, 0, 0, 8, "الأصناف حسب تاريخ الإنتهاء", title)
    ws.merge_range(1, 0, 1, 8,
                   "خلال %d يوماً — تاريخ التقرير: %s"
                   % (days, request.now.strftime("%Y-%m-%d %H:%M")), sub)

    headers = ["م", "الباركود", "رقم الدفعة", "اسم الصنف", "التصنيف",
               "تاريخ الإنتهاء", "الكمية المتوفرة", "ملاحظة ١", "ملاحظة ٢"]
    hr = 3
    for i, h in enumerate(headers):
        ws.write(hr, i, h, note_head if h.startswith("ملاحظة") else head)

    today = request.now.date()
    for i, r in enumerate(rows):
        rw = hr + 1 + i
        exp = r.get("expiration_date")
        ws.write(rw, 0, i + 1, cell_c)
        ws.write(rw, 1, r.get("item_id") or "", cell_c)
        ws.write(rw, 2, r.get("id") or "", cell_c)
        ws.write(rw, 3, r.get("name") or "", cell)
        ws.write(rw, 4, r.get("item_type") or "", cell)
        # المنتهي فعلاً يظهر بالأحمر ليُفرز بالعين قبل الجرد الميداني
        ws.write(rw, 5, str(exp or ""), expired_c if (exp and exp < today) else cell_c)
        ws.write(rw, 6, float(r.get("items_count") or 0), num)
        ws.write_blank(rw, 7, None, note_cell)
        ws.write_blank(rw, 8, None, note_cell)

    ws.set_column(0, 0, 5)
    ws.set_column(1, 2, 14)
    ws.set_column(3, 3, 42)
    ws.set_column(4, 4, 18)
    ws.set_column(5, 6, 14)
    ws.set_column(7, 8, 24)
    ws.freeze_panes(hr + 1, 0)
    ws.autofilter(hr, 0, hr + len(rows), len(headers) - 1)
    wb.close()
    buf.seek(0)

    response.headers["Content-Type"] = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    fname = "expiry_%dd_%s.xlsx" % (days, request.now.strftime("%Y%m%d_%H%M%S"))
    response.headers["Content-Disposition"] = "attachment; filename=" + fname
    return buf.read()


# =================================================================================================
@can_access(3004)
def conf_inv():
    inv = request.args(0)
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv="
        " %s  )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv="
        " %s  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/ "
        " CASE sum(inv_price) WHEN 0 THEN 1 ELSE sum(inv_price) END )* CASE sum(inv_price) WHEN 0 THEN 1 ELSE 100 END from items_det where supplier_inv="
        " %s  )) "
        " where id= %s"
    )
    db.executesql(qry, placeholders=[inv, inv, inv, inv])
    db.suppliers_bills(request.args(0)).update_record(bill_confirmation=True)
    qry = db(db.items_det.supplier_inv == inv).select()
    # تسجيل حركة شراء للأسطر التي لم تُسجَّل بعد فقط.
    # الأسطر الجديدة تُسجَّل لحظة الإدخال في items_qry.addit، فتُتجاوز هنا.
    # هذا الفحص يجعل الاعتماد آمناً عند التكرار (لا حركات مزدوجة)، ويغطي
    # الفواتير القديمة التي أُدخلت قبل تفعيل التسجيل اللحظي.
    bill = db.suppliers_bills(inv)
    for row in qry:
        if stock_purchase_logged(row.id):
            continue
        db.items_movement.insert(
            item_main=row.item_idr,
            item_det=row.id,
            move_type="شراء",
            move_date=request.now,
            qty_in=float(row.quantity or 0), qty_out=0,
            unit_price=float(row.buy_price or 0),
            reference=bill.bill_no if bill else "",
            ref_no=str(inv),
        )
    # إصلاح الأرصدة السالبة لأصناف هذه الفاتورة — إعادة توزيع محايدة
    # لا تغيّر إجمالي أي صنف (الخوارزمية في models/db_8_stock.py).
    for row in qry:
        stock_repair_item(row.item_idr)
    db.commit()
    for itm in qry:
        if itm.return_count > 0:
            return redirect(URL("suppliers", "return_suppliers_bills_print/" + inv))
    return redirect(URL("items", "de_it"))


# ==================================================================================================
# ------------------>      تعديل بيانات صنف موجود
@can_access(3009)
def itm_chang():
    return dict()


@can_access(3009)
def getitm():
    it = db(
        (db.items_det.item_idr == db.items_main.id)
        & (db.items_det.id == request.args(0))
    ).select(
        db.items_det.id,
        db.items_det.items_count,
        db.items_main.name,
        db.items_det.expiration_date,
        db.items_det.public_price,
    )
    # it = db(db.items_det.item_id == request.args(0)).select().first()
    # it = db.items_det[request.args(0)]
    if it != None:
        return response.json([it])
    else:
        return response.json(0)


@can_access(3009)
def up_c():
    row = db.items_det(request.args(0, cast=int))
    if not row:
        return response.json("0")
    try:
        new_qty = float(request.args(1))
    except (TypeError, ValueError):
        return response.json("0")
    # التعديل يمر من الوحدة المركزية ليُسجَّل الفارق في دفتر الحركات
    stock_set(row, new_qty, "تعديل يدوي", "تعديل كمية صنف", str(row.id))
    db.commit()
    return response.json("1")


@can_access(3009)
def up_sp():
    qry = (
        "update items_det  set public_price ="
        " %s where id ="
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(1), request.args(0)])
    return response.json("1")


@can_access(3009)
def up_ed():
    qry = (
        "update items_det  set expiration_date ="
        " %s::date where id ="
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(1), request.args(0)])
    return response.json("1")


# @auth.requires_membership("user1")
@can_access(3002)
def itm_rep():
    return dict()


# =================================================================================================
#                                        جداول الجرد
# =================================================================================================
@can_access(5200)
def inventory():
    if auth.has_membership("admin"):
        db.inventory.to_user.readable = False
        links = [
            lambda row: A(
                I(_class="fal fa-list"),
                "قوائم الجرد",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-repeat-alt"),
                "التكرار",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_dup_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-compass-slash"),
                "المفقود",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_not_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-print"),
                "طباعة",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_print_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-thumbs-up"),
                "اعتماد الجميع",
                _class="btn btn-outline-secondary",
                _href=URL("items", "inventory_items_approve_all", args=[row.id]),
            ),
        ]
        return dict(
            grid=SQLFORM.grid(
                db.inventory,
                user_signature=False,
                editable=True,
                paginate=200,
                links=links,
                deletable=False,
                create=True,
                csv=False,
                showbuttontext=True,
                maxtextlengths={"inventory.name": 200},
            )
        )
    elif auth.has_membership("user1"):
        q = db.inventory.open == True
        links = [
            lambda row: A(
                SPAN("قوائم الجرد", _class="btn btn-info", _title="الاصناف المجرودة"),
                _href=URL("items", "inventory_items", args=[row.id]),
            )
        ]
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                links=links,
                deletable=False,
                create=False,
                csv=False,
                showbuttontext=True,
                maxtextlengths={"inventory.name": 200},
            )
        )


@can_access(5200)
def inventory_items():
    q = db.inventory_items.inventory == request.args(0)
    if db.inventory[request.args(0)].open == False:
        return redirect(URL("items", "inventory"))
    if auth.has_membership("admin"):
        db.inventory_items.inventory.readable = False
        db.inventory_items.inventory.writable = False
        db.inventory_items.created_by.readable = True
        # db.inventory_items.difference.writable=False
        # links = [ lambda row: A(SPAN("اعتماد الجرد للصنف",_class="btn btn-info" ),_href=URL("items","inventory_items_approve",args=[row.id,request.args(0)]  )) ]
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                deletable=True,
                create=True,
                csv=True,
                showbuttontext=True,
                maxtextlengths={"inventory_items.item_name": 200},
                args=request.args[:1],
            )
        )
    elif auth.has_membership("user1"):
        db.inventory_items.id.readable = False
        db.inventory_items.real_quantity.readable = False
        db.inventory_items.difference.readable = False
        db.inventory_items.difference.writable = False
        db.inventory_items.inventory.readable = False
        db.inventory_items.inventory.writable = False
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                deletable=False,
                create=True,
                csv=False,
                showbuttontext=False,
                maxtextlengths={"inventory_items.item_name": 200},
                args=request.args[:1],
            )
        )


@can_access(5200)
def inventory_items_approve():
    it = db.inventory_items[request.args(0)]
    if it:
        if it.approve != True:
            if it.difference != 0:
                db1 = (
                    db(
                        (db.items_det.item_id == it.item_id)
                        & (db.items_det.items_count > 0)
                    )
                    .select()
                    .first()
                )
                if not db1:
                    return "لا توجد دفعة برصيد موجب لهذا الصنف"
                # فرق الجرد يمر من الوحدة المركزية ليُسجَّل في دفتر الحركات
                stock_move(db1, float(it.difference or 0) * -1, "جرد",
                           "اعتماد جرد", str(request.args(1) or ""))
            db.inventory_items[request.args(0)] = dict(approve=True)
            db.commit()
            return redirect(URL("items", "inventory_items/" + request.args(1)))
        else:
            return "تم اعتماد هذا الصنف"
        """
    if (it.real_quantity == db.items_det(it.item_id).items_count):
        db.items_det[it.item_id] = dict( items_count = it.quantity  )
        db.inventory_items[request.args(0)] = dict( approve = True )
        db.commit()
        return redirect(URL('items','inventory_items/'+request.args(1)))"""
    # return("الكمية غير متطابقة - تحذير تم تعديل بيانات الصنف بعد الجرد")


# ============================================================================================
@can_access(3002)
def itm_rep_det():
    item_id = request.args(0, cast=int)

    # 1) بيانات الصنف الأساسية
    q = db(db.items_main.id == item_id).select().first()

    # 2) جلب items_det مع suppliers_bills في استعلام واحد (JOIN)
    det_rows = db(db.items_det.item_idr == item_id).select(
        db.items_det.ALL,
        db.suppliers_bills.id,
        db.suppliers_bills.bill_date,
        db.suppliers_bills.bill_no,
        db.suppliers_bills.bill_confirmation,
        db.suppliers_bills.supplier,
        left=db.suppliers_bills.on(db.suppliers_bills.id == db.items_det.supplier_inv),
        orderby=db.items_det.id
    )

    # 3) جلب الكميات المباعة لكل items_det.id في استعلام واحد
    det_ids = [r.items_det.id for r in det_rows]
    sold_map = {}
    if det_ids:
        sold_sql = (
            "SELECT item_number, COALESCE(SUM(item_count),0) as total_sold "
            "FROM invoice_details WHERE item_number = ANY(%s) GROUP BY item_number"
        )
        sold_rows = db.executesql(sold_sql, placeholders=[det_ids], as_dict=True)
        for sr in sold_rows:
            sold_map[sr['item_number']] = float(sr['total_sold'])

    # 4) جلب أسماء الموردين في استعلام واحد
    supplier_ids = list(set(
        r.suppliers_bills.supplier for r in det_rows
        if r.suppliers_bills.id and r.suppliers_bills.supplier
    ))
    supplier_names = {}
    if supplier_ids:
        for s in db(db.suppliers.id.belongs(supplier_ids)).select(db.suppliers.id, db.suppliers.name):
            supplier_names[s.id] = s.name

    # 5) بناء بيانات الأوامر + حساب المجاميع
    m1 = m2 = m3 = m4 = mm2 = 0.0
    km1 = km2 = km3 = kmm2 = 0.0
    orders = []
    st = 0
    for r in det_rows:
        det = r.items_det
        sb = r.suppliers_bills
        st += 1
        ss = sold_map.get(det.id, 0.0)
        m3 += ss

        confirmed = bool(sb.bill_confirmation) if sb.id else False
        if confirmed:
            m1 += (det.quantity or 0)
            m2 += (det.items_count or 0)
            mm2 += (det.return_count or 0)
        else:
            km1 += (det.quantity or 0)
            km2 += (det.items_count or 0)
            kmm2 += (det.return_count or 0)

        orders.append(dict(
            st=st,
            confirmed=confirmed,
            supplier_inv=det.supplier_inv,
            bill_date=str(sb.bill_date) if sb.id and sb.bill_date else '',
            bill_no=sb.bill_no if sb.id else '',
            supplier_name=supplier_names.get(sb.supplier, '') if sb.id else '',
            quantity=det.quantity,
            sold=round(ss, 2),
            expiration_date=str(det.expiration_date) if det.expiration_date else '',
            buy_price=round((det.buy_price or 0), 2),
            public_price=round((det.public_price or 0), 2),
            sku_id=det.id,
            has_bill=bool(sb.id),
        ))

    # 6) المحول والمرتجع (استعلام واحد مجمع)
    rs_sql = (
        "SELECT admin_accept, COALESCE(SUM(d.item_count),0) as total "
        "FROM returned_supply_det d "
        "JOIN returned_supply r ON r.id = d.returned_supply "
        "WHERE d.item_id IN (SELECT id::text FROM items_det WHERE item_idr = %s) "
        "GROUP BY admin_accept"
    )
    rs_rows = db.executesql(rs_sql, placeholders=[item_id], as_dict=True)
    rs1 = 0.0
    rs2 = 0.0
    for rr in rs_rows:
        if rr['admin_accept'] == 'T':
            rs1 = float(rr['total'])
        elif rr['admin_accept'] == 'F':
            rs2 = float(rr['total'])

    # 7) جدول المبيعات الشهرية (crosstab)
    qs = (
        "SELECT * FROM crosstab("
        " 'select EXTRACT(YEAR FROM created_on)::integer as fday,"
        "EXTRACT(MONTH FROM created_on)::integer as fmonth,"
        " sum(item_count)::integer as fcount from invoice_details where item_number in"
        " (select id from items_det where item_idr = " + str(item_id) + " )"
        " group by EXTRACT(MONTH FROM created_on),EXTRACT(YEAR FROM created_on)"
        " order by EXTRACT(YEAR FROM created_on),EXTRACT(MONTH FROM created_on)"
        " ','select * from generate_series(1,12)' ) AS ct"
        " ( fcount int ,\"1\" int,\"2\" int,\"3\" int,\"4\" int,\"5\" int,\"6\" int,"
        "\"7\" int,\"8\" int,\"9\" int,\"10\" int,\"11\" int,\"12\" int )"
    )
    dataq = db.executesql(qs, as_dict=True)

    qs2 = (
        "select a.n ,(select sum(item_count)::integer as fcount from"
        " invoice_details where item_number in"
        " (select id from items_det where item_idr = " + str(item_id) + " )"
        " and EXTRACT(MONTH FROM created_on)::integer = a.n )"
        " from generate_series(1, 12) as a(n)"
    )
    dataq2 = db.executesql(qs2, as_dict=True)

    summary = dict(
        m1=round(m1, 2), m2=round(m2, 2), m3=round(m3, 2), m4=round(m4, 2),
        mm2=round(mm2, 2),
        km1=round(km1, 2), km2=round(km2, 2), kmm2=round(kmm2, 2),
        rs1=round(rs1, 2), rs2=round(rs2, 2),
    )

    return dict(
        q=q, orders=orders, summary=summary,
        dataq=dataq, dataq2=dataq2,
    )


# ********************************************************************************************
# شاشة محاضر الاتلاف
# ********************************************************************************************
@can_access(5200)
def damage_report():
    if auth.has_membership("admin"):
        links = [
            lambda row: A(
                SPAN("الاصناف", _class="btn btn-info"),
                _href=URL("items", "damage_report_det", args=[row.id]),
            ),
            lambda row: A(
                SPAN("احتساب", _class="btn btn-info"),
                _href=URL("items", "damage_report_count", args=[row.id]),
            ),
            lambda row: A(
                SPAN("اعتماد", _class="btn btn-info"),
                _href=URL("items", "damage_report_approving", args=[row.id]),
            ),
        ]
        q = (db.damage_report.user_accept == True) & (
            db.damage_report.admin_accept != True
        )
        db.damage_report.admin_accept.readable = False
        db.damage_report.admin_accept.writable = False
        grid = SQLFORM.grid(
            q,
            user_signature=False,
            links=links,
            orderby=~db.damage_report.id,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=True,
        )
        return dict(grid=grid)
    elif auth.has_membership("user1"):
        links = [
            lambda row: A(
                SPAN("الاصناف", _class="btn btn-info"),
                _href=URL("items", "damage_report_det", args=[row.id]),
            ),
            lambda row: A(
                SPAN("احتساب", _class="btn btn-info"),
                _href=URL("items", "damage_report_count", args=[row.id]),
            ),
        ]
        q = db.damage_report.user_accept == False
        db.damage_report.admin_accept.readable = False
        db.damage_report.admin_accept.writable = False
        grid = SQLFORM.grid(
            q,
            user_signature=False,
            links=links,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=True,
        )
        return dict(grid=grid)


@can_access(5200)
def damage_report_det():
    return dict()


@can_access(5200)
def damage_report_count():
    qry = (
        "update damage_report set  item_count= (select count(*) from damage_report_det where damage_report="
        " %s) , item_sum=(select sum(item_count) from damage_report_det where damage_report="
        " %s) where id = "
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(0), request.args(0), request.args(0)])
    redirect(URL(damage_report))


@can_access(5200)
def damage_report_det_add():
    items_det = db.damage_report_det.validate_and_insert(item_id=request.args(1))
    db.commit()
    return "0"


@can_access(5200)
def damage_report_approving():
    rep_id = request.args(0)
    rep = db.damage_report(rep_id)
    if rep and rep.admin_accept:
        redirect(URL(damage_report))
    # تصفير الدفعات التالفة عبر الوحدة المركزية ليُسجَّل الإخراج في الدفتر
    for d in db(db.damage_report_det.damage_report == rep_id).select():
        try:
            row = db.items_det(int(d.item_id))
        except (TypeError, ValueError):
            row = None
        if row:
            stock_set(row, 0, "تالف", "محضر إتلاف", str(rep_id))
    db(db.damage_report.id == rep_id).update(admin_accept=True)
    db.commit()
    redirect(URL(damage_report))


# --------------------------------------------------------------------------------------------------------
@can_access(5200)
def inventory_items_approve_all():
    thread.start_new_thread(inv_approve_all, (request.args(0),))
    return "الرجاء الانتظار سوف تأخذ هذه العملية بعض من الوقت و شكرا لك"


@can_access(5200)
def inv_approve_all(sh):
    db._adapter.reconnect()
    try:
        # print sh
        inv = db((db.inventory_items.inventory == sh)).select()
        for i in inv:
            # print i.id
            it = db.inventory_items[i.id]
            if it:
                if it.approve != True:
                    # if ( it.difference!=0 ) :
                    #    db1= db((db.items_det.item_id==it.item_id) & (db.items_det.items_count>0)).select().first()
                    #    if db1 :
                    # db.items_det[db1.id] = dict(items_count = db1.items_count + (it.difference*-1) )
                    #    else :
                    db1 = db((db.items_det.item_id == it.item_id)).select().last()
                    if db1:
                        # الضبط يمر من الوحدة المركزية ليُسجَّل الفارق في الدفتر
                        stock_set(db1, float(it.quantity or 0), "جرد",
                                  "اعتماد جرد شامل", str(sh))
                    db.inventory_items[i.id] = dict(approve=True)
                    db.commit()
        pr_id = db.print_report.validate_and_insert(er_dis="تمت عملية الاعتماد")
        db.commit()
    except Exception as e:
        print(e)
        pr_id = db.print_report.validate_and_insert(er_dis=e)
        db.commit()
    db._adapter.close()
    _lock.acquire()
    _lock.release()
    # =====================


@can_access(8201)
def inventory_items_dup_rep():
    return dict()


@can_access(8201)
def inventory_items_not_rep():
    return dict()


@can_access(8201)
def inventory_items_print_rep():
    return dict()


@can_access(3003)
def items_sales():
    return dict()


@can_access(3003)
def adjust_quantity():
    return dict()


@can_access(3008)
def items_merge():
    return dict()


@can_access(3008)
def items_merge_a():
    try:
        target_id = int(request.args(0) or 0)
        source_id = int(request.args(1) or 0)
    except (TypeError, ValueError):
        return dict(
            ok=False,
            mess="رقم الصنف غير صحيح. استخدم الرقم المسلسل الداخلي للصنف.",
            target_id=None,
            source_id=None,
            target_name="",
            source_name="",
            moved_count=0,
        )

    if not target_id or not source_id:
        return dict(
            ok=False,
            mess="يجب إدخال رقم الصنف الأساسي ورقم الصنف القديم.",
            target_id=target_id or "",
            source_id=source_id or "",
            target_name="",
            source_name="",
            moved_count=0,
        )

    if target_id == source_id:
        return dict(
            ok=False,
            mess="لا يمكن دمج الصنف مع نفسه. اختر رقمين مختلفين.",
            target_id=target_id,
            source_id=source_id,
            target_name="",
            source_name="",
            moved_count=0,
        )

    new_itm = db.items_main[target_id]
    old_itm = db.items_main[source_id]
    if new_itm is None or old_itm is None:
        return dict(
            ok=False,
            mess="لم يتم العثور على أحد الصنفين. تأكد من استخدام الرقم المسلسل الداخلي.",
            target_id=target_id,
            source_id=source_id,
            target_name=new_itm.name if new_itm else "",
            source_name=old_itm.name if old_itm else "",
            moved_count=0,
        )

    moved_count = db(db.items_det.item_idr == source_id).count()
    target_name = new_itm.name
    source_name = old_itm.name

    # كل ما يشير إلى الصنف المصدر يُنقل إلى الهدف قبل الحذف.
    # حقول reference في web2py تُنشأ بـ ON DELETE CASCADE، فحذف الصنف دون
    # نقلها يمحو معه دفتر حركاته وحالات البيع بدون رصيد المنسوبة إليه: أي
    # أن المخزون ينتقل إلى الهدف بينما تاريخه وأثر تدقيقه يُمحيان، فيختلف
    # دفتر الهدف عن رصيده بمقدار الكميات المنقولة.
    db(db.items_det.item_idr == source_id).update(item_idr=target_id)
    db(db.items_movement.item_main == source_id).update(item_main=target_id)
    db(db.stock_exception.item_main == source_id).update(item_main=target_id)
    db(db.inv_count_item.item_main == source_id).update(item_main=target_id)
    db(db.inventory_items.items_main == source_id).update(items_main=target_id)
    db(db.items_reorder_detail.items_main == source_id).update(items_main=target_id)
    db(db.item_requests.converted_to_item == source_id).update(
        converted_to_item=target_id
    )
    # حقل رقمي لا مرجعي: لا يُحذف تتابعياً لكنه يبقى معلّقاً على صنف محذوف
    db(db.invoice_details.item_idr == source_id).update(item_idr=target_id)
    # وسوم البحث: حقل item_idr فيها فريد، فنقلها يكسر القيد لو كان للهدف
    # وسوم أصلاً — ووسوم المصدر تكرار لا قيمة له بعد الدمج
    db(db.item_tags.item_idr == source_id).delete()
    db(db.item_barcode_alias.item_idr == source_id).update(item_idr=target_id)

    old_itm.delete_record()
    # باركود الصنف المحذوف يبقى قابلاً للبحث بعد الدمج: تُواءم نسخته النصية
    # في الدفعات المنقولة مع باركود الصنف الباقي (شاشة البيع وشاشات الأصناف
    # تربط items_det بـ items_main بنص الباركود لا بالمعرف — تركها على النص
    # القديم يجعل مسحها يجد دفعات «بلا اسم» تشير لصنف محذوف)، ويدخل الباركود
    # القديم دفتر السوابق مشيراً إلى الصنف الباقي.
    if old_itm.item_id and old_itm.item_id != new_itm.item_id:
        db(db.items_det.item_id == old_itm.item_id).update(item_id=new_itm.item_id)
        db.item_barcode_alias.update_or_insert(
            db.item_barcode_alias.barcode == old_itm.item_id,
            item_idr=target_id,
            barcode=old_itm.item_id,
            note="دمج في الصنف م %s" % target_id,
        )
    db.commit()
    mess = "تم دمج الصنفين. أصبح الصنف الأساسي هو السجل المعتمد."
    return dict(
        ok=True,
        mess=mess,
        target_id=target_id,
        source_id=source_id,
        target_name=target_name,
        source_name=source_name,
        moved_count=moved_count,
    )


# حُذفت هنا دالة editcountItem القديمة: كانت تصفّر كل دفعات الصنف بـ SQL خام
# دون أي حركة دفترية، وهي مكشوفة كرابط مستقل حتى بعد توقف الشاشات عن ندائها.
# البديل المعتمد الذي تستدعيه الشاشات هو api_1/editcountItem — يمر من الوحدة
# المركزية فيبقى الدفتر مطابقاً للمخزون.


# ════════════════════════════════════════════════════════════════════════
# تحويل الرقم الدولي (الباركود) لصنف — الشاشة 3014
#
# الشركات تغيّر باركود المنتج وتوقف القديم؛ فتح ملف جديد للرقم الجديد يقسم
# تاريخ الصنف على ملفين ويترك القديم يُباع من ذاكرة الكاشير حتى السالب.
# المعالجة: الملف القديم يبقى (رقمه الداخلي وتاريخه وطلبياته)، يتبنى الباركود
# الجديد، ويدخل القديم دفتر item_barcode_alias فيبقى البحث به يصل للصنف الحي.
# وإن كان الرقم الجديد قد أُدخل فعلاً كصنف مستقل (اكتشاف متأخر): تُسحب دفعاته
# وحركاته إلى الملف القديم ثم يُحذف — دمج معكوس وتحويل في عملية واحدة.
# ════════════════════════════════════════════════════════════════════════


@can_access(3014)
def barcode_change():
    return dict()


def _barcode_item_card(itm):
    """بطاقة معاينة لصنف: تُعرض قبل التنفيذ حتى يرى المستخدم ماذا سيُمس."""
    total = db.items_det.items_count.sum()
    stock = db(db.items_det.item_idr == itm.id).select(total).first()[total] or 0
    last = (
        db(db.items_movement.item_main == itm.id)
        .select(
            db.items_movement.move_date,
            orderby=~db.items_movement.id,
            limitby=(0, 1),
        )
        .first()
    )
    return {
        "id": itm.id,
        "barcode": itm.item_id,
        "name": itm.name,
        "stock": stock,
        "batches": db(db.items_det.item_idr == itm.id).count(),
        "moves": db(db.items_movement.item_main == itm.id).count(),
        "last_move": str(last.move_date) if last and last.move_date else "",
        "halt": bool(itm.halt),
    }


def _barcode_change_state(old_ref, new_code):
    """يفسّر المدخلات ويحدد وضع التنفيذ.

    يعيد (حالة للعرض, صف الصنف القديم, صف الصنف الجديد إن وُجد).
    الصنف القديم يُفسَّر باركوداً حالياً ثم باركوداً سابقاً ثم رقماً داخلياً —
    والمعاينة تعرض بطاقة ما وُجد فيحسم المستخدم أي التباس قبل التنفيذ.
    """
    old_ref = str(old_ref or "").strip()
    new_code = str(new_code or "").strip()
    if not old_ref or not new_code:
        return (
            {"mode": "blocked", "mess": "أدخل الصنف القديم والباركود الجديد."},
            None,
            None,
        )
    if len(new_code) > 20 or any(c.isspace() for c in new_code):
        return (
            {
                "mode": "blocked",
                "mess": "الباركود الجديد غير صالح: 20 خانة كحد أقصى وبلا مسافات.",
            },
            None,
            None,
        )

    old_itm = db(db.items_main.item_id == old_ref).select().first()
    if old_itm is None:
        old_itm = item_by_alias_barcode(old_ref)
    if old_itm is None and old_ref.isdigit() and len(old_ref) <= 9:
        old_itm = db.items_main(int(old_ref))
    if old_itm is None:
        return (
            {"mode": "blocked", "mess": "لم يتم العثور على الصنف القديم بهذا الرقم."},
            None,
            None,
        )

    if new_code == old_itm.item_id:
        return (
            {
                "mode": "blocked",
                "mess": "الباركود الجديد هو نفسه الباركود الحالي للصنف.",
                "old_item": _barcode_item_card(old_itm),
            },
            old_itm,
            None,
        )

    new_itm = db(db.items_main.item_id == new_code).select().first()

    # الرقم الجديد مسجل باركوداً سابقاً؟ لصنف آخر: التباس يُحل يدوياً.
    # لنفس الصنف: عودة لرقم قديم — مسموحة، يخرج من السوابق ويعود أساسياً.
    if new_itm is None:
        al = db(db.item_barcode_alias.barcode == new_code).select().first()
        if al is not None and al.item_idr != old_itm.id:
            other = db.items_main(al.item_idr)
            return (
                {
                    "mode": "blocked",
                    "mess": "الرقم الجديد مسجل كباركود سابق لصنف آخر: %s (م %s)."
                    % (other.name if other else "؟", al.item_idr),
                    "old_item": _barcode_item_card(old_itm),
                },
                old_itm,
                None,
            )

    state = {
        "old_item": _barcode_item_card(old_itm),
        "new_barcode": new_code,
        "new_item": None,
    }
    if new_itm is None:
        state["mode"] = "convert"
        state["mess"] = (
            "الرقم الجديد غير مسجل كصنف — سيُستبدل باركود الصنف مباشرة "
            "ويُحفظ الرقم القديم كباركود سابق."
        )
    else:
        state["mode"] = "merge_convert"
        state["new_item"] = _barcode_item_card(new_itm)
        state["mess"] = (
            "الرقم الجديد مسجل كصنف مستقل — ستُسحب دفعاته وحركاته إلى الصنف "
            "القديم صاحب التاريخ، يُحذف سجله، ثم يُعتمد الرقم الجديد على "
            "الصنف القديم ويُحفظ القديم كباركود سابق."
        )
    return state, old_itm, new_itm


@can_access(3014)
def barcode_change_info():
    """API: معاينة فقط — لا يكتب شيئاً."""
    try:
        state, _, _ = _barcode_change_state(
            request.vars.old_ref, request.vars.new_barcode
        )
        return response.json(api.api_ok(data=state))
    except Exception:
        db.rollback()
        return response.json(api.api_error(mess="تعذر فحص المدخلات."))


@can_access(3014)
def barcode_change_apply():
    """API: التنفيذ. يعيد حساب الوضع من القاعدة ولا يثق بمعاينة المتصفح."""
    try:
        state, old_itm, new_itm = _barcode_change_state(
            request.vars.old_ref, request.vars.new_barcode
        )
        if state["mode"] == "blocked":
            return response.json(api.api_error(mess=state["mess"]))
        if (request.vars.mode or "") != state["mode"]:
            return response.json(
                api.api_error(
                    mess="تغيّر وضع التنفيذ منذ المعاينة — حدّث المعاينة ثم أعد المحاولة."
                )
            )

        old_code = old_itm.item_id
        new_code = state["new_barcode"]
        moved_batches = 0
        moved_stock = 0

        if new_itm is not None:
            # دمج معكوس: القديم صاحب التاريخ هو الباقي. قفل دفعات الصنفين
            # بترتيب ثابت قبل القراءة والتعديل حتى لا نتقاطع مع بيع جارٍ.
            stock_lock_items([old_itm.id, new_itm.id])
            total = db.items_det.items_count.sum()
            moved_stock = (
                db(db.items_det.item_idr == new_itm.id).select(total).first()[total]
                or 0
            )
            moved_batches = db(db.items_det.item_idr == new_itm.id).count()

            # نفس قائمة المراجع التي تنقلها شاشة الدمج — حذف الصنف دون نقلها
            # يمحو دفتره وأثره التدقيقي (حقول reference تُحذف تتابعياً).
            db(db.items_det.item_idr == new_itm.id).update(item_idr=old_itm.id)
            db(db.items_movement.item_main == new_itm.id).update(item_main=old_itm.id)
            db(db.stock_exception.item_main == new_itm.id).update(item_main=old_itm.id)
            db(db.inv_count_item.item_main == new_itm.id).update(item_main=old_itm.id)
            db(db.inventory_items.items_main == new_itm.id).update(
                items_main=old_itm.id
            )
            db(db.items_reorder_detail.items_main == new_itm.id).update(
                items_main=old_itm.id
            )
            db(db.item_requests.converted_to_item == new_itm.id).update(
                converted_to_item=old_itm.id
            )
            db(db.invoice_details.item_idr == new_itm.id).update(item_idr=old_itm.id)
            db(db.item_barcode_alias.item_idr == new_itm.id).update(
                item_idr=old_itm.id
            )
            # الوسوم: يحتفظ القديم بوسومه، وإن لم تكن له تُنقل وسوم الجديد
            if db(db.item_tags.item_idr == old_itm.id).isempty():
                db(db.item_tags.item_idr == new_itm.id).update(item_idr=old_itm.id)
            else:
                db(db.item_tags.item_idr == new_itm.id).delete()
            # بطاقة الجديد أُنشئت مع آخر توريد فسعرها أحدث غالباً
            if new_itm.public_price:
                old_itm.update_record(public_price=new_itm.public_price)
            new_itm.delete_record()  # صار فارغاً؛ حذفه يحرر الباركود الجديد
        else:
            stock_lock_items([old_itm.id])

        # اعتماد الرقم الجديد على الملف القديم، مع مواءمة النسخة النصية في كل
        # الدفعات: البيع وشاشات الأصناف تربط الجدولين بنص الباركود لا بالمعرف.
        # يُرفع الإيقاف إن وُجد — هذا هو الصنف الحي الآن.
        old_itm.update_record(item_id=new_code, halt=False)
        db(db.items_det.item_idr == old_itm.id).update(item_id=new_code)
        db(db.items_det.item_id == old_code).update(item_id=new_code)

        # الرقم القديم يدخل دفتر السوابق؛ وإن كان الجديد رقماً سابقاً لنفس
        # الصنف (عودة لرقم أقدم) يخرج من السوابق لأنه صار الأساسي.
        db(db.item_barcode_alias.barcode == new_code).delete()
        db.item_barcode_alias.update_or_insert(
            db.item_barcode_alias.barcode == old_code,
            item_idr=old_itm.id,
            barcode=old_code,
            note="تحويل رقم دولي إلى %s" % new_code
            + (
                " مع دمج الصنف م %s" % state["new_item"]["id"]
                if new_itm is not None
                else ""
            ),
        )
        db.commit()
        return response.json(
            api.api_ok(
                data={
                    "mode": state["mode"],
                    "item_id": old_itm.id,
                    "name": old_itm.name,
                    "old_barcode": old_code,
                    "new_barcode": new_code,
                    "moved_batches": moved_batches,
                    "moved_stock": moved_stock,
                }
            )
        )
    except Exception:
        db.rollback()
        return response.json(
            api.api_error(mess="تعذر تنفيذ التحويل — لم يُكتب أي تغيير.")
        )


@can_access(3011)
def negative_items():
    qry = (
        "select  item_idr,sum(items_count) as sum , "
        " (select name from items_main  where items_main.id= item_idr ) as name  ,"
        " (select item_type from items_main  where items_main.id= item_idr ) as type  "
        " from items_det   "
        " group by item_idr   "
        " having sum(items_count) <0   "
        " ORDER BY type,item_idr   "
    )
    data = db.executesql(qry, as_dict=True)
    for i in data:
        itm = db.items_main(i["item_idr"])
        i["type"] = itm["item_type"].name
    return dict(data=data)


@can_access(3012)
def stop_items():
    return dict()


# ==============================
@can_access(3004)
def get_open_inv():
    # الفواتير المفتوحة (غير المؤكدة). الشرط الأصلي كان يستخدم `or` بايثون فيُختصر
    # فعلياً إلى == False فقط؛ نُبقي نفس الدلالة صراحةً.
    sp = db(db.suppliers_bills.bill_confirmation == False).select(
        orderby=db.suppliers_bills.id
    )
    if not sp:
        return sp.as_json()

    ids = [r.id for r in sp]

    # مجاميع أصناف كل الفواتير في استعلام واحد مجمّع (بدل 3 استعلامات لكل فاتورة)
    agg = {}
    for sid, s_price, s_vat, cnt in db.executesql(
        "SELECT supplier_inv, SUM(inv_price), SUM(inv_price*vat), COUNT(*) "
        "FROM items_det WHERE supplier_inv = ANY(%s) GROUP BY supplier_inv;",
        placeholders=[ids],
    ):
        agg[sid] = (s_price, s_vat, cnt)

    # تحميل الأسماء المرجعية دفعةً واحدة (بدل 4 استعلامات لكل فاتورة)
    def name_map(fk_field, ref_table):
        vals = list({r[fk_field] for r in sp if r[fk_field]})
        if not vals:
            return {}
        return {
            row.id: row.name
            for row in db(db[ref_table].id.belongs(vals)).select(
                db[ref_table].id, db[ref_table].name
            )
        }

    supplier_names = name_map("supplier", "suppliers")
    pay_names = name_map("payment_method", "key_payment_method")
    type_names = name_map("invoce_type", "key_invoce_type")

    user_ids = list({r.created_by for r in sp if r.created_by})
    users = {}
    if user_ids:
        for u in db(db.auth_user.id.belongs(user_ids)).select(
            db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
        ):
            users[u.id] = (u.first_name or "") + "   " + (u.last_name or "")

    # تعبئة الحقول المحسوبة بلا أي استعلام إضافي
    for r in sp:
        r["s_n"] = supplier_names.get(r.supplier, "")
        r["p_m"] = pay_names.get(r.payment_method, "")
        r["inv_type_name"] = type_names.get(r.invoce_type, "")
        r["u_n"] = users.get(r.created_by, "")
        a = agg.get(r.id)
        if a:
            s_price, s_vat, cnt = a
            r["inv_inp_s"] = s_price
            r["inv_countg"] = cnt
            r["inv_inp_s_v"] = (s_vat or 0) + (s_price or 0)
        else:
            r["inv_inp_s"] = None
            r["inv_countg"] = 0
            r["inv_inp_s_v"] = 0

    return sp.as_json()
