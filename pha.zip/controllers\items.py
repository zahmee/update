# -*- coding: utf-8 -*-
#  type: ignore
import math
import threading

_lock = threading.RLock()


@can_access(3001)
def main():
    sc = screens_rules(3001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


@can_access(3001)
def t1():
    return dict()


@can_access(3006)
def new_items_det():
    return dict()


# ==============================================
# ==============================================
# ==============================================
# ==============================================
# ==============================================


@can_access(3006)
def det_items():
    return dict()


# ++++++++++++++++++++++
@can_access(3006)
def get_itm_2():
    qry = (
        "select (select name from items_main where item_id= items_det.item_id limit 1) as name , (select name from suppliers where id=(select supplier from suppliers_bills where id= items_det.supplier_inv )) as supp , *  from items_det where id ="
        " %s ;"
    )
    qs = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(qs)


# ----------------------------------------------------------------------------------------------------------
@can_access(3001)
def main_it():
    headers = {"main_items.item_id": "رقم الصنف", "main_items.name": "اسم الصنف"}
    fields = [db.main_items.item_id, db.main_items.name]
    return dict(
        grid=SQLFORM.grid(
            db.main_items,
            user_signature=False,
            headers=headers,
            fields=fields,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=False,
            maxtextlengths={"main_items.name": 200},
        )
    )


@can_access(3004)
def de_it():
    return dict()


@can_access(3005)
def it_inv():
    it_inv = db.suppliers_bills(request.args(0))
    if it_inv == None:
        redirect(URL("not_inv"))
    if it_inv.bill_confirmation == True:
        redirect(URL("not_inv"))
    return dict()


@can_access(3004)
def not_inv():
    return dict(message="لا يوجد فاتورة بهذا الرقم")


@can_access(3005)
def inter():
    return dict()


# ---------------------------------------------------------------------------------------------
#    دوال شاشة اضافة الأصناف


@can_access(3005)
def mit():
    qry = (
        "select item_id,name from main_items where name like %s LIMIT 15;"
    )
    qs = db.executesql(qry, placeholders=['%' + request.vars.it + '%'], as_dict=True)
    return response.json(qs)


@can_access(3007)
def t():
    qry = "select sum(inv_price) from items_det where supplier_inv = 1 ;"
    qs = db.executesql(qry)
    # s = db(db.items_det(db.items_det.supplier_inv==1)).select()
    # inv_p = db.items_det.inv_price.sum()
    return str(qs[(0)])


@can_access(2013)
def it_prt():
    db1 = db(
        (db.items_det.item_id == db.items_main.item_id)
        & (db.items_det.supplier_inv == request.args(0))
    ).select(
        db.items_det.item_id,
        db.items_det.id,
        db.items_main.name,
        db.items_det.items_count,
        db.items_det.public_price,
        db.items_det.vat,
        db.items_det.vat_in_public_price,
        db.items_det.quantity,
        orderby=db.items_det.id,
    )
    for r in db1:
        r.items_det.public_price = round(
            (r.items_det.public_price * r.items_det.vat) + r.items_det.public_price, 2
        )
        r.items_det.items_count = r.items_det.quantity
        if r.items_det.vat_in_public_price == True:
            new_price = round((r.items_det.public_price / (r.items_det.vat + 1)), 2)
            r.items_det.public_price = new_price
    return str(db1)


@can_access(2012)
def it_prt_by_item():
    # q1 = db(db.items_main.item_id == request.args(0))
    try:
        itm1 = db(db.items_main.id == request.args(0)).select().first()
        itm2 = db(db.items_det.item_idr == itm1.id).select().last()
        db1 = db(
            (db.items_det.item_id == db.items_main.item_id)
            & (db.items_det.supplier_inv == itm2.supplier_inv)
            & (db.items_det.id == itm2.id)
        ).select(
            db.items_det.item_id,
            db.items_det.id,
            db.items_main.name,
            db.items_det.items_count,
            db.items_det.public_price,
        )
        return str(db1)
    except Exception as e:
        print(e)
        return str("رقم الصنف المدخل خطأ ، الرجاء ادخال الرقم الدولي ")


@can_access(2012)
def it_rep1():
    from datetime import date, timedelta

    inv_id = int(request.args(0) or 0)
    bill = db.suppliers_bills(inv_id)
    if not bill:
        return dict(message="الفاتورة غير موجودة")

    rows = db(db.items_det.supplier_inv == inv_id).select(orderby=db.items_det.id)

    items = []
    # FULL totals (based on quantity, no return deduction)
    purchase_without_vat = 0.0
    purchase_vat = 0.0
    sale_without_vat = 0.0
    sale_vat = 0.0
    public_price_before_vat = 0.0
    public_price_after_vat = 0.0
    increase_amount = 0.0

    # NET totals (after deducting returns)
    net_purchase_without_vat = 0.0
    net_purchase_vat = 0.0
    net_sale_without_vat = 0.0
    net_sale_vat = 0.0

    # RETURN totals
    return_qty_total = 0.0
    return_purchase_without_vat = 0.0
    return_purchase_vat = 0.0
    return_sale_without_vat = 0.0
    return_sale_vat = 0.0

    for idx, row in enumerate(rows, start=1):
        item_main = db.items_main(row.item_idr)
        item_name = item_main.name if item_main else ""

        # Fetch last 5 buy prices for this item (safe parameterized query)
        price_history = db.executesql(
            "SELECT buy_price FROM items_det WHERE item_idr=%s AND buy_price > 0 ORDER BY id DESC LIMIT 5",
            placeholders=[row.item_idr],
            as_dict=True,
        )

        current_buy = round(float(row.buy_price or 0), 2)
        low_price = current_buy
        for ph in price_history:
            ph_price = round(float(ph["buy_price"]), 2)
            if low_price > ph_price:
                low_price = ph_price

        # Supplier name
        supplier_name = ""
        if item_main and item_main.suppliers:
            sup = db.suppliers(item_main.suppliers)
            if sup:
                supplier_name = sup.name

        # Expiry warning
        expiry_warning = False
        if row.expiration_date and row.expiration_date <= (date.today() + timedelta(days=300)):
            expiry_warning = True

        # Buy price highlight logic
        buy_price_highlight = "danger" if (low_price != current_buy and low_price > 0) else "normal"
        price_diff = round(current_buy - low_price, 2) if buy_price_highlight == "danger" else 0.0
        price_diff_pct = round((price_diff / (low_price or 1)) * 100, 2) if price_diff else 0.0

        quantity = float(row.quantity or 0)
        return_count = float(row.return_count or 0)
        net_qty = max(quantity - return_count, 0)

        # Public price calculations
        public_price = float(row.public_price or 0)
        vat_rate = float(row.vat or 0)

        if row.vat_in_public_price:
            public_before_vat = public_price / (1 + vat_rate) if vat_rate else public_price
            public_vat_amount = public_price - public_before_vat
            public_after_vat = public_price
        else:
            public_before_vat = public_price
            public_vat_amount = public_price * vat_rate
            public_after_vat = public_price + public_vat_amount

        profit_pct = round((((public_before_vat - current_buy) / (current_buy or 1)) * 100), 2)

        # FULL line totals (based on full quantity — no return deduction)
        line_purchase = float(row.inv_price or 0)
        line_purchase_vat = line_purchase * vat_rate
        line_sale_without_vat = public_before_vat * quantity
        line_sale_with_vat = public_after_vat * quantity
        line_profit = line_sale_without_vat - line_purchase

        # NET line totals (after returns)
        net_factor = (net_qty / quantity) if quantity > 0 else 0
        net_line_purchase = line_purchase * net_factor
        net_line_purchase_vat = line_purchase_vat * net_factor
        net_line_sale_without_vat = public_before_vat * net_qty
        net_line_sale_vat = public_vat_amount * net_qty

        # RETURN line totals
        return_line_purchase = line_purchase - net_line_purchase
        return_line_purchase_vat = line_purchase_vat - net_line_purchase_vat
        return_line_sale_without_vat = public_before_vat * return_count
        return_line_sale_vat = public_vat_amount * return_count

        # Profit highlight class
        if profit_pct > 25:
            profit_class = "success"
        elif profit_pct > 16:
            profit_class = "normal"
        elif profit_pct < 1:
            profit_class = "danger"
        else:
            profit_class = "warning"

        # Return count highlight
        return_highlight = return_count > 0

        # Increase amount (price difference * full quantity)
        if buy_price_highlight == "danger":
            increase_amount += price_diff * quantity

        # FULL running totals (based on full quantity)
        purchase_without_vat += line_purchase
        purchase_vat += line_purchase_vat
        sale_without_vat += line_sale_without_vat
        sale_vat += public_vat_amount * quantity
        public_price_before_vat += public_before_vat * quantity
        public_price_after_vat += line_sale_with_vat

        # NET running totals (after returns)
        net_purchase_without_vat += net_line_purchase
        net_purchase_vat += net_line_purchase_vat
        net_sale_without_vat += net_line_sale_without_vat
        net_sale_vat += net_line_sale_vat

        # RETURN running totals
        return_qty_total += return_count
        return_purchase_without_vat += return_line_purchase
        return_purchase_vat += return_line_purchase_vat
        return_sale_without_vat += return_line_sale_without_vat
        return_sale_vat += return_line_sale_vat

        items.append({
            "no": idx,
            "id": row.id,
            "item_idr": row.item_idr,
            "name": item_name,
            "expiry_date": row.expiration_date,
            "expiry_warning": expiry_warning,
            "vat": vat_rate,
            "buy_price": current_buy,
            "low_price": low_price,
            "buy_price_highlight": buy_price_highlight,
            "price_diff": price_diff,
            "price_diff_pct": price_diff_pct,
            "public_price": public_price,
            "vat_in_public_price": row.vat_in_public_price,
            "public_before_vat": round(public_before_vat, 2),
            "public_vat_amount": round(public_vat_amount, 2),
            "public_after_vat": public_after_vat,
            "profit_pct": profit_pct,
            "profit_class": profit_class,
            "return_count": return_count,
            "return_highlight": return_highlight,
            "quantity": quantity,
            "inv_price": line_purchase,
            "line_sale_without_vat": round(line_sale_without_vat, 2),
            "line_sale_with_vat": round(line_sale_with_vat, 2),
            "profit_line": round(line_profit, 2),
            "created_by": row.created_by,
            "price_history": price_history,
            "supplier_name": supplier_name,
            "public_price_before_vat_acc": round(public_price_before_vat, 2),
            "public_price_after_vat_acc": round(public_price_after_vat, 2),
        })

    # FULL summary (based on full quantity)
    purchase_with_vat = purchase_without_vat + purchase_vat
    sale_with_vat_total = sale_without_vat + sale_vat

    profit_without_vat = sale_without_vat - purchase_without_vat
    profit_with_vat = sale_with_vat_total - purchase_with_vat
    vat_diff = sale_vat - purchase_vat

    profit_ratio = 0.0
    if purchase_without_vat > 0:
        profit_ratio = min(100.0, round((profit_without_vat / purchase_without_vat) * 100, 2))

    # NET summary (after returns)
    net_purchase_with_vat = net_purchase_without_vat + net_purchase_vat
    net_sale_with_vat = net_sale_without_vat + net_sale_vat
    net_profit_without_vat = net_sale_without_vat - net_purchase_without_vat
    net_profit_with_vat = net_sale_with_vat - net_purchase_with_vat
    net_profit_ratio = 0.0
    if net_purchase_without_vat > 0:
        net_profit_ratio = min(
            100.0, round((net_profit_without_vat / net_purchase_without_vat) * 100, 2)
        )

    # RETURN summary
    return_purchase_with_vat = return_purchase_without_vat + return_purchase_vat
    return_sale_with_vat = return_sale_without_vat + return_sale_vat

    # Bill comparison (safe parameterized query)
    inv_bill_net = float(bill.bill_net_amount or 0.0)
    inv_bill_total = float(bill.bill_total or 0.0)

    sum_inv_price = db.items_det.inv_price.sum()
    total_inv_price = (
        db(db.items_det.supplier_inv == inv_id).select(sum_inv_price).first()[sum_inv_price] or 0.0
    )

    total_vat = 0.0
    for r in db(db.items_det.supplier_inv == inv_id).select():
        total_vat += float(r.inv_price or 0) * (r.vat or 0)

    def fmt(val):
        """تنسيق الرقم إلى منزلتين عشريتين مع فاصل آلاف"""
        try:
            return "{:,.2f}".format(float(val))
        except (TypeError, ValueError):
            return "0.00"

    # Helper لتحديد لون فرق الفاتورة
    diff_without_vat = round(total_inv_price - inv_bill_net, 2)
    diff_with_vat = round((total_vat + total_inv_price) - inv_bill_total, 2)

    def diff_class(diff_val):
        if abs(diff_val) < 0.01:
            return "success"
        return "danger" if diff_val > 0 else "warning"

    return dict(
        bill=bill,
        items=items,
        item_count=len(items),
        purchase_without_vat=round(purchase_without_vat, 2),
        purchase_with_vat=round(purchase_with_vat, 2),
        purchase_vat=round(purchase_vat, 2),
        sale_without_vat=round(sale_without_vat, 2),
        sale_with_vat=round(sale_with_vat_total, 2),
        sale_vat=round(sale_vat, 2),
        profit_without_vat=round(profit_without_vat, 2),
        profit_with_vat=round(profit_with_vat, 2),
        vat_diff=round(vat_diff, 2),
        profit_ratio=profit_ratio,
        public_price_before_vat=round(public_price_before_vat, 2),
        public_price_after_vat=round(public_price_after_vat, 2),
        increase_amount=round(increase_amount, 2),
        # NET totals (after returns)
        net_purchase_without_vat=round(net_purchase_without_vat, 2),
        net_purchase_with_vat=round(net_purchase_with_vat, 2),
        net_purchase_vat=round(net_purchase_vat, 2),
        net_sale_without_vat=round(net_sale_without_vat, 2),
        net_sale_with_vat=round(net_sale_with_vat, 2),
        net_sale_vat=round(net_sale_vat, 2),
        net_profit_without_vat=round(net_profit_without_vat, 2),
        net_profit_with_vat=round(net_profit_with_vat, 2),
        net_profit_ratio=net_profit_ratio,
        # RETURN totals
        return_qty_total=round(return_qty_total, 2),
        return_purchase_without_vat=round(return_purchase_without_vat, 2),
        return_purchase_with_vat=round(return_purchase_with_vat, 2),
        return_sale_without_vat=round(return_sale_without_vat, 2),
        return_sale_with_vat=round(return_sale_with_vat, 2),
        inv_bill_net=round(inv_bill_net, 2),
        inv_bill_total=round(inv_bill_total, 2),
        total_inv_price=round(float(total_inv_price), 2),
        total_vat=round(total_vat, 2),
        diff_without_vat=diff_without_vat,
        diff_with_vat=diff_with_vat,
        diff_class=diff_class,
        fmt=fmt,
    )


@can_access(3002)
def it_rep2():
    return dict()


@can_access(3009)
def rep_bydate():
    return dict()


@can_access(3013)
def rep_bydatej():
    qry = (
        "select (select upper(trim(name)) from items_main where id= items_det.item_idr ) as name ,  "
        " ( select name from key_type where id= (select item_type from items_main where id=item_idr ) )  "
        " as item_type , *   "
        " from items_det where expiration_date < (current_date + %s) and "
        " expiration_date >(current_date -20) and  items_count>0 order by expiration_date;"
    )
    qs = db.executesql(qry, placeholders=[int(request.args(0))], as_dict=True)
    return response.json(qs)


# =================================================================================================
@can_access(3004)
def conf_inv():
    inv = request.args(0)
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv="
        " %s  )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv="
        " %s  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/ "
        " CASE sum(inv_price) WHEN 0 THEN 1 ELSE sum(inv_price) END )* CASE sum(inv_price) WHEN 0 THEN 1 ELSE 100 END from items_det where supplier_inv="
        " %s  )) "
        " where id= %s"
    )
    db.executesql(qry, placeholders=[inv, inv, inv, inv])
    db.suppliers_bills(request.args(0)).update_record(bill_confirmation=True)
    qry = db(db.items_det.supplier_inv == inv).select()
    # تسجيل حركة شراء
    bill = db.suppliers_bills(inv)
    for row in qry:
        db.items_movement.insert(
            item_main=row.item_idr,
            item_det=row.id,
            move_type="شراء",
            move_date=request.now,
            qty_in=float(row.quantity or 0), qty_out=0,
            unit_price=float(row.buy_price or 0),
            reference=bill.bill_no if bill else "",
            ref_no=str(inv),
        )
    # =============>      negative_repair
    sum = db.items_det.items_count.sum()
    # print "--------------------------------------"
    # num = 1
    for row in qry:
        sum_row_0 = (
            db((db.items_det.item_idr == row.item_idr) & (db.items_det.items_count < 0))
            .select(sum)
            .first()[sum]
            or 0
        )
        sum_row_1 = (
            db((db.items_det.item_idr == row.item_idr) & (db.items_det.items_count > 0))
            .select(sum)
            .first()[sum]
            or 0
        )
        if (sum_row_1 >= (sum_row_0 * -1)) and (sum_row_0 != 0):
            # print "("+str(num)+") "+str(row.id) +'----'+ str(sum_row_0 ) + '------' + str(sum_row_1 )+"   ( ok )"
            for itm in db(db.items_det.item_idr == row.item_idr).select(
                orderby=~db.items_det.id
            ):
                if itm.items_count == 0:
                    continue
                elif itm.items_count < 0:
                    itm.items_count = 0
                elif (itm.items_count > 0) & (sum_row_0 < 0):
                    if itm.items_count >= (sum_row_0 * -1):
                        save_count = itm.items_count
                        itm.items_count = itm.items_count + sum_row_0
                        sum_row_0 = sum_row_0 + save_count
                itm.update_record()
        # else :
        #    #print "("+str(num)+") "+str(row.id) +'----'+ str(sum_row_0 ) + '------' + str(sum_row_1 )
        #    #db.rollback()
        # num = num+1
        # db.commit()
    db.commit()
    for itm in qry:
        if itm.return_count > 0:
            return redirect(URL("suppliers", "return_suppliers_bills_print/" + inv))
    return redirect(URL("items", "de_it"))


# ==================================================================================================
# ------------------>      تعديل بيانات صنف موجود
@can_access(3009)
def itm_chang():
    return dict()


@can_access(3009)
def getitm():
    it = db(
        (db.items_det.item_idr == db.items_main.id)
        & (db.items_det.id == request.args(0))
    ).select(
        db.items_det.id,
        db.items_det.items_count,
        db.items_main.name,
        db.items_det.expiration_date,
        db.items_det.public_price,
    )
    # it = db(db.items_det.item_id == request.args(0)).select().first()
    # it = db.items_det[request.args(0)]
    if it != None:
        return response.json([it])
    else:
        return response.json(0)


@can_access(3009)
def up_c():
    qry = (
        "update items_det  set items_count ="
        " %s where id ="
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(1), request.args(0)])
    return response.json("1")


@can_access(3009)
def up_sp():
    qry = (
        "update items_det  set public_price ="
        " %s where id ="
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(1), request.args(0)])
    return response.json("1")


@can_access(3009)
def up_ed():
    qry = (
        "update items_det  set expiration_date ="
        " %s::date where id ="
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(1), request.args(0)])
    return response.json("1")


# @auth.requires_membership("user1")
@can_access(3002)
def itm_rep():
    return dict()


# =================================================================================================
#                                        جداول الجرد
# =================================================================================================
@can_access(5200)
def inventory():
    if auth.has_membership("admin"):
        db.inventory.to_user.readable = False
        links = [
            lambda row: A(
                I(_class="fal fa-list"),
                "قوائم الجرد",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-repeat-alt"),
                "التكرار",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_dup_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-compass-slash"),
                "المفقود",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_not_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-print"),
                "طباعة",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_print_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-thumbs-up"),
                "اعتماد الجميع",
                _class="btn btn-outline-secondary",
                _href=URL("items", "inventory_items_approve_all", args=[row.id]),
            ),
        ]
        return dict(
            grid=SQLFORM.grid(
                db.inventory,
                user_signature=False,
                editable=True,
                paginate=200,
                links=links,
                deletable=False,
                create=True,
                csv=False,
                showbuttontext=True,
                maxtextlengths={"inventory.name": 200},
            )
        )
    elif auth.has_membership("user1"):
        q = db.inventory.open == True
        links = [
            lambda row: A(
                SPAN("قوائم الجرد", _class="btn btn-info", _title="الاصناف المجرودة"),
                _href=URL("items", "inventory_items", args=[row.id]),
            )
        ]
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                links=links,
                deletable=False,
                create=False,
                csv=False,
                showbuttontext=True,
                maxtextlengths={"inventory.name": 200},
            )
        )


@can_access(5200)
def inventory_items():
    q = db.inventory_items.inventory == request.args(0)
    if db.inventory[request.args(0)].open == False:
        return redirect(URL("items", "inventory"))
    if auth.has_membership("admin"):
        db.inventory_items.inventory.readable = False
        db.inventory_items.inventory.writable = False
        db.inventory_items.created_by.readable = True
        # db.inventory_items.difference.writable=False
        # links = [ lambda row: A(SPAN("اعتماد الجرد للصنف",_class="btn btn-info" ),_href=URL("items","inventory_items_approve",args=[row.id,request.args(0)]  )) ]
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                deletable=True,
                create=True,
                csv=True,
                showbuttontext=True,
                maxtextlengths={"inventory_items.item_name": 200},
                args=request.args[:1],
            )
        )
    elif auth.has_membership("user1"):
        db.inventory_items.id.readable = False
        db.inventory_items.real_quantity.readable = False
        db.inventory_items.difference.readable = False
        db.inventory_items.difference.writable = False
        db.inventory_items.inventory.readable = False
        db.inventory_items.inventory.writable = False
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                deletable=False,
                create=True,
                csv=False,
                showbuttontext=False,
                maxtextlengths={"inventory_items.item_name": 200},
                args=request.args[:1],
            )
        )


@can_access(5200)
def inventory_items_approve():
    it = db.inventory_items[request.args(0)]
    if it:
        if it.approve != True:
            if it.difference != 0:
                db1 = (
                    db(
                        (db.items_det.item_id == it.item_id)
                        & (db.items_det.items_count > 0)
                    )
                    .select()
                    .first()
                )
                db.items_det[db1.id] = dict(
                    items_count=db1.items_count + (it.difference * -1)
                )
            db.inventory_items[request.args(0)] = dict(approve=True)
            db.commit()
            return redirect(URL("items", "inventory_items/" + request.args(1)))
        else:
            return "تم اعتماد هذا الصنف"
        """
    if (it.real_quantity == db.items_det(it.item_id).items_count):
        db.items_det[it.item_id] = dict( items_count = it.quantity  )
        db.inventory_items[request.args(0)] = dict( approve = True )
        db.commit()
        return redirect(URL('items','inventory_items/'+request.args(1)))"""
    # return("الكمية غير متطابقة - تحذير تم تعديل بيانات الصنف بعد الجرد")


# ============================================================================================
@can_access(3002)
def itm_rep_det():
    item_id = request.args(0, cast=int)

    # 1) بيانات الصنف الأساسية
    q = db(db.items_main.id == item_id).select().first()

    # 2) جلب items_det مع suppliers_bills في استعلام واحد (JOIN)
    det_rows = db(db.items_det.item_idr == item_id).select(
        db.items_det.ALL,
        db.suppliers_bills.id,
        db.suppliers_bills.bill_date,
        db.suppliers_bills.bill_no,
        db.suppliers_bills.bill_confirmation,
        db.suppliers_bills.supplier,
        left=db.suppliers_bills.on(db.suppliers_bills.id == db.items_det.supplier_inv),
        orderby=db.items_det.id
    )

    # 3) جلب الكميات المباعة لكل items_det.id في استعلام واحد
    det_ids = [r.items_det.id for r in det_rows]
    sold_map = {}
    if det_ids:
        sold_sql = (
            "SELECT item_number, COALESCE(SUM(item_count),0) as total_sold "
            "FROM invoice_details WHERE item_number = ANY(%s) GROUP BY item_number"
        )
        sold_rows = db.executesql(sold_sql, placeholders=[det_ids], as_dict=True)
        for sr in sold_rows:
            sold_map[sr['item_number']] = float(sr['total_sold'])

    # 4) جلب أسماء الموردين في استعلام واحد
    supplier_ids = list(set(
        r.suppliers_bills.supplier for r in det_rows
        if r.suppliers_bills.id and r.suppliers_bills.supplier
    ))
    supplier_names = {}
    if supplier_ids:
        for s in db(db.suppliers.id.belongs(supplier_ids)).select(db.suppliers.id, db.suppliers.name):
            supplier_names[s.id] = s.name

    # 5) بناء بيانات الأوامر + حساب المجاميع
    m1 = m2 = m3 = m4 = mm2 = 0.0
    km1 = km2 = km3 = kmm2 = 0.0
    orders = []
    st = 0
    for r in det_rows:
        det = r.items_det
        sb = r.suppliers_bills
        st += 1
        ss = sold_map.get(det.id, 0.0)
        m3 += ss

        confirmed = bool(sb.bill_confirmation) if sb.id else False
        if confirmed:
            m1 += (det.quantity or 0)
            m2 += (det.items_count or 0)
            mm2 += (det.return_count or 0)
        else:
            km1 += (det.quantity or 0)
            km2 += (det.items_count or 0)
            kmm2 += (det.return_count or 0)

        orders.append(dict(
            st=st,
            confirmed=confirmed,
            supplier_inv=det.supplier_inv,
            bill_date=str(sb.bill_date) if sb.id and sb.bill_date else '',
            bill_no=sb.bill_no if sb.id else '',
            supplier_name=supplier_names.get(sb.supplier, '') if sb.id else '',
            quantity=det.quantity,
            sold=round(ss, 2),
            expiration_date=str(det.expiration_date) if det.expiration_date else '',
            buy_price=round((det.buy_price or 0), 2),
            public_price=round((det.public_price or 0), 2),
            sku_id=det.id,
            has_bill=bool(sb.id),
        ))

    # 6) المحول والمرتجع (استعلام واحد مجمع)
    rs_sql = (
        "SELECT admin_accept, COALESCE(SUM(d.item_count),0) as total "
        "FROM returned_supply_det d "
        "JOIN returned_supply r ON r.id = d.returned_supply "
        "WHERE d.item_id IN (SELECT id::text FROM items_det WHERE item_idr = %s) "
        "GROUP BY admin_accept"
    )
    rs_rows = db.executesql(rs_sql, placeholders=[item_id], as_dict=True)
    rs1 = 0.0
    rs2 = 0.0
    for rr in rs_rows:
        if rr['admin_accept'] == 'T':
            rs1 = float(rr['total'])
        elif rr['admin_accept'] == 'F':
            rs2 = float(rr['total'])

    # 7) جدول المبيعات الشهرية (crosstab)
    qs = (
        "SELECT * FROM crosstab("
        " 'select EXTRACT(YEAR FROM created_on)::integer as fday,"
        "EXTRACT(MONTH FROM created_on)::integer as fmonth,"
        " sum(item_count)::integer as fcount from invoice_details where item_number in"
        " (select id from items_det where item_idr = " + str(item_id) + " )"
        " group by EXTRACT(MONTH FROM created_on),EXTRACT(YEAR FROM created_on)"
        " order by EXTRACT(YEAR FROM created_on),EXTRACT(MONTH FROM created_on)"
        " ','select * from generate_series(1,12)' ) AS ct"
        " ( fcount int ,\"1\" int,\"2\" int,\"3\" int,\"4\" int,\"5\" int,\"6\" int,"
        "\"7\" int,\"8\" int,\"9\" int,\"10\" int,\"11\" int,\"12\" int )"
    )
    dataq = db.executesql(qs, as_dict=True)

    qs2 = (
        "select a.n ,(select sum(item_count)::integer as fcount from"
        " invoice_details where item_number in"
        " (select id from items_det where item_idr = " + str(item_id) + " )"
        " and EXTRACT(MONTH FROM created_on)::integer = a.n )"
        " from generate_series(1, 12) as a(n)"
    )
    dataq2 = db.executesql(qs2, as_dict=True)

    summary = dict(
        m1=round(m1, 2), m2=round(m2, 2), m3=round(m3, 2), m4=round(m4, 2),
        mm2=round(mm2, 2),
        km1=round(km1, 2), km2=round(km2, 2), kmm2=round(kmm2, 2),
        rs1=round(rs1, 2), rs2=round(rs2, 2),
    )

    return dict(
        q=q, orders=orders, summary=summary,
        dataq=dataq, dataq2=dataq2,
    )


# ********************************************************************************************
# شاشة محاضر الاتلاف
# ********************************************************************************************
@can_access(5200)
def damage_report():
    if auth.has_membership("admin"):
        links = [
            lambda row: A(
                SPAN("الاصناف", _class="btn btn-info"),
                _href=URL("items", "damage_report_det", args=[row.id]),
            ),
            lambda row: A(
                SPAN("احتساب", _class="btn btn-info"),
                _href=URL("items", "damage_report_count", args=[row.id]),
            ),
            lambda row: A(
                SPAN("اعتماد", _class="btn btn-info"),
                _href=URL("items", "damage_report_approving", args=[row.id]),
            ),
        ]
        q = (db.damage_report.user_accept == True) & (
            db.damage_report.admin_accept != True
        )
        db.damage_report.admin_accept.readable = False
        db.damage_report.admin_accept.writable = False
        grid = SQLFORM.grid(
            q,
            user_signature=False,
            links=links,
            orderby=~db.damage_report.id,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=True,
        )
        return dict(grid=grid)
    elif auth.has_membership("user1"):
        links = [
            lambda row: A(
                SPAN("الاصناف", _class="btn btn-info"),
                _href=URL("items", "damage_report_det", args=[row.id]),
            ),
            lambda row: A(
                SPAN("احتساب", _class="btn btn-info"),
                _href=URL("items", "damage_report_count", args=[row.id]),
            ),
        ]
        q = db.damage_report.user_accept == False
        db.damage_report.admin_accept.readable = False
        db.damage_report.admin_accept.writable = False
        grid = SQLFORM.grid(
            q,
            user_signature=False,
            links=links,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=True,
        )
        return dict(grid=grid)


@can_access(5200)
def damage_report_det():
    return dict()


@can_access(5200)
def damage_report_count():
    qry = (
        "update damage_report set  item_count= (select count(*) from damage_report_det where damage_report="
        " %s) , item_sum=(select sum(item_count) from damage_report_det where damage_report="
        " %s) where id = "
        " %s"
    )
    qs = db.executesql(qry, placeholders=[request.args(0), request.args(0), request.args(0)])
    redirect(URL(damage_report))


@can_access(5200)
def damage_report_det_add():
    items_det = db.damage_report_det.validate_and_insert(item_id=request.args(1))
    db.commit()
    return "0"


@can_access(5200)
def damage_report_approving():
    qry = (
        "update items_det set  items_count= 0  where id IN ( select item_id::integer  from damage_report_det where damage_report = "
        " %s) "
    )
    qs = db.executesql(qry, placeholders=[request.args(0)])
    db(db.damage_report.id == request.args(0)).update(admin_accept=True)
    db.commit()
    redirect(URL(damage_report))


# --------------------------------------------------------------------------------------------------------
@can_access(5200)
def inventory_items_approve_all():
    thread.start_new_thread(inv_approve_all, (request.args(0),))
    return "الرجاء الانتظار سوف تأخذ هذه العملية بعض من الوقت و شكرا لك"


@can_access(5200)
def inv_approve_all(sh):
    db._adapter.reconnect()
    try:
        # print sh
        inv = db((db.inventory_items.inventory == sh)).select()
        for i in inv:
            # print i.id
            it = db.inventory_items[i.id]
            if it:
                if it.approve != True:
                    # if ( it.difference!=0 ) :
                    #    db1= db((db.items_det.item_id==it.item_id) & (db.items_det.items_count>0)).select().first()
                    #    if db1 :
                    # db.items_det[db1.id] = dict(items_count = db1.items_count + (it.difference*-1) )
                    #    else :
                    db1 = db((db.items_det.item_id == it.item_id)).select().last()
                    db.items_det[db1.id] = dict(items_count=it.quantity)
                    db.inventory_items[i.id] = dict(approve=True)
                    db.commit()
        pr_id = db.print_report.validate_and_insert(er_dis="تمت عملية الاعتماد")
        db.commit()
    except Exception as e:
        print(e)
        pr_id = db.print_report.validate_and_insert(er_dis=e)
        db.commit()
    db._adapter.close()
    _lock.acquire()
    _lock.release()
    # =====================


@can_access(8201)
def inventory_items_dup_rep():
    return dict()


@can_access(8201)
def inventory_items_not_rep():
    return dict()


@can_access(8201)
def inventory_items_print_rep():
    return dict()


@can_access(3003)
def items_sales():
    return dict()


@can_access(3003)
def adjust_quantity():
    return dict()


@can_access(3008)
def items_merge():
    return dict()


@can_access(3008)
def items_merge_a():
    try:
        target_id = int(request.args(0) or 0)
        source_id = int(request.args(1) or 0)
    except (TypeError, ValueError):
        return dict(
            ok=False,
            mess="رقم الصنف غير صحيح. استخدم الرقم المسلسل الداخلي للصنف.",
            target_id=None,
            source_id=None,
            target_name="",
            source_name="",
            moved_count=0,
        )

    if not target_id or not source_id:
        return dict(
            ok=False,
            mess="يجب إدخال رقم الصنف الأساسي ورقم الصنف القديم.",
            target_id=target_id or "",
            source_id=source_id or "",
            target_name="",
            source_name="",
            moved_count=0,
        )

    if target_id == source_id:
        return dict(
            ok=False,
            mess="لا يمكن دمج الصنف مع نفسه. اختر رقمين مختلفين.",
            target_id=target_id,
            source_id=source_id,
            target_name="",
            source_name="",
            moved_count=0,
        )

    new_itm = db.items_main[target_id]
    old_itm = db.items_main[source_id]
    if new_itm is None or old_itm is None:
        return dict(
            ok=False,
            mess="لم يتم العثور على أحد الصنفين. تأكد من استخدام الرقم المسلسل الداخلي.",
            target_id=target_id,
            source_id=source_id,
            target_name=new_itm.name if new_itm else "",
            source_name=old_itm.name if old_itm else "",
            moved_count=0,
        )

    moved_count = db(db.items_det.item_idr == source_id).count()
    target_name = new_itm.name
    source_name = old_itm.name
    qry = "update items_det set item_idr = %s where  item_idr = %s"
    db.executesql(qry, placeholders=[target_id, source_id])
    old_itm.delete_record()
    db.commit()
    mess = "تم دمج الصنفين. أصبح الصنف الأساسي هو السجل المعتمد."
    return dict(
        ok=True,
        mess=mess,
        target_id=target_id,
        source_id=source_id,
        target_name=target_name,
        source_name=source_name,
        moved_count=moved_count,
    )


@can_access(3007)
def editcountItem():
    update_qry = (
        "update items_det set items_count =0 where item_idr = %s"
    )
    db.executesql(update_qry, placeholders=[request.args(0)])
    db.commit()
    redirect(URL("items", "negative_items"))


@can_access(3011)
def negative_items():
    qry = (
        "select  item_idr,sum(items_count) as sum , "
        " (select name from items_main  where items_main.id= item_idr ) as name  ,"
        " (select item_type from items_main  where items_main.id= item_idr ) as type  "
        " from items_det   "
        " group by item_idr   "
        " having sum(items_count) <0   "
        " ORDER BY type,item_idr   "
    )
    data = db.executesql(qry, as_dict=True)
    for i in data:
        itm = db.items_main(i["item_idr"])
        i["type"] = itm["item_type"].name
    return dict(data=data)


@can_access(3012)
def stop_items():
    return dict()


# ==============================
@can_access(3004)
def get_open_inv():
    query = (db.suppliers_bills.bill_confirmation == False) or (
        suppliers_bills.bill_confirmation == None
    )
    sp = db(query).select(orderby=db.suppliers_bills.id)
    for r in sp :
        r["s_n"] = r.supplier.name
        r["p_m"] = r.payment_method.name
        try:
            r["inv_type_name"] = r.invoce_type.name if r.invoce_type else ""
        except Exception:
            r["inv_type_name"] = ""
        qry = "select sum(inv_price) from items_det where supplier_inv = %s ;"
        qs = db.executesql(qry, placeholders=[r['id']])
        r["inv_inp_s"] =  qs[0][0]
        r["u_n"]=r['created_by'].first_name + "   " + r['created_by'].last_name
        r["inv_countg"]  =db(db.items_det.supplier_inv == r['id'] ).count()
        qry = "select sum(inv_price*vat) from items_det where supplier_inv = %s ;"
        qs2 = db.executesql(qry, placeholders=[r['id']])
        r["inv_inp_s_v"] = ( qs2[0][0] or 0 ) + ( qs[0][0] or 0 )
    data = (sp.as_json())
    return data 
