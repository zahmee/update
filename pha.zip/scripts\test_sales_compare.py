# -*- coding: utf-8 -*-
"""مقارنة المبيعات الشهرية (modules/sales_compare.py): build() وworkbook() على صفوف مصطنعة.

Run from the app root: python -B scripts/test_sales_compare.py
لا قاعدة بيانات: build() دالة نقية فوق صفوف الاستعلام.
"""

import io
import sys
import unittest
from datetime import datetime
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP / "modules"))

import sales_compare as sc

NOW = datetime(2026, 3, 10, 12, 0)


def srow(y, m, amount, cnt=10, vat=0.0, amount_td=None, cnt_td=None, vat_td=None):
    return {"y": y, "m": m, "cnt": cnt, "amount": amount, "vat": vat,
            "cnt_td": cnt if cnt_td is None else cnt_td,
            "amount_td": amount if amount_td is None else amount_td,
            "vat_td": vat if vat_td is None else vat_td}


def cell(res, y, m):
    return next(c for c in res["rows"][m - 1]["cells"] if c["y"] == y)


def total(res, y):
    return next(t for t in res["totals"] if t["y"] == y)


class BuildTests(unittest.TestCase):
    def setUp(self):
        sales = []
        # 2024 تبدأ في مارس (افتتاح فرع)، 2025 كاملة، 2026 حتى 10 مارس
        for m in range(3, 13):
            sales.append(srow(2024, m, 100.0))
        for m in range(1, 13):
            # td للأشهر بعد مارس صفر، وللمارس جزء حتى 10 مارس
            td = {3: 40.0}.get(m, 120.0 if m < 3 else 0.0)
            sales.append(srow(2025, m, 120.0, vat=12.0, amount_td=td, vat_td=td / 10))
        sales.append(srow(2026, 1, 132.0))
        sales.append(srow(2026, 2, 108.0))
        sales.append(srow(2026, 3, 50.0, cnt=4))
        self.raw = {"sales": sales, "ret": [{"y": 2025, "m": 1, "cnt": 1, "amount": 20.0, "vat": 2.0,
                                              "cnt_td": 1, "amount_td": 20.0, "vat_td": 2.0}]}

    def test_month_growth_and_gaps(self):
        res = sc.build(self.raw, NOW, 2024, 2026)
        self.assertEqual(res["years"], [2024, 2025, 2026])
        self.assertIsNone(cell(res, 2024, 1)["v"])            # قبل بداية البيانات
        self.assertIsNone(cell(res, 2025, 1)["g"])            # لا أساس في 2024
        self.assertEqual(cell(res, 2025, 3)["g"], 20.0)       # 120 مقابل 100
        self.assertEqual(cell(res, 2026, 1)["g"], 10.0)       # 132 مقابل 120
        self.assertEqual(cell(res, 2026, 2)["g"], -10.0)
        self.assertIsNone(cell(res, 2026, 4)["v"])            # شهر لم يأتِ

    def test_partial_month_is_like_for_like(self):
        c = sc.build(self.raw, NOW, 2025, 2026)
        mar = cell(c, 2026, 3)
        self.assertTrue(mar["partial"])
        self.assertEqual(mar["v"], 50.0)
        self.assertEqual(mar["g"], 25.0)                       # 50 مقابل 40 حتى 10 مارس، لا مقابل 120
        self.assertFalse(cell(c, 2025, 3)["partial"])

    def test_year_growth_uses_shared_months(self):
        res = sc.build(self.raw, NOW, 2024, 2026)
        t25 = total(res, 2025)
        self.assertEqual(t25["v"], 1440.0)
        self.assertEqual(t25["shared"], 10)                    # مارس-ديسمبر فقط
        self.assertEqual(t25["g"], 20.0)                       # 1200 مقابل 1000
        self.assertFalse(total(res, 2024)["complete"])        # 10 أشهر فقط
        t26 = total(res, 2026)
        self.assertTrue(t26["current"])
        self.assertEqual(t26["v"], 290.0)
        self.assertEqual(t26["g"], round((290 / 280 - 1) * 100, 1))  # حتى تاريخه: 120+120+40
        self.assertEqual(res["best_year"], 2025)

    def test_measures(self):
        net = sc.build(self.raw, NOW, 2025, 2025, measure="net")
        self.assertEqual(cell(net, 2025, 1)["v"], 100.0)
        ex = sc.build(self.raw, NOW, 2025, 2025, measure="net", ex_vat=True)
        self.assertEqual(cell(ex, 2025, 1)["v"], 90.0)        # (120-12) - (20-2)
        cnt = sc.build(self.raw, NOW, 2026, 2026, measure="count")
        self.assertEqual(total(cnt, 2026)["v"], 24)
        avg = sc.build(self.raw, NOW, 2026, 2026, measure="avg")
        self.assertEqual(cell(avg, 2026, 3)["v"], 12.5)
        self.assertIsNone(total(avg, 2026)["avg_month"])
        self.assertEqual(sc.build(self.raw, NOW, 2026, 2026, measure="bogus")["measure"], "sales")

    def test_growth_without_base(self):
        self.assertIsNone(sc.growth(10, 0))
        self.assertIsNone(sc.growth(10, -5))
        self.assertIsNone(sc.growth(None, 5))

    def test_workbook(self):
        res = sc.build(self.raw, NOW, 2024, 2026, measure="net", ex_vat=True)
        data = sc.workbook(res)
        self.assertEqual(data[:2], b"PK")
        import zipfile
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            sheet = z.read("xl/worksheets/sheet1.xml").decode("utf-8")
        self.assertIn('rightToLeft="1"', sheet)


if __name__ == "__main__":
    unittest.main(verbosity=2)
