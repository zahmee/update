Vue.component('v-select', VueSelect.VueSelect);

function debounce(fn, delay) {
    var timer;
    return function() {
        var args = arguments, ctx = this;
        clearTimeout(timer);
        timer = setTimeout(function() { fn.apply(ctx, args); }, delay);
    };
}

var API_BASE = window.location.origin + window.location.pathname.replace(/\/customers\/index\/?$/, '/customers_api/');

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true,
            userType: 0,
            balState: '',
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        cust_in:  [],
        cust_out: [],
        coust_pay: { coust: 0, mount: 0.0, note: '', type: 10, pay_note: '', send_sms: true },
        paying: false,
        // تسوية رصيد عميل واحد (للمدير)
        adjust: { balance: null, amount: '', reason: '', error: '', loading: false, saving: false },
        // تسوية جماعية للأرصدة السالبة الصغيرة (للمدير)
        small: { limit: 5, limitUsed: 5, rows: [], total: 0, reason: '', loaded: false, loading: false, applying: false },
        loading: false,
    },
    created() {
        this.debouncedSearch = debounce(this.onChange.bind(this), 400);
        this.loading = true;
        fetch(API_BASE + 'get_customers', {
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        }).then(r => r.json())
          .then(data => {
              this.data           = Api.getData(data);
              this.data_row_count = data.count;
          }).finally(() => { this.loading = false; });
    },
    computed: {
        // مجاميع ظاهرة في الصفحة الحالية فقط
        totalInv() {
            return this.data.reduce((s, r) => s + parseFloat(r.cus_inv || 0), 0).toFixed(2);
        },
        totalPay() {
            return this.data.reduce((s, r) => s + parseFloat(r.cus_pay || 0), 0).toFixed(2);
        },
        totalBal() {
            return (parseFloat(this.totalInv) - parseFloat(this.totalPay)).toFixed(2);
        },
        adjustAmount() {
            var v = parseFloat(this.adjust.amount);
            return isFinite(v) && v > 0 ? v : 0;
        },
        // التسوية تأخذ إشارة الرصيد، فتقرّبه من الصفر ولا تقلبه
        adjustAfter() {
            var b = this.adjust.balance || 0;
            var signed = b > 0 ? this.adjustAmount : -this.adjustAmount;
            return Math.round((b - signed) * 100) / 100;
        },
        totalPages() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage() {
            return this.getData.page + 1;
        },
        visiblePages() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData(extraParams) {
            const params = {
                page:        this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText:  this.getData.SearchText,
                SortBy:      this.getData.SortBy,
                sequence:    this.getData.sortAsc,
                userType:    this.getData.userType,
                balState:    this.getData.balState,
                ...extraParams,
            };
            const url = new URL(API_BASE + 'get_customers');
            Object.keys(params).forEach(k => url.searchParams.append(k, params[k]));
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(r => r.json());
        },
        onChange() {
            this.getData.page = 0;
            this.selectedRow  = -1;
            this.loading = true;
            this.fetchData().then(data => {
                this.data           = Api.getData(data);
                this.data_row_count = data.count;
            }).finally(() => { this.loading = false; });
        },
        goToPage(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(data => {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
            }).finally(() => { this.loading = false; });
        },
        sortBy(field) {
            this.getData.SortBy  = (this.getData.SortBy === field)
                ? field : field;
            this.getData.sortAsc = (this.getData.SortBy !== field) ? true
                : !this.getData.sortAsc;
            this.getData.SortBy  = field;
            this.onChange();
        },
        // الرصيد = المشتريات الآجلة ناقص السدادات (والتسويات ضمن السدادات)
        bal(row) {
            return parseFloat((row && row.cus_inv) || 0) - parseFloat((row && row.cus_pay) || 0);
        },
        balClass(value) {
            var v = parseFloat(value) || 0;
            if (v > 0.005)  return 'money-positive';  // عليه
            if (v < -0.005) return 'money-credit';    // له
            return 'money-clear';
        },
        rowClass(row, index) {
            if (this.selectedRow === index) return 'customer-row-selected';
            var b = this.bal(row);
            if (b > 500)    return 'customer-row-danger';   // مديونية عالية
            if (b > 0.005)  return 'customer-row-warning';  // مديونية بسيطة
            if (b < -0.005) return 'customer-row-credit';   // له رصيد
            return '';
        },
        // إضافة مبلغ إلى سدادات العميل في الجدول والشريط دون إعادة التحميل
        bumpPay(customerId, amount) {
            var add = function (r) {
                return { ...r, cus_pay: (parseFloat(r.cus_pay || 0) + parseFloat(amount)).toFixed(2) };
            };
            var i = this.data.findIndex(function (r) { return r.id === customerId; });
            if (i >= 0) this.$set(this.data, i, add(this.data[i]));
            if (this.edit_row_data.id === customerId) this.edit_row_data = add(this.edit_row_data);
        },
        rowSelect(index, row) {
            this.selectedRow   = index;
            this.edit_row_data = { ...row };
        },
        edit_row() { this.new_row = false; },
        new_row_click() {
            this.new_row       = true;
            this.edit_row_data = {};
        },
        save_data() {
            var name = (this.edit_row_data.name || '').trim();
            var mobile = (this.edit_row_data.mobile || '').trim();
            if (!name) {
                Swal.fire('تنبية', 'اسم العميل مطلوب.', 'error');
                return;
            }
            if (!/^05\d{8}$/.test(mobile)) {
                Swal.fire('تنبية', 'رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05.', 'error');
                return;
            }
            this.edit_row_data.name = name;
            this.edit_row_data.mobile = mobile;
            const endpoint = this.new_row ? 'new_customer' : 'edit_customer';
            const url = new URL(API_BASE + endpoint);
            Object.keys(this.edit_row_data).forEach(k =>
                url.searchParams.append(k, this.edit_row_data[k]));
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (Api.isOk(data)) {
                        var result = Api.getData(data);
                        const saved = { ...this.edit_row_data, id: result.id };
                        saved.name = saved.name.trim();
                        if (this.new_row) {
                            this.data.push(saved);
                        } else {
                            // إصلاح: Vue 2 reactivity — يجب استخدام $set
                            this.$set(this.data, this.selectedRow, saved);
                        }
                        this.edit_row_data = {};
                        this.selectedRow   = -1;
                        this.new_row       = true;
                        bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                        Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Api.showError(data);
                    }
                });
        },
        cancel_data() {
            this.edit_row_data = {};
            this.selectedRow   = -1;
            this.new_row       = true;
        },
        items_history() {
            window.open(window.location.href + '/../customer_status_rep/' + this.edit_row_data.id);
        },
        items_sales() {
            window.open(window.location.href + '/../purchase/' + this.edit_row_data.id);
        },
        adjust_quantity() {
            window.open(window.location.href + '/../customers_pay/' + this.edit_row_data.id);
        },
        items_history2() {
            fetch(API_BASE + 'get_fast_data/' + this.edit_row_data.id, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(r => r.json())
              .then(data => {
                  if (Api.isOk(data)) {
                      var result = Api.getData(data);
                      this.cust_in  = result.in;
                      this.cust_out = result.out;
                  } else {
                      Api.showError(data);
                  }
              });
        },
        // نفس شرط الإرسال في customers_api.save_coust_pay
        hasMobile(row) {
            return String((row && row.mobile) || '').length === 10;
        },
        coust_pay_click() {
            const now = new Date();
            const pay_note = `عن سنة ${now.getFullYear()} لشهر ${now.getMonth() + 1}`;
            // الرسالة مفعّلة في البداية، ويستطيع المستخدم إلغاءها لهذا السداد
            this.coust_pay = { coust: 0, mount: 0.0, note: '', type: 10, pay_note: pay_note,
                               send_sms: this.hasMobile(this.edit_row_data) };
        },
        save_pay_data() {
            // الزر يُعطَّل أثناء الحفظ: النقر المتكرر كان يسجّل السداد نفسه عدة مرات
            if (this.paying) return;
            if (!this.coust_pay.mount || parseFloat(this.coust_pay.mount) <= 0) {
                Swal.fire('تنبية', 'يجب إدخال مبلغ صحيح أكبر من صفر.', 'error');
                return;
            }
            this.coust_pay.coust = this.edit_row_data.id;
            const customerId = this.edit_row_data.id;
            const amount = this.coust_pay.mount;
            const url = new URL(API_BASE + 'save_coust_pay');
            Object.keys(this.coust_pay).forEach(k =>
                url.searchParams.append(k, this.coust_pay[k]));
            this.paying = true;
            fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (Api.isOk(data)) {
                        bootstrap.Modal.getInstance(document.getElementById("pay_Modal")).hide();
                        this.bumpPay(customerId, amount);
                        Swal.fire('عمل رائع', data.mess || 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Api.showError(data);
                    }
                })
                .catch(() => Swal.fire('خطأ', 'تعذّر الاتصال بالخادم. تحقق من سجل السدادات قبل إعادة المحاولة.', 'error'))
                .finally(() => { this.paying = false; });
        },
        // ── تسوية رصيد عميل واحد (للمدير) ──
        open_adjust() {
            // الخطأ يُعرض داخل النافذة: إغلاقها أثناء حركة الفتح يتجاهله Bootstrap
            this.adjust = { balance: null, amount: '', reason: '', error: '', loading: true, saving: false };
            const url = new URL(API_BASE + 'get_balance');
            url.searchParams.append('customer_id', this.edit_row_data.id);
            // الرصيد يُقرأ من القاعدة الآن، لا من الجدول الذي قد يكون قديماً
            fetch(url, { headers: { 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (!Api.isOk(data)) {
                        this.adjust.error = Api.getError(data) || 'تعذّر جلب رصيد العميل.';
                        return;
                    }
                    const b = parseFloat(Api.getData(data).balance) || 0;
                    if (Math.abs(b) < 0.005) {
                        this.adjust.error = 'رصيد العميل صفر الآن، لا يحتاج تسوية.';
                        return;
                    }
                    this.adjust.balance = b;
                    this.adjust.amount = Math.abs(b).toFixed(2);
                })
                .catch(() => { this.adjust.error = 'تعذّر جلب رصيد العميل.'; })
                .finally(() => { this.adjust.loading = false; });
        },
        save_adjust() {
            if (this.adjust.saving || this.adjust.balance === null) return;
            const amount = parseFloat(this.adjust.amount);
            const reason = (this.adjust.reason || '').trim();
            if (!(amount > 0)) {
                Swal.fire('تنبيه', 'أدخل مبلغ تسوية أكبر من صفر.', 'error');
                return;
            }
            if (amount > Math.abs(this.adjust.balance) + 0.005) {
                Swal.fire('تنبيه', 'مبلغ التسوية أكبر من الرصيد.', 'error');
                return;
            }
            if (reason.length < 3) {
                Swal.fire('تنبيه', 'اكتب سبب التسوية.', 'error');
                return;
            }
            const customerId = this.edit_row_data.id;
            const url = new URL(API_BASE + 'adjust_balance');
            url.searchParams.append('customer_id', customerId);
            url.searchParams.append('amount', amount.toFixed(2));
            url.searchParams.append('expected_balance', this.adjust.balance.toFixed(2));
            url.searchParams.append('reason', reason);
            this.adjust.saving = true;
            fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (Api.isOk(data)) {
                        const res = Api.getData(data);
                        this.closeModal('adjust_Modal');
                        this.bumpPay(customerId, res.amount);
                        Swal.fire('تمت التسوية', 'رصيد العميل الآن ' + parseFloat(res.balance).toFixed(2), 'success');
                    } else {
                        Api.showError(data);
                    }
                })
                .catch(() => Swal.fire('خطأ', 'تعذّر الاتصال بالخادم. تحقق من سدادات العميل قبل إعادة المحاولة.', 'error'))
                .finally(() => { this.adjust.saving = false; });
        },
        // ── تسوية جماعية للأرصدة السالبة الصغيرة (للمدير) ──
        open_small() {
            this.small = { limit: 5, limitUsed: 5, rows: [], total: 0, reason: '', loaded: false, loading: false, applying: false };
        },
        load_small() {
            const limit = parseFloat(this.small.limit);
            if (!(limit > 0) || limit > 50) {
                Swal.fire('تنبيه', 'الحد يجب أن يكون أكبر من صفر ولا يتجاوز 50 ريال.', 'error');
                return;
            }
            const url = new URL(API_BASE + 'small_credits');
            url.searchParams.append('limit_amount', limit);
            this.small.loading = true;
            fetch(url, { headers: { 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(data => {
                    if (!Api.isOk(data)) { Api.showError(data); return; }
                    this.small.rows = Api.getData(data) || [];
                    this.small.total = parseFloat(data.total) || 0;
                    this.small.limitUsed = limit;
                    this.small.reason = 'تسوية فروقات صغيرة أقل من ' + limit + ' ريال';
                    this.small.loaded = true;
                })
                .catch(() => Swal.fire('خطأ', 'تعذّر جلب القائمة.', 'error'))
                .finally(() => { this.small.loading = false; });
        },
        apply_small() {
            if (this.small.applying || !this.small.loaded || !this.small.rows.length) return;
            const reason = (this.small.reason || '').trim();
            if (reason.length < 3) {
                Swal.fire('تنبيه', 'اكتب سبب التسوية.', 'error');
                return;
            }
            Swal.fire({
                title: 'تأكيد التسوية',
                text: 'عدد العملاء: ' + this.small.rows.length + ' — المجموع: ' + this.small.total.toFixed(2)
                    + ' ريال. سيُسجَّل لكل منهم قيد تسوية يجعل رصيده صفراً.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، نفّذ',
                cancelButtonText: 'تراجع',
            }).then(result => {
                if (!result.isConfirmed) return;
                const url = new URL(API_BASE + 'settle_small_credits');
                url.searchParams.append('limit_amount', this.small.limitUsed);
                url.searchParams.append('expected_count', this.small.rows.length);
                url.searchParams.append('expected_total', this.small.total.toFixed(2));
                url.searchParams.append('reason', reason);
                this.small.applying = true;
                fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' } })
                    .then(r => r.json())
                    .then(data => {
                        if (Api.isOk(data)) {
                            const res = Api.getData(data);
                            this.closeModal('small_Modal');
                            Swal.fire('تمت التسوية', 'عدد العملاء: ' + res.count + ' — المجموع: '
                                + parseFloat(res.total).toFixed(2) + ' ريال', 'success');
                            this.onChange();
                        } else {
                            Api.showError(data);
                        }
                    })
                    .catch(() => Swal.fire('خطأ', 'تعذّر الاتصال بالخادم. اعرض القائمة مرة أخرى قبل إعادة المحاولة.', 'error'))
                    .finally(() => { this.small.applying = false; });
            });
        },
        closeModal(id) {
            const el = document.getElementById(id);
            const modal = el && bootstrap.Modal.getInstance(el);
            if (modal) modal.hide();
        },
    },
    watch: {
        'getData.userType': function() { this.onChange(); },
        'getData.balState': function() { this.onChange(); },
    }
});
