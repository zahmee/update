# -*- coding: utf-8 -*-
"""ZATCA sending + issue-log regressions using an isolated in-memory DAL database.

Run from the app root: python -B scripts/test_zatca_sending.py
No application models, operational database, certificates or network calls are used:
the ZATCA call is replaced by fake process functions that return or raise what the real
api_client would.
"""

import json
import sys
import unittest
from datetime import date, datetime, time, timedelta
from pathlib import Path
from unittest.mock import patch

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP.parents[1]))
sys.path.insert(0, str(APP / "modules"))

from gluon import DAL, Field
from zatca_direct.api_client import ZatcaApiError, ZatcaConnectionError
import zatca_sending as zs

zs.logger.disabled = True  # اختبار تعذّر السجل يطبع أثراً متوقعاً

NOW = datetime(2026, 9, 24, 10, 0, 0)

REJECTED_400 = json.dumps({
    "validationResults": {
        "infoMessages": [],
        "warningMessages": [],
        "errorMessages": [{"type": "ERROR", "code": "BR-KSA-37", "category": "KSA",
                           "message": "The seller address building number must contain 4 digits.",
                           "status": "ERROR"}],
        "status": "ERROR"},
    "reportingStatus": "NOT_REPORTED"})

REPORTED_WITH_WARNINGS = {
    "validationResults": {
        "infoMessages": [],
        "warningMessages": [{"code": "BR-CO-17", "message": "VAT category tax amount rounding"},
                            {"code": "BR-S-09", "message": "VAT category tax amount"}],
        "errorMessages": [], "status": "WARNING"},
    "reportingStatus": "REPORTED"}

CERT = {"privateKey": "SECRET-KEY", "pcsid_binarySecurityToken": "TOKEN",
        "pcsid_secret": "SECRET", "environment": "simulation"}


def make_db():
    db = DAL("sqlite:memory")
    for name in ("invoice_master", "inv_return_master"):
        db.define_table(name, Field("total", "double"), Field("created_on", "datetime"),
                        Field("pih_txt", "text"), Field("qr_code", "text"),
                        Field("zatca_res", "text"), Field("send_to_zatca", "boolean", default=False))
    db.define_table("invoice_sending", Field("inv_id", "integer"), Field("inv_type", "integer"),
                    Field("inv_date", "date"), Field("inv_time", "time"), Field("inv_data", "text"),
                    Field("send", "boolean", default=False), Field("total_sum", "double"))
    db.define_table("csr_config", Field("privatekey", "text"), Field("csr", "text"),
                    Field("pcsid_binarysecuritytoken", "text"), Field("pcsid_secret", "text"),
                    Field("environment"))
    # نفس تعريف models/db_3_operations.py
    db.define_table(
        "zatca_issue",
        Field("inv_type", "integer"), Field("inv_id", "integer"), Field("inv_date", "date"),
        Field("inv_time", "time"), Field("inv_total", "double"), Field("kind", length=20),
        Field("state", length=12, default="open"), Field("http_status", "integer"),
        Field("zatca_status", length=40), Field("codes", length=255), Field("message", "text"),
        Field("response", "text"), Field("payload", "text"), Field("attempts", "integer", default=0),
        Field("first_at", "datetime"), Field("last_at", "datetime"), Field("sent_at", "datetime"),
        Field("history", "text"), Field("resolved_by", "integer"), Field("resolved_at", "datetime"),
        Field("resolve_note", length=255))
    db.define_table(
        "zatca_send_control",
        Field("paused", "boolean", default=False), Field("paused_until", "datetime"),
        Field("pause_reason", length=255), Field("paused_by", "integer"),
        Field("paused_by_name", length=128), Field("paused_at", "datetime"), Field("history", "text"))
    return db


def queue_invoice(db, inv_type=1, total=115.0, data="default"):
    master = db.invoice_master if inv_type == 1 else db.inv_return_master
    inv_id = master.insert(total=total, created_on=NOW - timedelta(hours=1))
    if data == "default":
        data = json.dumps({"cert_info": CERT, "document_type": "SIMSI", "icv_start": 7,
                           "pih_base64": "PIH", "invoice": {"ID": "INV-%012d" % inv_id}})
    row_id = db.invoice_sending.insert(inv_id=inv_id, inv_type=inv_type, inv_date=date(2026, 9, 24),
                                       inv_time=time(9, 0), inv_data=data, send=False)
    return inv_id, row_id


def ok_result(raw=None):
    return {"status": "REPORTED", "pih_base64": "NEW-HASH", "qr_value": "QR",
            "raw_response": raw if raw is not None else {"reportingStatus": "REPORTED"}}


def raiser(exc):
    def fn(_payload):
        raise exc
    return fn


class ClassificationTests(unittest.TestCase):
    def test_validation_errors_are_the_only_rejection(self):
        info = zs.classify_http(400, REJECTED_400)
        self.assertEqual(info["kind"], "rejected")
        self.assertTrue(info["leaves_queue"])
        self.assertEqual(info["codes"], "BR-KSA-37")
        self.assertEqual(info["zatca_status"], "NOT_REPORTED")
        self.assertIn("4 digits", info["message"])

    def test_maintenance_and_server_errors_stay_in_queue(self):
        for code, body in ((503, "<html><body>Service Unavailable</body></html>"),
                           (500, '{"message": "Internal Server Error"}'), (502, ""), (429, "{}")):
            info = zs.classify_http(code, body)
            self.assertEqual(info["kind"], "server", code)
            self.assertFalse(info["leaves_queue"])
            self.assertIn("(%d)" % code, info["message"])
        self.assertNotIn("<html", zs.classify_http(503, "<html>x</html>")["message"])

    def test_credentials_and_unknown_responses_stay_in_queue(self):
        self.assertEqual(zs.classify_http(401, "")["kind"], "auth")
        self.assertEqual(zs.classify_http(403, "Forbidden")["kind"], "auth")
        for code, body in ((404, "Not Found"), (400, '{"errors": [{"code": "X", "message": "bad"}]}'),
                           (200, "<html>maintenance</html>")):
            info = zs.classify_http(code, body)
            self.assertEqual(info["kind"], "unexpected", code)
            self.assertFalse(info["leaves_queue"])

    def test_exceptions(self):
        self.assertEqual(zs.classify_exception(ZatcaConnectionError("timeout"))["kind"], "connection")
        self.assertEqual(zs.classify_exception(ZatcaApiError(400, REJECTED_400))["kind"], "rejected")
        info = zs.classify_exception(KeyError("invoice"), tb="Traceback: boom")
        self.assertEqual(info["kind"], "internal")
        self.assertEqual(info["response"], "Traceback: boom")

    def test_prefixed_error_text_is_parsed(self):
        parsed = zs.parse_body("ZATCA API Error (400): " + REJECTED_400)
        self.assertEqual(parsed["errors"][0]["code"], "BR-KSA-37")

    def test_warnings_are_read_from_validation_results(self):
        warn = zs.warning_info(REPORTED_WITH_WARNINGS)
        self.assertEqual(warn["kind"], "warning")
        self.assertEqual(warn["codes"], "BR-CO-17, BR-S-09")
        self.assertIn("(+1)", warn["message"])
        self.assertIsNone(zs.warning_info({"reportingStatus": "REPORTED"}))

    def test_not_reported_is_never_success(self):
        self.assertEqual(zs.classify_result({"reportingStatus": "NOT_REPORTED"}, "NOT_REPORTED")["kind"],
                         "rejected")
        self.assertEqual(zs.classify_result({}, "PENDING")["kind"], "unexpected")

    def test_payload_never_keeps_certificate(self):
        payload = zs.strip_payload({"cert_info": CERT, "invoice": {"ID": "1"}})
        self.assertNotIn("SECRET", payload)
        self.assertEqual(json.loads(payload), {"invoice": {"ID": "1"}})


class ProcessRowTests(unittest.TestCase):
    def setUp(self):
        self.db = make_db()
        self.lock = patch.object(zs, "_lock_queue_row", lambda db, rid: bool(db.invoice_sending(rid))
                                 and not db.invoice_sending(rid).send)
        self.lock_issue = patch.object(zs, "_lock_issue", lambda db, iid: bool(db.zatca_issue(iid)))
        self.lock.start()
        self.lock_issue.start()

    def tearDown(self):
        self.lock.stop()
        self.lock_issue.stop()
        self.db.close()

    def run_row(self, row_id, fn, now=NOW):
        return zs.process_row(self.db, row_id, process_fn=fn, now=now)

    def issue(self, inv_type, inv_id):
        return zs.find_issue(self.db, inv_type, inv_id)

    def test_success_updates_invoice_and_logs_nothing(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        out = self.run_row(row_id, lambda p: ok_result())
        self.assertTrue(out["sent"])
        inv = db.invoice_master(inv_id)
        self.assertTrue(inv.send_to_zatca)
        self.assertEqual((inv.pih_txt, inv.qr_code), ("NEW-HASH", "QR"))
        self.assertTrue(db.invoice_sending(row_id).send)
        self.assertIsNone(self.issue(1, inv_id))

    def test_warnings_are_logged_for_review(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        out = self.run_row(row_id, lambda p: ok_result(REPORTED_WITH_WARNINGS))
        self.assertTrue(out["sent"] and out["warnings"])
        issue = self.issue(1, inv_id)
        self.assertEqual((issue.kind, issue.state, issue.attempts), ("warning", "open", 0))
        self.assertEqual(issue.sent_at, NOW)
        self.assertEqual(issue.inv_total, 115.0)

    def test_maintenance_keeps_invoice_queued_until_accepted(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        for i in range(2):
            out = self.run_row(row_id, raiser(ZatcaApiError(503, "<html>down</html>")),
                               now=NOW + timedelta(hours=2 * i))
            self.assertFalse(out["final"])
            self.assertTrue(out["logged"])
        self.assertFalse(db.invoice_sending(row_id).send)
        issue = self.issue(1, inv_id)
        self.assertEqual((issue.kind, issue.attempts, issue.http_status), ("server", 2, 503))
        self.assertEqual(issue.first_at, NOW)
        self.assertEqual(len(json.loads(issue.history)), 2)
        self.assertIsNone(issue.payload)

        out = self.run_row(row_id, lambda p: ok_result(), now=NOW + timedelta(hours=5))
        self.assertTrue(out["sent"])
        issue = self.issue(1, inv_id)
        self.assertEqual(issue.state, "sent_later")
        self.assertEqual(issue.sent_at, NOW + timedelta(hours=5))
        self.assertEqual(json.loads(issue.history)[-1]["kind"], "sent")

    def test_rejection_leaves_queue_with_payload_but_no_certificate(self):
        db = self.db
        inv_id, row_id = queue_invoice(db, inv_type=2, total=-40.0)
        out = self.run_row(row_id, raiser(ZatcaApiError(400, REJECTED_400)))
        self.assertTrue(out["final"])
        self.assertIsNone(db.invoice_sending(row_id))
        issue = self.issue(2, inv_id)
        self.assertEqual((issue.kind, issue.codes, issue.http_status), ("rejected", "BR-KSA-37", 400))
        self.assertIn("BR-KSA-37", issue.response)
        self.assertNotIn("SECRET", issue.payload)
        self.assertEqual(json.loads(issue.payload)["icv_start"], 7)
        self.assertEqual((issue.inv_date, issue.inv_time), (date(2026, 9, 24), time(9, 0)))

    def test_bad_queue_data_is_logged_and_removed(self):
        db = self.db
        inv_id, row_id = queue_invoice(db, data="{not json")
        out = self.run_row(row_id, lambda p: self.fail("must not send"))
        self.assertTrue(out["final"])
        self.assertEqual(self.issue(1, inv_id).kind, "bad_data")
        self.assertIsNone(db.invoice_sending(row_id))

    def test_internal_errors_and_connection_errors_stay(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        self.assertFalse(self.run_row(row_id, raiser(KeyError("invoice")))["final"])
        self.assertEqual(self.issue(1, inv_id).kind, "internal")
        self.assertIn("KeyError", self.issue(1, inv_id).response)
        self.assertFalse(self.run_row(row_id, raiser(ZatcaConnectionError("down")))["final"])
        self.assertEqual((self.issue(1, inv_id).kind, self.issue(1, inv_id).attempts), ("connection", 2))
        self.assertIsNotNone(db.invoice_sending(row_id))

    def test_log_failure_never_drops_invoice_or_undoes_send(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        with patch.object(zs, "record_problem", side_effect=RuntimeError("log down")):
            out = self.run_row(row_id, raiser(ZatcaApiError(400, REJECTED_400)))
        self.assertFalse(out["final"])
        self.assertFalse(out["logged"])
        self.assertIsNotNone(db.invoice_sending(row_id))

        with patch.object(zs, "record_sent", side_effect=RuntimeError("log down")):
            out = self.run_row(row_id, lambda p: ok_result(REPORTED_WITH_WARNINGS))
        self.assertTrue(out["sent"])
        self.assertTrue(db.invoice_master(inv_id).send_to_zatca)
        self.assertTrue(db.invoice_sending(row_id).send)

    def test_busy_row_is_skipped(self):
        inv_id, row_id = queue_invoice(self.db)
        with patch.object(zs, "_lock_queue_row", lambda db, rid: False):
            out = self.run_row(row_id, lambda p: self.fail("must not send"))
        self.assertEqual(out["status"], "BUSY")

    def test_ignored_issue_stays_ignored_resolved_reopens(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        fail = raiser(ZatcaApiError(500, ""))
        self.run_row(row_id, fail)
        issue_id = self.issue(1, inv_id).id
        self.assertEqual(zs.set_state(db, issue_id, "ignored", "no", user_id=3)[0], False)
        self.assertTrue(zs.set_state(db, issue_id, "ignored", "فاتورة تجربة", user_id=3)[0])
        self.run_row(row_id, fail)
        self.assertEqual(self.issue(1, inv_id).state, "ignored")
        self.assertTrue(zs.set_state(db, issue_id, "resolved", "تمت مراسلة الهيئة", user_id=3)[0])
        self.assertEqual(self.issue(1, inv_id).resolved_by, 3)
        self.run_row(row_id, fail)
        issue = self.issue(1, inv_id)
        self.assertEqual((issue.state, issue.resolved_by, issue.attempts), ("open", None, 3))
        self.assertFalse(zs.set_state(db, issue_id, "sent_later", "")[0])

    def test_requeue_restores_certificate_and_guards_duplicates(self):
        db = self.db
        db.csr_config.insert(privatekey="K2", pcsid_binarysecuritytoken="T2", pcsid_secret="S2",
                             environment="simulation")
        inv_id, row_id = queue_invoice(db)
        self.run_row(row_id, raiser(ZatcaApiError(400, REJECTED_400)))
        issue_id = self.issue(1, inv_id).id
        cert_fn = lambda csr: {"privateKey": csr.privatekey, "pcsid_secret": csr.pcsid_secret}

        ok, _ = zs.requeue(db, issue_id, actor="مدير", cert_info_fn=cert_fn)
        self.assertTrue(ok)
        queued = db(db.invoice_sending.inv_id == inv_id).select().first()
        data = json.loads(queued.inv_data)
        self.assertEqual(data["cert_info"]["privateKey"], "K2")
        self.assertEqual(data["icv_start"], 7)
        self.assertEqual(json.loads(self.issue(1, inv_id).history)[-1]["kind"], "requeued")

        ok, mess = zs.requeue(db, issue_id, cert_info_fn=cert_fn)
        self.assertFalse(ok)
        self.assertIn("طابور", mess)

        self.run_row(queued.id, lambda p: ok_result())
        self.assertEqual(self.issue(1, inv_id).state, "sent_later")
        ok, mess = zs.requeue(db, issue_id, cert_info_fn=cert_fn)
        self.assertFalse(ok)
        self.assertIn("مُرسلة", mess)

    def test_manual_removal_is_recorded_with_payload(self):
        db = self.db
        inv_id, row_id = queue_invoice(db)
        zs.record_removed(db, db.invoice_sending(row_id), actor="مدير", now=NOW)
        issue = self.issue(1, inv_id)
        self.assertEqual((issue.kind, issue.attempts), ("removed", 0))
        self.assertNotIn("SECRET", issue.payload)
        self.assertEqual(json.loads(issue.history)[0]["by"], "مدير")


class SendControlTests(unittest.TestCase):
    """الإيقاف المؤقت والمفتوح، والاستئناف التلقائي، ودورة الجدولة مع الإيقاف وتعطل الهيئة."""

    def setUp(self):
        self.db = make_db()
        self.lock = patch.object(zs, "_lock_queue_row", lambda db, rid: bool(db.invoice_sending(rid))
                                 and not db.invoice_sending(rid).send)
        self.lock.start()
        self.calls = []

    def tearDown(self):
        self.lock.stop()
        self.db.close()

    def run_queue(self, fn, now=NOW):
        return zs.run_queue(self.db, process_fn=fn, now_fn=lambda: now)

    def counting(self, fn):
        def wrapped(payload):
            self.calls.append(payload)
            return fn(payload)
        return wrapped

    def queue(self, n):
        rows = [queue_invoice(self.db)[1] for _ in range(n)]
        self.db.commit()  # كما في الواقع: طلب البيع يعتمد صف الطابور قبل أي زيارة
        return rows

    def history(self):
        return json.loads(self.db.zatca_send_control(1).history)

    def test_timed_pause_resumes_by_itself_and_is_recorded(self):
        db = self.db
        ok, mess = zs.pause_sending(db, "1h", "صيانة الهيئة", user_id=1, actor="مدير", now=NOW)
        self.assertTrue(ok)
        self.assertIn("١١:٠٠ ص", mess)
        self.assertTrue(zs.sending_paused(db, NOW + timedelta(minutes=59)))
        state = zs.control_state(db, NOW + timedelta(minutes=10))
        self.assertEqual((state["paused"], state["open_ended"], state["by"]), (True, False, "مدير"))
        self.assertFalse(zs.sending_paused(db, NOW + timedelta(minutes=61)))
        self.assertFalse(db.zatca_send_control(1).paused)
        self.assertEqual([h["action"] for h in self.history()], ["pause", "auto_resume"])

    def test_expired_pause_reads_as_running_before_it_is_recorded(self):
        zs.pause_sending(self.db, "1h", "اختبار", now=NOW)
        self.assertFalse(zs.control_state(self.db, NOW + timedelta(hours=2))["paused"])

    def test_open_pause_lasts_until_manual_resume(self):
        db = self.db
        ok, mess = zs.pause_sending(db, "open", "إيقاف طويل", now=NOW)
        self.assertTrue(ok)
        self.assertIn("حتى تستأنفه", mess)
        self.assertTrue(zs.sending_paused(db, NOW + timedelta(days=30)))
        self.assertTrue(zs.control_state(db, NOW)["open_ended"])
        self.assertTrue(zs.resume_sending(db, actor="مدير", now=NOW + timedelta(hours=2))[0])
        self.assertFalse(zs.sending_paused(db, NOW + timedelta(hours=2)))
        self.assertEqual(zs.resume_sending(db, now=NOW)[0], False)
        self.assertEqual([h["action"] for h in self.history()], ["pause", "resume"])

    def test_pause_validation_and_presets(self):
        db = self.db
        for preset, reason, until in (("1h", "", None), ("1h", "ab", None), ("forever", "سبب كافٍ", None),
                                      ("until", "سبب كافٍ", ""), ("until", "سبب كافٍ", "غير تاريخ"),
                                      ("until", "سبب كافٍ", "2026-09-24T09:00")):
            with self.subTest(preset=preset, until=until):
                self.assertFalse(zs.pause_sending(db, preset, reason, until, now=NOW)[0])
        self.assertIsNone(db.zatca_send_control(1))
        self.assertEqual(zs.pause_until_for("morning", None, NOW)[0], datetime(2026, 9, 25, 6, 0))
        self.assertEqual(zs.pause_until_for("morning", None, datetime(2026, 9, 24, 3, 0))[0],
                         datetime(2026, 9, 24, 6, 0))
        self.assertEqual(zs.pause_until_for("until", "2026-09-26T08:30", NOW)[0], datetime(2026, 9, 26, 8, 30))
        self.assertEqual(zs.pause_until_for("open", None, NOW), (None, None))

    def test_paused_visit_sends_nothing_and_keeps_the_queue(self):
        db = self.db
        rows = self.queue(2)
        zs.pause_sending(db, "3h", "صيانة", now=NOW)
        out = self.run_queue(self.counting(lambda p: ok_result()))
        self.assertTrue(out["paused"])
        self.assertEqual((out["processed"], len(self.calls)), (0, 0))
        self.assertTrue(all(not db.invoice_sending(r).send for r in rows))
        later = self.run_queue(self.counting(lambda p: ok_result()), now=NOW + timedelta(hours=4))
        self.assertEqual((later["paused"], later["processed"]), (False, 2))
        self.assertEqual([p["invoice"]["ID"] for p in self.calls],
                         sorted(p["invoice"]["ID"] for p in self.calls))  # الترتيب محفوظ

    def test_pause_during_a_visit_stops_before_the_next_invoice(self):
        db = self.db
        self.queue(3)

        def pause_after_first(payload):
            zs.pause_sending(db, "open", "إيقاف أثناء الدورة", now=NOW)
            return ok_result()
        out = self.run_queue(pause_after_first)
        self.assertEqual((out["stopped"], out["processed"], out["remaining"]), ("paused", 1, 2))

    def test_three_consecutive_outages_stop_the_visit(self):
        db = self.db
        self.queue(5)
        out = self.run_queue(self.counting(raiser(ZatcaConnectionError("timeout"))))
        self.assertEqual((out["stopped"], out["processed"], out["remaining"]), ("outage", 3, 2))
        self.assertEqual(len(self.calls), 3)
        self.assertEqual(db(db.invoice_sending.send == False).count(), 5)  # لا شيء خرج من الطابور
        note = self.history()[-1]
        self.assertEqual(note["action"], "outage")
        self.assertIn("٢", note["msg"])
        self.assertFalse(db.zatca_send_control(1).paused)  # التوقف لا يوقف الإرسال التلقائي

    def test_outage_streak_needs_consecutive_general_failures(self):
        self.queue(5)
        results = iter([raiser(ZatcaConnectionError("x")), raiser(ZatcaApiError(503, "")),
                        lambda p: ok_result(), raiser(ZatcaConnectionError("x")),
                        raiser(ZatcaApiError(502, ""))])
        out = self.run_queue(lambda p: next(results)(p))
        self.assertEqual((out["stopped"], out["processed"]), (None, 5))

    def test_credential_and_unexpected_errors_never_stop_the_visit(self):
        self.queue(4)
        out = self.run_queue(raiser(ZatcaApiError(401, "")))
        self.assertEqual((out["stopped"], out["processed"]), (None, 4))
        out = self.run_queue(raiser(ZatcaApiError(404, "Not Found")))
        self.assertEqual((out["stopped"], out["processed"]), (None, 4))

    def test_outage_on_the_last_invoices_is_not_a_stop(self):
        self.queue(3)
        out = self.run_queue(raiser(ZatcaConnectionError("x")))
        self.assertEqual((out["stopped"], out["processed"], out["remaining"]), (None, 3, 0))

    def test_broken_control_never_stops_sending(self):
        self.queue(2)
        with patch.object(zs, "sending_paused", side_effect=RuntimeError("control table missing")):
            zs.logger.disabled = True
            out = self.run_queue(lambda p: ok_result())
        self.assertEqual((out["paused"], out["processed"]), (False, 2))

    def test_oldest_waiting_warns_before_the_deadline(self):
        db = self.db
        self.assertIsNone(zs.oldest_waiting(db, NOW))
        queue_invoice(db)  # 2026-09-24 09:00
        cases = ((NOW, "ok"), (datetime(2026, 9, 25, 5, 30), "warn"), (datetime(2026, 9, 25, 9, 30), "danger"))
        for now, tone in cases:
            with self.subTest(now=now):
                self.assertEqual(zs.oldest_waiting(db, now)["tone"], tone)
        self.assertEqual(zs.oldest_waiting(db, NOW)["issued_label"], "اليوم ٩:٠٠ ص")


if __name__ == "__main__":
    unittest.main(verbosity=2)
