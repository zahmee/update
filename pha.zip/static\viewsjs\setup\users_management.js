var API_BASE = window.location.href.replace(/\/users_management.*$/, '/');

var app = new Vue({
    el: '#app',
    data: {
        // Users list
        users: [],
        usersCount: 0,
        userSearch: '',
        userStatusFilter: 'all',
        userPage: 0,
        userPageSize: 15,
        selectedUserId: null,
        selectedUser: null,
        usersLoading: false,

        // User form (add/edit)
        showUserModal: false,
        editingUser: false,
        userForm: { id: '', first_name: '', last_name: '', email: '', password: '' },

        // Groups / Membership
        allGroups: [],
        userMemberships: [],
        membershipLoading: false,

        // Screens Rules (reuse existing APIs)
        rules: [],
        rulesCount: 0,
        rulesPage: 0,
        rulesPageSize: 20,
        rulesLoading: false,
        savingRuleId: null,
        availableScreens: [],
        showAddRuleModal: false,
        newRule: { screens: '', can_log_in: false, can_add: false, can_edit: false, can_delete: false },
        searchScreen: '',

        // Tabs
        activeTab: 'membership', // 'membership' or 'screens'
    },
    computed: {
        userTotalPages: function () {
            return Math.ceil(this.usersCount / this.userPageSize) || 1;
        },
        userCurrentPage: function () { return this.userPage + 1; },
        userVisiblePages: function () {
            var total = this.userTotalPages, current = this.userCurrentPage, pages = [];
            var start = Math.max(1, current - 2), end = Math.min(total, current + 2);
            if (start > 1) { pages.push(1); if (start > 2) pages.push('...'); }
            for (var i = start; i <= end; i++) pages.push(i);
            if (end < total) { if (end < total - 1) pages.push('...'); pages.push(total); }
            return pages;
        },
        rulesTotalPages: function () {
            return Math.ceil(this.rulesCount / this.rulesPageSize) || 1;
        },
        rulesCurrentPage: function () { return this.rulesPage + 1; },
        rulesVisiblePages: function () {
            var total = this.rulesTotalPages, current = this.rulesCurrentPage, pages = [];
            var start = Math.max(1, current - 2), end = Math.min(total, current + 2);
            if (start > 1) { pages.push(1); if (start > 2) pages.push('...'); }
            for (var i = start; i <= end; i++) pages.push(i);
            if (end < total) { if (end < total - 1) pages.push('...'); pages.push(total); }
            return pages;
        },
        filteredScreens: function () {
            if (!this.searchScreen) return this.availableScreens;
            var term = this.searchScreen.trim();
            return this.availableScreens.filter(function (s) {
                return s.name.indexOf(term) !== -1 || String(s.screen_code).indexOf(term) !== -1;
            });
        },
    },
    created: function () {
        this.fetchUsers();
        this.fetchGroups();
    },
    methods: {
        // ========== Users ==========
        fetchUsers: function () {
            this.usersLoading = true;
            var params = { page: this.userPage, RecordCount: this.userPageSize, SearchText: this.userSearch, status_filter: this.userStatusFilter };
            this.$http.get(API_BASE + 'get_users', { params: params })
                .then(function (res) {
                    this.users = res.body.data || [];
                    this.usersCount = res.body.count || 0;
                }.bind(this), function () {
                    this.users = []; this.usersCount = 0;
                }.bind(this))
                .finally(function () { this.usersLoading = false; }.bind(this));
        },
        goToUserPage: function (p) {
            if (p === '...') return;
            this.userPage = p - 1;
            this.fetchUsers();
        },
        onSearchUsers: function () {
            this.userPage = 0;
            this.fetchUsers();
        },
        onStatusFilterChange: function () {
            this.userPage = 0;
            this.fetchUsers();
        },
        selectUser: function (user) {
            this.selectedUserId = user.id;
            this.selectedUser = user;
            this.activeTab = 'membership';
            this.fetchMemberships(user.id);
            this.fetchRules(user.id);
        },
        openAddUser: function () {
            this.editingUser = false;
            this.userForm = { id: '', first_name: '', last_name: '', email: '', password: '' };
            this.showUserModal = true;
        },
        openEditUser: function () {
            if (!this.selectedUser) return;
            this.editingUser = true;
            this.userForm = {
                id: this.selectedUser.id,
                first_name: this.selectedUser.first_name || '',
                last_name: this.selectedUser.last_name || '',
                email: this.selectedUser.email || '',
                password: '',
            };
            this.showUserModal = true;
        },
        closeUserModal: function () {
            this.showUserModal = false;
        },
        saveUser: function () {
            if (!this.userForm.first_name || !this.userForm.email) {
                Swal.fire({ icon: 'warning', title: 'تنبيه', text: 'الاسم والبريد مطلوبان', confirmButtonText: 'حسناً' });
                return;
            }
            if (!this.editingUser && !this.userForm.password) {
                Swal.fire({ icon: 'warning', title: 'تنبيه', text: 'كلمة المرور مطلوبة للمستخدم الجديد', confirmButtonText: 'حسناً' });
                return;
            }
            this.$http.post(API_BASE + 'save_user', this.userForm)
                .then(function (res) {
                    if (res.body.err === 0) {
                        this.closeUserModal();
                        this.fetchUsers();
                        Swal.fire({ icon: 'success', title: 'تم', text: 'تم الحفظ بنجاح', timer: 1500, showConfirmButton: false });
                    } else {
                        Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                    }
                }.bind(this), function () {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال بالخادم', confirmButtonText: 'حسناً' });
                }.bind(this));
        },
        deleteUserConfirm: function () {
            if (!this.selectedUser) return;
            var self = this;
            self.$http.post(API_BASE + 'delete_user/' + self.selectedUserId)
                .then(function (res) {
                    if (res.body.err === 0) {
                        self.selectedUser.registration_key = 'disabled';
                        self.fetchUsers();
                    } else {
                        Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                    }
                }, function () {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
                });
        },
        enableUserConfirm: function () {
            if (!this.selectedUser) return;
            var self = this;
            self.$http.post(API_BASE + 'enable_user/' + self.selectedUserId)
                .then(function (res) {
                    if (res.body.err === 0) {
                        self.selectedUser.registration_key = null;
                        self.fetchUsers();
                    } else {
                        Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                    }
                }, function () {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
                });
        },
        toggleUserStatus: function (user) {
            var self = this;
            var isDisabled = user.registration_key === 'disabled';
            var apiEndpoint = isDisabled ? 'enable_user/' : 'delete_user/';
            self.$http.post(API_BASE + apiEndpoint + user.id)
                .then(function (res) {
                    if (res.body.err === 0) {
                        user.registration_key = isDisabled ? null : 'disabled';
                        if (self.selectedUser && self.selectedUser.id === user.id) {
                            self.selectedUser.registration_key = user.registration_key;
                        }
                        self.fetchUsers();
                    } else {
                        Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                    }
                }, function () {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
                });
        },

        // ========== Groups / Membership ==========
        fetchGroups: function () {
            this.$http.get(API_BASE + 'get_groups')
                .then(function (res) {
                    this.allGroups = res.body || [];
                }.bind(this), function () {
                    this.allGroups = [];
                }.bind(this));
        },
        fetchMemberships: function (userId) {
            this.membershipLoading = true;
            this.$http.get(API_BASE + 'get_user_membership/' + userId)
                .then(function (res) {
                    this.userMemberships = res.body || [];
                }.bind(this), function () {
                    this.userMemberships = [];
                }.bind(this))
                .finally(function () { this.membershipLoading = false; }.bind(this));
        },
        isMember: function (groupId) {
            for (var i = 0; i < this.userMemberships.length; i++) {
                if (this.userMemberships[i].group_id === groupId) return true;
            }
            return false;
        },
        toggleMembership: function (groupId) {
            if (!this.selectedUserId) return;
            var checked = !this.isMember(groupId);
            this.$http.post(API_BASE + 'save_membership', {
                user_id: this.selectedUserId,
                group_id: groupId,
                checked: checked ? 'true' : 'false',
            }).then(function (res) {
                if (res.body.err === 0) {
                    this.fetchMemberships(this.selectedUserId);
                } else {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                }
            }.bind(this), function () {
                Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
            }.bind(this));
        },

        // ========== Screens Rules ==========
        fetchRules: function () {
            if (!this.selectedUserId) return;
            this.rulesLoading = true;
            var params = { page: this.rulesPage, RecordCount: this.rulesPageSize };
            this.$http.get(API_BASE + 'get_screens_rules/' + this.selectedUserId, { params: params })
                .then(function (res) {
                    var rows = res.body.data || [];
                    for (var i = 0; i < rows.length; i++) {
                        var r = rows[i];
                        r.can_log_in = (r.can_log_in === true || r.can_log_in === 'T' || r.can_log_in === 't');
                        r.can_add = (r.can_add === true || r.can_add === 'T' || r.can_add === 't');
                        r.can_edit = (r.can_edit === true || r.can_edit === 'T' || r.can_edit === 't');
                        r.can_delete = (r.can_delete === true || r.can_delete === 'T' || r.can_delete === 't');
                    }
                    this.rules = rows;
                    this.rulesCount = res.body.count || 0;
                }.bind(this), function () {
                    this.rules = []; this.rulesCount = 0;
                }.bind(this))
                .finally(function () { this.rulesLoading = false; }.bind(this));
        },
        goToRulesPage: function (p) {
            if (p === '...') return;
            this.rulesPage = p - 1;
            this.fetchRules();
        },
        saveRule: function (rule) {
            this.savingRuleId = rule.id;
            this.$http.post(API_BASE + 'save_rule', {
                id: rule.id,
                can_log_in: rule.can_log_in ? 'true' : 'false',
                can_add: rule.can_add ? 'true' : 'false',
                can_edit: rule.can_edit ? 'true' : 'false',
                can_delete: rule.can_delete ? 'true' : 'false',
            }).then(function (res) {
                if (res.body.err !== 0) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                }
            }.bind(this), function () {
                Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
            }.bind(this)).finally(function () { this.savingRuleId = null; }.bind(this));
        },
        openAddRuleModal: function () {
            this.newRule = { screens: '', can_log_in: false, can_add: false, can_edit: false, can_delete: false };
            this.searchScreen = '';
            this.fetchAvailableScreens();
            this.showAddRuleModal = true;
        },
        closeAddRuleModal: function () {
            this.showAddRuleModal = false;
        },
        fetchAvailableScreens: function () {
            this.$http.get(API_BASE + 'get_available_screens/' + this.selectedUserId)
                .then(function (res) {
                    this.availableScreens = res.body || [];
                    if (this.availableScreens.length > 0 && !this.newRule.screens) {
                        this.newRule.screens = this.availableScreens[0].id;
                    }
                }.bind(this), function () { this.availableScreens = []; }.bind(this));
        },
        addRule: function () {
            if (!this.newRule.screens) {
                Swal.fire({ icon: 'warning', title: 'تنبيه', text: 'يجب اختيار شاشة', confirmButtonText: 'حسناً' });
                return;
            }
            this.$http.post(API_BASE + 'save_rule', {
                to_user: this.selectedUserId,
                screens: this.newRule.screens,
                can_log_in: this.newRule.can_log_in ? 'true' : 'false',
                can_add: this.newRule.can_add ? 'true' : 'false',
                can_edit: this.newRule.can_edit ? 'true' : 'false',
                can_delete: this.newRule.can_delete ? 'true' : 'false',
            }).then(function (res) {
                if (res.body.err === 0) {
                    this.closeAddRuleModal();
                    this.rulesPage = 0;
                    this.fetchRules();
                    Swal.fire({ icon: 'success', title: 'تم', text: 'تمت الإضافة', timer: 1500, showConfirmButton: false });
                } else {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                }
            }.bind(this), function () {
                Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
            }.bind(this));
        },
        deleteRule: function (rule) {
            var self = this;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف صلاحية "' + rule.screen_name + '"؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonText: 'إلغاء',
                confirmButtonText: 'نعم، احذف',
            }).then(function (result) {
                if (result.value || result.isConfirmed) {
                    self.$http.post(API_BASE + 'delete_rule/' + rule.id)
                        .then(function (res) {
                            if (res.body.err === 0) {
                                self.fetchRules();
                                Swal.fire({ icon: 'success', title: 'تم الحذف', timer: 1500, showConfirmButton: false });
                            } else {
                                Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                            }
                        }, function () {
                            Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
                        });
                }
            });
        },
        grantAllRules: function () {
            var self = this;
            Swal.fire({
                title: 'تأكيد',
                text: 'هل أنت متأكد من منح جميع الصلاحيات؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم، منح الكل',
                cancelButtonText: 'إلغاء',
            }).then(function (result) {
                if (result.value || result.isConfirmed) {
                    self.$http.post(API_BASE + 'api_grant_all/' + self.selectedUserId)
                        .then(function (res) {
                            if (res.body.err === 0) {
                                self.rulesPage = 0;
                                self.fetchRules();
                                Swal.fire({ icon: 'success', title: 'تم', text: 'تم منح جميع الصلاحيات', timer: 1500, showConfirmButton: false });
                            } else {
                                Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                            }
                        }, function () {
                            Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
                        });
                }
            });
        },
        deleteAllRules: function () {
            var self = this;
            Swal.fire({
                title: 'تأكيد',
                text: 'هل أنت متأكد من حذف جميع الصلاحيات؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonText: 'إلغاء',
                confirmButtonText: 'نعم، احذف الكل',
            }).then(function (result) {
                if (result.value || result.isConfirmed) {
                    self.$http.post(API_BASE + 'api_delete_all/' + self.selectedUserId)
                        .then(function (res) {
                            if (res.body.err === 0) {
                                self.rulesPage = 0;
                                self.fetchRules();
                                Swal.fire({ icon: 'success', title: 'تم', text: 'تم حذف جميع الصلاحيات', timer: 1500, showConfirmButton: false });
                            } else {
                                Swal.fire({ icon: 'error', title: 'خطأ', text: res.body.mess || 'حدث خطأ', confirmButtonText: 'حسناً' });
                            }
                        }, function () {
                            Swal.fire({ icon: 'error', title: 'خطأ', text: 'فشل الاتصال', confirmButtonText: 'حسناً' });
                        });
                }
            });
        },
    },
});
