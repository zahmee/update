# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الترميزات الأساسية (Lookup Tables)
# البيانات الافتتاحية في: scripts/seed_data.py
# ===========================================================================================

# جدول الوحدات للأصناف
db.define_table("key_unit", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_unit.id.label = "م"

# ============================================================================
db.define_table(
    "key_payment_method", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_method.id.label = "م"

# =============================================================================
# جدول انواع العملاء
db.define_table("key_cust", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_cust.id.label = "م"

# ==============================================================================

# جدول التصنيفات للأصناف
db.define_table("key_type", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_type.id.label = "م"

# ==============================================================================

# جدول انواع السداد للمورد
db.define_table(
    "key_payment_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_type.id.label = "م"

# ==============================================================================
# جدول تصنيف الفواتير
db.define_table(
    "key_invoce_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_invoce_type.id.label = "م"
