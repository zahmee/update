# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الترميزات الأساسية (Lookup Tables)
# البيانات الافتتاحية في: modules/system_readiness.py (SEEDS) — تُفحص وتُضاف من شاشة setup/seed_data
# ===========================================================================================

# جدول الوحدات للأصناف
db.define_table(
    "key_unit", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# ============================================================================
db.define_table(
    "key_payment_method", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# =============================================================================
# جدول انواع العملاء
db.define_table(
    "key_cust", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# ==============================================================================

# جدول التصنيفات للأصناف
db.define_table(
    "key_type", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# ==============================================================================

# جدول انواع السداد للمورد
db.define_table(
    "key_payment_type", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# ==============================================================================
# جدول تصنيف الفواتير
db.define_table(
    "key_invoce_type", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)
