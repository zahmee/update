# -*- coding: utf-8 -*-
#  type: ignore


from datetime import datetime
import api_helpers as api

@can_access(2010)
def get_supp():
    q  = db(db.suppliers.stoped==False).select(db.suppliers.id ,db.suppliers.name , orderby=db.suppliers.name )
    return response.json(api.api_ok(data=q))

@can_access(2010)
def get_payment_method():
    q  = db(db.key_payment_method.id>0).select(db.key_payment_method.ALL, orderby=db.key_payment_method.id )
    return response.json(api.api_ok(data=q))

@can_access(2010)
def new_bill():
    try :
        data = request.vars
        #print data 
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        # bill_date = str(data['day']['month'])+'-'+str(data['day']['day'])+'-'+str(data['day']['year']) 
        nid = db.suppliers_bills.insert(
                        supplier=data.suppliers  , 
                        payment_method = data.payment_method ,
                        bill_no =  data.bill_no   , 
                        bill_date =  bill_date  , 
                        bill_total = data.total_vat ,
                        bill_vat = data.vat_inp   ,
                        bill_net_amount = data.total_no_vat  ,
                        note = data.memo
                        )
        db.commit()
        return response.json(api.api_ok(mess="تم الحفظ بنجاح"))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
