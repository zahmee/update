# -*- coding: utf-8 -*-
"""
Onboarding: send 6 test invoices for compliance checks, then request Production CSID.
"""

import base64
import json
import logging
import os
import uuid
from copy import deepcopy
from datetime import datetime

import importlib
etree = importlib.import_module("lxml.etree")

from zatca_direct.api_client import (
    build_urls,
    request_production_csid,
    submit_compliance_check,
)
from zatca_direct.signer import sign_invoice

logger = logging.getLogger(__name__)

RESOURCES_DIR = os.path.join(os.path.dirname(__file__), "resources")

# Initial PIH for the first invoice in the chain
_INITIAL_PIH = "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ=="

# 6 document types required for compliance testing
_DOCUMENT_TYPES = [
    # [prefix, type_code, description, instruction_note]
    ["STDSI", "388", "Standard Invoice", ""],
    ["STDCN", "383", "Standard CreditNote", "InstructionNotes for Standard CreditNote"],
    ["STDDN", "381", "Standard DebitNote", "InstructionNotes for Standard DebitNote"],
    ["SIMSI", "388", "Simplified Invoice", ""],
    ["SIMCN", "383", "Simplified CreditNote", "InstructionNotes for Simplified CreditNote"],
    ["SIMDN", "381", "Simplified DebitNote", "InstructionNotes for Simplified DebitNote"],
]

NS = {
    "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
    "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
}


def _load_template():
    """Load the base invoice XML template."""
    path = os.path.join(RESOURCES_DIR, "invoice_template.xml")
    parser = etree.XMLParser(remove_blank_text=False)
    return etree.parse(path, parser)


def _modify_xml(base_doc, invoice_id, type_code_name, type_code_value,
                icv, pih, instruction_note, vat_number, crn):
    """
    Clone and modify the base invoice XML for a specific test document type.
    """
    # Clone
    new_doc = etree.ElementTree(
        etree.fromstring(etree.tostring(base_doc.getroot(), pretty_print=True))
    )
    root = new_doc.getroot()

    # Invoice ID
    node = root.find(".//cbc:ID", namespaces=NS)
    if node is not None:
        node.text = invoice_id

    # UUID
    node = root.find(".//cbc:UUID", namespaces=NS)
    if node is not None:
        node.text = str(uuid.uuid4()).upper()

    # Issue date/time
    node = root.find(".//cbc:IssueDate", namespaces=NS)
    if node is not None:
        node.text = datetime.today().strftime("%Y-%m-%d")
    node = root.find(".//cbc:IssueTime", namespaces=NS)
    if node is not None:
        node.text = datetime.now().strftime("%H:%M:%S")

    # InvoiceTypeCode + name attribute
    node = root.find(".//cbc:InvoiceTypeCode", namespaces=NS)
    if node is not None:
        node.text = type_code_value
        node.set("name", type_code_name)

    # Supplier VAT
    node = root.find(
        ".//cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cbc:CompanyID",
        namespaces=NS,
    )
    if node is not None:
        node.text = vat_number

    # Supplier CRN
    node = root.find(
        ".//cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID",
        namespaces=NS,
    )
    if node is not None:
        node.text = crn

    # ICV
    node = root.find(
        ".//cac:AdditionalDocumentReference[cbc:ID='ICV']/cbc:UUID",
        namespaces=NS,
    )
    if node is not None:
        node.text = str(icv)

    # PIH
    node = root.find(
        ".//cac:AdditionalDocumentReference[cbc:ID='PIH']/cac:Attachment/cbc:EmbeddedDocumentBinaryObject",
        namespaces=NS,
    )
    if node is not None:
        node.text = pih

    # InstructionNote (for credit/debit notes) or remove BillingReference (for invoices)
    if instruction_note:
        payment_means = root.find(".//cac:PaymentMeans", namespaces=NS)
        if payment_means is not None:
            note_el = etree.Element(
                "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}InstructionNote"
            )
            note_el.text = instruction_note
            payment_means.append(note_el)
    else:
        for br in root.findall(".//cac:BillingReference", namespaces=NS):
            parent = br.getparent()
            if parent is not None:
                parent.remove(br)

    return new_doc


def run_onboarding(config):
    """
    Run the full onboarding flow:
    1. Send 6 test invoices for compliance checks
    2. Request Production CSID

    config dict keys:
        ccsid_requestid, ccsid_binarysecuritytoken, ccsid_secret,
        privatekey, environmentType, VAT, CN

    Returns dict with:
        pcsid_requestid, pcsid_binarysecuritytoken, pcsid_secret,
        compliance_results (list)
    """
    urls = build_urls(config["environmentType"])

    # Decode the certificate from base64
    x509_cert = base64.b64decode(
        config.get("ccsid_binarysecuritytoken", "")
    ).decode("utf-8")
    private_key = config.get("privatekey", "")
    vat_number = config.get("VAT", "")
    crn = config.get("CN", "")

    base_doc = _load_template()

    icv = 0
    pih = _INITIAL_PIH
    all_results = []

    for prefix, type_code, description, instruction_note in _DOCUMENT_TYPES:
        icv += 1
        is_simplified = prefix.startswith("SIM")

        logger.info("Processing %s (ICV=%d)", description, icv)

        doc = _modify_xml(
            base_doc,
            invoice_id=f"{prefix}-0001",
            type_code_name="0200000" if is_simplified else "0100000",
            type_code_value=type_code,
            icv=icv,
            pih=pih,
            instruction_note=instruction_note,
            vat_number=vat_number,
            crn=crn,
        )

        # Sign the invoice
        signed_json = sign_invoice(doc, x509_cert, private_key)
        payload = json.loads(signed_json)

        # Submit compliance check
        json_payload = json.dumps(payload)
        resp_data = submit_compliance_check(
            config["ccsid_binarysecuritytoken"],
            config["ccsid_secret"],
            json_payload,
            urls["complianceChecksUrl"],
        )

        all_results.append({
            "type": prefix,
            "description": description,
            "response": resp_data,
        })

        # Check status
        status = (
            resp_data.get("reportingStatus")
            if is_simplified
            else resp_data.get("clearanceStatus")
        )

        if status and ("REPORTED" in status or "CLEARED" in status):
            pih = payload["invoiceHash"]
            logger.info("%s passed: %s", description, status)
        else:
            raise Exception(
                f"فشل اختبار التوافق لـ {description}: الحالة {status}"
            )

    # All 6 passed — request Production CSID
    logger.info("All compliance checks passed. Requesting Production CSID...")

    pcsid_data = request_production_csid(
        config["ccsid_requestid"],
        config["ccsid_binarysecuritytoken"],
        config["ccsid_secret"],
        urls["productionCsidUrl"],
    )

    result = {
        "compliance_results": all_results,
    }

    if pcsid_data.get("requestID"):
        result["pcsid_requestid"] = str(pcsid_data["requestID"])
        result["pcsid_binarysecuritytoken"] = pcsid_data.get("binarySecurityToken", "")
        result["pcsid_secret"] = pcsid_data.get("secret", "")
    else:
        raise Exception(f"ZATCA لم ترجع Production CSID: {pcsid_data}")

    return result
