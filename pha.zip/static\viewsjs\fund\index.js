/* global Vue, Swal, Api, bootstrap */
var URLS = window.FUND_URLS || {};

var app = new Vue({
    el: '#app',
    data: {
        loading: false,
        filtersOpen: false,
        analyticsOpen: false,
        canApprove: !!window.FUND_CAN_APPROVE,
        data: [],
        data_row_count: 0,
        totals: { deposits: 0, expenses: 0 },
        lookups: { categories: [], payment_methods: [], users: [] },
        dashboard: {
            current_balance: 0,
            today_deposits: 0,
            today_expenses: 0,
            pending_approval: 0,
            submitted_deposits: 0,
            submitted_expenses: 0,
            draft_deposits: 0,
            draft_expenses: 0,
            returned_pending: 0,
            top_categories: [],
            trend_30d: [],
        },
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'entry_date',
            sortAsc: false,
            date_from: '',
            date_to: '',
            kind: '',
            category_id: '0',
            payment_method: '0',
            status: 'all',
            created_by: '0',
        },
        selectedRow: -1,
        edit_row_data: {},
        new_row: true,
        selected_file: null,
        reject_reason: '',
        return_reason: '',
    },
    computed: {
        currentPage() { return (this.getData.page || 0) + 1; },
        totalPages() {
            return Math.max(1, Math.ceil(this.data_row_count / this.getData.RecordCount));
        },
        visiblePages() {
            var total = this.totalPages, cur = this.currentPage;
            if (total <= 7) {
                return Array.from({ length: total }, (_, i) => i + 1);
            }
            var pages = [1];
            if (cur > 3) pages.push('...');
            for (var i = Math.max(2, cur - 1); i <= Math.min(total - 1, cur + 1); i++) pages.push(i);
            if (cur < total - 2) pages.push('...');
            pages.push(total);
            return pages;
        },
        filteredCategories() {
            var k = this.edit_row_data.kind;
            if (!k) return this.lookups.categories;
            return this.lookups.categories.filter(c => c.kind === k);
        },
        submittedNet() {
            return this.toNumber(this.dashboard.submitted_deposits) - this.toNumber(this.dashboard.submitted_expenses);
        },
        draftNet() {
            return this.toNumber(this.dashboard.draft_deposits) - this.toNumber(this.dashboard.draft_expenses);
        },
        balanceAfterSubmitted() {
            return this.toNumber(this.dashboard.current_balance) + this.submittedNet;
        },
        balanceAfterDrafts() {
            return this.balanceAfterSubmitted + this.draftNet;
        },
    },
    created() {
        this.loadLookups().then(() => {
            this.loadDashboard();
            this.loadEntries();
        });
    },
    methods: {
        formatMoney(v) {
            var n = this.toNumber(v);
            if (isNaN(n)) return '0.00';
            return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        toNumber(v) {
            var n = parseFloat(v || 0);
            return isNaN(n) ? 0 : n;
        },
        statusLabel(s) {
            return {
                draft: 'مسودة', submitted: 'مُقدَّم',
                approved: 'معتمد', rejected: 'مرفوض',
                returned: 'مُرجَع للتعديل',
            }[s] || s;
        },
        statusIcon(s) {
            return {
                draft: 'fas fa-circle', submitted: 'fas fa-clock',
                approved: 'fas fa-check-circle', rejected: 'fas fa-times-circle',
                returned: 'fas fa-undo',
            }[s] || 'fas fa-circle';
        },
        // مسودة أو مُرجَع = السند في يد أمين الصندوق، له تعديله وتقديمه وحذفه
        isEditable(s) {
            return s === 'draft' || s === 'returned';
        },
        sortIcon(col) {
            if (this.getData.SortBy !== col) return 'fa-sort text-muted';
            return this.getData.sortAsc ? 'fa-sort-up' : 'fa-sort-down';
        },
        trendHeight(v) {
            var max = 0;
            (this.dashboard.trend_30d || []).forEach(d => { if (d.expenses > max) max = d.expenses; });
            if (max <= 0) return 5;
            return Math.max(5, Math.round((parseFloat(v || 0) / max) * 100));
        },
        topCatPercent(v) {
            var max = 0;
            (this.dashboard.top_categories || []).forEach(t => { if (t.total > max) max = t.total; });
            if (max <= 0) return 0;
            return Math.max(3, Math.round((parseFloat(v || 0) / max) * 100));
        },
        downloadUrl(fname) {
            if (!fname) return '#';
            return URLS.download + '/' + fname;
        },

        loadLookups() {
            return Api.get(URLS.lookups).then(d => {
                if (Api.isOk(d)) this.lookups = Api.getData(d);
            });
        },
        loadDashboard() {
            return Api.get(URLS.dashboard).then(d => {
                if (Api.isOk(d)) this.dashboard = Api.getData(d);
            });
        },
        loadEntries() {
            this.loading = true;
            var p = this.getData;
            var url = new URL(URLS.entries, window.location.origin);
            var params = {
                page: p.page, RecordCount: p.RecordCount, SearchText: p.SearchText,
                SortBy: p.SortBy, sequence: p.sortAsc,
                date_from: p.date_from, date_to: p.date_to,
                kind: p.kind, category_id: p.category_id,
                payment_method: p.payment_method, status: p.status,
                created_by: p.created_by,
            };
            Object.keys(params).forEach(k => {
                if (params[k] !== '' && params[k] !== null && params[k] !== undefined)
                    url.searchParams.append(k, params[k]);
            });
            return Api.get(url.toString()).then(d => {
                this.loading = false;
                if (Api.isOk(d)) {
                    this.data = Api.getData(d) || [];
                    this.data_row_count = d.count || 0;
                    this.totals = d.totals || { deposits: 0, expenses: 0 };
                } else {
                    Api.showError(d);
                }
            });
        },
        onChange() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loadEntries();
        },
        sortBy(col) {
            if (this.getData.SortBy === col) {
                this.getData.sortAsc = !this.getData.sortAsc;
            } else {
                this.getData.SortBy = col;
                this.getData.sortAsc = true;
            }
            this.loadEntries();
        },
        goToPage(pg) {
            if (pg === '...' || pg < 1 || pg > this.totalPages) return;
            this.getData.page = pg - 1;
            this.selectedRow = -1;
            this.loadEntries();
        },
        clearFilters() {
            Object.assign(this.getData, {
                page: 0, SearchText: '', date_from: '', date_to: '',
                kind: '', category_id: '0', payment_method: '0',
                status: 'all', created_by: '0',
            });
            this.onChange();
        },

        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
        },
        cancel_data() {
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.selected_file = null;
            this.new_row = true;
        },
        viewRow(row) {
            this.edit_row_data = Object.assign({}, row);
        },
        new_row_click() {
            this.new_row = true;
            this.selected_file = null;
            var today = new Date().toISOString().substring(0, 10);
            this.edit_row_data = {
                entry_date: today, kind: 'expense',
                category_id: '', payment_method: '',
                amount: '', beneficiary: '', document_no: '', description: '',
            };
            this.selectedRow = -1;
            if (this.$refs.fileInput) this.$refs.fileInput.value = '';
        },
        editRow(row) {
            this.new_row = false;
            this.selected_file = null;
            this.edit_row_data = Object.assign({}, row);
            if (this.$refs.fileInput) this.$refs.fileInput.value = '';
        },
        onFileChange(e) {
            this.selected_file = e.target.files && e.target.files[0] ? e.target.files[0] : null;
        },

        _validateForm() {
            var d = this.edit_row_data;
            if (!d.entry_date) return 'التاريخ مطلوب';
            if (d.kind !== 'expense' && d.kind !== 'deposit') return 'النوع مطلوب';
            if (!d.category_id) return 'التصنيف مطلوب';
            if (!d.payment_method) return 'طريقة الدفع مطلوبة';
            var a = parseFloat(d.amount || 0);
            if (!a || a <= 0) return 'المبلغ يجب أن يكون أكبر من صفر';
            return null;
        },
        save_data() {
            var err = this._validateForm();
            if (err) { Swal.fire('تنبيه', err, 'error'); return; }
            var fd = new FormData();
            var d = this.edit_row_data;
            fd.append('entry_date', d.entry_date);
            fd.append('kind', d.kind);
            fd.append('category_id', d.category_id);
            fd.append('payment_method', d.payment_method);
            fd.append('amount', d.amount);
            fd.append('beneficiary', d.beneficiary || '');
            fd.append('document_no', d.document_no || '');
            fd.append('description', d.description || '');
            fd.append('ref_type', 'manual');
            if (this.selected_file) fd.append('attachment', this.selected_file);
            var url = this.new_row ? URLS.new_entry : URLS.edit_entry;
            if (!this.new_row) fd.append('id', d.id);
            Api.post(url, fd).then(resp => {
                if (Api.isOk(resp)) {
                    Api.showSuccess('تم الحفظ');
                    var modal = bootstrap.Modal.getInstance(document.getElementById('entryModal'));
                    if (modal) modal.hide();
                    this.cancel_data();
                    this.loadEntries();
                    this.loadDashboard();
                } else {
                    Api.showError(resp);
                }
            });
        },

        submitRow(row) {
            Swal.fire({
                title: 'تقديم للاعتماد',
                text: 'هل تريد تقديم هذه الحركة للاعتماد؟ لن تتمكن من تعديلها بعد ذلك.',
                icon: 'question', showCancelButton: true,
                confirmButtonText: 'نعم', cancelButtonText: 'تراجع',
            }).then(res => {
                if (!res.value) return;
                Api.get(URLS.submit_entry + '/' + row.id).then(d => {
                    if (Api.isOk(d)) {
                        Api.showSuccess('تم التقديم');
                        this.cancel_data();
                        this.loadEntries();
                        this.loadDashboard();
                    } else Api.showError(d);
                });
            });
        },
        approveRow(row) {
            Swal.fire({
                title: 'اعتماد الحركة',
                text: 'تأكيد اعتماد هذه الحركة نهائيًا؟',
                icon: 'question', showCancelButton: true,
                confirmButtonText: 'اعتماد', cancelButtonText: 'تراجع',
            }).then(res => {
                if (!res.value) return;
                Api.get(URLS.approve_entry + '/' + row.id).then(d => {
                    if (Api.isOk(d)) {
                        Api.showSuccess('تم الاعتماد');
                        this.cancel_data();
                        this.loadEntries();
                        this.loadDashboard();
                    } else Api.showError(d);
                });
            });
        },
        openReject(row) {
            this.edit_row_data = Object.assign({}, row);
            this.reject_reason = '';
        },
        rejectRow() {
            if (!this.reject_reason || !this.reject_reason.trim()) {
                Swal.fire('تنبيه', 'سبب الرفض مطلوب', 'error');
                return;
            }
            var fd = new FormData();
            fd.append('id', this.edit_row_data.id);
            fd.append('reason', this.reject_reason.trim());
            Api.post(URLS.reject_entry, fd).then(d => {
                if (Api.isOk(d)) {
                    Api.showSuccess('تم الرفض');
                    var modal = bootstrap.Modal.getInstance(document.getElementById('rejectModal'));
                    if (modal) modal.hide();
                    this.reject_reason = '';
                    this.cancel_data();
                    this.loadEntries();
                    this.loadDashboard();
                } else Api.showError(d);
            });
        },
        openReturn(row) {
            this.edit_row_data = Object.assign({}, row);
            this.return_reason = '';
        },
        returnRow() {
            if (!this.return_reason || !this.return_reason.trim()) {
                Swal.fire('تنبيه', 'سبب الإرجاع مطلوب — هو ما يقرأه أمين الصندوق ليعرف ما يُصححه', 'error');
                return;
            }
            var fd = new FormData();
            fd.append('id', this.edit_row_data.id);
            fd.append('reason', this.return_reason.trim());
            Api.post(URLS.return_entry, fd).then(d => {
                if (Api.isOk(d)) {
                    Api.showSuccess('تم إرجاع السند لأمين الصندوق للتعديل');
                    var modal = bootstrap.Modal.getInstance(document.getElementById('returnModal'));
                    if (modal) modal.hide();
                    this.return_reason = '';
                    this.cancel_data();
                    this.loadEntries();
                    this.loadDashboard();
                } else Api.showError(d);
            });
        },
        deleteRow(row) {
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'سيُحذف السجل نهائيًا. متابعة؟',
                icon: 'warning', showCancelButton: true,
                confirmButtonText: 'حذف', cancelButtonText: 'تراجع',
                confirmButtonColor: '#dc3545',
            }).then(res => {
                if (!res.value) return;
                Api.get(URLS.del_entry + '/' + row.id).then(d => {
                    if (Api.isOk(d)) {
                        Api.showSuccess('تم الحذف');
                        this.cancel_data();
                        this.loadEntries();
                        this.loadDashboard();
                    } else Api.showError(d);
                });
            });
        },
        printVoucher(row) {
            window.open(URLS.print_voucher + '/' + row.id, '_blank');
        },
        exportExcel() {
            var p = this.getData;
            var url = new URL(URLS.export_excel, window.location.origin);
            var params = {
                SearchText: p.SearchText, date_from: p.date_from, date_to: p.date_to,
                kind: p.kind, category_id: p.category_id, status: p.status,
            };
            Object.keys(params).forEach(k => {
                if (params[k] !== '' && params[k] !== null && params[k] !== undefined)
                    url.searchParams.append(k, params[k]);
            });
            window.open(url.toString(), '_blank');
        },
    },
});
