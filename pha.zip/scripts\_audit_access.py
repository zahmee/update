# -*- coding: utf-8 -*-
"""تحليل ثابت لمنظومة الصلاحيات في asbab5 — بدون قاعدة بيانات."""
import os, re, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CTRL = os.path.join(ROOT, "controllers")

# 1) السجل المرجعي من setup.py (قائمة screens_code)
setup_src = open(os.path.join(CTRL, "setup.py"), encoding="utf-8").read()
m = re.search(r"screens_code\s*=\s*\[(.*?)\n\]", setup_src, re.S)
registry = {}
for name, code in re.findall(r'\{[^{}]*?"name"\s*:\s*"([^"]+)"[^{}]*?"screen_code"\s*:\s*(\d+)[^{}]*?\}', m.group(1)):
    registry[int(code)] = name
print("عدد الشاشات في السجل المرجعي:", len(registry))

# 2) مسح كل وحدات التحكم
used_codes = {}            # code -> [(file, func)]
rules_calls = []           # (file, func, rule_code, gate_codes)
undecorated = []           # (file, func)
func_gates = {}            # (file, func) -> [codes]

dec_re = re.compile(r"^@can_access\(([\d,\s]+)\)")
other_auth_re = re.compile(r"^@(auth\.requires_login|auth\.requires_membership|require_agent_key)")
def_re = re.compile(r"^def ([a-zA-Z_]\w*)\(")
rule_re = re.compile(r"screens_rules\((\d+)\)")

for fn in sorted(os.listdir(CTRL)):
    if not fn.endswith(".py"):
        continue
    path = os.path.join(CTRL, fn)
    lines = open(path, encoding="utf-8").read().splitlines()
    pending_codes, pending_other, commented = [], False, False
    cur_func, cur_codes = None, []
    for ln in lines:
        s = ln.strip()
        if s.startswith("#"):
            continue
        dm = dec_re.match(s)
        if dm:
            pending_codes = [int(x) for x in dm.group(1).split(",")]
            continue
        if other_auth_re.match(s):
            pending_other = True
            continue
        fm = def_re.match(ln)
        if fm:
            cur_func, cur_codes = fm.group(1), pending_codes
            for c in pending_codes:
                used_codes.setdefault(c, []).append((fn, cur_func))
            func_gates[(fn, cur_func)] = list(pending_codes)
            if not pending_codes and not pending_other and not cur_func.startswith("_"):
                undecorated.append((fn, cur_func))
            pending_codes, pending_other = [], False
            continue
        if ln and not ln.startswith((" ", "\t", "@")) and cur_func and not s.startswith("#"):
            # خروج من جسم الدالة (سطر بمستوى المسافة البادئة 0)
            cur_func, cur_codes = None, []
        if cur_func:
            for rm in rule_re.finditer(ln):
                rules_calls.append((fn, cur_func, int(rm.group(1)), list(cur_codes)))

# 3) النواتج
used_set = set(used_codes)
reg_set = set(registry)

print("\n=== أكواد مستخدمة في @can_access وغير مسجلة في screens_code ===")
for c in sorted(used_set - reg_set):
    print(c, "->", used_codes[c][:3])

print("\n=== شاشات مسجلة في screens_code ولا يستخدمها أي @can_access ===")
for c in sorted(reg_set - used_set):
    print(c, registry[c])

print("\n=== استدعاءات screens_rules(X) داخل دالة محمية بكود مختلف ===")
for fn, func, rc, gates in rules_calls:
    if gates and rc not in gates:
        print(f"{fn}:{func}  محمية بـ {gates}  لكن تقرأ صلاحيات الشاشة {rc} ({registry.get(rc, '؟ غير مسجلة')})")

print("\n=== دوال عامة بدون أي حماية (لا can_access ولا requires_login ولا agent_key) ===")
for fn, func in undecorated:
    print(f"{fn}:{func}")

print("\n=== ملخص ===")
print("شاشات مسجلة:", len(reg_set), "| أكواد مستخدمة:", len(used_set),
      "| دوال عامة بلا حماية:", len(undecorated))
