var app = new Vue({
    el: '#app',
    data: {
        loading: false,
        searchQuery: '',
        filterStatus: 'all',
        editMode: false,
        form: {
            id: null,
            name: '',
            item_id: '',
            generic_name: '',
            supplier_name: '',
            notes: '',
            customer_name: '',
            customer_mobile: ''
        },
        searchResults: { existing: [], requested: [] },
        data: [],
        page: 0,
        recordCount: 10,
        totalCount: 0,
        totalPages: 0,
        currentPage: 1,
        selectedIndex: -1,
        selectedRow: {},
        smsMessage: ''
    },
    mounted: function () {
        this.loadList();
    },
    computed: {
        visiblePages: function () {
            var pages = [];
            var total = this.totalPages;
            var current = this.currentPage;
            if (total <= 7) {
                for (var i = 1; i <= total; i++) pages.push(i);
            } else {
                pages.push(1);
                if (current > 3) pages.push('...');
                var start = Math.max(2, current - 1);
                var end = Math.min(total - 1, current + 1);
                for (var j = start; j <= end; j++) pages.push(j);
                if (current < total - 2) pages.push('...');
                pages.push(total);
            }
            return pages;
        }
    },
    methods: {
        loadList: function () {
            var self = this;
            self.loading = true;
            var url = window.REQ_URLS.list
                + '?page=' + self.page
                + '&RecordCount=' + self.recordCount
                + '&status=' + self.filterStatus;
            if (self.searchQuery.trim()) {
                url += '&SearchText=' + encodeURIComponent(self.searchQuery.trim());
            }
            Api.get(url).then(function (res) {
                if (Api.isOk(res)) {
                    self.data = Api.getData(res) || [];
                    self.totalCount = res.count || 0;
                    self.totalPages = Math.ceil(self.totalCount / self.recordCount) || 1;
                    self.currentPage = self.page + 1;
                } else {
                    Api.showError(res);
                }
            }).catch(function (err) {
                console.error(err);
            }).finally(function () {
                self.loading = false;
            });
        },
        doSearch: function () {
            var self = this;
            var q = self.searchQuery.trim();
            if (!q) {
                self.searchResults = { existing: [], requested: [] };
                self.loadList();
                return;
            }
            Api.get(window.REQ_URLS.search + '?q=' + encodeURIComponent(q)).then(function (res) {
                if (Api.isOk(res)) {
                    var d = Api.getData(res);
                    self.searchResults = {
                        existing: d.existing || [],
                        requested: d.requested || []
                    };
                    if (self.searchResults.existing.length) {
                        Swal.fire({
                            icon: 'info',
                            title: 'الصنف موجود',
                            text: 'هذا الصنف موجود في المخزون',
                            showConfirmButton: false,
                            timer: 2000
                        });
                        self.loadList();
                        return;
                    }
                    if (self.searchResults.requested.length) {
                        self.loadList();
                        return;
                    }
                    // غير موجود → افتح المودال
                    self.loadList();
                    self.form.name = q;
                    self.editMode = false;
                    new bootstrap.Modal(document.getElementById('entryModal')).show();
                } else {
                    Api.showError(res);
                }
            });
        },
        clearFilters: function () {
            this.searchQuery = '';
            this.filterStatus = 'all';
            this.page = 0;
            this.searchResults = { existing: [], requested: [] };
            this.loadList();
        },
        backFromSearch: function () {
            this.searchResults = { existing: [], requested: [] };
            this.searchQuery = '';
            this.loadList();
        },
        autoIncrement: function (rq) {
            var self = this;
            var body = new FormData();
            body.append('name', rq.name);
            if (rq.item_id) body.append('item_id', rq.item_id);
            if (rq.generic_name) body.append('generic_name', rq.generic_name);
            if (rq.supplier_name) body.append('supplier_name', rq.supplier_name);
            if (rq.notes) body.append('notes', rq.notes);
            Api.post(window.REQ_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    Swal.fire({
                        icon: 'success',
                        title: res.mess || 'تم التسجيل',
                        showConfirmButton: false,
                        timer: 1500
                    });
                    self.searchResults = { existing: [], requested: [] };
                    self.searchQuery = '';
                    self.loadList();
                } else {
                    Api.showError(res);
                }
            });
        },
        requestAgain: function (rq) {
            this.autoIncrement(rq);
        },
        incrementSearch: function (rq) {
            var self = this;
            var body = new FormData();
            body.append('id', rq.id);
            Api.post(window.REQ_URLS.increment, body).then(function (res) {
                if (Api.isOk(res)) {
                    rq.request_count += 1;
                    self.loadList();
                } else {
                    Api.showError(res);
                }
            });
        },
        decrementSearch: function (rq) {
            var self = this;
            if (rq.request_count <= 1) {
                Swal.fire('تنبيه', 'لا يمكن أن يقل العدد عن 1', 'warning');
                return;
            }
            var body = new FormData();
            body.append('id', rq.id);
            Api.post(window.REQ_URLS.decrement, body).then(function (res) {
                if (Api.isOk(res)) {
                    rq.request_count -= 1;
                    self.loadList();
                } else {
                    Api.showError(res);
                }
            });
        },
        openForm: function () {
            this.clearForm();
            this.editMode = false;
            new bootstrap.Modal(document.getElementById('entryModal')).show();
        },
        clearForm: function () {
            this.form = {
                id: null,
                name: '',
                item_id: '',
                generic_name: '',
                supplier_name: '',
                notes: '',
                customer_name: '',
                customer_mobile: ''
            };
        },
        saveForm: function () {
            var self = this;
            if (!self.form.name.trim()) {
                Swal.fire('تنبيه', 'اسم الصنف مطلوب', 'warning');
                return;
            }
            var body = new FormData();
            body.append('name', self.form.name.trim());
            if (self.form.item_id) body.append('item_id', self.form.item_id.trim());
            if (self.form.generic_name) body.append('generic_name', self.form.generic_name.trim());
            if (self.form.supplier_name) body.append('supplier_name', self.form.supplier_name.trim());
            if (self.form.notes) body.append('notes', self.form.notes.trim());
            if (self.form.customer_name) body.append('customer_name', self.form.customer_name.trim());
            if (self.form.customer_mobile) body.append('customer_mobile', self.form.customer_mobile.trim());

            Api.post(window.REQ_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    Swal.fire({
                        icon: 'success',
                        title: res.mess || 'تم الحفظ',
                        showConfirmButton: false,
                        timer: 1500
                    });
                    var modalEl = document.getElementById('entryModal');
                    var modal = bootstrap.Modal.getInstance(modalEl);
                    if (modal) modal.hide();
                    self.clearForm();
                    self.searchResults = { existing: [], requested: [] };
                    self.searchQuery = '';
                    self.loadList();
                } else {
                    Api.showError(res);
                }
            });
        },
        selectRow: function (index) {
            this.selectedIndex = index;
            this.selectedRow = this.data[index] || {};
        },
        clearSelection: function () {
            this.selectedIndex = -1;
            this.selectedRow = {};
        },
        setStatus: function (status) {
            var self = this;
            var body = new FormData();
            body.append('id', self.selectedRow.id);
            body.append('status', status);
            Api.post(window.REQ_URLS.updateStatus, body).then(function (res) {
                if (Api.isOk(res)) {
                    Swal.fire({ icon: 'success', title: 'تم تحديث الحالة', showConfirmButton: false, timer: 1200 });
                    var modalEl = document.getElementById('statusModal');
                    if (modalEl) {
                        var modal = bootstrap.Modal.getInstance(modalEl);
                        if (modal) modal.hide();
                    }
                    self.loadList();
                    self.clearSelection();
                } else {
                    Api.showError(res);
                }
            });
        },
        convertItem: function () {
            var self = this;
            Swal.fire({
                title: 'تحويل لصنف؟',
                text: 'سيتم إنشاء صنف جديد في النظام بناءً على هذا الطلب',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    var body = new FormData();
                    body.append('id', self.selectedRow.id);
                    Api.post(window.REQ_URLS.convert, body).then(function (res) {
                        if (Api.isOk(res)) {
                            Swal.fire({ icon: 'success', title: 'تم التحويل', showConfirmButton: false, timer: 1500 });
                            self.loadList();
                            self.clearSelection();
                        } else {
                            Api.showError(res);
                        }
                    });
                }
            });
        },
        sendSms: function () {
            this.smsMessage = 'عزيزي العميل، الصنف \'' + this.selectedRow.name + '\' أصبح متوفراً الآن في صيدليتنا.';
            new bootstrap.Modal(document.getElementById('smsModal')).show();
        },
        doSendSms: function () {
            var self = this;
            var body = new FormData();
            body.append('id', self.selectedRow.id);
            body.append('message', self.smsMessage);
            Api.post(window.REQ_URLS.sendSms, body).then(function (res) {
                if (Api.isOk(res)) {
                    Swal.fire({ icon: 'success', title: 'تم إرسال الرسالة', showConfirmButton: false, timer: 1500 });
                    var modalEl = document.getElementById('smsModal');
                    if (modalEl) {
                        var modal = bootstrap.Modal.getInstance(modalEl);
                        if (modal) modal.hide();
                    }
                } else {
                    Api.showError(res);
                }
            });
        },
        editRow: function () {
            var r = this.selectedRow;
            this.form = {
                id: r.id,
                name: r.name || '',
                item_id: r.item_id || '',
                generic_name: r.generic_name || '',
                supplier_name: r.supplier_name || '',
                notes: r.notes || '',
                customer_name: r.customer_name || '',
                customer_mobile: r.customer_mobile || ''
            };
            this.editMode = true;
            new bootstrap.Modal(document.getElementById('entryModal')).show();
        },
        deleteRow: function () {
            var self = this;
            Swal.fire({
                title: 'حذف الطلب؟',
                text: 'هل أنت متأكد من حذف هذا الطلب؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#dc3545'
            }).then(function (result) {
                if (result.isConfirmed) {
                    var body = new FormData();
                    body.append('id', self.selectedRow.id);
                    Api.post(window.REQ_URLS.delete, body).then(function (res) {
                        if (Api.isOk(res)) {
                            Swal.fire({ icon: 'success', title: 'تم الحذف', showConfirmButton: false, timer: 1200 });
                            self.loadList();
                            self.clearSelection();
                        } else {
                            Api.showError(res);
                        }
                    });
                }
            });
        },
        goToPage: function (pg) {
            if (pg === '...') return;
            this.page = pg - 1;
            this.loadList();
        },
        formatDate: function (d) {
            if (!d) return '-';
            var dt = new Date(d);
            return dt.toLocaleDateString('ar-SA');
        },
        statusLabel: function (s) {
            var map = {
                'new': 'جديد',
                'ordered': 'تم الطلب',
                'available': 'متاح',
                'notified': 'تم الإبلاغ',
                'rejected': 'ملغي'
            };
            return map[s] || s;
        }
    }
});
