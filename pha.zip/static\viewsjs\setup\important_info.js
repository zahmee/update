var app = new Vue({
    el: '#app',
    data: {
        saving: false,
        form: emptyForm(),
        original: emptyForm(),
        errors: {}
    },
    computed: {
        // هل توجد تغييرات غير محفوظة؟
        dirty: function () {
            return JSON.stringify(this.form) !== JSON.stringify(this.original);
        }
    },
    mounted: function () {
        var d = window.INFO_DATA || {};
        var loaded = {
            name: d.name || '',
            vat: d.vat || '',
            tel: d.tel || '',
            mobile: d.mobile || '',
            address: d.address || '',
            msg1: d.msg1 || '',
            msg2: d.msg2 || '',
            change_count: !!d.change_count,
            change_count_amount: (d.change_count_amount != null ? String(d.change_count_amount) : '')
        };
        this.form = loaded;
        this.original = clone(loaded);
    },
    methods: {
        // إزالة خطأ الحقل بمجرد أن يبدأ المستخدم تصحيحه
        touch: function (field) {
            if (this.errors[field]) {
                this.$delete(this.errors, field);
            }
        },
        // التحقق من صحة الحقول قبل الإرسال
        validate: function () {
            var f = this.form;
            var e = {};
            if (!f.name) {
                e.name = 'اسم المنشأة مطلوب';
            }
            if (!f.vat) {
                e.vat = 'الرقم الضريبي مطلوب';
            } else if (!/^3\d{13}3$/.test(f.vat)) {
                e.vat = 'يجب أن يكون 15 رقماً ويبدأ وينتهي بالرقم 3';
            }
            if (!f.tel) {
                e.tel = 'رقم الهاتف الأرضي مطلوب';
            } else if (!/^0\d{8,9}$/.test(f.tel)) {
                e.tel = 'رقم الهاتف الأرضي غير صحيح';
            }
            if (!f.mobile) {
                e.mobile = 'رقم الجوال مطلوب';
            } else if (!/^05\d{8}$/.test(f.mobile)) {
                e.mobile = 'يجب أن يكون بصيغة 05XXXXXXXX';
            }
            if (!f.address) {
                e.address = 'العنوان مطلوب';
            }
            if (!f.msg1) {
                e.msg1 = 'رسالة الترحيب مطلوبة';
            }
            if (!f.msg2) {
                e.msg2 = 'رسالة أسفل الفاتورة مطلوبة';
            }
            if (f.change_count_amount !== '' &&
                (isNaN(Number(f.change_count_amount)) || Number(f.change_count_amount) < 0)) {
                e.change_count_amount = 'يجب أن يكون رقماً غير سالب';
            }
            this.errors = e;
            return Object.keys(e).length === 0;
        },
        // إعادة الحقول إلى آخر قيم محفوظة
        reset: function () {
            this.form = clone(this.original);
            this.errors = {};
        },
        save: function () {
            var self = this;
            if (!self.validate()) {
                Swal.fire('تنبيه', 'يرجى تصحيح الحقول المظللة بالأحمر', 'warning');
                return;
            }
            var f = self.form;
            var body = new FormData();
            body.append('name', f.name);
            body.append('vat', f.vat);
            body.append('tel', f.tel);
            body.append('mobile', f.mobile);
            body.append('address', f.address);
            body.append('msg1', f.msg1);
            body.append('msg2', f.msg2);
            body.append('change_count', f.change_count ? '1' : '0');
            body.append('change_count_amount', f.change_count_amount || '0');

            self.saving = true;
            Api.post(window.INFO_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    self.original = clone(self.form);
                    Api.showSuccess(res.mess || 'تم حفظ المعلومات بنجاح');
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.saving = false;
            });
        }
    }
});

function emptyForm() {
    return {
        name: '', vat: '', tel: '', mobile: '',
        address: '', msg1: '', msg2: '', change_count: false,
        change_count_amount: ''
    };
}

function clone(o) {
    return JSON.parse(JSON.stringify(o));
}
