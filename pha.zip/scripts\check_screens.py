# -*- coding: utf-8 -*-
import sys
sys.stdout = open('applications/asbab5/scripts/check_screens_out.txt', 'w', encoding='utf-8')
count = db(db.screens.id > 0).count()
print("Screens count:", count)
rows = db(db.screens.id > 0).select(orderby=db.screens.screen_code)
for r in rows:
    print(r.screen_code, r.name)
print("Done")
sys.stdout.close()
