var API_BASE = ADV_FLAGS.base;

var SOURCE_NAMES = {
    payroll: 'خصم من الراتب',
    reversal: 'عكس اعتماد المسير',
    cash: 'سداد مباشر',
    settle: 'تسوية',
    opening: 'مسدد سابق'
};

function localToday() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function postForm(url, fields) {
    var body = new FormData();
    Object.keys(fields || {}).forEach(function (k) {
        body.append(k, fields[k] === null || fields[k] === undefined ? '' : fields[k]);
    });
    return fetch(url, { method: 'POST', body: body }).then(function (r) { return r.json(); });
}

function toast(text) {
    Swal.fire({ toast: true, position: 'top', icon: 'success', title: text, timer: 2500, showConfirmButton: false });
}

var app = new Vue({
    el: '#app',
    data: {
        flags: ADV_FLAGS,
        sourceNames: SOURCE_NAMES,
        today: localToday(),
        data: [],
        totals: {},
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
            status_filter: '0'
        },
        columns: [
            { key: 'id', label: 'م', sort: true, cls: 'text-center' },
            { key: 'emp_name', label: 'اسم الموظف', sort: true },
            { key: 'advance_type', label: 'النوع', sort: true },
            { key: 'amount', label: 'المبلغ', sort: true },
            { key: 'paid_amount', label: 'المسدد', sort: true },
            { key: 'remaining', label: 'المتبقي', sort: true },
            { key: 'advance_date', label: 'تاريخ السلفة', sort: true },
            { key: 'last_pay_date', label: 'آخر سداد', sort: true },
            { key: 'is_closed', label: 'الحالة', sort: true, cls: 'text-center' }
        ],
        data_row_count: 0,
        selectedRow: -1,
        loading: false,
        // البطاقة
        card: null,
        cardRow: null,
        cardId: null,
        cardLoading: false,
        cardError: '',
        cardSeq: 0,
        cardTrigger: null,
        pendingModal: null,
        returnToCard: false,
        // نموذج السلفة
        new_row: true,
        edit_row_data: {},
        saving: false,
        employees_list: [],
        advance_types: [],
        // نموذج السداد
        pay: { source: 'cash', amount: '', pay_date: '', note: '', saving: false },
        searchTimer: null
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages, current = this.currentPage, pages = [];
            var start = Math.max(1, current - 2), end = Math.min(total, current + 2);
            if (start > 1) { pages.push(1); if (start > 2) pages.push('...'); }
            for (var i = start; i <= end; i++) pages.push(i);
            if (end < total) { if (end < total - 1) pages.push('...'); pages.push(total); }
            return pages;
        },
        cardTitle: function () {
            if (this.card) return this.card.employee.name;
            return this.cardRow ? this.cardRow.emp_name : 'بطاقة السلفة';
        },
        positivePayments: function () {
            return this.card ? this.card.payments.filter(function (p) { return p.amount > 0; }).length : 0;
        },
        payAmountNum: function () {
            return parseFloat(this.pay.amount) || 0;
        },
        payAfter: function () {
            return this.card ? Math.round((this.card.advance.remaining - this.payAmountNum) * 100) / 100 : 0;
        },
        editLocked: function () {
            return !this.new_row && (parseFloat(this.edit_row_data.paid_amount) || 0) > 0.005;
        }
    },
    created: function () {
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var d = Api.getData(data) || {};
                this.employees_list = d.employees || [];
                this.advance_types = d.advance_types || [];
            }.bind(this));
        this.reload().then(function () {
            // رابط مباشر لبطاقة سلفة: advances/index?adv=<id>
            var id = parseInt(new URLSearchParams(window.location.search).get('adv'), 10);
            if (id > 0) this.openCard(id, null);
        }.bind(this));
    },
    mounted: function () {
        var cardEl = document.getElementById('advCardModal');
        cardEl.addEventListener('shown.bs.modal', function () {
            // Bootstrap يتجاهل hide() أثناء حركة الفتح
            if (this.pendingModal) this.hideModal('advCardModal');
        }.bind(this));
        cardEl.addEventListener('hidden.bs.modal', function () {
            var next = this.pendingModal;
            this.pendingModal = null;
            if (next) this.showModal(next);
            else this.closeCard();
        }.bind(this));
        ['payModal', 'advModal'].forEach(function (id) {
            document.getElementById(id).addEventListener('hidden.bs.modal', function () {
                if (this.returnToCard && this.cardId) {
                    this.returnToCard = false;
                    this.loadCard(this.cardId);
                    this.showModal('advCardModal');
                } else {
                    this.returnToCard = false;
                    this.closeCard();
                }
            }.bind(this));
        }, this);
    },
    methods: {
        // ── القائمة ──
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                status_filter: this.getData.status_filter
            };
            var url = new URL(API_BASE + 'get_advances', window.location.origin);
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, { headers: { 'Accept': 'application/json' } }).then(function (r) { return r.json(); });
        },
        reload: function (silent) {
            if (!silent) this.loading = true;
            return this.fetchData().then(function (data) {
                if (!Api.isOk(data)) { Api.showError(data); return; }
                this.data = Api.getData(data) || [];
                this.data_row_count = data.count;
                this.totals = data.totals || {};
                if (this.cardId) {
                    this.selectedRow = this.data.findIndex(function (r) { return r.id === this.cardId; }, this);
                }
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.reload();
        },
        onSearch: function () {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(this.onChange, 300);
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.reload();
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },

        // ── البطاقة ──
        rowSelect: function (index, row, event) {
            // انتظر حتى تنتهي النافذة السابقة وخلفيتها من الإغلاق
            if (document.body.classList.contains('modal-open')) return;
            this.selectedRow = index;
            this.cardTrigger = event.currentTarget.matches('button')
                ? event.currentTarget : event.currentTarget.querySelector('.adv-name-btn');
            this.openCard(row.id, row);
        },
        openCard: function (id, row) {
            this.selectedRow = this.data.findIndex(function (r) { return r.id === id; });
            this.cardRow = row;
            this.card = null;
            this.loadCard(id);
            this.$nextTick(function () { this.showModal('advCardModal'); });
        },
        loadCard: function (id) {
            var seq = ++this.cardSeq;
            this.cardId = id;
            this.cardLoading = true;
            this.cardError = '';
            return fetch(API_BASE + 'get_advance_card/' + id, { headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (seq !== this.cardSeq) return;  // استجابة لبطاقة أُغلقت أو استُبدلت
                    if (Api.isOk(data)) this.card = Api.getData(data);
                    else { this.card = null; this.cardError = Api.getError(data) || 'تعذر تحميل بطاقة السلفة'; }
                }.bind(this))
                .catch(function () {
                    if (seq === this.cardSeq) this.cardError = 'تعذر الاتصال بالخادم';
                }.bind(this))
                .finally(function () { if (seq === this.cardSeq) this.cardLoading = false; }.bind(this));
        },
        switchCard: function (id) {
            this.cardRow = this.data.find(function (r) { return r.id === id; }) || this.cardRow;
            this.selectedRow = this.data.findIndex(function (r) { return r.id === id; });
            this.loadCard(id);
        },
        closeCard: function () {
            this.cardSeq++;
            this.card = null;
            this.cardRow = null;
            this.cardId = null;
            this.cardError = '';
            this.selectedRow = -1;
            if (this.cardTrigger && document.contains(this.cardTrigger)) this.cardTrigger.focus();
            this.cardTrigger = null;
        },
        showModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show();
        },
        hideModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).hide();
        },
        // ينتقل من البطاقة إلى نافذة أخرى ثم يعود إليها عند إغلاقها
        fromCard: function (modalId) {
            this.returnToCard = true;
            this.pendingModal = modalId;
            this.hideModal('advCardModal');
        },

        // ── السداد ──
        openPay: function () {
            if (!this.card || this.card.advance.is_closed) return;
            this.pay = { source: 'cash', amount: '', pay_date: this.today, note: '', saving: false };
            this.fromCard('payModal');
        },
        savePayment: function () {
            var adv = this.card && this.card.advance;
            if (!adv || this.pay.saving) return;
            var amount = this.payAmountNum;
            if (amount <= 0) { Swal.fire('تنبيه', 'أدخل مبلغ السداد', 'error'); return; }
            if (amount > adv.remaining + 0.005) {
                Swal.fire('تنبيه', 'المبلغ أكبر من المتبقي على السلفة (' + this.money(adv.remaining) + ')', 'error');
                return;
            }
            if (this.pay.source === 'settle' && !this.pay.note.trim()) {
                Swal.fire('تنبيه', 'اكتب سبب التسوية', 'error');
                return;
            }
            this.pay.saving = true;
            postForm(API_BASE + 'add_payment', {
                advance_id: adv.id,
                amount: amount,
                pay_date: this.pay.pay_date,
                source: this.pay.source,
                note: this.pay.note,
                expected_paid: adv.paid_amount
            }).then(function (data) {
                if (Api.isOk(data)) {
                    this.hideModal('payModal');  // تعود البطاقة محدَّثة عند الإغلاق
                    toast(data.mess || 'تم تسجيل السداد');
                    this.reload(true);
                } else {
                    Api.showError(data);
                }
            }.bind(this)).catch(function () {
                Swal.fire('خطأ', 'تعذر الاتصال بالخادم؛ لم يُحفظ السداد', 'error');
            }).finally(function () { this.pay.saving = false; }.bind(this));
        },
        canDeletePayment: function (p) {
            return p.deletable && (p.source !== 'settle' || this.flags.is_admin);
        },
        deletePayment: function (p) {
            var id = this.cardId;
            Swal.fire({
                title: 'حذف ' + p.source_name,
                text: 'حذف دفعة ' + this.money(p.amount) + ' بتاريخ ' + this.dateOnly(p.pay_date) + '؟ يعود المبلغ إلى المتبقي على السلفة.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('advCardModal')  // داخل البطاقة حتى لا يسحب مصيدة تركيزها الأزرار
            }).then(function (result) {
                if (!result.isConfirmed) return;
                postForm(API_BASE + 'delete_payment/' + p.id).then(function (data) {
                    if (Api.isOk(data)) {
                        toast(data.mess || 'حُذفت الدفعة');
                        if (this.cardId === id) this.loadCard(id);
                        this.reload(true);
                    } else {
                        Api.showError(data);
                    }
                }.bind(this));
            }.bind(this));
        },

        // ── إضافة / تعديل / حذف السلفة ──
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = { employee: '', advance_type: '', amount: '', advance_date: this.today };
            this.returnToCard = false;
            this.showModal('advModal');
        },
        edit_row: function () {
            if (!this.card) return;
            var a = this.card.advance;
            this.new_row = false;
            this.edit_row_data = {
                id: a.id, employee: a.employee, advance_type: a.advance_type,
                amount: a.amount, advance_date: this.dateOnly(a.advance_date), paid_amount: a.paid_amount
            };
            this.fromCard('advModal');
        },
        save_data: function () {
            var d = this.edit_row_data;
            if (!d.employee) { Swal.fire('تنبيه', 'يجب اختيار الموظف', 'error'); return; }
            if (!d.advance_type) { Swal.fire('تنبيه', 'يجب اختيار نوع السلفة', 'error'); return; }
            if (!(parseFloat(d.amount) > 0)) { Swal.fire('تنبيه', 'يجب إدخال المبلغ', 'error'); return; }
            if (this.saving) return;
            this.saving = true;
            var fields = { employee: d.employee, advance_type: d.advance_type, amount: d.amount, advance_date: d.advance_date || '' };
            if (!this.new_row) fields.id = d.id;
            postForm(API_BASE + (this.new_row ? 'new_advance' : 'update_advance'), fields).then(function (data) {
                if (Api.isOk(data)) {
                    var rec = Api.getData(data);
                    if (this.new_row && rec && rec.id) {
                        // افتح بطاقة السلفة الجديدة بعد إغلاق النموذج
                        this.cardRow = rec;
                        this.cardId = rec.id;
                        this.returnToCard = true;
                    }
                    this.hideModal('advModal');
                    toast('تم الحفظ');
                    this.reload(true);
                } else {
                    Api.showError(data);
                }
            }.bind(this)).catch(function () {
                Swal.fire('خطأ', 'تعذر الاتصال بالخادم؛ لم تُحفظ السلفة', 'error');
            }).finally(function () { this.saving = false; }.bind(this));
        },
        delete_adv: function () {
            if (!this.card) return;
            var adv = this.card.advance, name = this.card.employee.name;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'حذف سلفة ' + name + ' بمبلغ ' + this.money(adv.amount) + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('advCardModal')  // داخل البطاقة حتى لا يسحب مصيدة تركيزها الأزرار
            }).then(function (result) {
                if (!result.isConfirmed) return;
                postForm(API_BASE + 'delete_advance/' + adv.id).then(function (data) {
                    if (Api.isOk(data)) {
                        this.hideModal('advCardModal');
                        toast('حُذفت السلفة');
                        this.reload(true);
                    } else {
                        Api.showError(data);
                    }
                }.bind(this));
            }.bind(this));
        },

        // ── تنسيق ──
        isClosed: function (row) {
            return row.is_closed === 'T' || row.is_closed === true;
        },
        remaining: function (row) {
            return Math.round(((parseFloat(row.amount) || 0) - (parseFloat(row.paid_amount) || 0)) * 100) / 100;
        },
        progress: function (row) {
            var amount = parseFloat(row.amount) || 0;
            return amount > 0 ? Math.min(100, Math.round((parseFloat(row.paid_amount) || 0) / amount * 100)) : 0;
        },
        money: function (n) {
            return (parseFloat(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        dateOnly: function (v) {
            return v ? String(v).slice(0, 10) : '';
        },
        ageText: function (days) {
            if (days === null || days === undefined) return '—';
            if (days < 60) return days + ' يوم';
            var months = Math.floor(days / 30.44);
            return months < 24 ? months + ' شهر' : (Math.round(months / 12 * 10) / 10) + ' سنة';
        }
    }
});
