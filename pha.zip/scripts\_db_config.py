# -*- coding: utf-8 -*-
"""
قارئ إعدادات قاعدة البيانات للسكربتات المستقلة.

تقرأ هذه الوحدة سلسلة الاتصال من private/appconfig.ini بدلاً من تضمين
كلمة المرور داخل كود السكربتات. تُستخدم من السكربتات التي تعمل خارج
سياق web2py (لا تملك وصولاً لـ AppConfig).
"""

import os
import configparser
from urllib.parse import urlparse, unquote

# private/appconfig.ini يقع في المجلد الأعلى من scripts/
_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "private", "appconfig.ini"
)


def _parse_uri():
    """قراءة db.uri من appconfig.ini وتحليله إلى مكوّناته."""
    parser = configparser.ConfigParser(interpolation=None)
    if not parser.read(_CONFIG_PATH, encoding="utf-8"):
        raise RuntimeError("تعذّر قراءة appconfig.ini من: " + _CONFIG_PATH)
    uri = parser.get("db", "uri")
    parsed = urlparse(uri)
    return {
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
        "host": parsed.hostname or "localhost",
        "port": parsed.port or 5432,
        "dbname": (parsed.path or "/").lstrip("/"),
    }


def get_conn_string(dbname=None):
    """إرجاع سلسلة اتصال psycopg2 مبنية من appconfig.ini.

    dbname اختياري — لو مُرِّر يتجاوز الاسم المقروء من الإعداد
    (للحفاظ على توافق السكربتات التي تستقبل اسم القاعدة عبر sys.argv).
    """
    c = _parse_uri()
    db_name = dbname or c["dbname"]
    return (
        f"dbname={db_name} user={c['user']} password={c['password']} "
        f"host={c['host']} port={c['port']}"
    )


def get_db_params():
    """إرجاع مكوّنات الاتصال كقاموس (user, password, host, port, dbname)."""
    return _parse_uri()
