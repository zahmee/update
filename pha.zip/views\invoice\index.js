var app = new Vue({
    el: '#app',
    data: {
        newTodo: '',
        NewItem: [],
        NewItemCount: 1,
        // حدود الحارس — يضبطها الخادم من إعدادات النظام، وهذه قيم احتياطية
        maxLineQty: (typeof MAX_LINE_QTY !== 'undefined' ? MAX_LINE_QTY : 1000),
        confirmQty: (typeof CONFIRM_LINE_QTY !== 'undefined' ? CONFIRM_LINE_QTY : 100),
        invoiceWarnAmount: (typeof INVOICE_WARN_AMOUNT !== 'undefined' ? INVOICE_WARN_AMOUNT : 3000),
        AllItems: [],
        todos: [],
        uuid1: '',
        uuid2: '',
        URL: this.purl,
        seller: this.seller,
        vat_no: this.vat_no,
        comp_name: this.comp_name,
        way: '',
        NowDate: new Date(),
        itemNotFound: false,
        returnData: {},
        key_payment_method: [{
            name: '',
            id: 0
        }],
        selected_method: 1,
        customer: {
            'id': 1,
            'name': 'عميل نقدي',
            'show': false,
        },
        serchCustomar: {
            show: false,
            value: ''
        },
        serchCustomarList: [],
        serchItems: {
            show: false,
            vlaue: ''
        },
        serchItemsListDet: [],
        serchItemsListMaster: [],
        VAT: 0.0,
        discount: 0.0,
        invoce_no: 0,
        GivenByCustomer: 0.0,
        save_clicked: true,
        paying: false,
        aux: new AudioContext(),
        coust_pay: {
            coust: 0,
            mount: 0.0,
            note: '',
            type: 0,
            pay_note: '',
        },
    },
    created() {
        this.$http.get(this.URL + '/../get_payment_method').then(response => {
            if (Api.isOk(response.body)) {
                this.key_payment_method = Api.getData(response.body);
                this.uuid1 = this.uuidv4();
            }
        }, response => {});
    },
    methods: {
        getitem() {
            if (!this.NewItem) {
                this.itemNotFound = true;
                this.NewItemCount = 1;
                this.beep(100, 520, 200);
                return;
            }
            var itm = String(this.NewItem);
            var n_item = itm.split("*");
            if (n_item.length > 1) {
                this.NewItemCount = n_item[0];
                this.NewItem = n_item.slice(1).join("*");
            }
            if (this.NewItemCount < 0) {
                this.NewItemCount = 1;
                this.beep(100, 520, 200);
                return;
            }
            // حارس الكمية — يُطبَّق هنا لا في getcount، حتى تبقى سرعة الإدخال
            // بالسهم لأعلى كما هي دون أي تغيير.
            var q = parseFloat(this.NewItemCount);
            var self = this;
            if (isFinite(q) && q > this.maxLineQty) {
                this.badQty(q);
                this.beep(100, 520, 200);
                this.NewItem = '';
                this.NewItemCount = 1;
                return;
            }
            if (isFinite(q) && q > this.confirmQty) {
                Swal.fire({
                    icon: 'warning',
                    title: 'تأكيد الكمية',
                    html: 'الكمية المُدخلة <b>' + q + '</b> — هل هي صحيحة؟',
                    showCancelButton: true,
                    confirmButtonText: 'نعم، الكمية صحيحة',
                    cancelButtonText: 'إلغاء'
                }).then(function (res) {
                    if (res && (res.isConfirmed || res.value === true)) {
                        self.fetchAndAddItem();
                    } else {
                        self.NewItem = '';
                        self.NewItemCount = 1;
                    }
                });
                return;
            }
            this.fetchAndAddItem();
        },
        fetchAndAddItem() {
            this.$http.get(this.URL + '/../../invoice/getit/?itid=' + this.NewItem).then(response => {
                var items = Api.getData(response.body);
                if (Api.isOk(response.body) && items && items.length > 0) {
                    var itm = items[0];
                    if (itm.flexible_price === "T") {
                        items[0]['count'] = 1;
                        items[0]['public_price'] = (parseFloat(itm.public_price) * parseFloat(this.NewItemCount));
                        this.NewItemCount = 1;
                        items[0]['total'] = parseFloat(items[0]['public_price'] * this.NewItemCount).toFixed(2);
                        var vat_mount = (items[0]['public_price'] * this.NewItemCount * items[0]['vat']).toFixed(2);
                        items[0]['vat_mount'] = vat_mount;
                        items[0]['way'] = this.way;
                        this.AllItems.push(items[0]);
                        this.NewItem = '';
                        this.way = '';
                        this.itemNotFound = false;
                        this.NewItemCount = 1;
                    } else {
                        items[0]['count'] = this.NewItemCount;
                        items[0]['total'] = parseFloat(items[0]['public_price'] * this.NewItemCount).toFixed(2);
                        var vat_mount = (items[0]['public_price'] * this.NewItemCount * items[0]['vat']).toFixed(2);
                        items[0]['vat_mount'] = vat_mount;
                        items[0]['way'] = this.way;
                        this.AllItems.push(items[0]);
                        this.NewItem = '';
                        this.way = '';
                        this.itemNotFound = false;
                        this.NewItemCount = 1;
                    }
                } else {
                    this.beep(100, 520, 200);
                    this.NewItem = '';
                    this.itemNotFound = true;
                    this.NewItemCount = 1;
                }
            }, response => {
                this.NewItem = '';
            });
        },
        getcustomer() {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                var customers = Api.getData(response.body);
                if (Api.isOk(response.body) && customers && customers.length > 0) {
                    this.customer = customers[0];
                    this.customer.show = true;
                    this.selected_method = 3;
                    if (this.customer.amount < 0) {
                        this.GivenByCustomer = this.customer.amount.toFixed(2) * -1;
                    }
                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                    this.selected_method = 1;
                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
            });
        },
        removeItem(index) {
            this.AllItems.splice(index, 1);
        },
        lineTotal(item) {
            var p = parseFloat(item.public_price) || 0;
            var c = parseFloat(item.count) || 0;
            var v = parseFloat(item.vat) || 0;
            return (p * c * (1 + v)).toFixed(2);
        },
        getcount() {
            this.NewItemCount = this.NewItem;
            this.NewItem = '';
        },
        validQty(v) {
            var n = parseFloat(v);
            return isFinite(n) && n > 0 && n <= this.maxLineQty;
        },
        badQty(q) {
            Swal.fire({
                icon: 'error',
                title: 'كمية غير صحيحة',
                html: 'الكمية <b>' + q + '</b> تتجاوز الحد المسموح (' + this.maxLineQty + ').'
                    + '<br>تأكد أنك لم تُدخل <b>رقم الصنف</b> في خانة الكمية.'
            });
        },
        // تعديل الكمية يدوياً على سطر موجود — نفس تدرّج الحارس
        checkQty(item) {
            var q = parseFloat(item.count);
            var self = this;
            if (!isFinite(q) || q <= 0) {
                item.count = 1;
                return;
            }
            if (q > this.maxLineQty) {
                this.badQty(q);
                item.count = 1;
                return;
            }
            if (q > this.confirmQty) {
                Swal.fire({
                    icon: 'warning',
                    title: 'تأكيد الكمية',
                    html: 'الكمية المُدخلة <b>' + q + '</b> — هل هي صحيحة؟',
                    showCancelButton: true,
                    confirmButtonText: 'نعم، الكمية صحيحة',
                    cancelButtonText: 'إلغاء'
                }).then(function (res) {
                    if (!(res && (res.isConfirmed || res.value === true))) {
                        item.count = 1;
                        self.$forceUpdate();
                    }
                });
            }
        },
        discountFun() {
            var newval = this.total * 0.1;
            if (this.discount > newval) {
                this.discount = 0;
            }
        },
        findCustomer() {
            this.serchCustomar.show = !this.serchCustomar.show;
        },
        SerchCustomer() {
            if (this.serchCustomar.value.length > 2) {
                this.$http.get(this.URL + '/../../invoice/search_c/?itid=' + this.serchCustomar.value).then(response => {
                    var results = Api.getData(response.body);
                    if (Api.isOk(response.body) && results && results.length > 0) {
                        this.serchCustomarList = results;
                    } else {
                        this.serchCustomarList = [];
                        this.customer.id = 1;
                        this.customer.name = 'عميل نقدي';
                    }
                }, response => {});
            } else {
                this.serchCustomarList = [];
            }
        },
        selectSerchCustomer(index) {
            this.customer.id = this.serchCustomarList[index].id;
            this.getcustomer();
            this.serchCustomar.show = !this.serchCustomar.show;
        },
        findItems() {
            this.serchItems.show = !this.serchItems.show;
        },
        SerchItems() {
            if (this.serchItems.value.length > 2) {
                this.$http.get(this.URL + '/../../items_qry/search_item/?itid=' + this.serchItems.value).then(response => {
                    if (response.body != "") {
                        this.serchItemsListMaster = response.body;
                    } else {
                        this.serchItemsListMaster = [];
                    }
                });
            } else {
                this.serchItemsListMaster = [];
            }
        },
        selectserchItems(index) {
            var serch_item_det = this.serchItemsListMaster[index];
            this.$http.get(this.URL + '/../../items_qry/search_item_det/?itid=' + serch_item_det.id).then(response => {
                if (response.body != "") {
                    this.NewItem = response.body[0]['id'].toString();
                    this.getitem();
                    this.serchItemsListMaster = [];
                    this.serchItemsListDet = [];
                    this.serchItems.value = '';
                    this.NewItem = '';
                    this.itemNotFound = false;
                    this.NewItemCount = 1;
                    this.serchItems.show = !this.serchItems.show;
                } else {
                    this.serchItemsListMaster = [];
                }
            });
        },
        selectserchItemsDet(index) {},
        SaveAll() {
            var self = this;
            alldata = {};
            // حفظٌ جارٍ بالفعل: زر الحفظ يختفي عبر v-if، لكن اختصار F2 مربوط
            // على الحاوية في index.html فيتجاوز الزر تماماً. الحارس هنا لأن
            // هذه الدالة هي المدخل الوحيد المشترك بين الزر والاختصار.
            if (!this.save_clicked) {
                return;
            }
            if (this.customer.id == 1 & this.selected_method == 3) {
                Swal.fire('المبيعات النقدية يجب ان تكون بالنقدي فقط');
                return;
            }
            if (this.uuid1 === this.uuid2) {
                Swal.fire('لقد تم حفظ هذه الفاتورة بالفعل');
                return;
            }
            if (this.AllItems.length == 0) {
                Swal.fire('لا يوجد منتجات في الفاتورة');
                return;
            }
            // تنبيه على إجمالي الفاتورة — تأكيد لا منع، فالفواتير الكبيرة واردة
            var tot = parseFloat(this.totalAfterAll) || 0;
            if (tot > this.invoiceWarnAmount) {
                Swal.fire({
                    icon: 'warning',
                    title: 'تنبيه على مبلغ الفاتورة',
                    html: 'إجمالي الفاتورة <b>' + tot.toFixed(2) + '</b> ريال —'
                        + ' وهو أعلى من المعتاد (' + this.invoiceWarnAmount + ').'
                        + '<br>تأكد من الكميات والأسعار قبل الحفظ.',
                    showCancelButton: true,
                    confirmButtonText: 'المبلغ صحيح — احفظ',
                    cancelButtonText: 'رجوع للمراجعة'
                }).then(function (res) {
                    if (res && (res.isConfirmed || res.value === true)) {
                        self.doSave();
                    }
                });
                return;
            }
            this.doSave();
        },
        doSave() {
            var self = this;
            alldata = {};
            this.save_clicked = false;
            alldata['itm'] = this.AllItems;
            alldata['uuid'] = this.uuid1;
            alldata['total'] = parseFloat(this.total).toFixed(2);
            alldata['discount'] = this.discount;
            alldata['totalAfterDiscount'] = this.totalAfterDiscount.toFixed(2);
            alldata['vat'] = parseFloat(this.vat).toFixed(2);
            alldata['totalAfterAll'] = this.totalAfterAll.toFixed(2);
            alldata['customer'] = this.customer.id;
            alldata['method'] = this.selected_method;
            this.$http.post(this.URL + '/../save/', JSON.stringify(alldata), { emulateJSON: true }).then(function (response) {
                var d = response.body;
                if (Api.isOk(d) && d.invno > 0) {
                    self.invoce_no = d.invno;
                    self.uuid2 = self.uuid1;
                    self.returnData = d;
                    if (d.mess && d.mess.length > 0) {
                        Swal.fire('تم حفظ الفاتورة و لكن يوجد خطأ التالي :\n\n' + d.mess);
                    }
                    // تنبيه (لا خطأ): الفاتورة سليمة — يظهر كإشعار عابر لا يعطّل الطباعة
                    if (d.warn && d.warn.length > 0) {
                        Swal.fire({
                            toast: true, position: 'top', icon: 'warning',
                            title: d.warn, showConfirmButton: false, timer: 4000,
                            timerProgressBar: true
                        });
                    }
                    // طباعة مباشرة بعد الحفظ (ننتظر تحديث DOM أولاً)
                    self.$nextTick(function () {
                        self.printInvoice();
                        self.resetInvoice();
                    });
                } else if (d.err === "5" || d.err === 5) {
                    self.save_clicked = true;
                    Swal.fire('لقد تم حفظ هذه الفاتورة بالفعل');
                } else {
                    self.save_clicked = true;
                    Api.showError(d);
                }
            }, function () {
                self.save_clicked = true;
                Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
            });
        },
        printInvoice() {
            try {
                var elem = document.getElementById("pr");
                var titleDiv = elem.querySelector("#titel");
                if (titleDiv) {
                    titleDiv.innerText = "فاتورة ضريبية مبسطة";
                }
                var newpr = elem.innerHTML;
                var a = window.open('', 'PRINT', 'height=600, width=600');
                if (!a) {
                    Swal.fire('تنبيه', 'يرجى السماح بالنوافذ المنبثقة لطباعة الفاتورة', 'warning');
                    return;
                }
                var now_date = new Date().toLocaleString("en-GB");
                qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
                var a1 = this.getTLV(1, this.seller);
                var a2 = this.getTLV(2, this.vat_no);
                var a3 = this.getTLV(3, now_date);
                var a4 = this.getTLV(4, this.totalAfterDiscount.toString());
                var a5 = this.getTLV(5, this.vat.toString());
                var aa = a1 + a2 + a3 + a4 + a5;
                var qr = qrcode(0, 'L');
                if (this.returnData.qr && this.returnData.qr !== '') {
                    qr.addData(this.returnData.qr);
                } else {
                    qr.addData(this.hexToBase64(aa));
                }
                qr.make();
                a.document.write('<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>طباعة فاتورة</title><style>* { margin: 0; padding: 0; box-sizing: border-box; } html { direction: ltr; text-align: center; } body { font-family: Tahoma,Arial,sans-serif; direction: rtl; text-align: right; width: 72mm; margin: 0 auto; padding: 2mm; font-size: 13px; color: #000; background: #fff; display: inline-block; -webkit-print-color-adjust: exact; print-color-adjust: exact; } @media print { @page { size: 80mm auto; margin: 0; } html { text-align: center; } body { width: 72mm; margin: 0 auto; padding: 2mm; } }</style></head><body>');
                a.document.write(newpr);
                a.document.write('<div style="text-align:center; margin:8px 0;">');
                a.document.write(qr.createSvgTag(3, 1));
                a.document.write('</div>');
                a.document.write('<hr style="border:none; border-top:1px dashed #999; margin:6px 0;">');
                a.document.write('</body></html>');
                a.document.close();
                a.focus();
                a.onafterprint = function () { a.close(); };
                a.print();
            } catch (e) {
                console.error('print error:', e);
            }
        },
        resetInvoice() {
            this.uuid1 = this.uuidv4();
            this.save_clicked = true;
            this.AllItems = [];
            this.discount = 0;
            this.customer.id = 1;
            this.customer.name = "مبيعات نقدية";
            this.selected_method = 1;
            this.customer.show = false;
            this.GivenByCustomer = 0;
            this.$nextTick(function () {
                if (this.$refs.NewItem) this.$refs.NewItem.focus();
            });
        },
        AddHalal() {
            var me = this;
            this.AllItems.forEach(function (el, index) {
                if (el.id === 1) {
                    me.AllItems.splice(index, 1);
                }
            });
            var baqee = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            this.NewItem = 1;
            this.NewItemCount = Math.floor(baqee * 100).toFixed(0);
            this.getitem();
        },
        uuidv4() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },
        bytesToHex(bytes) {
            return Array.from(bytes, function (byte) { return byte.toString(16).padStart(2, "0"); }).join("");
        },
        hexToBase64(str) {
            return btoa(String.fromCharCode.apply(null,
                str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" "))
            );
        },
        stringToUTF8Bytes(string) {
            return new TextEncoder().encode(string);
        },
        isDoubleByte(str) {
            for (var i = 0, n = str.length; i < n; i++) {
                if (str.charCodeAt(i) > 255) { return true; }
            }
            return false;
        },
        getTLV(tag, val) {
            var len = parseInt(val.length.toString(2), 2).toString(16);
            var spaceCount = (val.split(" ").length - 1);
            if ((tag == 1) && (this.isDoubleByte(val) == true)) {
                len = parseInt(((val.length * 2) - spaceCount).toString(2), 2).toString(16);
            }
            var tag = parseInt(tag.toString(2), 2).toString(16);
            var vale = this.bytesToHex(this.stringToUTF8Bytes(val));
            if (len.length == 1) { len = '0' + len; }
            if (tag.length == 1) { tag = '0' + tag; }
            return tag + len + vale;
        },
        beep(vol, freq, duration) {
            aux = this.aux;
            v = aux.createOscillator();
            u = aux.createGain();
            v.connect(u);
            v.frequency.value = freq;
            v.type = "square";
            u.connect(aux.destination);
            u.gain.value = vol * 0.01;
            v.start(aux.currentTime);
            v.stop(aux.currentTime + duration * 0.001);
        },
        printOne(index) {
            var a = window.open('', 'PRINT', 'height=600, width=600');
            if (!a) return;
            a.document.write('<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=0.8"><title>طباعة فاتورة</title><style>* { margin: 0; padding: 0; box-sizing: border-box; }</style></head><body style="text-align: center; font-size: 14px;">');
            a.document.write('<div> ' + comp_name + ' </div>');
            a.document.write('<div> ' + this.customer.name + ' </div>');
            a.document.write('<div> ' + this.AllItems[index].name + ' </div>');
            a.document.write('<div> ' + this.AllItems[index].way + ' </div>');
            a.document.write('</body></html>');
            a.document.close();
            a.onafterprint = function () { a.close(); };
            a.print();
        },
        cancel_data() {},
        save_pay_data() {
            if (this.customer.id == 1) {
                Swal.fire('تنبيه', 'لا يمكن تسجيل سداد للعميل النقدي الافتراضي', 'warning');
                return;
            }
            if (this.paying) return;
            var self = this;
            this.paying = true;
            this.coust_pay.coust = this.customer.id;
            var url = new URL(window.location.href + '/../../customers_api/save_coust_pay');
            var params = this.coust_pay;
            Object.keys(params).forEach(function (key) { url.searchParams.append(key, params[key]); });
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (response) { return response.json(); })
              .then(function (data) {
                if (Api.isOk(data)) {
                    var elem = document.getElementById("pay_Modal");
                    var modal = bootstrap.Modal.getInstance(elem);
                    if (modal) modal.hide();
                    self.coust_pay.mount = 0.0;
                    self.coust_pay.note = '';
                    self.coust_pay.pay_note = '';
                    Swal.fire('عمل رائع', 'شكرا لك لقد تمت عملية الحفظ بشكل صحيح', 'success');
                } else {
                    Swal.fire('تنبية', Api.getError(data), 'error');
                }
            }).catch(function () {
                Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
            }).finally(function () {
                self.paying = false;
            });
        },
        ShowPrice() {
            var elem = document.getElementById("pr");
            var titleDiv = elem.querySelector("#titel");
            if (titleDiv) { titleDiv.innerText = "عرض سعر"; }
            var newpr = elem.innerHTML;
            var a = window.open('', 'PRINT', 'height=600, width=600');
            if (!a) return;
            a.document.write('<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>عرض سعر</title><style>* { margin: 0; padding: 0; box-sizing: border-box; } html { direction: ltr; text-align: center; } body { font-family: Tahoma,Arial,sans-serif; direction: rtl; text-align: right; width: 72mm; margin: 0 auto; padding: 2mm; font-size: 13px; color: #000; background: #fff; display: inline-block; -webkit-print-color-adjust: exact; print-color-adjust: exact; } @media print { @page { size: 80mm auto; margin: 0; } html { text-align: center; } body { width: 72mm; margin: 0 auto; padding: 2mm; } }</style></head><body>');
            a.document.write(newpr);
            a.document.write('</body></html>');
            a.document.close();
            a.onafterprint = function () { a.close(); };
            a.print();
        }
    },
    computed: {
        total() {
            var total = 0.0;
            this.AllItems.forEach(function (element) {
                total += parseFloat(element.public_price) * parseFloat(element.count);
            });
            return parseFloat(total).toFixed(2);
        },
        now() {
            return Date.now();
        },
        vat() {
            var vat = 0.0;
            this.AllItems.forEach(function (element) {
                var el_vat = ((element.public_price * element.vat) * element.count);
                vat += parseFloat(el_vat);
            });
            return parseFloat(vat).toFixed(2);
        },
        totalAfterDiscount() {
            return parseFloat(this.total) - parseFloat(this.discount);
        },
        totalAfterAll() {
            return parseFloat(this.totalAfterDiscount) + parseFloat(this.vat);
        },
        BaqeeHalal() {
            var halal = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            if (halal < 1) return halal;
            else return 0.0;
        },
        TheRest() {
            var rest = (this.GivenByCustomer - this.totalAfterAll.toFixed(2)).toFixed(2);
            return rest;
        }
    }
});
