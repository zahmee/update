# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime, timedelta
import re
import api_helpers as api

# أعمدة صف الموظف في القائمة ونتيجة الحفظ وبطاقة الموظف
_EMP_SELECT = (
    "SELECT e.id, e.emp_name, e.job_title, e.id_number, "
    "e.start_date, e.nationality, e.emp_status, e.created_on, "
    "e.mobile, e.user_id, e.leave_month, "
    "jt.name AS job_title_name, "
    "nt.name AS nationality_name, "
    "es.name AS emp_status_name, "
    "COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
    "FROM employees e "
    "LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
    "LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
    "LEFT JOIN key_emp_status es ON es.id = e.emp_status "
    "LEFT JOIN auth_user au ON au.id = e.user_id "
)


def _employee_row(emp_id):
    rows = db.executesql(_EMP_SELECT + "WHERE e.id = %s", placeholders=[emp_id], as_dict=True)
    return rows[0] if rows else None


def _validate_employee_payload(data):
    errors = []
    emp_name = (data.emp_name or "").strip()
    mobile = (data.mobile or "").strip()
    id_number = (data.id_number or "").strip()

    if not emp_name:
        errors.append("اسم الموظف مطلوب")

    def valid_ref(table_name, value, message):
        if not value:
            errors.append(message)
            return None
        try:
            row_id = int(value)
        except (TypeError, ValueError):
            errors.append(message)
            return None
        if not db[table_name][row_id]:
            errors.append(message)
            return None
        return row_id

    job_title = valid_ref("key_job_titles", data.job_title, "الوظيفة مطلوبة")
    nationality = valid_ref("key_nationalities", data.nationality, "الجنسية مطلوبة")
    emp_status = valid_ref("key_emp_status", data.emp_status, "حالة الموظف مطلوبة")

    start_date = None
    if data.start_date:
        try:
            start_date = datetime.strptime(str(data.start_date), "%Y-%m-%d").date()
            if start_date > request.now.date():
                errors.append("تاريخ المباشرة لا يمكن أن يكون مستقبلياً")
        except Exception:
            errors.append("تاريخ المباشرة غير صحيح")

    if mobile and not re.match(r"^(05\d{8}|9665\d{8}|\+9665\d{8})$", mobile):
        errors.append("رقم الجوال غير صحيح")

    user_id = None
    if data.user_id:
        try:
            user_id = int(data.user_id)
        except (TypeError, ValueError):
            user_id = None
        if not user_id or not db.auth_user[user_id]:
            errors.append("حساب المستخدم غير صحيح")

    leave_month = None
    if data.leave_month not in (None, "", "0"):
        try:
            leave_month = int(data.leave_month)
        except (TypeError, ValueError):
            leave_month = 0
        if not 1 <= leave_month <= 12:
            errors.append("شهر استحقاق الإجازة غير صحيح")
            leave_month = None

    return errors, {
        "emp_name": emp_name,
        "job_title": job_title,
        "id_number": id_number,
        "start_date": start_date,
        "nationality": nationality,
        "emp_status": emp_status,
        "mobile": mobile,
        "user_id": user_id,
        "leave_month": leave_month,
    }


@can_access(7002)
def index():
    return dict()


@can_access(7002)
def get_lookups():
    job_titles = db(db.key_job_titles.id > 0).select(
        db.key_job_titles.id, db.key_job_titles.name,
        orderby=db.key_job_titles.name
    )
    nationalities = db(db.key_nationalities.id > 0).select(
        db.key_nationalities.id, db.key_nationalities.name,
        orderby=db.key_nationalities.name
    )
    statuses = db(db.key_emp_status.id > 0).select(
        db.key_emp_status.id, db.key_emp_status.name,
        orderby=db.key_emp_status.id
    )
    auth_users = db(db.auth_user.id > 0).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
    )
    return response.json(api.api_ok(data={
        "job_titles": job_titles,
        "nationalities": nationalities,
        "statuses": statuses,
        "auth_users": auth_users,
    }))


@can_access(7002)
def get_employees():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( e.emp_name LIKE %s OR e.id_number LIKE %s "
                "OR CAST(e.start_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])

    # فلتر حالة الموظف
    if ReqVar.emp_status and ReqVar.emp_status != '' and ReqVar.emp_status != '0':
        conditions.append("( e.emp_status = %s )")
        params.append(int(ReqVar.emp_status))

    # ترتيب
    allowed_sort_columns = {'id', 'emp_name', 'job_title', 'id_number', 'start_date', 'nationality', 'emp_status',
                            'leave_month'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    # ترقيم
    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = _EMP_SELECT + f"{where} ORDER BY e.{sc} {sa} NULLS LAST, e.id LIMIT %s OFFSET %s"
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM employees e "
        f"LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
        f"LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
        f"LEFT JOIN key_emp_status es ON es.id = e.emp_status "
        f"LEFT JOIN auth_user au ON au.id = e.user_id "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7002)
def new_employee():
    try:
        data = request.vars
        errors, clean_data = _validate_employee_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        nid = db.employees.insert(
            **clean_data
        )
        db.commit()
        return response.json(api.api_ok(data=_employee_row(nid) or {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7002)
def update_employee():
    try:
        data = request.vars
        row = db.employees[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        errors, clean_data = _validate_employee_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        row.update_record(**clean_data)
        db.commit()
        return response.json(api.api_ok(data=_employee_row(row.id) or {"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7002)
def delete_employee():
    try:
        row = db.employees[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ============================ بطاقة الموظف ============================
# حالة الموظف في نافذة واحدة عند اختياره. الأقسام المالية لمن يملك شاشتها فقط: الراتب لمن يملك
# المرتبات (7003) أو كشف الرواتب (7006)، والسلف لمن يملك السلف (7004). الباقي لمن يملك 7002.

_YEARS = ("سنة", "سنتان", "سنوات", "سنة")
_MONTHS_AR = ("شهر", "شهران", "أشهر", "شهراً")
_DAYS = ("يوم", "يومان", "أيام", "يوماً")


def _can(*codes):
    for code in codes:
        sc = screens_rules(code)
        if sc and sc.can_log_in:
            return True
    return False


def _ar_count(n, forms):
    """عدد ومعدوده بقواعد العربية: شهر، شهران، 3-10 أشهر، 11 فأكثر شهراً."""
    one, two, few, many = forms
    n = int(n)
    if n == 1:
        return one
    if n == 2:
        return two
    return "%d %s" % (n, few if 3 <= n <= 10 else many)


def _span(start, end):
    """الفرق بين تاريخين (سنوات، أشهر، أيام)."""
    y, m, d = end.year - start.year, end.month - start.month, end.day - start.day
    if d < 0:
        m -= 1
        d += (end.replace(day=1) - timedelta(days=1)).day
    if m < 0:
        y -= 1
        m += 12
    return y, m, d


def _months_between(start, end):
    return (end.year - start.year) * 12 + end.month - start.month - (1 if end.day < start.day else 0)


def _months_text(n):
    """عدد أشهر مقروء: ما زاد على سنة يُكتب سنوات وأشهراً."""
    years, months = divmod(int(n), 12)
    parts = [_ar_count(years, _YEARS) if years else "", _ar_count(months, _MONTHS_AR) if months else ""]
    return " و".join(p for p in parts if p) or "أقل من شهر"


def _month_name(month):
    try:
        return HR_MONTHS[int(month) - 1]
    except (TypeError, ValueError, IndexError):
        return ""


def _profile_leaves(emp, today, alerts):
    rows = db.executesql(
        "SELECT start_date, end_date, days_count, tickets_paid, allowance_paid FROM emp_leaves "
        "WHERE employee = %s AND start_date IS NOT NULL ORDER BY start_date DESC, id DESC",
        placeholders=[emp["id"]], as_dict=True)
    for r in rows:
        r["end_date"] = r["end_date"] or r["start_date"]
        r["tickets_paid"] = r["tickets_paid"] == "T"
        r["allowance_paid"] = r["allowance_paid"] == "T"
    current = next((r for r in rows if r["start_date"] <= today <= r["end_date"]), None)
    last = next((r for r in rows if r["start_date"] <= today), None)
    upcoming = next((r for r in reversed(rows) if r["start_date"] > today), None)
    if current:
        current = dict(current, days_left=(current["end_date"] - today).days + 1)

    due = None
    if emp["leave_month"]:
        month = int(emp["leave_month"])
        until = (month - today.month) % 12
        due = {"month": month, "name": _month_name(month), "months_until": until,
               "text": ("مستحقة هذا الشهر" if until == 0 else "مستحقة الشهر القادم" if until == 1
                        else "مستحقة بعد " + _ar_count(until, _MONTHS_AR))}
        if until == 0 and not current:
            alerts.append({"level": "warn", "text": "إجازته السنوية مستحقة هذا الشهر (%s)" % due["name"]})
    else:
        alerts.append({"level": "info", "text": "لم يُحدَّد شهر استحقاق الإجازة في بياناته"})

    # منذ متى لم يأخذ إجازة: من نهاية آخر إجازة، وإن لم توجد فمن تاريخ المباشرة
    ref = last["end_date"] if last else emp["start_date"]
    months_since = _months_between(ref, today) if ref and ref <= today else None
    if not current and months_since is not None and months_since >= 12:
        alerts.append({"level": "warn", "text": (
            "لم يأخذ إجازة منذ " if last else "لم يأخذ أي إجازة منذ مباشرته قبل ")
            + _months_text(months_since)})
    if current:
        # حضور مسجل خلال الإجازة الجارية: إما الإجازة مسجلة خطأ أو الحضور
        worked = db.executesql(
            "SELECT COUNT(DISTINCT att_date) FROM attendance WHERE employee = %s "
            "AND att_date BETWEEN %s AND %s AND check_in IS NOT NULL",
            placeholders=[emp["id"], current["start_date"], today])[0][0]
        if worked:
            alerts.append({"level": "warn", "text": "سجّل حضوراً في %s خلال إجازته الحالية (من %s)" % (
                _ar_count(worked, _DAYS), current["start_date"])})

    status = emp["emp_status_name"] or ""
    if current and status and status != "في إجازة":
        alerts.append({"level": "warn", "text": "في إجازة حتى %s حسب سجل الإجازات، وحالته «%s»" % (
            current["end_date"], status)})
    if not current and status == "في إجازة":
        alerts.append({"level": "warn", "text": "حالته «في إجازة» ولا توجد إجازة مسجلة تشمل اليوم"})

    this_year = [r for r in rows if r["start_date"].year == today.year]
    return {"due": due, "current": current, "last": last, "upcoming": upcoming,
            "months_since": months_since, "total_count": len(rows),
            "year_count": len(this_year), "year_days": sum(int(r["days_count"] or 0) for r in this_year)}


def _profile_salary(emp_id, alerts):
    basic_row = db.executesql("SELECT basic_salary FROM emp_salary WHERE employee = %s", placeholders=[emp_id])
    items = db.executesql(
        "SELECT ad.name, ad.ad_type, COALESCE(d.amount, 0) AS amount FROM emp_salary_detail d "
        "JOIN key_allowance_deduction ad ON ad.id = d.allowance_deduction "
        "WHERE d.employee = %s ORDER BY ad.ad_type, ad.name", placeholders=[emp_id], as_dict=True)
    basic = float(basic_row[0][0] or 0) if basic_row else None
    allowances = sum(float(i["amount"]) for i in items if i["ad_type"] == "بدل")
    deductions = sum(float(i["amount"]) for i in items if i["ad_type"] == "خصم")
    pays = db.executesql(
        "SELECT p.id, p.pay_month, p.pay_year, COALESCE(p.basic_salary, 0) AS basic_salary, "
        "COALESCE(p.net_salary, 0) AS net_salary, "
        "COALESCE((SELECT bool_or(pp.is_approved = 'T') FROM payroll_period pp "
        "          WHERE pp.pay_month = p.pay_month AND pp.pay_year = p.pay_year), FALSE) AS approved "
        "FROM payroll p WHERE p.employee = %s "
        "ORDER BY p.pay_year DESC, p.pay_month DESC, p.id DESC LIMIT 6",
        placeholders=[emp_id], as_dict=True)
    for p in pays:
        p["month_name"] = _month_name(p["pay_month"])
    last = None
    if pays:
        last = dict(pays[0], lines=db.executesql(
            "SELECT ad.name, ad.ad_type, COALESCE(pd.amount, 0) AS amount FROM payroll_detail pd "
            "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
            "WHERE pd.payroll_id = %s ORDER BY ad.ad_type, ad.name",
            placeholders=[pays[0]["id"]], as_dict=True))
    if basic is None:
        alerts.append({"level": "info", "text": "لا يوجد راتب أساسي مسجل له"})
    elif basic <= 0:
        alerts.append({"level": "info", "text": "الراتب الأساسي في هيكل راتبه صفر"})
    return {"basic": basic, "items": items, "allowances": allowances, "deductions": deductions,
            "total": (basic or 0) + allowances - deductions, "last": last, "history": pays}


def _profile_advances(emp_id, alerts):
    rows = db.executesql(
        "SELECT a.id, kt.name AS type_name, a.advance_date, COALESCE(a.amount, 0) AS amount, "
        "COALESCE(a.paid_amount, 0) AS paid, COALESCE(a.is_closed, 'F') = 'T' AS closed "
        "FROM emp_advances a LEFT JOIN key_advance_types kt ON kt.id = a.advance_type "
        "WHERE a.employee = %s ORDER BY a.advance_date DESC NULLS LAST, a.id DESC",
        placeholders=[emp_id], as_dict=True)
    open_rows = []
    for a in rows:
        a["remaining"] = round(float(a["amount"]) - float(a["paid"]), 2)
        if not a["closed"] and a["remaining"] > 0.005:
            open_rows.append(a)
    remaining = round(sum(a["remaining"] for a in open_rows), 2)
    # قسط «خصم سلفة» الشهري في هيكل راتبه؛ يُنسخ إلى المسير ويُخصم عند اعتماده
    installment = float(db.executesql(
        "SELECT COALESCE(SUM(d.amount), 0) FROM emp_salary_detail d "
        "JOIN key_allowance_deduction ad ON ad.id = d.allowance_deduction "
        "WHERE d.employee = %s AND ad.name = 'خصم سلفة' AND ad.ad_type = 'خصم'",
        placeholders=[emp_id])[0][0] or 0)
    if remaining > 0:
        alerts.append({"level": "info", "text": "عليه سلف متبقية بقيمة %.2f ريال" % remaining})
        if installment <= 0:
            alerts.append({"level": "warn", "text": "لا يوجد قسط «خصم سلفة» في هيكل راتبه، فلن تُخصم السلفة تلقائياً"})
    return {"open": open_rows, "remaining": remaining, "installment": installment,
            "months_left": int(-(-remaining // installment)) if installment > 0 and remaining > 0 else None,
            "closed_count": len(rows) - len(open_rows), "total_count": len(rows),
            "paid_total": round(sum(float(a["paid"]) for a in rows), 2)}


def _profile_attendance(emp, today, alerts):
    month_start = today.replace(day=1)
    days, hours, total = db.executesql(
        "SELECT COUNT(DISTINCT att_date) FILTER (WHERE att_date >= %s), "
        "COALESCE(SUM(shift_hours) FILTER (WHERE att_date >= %s), 0), COUNT(*) "
        "FROM attendance WHERE employee = %s",
        placeholders=[month_start, month_start, emp["id"]])[0]
    last = db.executesql(
        "SELECT att_date, check_in, check_out FROM attendance WHERE employee = %s "
        "ORDER BY att_date DESC, id DESC LIMIT 1", placeholders=[emp["id"]], as_dict=True)
    last = last[0] if last else None
    if not emp["user_id"]:
        alerts.append({"level": "info", "text": "غير مرتبط بحساب مستخدم، فلا يستطيع تسجيل حضوره"})
    return {"month_days": days, "month_hours": round(float(hours), 1), "total": total, "last": last,
            "present_now": bool(last and last["att_date"] == today and last["check_in"] and not last["check_out"])}


@can_access(7002)
def get_profile():
    """بطاقة الموظف: بياناته، مدة خدمته، الإجازات والحضور، والراتب والسلف لمن يملك صلاحيتها."""
    try:
        emp_id = int(request.vars.id or 0)
    except (TypeError, ValueError):
        emp_id = 0
    emp = _employee_row(emp_id) if emp_id else None
    if not emp:
        return response.json(api.api_error(mess="الموظف غير موجود"))
    try:
        today = request.now.date()
        alerts = []
        service = None
        if emp["start_date"] and emp["start_date"] <= today:
            y, m, d = _span(emp["start_date"], today)
            parts = [_ar_count(n, forms) for n, forms in ((y, _YEARS), (m, _MONTHS_AR), (d, _DAYS)) if n]
            service = {"years": y, "months": m, "days": d, "text": " و".join(parts) or "بدأ اليوم"}
        emp["leave_month_name"] = _month_name(emp["leave_month"])
        data = {
            "employee": emp,
            "service": service,
            "leaves": _profile_leaves(emp, today, alerts),
            "attendance": _profile_attendance(emp, today, alerts),
            "salary": _profile_salary(emp_id, alerts) if _can(7003, 7006) else None,
            "advances": _profile_advances(emp_id, alerts) if _can(7004) else None,
            "today": today,
        }
        order = {"warn": 0, "info": 1}
        data["alerts"] = sorted(alerts, key=lambda a: order.get(a["level"], 2))
        return response.json(api.api_ok(data=data))
    except Exception as e:
        return response.json(api.api_error(mess="تعذّر تحميل بطاقة الموظف: %s" % e))
