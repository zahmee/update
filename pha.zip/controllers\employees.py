# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime
import re
import api_helpers as api


def _validate_employee_payload(data):
    errors = []
    emp_name = (data.emp_name or "").strip()
    mobile = (data.mobile or "").strip()
    id_number = (data.id_number or "").strip()

    if not emp_name:
        errors.append("اسم الموظف مطلوب")

    def valid_ref(table_name, value, message):
        if not value:
            errors.append(message)
            return None
        try:
            row_id = int(value)
        except (TypeError, ValueError):
            errors.append(message)
            return None
        if not db[table_name][row_id]:
            errors.append(message)
            return None
        return row_id

    job_title = valid_ref("key_job_titles", data.job_title, "الوظيفة مطلوبة")
    nationality = valid_ref("key_nationalities", data.nationality, "الجنسية مطلوبة")
    emp_status = valid_ref("key_emp_status", data.emp_status, "حالة الموظف مطلوبة")

    start_date = None
    if data.start_date:
        try:
            start_date = datetime.strptime(str(data.start_date), "%Y-%m-%d").date()
            if start_date > request.now.date():
                errors.append("تاريخ المباشرة لا يمكن أن يكون مستقبلياً")
        except Exception:
            errors.append("تاريخ المباشرة غير صحيح")

    if mobile and not re.match(r"^(05\d{8}|9665\d{8}|\+9665\d{8})$", mobile):
        errors.append("رقم الجوال غير صحيح")

    user_id = None
    if data.user_id:
        try:
            user_id = int(data.user_id)
        except (TypeError, ValueError):
            user_id = None
        if not user_id or not db.auth_user[user_id]:
            errors.append("حساب المستخدم غير صحيح")

    return errors, {
        "emp_name": emp_name,
        "job_title": job_title,
        "id_number": id_number,
        "start_date": start_date,
        "nationality": nationality,
        "emp_status": emp_status,
        "mobile": mobile,
        "user_id": user_id,
    }


@can_access(7002)
def index():
    return dict()


@can_access(7002)
def get_lookups():
    job_titles = db(db.key_job_titles.id > 0).select(
        db.key_job_titles.id, db.key_job_titles.name,
        orderby=db.key_job_titles.name
    )
    nationalities = db(db.key_nationalities.id > 0).select(
        db.key_nationalities.id, db.key_nationalities.name,
        orderby=db.key_nationalities.name
    )
    statuses = db(db.key_emp_status.id > 0).select(
        db.key_emp_status.id, db.key_emp_status.name,
        orderby=db.key_emp_status.id
    )
    auth_users = db(db.auth_user.id > 0).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
    )
    return response.json(api.api_ok(data={
        "job_titles": job_titles,
        "nationalities": nationalities,
        "statuses": statuses,
        "auth_users": auth_users,
    }))


@can_access(7002)
def get_employees():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( e.emp_name LIKE %s OR e.id_number LIKE %s "
                "OR CAST(e.start_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])

    # فلتر حالة الموظف
    if ReqVar.emp_status and ReqVar.emp_status != '' and ReqVar.emp_status != '0':
        conditions.append("( e.emp_status = %s )")
        params.append(int(ReqVar.emp_status))

    # ترتيب
    allowed_sort_columns = {'id', 'emp_name', 'job_title', 'id_number', 'start_date', 'nationality', 'emp_status'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    # ترقيم
    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT e.id, e.emp_name, e.job_title, e.id_number, "
        f"e.start_date, e.nationality, e.emp_status, e.created_on, "
        f"e.mobile, e.user_id, "
        f"jt.name AS job_title_name, "
        f"nt.name AS nationality_name, "
        f"es.name AS emp_status_name, "
        f"COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
        f"FROM employees e "
        f"LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
        f"LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
        f"LEFT JOIN key_emp_status es ON es.id = e.emp_status "
        f"LEFT JOIN auth_user au ON au.id = e.user_id "
        f"{where} ORDER BY e.{sc} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM employees e "
        f"LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
        f"LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
        f"LEFT JOIN key_emp_status es ON es.id = e.emp_status "
        f"LEFT JOIN auth_user au ON au.id = e.user_id "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7002)
def new_employee():
    try:
        data = request.vars
        errors, clean_data = _validate_employee_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        nid = db.employees.insert(
            **clean_data
        )
        db.commit()

        inserted = db.executesql(
            "SELECT e.id, e.emp_name, e.job_title, e.id_number, "
            "e.start_date, e.nationality, e.emp_status, e.created_on, "
            "e.mobile, e.user_id, "
            "jt.name AS job_title_name, "
            "nt.name AS nationality_name, "
            "es.name AS emp_status_name, "
            "COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
            "FROM employees e "
            "LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
            "LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
            "LEFT JOIN key_emp_status es ON es.id = e.emp_status "
            "LEFT JOIN auth_user au ON au.id = e.user_id "
            "WHERE e.id = %s",
            placeholders=[nid], as_dict=True
        )
        return response.json(api.api_ok(data=inserted[0] if inserted else {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7002)
def update_employee():
    try:
        data = request.vars
        row = db.employees[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        errors, clean_data = _validate_employee_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        row.update_record(**clean_data)
        db.commit()

        updated = db.executesql(
            "SELECT e.id, e.emp_name, e.job_title, e.id_number, "
            "e.start_date, e.nationality, e.emp_status, e.created_on, "
            "e.mobile, e.user_id, "
            "jt.name AS job_title_name, "
            "nt.name AS nationality_name, "
            "es.name AS emp_status_name, "
            "COALESCE(au.first_name || ' ' || au.last_name, '') AS user_name "
            "FROM employees e "
            "LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
            "LEFT JOIN key_nationalities nt ON nt.id = e.nationality "
            "LEFT JOIN key_emp_status es ON es.id = e.emp_status "
            "LEFT JOIN auth_user au ON au.id = e.user_id "
            "WHERE e.id = %s",
            placeholders=[data.id], as_dict=True
        )
        return response.json(api.api_ok(data=updated[0] if updated else {"id": data.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7002)
def delete_employee():
    try:
        row = db.employees[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
