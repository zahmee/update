# -*- coding: utf-8 -*-
"""Isolated customer maintenance/authorization regressions; no app models or DB.

Run: python -B scripts/test_customer_maintenance.py
"""
import ast
import json
import sys
import unittest
from datetime import datetime, date
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP.parents[1]))
sys.path.insert(0, str(APP / "modules"))
from gluon import DAL, Field, HTTP, URL, current, redirect
from gluon.globals import Request, Response, Session
from gluon.storage import Storage, List
from gluon.tools import Auth
import api_helpers as api
import customer_maintenance as maintenance

NOW = datetime(2026, 9, 22, 12)


def record(**changes):
    row = dict(id=1, name="  Alpha  Client ", administrator_name="  Lead  Person ", mobile="٠٥٠٠٠٠٠٠٠١",
               tel=["001", " 002 ", "001"], address=" First  street ", note=None, cust_type=10, modified_on=NOW)
    row.update(changes)
    return row


class FormattingTests(unittest.TestCase):
    def changes(self, row, operation, other=()):
        return maintenance.proposed_changes(row, operation, maintenance.indexes([row] + list(other)))

    def test_names_preserve_case_and_missing_values(self):
        result = self.changes(record(), "names")
        self.assertEqual([item["after"] for item in result], ["Alpha Client", "Lead Person"])
        self.assertEqual(self.changes(record(name=None, administrator_name="   "), "names"), [])

    def test_mobile_converts_only_unambiguous_valid_local_numbers(self):
        for value in ("٠٥٠٠٠٠٠٠٠١", "۰۵۰۰۰۰۰۰۰۱", " (050) 000-0001 "):
            self.assertEqual(self.changes(record(mobile=value), "mobile")[0]["after"], "0500000001")
        for value in (None, "", "0000000000", "500000001", "+966500000001", "0500000001 ext2"):
            self.assertEqual(self.changes(record(mobile=value), "mobile"), [])

    def test_formatted_mobile_collision_is_reported_and_never_proposed(self):
        first, second = record(), record(id=2, mobile="0500000001")
        self.assertEqual(self.changes(first, "mobile", [second]), [])
        result, plan = maintenance.preview([first, second], "contacts", 1)
        self.assertEqual(len(result["records"]), 2)
        self.assertIsNone(plan)
        self.assertTrue(any("متطابق" in text for text in result["records"][1]["issues"]))

    def test_list_phones_preserve_zeroes_and_internal_spacing(self):
        result = self.changes(record(tel=[" 001|002 ", "001", "+966 003", "+966003"]), "phones")
        self.assertEqual(result[0]["after"], ["001", "002", "+966 003", "+966003"])
        self.assertEqual(self.changes(record(tel=None), "phones"), [])

    def test_text_paragraphs_and_repeated_lines_are_preserved(self):
        result = self.changes(record(address=" A  B \r\n\r\n C | C "), "texts")
        self.assertEqual(result[0]["after"], "A B\n\nC\nC")

    def test_formatting_is_idempotent_and_never_writes_type_or_money(self):
        for operation in maintenance.OPERATIONS:
            row = record(total=123.45, amount=-10)
            with self.subTest(operation=operation["key"]):
                changes = self.changes(row, operation["key"])
                self.assertTrue(all(change["field"] in operation["fields"] for change in changes))
                row.update({change["field"]: change["after"] for change in changes})
                self.assertEqual(self.changes(row, operation["key"]), [])
                self.assertEqual((row["cust_type"], row["total"], row["amount"]), (10, 123.45, -10))

    def test_missing_type_and_duplicate_names_are_read_only_findings(self):
        rows = [record(name=" ALPHA Client ", cust_type=None), record(id=2, name="alpha client", cust_type=98)]
        for key in ("duplicates", "classification"):
            result, plan = maintenance.preview(rows, key, 1)
            self.assertEqual(len(result["records"]), 2)
            self.assertTrue(all(not row["changes"] for row in result["records"]))
            self.assertIsNone(plan)
        self.assertIsNone(rows[0]["cust_type"])

    def test_batch_limit_is_explicit_and_reports_are_complete(self):
        rows = [record(id=index+1, cust_type=None) for index in range(maintenance.MAX_BATCH + 2)]
        result, plan = maintenance.preview(rows, "names", 1)
        self.assertEqual(len(result["records"]), maintenance.MAX_BATCH)
        self.assertEqual(result["total"], len(rows))
        self.assertTrue(result["truncated"])
        report, plan = maintenance.preview(rows, "classification", 1)
        self.assertEqual(len(report["records"]), len(rows))
        self.assertIsNone(plan)

    def test_account_and_activity_states_are_explicit(self):
        rows = [record(id=index) for index in range(1, 6)]
        accounts = [dict(id=1, balance=100, invoice_count=2, last_purchase="2026-09-01"),
                    dict(id=2, balance=-30, invoice_count=1, last_purchase="2025-01-01"),
                    dict(id=3, balance=0, invoice_count=0),
                    dict(id=4, balance=0, invoice_count=1, last_purchase="2027-01-01"),
                    dict(id=5, balance=0, invoice_count=1, last_purchase=None)]
        result = maintenance.overview(rows, accounts, date(2026, 9, 22))
        self.assertEqual([row["balance_state"] for row in result["records"]], ["debit", "credit", "zero", "zero", "zero"])
        self.assertEqual([row["activity"] for row in result["records"]], ["recent", "inactive", "never", "unknown", "unknown"])
        self.assertEqual((result["summary"]["debit_amount"], result["summary"]["credit_amount"]), (100, 30))


class DatabaseFixture(unittest.TestCase):
    def setUp(self):
        self.db = DAL("sqlite:memory")
        self.addCleanup(self.db.close)
        self.db.define_table("customers", Field("name"), Field("administrator_name"), Field("mobile", unique=True),
                             Field("tel", "list:string"), Field("address", "text"), Field("note", "text"),
                             Field("cust_type", "integer"), Field("modified_on", "datetime", default=NOW,
                             update=lambda: datetime(2026, 9, 22, 13)), Field("total", "double"),
                             Field("amount", "double"), Field("payed", "double"), Field("returns", "double"))
        for row in (record(), record(id=2, name=" Beta  Client ", mobile="0500000002", cust_type=None)):
            row.pop("id")
            self.db.customers.insert(**row, total=100, amount=-10, payed=110, returns=0)
        self.db.commit()

    def rows(self):
        return maintenance.load_rows(self.db)

    def plan(self, operation="names"):
        return maintenance.preview(self.rows(), operation, 1)[1]


class DatabaseTests(DatabaseFixture):
    def test_selective_write_preserves_other_customer_and_financial_data(self):
        before = self.db.customers[1].as_dict()
        plan = self.plan()
        result = maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db.commit()
        self.assertEqual(result["fields"], 2)
        self.assertEqual(self.db.customers[1].name, "Alpha Client")
        self.assertEqual(self.db.customers[2].name, " Beta  Client ")
        for field in ("total", "amount", "payed", "returns", "cust_type", "mobile", "tel", "note"):
            self.assertEqual(self.db.customers[1][field], before[field])

    def test_list_phone_update_round_trips_through_dal(self):
        plan = self.plan("phones")
        maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db.commit()
        self.assertEqual(self.db.customers[1].tel, ["001", "002"])

    def test_mobile_update_preserves_unique_constraint(self):
        plan = self.plan("mobile")
        maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db.commit()
        self.assertEqual(self.db.customers[1].mobile, "0500000001")

    def test_collision_introduced_by_unselected_customer_blocks_apply(self):
        plan = self.plan("mobile")
        self.db(self.db.customers.id == 2).update(mobile="0500000001")
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db.rollback()
        self.assertEqual(self.db.customers[1].mobile, "٠٥٠٠٠٠٠٠٠١")

    def test_one_stale_row_blocks_all_changes(self):
        plan = self.plan()
        self.db(self.db.customers.id == 2).update(address="changed elsewhere")
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [1, 2], 1)
        self.db.rollback()
        self.assertEqual(self.db.customers[1].name, "  Alpha  Client ")

    def test_deleted_customer_or_changed_format_rules_require_new_preview(self):
        plan = self.plan()
        with patch.object(maintenance, "clean_name", return_value="changed rule"):
            with self.assertRaises(maintenance.MaintenanceError):
                maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db(self.db.customers.id == 1).delete()
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [1], 1)

    def test_invalid_token_user_age_and_selection_are_rejected(self):
        plan = self.plan()
        cases = [(None, plan["token"], [1], 1, None), (plan, "bad", [1], 1, None),
                 (plan, "غير صالح", [1], 1, None),
                 (plan, plan["token"], [1], 2, None),
                 (plan, plan["token"], [1], 1, plan["created_at"] + maintenance.PREVIEW_TTL + 1)]
        cases += [(plan, plan["token"], ids, 1, None) for ids in ([], [1, 1], [True], ["1"], [1.0], [0], [999], "1")]
        for candidate, token, ids, user, now in cases:
            with self.subTest(ids=ids), self.assertRaises(maintenance.MaintenanceError):
                maintenance.apply(self.db, candidate, token, ids, user, now)
        self.assertEqual(self.db.customers[1].name, "  Alpha  Client ")


class LegacyPhoneTests(DatabaseFixture):
    """A plain number in the list:string tel column (legacy data) used to be read as
    |0500550300| -> 50055030, and its compare-and-set never matched, so any batch
    containing such a customer was rejected with nothing saved."""

    def setUp(self):
        super().setUp()
        self.db.executesql("UPDATE customers SET tel = '0500550300', address = ' Second  street ' WHERE id = 2")
        self.db.commit()

    def test_legacy_value_is_read_whole(self):
        self.assertEqual(maintenance.decode_phones("0500550300"), ["0500550300"])
        self.assertEqual(maintenance.decode_phones("|001|a||b|"), ["001", "a|b"])
        self.assertEqual((maintenance.decode_phones("||"), maintenance.decode_phones(None)), ([], None))
        self.assertEqual(self.rows()[1]["tel"], ["0500550300"])

    def test_legacy_value_no_longer_blocks_other_fields(self):
        plan = self.plan("texts")
        result = maintenance.apply(self.db, plan, plan["token"], [1, 2], 1)
        self.db.commit()
        self.assertEqual(result["updated"], 2)
        self.assertEqual(self.db.customers[2].address, "Second street")
        self.assertEqual(self.db.executesql("SELECT tel FROM customers WHERE id = 2")[0][0], "0500550300")

    def test_phones_tool_rewrites_legacy_value_as_list(self):
        change = maintenance.preview(self.rows(), "phones", 1)[0]["records"][1]["changes"][0]
        self.assertEqual((change["before"], change["after"]), ("0500550300", ["0500550300"]))
        plan = self.plan("phones")
        maintenance.apply(self.db, plan, plan["token"], [2], 1)
        self.db.commit()
        self.assertEqual(self.db.executesql("SELECT tel FROM customers WHERE id = 2")[0][0], "|0500550300|")
        self.assertNotIn(2, [row["id"] for row in maintenance.preview(self.rows(), "phones", 1)[0]["records"]])

    def test_raw_tel_change_after_preview_still_blocks(self):
        plan = self.plan("texts")
        self.db.executesql("UPDATE customers SET tel = '0511111111' WHERE id = 2")
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [2], 1)
        self.db.rollback()
        self.assertEqual(self.db.customers[2].address, " Second  street ")


class EndpointTests(DatabaseFixture):
    def setUp(self):
        super().setUp()
        self.request = Request({"request_method": "POST", "http_host": "localhost"})
        self.request.application = "asbab5"
        self.request.controller = "customer_services_api"
        self.request.function = "preview"
        self.request.args = List()
        self.request.now = NOW
        self.response, self.session = Response(), Session()
        self.session.auth = Storage(user=Storage(id=1, first_name="Fixture"), last_visit=NOW,
                                    expiration=3600, hmac_key="isolated-customer-signing-key")
        current.request, current.response, current.session = self.request, self.response, self.session
        current.T = lambda text: text
        self.auth = Auth(self.db)
        self.auth.define_tables(username=False, signature=False)
        self.db.auth_user.insert(first_name="Fixture", email="fixture@example.invalid")
        self.db.define_table("screens", Field("screen_code", "integer"))
        self.db.define_table("screens_rules", Field("screens", "integer"), Field("to_user", "integer"),
                             Field("can_log_in", "boolean"), Field("can_edit", "boolean"))
        self.db.screens.insert(screen_code=1001)
        self.db.screens_rules.insert(screens=1, to_user=1, can_log_in=True, can_edit=True)
        self.db.commit()
        self.role = "admin"
        self.auth.has_membership = lambda group_id=None, role=None: bool(self.auth.user and self.role == (role or group_id))
        self.env = dict(auth=self.auth, request=self.request, response=self.response, session=self.session,
                        db=self.db, URL=URL, HTTP=HTTP, redirect=redirect)
        model = ast.parse((APP / "models/db_4_access.py").read_text(encoding="utf-8-sig"))
        access = next(node for node in model.body if isinstance(node, ast.FunctionDef) and node.name == "can_access")
        exec(compile(ast.Module(body=[access], type_ignores=[]), "access", "exec"), self.env)
        exec(compile((APP / "controllers/customer_services_api.py").read_text(encoding="utf-8-sig"), "customer_services_api", "exec"), self.env)

    def call(self, name, body=None, method="POST", signed=True):
        self.request.function = name
        self.request.env.request_method = method
        self.response.status = 200
        self.request._post_vars = Storage(body or {})
        self.request._get_vars = Storage()
        if signed:
            url = URL("customer_services_api", name, user_signature=True)
            self.request._get_vars = Storage({key: values[0] for key, values in parse_qs(urlsplit(url).query).items()})
        self.request._vars = None
        return json.loads(self.env[name]())

    def token(self):
        return self.call("preview", dict(operation="names"))["data"]["token"]

    def test_overview_and_preview_do_not_change_customer_records(self):
        before = self.rows()
        with patch.object(maintenance, "account_snapshot", return_value=[]):
            self.assertTrue(self.call("overview", method="GET")["ok"])
        self.assertTrue(self.call("preview", dict(operation="names"))["ok"])
        self.assertEqual(self.rows(), before)
        self.assertEqual(self.response.headers["Cache-Control"], "private, no-store")

    def test_post_and_session_signature_are_required(self):
        for endpoint in ("preview", "apply"):
            for method, signed, status in (("GET", True, 405), ("POST", False, 403)):
                with self.subTest(endpoint=endpoint, method=method):
                    self.assertFalse(self.call(endpoint, method=method, signed=signed)["ok"])
                    self.assertEqual(self.response.status, status)

    def test_no_screen_access_and_anonymous_are_blocked(self):
        self.role = "user"
        self.db(self.db.screens_rules.id > 0).update(can_log_in=False)
        self.db.commit()
        for endpoint in ("overview", "preview", "apply"):
            with self.subTest(endpoint=endpoint), self.assertRaises(HTTP):
                self.call(endpoint)
        self.auth.user = None
        with self.assertRaises(HTTP):
            self.call("overview", signed=False)

    def test_view_permission_does_not_grant_edit_or_other_services(self):
        self.role = "user"
        self.db(self.db.screens_rules.id > 0).update(can_edit=False)
        self.db.commit()
        with patch.object(maintenance, "account_snapshot", return_value=[]):
            permissions = self.call("overview", method="GET")["data"]["permissions"]
        self.assertFalse(any(permissions.values()))
        token = self.token()
        self.assertFalse(self.call("apply", dict(token=token, ids="[1]"))["ok"])
        self.assertEqual(self.response.status, 403)

    def test_authorized_editor_can_save_only_server_proposals_and_audit(self):
        self.role = "user"
        token = self.token()
        result = self.call("apply", dict(token=token, ids="[1]", after="FORGED", operation="mobile"))
        self.assertTrue(result["ok"])
        self.assertEqual(self.db.customers[1].name, "Alpha Client")
        self.assertEqual(self.db.customers[1].mobile, "٠٥٠٠٠٠٠٠٠١")
        self.assertIsNone(self.session.customer_maintenance_plan)
        self.assertEqual(self.db(self.db.auth_event.origin == "customer_maintenance").count(), 1)
        self.assertFalse(self.call("apply", dict(token=token, ids="[1]"))["ok"])
        self.assertEqual(self.response.status, 409)

    def test_audit_failure_rolls_back_entire_batch(self):
        token, before = self.token(), self.rows()
        with patch.object(self.auth, "log_event", side_effect=RuntimeError("fixture failure")):
            with self.assertLogs("customer_maintenance", level="ERROR"):
                result = self.call("apply", dict(token=token, ids="[1,2]"))
        self.assertFalse(result["ok"])
        self.assertEqual(self.response.status, 500)
        self.assertEqual(self.rows(), before)
        self.assertNotIn("fixture failure", result["mess"])

    def test_stale_preview_is_consumed_without_partial_updates(self):
        token = self.token()
        self.db(self.db.customers.id == 2).update(note="another change")
        self.db.commit()
        self.assertFalse(self.call("apply", dict(token=token, ids="[1,2]"))["ok"])
        self.assertEqual(self.response.status, 409)
        self.assertIsNone(self.session.customer_maintenance_plan)
        self.assertEqual(self.db.customers[1].name, "  Alpha  Client ")

    def test_unknown_operation_and_other_session_preview_are_rejected(self):
        self.assertFalse(self.call("preview", dict(operation="zero_balances"))["ok"])
        token = self.token()
        self.session.customer_maintenance_plan = None
        self.assertFalse(self.call("apply", dict(token=token, ids="[1]"))["ok"])
        self.assertEqual(self.response.status, 409)


if __name__ == "__main__":
    unittest.main(verbosity=2)
