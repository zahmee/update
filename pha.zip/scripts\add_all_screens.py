# -*- coding: utf-8 -*-
"""
إضافة جميع الشاشات المطلوبة لنظام الصلاحيات
"""

all_screens = [
    # العملاء (1000)
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    {"systems": 1, "name": "العملاء - تسوية حسابات", "screen_code": 1005},
    {"systems": 1, "name": "العملاء - تقرير حالة العملاء", "screen_code": 1006},

    # الموردين (2000)
    {"systems": 1, "name": "الموردين - استعراض الموردين", "screen_code": 2001},
    {"systems": 1, "name": "الموردين - اضافة مورد جديد", "screen_code": 2002},
    {"systems": 1, "name": "الموردين - تعديل بيانات مورد", "screen_code": 2003},
    {"systems": 1, "name": "الموردين - حذف مورد", "screen_code": 2004},
    {"systems": 1, "name": "الموردين - اقفال مورد", "screen_code": 2005},
    {"systems": 1, "name": "الموردين - حركة مشتريات المورد", "screen_code": 2006},
    {"systems": 1, "name": "الموردين - فواتير مورد محدد", "screen_code": 2007},
    {"systems": 1, "name": "الموردين - طباعة مرتجع فاتورة", "screen_code": 2008},
    {"systems": 1, "name": "الموردين - اعتماد مرتجع فاتورة", "screen_code": 2009},
    {"systems": 1, "name": "الموردين - اضافة فاتورة جديدة", "screen_code": 2010},
    {"systems": 1, "name": "الموردين - استعراض فواتير التوريد", "screen_code": 2011},
    {"systems": 1, "name": "الموردين - طباعة الأصناف المدخلة", "screen_code": 2012},
    {"systems": 1, "name": "الموردين - طباعة الباركود للفاتورة", "screen_code": 2013},
    {"systems": 1, "name": "الموردين - مرتجع فاتورة جديد", "screen_code": 2014},
    {"systems": 1, "name": "الموردين - طلبات الشراء", "screen_code": 2015},
    {"systems": 1, "name": "الموردين - تعديل طلب شراء", "screen_code": 2016},
    {"systems": 1, "name": "الموردين - حذف طلب شراء", "screen_code": 2017},
    {"systems": 1, "name": "الموردين - كشف حساب مورد", "screen_code": 2106},
    {"systems": 1, "name": "الموردين - سدادات الموردين", "screen_code": 2107},
    {"systems": 1, "name": "الموردين - ارصدة الموردين", "screen_code": 2108},
    {"systems": 1, "name": "الموردين - مطابقات كشف الحساب", "screen_code": 2109},
    {"systems": 1, "name": "الموردين - تقرير الموردين", "screen_code": 2110},
    {"systems": 1, "name": "الموردين - تقرير المشتريات", "screen_code": 2111},
    {"systems": 1, "name": "الموردين - مرتجع التوريد", "screen_code": 2112},

    # الأصناف (3000)
    {"systems": 1, "name": "الاصناف - التصنيف الرئيسي", "screen_code": 3001},
    {"systems": 1, "name": "الاصناف - حركة الصنف", "screen_code": 3002},
    {"systems": 1, "name": "الاصناف - سجل المبيعات", "screen_code": 3003},
    {"systems": 1, "name": "الاصناف - ادخال الاصناف حسب الفواتير", "screen_code": 3004},
    {"systems": 1, "name": "الاصناف - استعلام الاصناف", "screen_code": 3005},
    {"systems": 1, "name": "الاصناف - تفاصيل الاصناف", "screen_code": 3006},
    {"systems": 1, "name": "الاصناف - عمليات على الاصناف", "screen_code": 3007},
    {"systems": 1, "name": "الاصناف - دمج صنفين مع بعضها", "screen_code": 3008},
    {"systems": 1, "name": "الاصناف - تعديل سعر الصنف", "screen_code": 3009},
    {"systems": 1, "name": "الاصناف - اعادة الطلب", "screen_code": 3010},
    {"systems": 1, "name": "الاصناف - الاصناف ذات الاعداد بالسالب", "screen_code": 3011},
    {"systems": 1, "name": "الاصناف - الاصناف غير المتحركة", "screen_code": 3012},
    {"systems": 1, "name": "الاصناف - تقرير الأصناف المقاربة على الانتهاء", "screen_code": 3013},
    {"systems": 1, "name": "الاصناف - تحويل الباركود الدولي", "screen_code": 3014},

    # المبيعات (4000)
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض فاتورة", "screen_code": 4003},
    {"systems": 1, "name": "المبيعات - استعراض فواتير المبيعات", "screen_code": 4004},
    {"systems": 1, "name": "المبيعات - استعراض فواتير المرتجع", "screen_code": 4005},
    {"systems": 1, "name": "المبيعات - حذف فاتورة", "screen_code": 4006},

    # الصندوق (5000)
    {"systems": 1, "name": "الصندوق - مراقبة مصروفات الصندوق", "screen_code": 5001},
    {"systems": 1, "name": "الصندوق - اعتماد حركات الصندوق", "screen_code": 5002},

    # طلبات الأصناف (6000)
    {"systems": 1, "name": "طلبات الأصناف الجديدة", "screen_code": 6001},

    # شؤون الموظفين (7000)
    {"systems": 1, "name": "الحضور والانصراف", "screen_code": 7001},
    {"systems": 1, "name": "استعراض الموظفين", "screen_code": 7002},
    {"systems": 1, "name": "المرتبات", "screen_code": 7003},
    {"systems": 1, "name": "السلف", "screen_code": 7004},
    {"systems": 1, "name": "الإجازات", "screen_code": 7005},
    {"systems": 1, "name": "كشف الرواتب", "screen_code": 7006},
    {"systems": 1, "name": "ملفاتي", "screen_code": 7007},

    # إقفال الفترات (8000)
    {"systems": 1, "name": "إقفال الفترات", "screen_code": 8001},

    # تقارير المبيعات (8100)
    {"systems": 1, "name": "تقارير المبيعات - التقرير 1", "screen_code": 8101},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 2", "screen_code": 8102},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 3", "screen_code": 8103},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 4", "screen_code": 8104},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 5", "screen_code": 8105},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 6", "screen_code": 8106},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 7", "screen_code": 8107},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 8", "screen_code": 8108},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 10", "screen_code": 8110},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 11", "screen_code": 8111},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 12", "screen_code": 8112},

    # تقارير الأصناف (8200)
    {"systems": 1, "name": "تقارير الأصناف - التقرير 1", "screen_code": 8201},
    {"systems": 1, "name": "تقارير الأصناف - تقرير التجهيز", "screen_code": 8202},

    # الضريبة (9000)
    {"systems": 1, "name": "الضريبة - التقرير الرئيسي", "screen_code": 9001},
    {"systems": 1, "name": "الضريبة - تقرير 11", "screen_code": 9002},
    {"systems": 1, "name": "الضريبة - تقرير 12", "screen_code": 9003},
    {"systems": 1, "name": "الضريبة - تقرير 13", "screen_code": 9004},

    # زاتكا (9100)
    {"systems": 1, "name": "زاتكا - حالة الربط", "screen_code": 9101},
    {"systems": 1, "name": "زاتكا - توليد CSR وطلب CSID", "screen_code": 9102},
    {"systems": 1, "name": "زاتكا - التسجيل الإنتاجي", "screen_code": 9103},

    # APIs إضافية (9200)
    {"systems": 1, "name": "API - lookup عام", "screen_code": 9201},
    {"systems": 1, "name": "API - lookup موردين", "screen_code": 9202},
    {"systems": 1, "name": "API - lookup عملاء", "screen_code": 9203},
    {"systems": 1, "name": "API - lookup أصناف", "screen_code": 9204},

    # إعدادات (9300)
    {"systems": 1, "name": "الإعدادات العامة", "screen_code": 9301},
    {"systems": 1, "name": "إدارة المستخدمين والصلاحيات", "screen_code": 9302},
]

added = 0
skipped = 0
for s in all_screens:
    exists = db(db.screens.screen_code == s["screen_code"]).select().first()
    if not exists:
        db.screens.insert(systems=s["systems"], name=s["name"], screen_code=s["screen_code"])
        added += 1
        added += 1
    else:
        skipped += 1

db.commit()
with open('scripts/add_all_screens_log.txt', 'w', encoding='utf-8') as f:
    f.write(f"Done. Added: {added} Skipped: {skipped}\n")
