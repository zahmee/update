# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الصلاحيات والشاشات ودوال التحقق (Access Control)
# ===========================================================================================

# ===========================================================================================
#  جدول الشاشات
db.define_table(
    "screens",
    Field("systems", "reference systems", default=1, label="النظام"),
    Field("name", length=270, label="اسم الشاشة"),
    Field("screen_code", "integer", label="كود الشاشة"),
    format="%(screen_code)s - %(name)s",
)

# ===========================================================================================
#  جدول صلاحيات الشاشات
db.define_table(
    "screens_rules",
    Field("to_user", "reference auth_user", label="المستخدم"),
    Field("screens", "reference screens", label="الشاشة"),
    Field("can_log_in", "boolean", default=False, label="الدخول"),
    Field("can_add", "boolean", default=False, label="الاضافة"),
    Field("can_edit", "boolean", default=False, label="التعديل"),
    Field("can_delete", "boolean", default=False, label="الحذف"),
)
# ===========================================================================================
# ===========================================================================================
# ===========================================================================================
#  جدول معلومات الجهه
db.define_table(
    "important_info",
    Field(
        "name",
        length=370,
        label="الاسم ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "vat",
        length=100,
        label="الرقم الضريبي ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "tel",
        length=25,
        label="رقم الهاتف الارضي ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "mobile",
        length=25,
        label="رقم الجوال / الواتس آب ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "address",
        "text",
        default=" ",
        label="العنوان",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "msg1",
        "text",
        default=" ",
        label="رسالة للعميل",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "msg2",
        "text",
        default=" ",
        label="رسالة آخر الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "logo",
        "upload",
        autodelete=True,
        label="الشعار",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("change_count", "boolean", label="تعديل الكمية بالسعر"),
    Field("change_count_amount", "double", default=0, label="مبلغ فاتورة تعديل الكمية"),
    # السماح بالبيع بما يتجاوز الرصيد المتاح (ينتج أرصدة سالبة). الأصل: ممنوع.
    Field("allow_negative_stock", "boolean", default=False,
          label="السماح بالبيع بدون رصيد"),
    # حارس الكمية في سطر الفاتورة (ضد إدخال رقم الصنف في خانة العدد):
    #   حتى confirm_line_qty        -> يمر بلا اعتراض
    #   بينها وبين max_line_qty     -> يطلب تأكيد الكاشير
    #   أكبر من max_line_qty        -> يُرفض
    Field("confirm_line_qty", "double", default=100,
          label="الكمية التي تستدعي تأكيداً"),
    Field("max_line_qty", "double", default=1000,
          label="أقصى كمية في سطر الفاتورة"),
    # إجمالي الفاتورة الذي يستدعي تنبيهاً (تأكيد فقط — لا يمنع الحفظ)
    Field("invoice_warn_amount", "double", default=3000,
          label="مبلغ الفاتورة الذي يستدعي تنبيهاً"),
)
# ===========================================================================================
# ===========================================================================================


def can_access(*argument):
    # تحقق كسول (وقت الاستدعاء لا وقت تحميل الملف) — حتى لا يُحوَّل الزائر غير المسجل
    # أثناء تنفيذ المُزخرفات عند تحميل وحدة التحكم، فتبقى الدوال العامة في الملف نفسه
    # (مثل it_prt) متاحة دون تسجيل دخول. النتيجة للدوال المحمية لم تتغير: not_allow.
    def decorator(function):
        def wrapper(*args, **kwargs):
            if not auth.user or not auth.user.first_name:
                return redirect(URL("default", "not_allow"))
            if auth.has_membership("admin"):
                return function(*args, **kwargs)
            for code in argument:
                screen_row = db(db.screens.screen_code == code).select().first()
                if screen_row:
                    acc = db(
                        (db.screens_rules.screens == screen_row.id)
                        & (db.screens_rules.to_user == auth.user.id)
                        & (db.screens_rules.can_log_in == True)
                    ).select().first()
                    if acc:
                        return function(*args, **kwargs)
            return redirect(URL("default", "not_allow"))

        return wrapper

    return decorator


def screens_rules(sc):
    if not auth.user:
        return None
    # السماح لـ admin دائماً
    if auth.has_membership("admin"):
        class AdminScreen:
            can_log_in = True
            can_add = True
            can_edit = True
            can_delete = True
        return AdminScreen()
    screen_code = db(db.screens.screen_code == sc).select().first()
    if not screen_code:
        return None
    acc = (
        db(
            (db.screens_rules.screens == screen_code.id)
            & (db.screens_rules.to_user == auth.user.id)
        )
        .select()
        .first()
    )
    return acc


def has_any_screen(*codes):
    """تحقق إذا كان المستخدم لديه صلاحية دخول لأي شاشة من القائمة المعطاة"""
    if not auth.user:
        return False
    if auth.has_membership("admin"):
        return True
    screen_rows = db(db.screens.screen_code.belongs(list(codes))).select(db.screens.id)
    if not screen_rows:
        return False
    id_list = [r.id for r in screen_rows]
    rule = db(
        (db.screens_rules.screens.belongs(id_list))
        & (db.screens_rules.to_user == auth.user.id)
        & (db.screens_rules.can_log_in == True)
    ).select(db.screens_rules.id, limitby=(0, 1)).first()
    return rule is not None
