var API_BASE = window.location.href + '/../../payroll/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            SortBy: 'pay_year',
            sortAsc: false,
            year_filter: '0',
            status_filter: 'all',
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_form: { pay_month: '', pay_year: '' },
        loading: false,
        months: [
            { val: 1, name: 'يناير (1)' },
            { val: 2, name: 'فبراير (2)' },
            { val: 3, name: 'مارس (3)' },
            { val: 4, name: 'أبريل (4)' },
            { val: 5, name: 'مايو (5)' },
            { val: 6, name: 'يونيو (6)' },
            { val: 7, name: 'يوليو (7)' },
            { val: 8, name: 'أغسطس (8)' },
            { val: 9, name: 'سبتمبر (9)' },
            { val: 10, name: 'أكتوبر (10)' },
            { val: 11, name: 'نوفمبر (11)' },
            { val: 12, name: 'ديسمبر (12)' },
        ],
        years: (function () {
            var arr = [];
            var cur = new Date().getFullYear();
            for (var y = cur - 3; y <= cur + 2; y++) arr.push(y);
            return arr;
        })(),
    },
    created: function () {
        this.fetchData();
    },
    methods: {
        fetchData: function () {
            var self = this;
            self.loading = true;
            var params = {
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                year_filter: this.getData.year_filter,
                status_filter: this.getData.status_filter,
            };
            var url = new URL(API_BASE + 'get_periods');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    self.data = data.data;
                    self.data_row_count = data.data.length;
                }).finally(function () { self.loading = false; });
        },
        onChange: function () {
            this.selectedRow = -1;
            this.fetchData();
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
        },
        new_row_click: function () {
            var now = new Date();
            this.new_form = {
                pay_month: now.getMonth() + 1,
                pay_year: now.getFullYear(),
            };
        },
        save_period: function () {
            if (!this.new_form.pay_month) {
                Swal.fire('تنبيه', 'يجب اختيار الشهر', 'error');
                return;
            }
            if (!this.new_form.pay_year) {
                Swal.fire('تنبيه', 'يجب اختيار السنة', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('pay_month', this.new_form.pay_month);
            formData.append('pay_year', this.new_form.pay_year);

            var self = this;
            fetch(API_BASE + 'new_period', {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (Api.isOk(data)) {
                        bootstrap.Modal.getInstance(document.getElementById("periodModal")).hide();
                        Swal.fire('تم بنجاح', 'تم إنشاء الفترة بنجاح', 'success');
                        self.fetchData();
                    } else {
                        Api.showError(data);
                    }
                });
        },
        toggle_approve: function () {
            var row = this.data[this.selectedRow];
            var newStatus = !this.isTrue(row.is_approved);
            var msg = newStatus ? 'هل تريد اعتماد مسير ' : 'هل تريد إلغاء اعتماد مسير ';
            msg += this.monthName(row.pay_month) + ' ' + row.pay_year + '؟';

            var self = this;
            Swal.fire({
                title: newStatus ? 'اعتماد المسير' : 'إلغاء الاعتماد',
                text: msg,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    var formData = new FormData();
                    formData.append('id', row.id);
                    formData.append('is_approved', newStatus ? 'true' : 'false');
                    fetch(API_BASE + 'approve_period', {
                        method: 'POST',
                        body: formData
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (Api.isOk(data)) {
                                // mess: ما خُصم من السلف أو أُعيد إليها، وتنبيه الخصم الزائد عن المتبقي
                                Swal.fire('تم', (newStatus ? 'تم الاعتماد' : 'تم إلغاء الاعتماد')
                                    + (data.mess ? '. ' + data.mess : ''),
                                    data.mess && data.mess.indexOf('تنبيه') > -1 ? 'warning' : 'success');
                                self.fetchData();
                            } else {
                                Api.showError(data);
                            }
                        });
                }
            });
        },
        delete_period: function () {
            var row = this.data[this.selectedRow];
            var self = this;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف فترة ' + this.monthName(row.pay_month) + ' ' + row.pay_year + '؟ سيتم حذف جميع بيانات المسير لهذه الفترة',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_period/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (Api.isOk(data)) {
                                self.selectedRow = -1;
                                Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                                self.fetchData();
                            } else {
                                Api.showError(data);
                            }
                        });
                }
            });
        },
        goToMonth: function () {
            var row = this.data[this.selectedRow];
            window.location.href = API_BASE + 'view_month/' + row.pay_month + '/' + row.pay_year + '/' + row.id;
        },
        viewMonthUrl: function (row) {
            return API_BASE + 'view_month/' + row.pay_month + '/' + row.pay_year + '/' + row.id;
        },
        cancel_data: function () {
            this.selectedRow = -1;
        },
        formatNum: function (n) {
            if (n === null || n === undefined) return '0.00';
            return parseFloat(n).toFixed(2);
        },
        monthName: function (m) {
            var names = {
                1: 'يناير', 2: 'فبراير', 3: 'مارس', 4: 'أبريل',
                5: 'مايو', 6: 'يونيو', 7: 'يوليو', 8: 'أغسطس',
                9: 'سبتمبر', 10: 'أكتوبر', 11: 'نوفمبر', 12: 'ديسمبر',
            };
            return names[m] || m;
        },
        isTrue: function (val) {
            return val === 'T' || val === true || val === 't';
        },
    }
});
