
var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        items_reorder: this.items_id,
        data1: [],
        data2: [],
        quarterly: null,
        show_spinner: true,
    },
    created() {

        this.$http.get(this.URL + '/../../items_qry/sels_item/' + this.items_reorder).then(response => {
            // get body data
            if (response.body != "") {
                this.data = response.body;
                this.show_spinner = false;
            }
        });
        this.$http.get(this.URL + '/../../items_qry/quarterly_sales/' + this.items_reorder).then(response => {
            if (response.body != "") {
                this.quarterly = response.body;
            }
        });
    },
    methods: {
        remove_z() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.order_items > 0) {
                    return e;
                }
            });
        },
        add_avreg_0() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.avrg_items === 0) {
                    return e;
                }
            });
        },
        remove_count() {
            this.data = this.data.filter(function (e, index, arr) {
                if (e.quantity === 0) {
                    return e;
                }
            });
        },
        sort_name() {
            app.data = _.orderBy(app.data, ['items_main_name'], ['asc']);
        },
        sort_supp() {
            app.data = _.orderBy(app.data, ['supplier'], ['asc']);
        },
        sort_type() {
            app.data = _.orderBy(app.data, ['key_type'], ['asc']);
        },
        sort_items_main() {
            app.data = _.orderBy(app.data, ['items_main'], ['asc']);
        },
        sort_quantity() {
            app.data = _.orderBy(app.data, ['quantity'], ['asc']);
        },
        sort_avrg_items() {
            app.data = _.orderBy(app.data, ['avrg_items'], ['asc']);
        },
        sort_order_items() {
            app.data = _.orderBy(app.data, ['order_items'], ['asc']);
        },
        remove_supplier(sup) {
            //console.log(sup);
            this.data = this.data.filter(function (e, index, arr) {
                if (e.supplier != sup) {
                    return e;
                }
            });
        },
        remove_best_price() {
            this.data.forEach(function (e, index) {
                e.best_price = '';
            });
        },
        remove_supp_name() {
            this.data.forEach(function (e, index) {
                e.supplier = '';
            });
        },
        show_items_main(id) {
            window.open(purl + "/../../items/itm_rep_det/" + id, '_self');
        }
    },
    computed: {
        totalSalesQty() {
            if (!this.data || !this.data.data1) return 0;
            return this.data.data1.reduce(function(s, c) { return s + (parseFloat(c.item_count) || 0); }, 0);
        },
        totalSalesAmount() {
            if (!this.data || !this.data.data1) return '0.00';
            return this.data.data1.reduce(function(s, c) { return s + (parseFloat(c.total) || 0); }, 0).toFixed(2);
        },
        totalReturnQty() {
            if (!this.data || !this.data.data2) return 0;
            return this.data.data2.reduce(function(s, c) { return s + (parseFloat(c.item_count) || 0); }, 0);
        }
    },
});

