# -*- coding: utf-8 -*-
#  type: ignore
import math
# =======================================================================
@can_access(3010)
def index():
    return dict()


# =======================================================================
@can_access(3010)
def new():
    return dict()


# =======================================================================
@can_access(3010)
def preparation_reorder():
    sh = request.args(0)
    Order = db.items_reorder[sh] if sh else None
    if not Order:
        session.flash = "رقم الطلبية غير صحيح"
        redirect(URL("items_reorder", "index"))

    try:
        start_time = datetime.datetime.now().strftime("%H:%M:%S")
        avrg_by = Order.avrg_by

        if Order.supplier and Order.key_type:
            items_filter = "im.suppliers = %s AND im.item_type = %s"
            filter_params = [Order.supplier, Order.key_type]
        elif Order.key_type is not None:
            items_filter = "im.item_type = %s"
            filter_params = [Order.key_type]
        elif Order.supplier:
            items_filter = "im.suppliers = %s"
            filter_params = [Order.supplier]
        else:
            items_filter = "TRUE"
            filter_params = []

        big_query = f"""
            WITH filtered_items AS (
                SELECT id, suppliers, item_type
                FROM items_main im
                WHERE {items_filter}
            ),
            current_stock AS (
                SELECT d.item_idr,
                       COALESCE(SUM(d.items_count), 0) AS total_stock
                FROM items_det d
                WHERE d.item_idr IN (SELECT id FROM filtered_items)
                GROUP BY d.item_idr
            ),
            pending_returns AS (
                SELECT det.item_idr,
                       COALESCE(SUM(rsd.item_count), 0) AS return_qty
                FROM returned_supply_det rsd
                JOIN returned_supply rs ON rs.id = rsd.returned_supply
                JOIN items_det det ON det.id = CAST(rsd.item_id AS INTEGER)
                WHERE (rs.admin_accept = 'F' OR rs.admin_accept IS NULL)
                  AND det.item_idr IN (SELECT id FROM filtered_items)
                GROUP BY det.item_idr
            ),
            avg_sales AS (
                SELECT d.item_idr,
                       COALESCE(SUM(inv.item_count), 0) AS total_sales
                FROM invoice_details inv
                JOIN items_det d ON d.id = inv.item_number
                WHERE d.item_idr IN (SELECT id FROM filtered_items)
                  AND inv.created_on > date_trunc('month', CURRENT_DATE)
                                      - (%s * INTERVAL '1 month')
                GROUP BY d.item_idr
            ),
            best_prices AS (
                SELECT d.item_idr,
                       MIN(d.buy_price) AS best_price
                FROM items_det d
                WHERE d.item_idr IN (SELECT id FROM filtered_items)
                  AND d.buy_price > 0
                  AND d.created_on > date_trunc('month', CURRENT_DATE)
                                     - (%s * INTERVAL '1 month')
                GROUP BY d.item_idr
            )
            SELECT
                fi.id,
                fi.suppliers,
                fi.item_type,
                COALESCE(cs.total_stock, 0) - COALESCE(pr.return_qty, 0) AS current_stock,
                COALESCE(avs.total_sales, 0) AS total_sales,
                COALESCE(bp.best_price,   0) AS best_price
            FROM filtered_items fi
            LEFT JOIN current_stock    cs  ON cs.item_idr  = fi.id
            LEFT JOIN pending_returns  pr  ON pr.item_idr  = fi.id
            LEFT JOIN avg_sales        avs ON avs.item_idr = fi.id
            LEFT JOIN best_prices      bp  ON bp.item_idr  = fi.id
            ORDER BY fi.id
        """
        all_items = db.executesql(
            big_query,
            placeholders=filter_params + [avrg_by, avrg_by],
            as_dict=True,
        )
        row_count = len(all_items)

        db.executesql(
            "DELETE FROM items_reorder_detail WHERE items_reorder = %s",
            placeholders=[Order.id],
        )

        order_by = Order.order_by
        bulk_rows = []
        for row in all_items:
            sum_row = round(float(row["current_stock"]), 2)
            avrg_item = ((row["total_sales"] or 0) / avrg_by) or 0
            best_price = round(float(row["best_price"] or 0), 2)

            order_items = (avrg_item * order_by) - sum_row
            if order_items < (avrg_item / 2):
                order_items = 0
            if order_items < 0:
                order_items = 0

            bulk_rows.append(dict(
                items_reorder=Order.id,
                items_main=row["id"],
                supplier=row["suppliers"],
                key_type=row["item_type"],
                quantity=sum_row,
                avrg_items=round(avrg_item, 2),
                order_items=math.ceil(order_items),
                best_price=best_price,
            ))

        if bulk_rows:
            db.items_reorder_detail.bulk_insert(bulk_rows)

        end_time = datetime.datetime.now().strftime("%H:%M:%S")
        Order.update_record(
            jop_start_time=start_time,
            jop_end_time=end_time,
            row_count=row_count,
        )
        db.commit()
        session.flash = "تم تجهيز الطلبية (%s صنف)" % row_count
    except Exception as e:
        db.rollback()
        session.flash = "خطأ أثناء التجهيز: %s" % e

    redirect(URL("items_reorder", "index"))


# =======================================================================
@can_access(3010)
def show_reorder():
    return dict()


# ========================================================================
#          عمليات شاشة ادخال الاصناف من فواتير التوريد
# ========================================================================
@can_access(3010)
def get_key_types():
    q = db(db.key_type.id > 0).select()
    return response.json(q)


@can_access(3010)
def get_suppliers():
    q = db(db.suppliers.stoped == False).select(
        db.suppliers.id, db.suppliers.name, orderby=db.suppliers.id
    )
    return response.json(q)


@can_access(3010)
def get_items_reorder():
    qry = """
        SELECT
            ir.id, ir.dis, ir.avrg_by, ir.order_by,
            ir.order_date, ir.order_time,
            ir.jop_start_time, ir.jop_end_time, ir.row_count,
            s.name  AS supplier,
            kt.name AS key_type
        FROM items_reorder ir
        LEFT JOIN suppliers s  ON s.id  = ir.supplier
        LEFT JOIN key_type  kt ON kt.id = ir.key_type
        ORDER BY ir.id DESC
        LIMIT 20
    """
    det_items = db.executesql(qry, as_dict=True)
    return response.json(det_items)
    # --------------------------------------


@can_access(3010)
def get_items_reorder_detail():
    qry = """
        SELECT
            ird.id,
            ird.items_reorder,
            ird.items_main,
            ird.quantity,
            ird.avrg_items,
            ird.order_items,
            ird.best_price,
            UPPER(im.name)      AS items_main_name,
            im.item_id          AS item_id,
            s.name              AS supplier,
            kt.name             AS key_type
        FROM items_reorder_detail ird
        LEFT JOIN items_main    im   ON im.id   = ird.items_main
        LEFT JOIN suppliers     s    ON s.id    = ird.supplier
        LEFT JOIN key_type      kt   ON kt.id   = ird.key_type
        WHERE ird.items_reorder = %s
        ORDER BY UPPER(im.name)
    """
    det_items = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(det_items)


@can_access(3010)
def get_best_suppliers():
    qry = """
        SELECT DISTINCT ON (ird.items_main)
            ird.items_main,
            sb_s.name AS supp_name
        FROM items_reorder_detail ird
        JOIN items_det       id2  ON id2.item_idr  = ird.items_main
                                  AND id2.buy_price = ird.best_price
        JOIN suppliers_bills sb   ON sb.id   = id2.supplier_inv
        JOIN suppliers       sb_s ON sb_s.id = sb.supplier
        WHERE ird.items_reorder = %s
          AND ird.best_price > 0
        ORDER BY ird.items_main, id2.id DESC
    """
    data = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(data)


@can_access(3010)
def search_item():
    search = request.vars.itid
    srh = search.split()
    data = []
    if len(srh) == 1:
        qry = (
            "select * from items_main  where LOWER(name) like %s"
            " order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=['%' + request.vars.itid.lower() + '%'], as_dict=True)
    elif len(srh) == 2:
        qry = (
            "select * from items_main  where LOWER(name) like %s"
            " and LOWER(name) like %s"
            "   order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=['%' + srh[0].lower() + '%', '%' + srh[1].lower() + '%'], as_dict=True)
    return response.json(data)


@can_access(3010)
def addit():
    try:
        import json
        body = request.body.read()
        if body:
            itm = json.loads(body)
        else:
            itm = request.vars

        type_id = None
        supp_id = None
        if int(itm.get("type_id", -1)) > 0:
            type_id = int(itm["type_id"])

        supp_id_val = itm.get("supp_id")
        if isinstance(supp_id_val, dict):
            if int(supp_id_val.get("id", -1)) > 0:
                supp_id = int(supp_id_val["id"])
        elif supp_id_val and int(supp_id_val) > 0:
            supp_id = int(supp_id_val)

        new_id = db.items_reorder.insert(
            dis=itm.get("dis", ""),
            supplier=supp_id,
            key_type=type_id,
            avrg_by=float(itm.get("avrg_by", 0)),
            order_by=float(itm.get("order_by", 0)),
        )
        db.commit()
        if new_id:
            return "0"
        else:
            return "1"
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


@can_access(3010)
def delete_order():
    row = db.items_reorder[request.args(0)]
    if row == None:
        return "هذه الطلبية غير صحيحة"
    row.delete_record()
    redirect(URL("items_reorder", "index"))


# <=============================    end   ===============================>


@can_access(3010)
def deleteall():
    db.executesql("delete from items_reorder")
    db.executesql("delete from items_reorder_detail")
    redirect(URL("items_reorder", "index"))
