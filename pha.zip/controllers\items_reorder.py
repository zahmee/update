# -*- coding: utf-8 -*-
#  type: ignore
import math


def _json_error(message):
    return response.json({"err": 3, "mess": message})


def _float_nonnegative(value, label):
    try:
        number = float(value or 0)
    except (TypeError, ValueError):
        raise ValueError("{} غير صحيح".format(label))
    if number < 0:
        raise ValueError("{} لا يمكن أن يكون سالباً".format(label))
    return number


def _optional_existing_id(table_name, value, label):
    if value in (None, "", "0", 0):
        return None
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        raise ValueError("{} غير صحيح".format(label))
    # -1 (و أي قيمة غير موجبة) = "بدون اختيار" → اختياري
    if row_id <= 0:
        return None
    if not db[table_name](row_id):
        raise ValueError("{} غير موجود".format(label))
    return row_id


def _get_reorder_or_redirect(order_id=None):
    try:
        rid = int(order_id or request.args(0) or 0)
    except (TypeError, ValueError):
        rid = 0
    row = db.items_reorder[rid]
    if not row:
        session.flash = "رقم الطلبية غير صحيح"
        redirect(URL("items_reorder", "index"))
    supplier = db.suppliers[row.supplier] if row.supplier else None
    key_type = db.key_type[row.key_type] if row.key_type else None
    return row, supplier, key_type


def _reorder_importance(row, order_by):
    order_items = float(row.get("order_items") or 0)
    quantity = float(row.get("quantity") or 0)
    order_by = float(order_by or 1) or 1
    if order_items == 0:
        return 0
    if quantity == 0 and order_items > 0:
        return 9999
    return int(round(((order_items / quantity) * 100) / order_by, 0))


def _get_reorder_detail_rows(order_id, order_by=None, include_best_supplier=False):
    best_supplier_select = "'' AS best_price_supp_n"
    best_supplier_join = ""
    placeholders = []
    if include_best_supplier:
        best_supplier_select = "COALESCE(bps.supp_name, '') AS best_price_supp_n"
        best_supplier_join = """
            LEFT JOIN (
                SELECT DISTINCT ON (ird2.items_main)
                    ird2.items_main,
                    sb_s.name AS supp_name
                FROM items_reorder_detail ird2
                JOIN items_det       id2  ON id2.item_idr  = ird2.items_main
                                          AND id2.buy_price = ird2.best_price
                JOIN suppliers_bills sb   ON sb.id   = id2.supplier_inv
                JOIN suppliers       sb_s ON sb_s.id = sb.supplier
                WHERE ird2.items_reorder = %s
                  AND ird2.best_price > 0
                ORDER BY ird2.items_main, id2.id DESC
            ) bps ON bps.items_main = ird.items_main
        """
        placeholders.append(order_id)

    qry = """
        SELECT
            ird.id,
            ird.items_reorder,
            ird.items_main,
            ird.quantity,
            ird.avrg_items,
            ird.order_items,
            ird.best_price,
            UPPER(im.name)      AS items_main_name,
            im.item_id          AS item_id,
            s.name              AS supplier,
            kt.name             AS key_type,
            {best_supplier_select}
        FROM items_reorder_detail ird
        LEFT JOIN items_main    im   ON im.id   = ird.items_main
        LEFT JOIN suppliers     s    ON s.id    = ird.supplier
        LEFT JOIN key_type      kt   ON kt.id   = ird.key_type
        {best_supplier_join}
        WHERE ird.items_reorder = %s
        ORDER BY UPPER(im.name)
    """.format(
        best_supplier_select=best_supplier_select,
        best_supplier_join=best_supplier_join,
    )
    placeholders.append(order_id)
    rows = db.executesql(qry, placeholders=placeholders, as_dict=True)
    for row in rows:
        row["important"] = _reorder_importance(row, order_by)
    return rows

# =======================================================================
@can_access(3010)
def index():
    return dict()


# =======================================================================
@can_access(3010)
def new():
    return dict()


# =======================================================================
@can_access(3010)
def preparation_reorder():
    sh = request.args(0)
    Order = db.items_reorder[sh] if sh else None
    if not Order:
        session.flash = "رقم الطلبية غير صحيح"
        redirect(URL("items_reorder", "index"))

    try:
        start_time = datetime.datetime.now().strftime("%H:%M:%S")
        avrg_by = Order.avrg_by

        if Order.supplier and Order.key_type:
            items_filter = "im.suppliers = %s AND im.item_type = %s"
            filter_params = [Order.supplier, Order.key_type]
        elif Order.key_type is not None:
            items_filter = "im.item_type = %s"
            filter_params = [Order.key_type]
        elif Order.supplier:
            items_filter = "im.suppliers = %s"
            filter_params = [Order.supplier]
        else:
            items_filter = "TRUE"
            filter_params = []

        big_query = f"""
            WITH filtered_items AS (
                SELECT id, suppliers, item_type
                FROM items_main im
                WHERE {items_filter}
            ),
            current_stock AS (
                SELECT d.item_idr,
                       COALESCE(SUM(d.items_count), 0) AS total_stock
                FROM items_det d
                WHERE d.item_idr IN (SELECT id FROM filtered_items)
                GROUP BY d.item_idr
            ),
            pending_returns AS (
                SELECT det.item_idr,
                       COALESCE(SUM(rsd.item_count), 0) AS return_qty
                FROM returned_supply_det rsd
                JOIN returned_supply rs ON rs.id = rsd.returned_supply
                JOIN items_det det ON det.id = CAST(rsd.item_id AS INTEGER)
                WHERE (rs.admin_accept = 'F' OR rs.admin_accept IS NULL)
                  AND det.item_idr IN (SELECT id FROM filtered_items)
                GROUP BY det.item_idr
            ),
            avg_sales AS (
                SELECT d.item_idr,
                       COALESCE(SUM(inv.item_count), 0) AS total_sales
                FROM invoice_details inv
                JOIN items_det d ON d.id = inv.item_number
                WHERE d.item_idr IN (SELECT id FROM filtered_items)
                  AND inv.created_on > date_trunc('month', CURRENT_DATE)
                                      - (%s * INTERVAL '1 month')
                GROUP BY d.item_idr
            ),
            best_prices AS (
                SELECT d.item_idr,
                       MIN(d.buy_price) AS best_price
                FROM items_det d
                WHERE d.item_idr IN (SELECT id FROM filtered_items)
                  AND d.buy_price > 0
                  AND d.created_on > date_trunc('month', CURRENT_DATE)
                                     - (%s * INTERVAL '1 month')
                GROUP BY d.item_idr
            )
            SELECT
                fi.id,
                fi.suppliers,
                fi.item_type,
                COALESCE(cs.total_stock, 0) - COALESCE(pr.return_qty, 0) AS current_stock,
                COALESCE(avs.total_sales, 0) AS total_sales,
                COALESCE(bp.best_price,   0) AS best_price
            FROM filtered_items fi
            LEFT JOIN current_stock    cs  ON cs.item_idr  = fi.id
            LEFT JOIN pending_returns  pr  ON pr.item_idr  = fi.id
            LEFT JOIN avg_sales        avs ON avs.item_idr = fi.id
            LEFT JOIN best_prices      bp  ON bp.item_idr  = fi.id
            ORDER BY fi.id
        """
        all_items = db.executesql(
            big_query,
            placeholders=filter_params + [avrg_by, avrg_by],
            as_dict=True,
        )
        row_count = len(all_items)

        db.executesql(
            "DELETE FROM items_reorder_detail WHERE items_reorder = %s",
            placeholders=[Order.id],
        )

        order_by = Order.order_by
        bulk_rows = []
        for row in all_items:
            sum_row = round(float(row["current_stock"]), 2)
            avrg_item = ((row["total_sales"] or 0) / avrg_by) or 0
            best_price = round(float(row["best_price"] or 0), 2)

            order_items = (avrg_item * order_by) - sum_row
            if order_items < (avrg_item / 2):
                order_items = 0
            if order_items < 0:
                order_items = 0

            bulk_rows.append(dict(
                items_reorder=Order.id,
                items_main=row["id"],
                supplier=row["suppliers"],
                key_type=row["item_type"],
                quantity=sum_row,
                avrg_items=round(avrg_item, 2),
                order_items=math.ceil(order_items),
                best_price=best_price,
            ))

        if bulk_rows:
            db.items_reorder_detail.bulk_insert(bulk_rows)

        end_time = datetime.datetime.now().strftime("%H:%M:%S")
        Order.update_record(
            jop_start_time=start_time,
            jop_end_time=end_time,
            row_count=row_count,
        )
        db.commit()
        session.flash = "تم تجهيز الطلبية (%s صنف)" % row_count
    except Exception as e:
        db.rollback()
        session.flash = "خطأ أثناء التجهيز: %s" % e

    redirect(URL("items_reorder", "index"))


# =======================================================================
@can_access(3010)
def show_reorder():
    if request.extension == "js":
        return dict()
    row, supplier, key_type = _get_reorder_or_redirect()
    return dict(row=row, supplier=supplier, key_type=key_type)


@can_access(3010)
def export_excel():
    order, supplier, key_type = _get_reorder_or_redirect()

    export_columns = [
        ("items_main", "رقم الصنف", "items_main", "number", 13),
        ("item_id", "الرقم الدولي", "item_id", "text_center", 15),
        ("items_main_name", "اسم الصنف", "items_main_name", "text", 38),
        ("key_type", "التصنيف", "key_type", "text_center", 16),
        ("supplier", "المورد", "supplier", "text_center", 18),
        ("quantity", "الموجود", "quantity", "number", 11),
        ("order_items", "المطلوب", "order_items", "need", 11),
        ("important", "الأهمية %", "important", "number", 11),
        ("avrg_items", "المتوسط", "avrg_items", "number", 11),
        ("best_price", "أقل سعر", "best_price", "number", 11),
        ("best_price_supp_n", "مورد أقل سعر", "best_price_supp_n", "text_center", 20),
    ]
    default_fields = [
        "items_main", "item_id", "items_main_name", "supplier", "quantity",
        "order_items", "important", "avrg_items",
    ]
    allowed = {col[0]: col for col in export_columns}
    requested_fields = [
        field.strip()
        for field in (request.vars.fields or ",".join(default_fields)).split(",")
        if field.strip() in allowed
    ]
    if not requested_fields:
        requested_fields = default_fields
    selected_columns = [allowed[field] for field in requested_fields]
    rows = _get_reorder_detail_rows(
        order.id,
        order.order_by,
        include_best_supplier=("best_price_supp_n" in requested_fields),
    )

    import io
    import xlsxwriter

    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream, {"in_memory": True})
    worksheet = workbook.add_worksheet("طلبية")
    worksheet.right_to_left()

    title_fmt = workbook.add_format({
        "bold": True, "font_size": 14, "align": "center", "valign": "vcenter",
        "bg_color": "#233044", "font_color": "#FFFFFF",
    })
    meta_fmt = workbook.add_format({"align": "center", "valign": "vcenter", "border": 1})
    header_fmt = workbook.add_format({
        "bold": True, "align": "center", "valign": "vcenter",
        "bg_color": "#E8F0E8", "border": 1,
    })
    text_fmt = workbook.add_format({"align": "right", "valign": "vcenter", "border": 1})
    center_fmt = workbook.add_format({"align": "center", "valign": "vcenter", "border": 1})
    number_fmt = workbook.add_format({"align": "center", "valign": "vcenter", "border": 1, "num_format": "#,##0.##"})
    warning_fmt = workbook.add_format({"align": "center", "valign": "vcenter", "border": 1, "bg_color": "#FFF2CC"})

    last_col = len(selected_columns)
    worksheet.merge_range(0, 0, 0, last_col, "طلبية إعادة الطلب رقم {}".format(order.id), title_fmt)
    meta_rows = [
        ("الوصف", order.dis or ""),
        ("المورد", supplier.name if supplier else "الكل"),
        ("التصنيف", key_type.name if key_type else "الكل"),
        ("التاريخ", "{} / {}".format(order.order_date or "", order.order_time or "")),
        ("متوسط / طلب", "{} شهر / {} شهر".format(order.avrg_by or 0, order.order_by or 0)),
        ("عدد الأصناف", len(rows)),
    ]
    for idx, (label, value) in enumerate(meta_rows, start=1):
        worksheet.write(idx, 0, label, header_fmt)
        worksheet.merge_range(idx, 1, idx, last_col, value, meta_fmt)

    headers = ["#"] + [col[1] for col in selected_columns]
    start_row = len(meta_rows) + 2
    for col, header in enumerate(headers):
        worksheet.write(start_row, col, header, header_fmt)

    for row_idx, row in enumerate(rows, start=start_row + 1):
        worksheet.write_number(row_idx, 0, row_idx - start_row, center_fmt)
        for col_idx, (_, _, key, value_type, _) in enumerate(selected_columns, start=1):
            value = row.get(key)
            if value_type == "text":
                worksheet.write(row_idx, col_idx, value or "", text_fmt)
            elif value_type == "text_center":
                worksheet.write(row_idx, col_idx, value or "", center_fmt)
            elif value_type == "need":
                number_value = float(value or 0)
                worksheet.write_number(row_idx, col_idx, number_value, warning_fmt if number_value > 0 else number_fmt)
            else:
                worksheet.write_number(row_idx, col_idx, float(value or 0), number_fmt)

    worksheet.freeze_panes(start_row + 1, 0)
    worksheet.autofilter(start_row, 0, start_row + len(rows), len(headers) - 1)
    worksheet.set_column(0, 0, 6)
    for col_idx, (_, _, _, _, width) in enumerate(selected_columns, start=1):
        worksheet.set_column(col_idx, col_idx, width)
    worksheet.set_portrait()
    worksheet.set_paper(9)
    worksheet.fit_to_pages(1, 0)
    workbook.close()

    stream.seek(0)
    filename = "items_reorder_{}.xlsx".format(order.id)
    response.headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    response.headers["Content-Disposition"] = "attachment; filename={}".format(filename)
    return stream.read()


@can_access(3010)
def export_pdf():
    order, supplier, key_type = _get_reorder_or_redirect()
    rows = _get_reorder_detail_rows(order.id, order.order_by, include_best_supplier=True)
    return dict(order=order, supplier=supplier, key_type=key_type, rows=rows)


# ========================================================================
#          عمليات شاشة ادخال الاصناف من فواتير التوريد
# ========================================================================
@can_access(3010)
def get_key_types():
    q = db(db.key_type.id > 0).select()
    return response.json(q)


@can_access(3010)
def get_suppliers():
    q = db(db.suppliers.stoped == False).select(
        db.suppliers.id, db.suppliers.name, orderby=db.suppliers.id
    )
    return response.json(q)


@can_access(3010)
def get_items_reorder():
    qry = """
        SELECT
            ir.id, ir.dis, ir.avrg_by, ir.order_by,
            ir.order_date, ir.order_time,
            ir.jop_start_time, ir.jop_end_time, ir.row_count,
            s.name  AS supplier,
            kt.name AS key_type
        FROM items_reorder ir
        LEFT JOIN suppliers s  ON s.id  = ir.supplier
        LEFT JOIN key_type  kt ON kt.id = ir.key_type
        ORDER BY ir.id DESC
        LIMIT 20
    """
    det_items = db.executesql(qry, as_dict=True)
    return response.json(det_items)
    # --------------------------------------


@can_access(3010)
def get_items_reorder_detail():
    order, supplier, key_type = _get_reorder_or_redirect()
    det_items = _get_reorder_detail_rows(order.id, order.order_by, include_best_supplier=False)
    return response.json(det_items)


@can_access(3010)
def get_best_suppliers():
    qry = """
        SELECT DISTINCT ON (ird.items_main)
            ird.items_main,
            sb_s.name AS supp_name
        FROM items_reorder_detail ird
        JOIN items_det       id2  ON id2.item_idr  = ird.items_main
                                  AND id2.buy_price = ird.best_price
        JOIN suppliers_bills sb   ON sb.id   = id2.supplier_inv
        JOIN suppliers       sb_s ON sb_s.id = sb.supplier
        WHERE ird.items_reorder = %s
          AND ird.best_price > 0
        ORDER BY ird.items_main, id2.id DESC
    """
    data = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(data)


@can_access(3010)
def search_item():
    search = request.vars.itid
    srh = search.split()
    data = []
    if len(srh) == 1:
        qry = (
            "select * from items_main  where LOWER(name) like %s"
            " order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=['%' + request.vars.itid.lower() + '%'], as_dict=True)
    elif len(srh) == 2:
        qry = (
            "select * from items_main  where LOWER(name) like %s"
            " and LOWER(name) like %s"
            "   order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=['%' + srh[0].lower() + '%', '%' + srh[1].lower() + '%'], as_dict=True)
    return response.json(data)


@can_access(3010)
def addit():
    try:
        import json
        body = request.body.read()
        if body:
            itm = json.loads(body)
        else:
            itm = request.vars

        type_id = _optional_existing_id("key_type", itm.get("type_id"), "التصنيف")
        supp_id_val = itm.get("supp_id")
        if isinstance(supp_id_val, dict):
            supp_id_val = supp_id_val.get("id")
        supp_id = _optional_existing_id("suppliers", supp_id_val, "المورد")
        avrg_by = _float_nonnegative(itm.get("avrg_by", 0), "المتوسط")
        order_by = _float_nonnegative(itm.get("order_by", 0), "الطلب")

        new_id = db.items_reorder.insert(
            dis=itm.get("dis", ""),
            supplier=supp_id,
            key_type=type_id,
            avrg_by=avrg_by,
            order_by=order_by,
        )
        db.commit()
        if new_id:
            return "0"
        else:
            return "1"
    except Exception as e:
        db.rollback()
        print(e)
        return _json_error(str(e))


@can_access(3010)
def delete_order():
    row = db.items_reorder[request.args(0)]
    if row == None:
        return "هذه الطلبية غير صحيحة"
    row.delete_record()
    redirect(URL("items_reorder", "index"))


# <=============================    end   ===============================>


@can_access(3010)
def deleteall():
    db.executesql("delete from items_reorder")
    db.executesql("delete from items_reorder_detail")
    redirect(URL("items_reorder", "index"))
