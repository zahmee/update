Vue.component('v-select', VueSelect.VueSelect);


var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        day_date: {
            day: 1,
            month: 1,
            year: 2019
        },
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
        },
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        text_ltr: false,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
    },
    created() {
        this.getData.SortBy = 'id';
        this.getData.sortAsc = false;
        fetch(window.location.href + '/../../suppliers_api/get_B_R', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
            }).then(() => {
                fetch(window.location.href + '/../../api_1/min_suppliers_1')
                    .then(response => response.json())
                    .then(resp => {
                        var data = Api.getData(resp);
                        this.coding.supplier = data;
                        this.coding.Allsupplier = data;
                        op = this.options;
                        data.forEach(function (el) {
                            new_el = {
                                value: el.id,
                                label: '[' + el.id + '] - ' + el.name
                            }
                            //
                            op.push(new_el);
                        });

                    })

            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../suppliers_api/get_B_R'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = Api.getData(data);
                        this.data_row_count = data.count;
                    });
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined') {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/get_B_R'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    Api.getData(data).forEach(el => {
                        this.data.push(el);
                    })
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
        },
        on_change_select() {
            this.$forceUpdate();
        },

        edit_row() {
            this.new_row = false;
            var today = new Date(this.edit_row_data.balance_date);
            this.day_date.year = today.getFullYear()
            this.day_date.month = today.getMonth() + 1
            this.day_date.day = today.getDate()
            this.edit_row_data.supplier = { value: this.edit_row_data.supplier, label: this.edit_row_data.s_name };
            //console.log(this.edit_row_data);

        },
        new_row_click() {
            this.new_row = true;
            var today = new Date();
            this.day_date.year = today.getFullYear()
            this.day_date.month = today.getMonth() + 1
            this.day_date.day = today.getDate()
        },
        chk_date() {
            var today = new Date();
            if (this.day_date.day > 31 || this.day_date.day < 1) {
                this.day_date.day = today.getDate()
            }
            if (this.day_date.month > 12 || this.day_date.month < 1) {
                this.day_date.month = today.getMonth() + 1
            }
            if (this.day_date.year > 2030 || this.day_date.year < 2020) {
                this.day_date.year = today.getFullYear()
            }
        },

        save_data() {
            if (!this.edit_row_data.supplier || !this.edit_row_data.balance || !this.day_date.year
                || !this.day_date.month || !this.day_date.day) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [كافة الحقول لكي تحفظ ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_B_R');
                params = this.edit_row_data;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.supplier);
                params.supplier = this.edit_row_data.supplier.value;
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (Api.isOk(data)) {
                            this.data.splice(0, 0, Api.getData(data));
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            //row_modal.hide();
                            $('#exampleModal').modal('hide')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Api.showError(data);
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/edit_B_R');
                params = this.edit_row_data;
                params.day = JSON.stringify(this.day_date);
                params.suppliers = JSON.stringify(this.edit_row_data.supplier);
                params.supplier = this.edit_row_data.supplier.value;
                console.log(params);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (Api.isOk(data)) {
                            this.data[this.selectedRow] = Api.getData(data);
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            $('#exampleModal').modal('hide')
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Api.showError(data);
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    },


});
