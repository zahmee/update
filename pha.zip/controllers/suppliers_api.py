# -*- coding: utf-8 -*-
#  type: ignore

#====================================================================
#def get_supp():
#    q  = db(db.suppliers.id>0).select(db.suppliers.id ,db.suppliers.name , db.suppliers.stoped , orderby=[db.suppliers.stoped,db.suppliers.name ])
#    return response.json(q)

# from asyncio.windows_events import NULL
from datetime import datetime
import json


@can_access(2001)
def get_supp():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0 
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    where = '' 
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i==0 :
                where = f" where (  name like '%{srt[i]}%' or tel like '%{srt[i]}%' or address like '%{srt[i]}%'  ) "
            else :
                where = where +f" and ( name like '%{srt[i]}%' or tel like '%{srt[i]}%' or address like '%{srt[i]}%'   ) "
    if ReqVar.SortBy :
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'desc'
    else :
        sa = 'ASC'
    pg = int(int(pg) * int(rc))
    where = where.replace('where  and', 'where')    
    where = where.replace('where  and', 'where') 
    where = where.replace('and  and', 'and') 
    sql = f" SELECT id,name,tel, address ,stoped ,note,bank_account  FROM suppliers {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    sql = sql.replace('and  order', 'order') 
    sql2 = f" SELECT count(*) FROM suppliers  {where}  ; "
    sql2 = sql2.replace('and   ;' , '; ')
    qry = db.executesql(sql  ,as_dict=True)
    qry2 = db.executesql(sql2  ,as_dict=True)
    data = { "data" : qry , "count" :qry2[0]["count"] }
    return response.json(data)


#====================================================================
@can_access(2005)
def supply_lock():
    q = db.suppliers[request.args(0)]
    if q.stoped == True :
        q.stoped = False 
    else : 
        q.stoped = True
    q.update_record() 
    db.commit()
    return 0
#====================================================================
def get_supp_id():
    q  = db.suppliers[request.args(0)]
    return response.json(q)
#====================================================================
@can_access(2003)
def update_supplier():
    data = request.vars
    row = db.suppliers[data.id]
    row.name = data.name 
    row.bank_account = data.bank_account
    row.note = data.note 
    row.tel = data.tel 
    row.address = data.address
    row.stoped = data.stoped
    row.update_record() 
    db.commit()
    return response.json(row)
#====================================================================
#@auth.requires(auth.has_membership('user1') or auth.has_membership('admin') or auth.has_membership('secretarial'))
@can_access(2002)
def new_supplier():
    data = request.vars
    if data.stoped==None :
        data.stoped = False 

    nid = db.suppliers.insert(
                    name=data.name  , 
                    bank_account = data.bank_account ,
                    note =  data.note   , 
                    tel = data.tel , 
                    address = data.address ,
                    stoped = data.stoped  
                    )
    db.commit()
    ret = {"id":str(nid)}
    return response.json(ret)
#====================================================================
#@auth.requires(auth.has_membership('admin') )
# @can_access(2004)
# def delete_supplier():
#     try :
#         data = request.vars
#         row = db.suppliers[data.id]
#         row.delete_record()
#         db.commit()
#         return 0
#     except Exception :
#         db.rollback()
#         print ( e )
#         return e
#====================================================================
def get_invoce_type():
    q  = db(db.key_invoce_type.id>0).select(db.key_invoce_type.id ,db.key_invoce_type.name , orderby=[db.key_invoce_type.id ])
    return response.json(q)
#====================================================================
def getSuppInvoce():
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0 
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    where_1 = where_2 = where_3 = where_4 = '' 
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i==0 :
                where_1 = f" (  bill_no like '%{srt[i]}%' or CAST (id   AS text) like '%{srt[i]}%' or CAST (bill_total  AS text) like '%{srt[i]}%' or CAST (bill_vat  AS text) like '%{srt[i]}%' or CAST (bill_date  AS text) like '%{srt[i]}%' ) "
            else :
                where_1 = where_1 +f" and (  bill_no like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' or CAST (bill_total  AS text) like '%{srt[i]}%' or CAST (bill_vat  AS text) like '%{srt[i]}%' or CAST (bill_date  AS text) like '%{srt[i]}%' ) "
    if ReqVar.supplier :
        if ( (ReqVar.supplier is not None) or (ReqVar.supplier !=''))  :
            where_2 = f"  ( supplier = {ReqVar.supplier}  ) "
    if ReqVar.types  and (ReqVar.types != '0' )  :
        if ( (ReqVar.types is not None) or (ReqVar.types !=''))  :
            where_3 = f"  ( invoce_type = {ReqVar.types} ) "
    if len(where_1)>0 or len(where_2)>0 or len(where_3)>0 :
        where_4 = " where " + where_1 + " and " + where_2 +" and " + where_3
    if ReqVar.SortBy :
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'desc'
    else :
        sa = 'desc'
    pg = int(int(pg) * int(rc))
    where = where_4.replace('where  and', 'where')    
    where = where.replace('where  and', 'where')    
    where = where.replace('where  and', 'where') 
    where = where.replace('and  and', 'and') 
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq2 = "(select name from key_invoce_type where id=invoce_type) as t_name"
    subq3 = "(select count(*) from items_det where supplier_inv=suppliers_bills.id) as itm_count"
    subq4 = "(select count(*) from items_det where supplier_inv=suppliers_bills.id and return_count>0) as itm_r_count"
    subq41 = "(select count(*) from suppliers_bills_files where suppliers_bills_id=suppliers_bills.id ) as f_count"
    subq5 = "(select name from key_payment_method where id=payment_method) as m_name"
    sql = ( f" SELECT id,bill_no, bill_date, bill_total,bill_net_amount,bill_vat,bill_confirmation,return_confirmation,"
            f" {subq1} ,{subq2},{subq3},{subq4},{subq41},{subq5},supplier,payment_method,invoce_type FROM suppliers_bills "
            f" {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; ")
    sql = sql.replace('and  order', 'order') 
    sql2 = f" SELECT count(*) FROM suppliers_bills  {where}  ; "
    sql2 = sql2.replace('and   ;' , '; ')
    qry = db.executesql(sql  ,as_dict=True)
    qry2 = db.executesql(sql2  ,as_dict=True)
    data = { "data" : qry , "count" :qry2[0]["count"] }
    return response.json(data)
#====================================================================
@can_access(2010)
def new_bill():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        bill_net_amount = round((float(data.bill_total) - float(data.bill_vat)) , 2)
        nid = db.suppliers_bills.insert(
                        supplier=data.suppliers['value']  , 
                        payment_method = data.payment_method ,
                        bill_no =  data.bill_no   , 
                        bill_date =  bill_date  , 
                        bill_total = data.bill_total ,
                        bill_vat = data.bill_vat   ,
                        bill_net_amount = bill_net_amount  ,
                        invoce_type = data.invoce_type
                        )
        inserted = db.suppliers_bills[nid]
        db.commit()
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e
#====================================================================
@can_access(2010)
def edit_bill():
    try :
        data = request.vars
        q = db.suppliers_bills[data.id]
        if q.bill_confirmation==False :
            data.day = json.loads(data.day)
            suppliers = json.loads(data.suppliers)
            bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
            bill_net_amount = round((float(data.bill_total) - float(data.bill_vat)) , 2)
            q.supplier = suppliers['value']
            q.payment_method = int(data.payment_method) 
            q.bill_no =  data.bill_no   
            q.bill_date =  bill_date  
            q.bill_total = float(data.bill_total) 
            q.bill_vat = float(data.bill_vat)   
            q.bill_net_amount = float(bill_net_amount)  
            q.invoce_type = data.invoce_type
            q.update_record() 
            db.commit()
            return response.json(q)
        else :
            return response.json({'mess':'لايمكن الحفظ'})
    except Exception as e:
        db.rollback()
        print ( e )
        return e

#================================================================
# ----------------->  returned_supply                  <=========
#================================================================
def getRetSuppInvoce():
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0 
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    where_1 = where_2 = where_3 = where_4 = '' 
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i==0 :
                where_1 = f" (  name like '%{srt[i]}%' or CAST (id   AS text) like '%{srt[i]}%' or CAST (total  AS text) like '%{srt[i]}%' or CAST (item_count  AS text) like '%{srt[i]}%' or CAST (ret_date  AS text) like '%{srt[i]}%' ) "
            else :
                where_1 = where_1 +f" and (  name like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' or CAST (total  AS text) like '%{srt[i]}%' or CAST (item_count  AS text) like '%{srt[i]}%' or CAST (ret_date  AS text) like '%{srt[i]}%' ) "
    if ReqVar.supplier :
        if ( (ReqVar.supplier is not None) or (ReqVar.supplier !=''))  :
            where_2 = f"  ( supplier = {ReqVar.supplier}  ) "
    if len(where_1)>0 or len(where_2)>0 or len(where_3)>0 :
        where_4 = " where " + where_1 + " and " + where_2 +" and " + where_3
    if ReqVar.SortBy :
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'desc'
    else :
        sa = 'desc'
    pg = int(int(pg) * int(rc))
    where = where_4.replace('where  and', 'where')    
    where = where.replace('where  and', 'where')    
    where = where.replace('where  and', 'where') 
    where = where.replace('and  and', 'and') 
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq3 = "(select count(*) from returned_supply_det where returned_supply=returned_supply.id) as itm_count"
    subq4 = "(select sum(item_count) from returned_supply_det where returned_supply=returned_supply.id ) as itm_r_count"
    sql = ( f" SELECT id,name ,supplier ,ret_date ,round(CAST(real_total AS decimal ) ,2) as real_total , admin_accept,"
            f" {subq1} ,{subq3},{subq4} FROM returned_supply "
            f" {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; ")
    sql = sql.replace('and  order', 'order') 
    sql2 = f" SELECT count(*) FROM returned_supply  {where}  ; "
    sql2 = sql2.replace('and   ;' , '; ')
    qry = db.executesql(sql  ,as_dict=True)
    qry2 = db.executesql(sql2  ,as_dict=True)
    data = { "data" : qry , "count" :qry2[0]["count"] }
    return response.json(data)
#====================================================================
def new_RetSupInv():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        nid = db.returned_supply.insert(
                        supplier=data.suppliers['value']  , 
                        name = data.name ,
                        ret_date =  bill_date  , 
                        admin_accept = False 
                        )
        inserted = db.returned_supply[nid]
        db.commit()
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e
#====================================================================
def edit_RetSupInv():
    try :
        data = request.vars
        q = db.returned_supply[data.id]
        if q.admin_accept==False :
            data.day = json.loads(data.day)
            suppliers = json.loads(data.suppliers)
            ret_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
            q.supplier = suppliers['value']
            q.ret_date =  ret_date  
            q.name = data.name
            q.update_record() 
            db.commit()
            return response.json(q)
        else :
            return response.json({'mess':'لايمكن الحفظ'})
    except Exception as e:
        db.rollback()
        print ( e )
        return e

#================================================================
# ----------------->  returned_supply detail           <=========
#================================================================
def getRetSuppInvoceDet():
    qry = db(db.returned_supply_det.returned_supply==request.args(0) ).select() 
    return response.json(qry)
#====================================================================
def getit(): 
    qry = ("select id as item_id ,item_idr,supplier_inv ,expiration_date ,buy_price ,vat ,vat_in_public_price, "
        " ( select name from suppliers where suppliers.id=(select supplier  from suppliers_bills where suppliers_bills.id=supplier_inv)) as s_name , "
        " ( select name from items_main where items_main.id= items_det.item_idr ) as it_name "
        f" from items_det  where id={request.args(0)}")
    data = db.executesql(qry, as_dict=True)
    return response.json(data)
#====================================================================
def new_RetSupInvDet():
    try :
        data = request.vars
        items_det = db.items_det[data.item_id]
        total = float(data.item_count) * float(items_det.buy_price)
        total_2 = float(data.item_count) * float(items_det.public_price)
        nid = db.returned_supply_det.insert(
                        returned_supply=data.returned_supply  , 
                        item_count = data.item_count  ,
                        item_id = data.item_id ,
                        vat  =  items_det.vat  , 
                        inv_price = items_det.buy_price ,
                        inv_bay = items_det.public_price ,
                        total = total,
                        total_2 = total_2 ,
                        )
        inserted = db.returned_supply_det[nid]
        db.commit()
        qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply="+data.returned_supply+") ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply="+data.returned_supply+" ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply="+data.returned_supply+" ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply="+data.returned_supply+" ) "
            " where id = "+data.returned_supply
        )
        qs = db.executesql(qry)
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e
#====================================================================
def edit_RetSupInvDet():
    try :
        data = request.vars
        q = db.returned_supply[data.returned_supply]
        if q.admin_accept==False :
            edit_row = db.returned_supply_det[data.id]
            items_det = db.items_det[data.item_id]
            total = float(data.item_count) * float(items_det.buy_price)
            total_2 = float(data.item_count) * float(items_det.public_price)
            #
            edit_row.item_count = data.item_count  
            edit_row.item_name =  db.items_main[items_det.item_idr].name
            edit_row.item_id = data.item_id 
            edit_row.vat  =  items_det.vat  
            edit_row.inv_price = items_det.buy_price 
            edit_row.inv_bay = items_det.public_price 
            edit_row.total = total
            edit_row.total_2 = total_2 
            edit_row.update_record() 
            db.commit()
            qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply="+data.returned_supply+") ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply="+data.returned_supply+" ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply="+data.returned_supply+" ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply="+data.returned_supply+" ) "
            " where id = "+data.returned_supply
            )
            qs = db.executesql(qry)
            return response.json(edit_row)
        else :
            return response.json({'mess':'لايمكن الحفظ'})
    except Exception as e:
        db.rollback()
        print ( e )
        return e
#====================================================================
def delete_RetSupInvDet():
    try :
        edit_row = db.returned_supply_det[request.args(0)]
        q = db.returned_supply[edit_row.returned_supply]
        q_id = str(q.id)
        if q.admin_accept==False :
            edit_row.delete_record()
            db.commit()
            qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply="+q_id+") ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply="+q_id+" ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply="+q_id+" ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply="+q_id+" ) "
            " where id = "+q_id
            )
            qs = db.executesql(qry)
            return response.json("0")
        else :
            return response.json({'mess':'حصل خطأ'})
    except Exception as e:
        db.rollback()
        print ( e )
        return e


#================================================================
# ----------------->     suppliers_payment             <=========
#================================================================

def get_payment_type():
    q = db(db.key_payment_type.id > 0).select(db.key_payment_type.id,
                                             db.key_payment_type.name, orderby=[db.key_payment_type.id])
    return response.json(q)


def getSuppPyment():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where_1 = where_2 = where_3 = where_4 = ''
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where_1 = f" (  note like '%{srt[i]}%' or CAST (id   AS text) like '%{srt[i]}%' or CAST (supplier  AS text) like '%{srt[i]}%' or CAST (pay_total  AS text) like '%{srt[i]}%' or CAST (pay_date  AS text) like '%{srt[i]}%' ) "
            else:
                where_1 = where_1 + \
                    f" and (  note like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' or CAST (supplier  AS text) like '%{srt[i]}%' or CAST (pay_total  AS text) like '%{srt[i]}%' or CAST (pay_date  AS text) like '%{srt[i]}%' ) "
    if ReqVar.supplier:
        if ((ReqVar.supplier is not None) or (ReqVar.supplier != '')):
            where_2 = f"  ( supplier = {ReqVar.supplier}  ) "
    if ReqVar.types and (ReqVar.types != '0'):
        if ((ReqVar.types is not None) or (ReqVar.types != '')):
            where_3 = f"  ( payment_type = {ReqVar.types} ) "
    if len(where_1) > 0 or len(where_2) > 0 or len(where_3) > 0:
        where_4 = " where " + where_1 + " and " + where_2 + " and " + where_3
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'desc'
    else:
        sa = 'desc'
    pg = int(int(pg) * int(rc))
    where = where_4.replace('where  and', 'where')
    where = where.replace('where  and', 'where')
    where = where.replace('where  and', 'where')
    where = where.replace('and  and', 'and')
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq2 = "(select name from key_payment_type where id=payment_type) as t_name"
    subq5 = "(select name from key_payment_method where id=payment_method) as m_name"
    sql = (f" SELECT id,supplier, payment_method, payment_type,pay_total,pay_date,note,"
           f" {subq1} ,{subq2},{subq5} FROM suppliers_bills_pay "
           f" {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; ")
    sql = sql.replace('and  order', 'order')
    sql2 = f" SELECT count(*) FROM suppliers_bills_pay  {where}  ; "
    sql2 = sql2.replace('and   ;', '; ')
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)

#====================================================================
def new_SP():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        nid = db.suppliers_bills_pay.insert(
                        supplier=data.supplier , 
                        payment_method = data.payment_method ,
                        pay_date =  bill_date  , 
                        pay_total = data.pay_total ,
                        note = data.note   ,
                        payment_type = data.payment_type
                        )
        inserted = db.suppliers_bills_pay[nid]
        inserted.s_name = inserted.supplier.name
        inserted.m_name = inserted.payment_method.name
        inserted.t_name = inserted.payment_type.name
        db.commit()
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e
#------------------------------------------------------------------
def edit_SP():
    try :
        data = request.vars
        print(data)
        row = db.suppliers_bills_pay[data.id]
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        row.supplier=data.supplier 
        row.payment_method = data.payment_method
        row.pay_date =  bill_date  
        row.pay_total = data.pay_total
        row.note = data.note  
        row.payment_type = data.payment_type
        row.update_record()
        inserted = db.suppliers_bills_pay[data.id]
        inserted.s_name = inserted.supplier.name
        inserted.m_name = inserted.payment_method.name
        inserted.t_name = inserted.payment_type.name
        db.commit()
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e

#================================================================
# ----------------->     opening_balance               <=========
#================================================================

def get_opening_balance():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where = ''
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where = f" where (  CAST (supplier AS text)  like '%{srt[i]}%' or CAST (account AS text)  like '%{srt[i]}%' or CAST (year_balance AS text)  like '%{srt[i]}%'  ) "
            else:
                where = where + \
                    f" and ( CAST (supplier AS text) like '%{srt[i]}%' or  CAST (account AS text) like '%{srt[i]}%' or (year_balance AS text) like '%{srt[i]}%'   ) "
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'desc'
    else:
        sa = 'desc'
    pg = int(int(pg) * int(rc))
    where = where.replace('where  and', 'where')
    where = where.replace('where  and', 'where')
    where = where.replace('and  and', 'and')
    sql = (
            f" SELECT id,year_balance,supplier, account , note,"
            f" (select name from suppliers where id=supplier) as supplier_n "
            f"  FROM suppliers_opening_balance {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    )
    sql = sql.replace('and  order', 'order')
    sql2 = f" SELECT count(*) FROM suppliers_opening_balance  {where}  ; "
    sql2 = sql2.replace('and   ;', '; ')
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def new_o_b():
    try:
        data = request.vars
        data.supplier = json.loads(data.supplier)
        q = db(
            (db.suppliers_opening_balance.year_balance == data.year_balance) 
            & 
            (db.suppliers_opening_balance.supplier == data.supplier['value'])
            ).select()
        if (q) :
            return response.json({ "id":0 , "err":"هذا السجل مسجل مسبقا"})
        else :
            nid = db.suppliers_opening_balance.insert(
                supplier=data.supplier['value'],
                year_balance=data.year_balance,
                account=data.account,
                note=data.note
            )
            inserted = db.suppliers_opening_balance[nid]
            inserted.supplier_n = inserted.supplier.name
            db.commit()
            return response.json(inserted)
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"id": 0, "err": str(e) })


def edit_o_b():
    try:
        data = request.vars
        data.supplier = json.loads(data.supplier)
        row = db.suppliers_opening_balance[data.id]
        if (row.supplier != int(data.supplier['value'])) or (row.year_balance != int(data.year_balance)):
            q = db(
                (db.suppliers_opening_balance.year_balance == data.year_balance)
                &
                (db.suppliers_opening_balance.supplier == data.supplier['value'])
            ).select()
            if (q):
                return response.json({"id": 0, "err": "هذا السجل مسجل مسبقا"})
        row.supplier = data.supplier['value']
        row.year_balance = data.year_balance
        row.account = data.account
        row.note = data.note
        row.update_record()
        row.supplier_n = db.suppliers[data.supplier['value']].name
        edit_row = row.as_json()
        db.commit()
        return (edit_row)
    except Exception as e:
        db.rollback()
        return response.json({"id": 0, "err": str(e)})


#======================================================================
# ----->      suppliers_balance_reconciliation               <=========
#======================================================================

def get_B_R():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where_1 = where_2 = where_3 = where_4 = ''
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where_1 = f" (  note like '%{srt[i]}%' or CAST (id   AS text) like '%{srt[i]}%' or CAST (supplier  AS text) like '%{srt[i]}%' or CAST (balance_date  AS text) like '%{srt[i]}%' or CAST (balance_def  AS text) like '%{srt[i]}%' ) "
            else:
                where_1 = where_1 + \
                    f" and (  note like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' or CAST (supplier  AS text) like '%{srt[i]}%' or CAST (balance_date  AS text) like '%{srt[i]}%' or CAST (balance_def  AS text) like '%{srt[i]}%' ) "
    if ReqVar.supplier:
        if ((ReqVar.supplier is not None) or (ReqVar.supplier != '')):
            where_2 = f"  ( supplier = {ReqVar.supplier}  ) "
    if ReqVar.types and (ReqVar.types != '0'):
        if ((ReqVar.types is not None) or (ReqVar.types != '')):
            where_3 = f"  ( balance = {ReqVar.types} ) "
    if len(where_1) > 0 or len(where_2) > 0 or len(where_3) > 0:
        where_4 = " where " + where_1 + " and " + where_2 + " and " + where_3
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'desc'
    else:
        sa = 'desc'
    pg = int(int(pg) * int(rc))
    where = where_4.replace('where  and', 'where')
    where = where.replace('where  and', 'where')
    where = where.replace('where  and', 'where')
    where = where.replace('and  and', 'and')
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    sql = (f" SELECT id,supplier, balance_date ,balance ,balance_def ,note,"
           f" {subq1}  FROM suppliers_balance_reconciliation "
           f" {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; ")
    sql = sql.replace('and  order', 'order')
    sql2 = f" SELECT count(*) FROM suppliers_balance_reconciliation  {where}  ; "
    sql2 = sql2.replace('and   ;', '; ')
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)

def new_B_R():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        nid = db.suppliers_balance_reconciliation.insert(
                        supplier=data.supplier , 
                        balance = data.balance ,
                        balance_date =  bill_date  , 
                        balance_def = data.balance_def ,
                        note = data.note   ,
                        )
        inserted = db.suppliers_balance_reconciliation[nid]
        inserted.s_name = inserted.supplier.name
        db.commit()
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e

def edit_B_R():
    try :
        data = request.vars
        row = db.suppliers_balance_reconciliation[data.id]
        data.day = json.loads(data.day)
        #data.suppliers = json.loads(data.suppliers)
        if is_float(data.balance_def) == False :
            data.balance_def = 0 
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        row.supplier=data.supplier 
        row.payment_method = data.payment_method
        row.balance_date =  bill_date  
        row.balance = data.balance
        row.balance_def = data.balance_def or 0
        row.note = data.note  
        row.update_record()
        db.commit()
        inserted = db.suppliers_balance_reconciliation[data.id]
        inserted.s_name = db.suppliers[data.supplier].name
        #print(row)
        return response.json(inserted)
    except Exception as e:
        db.rollback()
        print ( e )
        return e

#------------------------------------------------------------------

def is_float(value):
  try:
    float(value)
    return True
  except:
    return False
