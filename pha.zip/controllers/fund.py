# -*- coding: utf-8 -*-
#  type: ignore


def index():
    return dict()


def get_movment():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where = ""
    if ReqVar.SearchText and ReqVar.SearchText != "":
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where = f" where ( detill like '%{srt[i]}%' or CAST (amount   AS text)  like '%{srt[i]}%' or CAST (process_date AS text) like '%{srt[i]}%' ) "
            else:
                where = (
                    where
                    + f" and ( detill like '%{srt[i]}%' or CAST (amount   AS text) like '%{srt[i]}%'  or  CAST (process_date AS text) like '%{srt[i]}%' ) "
                )
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = "id"
    if ReqVar.sequence:
        if ReqVar.sequence == "true":
            sa = "ASC"
        else:
            sa = "desc"
    else:
        sa = "ASC"
    pg = int(int(pg) * int(rc))
    where = where.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("and  and", "and")
    sql = f" SELECT *,0 as sum_total  FROM fund_movement  {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    sql = sql.replace("and  order", "order")
    sql2 = f" SELECT count(*) FROM fund_movement  {where}  ; "
    sql2 = sql2.replace("and   ;", "; ")
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def new_movment():
    try:
        data = request.vars
        nid = db.fund_movement.validate_and_insert(
            process_date=data.process_date,
            process_type=data.process_type,
            detill=data.detill,
            amount=data.amount,
            aprove=False,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(e)


def edit_movment():
    try:
        data = request.vars
        q = db.fund_movement[data.id]
        if q and q.aprove == False:
            q.process_date = data.process_date
            q.process_type = data.process_type
            q.detill = data.detill
            q.amount = data.amount
            q.update_record()
            db.commit()
            return response.json(q)
        else:
            return response.json({"mess": "لايمكن الحفظ"})
    except Exception as e:
        db.rollback()
        print(e)
        return e


def del_movment():
    try:
        del_row = db.fund_movement[request.args(0)]
        if del_row and del_row.aprove == False:
            del_row.delete_record()
            db.commit()
            return response.json({"mess": 1})
        else:
            return response.json({"mess": "حصل خطأ"})
    except Exception as e:
        db.rollback()
        print(e)
        return e


@auth.requires_membership("admin")
def aprove_movment():
    try:
        edi_row = db.fund_movement[request.args(0)]
        if edi_row:
            edi_row.aprove = not edi_row.aprove
            edi_row.update_record()
            db.commit()
            return response.json(edi_row)
        else:
            return response.json({"mess": "حصل خطأ"})
    except Exception as e:
        db.rollback()
        print(e)
        return e


def print():
    return dict()

# edit_row.delete_record()
"""
@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


"""
