# -*- coding: utf-8 -*-
#  type: ignore

from datetime import date, datetime, timedelta
import json
import os
import sys
import send_sms as sms
import httpx
import uuid
from decimal import Decimal, ROUND_HALF_UP
import invoice_zatca
import api_helpers as api

@can_access(4001)
def index():
    return dict()


# ! important to edit
# todo : crate new one
# ? => لازم نجربها بشكل اكبر
@can_access(4001, 4002, 4006)
def getco():
    arg = request.args(0)
    qry = "select * from customers where id=%s or mobile=%s"
    custdata = db.executesql(qry, placeholders=[arg, arg], as_dict=True)
    lastpay = 0
    if custdata:
        cust_id = int(custdata[0]["id"])
        qry = (
            "update customers set total = (select sum(total_after_discount) from invoice_master "
            " where payment_method=3 and customer = %s ) , "
            " payed=( select sum(amount) from customers_pay where customers_id = %s) , "
            " amount = (select sum(total_after_discount) from invoice_master where "
            " payment_method=3 and customer = %s ) "
            " -( select sum(amount) from customers_pay where customers_id = %s) "
            " where id = %s"
        )
        db.executesql(qry, placeholders=[cust_id, cust_id, cust_id, cust_id, cust_id])
        cus = (
            db(db.customers_pay.customers_id == cust_id)
            .select(
                db.customers_pay.ALL,
                orderby=~db.customers_pay.modified_on,
                limitby=(0, 1),
            )
            .first()
        )
        if cus:
            now = datetime.now()
            lastpay = (now - cus.modified_on).days
        else:
            lastpay = 0
        qry = "select * from customers where id=%s"
        custdata = db.executesql(qry, placeholders=[cust_id], as_dict=True)
        custdata[0]["lastpay"] = lastpay
        if custdata[0]["payed"] == None:
            custdata[0]["payed"] = 0
        if custdata[0]["amount"] == None:
            custdata[0]["amount"] = custdata[0]["payed"] * -1
    return response.json(api.api_ok(data=custdata))


@can_access(4001, 4002)
def get_payment_method():
    q = db(db.key_payment_method.id > 0).select()
    return response.json(api.api_ok(data=q))


@can_access(4001, 4002)
def getit():
    try:
        # qry = "select (select name from items_main where item_id= items_det.item_id limit 1) as name,* from items_det where id=" + request.vars.itid +" and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
        itid = str(request.vars.itid or "").strip()
        data = []
        if itid.isdigit():
            qry = (
                "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
                " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
                " supplier_inv  from items_det where id=%s"
            )
            data = db.executesql(qry, placeholders=[int(itid)], as_dict=True)
        if data:
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id=%s"
                    " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, placeholders=[qr.id], as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json(api.api_ok(data=[]))
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        else:
            qry = (
                "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
                " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
                " supplier_inv  from items_det where item_id=%s order by id desc  limit 1 "
            )
            data = db.executesql(qry, placeholders=[itid], as_dict=True)
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id=%s"
                    " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, placeholders=[qr.id], as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json(api.api_ok(data=[]))
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        return response.json(api.api_ok(data=data))
    except Exception as e:
        db.rollback()
        return response.json(api.api_ok(data=[]))


@can_access(4001)
def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(4001)
def invoice():
    return dict()


'''
    p = sms.SMS()
    ms = """
    halooooooo
    احمد بن محمد
    كيفك
    """
    print(p.send('966557565667', ms))
    print(p.getbalance())

'''
round_up = invoice_zatca.round_up


def _day_sales_total():
    """إجمالي مبالغ فواتير المبيعات (invoice_master) لليوم الحالي، من 00:00:00
    حتى 23:59:59. مصدر دائم لا يُحذف (بخلاف الجدول الوسيط invoice_sending الذي
    تُمسح صفوفه بعد الإرسال). تُستدعى بعد إدراج الفاتورة الحالية فتشملها."""
    now = datetime.now()
    start = datetime.combine(now.date(), datetime.min.time())
    end = datetime.combine(now.date(), datetime.max.time())
    s = db.invoice_master.total.sum()
    row = db(
        (db.invoice_master.created_on >= start)
        & (db.invoice_master.created_on <= end)
    ).select(s).first()
    return float((row[s] if row else 0) or 0)


def _change_count_threshold():
    """الحدّ الأقصى لإجمالي مبيعات اليوم المسموح بإرساله لزاتكا، من معلومات النظام
    (الحقل change_count_amount). القيمة 0 (أو أقل) تعني عدم وجود حدّ."""
    info = db(db.important_info.id > 0).select(
        db.important_info.change_count_amount, limitby=(0, 1)
    ).first()
    try:
        return float(info.change_count_amount or 0) if info else 0.0
    except Exception:
        return 0.0


def _queue_invoice_sending(skip_cap=False, **fields):
    """يُدرج الفاتورة في جدول الإرسال (invoice_sending) ما لم يتجاوز إجمالي مبيعات
    اليوم — المحسوب من invoice_master مباشرةً — الحدّ المعرّف في
    important_info.change_count_amount.
    - الحدّ ≤ 0 ⇒ لا قيود (إدراج دائمًا).
    - skip_cap=True ⇒ تجاوز الفحص كليًا (تُستخدم للمرتجعات: تُرسَل دائمًا)."""
    if not skip_cap:
        threshold = _change_count_threshold()
        if threshold > 0 and _day_sales_total() > threshold:
            return None
    return db.invoice_sending.insert(**fields)


def _payload_value(payload, key, default=None):
    try:
        return payload.get(key, default)
    except AttributeError:
        try:
            return payload[key]
        except Exception:
            return default


def _decimal_value(value):
    try:
        return round_up(value)
    except Exception:
        return None


def _validated_invoice_payload(payload, is_return=False):
    errors = []
    uuid_value = str(_payload_value(payload, "uuid", "") or "").strip()
    if not uuid_value:
        errors.append("رقم العملية غير موجود")

    try:
        customer_id = int(_payload_value(payload, "customer"))
    except (TypeError, ValueError):
        customer_id = 0
    if not customer_id or not db.customers(customer_id):
        errors.append("العميل غير صحيح")

    try:
        method_id = int(_payload_value(payload, "method"))
    except (TypeError, ValueError):
        method_id = 0
    if not method_id or not db.key_payment_method(method_id):
        errors.append("طريقة الدفع غير صحيحة")

    lines = _payload_value(payload, "itm", [])
    if isinstance(lines, str):
        try:
            lines = json.loads(lines)
        except Exception:
            lines = []
    if not isinstance(lines, list) or not lines:
        errors.append("لا توجد أصناف في الفاتورة")
        lines = []

    clean_lines = []
    for idx, line in enumerate(lines, start=1):
        if not isinstance(line, dict):
            errors.append("بيانات الصنف رقم {} غير صحيحة".format(idx))
            continue
        try:
            item_det_id = int(line.get("id"))
        except (TypeError, ValueError):
            item_det_id = 0
        item_det = db.items_det(item_det_id) if item_det_id else None
        if not item_det:
            errors.append("الصنف رقم {} غير موجود".format(idx))
            continue

        count = _decimal_value(line.get("count"))
        public_price = _decimal_value(line.get("public_price"))
        vat = _decimal_value(line.get("vat") or 0)
        if count is None or count <= 0:
            errors.append("كمية الصنف رقم {} يجب أن تكون أكبر من صفر".format(idx))
        if public_price is None or public_price < 0:
            errors.append("سعر الصنف رقم {} لا يمكن أن يكون سالباً".format(idx))
        if vat is None or vat < 0:
            errors.append("ضريبة الصنف رقم {} لا يمكن أن تكون سالبة".format(idx))
        if count is None or public_price is None or vat is None:
            continue

        # حارس الكمية: الخطأ الشائع هو إدخال رقم الصنف في خانة الكمية،
        # فينتج سطر بكمية فلكية يفسد الفاتورة والمخزون والتقارير معاً.
        # يُطبَّق على البيع والمرتجع.
        itm_main = db.items_main(item_det.item_idr)
        max_qty = stock_max_line_qty()
        if float(count) > max_qty:
            if stock_qty_looks_like_barcode(count, itm_main):
                errors.append(
                    "الصنف رقم {}: أدخلتَ رقم الصنف ({}) في خانة الكمية".format(
                        idx, (itm_main.item_id if itm_main else "")
                    )
                )
            else:
                errors.append(
                    "كمية الصنف رقم {} ({}) تتجاوز الحد المسموح ({})".format(
                        idx, count, int(max_qty)
                    )
                )
            continue
        # حماية السعر: يُمنع تعديل سعر الأصناف غير الموسومة "متغير السعر" (فواتير البيع فقط)
        if not is_return:
            is_flexible = bool(itm_main and itm_main.flexible_price)
            if not is_flexible:
                expected_price = float(item_det.public_price or 0)
                if item_det.vat_in_public_price:
                    det_vat = item_det.vat
                    if det_vat is None:
                        det_vat = (itm_main.vat if itm_main and itm_main.vat else 0) or 0
                    expected_price = round(expected_price / (float(det_vat) + 1), 2)
                if abs(float(public_price) - expected_price) > 0.005:
                    errors.append(
                        "سعر الصنف رقم {} لا يطابق السعر المسجل (الصنف غير متغير السعر)".format(idx)
                    )
                    continue
        clean_lines.append({
            "id": item_det_id,
            "item_main": item_det.item_idr,
            "name": line.get("name") or "صنف عام تجميل",
            "count": count,
            "public_price": public_price,
            "vat": vat,
        })

    return errors, {
        "uuid": uuid_value,
        "customer": customer_id,
        "method": method_id,
        "items": clean_lines,
    }


@can_access(4001)
def save():
    try:
        itm = request.vars
        errors, clean = _validated_invoice_payload(itm, is_return=False)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors), err=3, invno=0))
        qr = ""
        uuid = clean["uuid"]
        messg = ""
        warn = ""
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            return response.json(api.api_error(mess="تم حفظ هذه الفاتورة من", err="5", invno="0"))
        to = 0.0
        vat_to = 0.0
        TaxableAmount =0.0
        to_lien_sum = 0.0
        csr_config = db(db.csr_config.id > 0).select().first()

        # === قفل دفعات الأصناف ورصد البيع بدون رصيد ===
        # القفل (FOR UPDATE) يمنع التعارض التزامني بين أكثر من كاشير على نفس الصنف.
        #
        # البيع لا يُمنع أبداً: منعه يدفع العملية خارج الدفاتر — الصنف على الرف
        # والنظام يرفض، فيأخذ البائع المبلغ نقداً بلا فاتورة ولا أثر. فيتحول خلل
        # محاسبي (رصيد سالب يُصلحه الجرد) إلى سرقة لا تُسترد.
        # البديل: البيع يمر، والنقص يُسجَّل في stock_exception باسم البائع للمراجعة.
        item_ids = {int(i["item_main"]) for i in clean["items"]}
        batches = stock_lock_items(item_ids)
        needed = {}
        for i in clean["items"]:
            k = int(i["item_main"])
            needed[k] = needed.get(k, 0.0) + float(i["count"])
        oversells = []
        for main_id, qty in needed.items():
            # الأصناف الخدمية/الوهمية (مثل صنف "هللة") رصيدها سالب بطبيعتها
            if not stock_tracked(main_id):
                continue
            avail = stock_item_available(main_id, batches.get(main_id, []))
            if avail + 1e-9 < qty:
                oversells.append({"main": main_id, "qty": qty, "avail": avail})

        for i in clean["items"]:
            count = i["count"]
            public_price = i["public_price"]
            vat = i["vat"]
            # الخصم يمر من الوحدة المركزية: يعدّل الكمية ويسجّل الحركة معاً.
            # يبدأ من الدفعة التي اختارها الكاشير ثم يكمل من الأقرب انتهاءً.
            main_id = int(i["item_main"])
            plan, shortage = stock_plan_sale(
                batches.get(main_id, []), float(count), i["id"]
            )
            for det_row, qty in plan:
                stock_move(det_row, -qty, "بيع", "فاتورة بيع", uuid, float(public_price))
            if shortage > 1e-9:
                # لا يحدث إلا إذا سمح الإعداد الإداري بالبيع بدون رصيد
                pref = None
                for r in batches.get(main_id, []):
                    if int(r.id) == int(i["id"]):
                        pref = r
                        break
                stock_move(pref or i["id"], -shortage, "بيع", "فاتورة بيع",
                           uuid, float(public_price))
            vat_str = (vat * (count * public_price))
            vat_total = round_up(vat_str)
            total_str = vat_total + (count * public_price )
            total = round_up(total_str)
            if vat  > 0 :
                TaxableAmount = TaxableAmount + float(count * public_price)
            db.invoice_details.insert(
                item_number=i["id"],
                item_count=count,
                uuid=uuid,
                vat=vat,
                amount=public_price,
                total=total ,
                discount=0.0,
                total_after_discount=total ,
                vat_total=vat_total ,
            )
            i["total"] = total
            i["vat_mount"] = vat_total
            i["count"] = count
            i["public_price"] = public_price
            i["vat"] = vat
            to += float(total)
            vat_to += float(vat_total)
            line_str = (float(i["count"]) * float(i["public_price"]))
            to_line = round_up(line_str)
            to_lien_sum += float(to_line)
            i["LineExtensionAmount"] =  round_up(to_line)
        invno = db.invoice_master.insert(
            customer=clean["customer"],
            total=round_up(to)  ,
            payment_method=clean["method"],
            total_after_discount=round_up(to) ,
            uuid=uuid,
            vat=round_up(vat_to),
        )
        # تسجيل حالات البيع بدون رصيد باسم البائع (بعد معرفة رقم الفاتورة)
        for ov in oversells:
            first_det, unit_p = 0, 0
            for i in clean["items"]:
                if int(i["item_main"]) == int(ov["main"]):
                    first_det = i["id"]
                    unit_p = float(i["public_price"])
                    break
            stock_log_exception(
                invoice_uuid=uuid, invoice_no=invno, item_main=ov["main"],
                item_det=first_det, qty_requested=ov["qty"],
                qty_available=ov["avail"], unit_price=unit_p,
            )
        # تنبيه منفصل عن messg: الأخيرة تعرضها الواجهة تحت عنوان "خطأ"،
        # وهذه ملاحظة لا خطأ — الفاتورة حُفظت وطُبعت بشكل سليم.
        if oversells:
            warn = "الصنف بيع بدون رصيد كافٍ — سُجّلت الحالة للمراجعة"
        itm["uuid"] = uuid
        itm["customer"] = clean["customer"]
        itm["method"] = clean["method"]
        itm["itm"] = clean["items"]
        itm["total"] = to
        itm["vat"] = vat_to
        itm["LineExtensionAmount"] = to_lien_sum
        itm["TaxableAmount"] = round_up(TaxableAmount)
        itm["totalAfterAll"] = to
        db.commit()
        # === الفاتورة محفوظة الآن. أي خطوة جانبية تالية لا يجوز أن تُفشل الاستجابة ===
        re_ms = {}
        # إرسال SMS (غير حرج) — معزول حتى لا يُسقط الفاتورة المحفوظة
        try:
            costmer = db.customers[clean["customer"]]
            if costmer and costmer.mobile and len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS(sms_authorization, sms_sender)
                ms = (
                    "شكرا لزيارتك "
                    + configuration.name
                    + " تم شراء فاتورة بمبلغ "
                    + str(itm["totalAfterAll"] or "0.0")
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)
        except Exception:
            messg = (messg + " | " if messg else "") + "تعذّر إرسال الرسالة النصية"

        ##---------------  توقيع الفاتورة محلياً + تسجيلها في الجدول الوسيط (معزول أيضاً)
        try:
            if csr_config and csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0:
                inv_type = "SIMSI"
                itm["invoice_number"] = str(invno)
                json_inv = invoice_zatca.generate_invoice_json(db, itm, inv_type)
                json_inv_dict = json_inv if isinstance(json_inv, dict) else json.loads(json_inv)
                json_inv_dict["icv_start"] = int(csr_config.icv or 1)
                json_inv_dict["pih_base64"] = csr_config.pih or ""
                try:
                    from zatca_direct.invoice_processor import sign_only
                    sign_result = sign_only(json_inv_dict)
                    qr = sign_result.get("qr_value", "")
                    pih_txt = sign_result.get("pih_base64", "")
                    inv_update = db.invoice_master[invno]
                    inv_update.update_record(pih_txt=pih_txt, qr_code=qr)
                    icv_new = int(csr_config.icv or 0) + 1
                    csr_config.update_record(icv=icv_new, pih=pih_txt)
                except Exception as exc:
                    messg = str(exc)
                json_inv_str = json.dumps(json_inv_dict, ensure_ascii=False)
                _queue_invoice_sending(
                    inv_type=1,
                    inv_id=invno,
                    inv_date=datetime.now().strftime("%Y-%m-%d"),
                    inv_time=datetime.now().strftime("%H:%M:%S"),
                    inv_data=json_inv_str,
                    send=False,
                    total_sum=_day_sales_total(),
                )
                db.commit()
        except Exception as exc:
            db.rollback()
            messg = (messg + " | " if messg else "") + ("تعذّر تجهيز فاتورة الضريبة: " + str(exc))
        return response.json(api.api_ok(data={"invno": invno, "sms": re_ms, "qr": qr}, mess=messg, invno=invno, err=1, sms=re_ms, qr=qr, warn=warn))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


# =================================================================================================================================================
# مرتجع البيع
@can_access(4002)
def inv_return():
    return dict()


@can_access(4002)
def inv_return_save():
    try:
        return response.json(api.api_error(mess="not implemented", err=3, invno=0))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


@can_access(4002)
def saver():
    try:
        itm = request.vars
        errors, clean = _validated_invoice_payload(itm, is_return=True)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors), err=3, invno=0))
        qr = ""
        uuid = clean["uuid"]
        messg = ""
        fqry = db(db.inv_return_master.uuid == uuid).select()
        if fqry:
            return response.json(api.api_error(mess="تم حفظ هذه الفاتورة من", err="5", invno="0"))
        to = 0.0
        vat_to = 0.0
        TaxableAmount =0.0
        to_lien_sum = 0.0
        csr_config = db(db.csr_config.id > 0).select().first()
        for i in clean["items"]:
            count = i["count"]
            public_price = i["public_price"]
            vat = i["vat"]
            # الإرجاع يمر من الوحدة المركزية: يزيد الكمية ويسجّل الحركة معاً
            stock_move(i["id"], float(count), "مرتجع بيع", "مرتجع بيع",
                       uuid, float(public_price))
            vat_str = (vat * (count * public_price))
            vat_total = round_up(vat_str)
            total_str = vat_total + (count * public_price )
            total = round_up(total_str)
            if vat  > 0 :
                TaxableAmount = TaxableAmount + float(count * public_price)
            db.inv_return_details.insert(
                item_number=i["id"],
                item_count=count,
                uuid=uuid,
                vat=vat,
                amount=public_price,
                total=total ,
                discount=0.0,
                total_after_discount=total ,
                vat_total=vat_total ,
            )
            i["total"] = total
            i["vat_mount"] = vat_total
            i["count"] = count
            i["public_price"] = public_price
            i["vat"] = vat
            to += float(total)
            vat_to += float(vat_total)
            line_str = (float(i["count"]) * float(i["public_price"]))
            to_line = round_up(line_str)
            to_lien_sum += float(to_line)
            i["LineExtensionAmount"] =  round_up(to_line)
        invno = db.inv_return_master.insert(
            customer=clean["customer"],
            total=round_up(to)  ,
            payment_method=clean["method"],
            total_after_discount=round_up(to) ,
            uuid=uuid,
            vat=round_up(vat_to),
        )
        itm["uuid"] = uuid
        itm["customer"] = clean["customer"]
        itm["method"] = clean["method"]
        itm["itm"] = clean["items"]
        itm["total"] = to
        itm["vat"] = vat_to
        itm["LineExtensionAmount"] = to_lien_sum
        itm["TaxableAmount"] = round_up(TaxableAmount)
        itm["totalAfterAll"] = to
        db.commit()
        #=============================================  توقيع المرتجع محلياً + تسجيله في الجدول الوسيط
        if csr_config and csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0:
            inv_type = "SIMCN"
            itm["invoice_number"] = str(invno)
            json_inv = invoice_zatca.generate_invoice_json(db, itm, inv_type)
            json_inv_dict = json_inv if isinstance(json_inv, dict) else json.loads(json_inv)
            json_inv_dict["icv_start"] = int(csr_config.icv or 1)
            json_inv_dict["pih_base64"] = csr_config.pih or ""
            try:
                from zatca_direct.invoice_processor import sign_only
                sign_result = sign_only(json_inv_dict)
                qr = sign_result.get("qr_value", "")
                pih_txt = sign_result.get("pih_base64", "")
                inv_update = db.inv_return_master[invno]
                inv_update.update_record(pih_txt=pih_txt, qr_code=qr)
                icv_new = int(csr_config.icv or 0) + 1
                csr_config.update_record(icv=icv_new, pih=pih_txt)
            except Exception as exc:
                messg = str(exc)
            json_inv_str = json.dumps(json_inv_dict, ensure_ascii=False)
            _queue_invoice_sending(
                skip_cap=True,
                inv_type=2,
                inv_id=invno,
                inv_date=datetime.now().strftime("%Y-%m-%d"),
                inv_time=datetime.now().strftime("%H:%M:%S"),
                inv_data=json_inv_str,
                send=False,
                total_sum=_day_sales_total(),
            )
        db.commit()
        return response.json(api.api_ok(data={"invno": invno, "qr": qr}, mess=messg, invno=invno, err=1, qr=qr))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


# ==========================================       نهاية مرتجع البيع  ==============================================================================
# تقارير الفواتير و المبيعات
# -----------------------------------------------------------------------------


@can_access(8101)
def inv_rep1():
    return dict()


@can_access(8102)
def rep_bydate():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.invoice_master.created_on >= request.vars.da1)
        & (db.invoice_master.created_on <= request.vars.da2)
    ).select()
    return response.json(api.api_ok(data=s))


@can_access(8103)
def rep_bydate2():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.inv_return_master.created_on >= request.vars.da1)
        & (db.inv_return_master.created_on <= request.vars.da2)
    ).select()
    return response.json(api.api_ok(data=s))


@can_access(8104)
def rep_bydate3():
    # sum = db.invoice_master.total_after_discount.sum()
    s = (
        "select EXTRACT(HOUR FROM created_on),count(*),sum(total_after_discount) from invoice_master "
        " where created_on >= %s::timestamp and created_on <= %s::timestamp "
        " group by EXTRACT(HOUR FROM created_on) order by EXTRACT(HOUR FROM created_on) "
    )
    custdata = db.executesql(s, placeholders=[request.vars.da1, request.vars.da2], as_dict=True)
    return response.json(api.api_ok(data=custdata))


@can_access(4006)
def inv_view_1():
    if request.args(0) == "1":
        qry = db.invoice_master[request.args(1)]
        if qry:
            qry.pyer = (
                (qry.created_by.first_name or "")
                + " "
                + (qry.created_by.last_name or "")
            )
            data = db(
                (db.invoice_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.invoice_details.uuid == qry.uuid)
            ).select(
                (db.invoice_details.item_number).with_alias("item_number"),
                (db.invoice_details.amount).with_alias("amount"),
                (db.invoice_details.item_count).with_alias("item_count"),
                (db.invoice_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.invoice_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""
    else:
        qry = db.inv_return_master[request.args(1)]
        if qry:
            qry.pyer = qry.created_by.first_name + " " + qry.created_by.last_name
            data = db(
                (db.inv_return_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.inv_return_details.uuid == qry.uuid)
            ).select(
                (db.inv_return_details.item_number).with_alias("item_number"),
                (db.inv_return_details.amount).with_alias("amount"),
                (db.inv_return_details.item_count).with_alias("item_count"),
                (db.inv_return_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.inv_return_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""


@can_access(4006)
def inv_view_2():
    sc = screens_rules(4006)
    if sc.can_delete:
        if request.args(0) == "1":
            qry1 = db.invoice_master[request.args(1)]
            db(db.invoice_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"
        else:
            qry1 = db.inv_return_master[request.args(1)]
            db(db.inv_return_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"


# بحث عن عميل
@can_access(4001, 4002)
def search_c():
    # q = db.items_main[request.vars.itid]
    newstr = request.vars.itid  # .replace("'", "")
    # qry = "select * from items_main where name::text like '%"+str(newstr)+"%'  LIMIT 10 ;"
    q = db(db.customers.name.like("%" + newstr + "%")).select()
    return response.json(api.api_ok(data=q))


# =================================================================================================================================================
@can_access(4006)
def delete_inv():
    return dict()


@can_access(4004)
def invoice_show():
    return dict()


@can_access(4004)
def invoice_show_data():
    @api.api_safe(db_conn=db)
    def _do():
        page = max(int(request.vars.page or 0), 0)
        record_count = int(request.vars.RecordCount or 20)
        if record_count not in (20, 50, 100):
            record_count = 20
        search_text = (request.vars.SearchText or "").strip()
        zatca_status = request.vars.ZatcaStatus or "all"
        sort_by = request.vars.SortBy or "id"
        sort_asc = str(request.vars.sequence or "false").lower() in ("true", "1", "t")

        query = db.invoice_master.id > 0
        if zatca_status == "sent":
            query &= db.invoice_master.send_to_zatca == True
        elif zatca_status == "pending":
            query &= db.invoice_master.send_to_zatca == False

        if search_text:
            if search_text.isdigit():
                query &= db.invoice_master.id == int(search_text)
            else:
                query &= (
                    (db.invoice_master.customer == db.customers.id)
                    & db.customers.name.contains(search_text)
                )

        sort_map = {
            "id": db.invoice_master.id,
            "customer": db.customers.name,
            "payment_method": db.key_payment_method.name,
            "total_after_discount": db.invoice_master.total_after_discount,
            "vat": db.invoice_master.vat,
            "created_on": db.invoice_master.created_on,
            "send_to_zatca": db.invoice_master.send_to_zatca,
        }
        order_field = sort_map.get(sort_by, db.invoice_master.id)
        orderby = order_field if sort_asc else ~order_field
        left = [
            db.customers.on(db.customers.id == db.invoice_master.customer),
            db.key_payment_method.on(
                db.key_payment_method.id == db.invoice_master.payment_method
            ),
        ]
        total_count = db(query).count()
        rows = db(query).select(
            db.invoice_master.id,
            db.invoice_master.customer,
            db.invoice_master.payment_method,
            db.invoice_master.total_after_discount,
            db.invoice_master.vat,
            db.invoice_master.created_on,
            db.invoice_master.send_to_zatca,
            db.customers.name,
            db.key_payment_method.name,
            left=left,
            orderby=orderby,
            limitby=(page * record_count, (page + 1) * record_count),
        )

        data = []
        page_net = 0.0
        page_vat = 0.0
        page_sent = 0
        for row in rows:
            inv = row.invoice_master
            customer_name = row.customers.name if row.customers else ""
            payment_name = row.key_payment_method.name if row.key_payment_method else ""
            net = float(inv.total_after_discount or 0)
            vat = float(inv.vat or 0)
            sent = bool(inv.send_to_zatca)
            page_net += net
            page_vat += vat
            if sent:
                page_sent += 1
            data.append(
                {
                    "id": inv.id,
                    "customer": inv.customer,
                    "customer_name": customer_name,
                    "payment_method": inv.payment_method,
                    "payment_method_name": payment_name,
                    "total_after_discount": net,
                    "vat": vat,
                    "created_on": str(inv.created_on) if inv.created_on else "",
                    "send_to_zatca": sent,
                    "print_url": URL("invoice", "invoice_print", args=[inv.id]),
                    "zatca_status_url": URL("invoice", "show_zatca_status", args=[inv.id]),
                }
            )

        return api.api_list(
            rows=data,
            count=total_count,
            page_net=round(page_net, 2),
            page_vat=round(page_vat, 2),
            page_sent=page_sent,
        )

    return response.json(_do())


@can_access(4004)
def invoice_print():
    return dict()

@can_access(4004)
def show_zatca_status():
    get_inv = db.invoice_master(request.args(0))
    if not get_inv:
        return response.json(api.api_error(mess="لم يتم العثور على الفاتورة"))
    if not get_inv.zatca_res:
        return response.json(
            api.api_ok(data={"message": "لا توجد استجابة محفوظة من الزكاة لهذه الفاتورة"})
        )
    try:
        data = json.loads(get_inv.zatca_res)
    except Exception:
        data = {"raw": get_inv.zatca_res}
    return response.json(api.api_ok(data=data))

@can_access(4005)
def invoice_show_return():
    return dict()


@can_access(4005)
def invoice_show_return_data():
    @api.api_safe(db_conn=db)
    def _do():
        page = max(int(request.vars.page or 0), 0)
        record_count = int(request.vars.RecordCount or 20)
        if record_count not in (20, 50, 100):
            record_count = 20
        search_text = (request.vars.SearchText or "").strip()
        zatca_status = request.vars.ZatcaStatus or "all"
        sort_by = request.vars.SortBy or "id"
        sort_asc = str(request.vars.sequence or "false").lower() in ("true", "1", "t")

        query = db.inv_return_master.id > 0
        if zatca_status == "sent":
            query &= db.inv_return_master.send_to_zatca == True
        elif zatca_status == "pending":
            query &= db.inv_return_master.send_to_zatca == False

        if search_text:
            if search_text.isdigit():
                query &= db.inv_return_master.id == int(search_text)
            else:
                query &= (
                    (db.inv_return_master.customer == db.customers.id)
                    & db.customers.name.contains(search_text)
                )

        sort_map = {
            "id": db.inv_return_master.id,
            "customer": db.customers.name,
            "payment_method": db.key_payment_method.name,
            "total_after_discount": db.inv_return_master.total_after_discount,
            "vat": db.inv_return_master.vat,
            "created_on": db.inv_return_master.created_on,
            "send_to_zatca": db.inv_return_master.send_to_zatca,
        }
        order_field = sort_map.get(sort_by, db.inv_return_master.id)
        orderby = order_field if sort_asc else ~order_field
        left = [
            db.customers.on(db.customers.id == db.inv_return_master.customer),
            db.key_payment_method.on(
                db.key_payment_method.id == db.inv_return_master.payment_method
            ),
        ]
        total_count = db(query).count()
        rows = db(query).select(
            db.inv_return_master.id,
            db.inv_return_master.customer,
            db.inv_return_master.payment_method,
            db.inv_return_master.total_after_discount,
            db.inv_return_master.vat,
            db.inv_return_master.created_on,
            db.inv_return_master.send_to_zatca,
            db.customers.name,
            db.key_payment_method.name,
            left=left,
            orderby=orderby,
            limitby=(page * record_count, (page + 1) * record_count),
        )

        data = []
        page_net = 0.0
        page_vat = 0.0
        page_sent = 0
        for row in rows:
            inv = row.inv_return_master
            customer_name = row.customers.name if row.customers else ""
            payment_name = row.key_payment_method.name if row.key_payment_method else ""
            net = float(inv.total_after_discount or 0)
            vat = float(inv.vat or 0)
            sent = bool(inv.send_to_zatca)
            page_net += net
            page_vat += vat
            if sent:
                page_sent += 1
            data.append(
                {
                    "id": inv.id,
                    "customer": inv.customer,
                    "customer_name": customer_name,
                    "payment_method": inv.payment_method,
                    "payment_method_name": payment_name,
                    "total_after_discount": net,
                    "vat": vat,
                    "created_on": str(inv.created_on) if inv.created_on else "",
                    "send_to_zatca": sent,
                    "print_url": URL("invoice", "invoice_return_print", args=[inv.id]),
                    "zatca_status_url": URL(
                        "invoice", "show_return_zatca_status", args=[inv.id]
                    ),
                }
            )

        return api.api_list(
            rows=data,
            count=total_count,
            page_net=round(page_net, 2),
            page_vat=round(page_vat, 2),
            page_sent=page_sent,
        )

    return response.json(_do())


@can_access(4005)
def invoice_return_print():
    return dict()

@can_access(4005)
def show_return_zatca_status():
    get_inv = db.inv_return_master(request.args(0))
    if not get_inv:
        return response.json(api.api_error(mess="لم يتم العثور على فاتورة المرتجع"))
    if not get_inv.zatca_res:
        return response.json(
            api.api_ok(data={"message": "لا توجد استجابة محفوظة من الزكاة لهذا المرتجع"})
        )
    try:
        data = json.loads(get_inv.zatca_res)
    except Exception:
        data = {"raw": get_inv.zatca_res}
    return response.json(api.api_ok(data=data))

