# -*- coding: utf-8 -*-
#  type: ignore
# script_dir = os.path.dirname(__file__)
# sms_dir = os.path.join(script_dir, '..', 'scripts')
# sys.path.append(sms_dir)

from datetime import date, datetime
import json
import os
import sys
import send_sms as sms
import httpx
import uuid
from decimal import Decimal, ROUND_HALF_UP



def round_json_values(data):
    """
    دالة تقوم بالمرور على كائن JSON (سواء كان قاموس أو قائمة)
    وتقرب أي قيمة عشرية (float) إلى خانتين بدقة مالية.
    """
    
    # 1. إذا كان العنصر قاموس (Dict)
    if isinstance(data, dict):
        return {k: round_json_values(v) for k, v in data.items()}
    
    # 2. إذا كان العنصر قائمة (List)
    elif isinstance(data, list):
        return [round_json_values(i) for i in data]
    
    # 3. إذا كان العنصر رقم عشري (Float)
    elif isinstance(data, float):
        # استخدام Decimal لضمان التقريب المالي الصحيح (مثل 1.005 يصبح 1.01)
        # نحوله لنص أولاً لتجنب مشاكل الفواصل العائمة
        d = Decimal(str(data))
        rounded = d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return float(rounded)
    
    # 4. إذا كان أي شيء آخر (نص، رقم صحيح، بولين) يرجع كما هو
    return data

@can_access(4001)
def index():
    return dict()


# ! important to edit
# todo : crate new one
# ? => لازم نجربها بشكل اكبر
def getco():
    qry = (
        "select * from customers where id="
        + request.args(0)
        + " or mobile='"
        + request.args(0)
        + "'"
    )  # db.customers[request.args(0)] #
    custdata = db.executesql(qry, as_dict=True)
    lastpay = 0
    if custdata:
        qry = (
            "update customers set total = (select sum(total_after_discount) from invoice_master "
            " where payment_method=3 and customer ="
            + str(custdata[0]["id"])
            + " ) , payed=( select sum(amount) "
            " from customers_pay where customers_id =" + str(custdata[0]["id"]) + ") , "
            " amount = (select sum(total_after_discount) from invoice_master where "
            " payment_method=3 and customer ="
            + str(custdata[0]["id"])
            + " ) -( select sum(amount) "
            " from customers_pay where customers_id ="
            + str(custdata[0]["id"])
            + ")  where "
            "id = " + str(custdata[0]["id"])
        )
        db.executesql(qry)
        # print (qry)
        cus = (
            db(db.customers_pay.customers_id == custdata[0]["id"])
            .select(
                db.customers_pay.ALL,
                orderby=~db.customers_pay.modified_on,
                limitby=(0, 1),
            )
            .first()
        )
        # print(cus)
        if cus:
            now = datetime.now()
            lastpay = (now - cus.modified_on).days
        else:
            lastpay = 0
        qry = "select * from customers where id=" + str(custdata[0]["id"])
        custdata = db.executesql(qry, as_dict=True)
        custdata[0]["lastpay"] = lastpay
        if custdata[0]["payed"] == None:
            custdata[0]["payed"] = 0
        if custdata[0]["amount"] == None:
            custdata[0]["amount"] = custdata[0]["payed"] * -1
    return response.json(custdata)


def get_payment_method():
    q = db(db.key_payment_method.id > 0).select()
    return response.json(q)


def getit():
    try:
        # qry = "select (select name from items_main where item_id= items_det.item_id limit 1) as name,* from items_det where id=" + request.vars.itid +" and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
        qry = (
            "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
            " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
            " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
            " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
            " supplier_inv  from items_det where id=" + request.vars.itid
        )
        data = db.executesql(qry, as_dict=True)
        if data:
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id="
                    + str(qr.id)
                    + " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json([])
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        else:
            qry = (
                "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
                " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
                " supplier_inv  from items_det where item_id='"
                + request.vars.itid
                + "' order by id desc  limit 1 "
            )
            data = db.executesql(qry, as_dict=True)
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id="
                    + str(qr.id)
                    + " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json([])
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        return response.json(data)
    except Exception as e:
        db.rollback()
        # print e
        ret = []
        return response.json(ret)


def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("user1")
def invoice():
    return dict()


'''
    p = sms.SMS()
    ms = """
    halooooooo
    احمد بن محمد
    كيفك
    """
    print(p.send('966557565667', ms))
    print(p.getbalance())

'''
def round_up(x):
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

@can_access(4001)
def save():
    try:
        itm = request.vars
        qr = ""
        uuid = itm["uuid"]
        messg = ""
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        vat_to = 0.0
        to_lien_sum = 0.0
        csr_config = db(db.csr_config.id > 0).select().first()
        for i in itm["itm"]:
            it = db.items_det(i["id"])
            if it.items_count != None:
                db.items_det[i["id"]] = dict(
                    items_count=it.items_count - float(i["count"])
                )
            count = round_up(i["count"])
            public_price = round_up(i["public_price"])
            vat = round_up(i["vat"])
            total_str = ((count * public_price) + (count * public_price * vat))
            total = Decimal(str(total_str)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            vat_str = (vat * (count * public_price))
            vat_total = Decimal(str(vat_str)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            db.invoice_details.insert(
                item_number=i["id"],
                item_count=count,
                uuid=uuid,
                vat=vat,
                amount=public_price,
                total=total ,
                discount=0.0,
                total_after_discount=total ,
                vat_total=vat_total ,
            )
            i["total"] = total
            i["vat_mount"] = vat_total
            i["count"] = count
            i["public_price"] = public_price
            i["vat"] = vat
            to += float(total)  
            vat_to += float(vat_total)
            line_str = (float(i["count"]) * float(i["public_price"]))
            to_line = Decimal(str(line_str)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            to_lien_sum += float(to_line)
        invno = db.invoice_master.insert(
            customer=itm["customer"],
            total=to  ,
            payment_method=itm["method"],
            total_after_discount=to ,
            uuid=uuid,
            vat=vat_to,
        )
        itm["total"] = to 
        itm["vat"] = vat_to
        itm["LineExtensionAmount"] = to_lien_sum
        itm["totalAfterAll"] = to
        db.commit()
        costmer = db.customers[itm["customer"]]
        re_ms = {}
        if costmer.mobile:
            if len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS()
                ms = (
                    "شكرا لزيارتك "
                    + configuration.name
                    + " تم شراء فاتورة بمبلغ "
                    + (itm["totalAfterAll"] or "0.0")
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)
        
        ##---------------  معالجة الفاتورة في زاتكا
        # ==========  احضار qr code   ========
        if csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0 :
            sim_invoce = True
            inv_type = "SIMSI"
            headers = {}
            headers["Content-Type"] = "application/json"
            headers["accept"] = "application/json"
            itm["invoice_number"] = str(invno)
            # cleaned_data = round_json_values(itm)
            # json_string = json.dumps(cleaned_data, ensure_ascii=False, indent=4)
            # print(json_string)
            json_inv = generate_invoice_json(itm, inv_type)
            url = csr_config.api_site + "/zatca/process-simplified"        
            #url = csr_config.api_site + "/zatca/process-one"
            try :
                resp = httpx.post(url, json=json_inv, headers=headers )
                qr_data = resp.json()
                inv_update = db.invoice_master[invno]
                inv_update.update_record(
                pih_txt=qr_data.get("pih_base64", ""), 
                qr_code=qr_data.get("qr_value", "")
                )
                db.invoice_sending.insert(
                    inv_type = 1,
                    inv_id=invno,
                    inv_date=datetime.now().strftime("%Y-%m-%d"),
                    inv_time=datetime.now().strftime("%H:%M:%S"),
                    inv_data=json_inv,
                    send=False
                )
                qr = qr_data.get("qr_value", "")
            except Exception as exc:
                qr = ""
                messg = str(exc)
        db.commit()        
        ret = {"err": 1, "invno": invno, "mess": messg , "sms": re_ms,"qr":qr }
        return response.json(ret)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


# =================================================================================================================================================
# مرتجع البيع
@can_access(4002)
def inv_return():
    return dict()


@can_access(4002)
def inv_return_save():
    try:
        ret = {"err": 3, "invno": 0, "mess": e}
        return gluon.contrib.simplejson.dumps(ret)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": e}
        return gluon.contrib.simplejson.dumps(ret)


@can_access(4002)
def saver():
    try:
        qr = ""
        messg = ""
        csr_config = db(db.csr_config.id > 0).select().first()
        itm = request.vars
        uuid = itm["uuid"]
        to = 0.0
        vat_to = 0.0
        to_lien_sum = 0.0
        for i in itm["itm"]:
            it = db.items_det(i["id"])
            if it.items_count != None:
                db.items_det[i["id"]] = dict(
                    items_count=it.items_count + float(i["count"])
                )
            count = round_up(i["count"])
            public_price = round_up(i["public_price"])
            vat = round_up(i["vat"])
            total_str = ((count * public_price) + (count * public_price * vat))
            total = Decimal(str(total_str)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            vat_str = (vat * (count * public_price))
            vat_total = Decimal(str(vat_str)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            db.inv_return_details.insert(
                item_number=i["id"],
                item_count=count,
                uuid=uuid ,
                vat=vat,
                amount=public_price,
                total=total ,
                discount=0.0,
                total_after_discount=total ,
                vat_total=vat_total ,
            )
            i["total"] = total
            i["vat_mount"] = vat_total
            i["count"] = count
            i["public_price"] = public_price
            i["vat"] = vat
            to += float(total)  
            vat_to += float(vat_total)
            line_str = (float(i["count"]) * float(i["public_price"]))
            to_line = Decimal(str(line_str)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            to_lien_sum += float(to_line)
        invno = db.inv_return_master.insert(
            customer=itm["customer"],
            total=to,
            payment_method=itm["method"],
            total_after_discount=to,
            uuid=uuid ,
            vat=vat_to,
        )
        itm["total"] = to 
        itm["vat"] = vat_to
        itm["LineExtensionAmount"] = to_lien_sum
        itm["totalAfterAll"] = to
        db.commit()
        #=============================================  طلب qr code 
        if csr_config.pcsid_requestid and len(csr_config.pcsid_requestid) > 0 :
            sim_invoce = True
            inv_type = "SIMCN"
            headers = {}
            headers["Content-Type"] = "application/json"
            headers["accept"] = "application/json"
            itm["invoice_number"] = str(invno)
            json_inv = generate_invoice_json(itm, inv_type)
            # json_string = json.dumps(json_inv, ensure_ascii=False, indent=4)
            # print(json_string)
            url = csr_config.api_site + "/zatca/process-simplified"     
            try:   
                resp = httpx.post(url, json=json_inv, headers=headers)
                if resp.status_code == 200:
                    qr_data = resp.json()
                    inv_update = db.inv_return_master[invno]
                    inv_update.update_record(
                    pih_txt=qr_data.get("pih_base64", ""), 
                    qr_code=qr_data.get("qr_value", "")
                    )
                db.invoice_sending.insert(
                    inv_type = 2,
                    inv_id=invno,
                    inv_date=datetime.now().strftime("%Y-%m-%d"),
                    inv_time=datetime.now().strftime("%H:%M:%S"),
                    inv_data=json_inv,
                    send=False
                )
                qr = qr_data.get("qr_value", "")
            except Exception as exc:
                qr = ""
                messg = str(exc)
        db.commit()        
        ret = {"err": 1, "invno": invno, "mess": messg, "qr":qr }
        return response.json(ret)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


# ==========================================       نهاية مرتجع البيع  ==============================================================================
# تقارير الفواتير و المبيعات
# -----------------------------------------------------------------------------


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def inv_rep1():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.invoice_master.created_on >= request.vars.da1)
        & (db.invoice_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate2():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.inv_return_master.created_on >= request.vars.da1)
        & (db.inv_return_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate3():
    # sum = db.invoice_master.total_after_discount.sum()
    s = (
        "select EXTRACT(HOUR FROM created_on),count(*),sum(total_after_discount) from invoice_master where created_on >= timestamp '"
        + request.vars.da1
        + "' and created_on <= timestamp '"
        + request.vars.da2
        + "'  group by EXTRACT(HOUR FROM created_on) order by EXTRACT(HOUR FROM created_on) "
    )
    custdata = db.executesql(s, as_dict=True)
    return response.json(custdata)


# ==============================================================  استعراض فاتورة مسجلة  =================================================================
@can_access(4003)
def inv_view():
    sc = screens_rules(4003)
    return dict(sc=sc)


@can_access(4003)
def inv_view_1():
    if request.args(0) == "1":
        qry = db.invoice_master[request.args(1)]
        if qry:
            qry.pyer = (
                (qry.created_by.first_name or "")
                + " "
                + (qry.created_by.last_name or "")
            )
            data = db(
                (db.invoice_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.invoice_details.uuid == qry.uuid)
            ).select(
                (db.invoice_details.item_number).with_alias("item_number"),
                (db.invoice_details.amount).with_alias("amount"),
                (db.invoice_details.item_count).with_alias("item_count"),
                (db.invoice_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.invoice_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""
    else:
        qry = db.inv_return_master[request.args(1)]
        if qry:
            qry.pyer = qry.created_by.first_name + " " + qry.created_by.last_name
            data = db(
                (db.inv_return_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.inv_return_details.uuid == qry.uuid)
            ).select(
                (db.inv_return_details.item_number).with_alias("item_number"),
                (db.inv_return_details.amount).with_alias("amount"),
                (db.inv_return_details.item_count).with_alias("item_count"),
                (db.inv_return_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.inv_return_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""


@can_access(4003)
def inv_view_2():
    sc = screens_rules(4003)
    if sc.can_delete:
        if request.args(0) == "1":
            qry1 = db.invoice_master[request.args(1)]
            db(db.invoice_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"
        else:
            qry1 = db.inv_return_master[request.args(1)]
            db(db.inv_return_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"


# بحث عن عميل
def search_c():
    # q = db.items_main[request.vars.itid]
    newstr = request.vars.itid  # .replace("'", "")
    # qry = "select * from items_main where name::text like '%"+str(newstr)+"%'  LIMIT 10 ;"
    q = db(db.customers.name.like("%" + newstr + "%")).select()
    # data = db.executesql(qry, as_dict=True)
    return response.json(q)
    # return q


# =================================================================================================================================================
@auth.requires_membership("user1")
def delete_inv():
    return dict()


def invoice_show():
    q = db.invoice_master.customer
    db.invoice_master.created_on.readable = True
    headers = {
        "invoice_master.id": "رقم الفاتورة",
        "invoice_master.customer": "العميل",
        "invoice_master.payment_method": "طريقة الدفع",
        "invoice_master.total_after_discount": "صافي الفااتورة",
        "invoice_master.vat": "الضريبة",
        "invoice_master.created_on": "تاريخ و وقت الفاتورة",
    }
    fields = [
        db.invoice_master.id,
        db.invoice_master.customer,
        db.invoice_master.payment_method,
        db.invoice_master.total_after_discount,
        db.invoice_master.vat,
        db.invoice_master.created_on,
    ]
    links = [
        lambda row: A(
            IMG(_src="../static/svg/045-printer.svg", _width="24px"),
            _role="button",
            _title="استعراض القيد",
            _target="_blank",
            _href=URL("invoice", "invoice_print", args=[row.id]),
        ),
    ]
    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.invoice_master.id,
    )
    return dict(grid=grid)


def invoice_print():
    return dict()


##===========================================================#
## ->  close_periods <-  ##
def close_periods():
    return dict()


def close_periods_add():
    try:
        row = request.vars
        k_total = (
            float(row.kashir_amount_cash)
            + float(row.kashir_amount_atm)
            + float(row.kashir_amount_delay)
        )
        k_total = round(k_total, 2)
        s = (
            "select  "
            " sum(total_after_discount) as u_total from invoice_master "
            f" where (created_on >= '{row.start_time}' "
            f" and created_on <= '{row.end_time}' "
            f" and created_by={auth.user.id} ) group by created_by  "
        )
        data = db.executesql(s, as_dict=True)
        if data:
            difference = k_total - float(data[0]["u_total"])
            app_total = data[0]["u_total"]
        else:
            app_total = 0
            difference = k_total - 0
        new_row = db.closing_shift.validate_and_insert(
            pha_user=auth.user.id,
            start_time=row.start_time,
            end_time=row.end_time,
            kashir_amount_cash=row.kashir_amount_cash,
            kashir_amount_atm=row.kashir_amount_atm,
            kashir_amount_delay=row.kashir_amount_delay,
            kashir_note=row.kashir_note,
            kashir_total=k_total,
            app_total=app_total,
            app_amount_cash=app_total,
            app_amount_atm=0,
            app_amount_delay=0,
            accountant_aprove=False,
            difference=round(difference, 2),
        )
        return response.json(new_row)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)

    # app_amount_cash= row.,
    # app_amount_atm= row.,
    # app_amount_delay= row.,
    # app_total= row.,


def close_periods_get():
    if auth.has_membership("account"):
        tod = datetime.datetime.now()
        d = datetime.timedelta(days = 7 )
        a = tod - d
        data = db((db.closing_shift.end_time > a)).select(
            db.closing_shift.id,
            db.closing_shift.start_time,
            db.closing_shift.end_time,
            db.closing_shift.kashir_amount_cash,
            db.closing_shift.kashir_amount_atm,
            db.closing_shift.kashir_amount_delay,
            db.closing_shift.kashir_note,
            db.closing_shift.kashir_total,
            db.closing_shift.pha_user,
            db.closing_shift.accountant_aprove,
        )
        for row in data:
            uuser = db.auth_user[row.pha_user]
            row["user_name"] = uuser.first_name + " " + uuser.last_name
            row.cash = row.kashir_amount_cash
            row.kashir_amount_cash = 0
            row.kashir_amount_atm = 0
            row.kashir_amount_delay = 0
            row.kashir_total = 0

        return response.json(data)
    else:
        data = db(
            (db.closing_shift.pha_user == auth.user.id)
            & (db.closing_shift.accountant_aprove == False)
        ).select(
            db.closing_shift.id,
            db.closing_shift.start_time,
            db.closing_shift.end_time,
            db.closing_shift.kashir_amount_cash,
            db.closing_shift.kashir_amount_atm,
            db.closing_shift.kashir_amount_delay,
            db.closing_shift.kashir_note,
            db.closing_shift.kashir_total,
            db.closing_shift.pha_user,
        )
        for row in data:
            uuser = db.auth_user[row.pha_user]
            row["user_name"] = uuser.first_name + " " + uuser.last_name
        return response.json(data)


def close_periods_edit():
    try:
        if auth.has_membership("account"):
            row = request.vars
            if row.kashir_amount_cash == row.cash:
                edit_row = db.closing_shift[row.id]
                edit_row.accountant_aprove = True
                edit_row.update_record()
                return response.json(row)
        else :
            row = request.vars
            k_total = (
                float(row.kashir_amount_cash)
                + float(row.kashir_amount_atm)
                + float(row.kashir_amount_delay)
            )
            k_total = round(k_total, 2)
            s = (
                "select  "
                " sum(total_after_discount) as u_total from invoice_master "
                f" where (created_on >= '{row.start_time}' "
                f" and created_on <= '{row.end_time}' "
                f" and created_by={auth.user.id} ) group by created_by  "
            )
            data = db.executesql(s, as_dict=True)
            if data:
                difference = k_total - float(data[0]["u_total"])
                app_total = data[0]["u_total"]
            else:
                app_total = 0
                difference = k_total - 0
            edit_row = db.closing_shift[row.id]
            edit_row.pha_user = auth.user.id
            edit_row.start_time = row.start_time
            edit_row.end_time = row.end_time
            edit_row.kashir_amount_cash = row.kashir_amount_cash
            edit_row.kashir_amount_atm = row.kashir_amount_atm
            edit_row.kashir_amount_delay = row.kashir_amount_delay
            edit_row.kashir_note = row.kashir_note
            edit_row.kashir_total = k_total
            edit_row.app_total = app_total
            edit_row.app_amount_cash = app_total
            edit_row.app_amount_atm = 0
            edit_row.app_amount_delay = 0
            edit_row.accountant_aprove = False
            edit_row.difference = round(difference, 2)
            edit_row.update_record()
            myrecord = (
                db(db.closing_shift.id == row.id)
                .select(
                    db.closing_shift.id,
                    db.closing_shift.start_time,
                    db.closing_shift.end_time,
                    db.closing_shift.kashir_amount_cash,
                    db.closing_shift.kashir_amount_atm,
                    db.closing_shift.kashir_amount_delay,
                    db.closing_shift.kashir_note,
                    db.closing_shift.kashir_total,
                )
                .first()
            )
            return response.json(myrecord)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)


def close_periods_delete():
    try:
        delete_row = db.closing_shift[request.args(0)]
        if delete_row:
            if (
                delete_row.pha_user == auth.user.id
                and delete_row.accountant_aprove == False
            ):
                delete_row.delete_record()
                db.commit()
                return response.json({"mess": 1})
            else:
                return response.json({"mess": 0})
        else:
            return response.json({"mess": 0})
    except Exception as e:
        db.rollback()
        print(e)
        ret = {print(e)}
        return response.json(ret)


def print_close_period():
    return dict()



data = {
    "cert_info": {
        "privateKey": "",
        "csr": "",
        "pcsid_binarySecurityToken": "",
        "pcsid_secret": "",
        "environment": "Simulation",
        "reportingUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/reporting/single",
        "clearanceUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/clearance/single"
    },
    "input_xml": {
        "xml_template_path": "xxx.xml"
    },
    "document_type": "SIMSI",
    "invoice_number": "DOC-0001",
    "icv_start": 1,
    "pih_base64": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
    "invoice": {
        "ProfileID": "reporting:1.0",
        "ID": "SME00011",
        "UUID": "8e6000cf-1a98-4500-b3e7-b5d5954bc10d",
        "IssueDate": "2025-11-25",
        "IssueTime": "02:30:08",
        "InvoiceTypeCode": "388",
        "InvoiceTypeCodeName": "0200000",
        "Note": "",
        "DocumentCurrencyCode": "SAR",
        "TaxCurrencyCode": "SAR",
        "BillingReference": "",
        "AdditionalDocumentReferences": [
            {
                "ID": "ICV",
                "UUID": "10"
            },
            {
                "ID": "PIH",
                "Attachment": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
                "FileName": "pih.txt"
            }
        ],
        "SupplierStreetName": "1234 Street",
        "SupplierBuildingNumber": "2322",
        "SupplierCityName": "Riyadh",
        "SupplierDistrict": "Al-Murabba",
        "SupplierPostalZone": "23333",
        "SupplierCountryCode": "SA",
        "SupplierVAT": "",
        "SupplierName": "",
        "SupplierSchemeID": "CRN",
        "SupplierCRN": "",
        "CustomerStreetName": "*",
        "CustomerBuildingNumber": "1111",
        "CustomerCityName": "*",
        "CustomerDistrict": "*",
        "CustomerPostalZone": "12345",
        "CustomerCountryCode": "SA",
        "CustomerVAT": "",
        "CustomerName": "****",
        "CustomerCRN": "",
        "DeliveryDate": "2025-01-01",
        "PaymentMeansCode": "10",
        "AllowanceCharge": {
            "ChargeIndicator": "False",
            "Reason": "discount",
            "Amount": 0.00,
            "TaxCategories": [
                {"ID": "S", "Percent": 15, "SchemeID": "VAT"}
            ]
        },
        "InvoiceLines": [
            {
                "ID": "1",
                "UnitCode": "PCE",
                "Quantity": 33,
                "LineExtensionAmount": 99.00,
                "TaxAmount": 14.85,
                "RoundingAmount": 113.85,
                "Name": "book",
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": 3.00,
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00
                }
            },
            {
                "ID": "2",
                "UnitCode": "PCE",
                "Quantity": 3,
                "LineExtensionAmount": 102.00,
                "TaxAmount": 15.30,
                "RoundingAmount": 117.30,
                "Name": "قلم",
                "TaxCategoryID": "S",
                "TaxPercent": 15.00,
                "PriceAmount": 34.00,
                "AllowanceCharge": {
                    "ChargeIndicator": "False",
                    "Reason": "discount",
                    "Amount": 0.00
                }
            }
        ],
        "TaxAmount": 30.15,
        "TaxableAmount": 201.00,
        "TaxPercent": 15.00,
        "LineExtensionAmount": 201.00,
        "TaxExclusiveAmount": 201.00,
        "TaxInclusiveAmount": 231.15,
        "AllowanceTotalAmount": 0.00,
        "PrepaidAmount": 0.00,
        "PayableAmount": 231.15
    }
}

def generate_invoice_json(invo:dict, invtype:str) :
    try :
        #impo_info = db(db.important_info.id > 0).select().first()
        csr_config = db(db.csr_config.id > 0).select().first()
        now = datetime.now()
        environment_type = csr_config.environment
        if environment_type.lower() == "nonproduction":
            api_path = "developer-portal"
        elif environment_type.lower() == "simulation":
            api_path = "simulation"
        elif environment_type.lower() == "production":
            api_path = "core"
        # last_invo = 0
        # if invtype.endswith("SI") :
        #     max_no = db.invoice_master.id.max()
        #     last_invo = db(db.invoice_master.id > 0).select(max_no).first()[max_no] or 0
        # else :
        #     max_no = db.inv_return_master.id.max()
        #     last_invo = db(db.inv_return_master.id > 0).select(max_no).first()[max_no] or 0 

        invoce = invo
        re_data = data
        re_data["cert_info"]["privateKey"] = csr_config.privatekey
        re_data["cert_info"]["csr"] = csr_config.csr
        re_data["cert_info"]["pcsid_binarySecurityToken"] = csr_config.pcsid_binarysecuritytoken
        re_data["cert_info"]["pcsid_secret"] = csr_config.pcsid_secret
        re_data["cert_info"]["environment"] = csr_config.environment  # "Simulation"
        re_data["cert_info"]["reportingUrl"] = (
            f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
        )
        re_data["cert_info"]["clearanceUrl"] = (
            f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single"
        )
        re_data["document_type"] = invtype
        re_data["invoice_number"] = "INV-" + invoce["invoice_number"].zfill(12)
        re_data["invoice"]["ID"] = "INV-" + invoce["invoice_number"].zfill(12)
        re_data["invoice"]["UUID"] = invoce.uuid
        re_data["invoice"]["IssueDate"] = now.strftime("%Y-%m-%d") # invoce.created_on.strftime("%Y-%m-%d")
        re_data["invoice"]["IssueTime"] = now.strftime("%H:%M:%S") # invoce.created_on.strftime("%H:%M:%S")
        re_data["invoice"]["AdditionalDocumentReferences"][0]["UUID"] = str(csr_config.icv) # ICV
        re_data["invoice"]["AdditionalDocumentReferences"][1]["Attachment"] = csr_config.pih # PIH
        # معلومات المورد
        re_data["invoice"]["SupplierStreetName"] = csr_config.address_street_name
        re_data["invoice"]["SupplierBuildingNumber"] = csr_config.address_building_number
        re_data["invoice"]["SupplierCityName"] = csr_config.address_city_name
        re_data["invoice"]["SupplierDistrict"] = csr_config.address_neighborhood
        re_data["invoice"]["SupplierPostalZone"] = csr_config.address_postal_zone
        re_data["invoice"]["SupplierVAT"] = csr_config.organization_identifier
        re_data["invoice"]["SupplierName"] = csr_config.organization_name
        re_data["invoice"]["SupplierCRN"] = csr_config.company_id
        # معلومات العميل
        if invtype.startswith("STD") :
            if invoce.customer > 1:
                customer = db.customers[invoce.customer]
                re_data["invoice"]["CustomerStreetName"]=  "main"
                re_data["invoice"]["CustomerBuildingNumber"]= "1111"
                re_data["invoice"]["CustomerCityName"]= "my city"
                re_data["invoice"]["CustomerDistrict"]= "my dist"
                re_data["invoice"]["CustomerPostalZone"]= "12345"
                re_data["invoice"]["CustomerCountryCode"]= "SA"
                re_data["invoice"]["CustomerVAT"]= customer.vat
                re_data["invoice"]["CustomerName"]= customer.name
                re_data["invoice"]["CustomerCRN"]= customer.crn
        re_data["invoice"]["PaymentMeansCode"] = "1"  # غير محددة
        # تفاصيل الاصناف
        # inv_items = db(db.invoice_details.uuid == invoce.uuid).select()
        inv_lines = []
        line_id = 1
        # print("=============================================================")
        # i["total"] = total
        # i["vat_mount"]
        for item in invoce.itm :
            if item["vat"] > 0 :
                line = {
                    "ID": str(item["id"]),
                    "UnitCode": "PCE",
                    "Quantity": float(item["count"]),
                    "LineExtensionAmount": round((float(item["total"]) - float(item["vat_mount"])),2) ,
                    "TaxAmount": float(item["vat_mount"]),
                    "RoundingAmount": float(item["total"]),
                    "Name": item["name"],
                    "TaxCategoryID": "S",
                    "TaxPercent": 15.00,
                    "PriceAmount": float(item["public_price"]) ,
                    "AllowanceCharge": {
                        "ChargeIndicator": "False",
                        "Reason": "discount",
                        "Amount": 0.00,
                    },
                }
            else :
                line = {
                    "ID": str(item["id"]),
                    "UnitCode": "PCE",
                    "Quantity": float(item["count"]),
                    "LineExtensionAmount": round((float(item["total"]) - float(item["vat_mount"])),2) ,
                    "TaxAmount": 0.00,
                    "RoundingAmount": float(item["total"]),
                    "Name": item["name"],
                    "TaxCategoryID": "Z",
                    "TaxPercent": 0.00,
                    "PriceAmount": float(item["public_price"]) ,
                    "AllowanceCharge": {
                        "ChargeIndicator": "False",
                        "Reason": "discount",
                        "Amount": 0.00,
                    },
                }
            inv_lines.append(line)
            line_id += 1

        re_data["invoice"]["InvoiceLines"] = inv_lines
        # القيم المالية
        re_data["invoice"]["TaxAmount"] = float(invoce.vat)
        re_data["invoice"]["TaxableAmount"] = float(invoce.totalAfterDiscount)
        re_data["invoice"]["TaxPercent"] = 15.00
        re_data["invoice"]["LineExtensionAmount"] = float(invoce.LineExtensionAmount)
        re_data["invoice"]["TaxExclusiveAmount"] = float(invoce.LineExtensionAmount)
        re_data["invoice"]["TaxInclusiveAmount"] = float(invoce.totalAfterAll)
        re_data["invoice"]["AllowanceTotalAmount"] = 0.00
        re_data["invoice"]["PayableAmount"] = float(invoce.totalAfterAll)
        # formatted_json = json.dumps(re_data, indent=4, ensure_ascii=False)
        # print(formatted_json)
        return re_data
    except Exception as e:
        print(f"error{e}")
        return str(e)
