# -*- coding: utf-8 -*-
#  type: ignore
# script_dir = os.path.dirname(__file__)
# sms_dir = os.path.join(script_dir, '..', 'scripts')
# sys.path.append(sms_dir)

from datetime import date
import os
import sys
import send_sms as sms


@can_access(4001)
def index():
    return dict()


# ! important to edit
# todo : crate new one
# ? => لازم نجربها بشكل اكبر
def getco():
    qry = (
        "select * from customers where id="
        + request.args(0)
        + " or mobile='"
        + request.args(0)
        + "'"
    )  # db.customers[request.args(0)] #
    custdata = db.executesql(qry, as_dict=True)
    lastpay = 0
    if custdata:
        qry = (
            "update customers set total = (select sum(total_after_discount) from invoice_master "
            " where payment_method=3 and customer ="
            + str(custdata[0]["id"])
            + " ) , payed=( select sum(amount) "
            " from customers_pay where customers_id =" + str(custdata[0]["id"]) + ") , "
            " amount = (select sum(total_after_discount) from invoice_master where "
            " payment_method=3 and customer ="
            + str(custdata[0]["id"])
            + " ) -( select sum(amount) "
            " from customers_pay where customers_id ="
            + str(custdata[0]["id"])
            + ")  where "
            "id = " + str(custdata[0]["id"])
        )
        db.executesql(qry)
        # print (qry)
        cus = (
            db(db.customers_pay.customers_id == custdata[0]["id"])
            .select(
                db.customers_pay.ALL,
                orderby=~db.customers_pay.modified_on,
                limitby=(0, 1),
            )
            .first()
        )
        # print(cus)
        if cus:
            now = datetime.datetime.now()
            lastpay = (now - cus.modified_on).days
        else:
            lastpay = 0
        qry = "select * from customers where id=" + str(custdata[0]["id"])
        custdata = db.executesql(qry, as_dict=True)
        custdata[0]["lastpay"] = lastpay
        if custdata[0]["payed"] == None:
            custdata[0]["payed"] = 0
        if custdata[0]["amount"] == None:
            custdata[0]["amount"] = custdata[0]["payed"] * -1
    return response.json(custdata)


def get_payment_method():
    q = db(db.key_payment_method.id > 0).select()
    return response.json(q)


def getit():
    try:
        # qry = "select (select name from items_main where item_id= items_det.item_id limit 1) as name,* from items_det where id=" + request.vars.itid +" and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
        qry = (
            "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
            " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
            " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
            " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
            " supplier_inv  from items_det where id=" + request.vars.itid
        )
        data = db.executesql(qry, as_dict=True)
        if data:
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id="
                    + str(qr.id)
                    + " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json([])
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        else:
            qry = (
                "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                " ,( select flexible_price from items_main where item_id=items_det.item_id limit 1 ) as flexible_price "
                " , expiration_date , id ,is_active ,item_id ,item_idr ,public_price,vat ,vat_in_public_price ,vat_price , "
                " supplier_inv  from items_det where item_id='"
                + request.vars.itid
                + "' order by id desc  limit 1 "
            )
            data = db.executesql(qry, as_dict=True)
            if data[0]["bill_confirmation"] == "F":
                qr = (
                    db(
                        (db.items_det.item_idr == data[0]["item_idr"])
                        & (db.items_det.supplier_inv != data[0]["supplier_inv"])
                    )
                    .select(orderby=~db.items_det.id)
                    .first()
                )
                qry = (
                    "select (select name from items_main where item_id= items_det.item_id limit 1) as name "
                    " ,( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) as bill_confirmation "
                    " , * from items_det where id="
                    + str(qr.id)
                    + " and ( select bill_confirmation from suppliers_bills where id=items_det.supplier_inv ) = 'T' "
                )
                data_new = db.executesql(qry, as_dict=True)
                if data[0]["vat_in_public_price"] == "T":
                    new_price = round(
                        (data[0]["public_price"] / (data[0]["vat"] + 1)), 2
                    )
                    data[0]["public_price"] = new_price
                if data[0]["public_price"] != data_new[0]["public_price"]:
                    return response.json([])
                else:
                    data = data_new
            if len(data) > 0:
                itm_det = db.items_det[data[0]["id"]]
                if data[0]["vat"] is None:
                    itm_main = db.items_main[data[0]["item_idr"]]

                    if itm_main.vat:
                        data[0]["vat"] = itm_main.vat
                        itm_det.vat = itm_main.vat
                    else:
                        data[0]["vat"] = 0
                        itm_det.vat = 0
                itm_det.update_record()
            if data[0]["vat_in_public_price"] == "T":
                new_price = round((data[0]["public_price"] / (data[0]["vat"] + 1)), 2)
                data[0]["public_price"] = new_price
        return response.json(data)
    except Exception as e:
        db.rollback()
        # print e
        ret = []
        return response.json(ret)


def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("user1")
def invoice():
    return dict()


'''
    p = sms.SMS()
    ms = """
    halooooooo
    احمد بن محمد
    كيفك
    """
    print(p.send('966557565667', ms))
    print(p.getbalance())

'''


@can_access(4001)
def save():
    try:
        # import uuid
        itm = request.vars
        uuid = itm["uuid"]
        fqry = db(db.invoice_master.uuid == uuid).select()
        if fqry:
            ret = {"err": "5", "invno": "0", "mess": "تم حفظ هذه الفاتورة من"}
            return response.json(ret)
        to = 0.0
        for i in itm["itm"]:
            it = db.items_det(i["id"])
            if it.items_count != None:
                db.items_det[i["id"]] = dict(
                    items_count=it.items_count - float(i["count"])
                )
            total = round(
                (
                    (float(i["count"]) * float(i["public_price"]))
                    + (float(i["count"]) * float(i["public_price"]) * float(i["vat"]))
                ),
                2,
            )
            total_after_discount = round(
                (
                    (float(i["count"]) * float(i["public_price"]))
                    + (float(i["count"]) * float(i["public_price"]) * float(i["vat"]))
                ),
                2,
            )
            vat_total = round(
                (float(i["vat"] * (float(i["count"]) * float(i["public_price"])))), 2
            )
            db.invoice_details.insert(
                item_number=i["id"],
                item_count=float(i["count"]),
                uuid=uuid,
                vat=i["vat"],
                amount=float(i["public_price"]),
                total=total,
                discount=0.0,
                total_after_discount=total_after_discount,
                vat_total=vat_total,
            )
            to += (float(i["count"]) * float(i["public_price"])) + (
                float(i["count"]) * float(i["public_price"]) * float(i["vat"])
            )
        # print '===================================='
        # print to
        # print round( to , 2 )
        # print round(float(itm["totalAfterAll"]),2)
        # print '===================================='
        if (round(to, 2) - round(float(itm["totalAfterAll"]), 2)) > 1:
            db.rollback()
            ret = {"err": "2", "invno": "0", "mess": to}
            return response.json(ret)
        invno = db.invoice_master.insert(
            customer=itm["customer"],
            total=itm["totalAfterAll"],
            payment_method=itm["method"],
            total_after_discount=itm["totalAfterAll"],
            uuid=uuid,
            vat=itm["vat"],
        )
        db.commit()
        costmer = db.customers[itm["customer"]]
        re_ms = {}
        if costmer.mobile:
            if len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS()
                ms = (
                    "شكرا لزيارتك "
                    + configuration.name
                    + " تم شراء فاتورة بمبلغ "
                    + (itm["totalAfterAll"] or "0.0")
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)
        ret = {"err": 1, "invno": invno, "mess": "0", "sms": re_ms}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


# =================================================================================================================================================
# مرتجع البيع
@can_access(4002)
def inv_return():
    return dict()


@can_access(4002)
def inv_return_save():
    try:
        ret = {"err": 3, "invno": 0, "mess": e}
        return gluon.contrib.simplejson.dumps(ret)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": e}
        return gluon.contrib.simplejson.dumps(ret)


@can_access(4002)
def saver():
    try:
        import uuid

        itm = request.vars
        uuid = uuid.uuid4()
        to = 0.0
        for i in itm["itm"]:
            it = db.items_det(i["id"])
            if it.items_count != None:
                db.items_det[i["id"]] = dict(
                    items_count=it.items_count + float(i["count"])
                )
            db.inv_return_details.insert(
                item_number=i["id"],
                item_count=float(i["count"]),
                uuid=uuid,
                vat=i["vat"],
                amount=float(i["public_price"]),
                total=(float(i["count"]) * float(i["public_price"]))
                + (float(i["count"]) * float(i["public_price"]) * float(i["vat"])),
                discount=0.0,
                total_after_discount=(float(i["count"]) * float(i["public_price"]))
                + (float(i["count"]) * float(i["public_price"]) * float(i["vat"])),
                vat_total=float(
                    i["vat"] * (float(i["count"]) * float(i["public_price"]))
                ),
            )
            to += (float(i["count"]) * float(i["public_price"])) + (
                float(i["count"]) * float(i["public_price"]) * float(i["vat"])
            )
        if round(to, 0) != round(float(itm["totalAfterAll"]), 0):
            db.rollback()
            ret = {"err": "2", "invno": "0", "mess": to}
            return response.json(ret)
        invno = db.inv_return_master.insert(
            customer=itm["customer"],
            total=itm["totalAfterAll"],
            payment_method=itm["method"],
            total_after_discount=itm["totalAfterAll"],
            uuid=uuid,
            vat=itm["vat"],
        )
        db.commit()
        ret = {"err": 1, "invno": invno, "mess": "0"}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


# ==========================================       نهاية مرتجع البيع  ==============================================================================
# تقارير الفواتير و المبيعات
# -----------------------------------------------------------------------------


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def inv_rep1():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.invoice_master.created_on >= request.vars.da1)
        & (db.invoice_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate2():
    # sum = db.invoice_master.total_after_discount.sum()
    s = db(
        (db.inv_return_master.created_on >= request.vars.da1)
        & (db.inv_return_master.created_on <= request.vars.da2)
    ).select()
    return response.json(s)


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep_bydate3():
    # sum = db.invoice_master.total_after_discount.sum()
    s = (
        "select EXTRACT(HOUR FROM created_on),count(*),sum(total_after_discount) from invoice_master where created_on >= timestamp '"
        + request.vars.da1
        + "' and created_on <= timestamp '"
        + request.vars.da2
        + "'  group by EXTRACT(HOUR FROM created_on) order by EXTRACT(HOUR FROM created_on) "
    )
    custdata = db.executesql(s, as_dict=True)
    return response.json(custdata)


# ==============================================================  استعراض فاتورة مسجلة  =================================================================
@can_access(4003)
def inv_view():
    sc = screens_rules(4003)
    return dict(sc=sc)


@can_access(4003)
def inv_view_1():
    if request.args(0) == "1":
        qry = db.invoice_master[request.args(1)]
        if qry:
            qry.pyer = (
                (qry.created_by.first_name or "")
                + " "
                + (qry.created_by.last_name or "")
            )
            data = db(
                (db.invoice_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.invoice_details.uuid == qry.uuid)
            ).select(
                (db.invoice_details.item_number).with_alias("item_number"),
                (db.invoice_details.amount).with_alias("amount"),
                (db.invoice_details.item_count).with_alias("item_count"),
                (db.invoice_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.invoice_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""
    else:
        qry = db.inv_return_master[request.args(1)]
        if qry:
            qry.pyer = qry.created_by.first_name + " " + qry.created_by.last_name
            data = db(
                (db.inv_return_details.item_number == db.items_det.id)
                & (db.items_det.item_idr == db.items_main.id)
                & (db.inv_return_details.uuid == qry.uuid)
            ).select(
                (db.inv_return_details.item_number).with_alias("item_number"),
                (db.inv_return_details.amount).with_alias("amount"),
                (db.inv_return_details.item_count).with_alias("item_count"),
                (db.inv_return_details.total).with_alias("total"),
                (db.items_det.item_idr).with_alias("item_idr"),
                (db.items_main.name).with_alias("name"),
                (db.inv_return_details.vat_total).with_alias("vat_total"),
            )
            qry.itm = response.json(data)
            return response.json(qry)
        else:
            return ""


@can_access(4003)
def inv_view_2():
    sc = screens_rules(4003)
    if sc.can_delete:
        if request.args(0) == "1":
            qry1 = db.invoice_master[request.args(1)]
            db(db.invoice_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"
        else:
            qry1 = db.inv_return_master[request.args(1)]
            db(db.inv_return_details.uuid == qry1.uuid).delete()
            qry1.delete_record()
            return "1"


# بحث عن عميل
def search_c():
    # q = db.items_main[request.vars.itid]
    newstr = request.vars.itid  # .replace("'", "")
    # qry = "select * from items_main where name::text like '%"+str(newstr)+"%'  LIMIT 10 ;"
    q = db(db.customers.name.like("%" + newstr + "%")).select()
    # data = db.executesql(qry, as_dict=True)
    return response.json(q)
    # return q


# =================================================================================================================================================
@auth.requires_membership("user1")
def delete_inv():
    return dict()


def invoice_show():
    q = db.invoice_master.customer
    db.invoice_master.created_on.readable = True
    headers = {
        "invoice_master.id": "رقم الفاتورة",
        "invoice_master.customer": "العميل",
        "invoice_master.payment_method": "طريقة الدفع",
        "invoice_master.total_after_discount": "صافي الفااتورة",
        "invoice_master.vat": "الضريبة",
        "invoice_master.created_on": "تاريخ و وقت الفاتورة",
    }
    fields = [
        db.invoice_master.id,
        db.invoice_master.customer,
        db.invoice_master.payment_method,
        db.invoice_master.total_after_discount,
        db.invoice_master.vat,
        db.invoice_master.created_on,
    ]
    links = [
        lambda row: A(
            IMG(_src="../static/svg/view_file2.svg", _width="24px"),
            _role="button",
            _title="استعراض القيد",
            _target="_blank",
            _href=URL("invoice", "invoice_print", args=[row.id]),
        ),
    ]
    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=False,
        deletable=False,
        create=False,
        csv=False,
        searchable=False,
        showbuttontext=False,
        orderby=~db.invoice_master.id,
    )
    return dict(grid=grid)


def invoice_print():
    return dict()


##===========================================================#
## ->  close_periods <-  ##
def close_periods():
    return dict()


def close_periods_add():
    try:
        row = request.vars
        k_total = (
            float(row.kashir_amount_cash)
            + float(row.kashir_amount_atm)
            + float(row.kashir_amount_delay)
        )
        k_total = round(k_total, 2)
        s = (
            "select  "
            " sum(total_after_discount) as u_total from invoice_master "
            f" where (created_on >= '{row.start_time}' "
            f" and created_on <= '{row.end_time}' "
            f" and created_by={auth.user.id} ) group by created_by  "
        )
        data = db.executesql(s, as_dict=True)
        if data:
            difference = k_total - float(data[0]["u_total"])
            app_total = data[0]["u_total"]
        else:
            app_total = 0
            difference = k_total - 0
        new_row = db.closing_shift.validate_and_insert(
            pha_user=auth.user.id,
            start_time=row.start_time,
            end_time=row.end_time,
            kashir_amount_cash=row.kashir_amount_cash,
            kashir_amount_atm=row.kashir_amount_atm,
            kashir_amount_delay=row.kashir_amount_delay,
            kashir_note=row.kashir_note,
            kashir_total=k_total,
            app_total=app_total,
            app_amount_cash=app_total,
            app_amount_atm=0,
            app_amount_delay=0,
            accountant_aprove=False,
            difference=round(difference, 2),
        )
        return response.json(new_row)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)

    # app_amount_cash= row.,
    # app_amount_atm= row.,
    # app_amount_delay= row.,
    # app_total= row.,


def close_periods_get():
    if auth.has_membership("account"):
        tod = datetime.datetime.now()
        d = datetime.timedelta(days = 7 )
        a = tod - d
        data = db((db.closing_shift.end_time > a)).select(
            db.closing_shift.id,
            db.closing_shift.start_time,
            db.closing_shift.end_time,
            db.closing_shift.kashir_amount_cash,
            db.closing_shift.kashir_amount_atm,
            db.closing_shift.kashir_amount_delay,
            db.closing_shift.kashir_note,
            db.closing_shift.kashir_total,
            db.closing_shift.pha_user,
            db.closing_shift.accountant_aprove,
        )
        for row in data:
            uuser = db.auth_user[row.pha_user]
            row["user_name"] = uuser.first_name + " " + uuser.last_name
            row.cash = row.kashir_amount_cash
            row.kashir_amount_cash = 0
            row.kashir_amount_atm = 0
            row.kashir_amount_delay = 0
            row.kashir_total = 0

        return response.json(data)
    else:
        data = db(
            (db.closing_shift.pha_user == auth.user.id)
            & (db.closing_shift.accountant_aprove == False)
        ).select(
            db.closing_shift.id,
            db.closing_shift.start_time,
            db.closing_shift.end_time,
            db.closing_shift.kashir_amount_cash,
            db.closing_shift.kashir_amount_atm,
            db.closing_shift.kashir_amount_delay,
            db.closing_shift.kashir_note,
            db.closing_shift.kashir_total,
            db.closing_shift.pha_user,
        )
        for row in data:
            uuser = db.auth_user[row.pha_user]
            row["user_name"] = uuser.first_name + " " + uuser.last_name
        return response.json(data)


def close_periods_edit():
    try:
        if auth.has_membership("account"):
            row = request.vars
            if row.kashir_amount_cash == row.cash:
                edit_row = db.closing_shift[row.id]
                edit_row.accountant_aprove = True
                edit_row.update_record()
                return response.json(row)
        else :
            row = request.vars
            k_total = (
                float(row.kashir_amount_cash)
                + float(row.kashir_amount_atm)
                + float(row.kashir_amount_delay)
            )
            k_total = round(k_total, 2)
            s = (
                "select  "
                " sum(total_after_discount) as u_total from invoice_master "
                f" where (created_on >= '{row.start_time}' "
                f" and created_on <= '{row.end_time}' "
                f" and created_by={auth.user.id} ) group by created_by  "
            )
            data = db.executesql(s, as_dict=True)
            if data:
                difference = k_total - float(data[0]["u_total"])
                app_total = data[0]["u_total"]
            else:
                app_total = 0
                difference = k_total - 0
            edit_row = db.closing_shift[row.id]
            edit_row.pha_user = auth.user.id
            edit_row.start_time = row.start_time
            edit_row.end_time = row.end_time
            edit_row.kashir_amount_cash = row.kashir_amount_cash
            edit_row.kashir_amount_atm = row.kashir_amount_atm
            edit_row.kashir_amount_delay = row.kashir_amount_delay
            edit_row.kashir_note = row.kashir_note
            edit_row.kashir_total = k_total
            edit_row.app_total = app_total
            edit_row.app_amount_cash = app_total
            edit_row.app_amount_atm = 0
            edit_row.app_amount_delay = 0
            edit_row.accountant_aprove = False
            edit_row.difference = round(difference, 2)
            edit_row.update_record()
            myrecord = (
                db(db.closing_shift.id == row.id)
                .select(
                    db.closing_shift.id,
                    db.closing_shift.start_time,
                    db.closing_shift.end_time,
                    db.closing_shift.kashir_amount_cash,
                    db.closing_shift.kashir_amount_atm,
                    db.closing_shift.kashir_amount_delay,
                    db.closing_shift.kashir_note,
                    db.closing_shift.kashir_total,
                )
                .first()
            )
            return response.json(myrecord)
    except Exception as e:
        db.rollback()
        print(e)
        ret = []
        return response.json(ret)


def close_periods_delete():
    try:
        delete_row = db.closing_shift[request.args(0)]
        if delete_row:
            if (
                delete_row.pha_user == auth.user.id
                and delete_row.accountant_aprove == False
            ):
                delete_row.delete_record()
                db.commit()
                return response.json({"mess": 1})
            else:
                return response.json({"mess": 0})
        else:
            return response.json({"mess": 0})
    except Exception as e:
        db.rollback()
        print(e)
        ret = {print(e)}
        return response.json(ret)


def print_close_period():
    return dict()
