# -*- coding: utf-8 -*-
#  type: ignore
import math
import threading

_lock = threading.RLock()


@can_access(3001)
def main():
    sc = screens_rules(3001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


def t1():
    return dict()


@can_access(3006)
def new_items_det():
    return dict()


# ==============================================
# ==============================================
# ==============================================
# ==============================================
# ==============================================


@auth.requires_membership("user1")
def det_items():
    return dict()


# ++++++++++++++++++++++
@auth.requires_membership("user1")
def get_itm_2():
    qry = (
        "select (select name from items_main where item_id= items_det.item_id limit 1) as name , (select name from suppliers where id=(select supplier from suppliers_bills where id= items_det.supplier_inv )) as supp , *  from items_det where id ="
        + str(request.args(0))
        + " ;"
    )
    qs = db.executesql(qry, as_dict=True)
    return response.json(qs)


# ----------------------------------------------------------------------------------------------------------
@auth.requires_membership("admin")
def main_it():
    headers = {"main_items.item_id": "رقم الصنف", "main_items.name": "اسم الصنف"}
    fields = [db.main_items.item_id, db.main_items.name]
    return dict(
        grid=SQLFORM.grid(
            db.main_items,
            user_signature=False,
            headers=headers,
            fields=fields,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=False,
            maxtextlengths={"main_items.name": 200},
        )
    )


@can_access(3004)
def de_it():
    return dict()


@can_access(3005)
def it_inv():
    it_inv = db.suppliers_bills(request.args(0))
    if it_inv == None:
        redirect(URL("not_inv"))
    if it_inv.bill_confirmation == True:
        redirect(URL("not_inv"))
    return dict()


def not_inv():
    return dict(message="لا يوجد فاتورة بهذا الرقم")


@auth.requires_membership("user1")
def inter():
    return dict()


# ---------------------------------------------------------------------------------------------
#    دوال شاشة اضافة الأصناف


@auth.requires_membership("user1")
def mit():
    qry = (
        "select item_id,name from main_items where name like '%"
        + request.vars.it
        + "%' LIMIT 15;"
    )
    qs = db.executesql(qry, as_dict=True)
    return response.json(qs)


@auth.requires_membership("user1")
def t():
    qry = "select sum(inv_price) from items_det where supplier_inv = 1 ;"
    qs = db.executesql(qry)
    # s = db(db.items_det(db.items_det.supplier_inv==1)).select()
    # inv_p = db.items_det.inv_price.sum()
    return str(qs[(0)])


@can_access(2013)
def it_prt():
    db1 = db(
        (db.items_det.item_id == db.items_main.item_id)
        & (db.items_det.supplier_inv == request.args(0))
    ).select(
        db.items_det.item_id,
        db.items_det.id,
        db.items_main.name,
        db.items_det.items_count,
        db.items_det.public_price,
        db.items_det.vat,
        db.items_det.vat_in_public_price,
        db.items_det.quantity,
        orderby=db.items_det.id,
    )
    for r in db1:
        r.items_det.public_price = round(
            (r.items_det.public_price * r.items_det.vat) + r.items_det.public_price, 2
        )
        r.items_det.items_count = r.items_det.quantity
        if r.items_det.vat_in_public_price == True:
            new_price = round((r.items_det.public_price / (r.items_det.vat + 1)), 2)
            r.items_det.public_price = new_price
    return str(db1)


def it_prt_by_item():
    # q1 = db(db.items_main.item_id == request.args(0))
    try:
        itm1 = db(db.items_main.id == request.args(0)).select().first()
        itm2 = db(db.items_det.item_idr == itm1.id).select().last()
        db1 = db(
            (db.items_det.item_id == db.items_main.item_id)
            & (db.items_det.supplier_inv == itm2.supplier_inv)
            & (db.items_det.id == itm2.id)
        ).select(
            db.items_det.item_id,
            db.items_det.id,
            db.items_main.name,
            db.items_det.items_count,
            db.items_det.public_price,
        )
        return str(db1)
    except Exception as e:
        print(e)
        return str("رقم الصنف المدخل خطأ ، الرجاء ادخال الرقم الدولي ")


@can_access(2012)
def it_rep1():
    return dict()


def it_rep2():
    return dict()


@can_access(3009)
def rep_bydate():
    return dict()


def rep_bydatej():
    qry = (
        "select (select upper(trim(name)) from items_main where id= items_det.item_idr ) as name ,  "
        " ( select name from key_type where id= (select item_type from items_main where id=item_idr ) )  "
        " as item_type , *   "
        " from items_det where expiration_date < (current_date + "
        + str(request.args(0))
        + ") and "
        " expiration_date >(current_date -20) and  items_count>0 order by expiration_date;"
    )
    qs = db.executesql(qry, as_dict=True)
    return response.json(qs)


# =================================================================================================
@auth.requires(auth.has_membership("admin"))
def conf_inv():
    inv = request.args(0)
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv="
        + inv
        + "  )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv="
        + inv
        + "  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/ "
        " CASE sum(inv_price) WHEN 0 THEN 1 ELSE sum(inv_price) END )* CASE sum(inv_price) WHEN 0 THEN 1 ELSE 100 END from items_det where supplier_inv="
        + inv
        + "  )) "
        " where id=" + inv
    )
    db.executesql(qry)
    db.suppliers_bills(request.args(0)).update_record(bill_confirmation=True)
    qry = db(db.items_det.supplier_inv == inv).select()
    # =============>      negative_repair
    sum = db.items_det.items_count.sum()
    # print "--------------------------------------"
    # num = 1
    for row in qry:
        sum_row_0 = (
            db((db.items_det.item_idr == row.item_idr) & (db.items_det.items_count < 0))
            .select(sum)
            .first()[sum]
            or 0
        )
        sum_row_1 = (
            db((db.items_det.item_idr == row.item_idr) & (db.items_det.items_count > 0))
            .select(sum)
            .first()[sum]
            or 0
        )
        if (sum_row_1 >= (sum_row_0 * -1)) and (sum_row_0 != 0):
            # print "("+str(num)+") "+str(row.id) +'----'+ str(sum_row_0 ) + '------' + str(sum_row_1 )+"   ( ok )"
            for itm in db(db.items_det.item_idr == row.item_idr).select(
                orderby=~db.items_det.id
            ):
                if itm.items_count == 0:
                    continue
                elif itm.items_count < 0:
                    itm.items_count = 0
                elif (itm.items_count > 0) & (sum_row_0 < 0):
                    if itm.items_count >= (sum_row_0 * -1):
                        save_count = itm.items_count
                        itm.items_count = itm.items_count + sum_row_0
                        sum_row_0 = sum_row_0 + save_count
                itm.update_record()
        # else :
        #    #print "("+str(num)+") "+str(row.id) +'----'+ str(sum_row_0 ) + '------' + str(sum_row_1 )
        #    #db.rollback()
        # num = num+1
        # db.commit()
    db.commit()
    for itm in qry:
        if itm.return_count > 0:
            return redirect(URL("suppliers", "return_suppliers_bills_print/" + inv))
    return redirect(URL("items", "de_it"))


# ==================================================================================================
# ------------------>      تعديل بيانات صنف موجود
@auth.requires_membership("admin")
def itm_chang():
    return dict()


@auth.requires_membership("admin")
def getitm():
    it = db(
        (db.items_det.item_idr == db.items_main.id)
        & (db.items_det.id == request.args(0))
    ).select(
        db.items_det.id,
        db.items_det.items_count,
        db.items_main.name,
        db.items_det.expiration_date,
        db.items_det.public_price,
    )
    # it = db(db.items_det.item_id == request.args(0)).select().first()
    # it = db.items_det[request.args(0)]
    if it != None:
        return response.json([it])
    else:
        return response.json(0)


@auth.requires_membership("admin")
def up_c():
    qry = (
        "update items_det  set items_count ="
        + request.args(1)
        + " where id ="
        + request.args(0)
    )
    qs = db.executesql(qry)
    return response.json("1")


@auth.requires_membership("admin")
def up_sp():
    qry = (
        "update items_det  set public_price ="
        + request.args(1)
        + " where id ="
        + request.args(0)
    )
    qs = db.executesql(qry)
    return response.json("1")


@auth.requires_membership("admin")
def up_ed():
    qry = (
        "update items_det  set expiration_date =date'"
        + request.args(1)
        + "' where id ="
        + request.args(0)
    )
    qs = db.executesql(qry)
    return response.json("1")


# @auth.requires_membership("user1")
def itm_rep():
    return dict()


# =================================================================================================
#                                        جداول الجرد
# =================================================================================================
@auth.requires_membership("user1")
def inventory():
    if auth.has_membership("admin"):
        db.inventory.to_user.readable = False
        links = [
            lambda row: A(
                I(_class="fal fa-list"),
                "قوائم الجرد",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-repeat-alt"),
                "التكرار",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_dup_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-compass-slash"),
                "المفقود",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_not_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-print"),
                "طباعة",
                _class="btn btn-outline-secondary",
                _title="الاصناف المجرودة",
                _href=URL("items", "inventory_items_print_rep", args=[row.id]),
            ),
            lambda row: A(
                I(_class="fal fa-thumbs-up"),
                "اعتماد الجميع",
                _class="btn btn-outline-secondary",
                _href=URL("items", "inventory_items_approve_all", args=[row.id]),
            ),
        ]
        return dict(
            grid=SQLFORM.grid(
                db.inventory,
                user_signature=False,
                editable=True,
                paginate=200,
                links=links,
                deletable=False,
                create=True,
                csv=False,
                showbuttontext=True,
                maxtextlengths={"inventory.name": 200},
            )
        )
    elif auth.has_membership("user1"):
        q = db.inventory.open == True
        links = [
            lambda row: A(
                SPAN("قوائم الجرد", _class="btn btn-info", _title="الاصناف المجرودة"),
                _href=URL("items", "inventory_items", args=[row.id]),
            )
        ]
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                links=links,
                deletable=False,
                create=False,
                csv=False,
                showbuttontext=True,
                maxtextlengths={"inventory.name": 200},
            )
        )


@auth.requires_membership("user1")
def inventory_items():
    q = db.inventory_items.inventory == request.args(0)
    if db.inventory[request.args(0)].open == False:
        return redirect(URL("items", "inventory"))
    if auth.has_membership("admin"):
        db.inventory_items.inventory.readable = False
        db.inventory_items.inventory.writable = False
        db.inventory_items.created_by.readable = True
        # db.inventory_items.difference.writable=False
        # links = [ lambda row: A(SPAN("اعتماد الجرد للصنف",_class="btn btn-info" ),_href=URL("items","inventory_items_approve",args=[row.id,request.args(0)]  )) ]
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                deletable=True,
                create=True,
                csv=True,
                showbuttontext=True,
                maxtextlengths={"inventory_items.item_name": 200},
                args=request.args[:1],
            )
        )
    elif auth.has_membership("user1"):
        db.inventory_items.id.readable = False
        db.inventory_items.real_quantity.readable = False
        db.inventory_items.difference.readable = False
        db.inventory_items.difference.writable = False
        db.inventory_items.inventory.readable = False
        db.inventory_items.inventory.writable = False
        return dict(
            grid=SQLFORM.grid(
                q,
                user_signature=False,
                editable=True,
                deletable=False,
                create=True,
                csv=False,
                showbuttontext=False,
                maxtextlengths={"inventory_items.item_name": 200},
                args=request.args[:1],
            )
        )


@auth.requires_membership("user1")
def inventory_items_approve():
    it = db.inventory_items[request.args(0)]
    if it:
        if it.approve != True:
            if it.difference != 0:
                db1 = (
                    db(
                        (db.items_det.item_id == it.item_id)
                        & (db.items_det.items_count > 0)
                    )
                    .select()
                    .first()
                )
                db.items_det[db1.id] = dict(
                    items_count=db1.items_count + (it.difference * -1)
                )
            db.inventory_items[request.args(0)] = dict(approve=True)
            db.commit()
            return redirect(URL("items", "inventory_items/" + request.args(1)))
        else:
            return "تم اعتماد هذا الصنف"
        """
    if (it.real_quantity == db.items_det(it.item_id).items_count):
        db.items_det[it.item_id] = dict( items_count = it.quantity  )
        db.inventory_items[request.args(0)] = dict( approve = True )
        db.commit()
        return redirect(URL('items','inventory_items/'+request.args(1)))"""
    # return("الكمية غير متطابقة - تحذير تم تعديل بيانات الصنف بعد الجرد")


# ============================================================================================
@can_access(3002)
def itm_rep_det():
    return dict()


# ********************************************************************************************
# شاشة محاضر الاتلاف
# ********************************************************************************************
@auth.requires_membership("user1")
def damage_report():
    if auth.has_membership("admin"):
        links = [
            lambda row: A(
                SPAN("الاصناف", _class="btn btn-info"),
                _href=URL("items", "damage_report_det", args=[row.id]),
            ),
            lambda row: A(
                SPAN("احتساب", _class="btn btn-info"),
                _href=URL("items", "damage_report_count", args=[row.id]),
            ),
            lambda row: A(
                SPAN("اعتماد", _class="btn btn-info"),
                _href=URL("items", "damage_report_approving", args=[row.id]),
            ),
        ]
        q = (db.damage_report.user_accept == True) & (
            db.damage_report.admin_accept != True
        )
        db.damage_report.admin_accept.readable = False
        db.damage_report.admin_accept.writable = False
        grid = SQLFORM.grid(
            q,
            user_signature=False,
            links=links,
            orderby=~db.damage_report.id,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=True,
        )
        return dict(grid=grid)
    elif auth.has_membership("user1"):
        links = [
            lambda row: A(
                SPAN("الاصناف", _class="btn btn-info"),
                _href=URL("items", "damage_report_det", args=[row.id]),
            ),
            lambda row: A(
                SPAN("احتساب", _class="btn btn-info"),
                _href=URL("items", "damage_report_count", args=[row.id]),
            ),
        ]
        q = db.damage_report.user_accept == False
        db.damage_report.admin_accept.readable = False
        db.damage_report.admin_accept.writable = False
        grid = SQLFORM.grid(
            q,
            user_signature=False,
            links=links,
            editable=True,
            deletable=True,
            create=True,
            csv=False,
            showbuttontext=True,
        )
        return dict(grid=grid)


@auth.requires_membership("user1")
def damage_report_det():
    return dict()


@auth.requires_membership("user1")
def damage_report_count():
    qry = (
        "update damage_report set  item_count= (select count(*) from damage_report_det where damage_report="
        + request.args(0)
        + ") , item_sum=(select sum(item_count) from damage_report_det where damage_report="
        + request.args(0)
        + ") where id = "
        + request.args(0)
    )
    qs = db.executesql(qry)
    redirect(URL(damage_report))


@auth.requires_membership("user1")
def damage_report_det_add():
    items_det = db.damage_report_det.validate_and_insert(item_id=request.args(1))
    db.commit()
    return "0"


@auth.requires_membership("admin")
def damage_report_approving():
    qry = (
        "update items_det set  items_count= 0  where id IN ( select item_id::integer  from damage_report_det where damage_report = "
        + request.args(0)
        + ") "
    )
    qs = db.executesql(qry)
    db(db.damage_report.id == request.args(0)).update(admin_accept=True)
    db.commit()
    redirect(URL(damage_report))


# --------------------------------------------------------------------------------------------------------
@auth.requires_membership("admin")
def inventory_items_approve_all():
    thread.start_new_thread(inv_approve_all, (request.args(0),))
    return "الرجاء الانتظار سوف تأخذ هذه العملية بعض من الوقت و شكرا لك"


def inv_approve_all(sh):
    db._adapter.reconnect()
    try:
        # print sh
        inv = db((db.inventory_items.inventory == sh)).select()
        for i in inv:
            # print i.id
            it = db.inventory_items[i.id]
            if it:
                if it.approve != True:
                    # if ( it.difference!=0 ) :
                    #    db1= db((db.items_det.item_id==it.item_id) & (db.items_det.items_count>0)).select().first()
                    #    if db1 :
                    # db.items_det[db1.id] = dict(items_count = db1.items_count + (it.difference*-1) )
                    #    else :
                    db1 = db((db.items_det.item_id == it.item_id)).select().last()
                    db.items_det[db1.id] = dict(items_count=it.quantity)
                    db.inventory_items[i.id] = dict(approve=True)
                    db.commit()
        pr_id = db.print_report.validate_and_insert(er_dis="تمت عملية الاعتماد")
        db.commit()
    except Exception as e:
        print(e)
        pr_id = db.print_report.validate_and_insert(er_dis=e)
        db.commit()
    db._adapter.close()
    _lock.acquire()
    _lock.release()
    # =====================


@auth.requires_membership("admin")
def inventory_items_dup_rep():
    return dict()


@auth.requires_membership("admin")
def inventory_items_not_rep():
    return dict()


@auth.requires_membership("admin")
def inventory_items_print_rep():
    return dict()


def items_sales():
    return dict()


@can_access(3003)
def adjust_quantity():
    return dict()


@can_access(3008)
def items_merge():
    return dict()


@can_access(3008)
def items_merge_a():
    itm_1 = request.args(0)
    itm_2 = request.args(1)
    new_itm = db.items_main[itm_1]
    old_itm = db.items_main[itm_2]
    qry = "update items_det set item_idr = " + itm_1 + " where  item_idr = " + itm_2
    db.executesql(qry)
    old_itm.delete_record()
    db.commit()
    mess = " تم دمج الصنفين مع بعضها "
    return dict(mess=mess)


@auth.requires_membership("admin")
def editcountItem():
    update_qry = (
        f"update items_det set items_count =0 where item_idr = {request.args(0)}"
    )
    db.executesql(update_qry)
    db.commit()
    redirect(URL("items", "negative_items"))


@can_access(3011)
def negative_items():
    qry = (
        "select  item_idr,sum(items_count) as sum , "
        " (select name from items_main  where items_main.id= item_idr ) as name  ,"
        " (select item_type from items_main  where items_main.id= item_idr ) as type  "
        " from items_det   "
        " group by item_idr   "
        " having sum(items_count) <0   "
        " ORDER BY type,item_idr   "
    )
    data = db.executesql(qry, as_dict=True)
    for i in data:
        itm = db.items_main(i["item_idr"])
        i["type"] = itm["item_type"].name
    return dict(data=data)


def stop_items():
    return dict()


# ==============================
def get_open_inv():
    query = (db.suppliers_bills.bill_confirmation == False) or (
        suppliers_bills.bill_confirmation == None
    )
    sp = db(query).select(orderby=db.suppliers_bills.id)
    for r in sp :
        r["s_n"] = r.supplier.name
        r["p_m"] = r.payment_method.name
        qry = "select sum(inv_price) from items_det where supplier_inv = "+str(r['id'])+" ;"
        qs = db.executesql(qry)
        r["inv_inp_s"] =  qs[0][0] 
        r["u_n"]=r['created_by'].first_name + "   " + r['created_by'].last_name 
        r["inv_countg"]  =db(db.items_det.supplier_inv == r['id'] ).count() 
        qry = "select sum(inv_price*vat) from items_det where supplier_inv = "+str(r['id'])+" ;"
        qs2 = db.executesql(qry)
        r["inv_inp_s_v"] = ( qs2[0][0] or 0 ) + ( qs[0][0] or 0 )
    data = (sp.as_json())
    return data 
