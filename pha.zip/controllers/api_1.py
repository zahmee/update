# -*- coding: utf-8 -*-
#  type: ignore

# import gluon.contrib.simplejson as json
# print (json.dumps({"c": 0, "b": 0, "a": 0}, sort_keys=True))
# sup = db().select(db.suppliers.ALL ).as_list()


def min_suppliers_1():
    sql = "select id , name from suppliers where stoped='F' order by id  "
    sup = db.executesql(sql, as_dict=True)
    return response.json(sup)


def types():
    sql = "select id , name from key_type order by id"
    sup = db.executesql(sql, as_dict=True)
    return response.json(sup)


def units():
    sql = "select id , name from key_unit order by id"
    sup = db.executesql(sql, as_dict=True)
    return response.json(sup)


def getMainItems2():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where_1 = where_2 = where_3 = where_4 = ""
    if ReqVar.SearchText and ReqVar.SearchText != "":
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where_1 = f" (  upper(name) like upper('%{srt[i]}%') or item_id like '%{srt[i]}%' or item_reg like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' ) "
            else:
                where_1 = (
                    where_1
                    + f" and (  upper(name) like upper('%{srt[i]}%') or item_id like '%{srt[i]}%' or item_reg like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' ) "
                )
    if ReqVar.supplier:
        if (ReqVar.supplier is not None) or (ReqVar.supplier != ""):
            where_2 = f"  ( suppliers = {ReqVar.supplier}  ) "
    if ReqVar.types and (ReqVar.types != "0"):
        if (ReqVar.types is not None) or (ReqVar.types != ""):
            where_3 = f"  ( item_type = {ReqVar.types} ) "
    if len(where_1) > 0 or len(where_2) > 0 or len(where_3) > 0:
        where_4 = " where " + where_1 + " and " + where_2 + " and " + where_3
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = "id"
    if ReqVar.sequence:
        if ReqVar.sequence == "true":
            sa = "ASC"
        else:
            sa = "desc"
    else:
        sa = "ASC"
    pg = int(int(pg) * int(rc))
    where = where_4.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("and  and", "and")
    subq1 = "(select name from suppliers where id=suppliers) as s_name"
    subq2 = "(select name from key_type where id=item_type) as t_name"
    sql = f" SELECT id,upper(name) as name,item_id, public_price, suppliers,item_type,item_unit,{subq1} ,{subq2},flexible_price,item_group FROM items_main  {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    sql = sql.replace("and  order", "order")
    sql2 = f" SELECT count(*) FROM items_main  {where}  ; "
    sql2 = sql2.replace("and   ;", "; ")
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def newMainItem():
    try:
        data = request.vars
        nid = db.items_main.validate_and_insert(
            name=data.name.upper(),
            item_id=data.item_id,
            item_unit=data.item_unit,
            item_type=data.item_type,
            public_price=data.public_price,
            suppliers=data.suppliers,
            flexible_price=data.flexible_price,
            item_group=data.item_group,
        )
        db.commit()
        return response.json(nid)
    except Exception as e:
        db.rollback()
        return response.json(e)


def editMainItem():
    try:
        data = request.vars
        row = db.items_main[data.id]
        row.update_record(
            name=data.name.upper(),
            item_id=data.item_id,
            item_unit=data.item_unit,
            item_type=data.item_type,
            public_price=data.public_price,
            suppliers=data.suppliers,
            flexible_price=data.flexible_price,
            item_group=data.item_group,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


# ============================>  items_det
def getItemsDet():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    where_1 = where_2 = where_3 = where_4 = ""
    if ReqVar.SearchText and ReqVar.SearchText != "":
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i == 0:
                where_1 = f" (  item_id like '%{srt[i]}%' or CAST (supplier_inv AS text) like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' ) "
            else:
                where_1 = (
                    where_1
                    + f" and (   item_id like '%{srt[i]}%' or CAST (supplier_inv AS text) like '%{srt[i]}%' or CAST (id  AS text) like '%{srt[i]}%' ) "
                )
    if ReqVar.supplier:
        if (ReqVar.supplier is not None) or (ReqVar.supplier != ""):
            where_2 = f"  ( suppliers = {ReqVar.supplier}  ) "
    if ReqVar.types and (ReqVar.types != "0"):
        if (ReqVar.types is not None) or (ReqVar.types != ""):
            where_3 = f"  ( item_type = {ReqVar.types} ) "
    if len(where_1) > 0 or len(where_2) > 0 or len(where_3) > 0:
        where_4 = " where " + where_1 + " and " + where_2 + " and " + where_3
    if ReqVar.SortBy:
        sc = ReqVar.SortBy
    else:
        sc = "id"
    if ReqVar.sequence:
        if ReqVar.sequence == "true":
            sa = "ASC"
        else:
            sa = "desc"
    else:
        sa = "ASC"
    pg = int(int(pg) * int(rc))
    where = where_4.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("where  and", "where")
    where = where.replace("and  and", "and")
    subq1 = "(select upper(name)  from items_main where id=item_idr) as it_name"
    sql = (
        f" SELECT id, item_idr,item_id ,public_price, supplier_inv,quantity,buy_price,"
        f" expiration_date,items_count,vat ,vat_in_public_price ,return_count , {subq1} FROM items_det"
        f" {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    )
    sql = sql.replace("and  order", "order")
    sql2 = f" SELECT count(*) FROM items_det  {where}  ; "
    sql2 = sql2.replace("and   ;", "; ")
    qry = db.executesql(sql, as_dict=True)
    qry2 = db.executesql(sql2, as_dict=True)
    data = {"data": qry, "count": qry2[0]["count"]}
    return response.json(data)


def editItemsDet():
    try:
        data = request.vars
        row = db.items_det[data.id]
        row.update_record(
            public_price=data.public_price,
            items_count=data.items_count,
            vat=data.vat,
            vat_in_public_price=data.vat_in_public_price,
            return_count=data.return_count,
        )
        db.commit()
        return response.json(row)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": str(e)}
        return response.json(ret)


def getCountItems():
    id = request.args(0)
    sql = f"select ROUND(sum( items_count )::numeric,2) as count from items_det id where item_idr = {id} "
    qry = db.executesql(sql, as_dict=True)
    re = qry[0]["count"]
    return re


@auth.requires_membership("admin")
def editcountItem():
    data = request.vars
    update_qry = f"update items_det set items_count =0 where item_idr = {data.item_id}"
    db.executesql(update_qry)
    new_count = (
        db(db.items_det.item_idr == data.item_id).select(orderby=db.items_det.id).last()
    )
    new_count.items_count = data.total_count
    new_count.update_record()
    db.commit()
    return response.json(1)
