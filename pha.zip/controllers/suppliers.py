# -*- coding: utf-8 -*-
#  type: ignore


# secretarial
# @auth.requires(auth.has_membership('user1') or auth.has_membership('admin') or auth.has_membership('secretarial'))
# @auth.requires( auth.has_membership('admin')  )
@can_access(2001)
def index():
    return dict()


# @auth.requires(  auth.has_membership('admin')  )
@can_access(2003)
def edit_supplier():
    return dict()


@can_access(2002)
def new_supplier():
    return dict()


@can_access(2011)
def suppliers_bills():
    return dict()


@can_access(2008)
def returned_supply():
    return dict()


@can_access(2108)
def opening_balance():
    return dict()


@can_access(2109)
def balance_reconciliation():
    return dict()


@can_access(2106)
def rep5():
    my_data = []
    r = lambda s: str(datetime.datetime.now()) if s == "" else str(s)
    sda1 = request.vars.da1.split(",")
    sda2 = request.vars.da2.split(",")
    da1 = r(sda1[2] + "-01-01")
    da2 = r(sda1[2] + "-12-31")
    s_b = db(
        (db.suppliers_bills.bill_date >= da1)
        & (db.suppliers_bills.bill_date <= da2)
        & (db.suppliers_bills.supplier == request.vars.sup)
    ).select()
    s_p = db(
        (db.suppliers_bills_pay.pay_date >= da1)
        & (db.suppliers_bills_pay.pay_date <= da2)
        & (db.suppliers_bills_pay.supplier == request.vars.sup)
    ).select()
    s_pc = db(
        (db.suppliers_balance_reconciliation.balance_date >= da1)
        & (db.suppliers_balance_reconciliation.balance_date <= da2)
        & (db.suppliers_balance_reconciliation.supplier == request.vars.sup)
    ).select()
    for r in s_b:
        disc = r.invoce_type.name + " [ " + r.bill_no + " ]"
        my_data.append(
            {
                "id": r.id,
                "date": r.bill_date,
                "disc": disc,
                "mount": r.bill_total,
                "note": r.note,
                "net": 0.0,
                "type": 1,
            }
        )
    for r in s_p:
        disc = "* " + r.payment_type.name + " *"
        my_data.append(
            {
                "id": r.id,
                "date": r.pay_date,
                "disc": disc,
                "mount": r.pay_total,
                "note": r.note,
                "net": 0.0,
                "type": 0,
            }
        )
    for r in s_pc:
        if r.balance == 1:
            disc = "{ عملية مطابقة حساب - الرصيد مطابق }"
        else:
            disc = (
                "{ عملية مطابقة حساب - الرصيد غير مطابق }"
                + "[ "
                + str(r.balance_def)
                + "  ]"
            )

        my_data.append(
            {
                "id": r.id,
                "date": r.balance_date,
                "disc": disc,
                "mount": 0,
                "note": r.note,
                "net": 0.0,
                "type": -1,
            }
        )
    my_data.sort(key=lambda x: x["date"])
    return dict(data=my_data)


@can_access(2006)
def account_movement():
    supplier_id = int(request.args(0))
    months = [
        ("1", "يناير"), ("2", "فبراير"), ("3", "مارس"), ("4", "أبريل"),
        ("5", "مايو"), ("6", "يونيو"), ("7", "يوليو"), ("8", "أغسطس"),
        ("9", "سبتمبر"), ("10", "أكتوبر"), ("11", "نوفمبر"), ("12", "ديسمبر"),
    ]

    def row_total(row):
        return sum(float(row.get(key) or 0) for key, label in months)

    def table_total(rows):
        return sum(row_total(row) for row in rows)

    def money(value, blank_zero=False):
        value = float(value or 0)
        if blank_zero and value == 0:
            return ""
        return "{:,.0f}".format(value)

    # crosstab: الاستعلام الداخلي يُمرَّر كنص لـ crosstab — لا يدعم placeholders
    # التحويل لـ int أعلاه يمنع SQL injection تماماً
    ct_cols = (
        ' AS ct ( fcount int ,"1" int,"2" int,"3" int,"4" int,"5" int,'
        ' "6" int,"7" int,"8" int,"9" int,"10" int,"11" int,"12" int )'
    )
    qry = (
        "SELECT * FROM crosstab("
        " 'SELECT EXTRACT(YEAR FROM bill_date)::integer,"
        " EXTRACT(MONTH FROM bill_date)::integer,"
        " SUM(bill_total)::integer"
        " FROM suppliers_bills WHERE supplier = " + str(supplier_id) +
        " GROUP BY 1,2 ORDER BY 1,2',"
        " 'SELECT * FROM generate_series(1,12)')"
        + ct_cols
    )
    qs1 = db.executesql(qry, as_dict=True)
    for row in qs1:
        row["_total"] = row_total(row)

    qry2 = (
        "SELECT a.n,"
        " (SELECT SUM(bill_total)::integer FROM suppliers_bills"
        "  WHERE supplier = %s"
        "  AND EXTRACT(MONTH FROM bill_date)::integer = a.n)"
        " AS fcount FROM generate_series(1, 12) AS a(n)"
    )
    qs11 = db.executesql(qry2, placeholders=[supplier_id], as_dict=True)

    qry3 = (
        "SELECT * FROM crosstab("
        " 'SELECT EXTRACT(YEAR FROM pay_date)::integer,"
        " EXTRACT(MONTH FROM pay_date)::integer,"
        " SUM(pay_total)::integer"
        " FROM suppliers_bills_pay WHERE supplier = " + str(supplier_id) +
        " GROUP BY 1,2 ORDER BY 1,2',"
        " 'SELECT * FROM generate_series(1,12)')"
        + ct_cols
    )
    qs2 = db.executesql(qry3, as_dict=True)
    for row in qs2:
        row["_total"] = row_total(row)

    qry4 = (
        "SELECT a.n,"
        " (SELECT SUM(pay_total)::integer FROM suppliers_bills_pay"
        "  WHERE supplier = %s"
        "  AND EXTRACT(MONTH FROM pay_date)::integer = a.n)"
        " AS fcount FROM generate_series(1, 12) AS a(n)"
    )
    qs22 = db.executesql(qry4, placeholders=[supplier_id], as_dict=True)

    purchase_total = table_total(qs1)
    payment_total = table_total(qs2)
    balance_total = purchase_total - payment_total

    supplier = db.suppliers[supplier_id]

    return dict(
        supplier=supplier,
        supplier_name=supplier.name if supplier else "مورد غير معروف",
        months=months,
        money=money,
        data1=qs1,
        data11=qs11,
        data2=qs2,
        data22=qs22,
        purchase_total=purchase_total,
        payment_total=payment_total,
        balance_total=balance_total,
        balance_class="balance-negative" if balance_total < 0 else "",
    )


#


@can_access(2009)
def return_suppliers_bills_ok():
    from datetime import date

    inv = int(request.args(0))
    invc = db.suppliers_bills[inv]
    itm = db(
        (db.items_det.supplier_inv == inv) & (db.items_det.return_count > 0)
    ).select()
    # تُعالَج الأسطر غير المُرتجعة فقط، وفي نفس الدورة يُخصم المخزون وتُسجَّل
    # الحركة معاً، ثم يُحتسب إشعار المورد من هذه الأسطر وحدها.
    # سابقاً: وجود سطر مُرتجع مسبقاً كان يُلغي تسجيل الحركة وإشعار المورد كلياً
    # بينما يُخصم المخزون فعلياً — فينشأ نقص بلا أثر محاسبي ولا دفتري.
    base = vat_amount = 0.0
    processed = 0
    for row in itm:
        if row.return_chked:
            continue
        qty = float(row.return_count or 0)
        price = float(row.buy_price or 0)
        stock_move(row, -qty, "مرتجع شراء",
                   (invc.bill_no or "") if invc else "", str(inv), price)
        row.update_record(return_chked=True)
        base += price * qty
        vat_amount += price * qty * float(row.vat or 0)
        processed += 1
    if processed:
        total = round((base + vat_amount), 2)
        db.suppliers_bills_pay.insert(
            supplier=invc.supplier,
            payment_method=4,
            payment_type=3,
            pay_total=total,
            pay_date=date.today(),
            note="ارجاع اصناف فاتورة رقم :" + ((invc.bill_no or "") if invc else ""),
        )
    db.commit()
    redirect(URL("items", "de_it" ))


@can_access(2008)
def return_suppliers_bills_print():
    sc = screens_rules(2009)
    return dict(sc=sc)


@can_access(2015)
def returned_supply_det():
     row = db.returned_supply[request.args(0)]
     if row :
        if row.admin_accept == False:
            return dict()
        else:
            return "لقد تم اقفال هذه الفاتورة"
     else:
        return dict()


@can_access(2008)
def returned_supply_print():
    return dict()


@can_access(2016)
def returned_supply_approving():
    from datetime import date

    if db.returned_supply[request.args(0)].admin_accept == False:
        qry = db(db.returned_supply_det.returned_supply == request.args(0)).select()
        ret_record = db.returned_supply(request.args(0))
        # الخصم وتسجيل الحركة في خطوة واحدة عبر الوحدة المركزية
        for r in qry:
            det = db.items_det(r.item_id)
            if not det:
                continue
            stock_move(det, -float(r.item_count or 0), "مرتجع توريد",
                       (ret_record.name or "") if ret_record else "",
                       str(request.args(0)), float(r.inv_price or 0))
        db(db.returned_supply.id == request.args(0)).update(admin_accept=True)
        # =============== تسجيل سداد الموردين
        itm = db(db.returned_supply_det.returned_supply == request.args(0)).select()
        inv = db.returned_supply[request.args(0)]
        sumv = 0.0
        for i in itm:
            sumv = sumv + ((i.total or 0) + ((i.total or 0) * (i.vat or 0)))
        total = round(sumv, 2)
        today = date.today()
        note = f"مرتجع اصناف  رقم :" + request.args(0)
        nid = db.suppliers_bills_pay.insert(
            supplier=inv.supplier,
            payment_method=4,
            payment_type=4,
            pay_total=total,
            pay_date=today,
            note=note,
        )
        db.commit()
        redirect(URL("suppliers", "returned_supply"))
    else:
        return "لقد تم اقفال هذه الفاتورة"


@can_access(2107)
def suppliers_payment():
    return dict()


@can_access(2110)
def supply_rep():
    return dict()


@can_access(3003)
def supplier_items_sales():
    return dict()


# ==============================================================================#
# =======================       التقارير           =============================#
# ==============================================================================#


@can_access(2111)
def rep1():
    return dict()


@can_access(2111)
def rep2():
    return dict()


@can_access(2111)
def rep3():
    return dict()


@can_access(2111)
def rep4():
    return dict()


# --------------------------------------------------------------------------------------------------
