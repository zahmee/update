# -*- coding: utf-8 -*-
#  type: ignore


# secretarial
# @auth.requires(auth.has_membership('user1') or auth.has_membership('admin') or auth.has_membership('secretarial'))
# @auth.requires( auth.has_membership('admin')  )
@can_access(2001)
def index():
    return dict()


# @auth.requires(  auth.has_membership('admin')  )
@can_access(2003)
def edit_supplier():
    return dict()


@can_access(2002)
def new_supplier():
    return dict()


def suppliers_bills():
    return dict()


def returned_supply():
    return dict()


@can_access(2107)
def suppliers_payment():
    return dict()


@can_access(2108)
def opening_balance():
    return dict()


@can_access(2109)
def balance_reconciliation():
    return dict()


@can_access(2106)
def rep5():
    my_data = []
    r = lambda s: str(datetime.datetime.now()) if s == "" else str(s)
    sda1 = request.vars.da1.split(",")
    sda2 = request.vars.da2.split(",")
    da1 = r(sda1[2] + "-01-01")
    da2 = r(sda1[2] + "-12-31")
    s_b = db(
        (db.suppliers_bills.bill_date >= da1)
        & (db.suppliers_bills.bill_date <= da2)
        & (db.suppliers_bills.supplier == request.vars.sup)
    ).select()
    s_p = db(
        (db.suppliers_bills_pay.pay_date >= da1)
        & (db.suppliers_bills_pay.pay_date <= da2)
        & (db.suppliers_bills_pay.supplier == request.vars.sup)
    ).select()
    s_pc = db(
        (db.suppliers_balance_reconciliation.balance_date >= da1)
        & (db.suppliers_balance_reconciliation.balance_date <= da2)
        & (db.suppliers_balance_reconciliation.supplier == request.vars.sup)
    ).select()
    for r in s_b:
        disc = r.invoce_type.name + " [ " + r.bill_no + " ]"
        my_data.append(
            {
                "id": r.id,
                "date": r.bill_date,
                "disc": disc,
                "mount": r.bill_total,
                "note": r.note,
                "net": 0.0,
                "type": 1,
            }
        )
    for r in s_p:
        disc = "* " + r.payment_type.name + " *"
        my_data.append(
            {
                "id": r.id,
                "date": r.pay_date,
                "disc": disc,
                "mount": r.pay_total,
                "note": r.note,
                "net": 0.0,
                "type": 0,
            }
        )
    for r in s_pc:
        if r.balance == 1:
            disc = "{ عملية مطابقة حساب - الرصيد مطابق }"
        else:
            disc = (
                "{ عملية مطابقة حساب - الرصيد غير مطابق }"
                + "[ "
                + str(r.balance_def)
                + "  ]"
            )

        my_data.append(
            {
                "id": r.id,
                "date": r.balance_date,
                "disc": disc,
                "mount": 0,
                "note": r.note,
                "net": 0.0,
                "type": -1,
            }
        )
    my_data.sort(key=lambda x: x["date"])
    return dict(data=my_data)


@can_access(2006)
def account_movement():
    qry = (
        " SELECT * FROM "
        "      crosstab( 'select EXTRACT(YEAR FROM bill_date)::integer as fday,' || "
        "                'EXTRACT(MONTH FROM bill_date)::integer as fmonth,' || "
        "                ' sum(bill_total)::integer as fcount from suppliers_bills where supplier = "
        + str(request.args(0))
        + " ' || "
        "                'group by EXTRACT(MONTH FROM bill_date),EXTRACT(YEAR FROM bill_date)  ' || "
        "                'order by EXTRACT(YEAR FROM bill_date),EXTRACT(MONTH FROM bill_date)  ', "
        '          \'select * from generate_series(1,12) \' ) AS ct ( fcount int ,"1" int,"2" int,"3" int,"4" int,"5" int, '
        '              "6" int,"7" int,"8" int,"9" int,"10" int,"11" int,"12" int ); '
    )
    qs1 = db.executesql(qry, as_dict=True)
    print(qs1)
    qry = (
        "select a.n , "
        "    (select sum(bill_total)::integer as fcount from suppliers_bills where supplier="
        + str(request.args(0))
        + "    and EXTRACT(MONTH FROM created_on)::integer = a.n ) "
        "        from generate_series(1, 12) as a(n)"
    )
    qs11 = db.executesql(qry, as_dict=True)
    qry = (
        " SELECT * FROM "
        "      crosstab( 'select EXTRACT(YEAR FROM pay_date)::integer as fday,' || "
        "                'EXTRACT(MONTH FROM pay_date)::integer as fmonth,' || "
        "                ' sum(pay_total)::integer as fcount from suppliers_bills_pay where supplier = "
        + str(request.args(0))
        + " ' || "
        "                'group by EXTRACT(MONTH FROM pay_date),EXTRACT(YEAR FROM pay_date)  ' || "
        "                'order by EXTRACT(YEAR FROM pay_date),EXTRACT(MONTH FROM pay_date)  ', "
        '          \'select * from generate_series(1,12) \' ) AS ct ( fcount int ,"1" int,"2" int,"3" int,"4" int,"5" int, '
        '              "6" int,"7" int,"8" int,"9" int,"10" int,"11" int,"12" int ); '
    )
    qs2 = db.executesql(qry, as_dict=True)
    qry = (
        "select a.n , "
        "    (select sum(pay_total)::integer as fcount from suppliers_bills_pay where supplier="
        + str(request.args(0))
        + "    and EXTRACT(MONTH FROM created_on)::integer = a.n ) "
        "        from generate_series(1, 12) as a(n)"
    )
    qs22 = db.executesql(qry, as_dict=True)

    return dict(data1=qs1, data11=qs11, data2=qs2, data22=qs22)


#


@can_access(2009)
def return_suppliers_bills_ok():
    from datetime import date

    inv = int(request.args(0))
    invc = db.suppliers_bills[inv]
    itm = db(
        (db.items_det.supplier_inv == inv) & (db.items_det.return_count > 0)
    ).select()
    sum = sum2 = total = 0.0
    add_paynet = True
    for row in itm:
        if row.return_chked == None or row.return_chked == False:
            row.update_record(
                return_chked=True, items_count=(row.items_count - row.return_count)
            )
        else:
            add_paynet = False
    if add_paynet:
        itm = db(
            (db.items_det.supplier_inv == inv) & (db.items_det.return_count > 0)
        ).select()
        for i in itm:
            sum = sum + (i.buy_price * i.return_count)
            sum2 = sum2 + (i.buy_price * i.return_count * (i.vat or 0))
        total = round((sum + sum2), 2)
        today = date.today()
        note = f"ارجاع اصناف فاتورة رقم :" + invc.bill_no
        nid = db.suppliers_bills_pay.insert(
            supplier=invc.supplier,
            payment_method=4,
            payment_type=3,
            pay_total=total,
            pay_date=today,
            note=note,
        )
    db.commit()
    redirect(URL("items", "de_it" ))


@can_access(2008)
def return_suppliers_bills_print():
    sc = screens_rules(2009)
    return dict(sc=sc)


@can_access(2015)
def returned_supply_det():
     row = db.returned_supply[request.args(0)]
     if row :
        if row.admin_accept == False:
            return dict()
        else:
            return "لقد تم اقفال هذه الفاتورة"
     else:
        return dict()


def returned_supply_print():
    return dict()


@can_access(2016)
def returned_supply_approving():
    from datetime import date

    if db.returned_supply[request.args(0)].admin_accept == False:
        qry = db(db.returned_supply_det.returned_supply == request.args(0)).select()
        for r in qry:
            db(db.items_det.id == r.item_id).update(
                items_count=(db.items_det.items_count - r.item_count)
            )
        db(db.returned_supply.id == request.args(0)).update(admin_accept=True)
        # =============== تسجيل سداد الموردين
        itm = db(db.returned_supply_det.returned_supply == request.args(0)).select()
        inv = db.returned_supply[request.args(0)]
        sumv = 0.0
        for i in itm:
            sumv = sumv + ((i.total or 0) + ((i.total or 0) * (i.vat or 0)))
        total = round(sumv, 2)
        today = date.today()
        note = f"مرتجع اصناف  رقم :" + request.args(0)
        nid = db.suppliers_bills_pay.insert(
            supplier=inv.supplier,
            payment_method=4,
            payment_type=4,
            pay_total=total,
            pay_date=today,
            note=note,
        )
        db.commit()
        redirect(URL("suppliers", "returned_supply"))
    else:
        return "لقد تم اقفال هذه الفاتورة"


@can_access(2107)
def suppliers_payment():
    return dict()


@auth.requires(auth.has_membership("admin"))
def supply_rep():
    return dict()


# ==============================================================================#
# =======================       التقارير           =============================#
# ==============================================================================#


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep1():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep2():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep3():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep4():
    return dict()


@can_access(2106)
def rep5():
    my_data = []
    r = lambda s: str(datetime.datetime.now()) if s == "" else str(s)
    sda1 = request.vars.da1.split(",")
    sda2 = request.vars.da2.split(",")
    da1 = r(sda1[2] + "-01-01")
    da2 = r(sda1[2] + "-12-31")
    s_b = db(
        (db.suppliers_bills.bill_date >= da1)
        & (db.suppliers_bills.bill_date <= da2)
        & (db.suppliers_bills.supplier == request.vars.sup)
    ).select()
    s_p = db(
        (db.suppliers_bills_pay.pay_date >= da1)
        & (db.suppliers_bills_pay.pay_date <= da2)
        & (db.suppliers_bills_pay.supplier == request.vars.sup)
    ).select()
    s_pc = db(
        (db.suppliers_balance_reconciliation.balance_date >= da1)
        & (db.suppliers_balance_reconciliation.balance_date <= da2)
        & (db.suppliers_balance_reconciliation.supplier == request.vars.sup)
    ).select()
    for r in s_b:
        disc = r.invoce_type.name + " [ " + r.bill_no + " ]"
        my_data.append(
            {
                "id": r.id,
                "date": r.bill_date,
                "disc": disc,
                "mount": r.bill_total,
                "note": r.note,
                "net": 0.0,
                "type": 1,
            }
        )
    for r in s_p:
        disc = "* " + r.payment_type.name + " *"
        my_data.append(
            {
                "id": r.id,
                "date": r.pay_date,
                "disc": disc,
                "mount": r.pay_total,
                "note": r.note,
                "net": 0.0,
                "type": 0,
            }
        )
    for r in s_pc:
        if r.balance == 1:
            disc = "{ عملية مطابقة حساب - الرصيد مطابق }"
        else:
            disc = (
                "{ عملية مطابقة حساب - الرصيد غير مطابق }"
                + "[ "
                + str(r.balance_def)
                + "  ]"
            )

        my_data.append(
            {
                "id": r.id,
                "date": r.balance_date,
                "disc": disc,
                "mount": 0,
                "note": r.note,
                "net": 0.0,
                "type": -1,
            }
        )
    my_data.sort(key=lambda x: x["date"])
    return dict(data=my_data)


# --------------------------------------------------------------------------------------------------
