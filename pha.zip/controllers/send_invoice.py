# -*- coding: utf-8 -*-
#  type: ignore

from datetime import date, datetime
import json
import os
import sys
import httpx
import ast

def index():
    pih_txt =""
    qr_code = ""
    icv = 0
    db(db.invoice_sending.send == True).delete()
    db.commit()
    all_inv = db(db.invoice_sending).select(orderby=db.invoice_sending.id)
    for r in all_inv :
        if r.send:
            continue
        csr_config = db(db.csr_config.id > 0).select().first()
        headers = {}
        headers["Content-Type"] = "application/json"
        headers["accept"] = "application/json"
        invno = r.inv_id
        json_inv = ast.literal_eval(r.inv_data)
        json_inv["invoice"]["AdditionalDocumentReferences"][0]["UUID"] = str(csr_config.icv) # ICV
        json_inv["invoice"]["AdditionalDocumentReferences"][1]["Attachment"] = csr_config.pih # PIH
        # json_string = json.dumps(json_inv, ensure_ascii=False, indent=4)
        #url = csr_config.api_site + "/zatca/process-simplified"        
        url = csr_config.api_site + "/zatca/process-one"
        resp = None
        for i in range(4):
            try:
                resp = httpx.post(url, json=json_inv, headers=headers, timeout=50.0)
                if resp.status_code == 200:
                    break
            except Exception:
                pass
        try:
            if resp and resp.status_code == 200:
                api_response = resp.json()
                if api_response["raw_response"]["reportingStatus"] == "REPORTED":
                    pih_txt = api_response["pih_base64"]
                    qr_code = api_response["qr_value"]
                    zatca_res = json.dumps(api_response, ensure_ascii=False)
                    if r.inv_type == 1:  # الفواتير
                        inv_update = db.invoice_master[invno]
                        inv_update.update_record(
                            pih_txt=pih_txt, 
                            qr_code=qr_code,
                            zatca_res=zatca_res ,
                            send_to_zatca=True
                        )
                    elif r.inv_type == 2:  # المرتجعات
                        inv_update = db.inv_return_master[invno]
                        inv_update.update_record(
                            pih_txt=pih_txt, 
                            qr_code=qr_code,
                            zatca_res=zatca_res ,
                            send_to_zatca=True
                        )
                    icv = int(csr_config.icv or 0) + 1
                    csr_config.update_record(icv=icv, pih=pih_txt)
                    r.update_record(
                        send=True
                    )
                else:
                    r.delete_record()
            else:
                r.delete_record()
        except Exception as e:
            #print(e)
            r.delete_record()
        finally:
            db.commit()        
    return ("ok")
