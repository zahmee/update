# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
import send_sms as sms

@can_access(1001)
def get_customers():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)
    ut = int(ReqVar.userType    or 0)

    allowed_sort = {'id', 'name', 'mobile', 'cust_type'}
    sort_col = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    conditions = []
    params      = []

    # بحث نصي — parameterized (لا SQL injection)
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append("(c.name LIKE %s OR c.mobile LIKE %s)")
            params.extend([pattern, pattern])

    # فلتر نوع العميل — إصلاح: كان يضيف WHERE بعد WHERE مما ينتج SQL مكسور
    if ut != 0:
        conditions.append("c.cust_type = %s")
        params.append(ut)

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف × 2
    data_sql = f"""
        SELECT
            c.id, c.name, c.mobile, c.address, c.cust_type,
            CASE WHEN c.cust_type = 10 THEN 'دعم الجمعية' ELSE 'عام' END AS cust_type_name,
            COALESCE(inv.total, 0) AS cus_inv,
            COALESCE(pay.total, 0) AS cus_pay
        FROM customers c
        LEFT JOIN (
            SELECT customer, SUM(total_after_discount) AS total
            FROM   invoice_master
            WHERE  payment_method = 3
            GROUP BY customer
        ) inv ON inv.customer = c.id
        LEFT JOIN (
            SELECT customers_id, SUM(amount) AS total
            FROM   customers_pay
            GROUP BY customers_id
        ) pay ON pay.customers_id = c.id
        {where}
        ORDER BY c.{sort_col} {sa}
        LIMIT {rc} OFFSET {offset}
    """
    count_sql = f"SELECT COUNT(*) FROM customers c {where}"

    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    return response.json({"data": qry, "count": qry2[0]["count"]})


def new_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(db, 'customers.mobile' ,
        error_message='يوجد هذا الرقم مسجل مسبقا' )
        nid = db.customers.validate_and_insert(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            cust_type=data.cust_type,
        )
        db.commit()
        return response.json(nid)
    except Exception as e :
        print(e)
        db.rollback()
        return response.json(e)

def edit_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(db, 'customers.mobile' ,
        error_message='يوجد هذا الرقم مسجل مسبقا' )
        row = db.customers[data.id]
        row.update_record(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            cust_type=data.cust_type,
        )
        db.commit()
        return response.json(row)
    except Exception as e :
        db.rollback()
        ret = {"err":3 ,"invno":0 ,"mess":str(e)}
        return response.json(ret)


def get_fast_data():
    try:
        #
        qry1 = db(
                db.customers_pay.customers_id ==  request.args(0) 
            ).select(
                orderby= ~db.customers_pay.id  ,
                limitby= (0,10) ,
            )
        qry2 = db(
                db.invoice_master.customer ==  request.args(0) 
            ).select(
                orderby= ~db.invoice_master.id  ,
                limitby= (0,10) ,
            )
        for q2 in qry2:
            q2["payment_method"] = q2.payment_method.name

        return response.json({"in": qry1, "out": qry2})
    except Exception as e :
        db.rollback()
        ret = {"err":3 ,"invno":0 ,"mess":str(e)}
        return response.json(ret)


def save_coust_pay():
    try:
        data = request.vars
        # print(data)
        now_date = request.now.strftime("%Y-%m-%d")
        nid = db.customers_pay.validate_and_insert(
            customers_id=data.coust,
            amount=data.mount,
            customers_pay_data=now_date,
            note=data.note,
            cust_type=data.cust_type,
            pay_note=data.pay_note,
            pay_type=data.type ,
        )
        db.commit()
        # ==========================
        costmer = db.customers[data.coust]
        data_sms = "" 
        if data.type=="10" :
            data_sms = "دعم الجمعية الخيرية \r\n "
        else :
            data_sms = " سداد نقدي \r\n "
        if costmer.mobile:
            if len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS()
                ms = (
                    "تم اضافة "
                    + data.mount
                    + " ريال "
                    + " الى حسابك "
                    + " \r\n "
                    + data_sms
                    + data.pay_note
                    + " \r\n "
                    + configuration.name
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)
                nid["sms"] = re_ms
        # ==========================
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(e)
