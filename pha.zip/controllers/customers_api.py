# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
import send_sms as sms

@can_access(1001)
def get_customers():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0 
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    if ReqVar.userType:
        ut = ReqVar.userType
    else:
        ut = 0
    where = '' 
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            if i==0 :
                where = f" where (  name like '%{srt[i]}%' or mobile like '%{srt[i]}%'  ) "
            else :
                where = where +f" and ( name like '%{srt[i]}%' or mobile like '%{srt[i]}%'  ) "
    if int(ut) != 0 :
        where = where + f" where ( cust_type = {ut}   ) "
        
    if ReqVar.SortBy :
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'desc'
    else :
        sa = 'ASC'

    pg = int(int(pg) * int(rc))

    where = where.replace('where  and', 'where')    
    where = where.replace('where  and', 'where') 
    where = where.replace('and  and', 'and') 
    where = where.replace(")  where (", ") and (")
    print(where)
    sql = f" SELECT id,name,mobile, address,cust_type,( select sum(total_after_discount) from invoice_master where payment_method=3 and customer =customers.id ) as cus_inv, ( select sum(amount) from customers_pay  where customers_id=customers.id  ) as cus_pay FROM customers {where} order by {sc}  {sa}  limit {rc} OFFSET {pg} ; "
    sql = sql.replace('and  order', 'order') 
    sql2 = f" SELECT count(*) FROM customers  {where}  ; "
    sql2 = sql2.replace('and   ;' , '; ')
    qry = db.executesql(sql  ,as_dict=True)
    qry2 = db.executesql(sql2  ,as_dict=True)
    data = { "data" : qry , "count" :qry2[0]["count"] }
    return response.json(data)


def new_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(db, 'customers.mobile' ,
        error_message='يوجد هذا الرقم مسجل مسبقا' )
        nid = db.customers.validate_and_insert(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            cust_type=data.cust_type,
        )
        db.commit()
        return response.json(nid)
    except Exception as e :
        print(e)
        db.rollback()
        return response.json(e)

def edit_customer():
    try:
        data = request.vars
        db.customers.mobile.requires = IS_NOT_IN_DB(db, 'customers.mobile' ,
        error_message='يوجد هذا الرقم مسجل مسبقا' )
        row = db.customers[data.id]
        row.update_record(
            name=data.name.lower(),
            mobile=data.mobile,
            address=data.address,
            cust_type=data.cust_type,
        )
        db.commit()
        return response.json(row)
    except Exception as e :
        db.rollback()
        ret = {"err":3 ,"invno":0 ,"mess":str(e)}
        return response.json(ret)


def get_fast_data():
    try:
        #
        qry1 = db(
                db.customers_pay.customers_id ==  request.args(0) 
            ).select(
                orderby= ~db.customers_pay.id  ,
                limitby= (0,10) ,
            )
        qry2 = db(
                db.invoice_master.customer ==  request.args(0) 
            ).select(
                orderby= ~db.invoice_master.id  ,
                limitby= (0,10) ,
            )
        for q2 in qry2:
            q2["payment_method"] = q2.payment_method.name

        return response.json({"in": qry1, "out": qry2})
    except Exception as e :
        db.rollback()
        ret = {"err":3 ,"invno":0 ,"mess":str(e)}
        return response.json(ret)


def save_coust_pay():
    try:
        data = request.vars
        # print(data)
        now_date = request.now.strftime("%Y-%m-%d")
        nid = db.customers_pay.validate_and_insert(
            customers_id=data.coust,
            amount=data.mount,
            customers_pay_data=now_date,
            note=data.note,
            cust_type=data.cust_type,
            pay_note=data.pay_note,
            pay_type=data.type ,
        )
        db.commit()
        # ==========================
        costmer = db.customers[data.coust]
        data_sms = "" 
        if data.type=="10" :
            data_sms = "دعم الجمعية الخيرية \r\n "
        else :
            data_sms = " سداد نقدي \r\n "
        if costmer.mobile:
            if len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS()
                ms = (
                    "تم اضافة "
                    + data.mount
                    + " ريال "
                    + " الى حسابك "
                    + " \r\n "
                    + data_sms
                    + data.pay_note
                    + " \r\n "
                    + configuration.name
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)
        nid["sms"] = re_ms
        # ==========================
        return response.json(nid)
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(e)
