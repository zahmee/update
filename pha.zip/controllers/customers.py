# -*- coding: utf-8 -*-
#  type: ignore

import os
import sys

'''
p = send_sms.SMS()
p.getbalance()
ms = """
كيفكم
نجرب

تحية 
"""
print(p.send('966557565667', ms))
p.getbalance()
'''


# @auth.requires_membership("user1")
@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


@auth.requires_membership("user1")
def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(1002)
def purchase():
    q = db(db.invoice_master.customer == request.args(0)).select(
        orderby=~db.invoice_master.id, limitby=(0, 50)
    )
    return dict(data=q)


@can_access(1003)
def customers_pay():
    sc = screens_rules(1003)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    db.customers_pay.customers_id.default = request.args(0)
    db.customers_pay.customers_id.writable = False
    db.customers_pay.customers_id.readable = False
    db.customers_pay.customers_pay_data.writable = False
    db.customers_pay.customers_pay_data.readable = False
    db.customers_pay.created_on.readable = True
    q = db.customers_pay.customers_id == request.args(0)
    headers = {
        "customers_pay.id": "رقم السند",
        "customers_pay.amount": "المبلغ المسدد",
        "customers_pay.pay_note": "ملاحظات",
        "customers_pay.pay_type": "النوع",
        "customers_pay.created_on": "تاريخ و وقت السند",
    }
    fields = [
        db.customers_pay.id,
        db.customers_pay.amount,
        db.customers_pay.pay_note,
        db.customers_pay.pay_type,
        db.customers_pay.created_on,
    ]
    links = [
        lambda row: A(
            IMG(_src="../../static/svg/045-printer.svg", _width="24px"),
            _role="button",
            _title="طباعة السند",
            _target="_blank",
            _href=URL("customers", "pay_print", args=[row.id]),
        ),
    ]
    grid = SQLFORM.grid(
        q,
        headers=headers,
        fields=fields,
        links=links,
        user_signature=False,
        details=False,
        editable=can_edit,
        deletable=can_delete,
        create=can_add,
        csv=False,
        searchable=False,
        showbuttontext=True,
        
        args=request.args[:1],
    )
    return dict(grid=grid)


@can_access(1004)
def customers_pay_all():
    sc = screens_rules(1004)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    q = db.customers_pay  # .customers_id == request.args(0)
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=can_edit,
        deletable=can_delete,
        create=can_add,
        csv=False,
        searchable=True,
        showbuttontext=False,
    )
    return dict(grid=grid)


@auth.requires_membership("user1")
def customers_accounts_settlement():
    return dict()


@auth.requires_membership("user1")
def accounts_settlement():
    ts = db(db.customers_accounts_settlement.customers_id == request.args(0)).select()
    if ts:
        sd = ts.last().settlement_data
        qry = (
            "select sum(total_after_discount) from invoice_master where customer ="
            + request.args(0)
            + " and payment_method=3 and created_on>='"
            + str(sd)
            + "'"
        )
        qs = db.executesql(qry)
        mm1 = qs[0][0]
        mm1 = (mm1) and mm1 or 0
        qry = (
            "select sum(amount) from customers_pay where customers_id ="
            + request.args(0)
            + "  and created_on>='"
            + str(sd)
            + "'"
        )
        qs = db.executesql(qry)
        mm2 = qs[0][0]
        mm2 = (mm2) and mm2 or 0
        if (int(mm1) == int(mm2)) and (int(mm1) == int(mm2) != 0):
            db.customers_accounts_settlement.insert(customers_id=request.args(0))
        return redirect(URL("customers", "index"))
    else:
        qry = (
            "select sum(total_after_discount) from invoice_master where payment_method=3 and customer ="
            + request.args(0)
        )
        qs = db.executesql(qry)
        m1 = qs[0][0]
        qry = (
            "select sum(amount) from customers_pay where customers_id ="
            + request.args(0)
        )
        qs = db.executesql(qry)
        m2 = qs[0][0]
        if int(m1) == int(m2) and (int(m1) == int(m2) != 0):
            db.customers_accounts_settlement.insert(customers_id=request.args(0))
        return redirect(URL("customers", "index"))


def customers_accounts_calc():
    qry = (
        "update customers set total = (select round( CAST(COALESCE(sum(total_after_discount) ,0) as numeric) ,2) from invoice_master "
        " where payment_method=3 and customer =" + request.args(0) + " ) ,  "
        " payed=( select round( CAST( COALESCE(sum(amount),0) as numeric) ,2) from customers_pay where customers_id ="
        + request.args(0)
        + ") , "
        " returns = (select round( CAST(COALESCE(sum(total_after_discount),0) as numeric) ,2) from inv_return_master where payment_method=3 and customer ="
        + request.args(0)
        + " ) , "
        " amount = round( CAST((select COALESCE(sum(total_after_discount),0) from invoice_master where payment_method=3 and customer ="
        + request.args(0)
        + " ) "
        " - ( select COALESCE(sum(amount),0) from customers_pay where customers_id ="
        + request.args(0)
        + ") "
        " - (select COALESCE(sum(total_after_discount),0) from inv_return_master where payment_method=3 and customer ="
        + request.args(0)
        + " ) as numeric) ,2)  "
        " where id = " + request.args(0)
    )
    db.executesql(qry)
    return redirect(URL("customers", "index"))


## ========================= Ver 4.0 ==============================
# ===================================================================


def customer_status_rep():
    return dict()


def pay_print():
    return dict()


def report_cost_1():
    return dict()


def report_cost_2():
    return dict()


def report_cost_3():
    return dict()


def report_cost_4():
    return dict()
