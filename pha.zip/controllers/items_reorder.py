# -*- coding: utf-8 -*-
#  type: ignore
import gluon.contrib.simplejson
import math
import os
import threading
import time
import _thread


# _lock = threading.RLock()
# =======================================================================
@can_access(3010)
def index():
    return dict()


# =======================================================================
@can_access(3010)
def new():
    return dict()


# =======================================================================
import os
import shlex, subprocess
import sys
from pathlib import Path


@can_access(3010)
def preparation_reorder():
    # _thread.start_new_thread(excelFilePros1 ,( request.args(0) ,) )
    THIS_FOLDER = Path(__file__).resolve().parents[1]
    my_file = os.path.join(THIS_FOLDER, "scripts")
    my_file = os.path.join(my_file, "reorder.py")
    db_name = db._uri.split("/")[-1]
    if sys.platform.startswith("win32"):
        print("ok")
        command1 = subprocess.Popen(
            ["python", my_file, request.args(0), db_name],
            shell=False,
            stdin=None,
            stdout=None,
            stderr=None,
            close_fds=True,
        )
        print(command1)
    elif sys.platform.startswith("linux"):
        command1 = subprocess.Popen(
            ["python3", my_file, request.args(0), db_name],
            shell=False,
            stdin=None,
            stdout=None,
            stderr=None,
            close_fds=True,
        )
    return dict()


def excelFilePros1(sh):
    db._adapter.reconnect()
    try:
        # print "----------  start  ----------"
        Order = db.items_reorder[sh]
        Order.jop_start_time = datetime.datetime.now().strftime("%H:%M:%S")
        if (Order.supplier) and (Order.key_type):
            # print "all"
            qry = db(
                (db.items_main.suppliers == Order.supplier)
                & (db.items_main.item_type == Order.key_type)
            ).select(orderby=db.items_main.id)
        elif Order.key_type != None:
            # print "type only"
            qry = db(db.items_main.item_type == Order.key_type).select(
                orderby=db.items_main.id
            )
        elif Order.supplier != "":
            # print "suppliers only"
            qry = db(db.items_main.suppliers == Order.supplier).select(
                orderby=db.items_main.id
            )
        db(db.items_reorder_detail.items_reorder == sh).delete()
        db.commit()
        sum = db.items_det.items_count.sum()
        # print ('==============')
        for r in qry:
            sum_row = db(db.items_det.item_idr == r.id).select(sum).first()[sum]
            avrg_itms_qry = (
                "select sum(item_count)from  invoice_details "
                " where item_number in (select id from items_det where item_idr =  "
                + str(r.id)
                + " )"
                " and created_on> date_trunc('month', CURRENT_DATE) - INTERVAL '"
                + str(Order.avrg_by)
                + " month'  "
            )
            avrg_itms = db.executesql(avrg_itms_qry, as_dict=True)
            avrg_item = ((avrg_itms[0]["sum"] or 0) / Order.avrg_by) or 0
            best_price_qry = (
                " select min(buy_price)  from  items_det  "
                "     where item_idr =  " + str(r.id) + "  "
                "     and buy_price > 0  "
                "     and created_on> date_trunc('month', CURRENT_DATE) - INTERVAL '"
                + str(Order.avrg_by)
                + " month' "
            )
            best_price_row = db.executesql(best_price_qry, as_dict=True)
            # مشكلة سعر الشراء اذا كان الصنف لم يشترى خلال الفترة المحددة
            best_price = best_price_row[0]["min"] or 0
            order_items = (avrg_item * Order.order_by) - (sum_row or 0)
            # print r.id
            if (order_items) < (avrg_item / 2):
                order_items = 0
            if order_items < 0:
                order_items = 0
            items_main = db.items_main[r.id]
            nr1 = db.items_reorder_detail.insert(
                items_reorder=sh,
                items_main=r.id,
                supplier=items_main.suppliers,
                key_type=items_main.item_type,
                quantity=round((sum_row or 0), 2),
                avrg_items=round(avrg_item, 2),
                order_items=math.ceil(order_items),
                best_price=round(best_price, 2),
            )
        Order.jop_end_time = datetime.datetime.now().strftime("%H:%M:%S")
        Order.row_count = len(qry)
        Order.update_record()
        db.commit()
        # print "----------  end  ----------"
    except Exception as e:
        print(e)
    db._adapter.close()
    _lock.acquire()
    _lock.release()


# =======================================================================
@can_access(3010)
def show_reorder():
    return dict()


# ========================================================================
#          عمليات شاشة ادخال الاصناف من فواتير التوريد
# ========================================================================
@can_access(3010)
def get_key_types():
    q = db(db.key_type.id > 0).select()
    return response.json(q)


def get_suppliers():
    q = db(db.suppliers.stoped == False).select(
        db.suppliers.id, db.suppliers.name, orderby=db.suppliers.id
    )
    return response.json(q)


def get_items_reorder():
    qry = "SELECT * FROM items_reorder  order by id desc limit 20"
    det_items = db.executesql(qry, as_dict=True)
    for r in det_items:
        # r['name'] = db.items_main[r.item_idr].name
        if r["supplier"]:
            r["supplier"] = db.suppliers[r["supplier"]].name
        if r["key_type"]:
            r["key_type"] = db.key_type[r["key_type"]].name
    return response.json(det_items)
    # --------------------------------------


def get_items_reorder_detail():
    qry = (
        "SELECT *,(select upper(name) from items_main  where items_main.id= items_main ) as "
        "items_main_name  , "
        " (select item_id from items_main  where items_main.id= items_main ) as item_id"
        " FROM items_reorder_detail  where items_reorder="
        + request.args(0)
        + " order by items_main_name  "
    )
    det_items = db.executesql(qry, as_dict=True)
    for r in det_items:
        # r['name'] = db.items_main[r.item_idr].name
        if r["supplier"]:
            r["supplier"] = db.suppliers[r["supplier"]].name
        if r["key_type"]:
            r["key_type"] = db.key_type[r["key_type"]].name
        if r["best_price"]:
            qq = (
                "select * from items_det where item_idr="
                + str(r["items_main"])
                + " and buy_price ="
                + str(r["best_price"])
                + " ORDER BY id DESC LIMIT 1 "
            )
            # print qq
            item = db.executesql(qq, as_dict=True)
            # r['best_price_supp'] = db.suppliers_bills[item[0]['supplier_inv']].supplier.name
            r["best_price_supp_n"] = db.suppliers_bills[
                item[0]["supplier_inv"]
            ].supplier.name
    return response.json(det_items)


@can_access(3010)
def search_item():
    search = request.vars.itid
    srh = search.split()
    data = []
    if len(srh) == 1:
        qry = (
            "select * from items_main  where LOWER(name) like '%"
            + str(request.vars.itid.lower())
            + "%' order by name asc limit 10"
        )
        data = db.executesql(qry, as_dict=True)
    elif len(srh) == 2:
        qry = (
            "select * from items_main  where LOWER(name) like '%"
            + str(srh[0].lower())
            + "%' and LOWER(name) like '%"
            + str(srh[1].lower())
            + "%'   order by name asc limit 10"
        )
        data = db.executesql(qry, as_dict=True)
    return response.json(data)


@can_access(3010)
def addit():
    try:
        itm = request.vars
        type_id = ""
        supp_id = ""
        if int(itm["type_id"]) > 0:
            type_id = int(itm["type_id"])
        if int(itm["supp_id"]["id"]) > 0:
            supp_id = int(itm["supp_id"]["id"])
        new_row = db.items_reorder.validate_and_insert(
            dis=itm["dis"],
            supplier=supp_id,
            key_type=type_id,
            avrg_by=float(itm["avrg_by"]),
            order_by=float(itm["order_by"]),
        )
        db.commit()
        if new_row.id > 0:
            return "0"
        else:
            return "1"
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e[0]}
        return response.json(ret)


@can_access(3010)
def delete_order():
    row = db.items_reorder[request.args(0)]
    if row == None:
        return "هذه الطلبية غير صحيحة"
    row.delete_record()
    redirect(URL("items_reorder", "index"))


# <=============================    end   ===============================>


def deleteall():
    db.executesql("delete from items_reorder")
    db.executesql("delete from items_reorder_detail")
    redirect(URL("items_reorder", "index"))
