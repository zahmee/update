# -*- coding: utf-8 -*-
#  type: ignore

from pathlib import Path
import os
import time
import shlex, subprocess
import sys
import threading
_lock = threading.RLock()
import xlsxwriter

def get_key_types():
    q  = db(db.key_type.id>0).select(db.key_type.ALL)
    return response.json(q)

def update_h():
    #q = "update suppliers set  stoped='F'  "
    db.executesql(q)
    return 'ok'

def get_suppliers():
    q  = db(db.suppliers.stoped==False).select(db.suppliers.id ,db.suppliers.name , orderby=db.suppliers.id )
    return response.json(q)


def preparation_report():
    qry = ("update items_main "
                " set  "
                "     report_year = EXTRACT(year FROM CURRENT_DATE) , "
                "     report_month = EXTRACT(MONTH FROM CURRENT_DATE) , "
                "     report_date = localtimestamp , "
                "     selling_average = ( select sum(item_count)from  invoice_details "
                "                 where item_number in "
                "                       ( select id from items_det where item_idr = items_main.id ) "
                "                 and created_on> "
                "                 date_trunc('month', CURRENT_DATE) - INTERVAL '1 year' )  "
                )
    db.executesql(qry)
    redirect(URL('items_rep','rep1'))

def rep1_api():
    if request.args(0) == '10' :
        if request.args(1) != '0' :
            """
            qry = ("update items_main "
                " set  "
                "     report_year = EXTRACT(year FROM CURRENT_DATE) , "
                "     report_month = EXTRACT(MONTH FROM CURRENT_DATE) , "
                "     selling_average = ( select sum(item_count)from  invoice_details "
                "                 where item_number in "
                "                       ( select id from items_det where item_idr = items_main.id ) "
                "                 and created_on> "
                "                 date_trunc('month', CURRENT_DATE) - INTERVAL '1 year' )  "
                " where item_type="+request.args(1) 
                )
            db.executesql(qry)
            """
            qry = ("update items_main "
                " set  "
                " existing = (select sum(items_count) from items_det where item_idr = items_main.id ) ,  "
                " lowest_price = (select min(buy_price) from items_det where item_idr = items_main.id ) ,  "
                " quantity_reorder = selling_average / 12 , "
                " quantity_order = (selling_average / 12)/2 "
                " where item_type="+request.args(1) 
            )
            db.executesql(qry)
            qry = ("update items_main "
                " set  "
                " quantity_reorder = 1   "
                " where quantity_reorder <1 and item_type="+request.args(1) 
            )
            db.executesql(qry)
            qry = ("update items_main "
                " set  "
                " quantity_order = 1   "
                " where quantity_order <1 and item_type="+request.args(1) 
            )
            db.executesql(qry)
            qry = ("select id , name , report_year ,report_month ,item_type ,seasonal_drug , "
                "        selling_average , existing , quantity_reorder ,quantity_order , "
                "            (quantity_reorder - existing ) as now_order ,lowest_price , "
                "         ( select name from key_type where id=items_main.item_type) as key_types ,"
                "         ( select name from suppliers where id=items_main.suppliers) as suppliers "
                "    from items_main "
                "    where existing < quantity_order  and item_type="+request.args(1) +
                " and halt ='F'  order by name "
                ) 
            qs = db.executesql(qry, as_dict=True)
            return response.json(qs)
        elif request.args(1)=='0'  :
            """
            qry = ("update items_main "
                " set  "
                "     report_year = EXTRACT(year FROM CURRENT_DATE) , "
                "     report_month = EXTRACT(MONTH FROM CURRENT_DATE) , "
                "     selling_average = ( select sum(item_count)from  invoice_details "
                "                 where item_number in "
                "                       ( select id from items_det where item_idr = items_main.id ) "
                "                 and created_on> "
                "                 date_trunc('month', CURRENT_DATE) - INTERVAL '1 year' )  "
                " where item_type is null " 
                )
            qq = db.executesql(qry)
            """
            qry = ("update items_main "
                " set  "
                " existing = (select sum(items_count) from items_det where item_idr = items_main.id ) ,  "
                " lowest_price = (select min(buy_price) from items_det where item_idr = items_main.id ) ,  "
                " quantity_reorder = (selling_average / 12)+1 , "
                " quantity_order = (selling_average / 12)/2 "
                " where item_type is null " 

            )
            qq = db.executesql(qry)
            qry = ("select id , name , report_year ,report_month ,item_type , "
                "        selling_average , existing , quantity_reorder ,quantity_order , "
                "            (quantity_reorder - existing ) as now_order ,lowest_price , "
                "         ( select name from key_type where id=items_main.item_type) as key_types ,"
                "         ( select name from suppliers where id=items_main.suppliers) as suppliers "
                "    from items_main "
                "    where existing < quantity_order  and item_type is null " 
                " and halt ='F'  order by name "
                ) 
            qs = db.executesql(qry, as_dict=True)
            return response.json(qs)
    elif request.args(0) == '20' :
            """
            qry = ("update items_main "
                " set  "
                "     report_year = EXTRACT(year FROM CURRENT_DATE) , "
                "     report_month = EXTRACT(MONTH FROM CURRENT_DATE) , "
                "     selling_average = ( select sum(item_count)from  invoice_details "
                "                 where item_number in "
                "                       ( select id from items_det where item_idr = items_main.id ) "
                "                 and created_on> "
                "                 date_trunc('month', CURRENT_DATE) - INTERVAL '1 year' )  "
                " where suppliers="+request.args(2) 
                )
            db.executesql(qry)
            """
            qry = ("update items_main "
                " set  "
                " existing = (select sum(items_count) from items_det where item_idr = items_main.id ) ,  "
                " lowest_price = (select min(buy_price) from items_det where item_idr = items_main.id ) ,  "
                " quantity_reorder = selling_average / 12 , "
                " quantity_order = (selling_average / 12)/2 "
                " where suppliers="+request.args(2) 
            )
            db.executesql(qry)
            db.executesql(qry)
            qry = ("update items_main "
                " set  "
                " quantity_reorder = 1   "
                " where quantity_reorder <1 and suppliers="+request.args(2) 
            )
            db.executesql(qry)
            qry = ("update items_main "
                " set  "
                " quantity_order = 1   "
                " where quantity_order <1 and suppliers="+request.args(2) 
            )
            db.executesql(qry)
            qry = ("select id , name , report_year ,report_month ,item_type ,seasonal_drug , "
                "        selling_average , existing , quantity_reorder ,quantity_order , "
                "            (quantity_reorder - existing ) as now_order ,lowest_price , "
                "         ( select name from key_type where id=items_main.item_type) as key_types ,"
                "         ( select name from suppliers where id=items_main.suppliers) as suppliers "
                "    from items_main "
                "    where existing < quantity_order  and suppliers="+request.args(2) +
                " and halt ='F'  order by name "
                ) 
            qs = db.executesql(qry, as_dict=True)
            return response.json(qs)


def rep1():
    return dict( )

def items_report_crate():
    THIS_FOLDER = Path(__file__).resolve().parents[1]
    my_file = os.path.join(THIS_FOLDER, "static")
    my_file = os.path.join(my_file, 'all_items_in_stock.xlsx')
    file1 = Path(my_file)
    if file1.is_file():
        f1_date = time.strftime('%m/%d/%Y  %H:%M:%S', time.localtime(os.path.getmtime(file1)))
    else:
        f1_date = 'الملف غير موجود'
    
    my_file = os.path.join(THIS_FOLDER, "static")
    my_file = os.path.join(my_file, 'items_sales_in_date.xlsx')
    file2 = Path(my_file)
    if file2.is_file():
        f2_date = time.strftime('%m/%d/%Y  %H:%M:%S', time.localtime(os.path.getmtime(file2)))
    else:
        f2_date = 'الملف غير موجود'
    return dict(f1=f1_date , f2 = f2_date )

def pre_report1():
    THIS_FOLDER = Path(__file__).resolve().parents[1]
    my_file = os.path.join(THIS_FOLDER, "scripts")
    my_file = os.path.join(my_file, 'all_items_in_stock.py')
    db_name = db._uri.split("/")[-1]
    if sys.platform.startswith('win32'):
        command1 = subprocess.Popen(['python', my_file , db_name ], shell=False, stdin=None, stdout=None, stderr=None, close_fds=True)
    elif sys.platform.startswith('linux'):
        command1 = subprocess.Popen(['python3', my_file , db_name ], shell=False, stdin=None, stdout=None, stderr=None, close_fds=True)
    return '0'



def pre_report2():
    r = lambda s: str(datetime.datetime.now()) if s == '' else str(s)
    sart_date= r(request.vars.da1)
    end_date= r(request.vars.da2)
    x = threading.Thread(target=pre_report2_1 ,args=(sart_date,end_date,) )
    x.start()
    return '0'

def pre_report2_1(da1 , da2 ):
    db._adapter.reconnect()
    try:
        THIS_FOLDER = Path(__file__).resolve().parents[1]
        my_file = os.path.join(THIS_FOLDER, "static")
        my_file = os.path.join(my_file, 'items_sales_in_date.xlsx')
        workbook = xlsxwriter.Workbook(my_file)
        r = lambda s: str(datetime.datetime.now()) if s == '' else str(s)
        sart_date= r(da1)
        end_date= r(da2)
        #print ('====================================    start    up     ===================================================')
        db.executesql("SET datestyle = US, MDY;")
        qry = ("select ( select name from customers where id = "
            " ( select customer from invoice_master  "
            "  where invoice_master.uuid = invoice_details.uuid ) ) as coust  , "
            "  ( select name from key_payment_method where id =  "
            "   ( select payment_method from invoice_master  "
            "    where invoice_master.uuid = invoice_details.uuid ) ) as payment_method  , "
            "    ( select id  from invoice_master  "
            " 	where invoice_master.uuid = invoice_details.uuid  ) as inv_no  , "
            " 	( select id from items_det where id = item_number ) as id_det , "
            " 	( select name from items_main where id =  "
            " 	 ( select item_idr from items_det where id = item_number ) ) as name , "
            " 	 vat , item_count ,created_on , created_by , "
            " 	  ( select  first_name ||' '|| last_name  from auth_user where id = created_by ) as created_name , "
            " 	  ( select public_price from items_det where id = item_number ) as price , "
            " 	   total , "
            " 	   vat_total "
            " 	 from invoice_details  where created_on >= '"+sart_date+"' and created_on <= '"+end_date+"'  " )
        q = db.executesql(qry, as_dict=True)
        qry = ("select ( select name from customers where id = "
            " ( select customer from inv_return_master  "
            "  where inv_return_master.uuid = inv_return_details.uuid ) ) as coust  , "
            "  ( select name from key_payment_method where id =  "
            "   ( select payment_method from inv_return_master  "
            "    where inv_return_master.uuid = inv_return_details.uuid ) ) as payment_method  , "
            "    ( select id  from inv_return_master  "
            " 	where inv_return_master.uuid = inv_return_details.uuid  ) as inv_no  , "
            " 	( select id from items_det where id = item_number ) as id_det , "
            " 	( select name from items_main where id =  "
            " 	 ( select item_idr from items_det where id = item_number ) ) as name , "
            " 	 vat , item_count ,created_on , created_by ,"
            " 	  ( select  first_name ||' '|| last_name  from auth_user where id = created_by ) as created_name , "
            " 	  ( select public_price from items_det where id = item_number ) as price , "
            " 	   total , "
            " 	   vat_total "
            " 	 from inv_return_details  where created_on >= '"+sart_date+"' and created_on <= '"+end_date+"'  " )
        q2 = db.executesql(qry, as_dict=True)
        worksheet = workbook.add_worksheet()
        bold = workbook.add_format()
        bold.set_font_size(12)
        bold.set_align('center')
        bold.set_bold()
        bold.set_font_name('Segoe UI')
        format_right_to_left = workbook.add_format({'reading_order': 2 , 'border': 1 })
        worksheet.right_to_left()
        worksheet.repeat_rows(0)    
        worksheet.set_landscape() 
        worksheet.set_header(f'&C&24 المبيعات التفصيلية من {sart_date} الى  {end_date}    ')
        worksheet.set_footer('&Cصفحة &P من &N     &Rطبعة في  &D   &T')
        worksheet.set_margins(0.7 ,0.7,0.7,0.7)
        worksheet.set_paper(9)
        workbook.set_properties({
            'title':    'كشف بالاصناف',
            'subject':  'With document properties',
            'author':   'صدارة التطوير و البرمجة',
            'manager':  'Dr. Heinz Doofenshmirtz',
            'company':  'صدارة التطوير و البرمجة',
            'category': 'كشف',
            'keywords': 'Sample, Example, Properties',
            'comments': 'Created with Python and XlsxWriter',
            'status':   'Quo',
        })
        worksheet.fit_to_pages(1, 0)  
        format = workbook.add_format()
        format.set_font_size(11)
        format.set_font_name('Segoe UI')
        memo = workbook.add_format()
        memo.set_font_size(16)
        memo.set_font_name('Segoe UI')
        memo.set_text_wrap()
        """
        worksheet.write('A1', u'الفاتورة', bold  )
        worksheet.write('A1', u'الدفع', bold  )
        worksheet.write('A1', u'اسم العميل', bold  )
        worksheet.write('B1', u'رقم الصنف', bold  )
        worksheet.write('C1', u'اسم الصنف', bold  )
        worksheet.write('D1', u'VAT', bold )
        worksheet.write('E1', u' العدد', bold )
        worksheet.write('F1', u'المبلغ', bold )
        worksheet.write('G1', u'الاجمالي', bold )
        worksheet.write('H1', u'الضريبة ', bold )
        worksheet.write('I1', u'تصنيف الصنف', bold  )
        worksheet.write('J1', u'مجموعة الصنف', bold  )
        worksheet.write('K1', u'البائع', bold  )
        worksheet.write('L1', u'الرقم الدولي', bold  )
        """
        # ---------------------------------------------------------------
        worksheet.set_column('A:A', 10)
        worksheet.set_column('B:B', 10)
        worksheet.set_column('C:C', 22)
        worksheet.set_column('D:D', 10)
        worksheet.set_column('E:E', 50)
        worksheet.set_column('F:F', 8)
        worksheet.set_column('G:G',8)
        worksheet.set_column('H:H', 10)
        worksheet.set_column('I:I', 12)
        worksheet.set_column('J:J', 12)
        worksheet.set_column('K:K', 18)
        worksheet.set_column('L:L', 20)
        worksheet.set_column('M:M', 10)
        worksheet.set_column('N:N', 20)
        worksheet.set_column('O:O', 20)
        worksheet.set_column('P:P', 12)
        format2 = workbook.add_format({'num_format': 'dd/mm/yyyy HH:MM:ss'})
        row = 1
        col = 0
        for r in (q):
            it_det = db.items_det[r['id_det']]
            worksheet.write  ( row , col      , r['inv_no']         , format  )
            worksheet.write  ( row , col + 1  , r['payment_method']  , format  ) 
            worksheet.write  ( row , col + 2  , r['coust'] or '--'            , format  )
            worksheet.write  ( row , col + 3  , r['id_det']         , format  ) 
            worksheet.write  ( row , col + 4  , r['name'] or '--'            , format  )  
            worksheet.write  ( row , col + 5  , r['vat']            , format  )
            worksheet.write  ( row , col + 6  , float(r['item_count'] or 0 )    , format  )
            worksheet.write  ( row , col + 7  , float(r['price'] or 0  )        , format  )
            worksheet.write  ( row , col + 8  , float(r['total'] or 0  )        , format  )
            worksheet.write  ( row , col + 9  , float(r['vat_total'] or 0 )      , format  )
            worksheet.write  ( row , col + 10 , r['created_on']     , format2  )
            if it_det.item_idr.item_type :
                it_ty = it_det.item_idr.item_type.name
            else :
                it_ty ='-'
            worksheet.write  ( row , col + 11 , it_ty     , format  )
            worksheet.write  ( row , col + 12 , it_det.item_idr.item_group   , format  )
            worksheet.write  ( row , col + 13 , it_det.item_idr.item_id   , format  )
            worksheet.write  ( row , col + 14 , r['created_name']   , format  )
            worksheet.write  ( row , col + 15 , 'مبيعات'   , format  )
            row += 1
        for r in (q2):
            it_det = db.items_det[r['id_det']]
            worksheet.write  ( row , col      , r['inv_no']         , format  )
            worksheet.write  ( row , col + 1  , r['payment_method']  , format  ) 
            worksheet.write  ( row , col + 2  , r['coust'] or '--'            , format  )
            worksheet.write  ( row , col + 3  , r['id_det']         , format  ) 
            worksheet.write  ( row , col + 4  , r['name'] or '--'            , format  )  
            worksheet.write  ( row , col + 5  , r['vat']            , format  )
            worksheet.write  ( row , col + 6  , float(r['item_count'] or 0 )    , format  )
            worksheet.write  ( row , col + 7  , float(r['price'] or 0  )        , format  )
            worksheet.write  ( row , col + 8  , float(r['total'] or 0  )        , format  )
            worksheet.write  ( row , col + 9  , float(r['vat_total'] or 0 )      , format  )
            worksheet.write  ( row , col + 10 , r['created_on']     , format2  )
            if it_det.item_idr.item_type :
                it_ty = it_det.item_idr.item_type.name
            else :
                it_ty ='-'
            worksheet.write  ( row , col + 11 , it_ty     , format  )
            worksheet.write  ( row , col + 12 , it_det.item_idr.item_group   , format  )
            worksheet.write  ( row , col + 13 , it_det.item_idr.item_id   , format  )
            worksheet.write  ( row , col + 14 , r['created_name']   , format  )
            worksheet.write  ( row , col + 15 , 'مرتجعات'   , format  )
            row += 1
        worksheet.add_table('A1:P'+str(row+1 ), {'total_row': True ,
            'columns':[
                {'header': u'الفاتورة' ,           'header_format' : bold , 'total_string': 'الاجمالي'},
                {'header': u'الدفع' ,              'header_format' : bold , 'total_function': 'count'},
                {'header': u'اسم العميل' ,         'header_format' : bold , 'total_string': ' '},
                {'header': u'رقم الصنف' ,          'header_format' : bold , 'total_string': ' '},
                {'header': u'اسم الصنف' ,          'header_format' : bold , 'total_string': ' '},
                {'header': u'VAT',                  'header_format' : bold , 'total_string': ' '},
                {'header': u' العدد' ,              'header_format' : bold , 'total_function': 'sum'},
                {'header': u'المبلغ' ,              'header_format' : bold , 'total_function': 'sum'},
                {'header': u'الاجمالي' ,             'header_format' : bold , 'total_function': 'sum'},
                {'header': u'الضريبة ' ,            'header_format' : bold , 'total_function': 'sum'},
                {'header': u'التاريخ' ,             'header_format' : bold , 'total_string': ' '},
                {'header': u'التصنيف' ,             'header_format' : bold , 'total_string': ' '},
                {'header': u'المجموعة' ,            'header_format' : bold , 'total_string': ' '},
                {'header': u'الرقم الدولي' ,        'header_format' : bold , 'total_string': ' '},
                {'header': u'البائع' ,              'header_format' : bold , 'total_string': ' '},
                {'header': u'نوعها' ,               'header_format' : bold , 'total_string': ' '},
            ], 'autofilter': True ,                  'style': 'Table Style Light 8' })
        workbook.close()
        #print ('====================================        end         ===================================================')
    except Exception as e:
        print(e)
    _lock.acquire()
    _lock.release()
    db._adapter.close()


#=================================================================================================
#=================================================================================================

def show1():
    import pandas as pd
    import matplotlib.pyplot as plt
    import io
    import base64
    #s = pd.Series([1, 10, 3,5,6,2,4,8])
    #fig, ax = plt.subplots()
    #s.plot.bar()
    a1 = [1,5,9,5,7,3,6]
    a2 = [3,9,8,5,4,5,2]
    a3 = [9,8,1,6,2,4,8]
    plt.plot(a1,a2,a3)
    fig2  = plt

    img = io.BytesIO()
    fig2.savefig(img, format='png', bbox_inches='tight')
    img.seek(0)
    encoded = base64.b64encode(img.getvalue())
    my_html = '<img src="data:image/png;base64, {}">'.format(encoded.decode('utf-8'))
    return my_html

def s1():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.switch_backend('agg')
    import io
    import base64
    import numpy as np 
    a1 = [1,2,3,4,5,6,7]
    a2 = [3,9,8,5,4,5,2]
    a3 = [9,8,1,6,2,4,8]
    x_index = np.arange(len(a1))
    width = 0.2
    plt.barh(x_index,a2 , height=width ,label="aaaa" )
    plt.barh(x_index-width ,a3 , height=width  )
    plt.xlabel(" year ")
    plt.ylabel(" dayes ")
    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight', pad_inches = 1 )
    img.seek(0)
    encoded = base64.b64encode(img.getvalue())
    my_html = '<img src="data:image/png;base64, {}">'.format(encoded.decode('utf-8'))
    return my_html


