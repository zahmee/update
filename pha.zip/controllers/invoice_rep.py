# -*- coding: utf-8 -*-
#  type: ignore

# try something like
#   تقارير المبيعات
import xlsxwriter
import io
import sys


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep1():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep2():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep3():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep4():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep5():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep6():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep7():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep8():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep10():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep11():
    return dict()


@auth.requires(auth.has_membership("account") or auth.has_membership("admin"))
def rep12():
    return dict()


# ==============================================================================================================


def excl2():
    import xlsxwriter
    import cStringIO

    qry = "select ( select name from customers where id = ( select customer from invoice_master where invoice_master.uuid = invoice_details.uuid ) ) as coust  , ( select id from items_det where id = item_number ) as id_det , ( select name from items_main where id = ( select item_idr from items_det where id = item_number ) ) as name , ( select vat from items_main where id = ( select item_idr from items_det where id = item_number ) ) as vat ,  item_count ,created_on ,  ( select public_price from items_det where id = item_number ) as price ,  ( item_count * ( select public_price from items_det where id = item_number ) ) as total ,   ( item_count * ( select public_price from items_det where id = item_number ) * ( select vat from items_main where id = ( select item_idr from items_det where id = item_number ) )  ) as  vat_total from invoice_details  where created_on > '2018-07-01' and created_on < '2018-10-01' "
    q = db.executesql(qry, as_dict=True)
    # inf = db(db.information.id>0).select().first()
    # q = db((db.account_movement.date_year == inf.present_year ) and (db.account_movement.date_month == inf.present_month )).select()
    filename = "excel_movment.xlsx"
    stream = cStringIO.StringIO()
    workbook = xlsxwriter.Workbook(stream)
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align("center")
    bold.set_bold()
    bold.set_font_name("Segoe UI")

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name("Segoe UI")

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name("Segoe UI")
    memo.set_text_wrap()

    """
    worksheet.set_column('A:A', 20)
    bold = workbook.add_format({'bold': True})
    worksheet.write('A1', u'مرحبا بكم')
    worksheet.write('A2', 'World', bold)
    worksheet.write(2, 0, 123)
    worksheet.write(3, 0, 123.456)
    # worksheet.insert_image('B5', 'logo.png')
    """
    worksheet.write("A1", "اسم العميل", bold)
    worksheet.write("B1", "رقم الصنف", bold)
    worksheet.write("C1", "اسم الصنف", bold)
    worksheet.write("D1", "VAT", bold)
    worksheet.write("E1", " العدد", bold)
    worksheet.write("F1", "المبلغ", bold)
    worksheet.write("G1", "الاجمالي", bold)
    worksheet.write("H1", "الضريبة المحصلة", bold)
    # ---------------------------------------------------------------
    worksheet.set_column("A:A", 30)
    worksheet.set_column("B:B", 12)
    worksheet.set_column("C:C", 50)
    worksheet.set_column("D:D", 22)
    worksheet.set_column("E:E", 12)
    worksheet.set_column("F:F", 20)
    worksheet.set_column("G:G", 20)
    worksheet.set_column("H:H", 20)
    worksheet.set_column("I:I", 20)
    format2 = workbook.add_format({"num_format": "dd/mm/yyyy"})
    row = 1
    col = 0
    for r in q:
        # print r
        worksheet.write(row, col, r["coust"], format)
        worksheet.write(row, col + 1, r["id_det"], format)
        worksheet.write_string(row, col + 2, r["name"], format)
        worksheet.write(row, col + 3, r["vat"], format)
        worksheet.write(row, col + 4, r["item_count"], format)
        worksheet.write(row, col + 5, r["price"], format)
        worksheet.write(row, col + 6, r["total"], format)
        worksheet.write(row, col + 7, r["vat_total"], format)
        worksheet.write(row, col + 8, r["created_on"], format2)
        row += 1
    worksheet.add_table(
        "A1:I" + str(row),
        {
            "columns": [
                {"header": "اسم العميل", "header_format": bold},
                {"header": "رقم الصنف", "header_format": bold},
                {"header": "اسم الصنف", "header_format": bold},
                {"header": "VAT", "header_format": bold},
                {"header": " العدد", "header_format": bold},
                {"header": "المبلغ", "header_format": bold},
                {"header": "الاجمالي", "header_format": bold},
                {"header": "الضريبة المحصلة", "header_format": bold},
                {"header": "التاريخ", "header_format": bold},
            ]
        },
    )

    workbook.close()
    response.headers[
        "Content-Type"
    ] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    stream.seek(0)
    return stream.read()


# ==============================================================================================================


def excl21():
    import xlsxwriter
    import cStringIO

    qry = "select ( select name from customers where id = ( select customer from inv_return_master where inv_return_master.uuid = inv_return_details.uuid ) ) as coust  , ( select id from items_det where id = item_number ) as id_det , ( select name from items_main where id = ( select item_idr from items_det where id = item_number ) ) as name , ( select vat from items_main where id = ( select item_idr from items_det where id = item_number ) ) as vat ,  item_count ,created_on ,  ( select public_price from items_det where id = item_number ) as price ,  ( item_count * ( select public_price from items_det where id = item_number ) ) as total ,   ( item_count * ( select public_price from items_det where id = item_number ) * ( select vat from items_main where id = ( select item_idr from items_det where id = item_number ) )  ) as  vat_total from inv_return_details  where created_on > '2018-07-01' and created_on <'2018-10-01' "
    q = db.executesql(qry, as_dict=True)
    # inf = db(db.information.id>0).select().first()
    # q = db((db.account_movement.date_year == inf.present_year ) and (db.account_movement.date_month == inf.present_month )).select()
    filename = "excel_movment.xlsx"
    stream = cStringIO.StringIO()
    workbook = xlsxwriter.Workbook(stream)
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format()
    bold.set_font_size(16)
    bold.set_align("center")
    bold.set_bold()
    bold.set_font_name("Segoe UI")

    format = workbook.add_format()
    format.set_font_size(16)
    format.set_font_name("Segoe UI")

    memo = workbook.add_format()
    memo.set_font_size(16)
    memo.set_font_name("Segoe UI")
    memo.set_text_wrap()

    """
    worksheet.set_column('A:A', 20)
    bold = workbook.add_format({'bold': True})
    worksheet.write('A1', u'مرحبا بكم')
    worksheet.write('A2', 'World', bold)
    worksheet.write(2, 0, 123)
    worksheet.write(3, 0, 123.456)
    # worksheet.insert_image('B5', 'logo.png')
    """
    worksheet.write("A1", "اسم العميل", bold)
    worksheet.write("B1", "رقم الصنف", bold)
    worksheet.write("C1", "اسم الصنف", bold)
    worksheet.write("D1", "VAT", bold)
    worksheet.write("E1", " العدد", bold)
    worksheet.write("F1", "المبلغ", bold)
    worksheet.write("G1", "الاجمالي", bold)
    worksheet.write("H1", "الضريبة المحصلة", bold)
    # ---------------------------------------------------------------
    worksheet.set_column("A:A", 30)
    worksheet.set_column("B:B", 12)
    worksheet.set_column("C:C", 50)
    worksheet.set_column("D:D", 22)
    worksheet.set_column("E:E", 12)
    worksheet.set_column("F:F", 20)
    worksheet.set_column("G:G", 20)
    worksheet.set_column("H:H", 20)
    worksheet.set_column("I:I", 20)
    format2 = workbook.add_format({"num_format": "dd/mm/yyyy"})
    row = 1
    col = 0
    for r in q:
        # print r
        worksheet.write(row, col, r["coust"], format)
        worksheet.write(row, col + 1, r["id_det"], format)
        worksheet.write_string(row, col + 2, r["name"], format)
        worksheet.write(row, col + 3, r["vat"], format)
        worksheet.write(row, col + 4, r["item_count"], format)
        worksheet.write(row, col + 5, r["price"], format)
        worksheet.write(row, col + 6, r["total"], format)
        worksheet.write(row, col + 7, r["vat_total"], format)
        worksheet.write(row, col + 8, r["created_on"], format2)
        row += 1
    worksheet.add_table(
        "A1:I" + str(row),
        {
            "columns": [
                {"header": "اسم العميل", "header_format": bold},
                {"header": "رقم الصنف", "header_format": bold},
                {"header": "اسم الصنف", "header_format": bold},
                {"header": "VAT", "header_format": bold},
                {"header": " العدد", "header_format": bold},
                {"header": "المبلغ", "header_format": bold},
                {"header": "الاجمالي", "header_format": bold},
                {"header": "الضريبة المحصلة", "header_format": bold},
                {"header": "التاريخ", "header_format": bold},
            ]
        },
    )

    workbook.close()
    response.headers[
        "Content-Type"
    ] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    stream.seek(0)
    return stream.read()


# ==============================================================================================================
