# -*- coding: utf-8 -*-
#  type: ignore

import gluon.contrib.simplejson
import math
from datetime import datetime


# =======================================================================
@can_access(3007)
def items_qry():
    return dict()


# ========================================================================
#          عمليات شاشة ادخال الاصناف من فواتير التوريد
# ========================================================================


def getit():
    qry = "select * from items_main  where item_id = '" + str(request.vars.itid) + "'"
    data = db.executesql(qry, as_dict=True)
    if data:
        qry = (
            "SELECT public_price FROM items_det where item_idr="
            + str(data[0]["id"])
            + " ORDER BY id DESC LIMIT 5; "
        )
        data2 = db.executesql(qry, as_dict=True)
        data[0]["old_public_price"] = data2
        if data2:
            data[0]["old_public_price"] = data2
        else:
            data[0]["old_public_price"] = [{"public_price": 0}]
        qry = (
            "SELECT buy_price FROM items_det where item_idr="
            + str(data[0]["id"])
            + " ORDER BY id DESC LIMIT 5; "
        )
        data2 = db.executesql(qry, as_dict=True)
        if data2:
            data[0]["old_buy_price"] = data2
        else:
            data[0]["old_buy_price"] = [{"buy_price": 0}]
        qry = (
            "SELECT vat FROM items_det where item_idr="
            + str(data[0]["id"])
            + " ORDER BY id DESC LIMIT 1; "
        )
        data3 = db.executesql(qry, as_dict=True)
        if data3:
            data[0]["last_vat"] = data3[0]["vat"]
        else:
            data[0]["last_vat"] = 0.15
        return response.json(data)
    else:
        return response.json([])


def gethistory():
    qry = "select * from items_main  where item_id = '" + str(request.vars.itid) + "'"
    main_items = db.executesql(qry, as_dict=True)
    qry = (
        "SELECT * FROM items_det where item_idr ="
        + str(main_items[0]["id"])
        + " order by id desc limit 10"
    )
    det_items = db.executesql(qry, as_dict=True)
    for i in det_items:
        sp_info = db.suppliers_bills[i["supplier_inv"]]
        sp = db.suppliers[sp_info.supplier]
        i["supplier_inv"] = sp.name
    qry = (
        "SELECT max(buy_price) FROM items_det where item_idr ="
        + str(main_items[0]["id"])
        + " and buy_price!=public_price "
    )
    max_items = db.executesql(qry, as_dict=True)
    qry = "SELECT min(buy_price) FROM items_det where item_idr =" + str(
        main_items[0]["id"]
    )
    min_items = db.executesql(qry, as_dict=True)
    data = {"det": det_items, "max": max_items, "min": min_items}
    return response.json(data)
    # --------------------------------------


def search_item():
    search = request.vars.itid
    srh = search.split()
    data = []
    if len(srh) == 1:
        qry = (
            "select * from items_main  where LOWER(name) like '%"
            + str(request.vars.itid.lower())
            + "%' order by name asc limit 10"
        )
        data = db.executesql(qry, as_dict=True)
    elif len(srh) == 2:
        qry = (
            "select * from items_main  where LOWER(name) like '%"
            + str(srh[0].lower())
            + "%' and LOWER(name) like '%"
            + str(srh[1].lower())
            + "%'   order by name asc limit 10"
        )
        data = db.executesql(qry, as_dict=True)
    return response.json(data)


@can_access(3005)
def addit():
    try:
        itm = request.vars.itm
        it_inv = db.suppliers_bills(itm["supplier_inv"])
        if it_inv == None:
            return response.json({"mess": "هذه الفاتورة غير صحيحة"})
        if it_inv.bill_confirmation == True:
            return response.json({"mess": "فاتورة مغلقة"})
        buy_price = itm["buy_price"]
        supplier_inv = itm["supplier_inv"]
        item_idr = itm["item_idr"]
        item_id = itm["item_id"]
        public_price = itm["public_price"]
        expiration_date = itm["expiration_date"]
        inv_price = float(itm["inv_price"])
        vat = float(itm["vat"])
        items_count = itm["items_count"]
        return_count = itm["return_count"]
        vat_in_public_price = itm["vat_in_public_price"]
        if (buy_price is None) or (buy_price == "0"):
            buy_price = float(inv_price) / float(items_count)
        vat_price = 0.0
        # ---------------- حساب الضريبة للصنف
        if vat > 0:
            vat_price = round(inv_price - (math.fabs(float(inv_price)) / (vat + 1)), 2)
        else:
            vat_price = 0
        if itm["editRow"] == False:
            items_det = db.items_det.validate_and_insert(
                supplier_inv=supplier_inv,
                item_idr=item_idr,
                item_id=item_id,
                public_price=math.fabs(float(public_price)),
                items_count=math.fabs(float(items_count)),
                buy_price=math.fabs(float(buy_price)),
                expiration_date=expiration_date,
                inv_price=math.fabs(float(inv_price)),
                vat=math.fabs(float(vat)),
                return_count=math.fabs(float(return_count)),
                quantity=math.fabs(float(items_count)),
                free_quantity=0,
                discount_rate=0,
                discount=0,
                vat_price=vat_price,
                vat_in_public_price=vat_in_public_price,
            )
        else:
            items_det = db.items_det[itm["id"]]
            items_det.supplier_inv = supplier_inv
            items_det.item_idr = item_idr
            items_det.item_id = item_id
            items_det.public_price = math.fabs(float(public_price))
            items_det.items_count = math.fabs(float(items_count))
            items_det.buy_price = math.fabs(float(buy_price))
            items_det.expiration_date = expiration_date
            items_det.inv_price = math.fabs(float(inv_price))
            items_det.vat = math.fabs(float(vat))
            items_det.return_count = math.fabs(float(return_count))
            items_det.quantity = math.fabs(float(items_count))
            items_det.free_quantity = 0
            items_det.discount_rate = 0
            items_det.discount = 0
            items_det.vat_price = vat_price
            items_det.vat_in_public_price = vat_in_public_price
            items_det.update_record()
        db.commit()
        ret = {"id": str(items_det.id)}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "invno": 0, "mess": e[0]}
        return response.json(ret)


@can_access(3005)
def delitm():
    try:
        row = db.items_det[request.args(0)]
        it_inv = db.suppliers_bills(row.supplier_inv)
        if it_inv == None:
            return response.json({"mess": "هذه الفاتورة غير صحيحة"})
        if it_inv.bill_confirmation == True:
            return response.json({"mess": "فاتورة مغلقة"})
        row.delete_record()
        db.commit()
        ret = {"mess": "0"}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        ret = {"err": 3, "invno": 0, "mess": e}
        return response.json(ret)


@can_access(3005)
def get_inv_items():
    inv = int(request.args(0))
    itm = db(db.items_det.supplier_inv == inv).select(orderby=db.items_det.id)
    for r in itm:
        r["name"] = db.items_main[r.item_idr].name
        if r.vat is None:
            r.vat = 0
        if r.return_count is None:
            r.return_count = 0
    return response.json(itm)


# <=============================    end   ===============================>


@auth.requires_membership("admin")
def items_edit():
    itm = db.items_det(request.args(0))
    inv = db.suppliers_bills(itm.supplier_inv)
    if auth.has_membership("admin"):
        response.title = ""
        db.items_det.supplier_inv.readable = False
        db.items_det.item_chked.readable = False
        db.items_det.supplier_inv.writable = False
        db.items_det.item_chked.writable = False
        form = SQLFORM(db.items_det, record=itm)
        if form.process().accepted:
            response.flash = "تمت عملية الحفظ بنجاح"
            redirect(URL("items", "de_it"))
        elif form.errors:
            response.flash = "يوجد خطأ في عملية الحفظ"
        return dict(form=form)
    elif inv.bill_confirmation == False:
        response.title = ""
        db.items_det.supplier_inv.readable = False
        db.items_det.item_chked.readable = False
        db.items_det.supplier_inv.writable = False
        db.items_det.item_chked.writable = False
        form = SQLFORM(db.items_det, deletable=False, record=itm)
        if form.process().accepted:
            response.flash = "تمت عملية الحفظ بنجاح"
            redirect(URL("items", "de_it"))
        elif form.errors:
            response.flash = "يوجد خطأ في عملية الحفظ"
        return dict(form=form)
    else:
        redirect(URL("items", "de_it"))


def rep_byid():
    return dict()


def it_prt_by_item():
    q1 = db(db.items_main.item_id == request.args(0))
    try:
        itm1 = db(db.items_main.item_id == request.args(0)).select().first()
        itm2 = db(db.items_det.item_idr == itm1.id).select().last()
        db1 = db(
            (db.items_det.item_id == db.items_main.item_id)
            & (db.items_det.supplier_inv == itm2.supplier_inv)
            & (db.items_det.id == itm2.id)
        ).select(
            db.items_det.item_id,
            db.items_det.id,
            db.items_main.name,
            db.items_det.items_count,
            db.items_det.public_price,
        )
        return str(db1)
    except Exception as e:
        return str("رقم الصنف المدخل خطأ ، الرجاء ادخال الرقم الدولي ")
    # q1 = db(db.items_main.item_id == request.args(0))
    #
    #    db1= db((db.items_det.item_id==db.items_main.item_id) & (db.items_det.supplier_inv ==request.args(0)) ).select(
    #    db.items_det.item_id,
    #    db.items_det.id,
    #    db.items_main.name,
    #    db.items_det.items_count,
    #    db.items_det.public_price,
    #    db.items_det.vat ,
    #    db.items_det.vat_in_public_price ,
    #    db.items_det.quantity ,
    #    orderby=db.items_det.id
    #    )
    # for r in db1 :
    #    r.items_det.public_price = round((r.items_det.public_price * r.items_det.vat)+r.items_det.public_price , 2)
    #    r.items_det.items_count = r.items_det.quantity
    #    if r.items_det.vat_in_public_price == True :
    #        new_price = round((r.items_det.public_price / (r.items_det.vat+1)) , 2)
    #        r.items_det.public_price = new_price
    # return str(db1)


# ===============================================================================================


def search_item_det():
    search = request.vars.itid
    qry = (
        "select * from items_det  where item_idr ="
        + str(request.vars.itid)
        + " order by id desc limit 1   ; "
    )
    data = db.executesql(qry, as_dict=True)
    return response.json(data)


@auth.requires_membership("admin")
def it_rep1_count():
    inv = request.args(0)
    """
    sum = 0.0
    sum2 = 0.0
    sum3_1 = 0.0
    sum3_2 = 0.0
    itm = db(db.items_det.supplier_inv ==inv ).select()
    for i in itm :
        sum = sum + (i.inv_price or 0 ) 
        sum2 = sum2 + (i.public_price * i.quantity ) 
        sum3_1 = sum3_1 + (i.public_price * i.quantity * (i.vat or 0) ) 
        sum3_2 = sum3_2 + (i.inv_price * (i.vat or 0) ) 
    row = db.suppliers_bills[inv]
    row.update_record(
                bill_selling = sum2 , 
                bill_profit_ratio = round(( (sum2-sum)/sum  )*100 ,2) ,
                bill_profit = sum2-sum 
                )
    db.commit()
    """
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv="
        + inv
        + "  )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv="
        + inv
        + "  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/sum(inv_price))*100 from items_det where supplier_inv="
        + inv
        + "  )) "
        " where id=" + inv
    )
    db.executesql(qry)
    redirect(URL("suppliers", "supply_bills"))


def qur():
    qry = (
        "update suppliers_bills set "
        " bill_selling = ROUND(( select sum(public_price * quantity) from items_det where supplier_inv=suppliers_bills.id   )) , "
        " bill_profit = ROUND(( select (sum(public_price * quantity)-sum(inv_price)) from items_det where supplier_inv=suppliers_bills.id  )) , "
        " bill_profit_ratio = ROUND(( select ((sum(public_price * quantity)-sum(inv_price))/sum(inv_price))*100 from items_det where supplier_inv=suppliers_bills.id  )) "
    )
    db.executesql(qry)
    return "ok"


@can_access(3008)
def items_merge():
    return dict()


@can_access(3008)
def items_merge_a():
    itm_1 = request.args(0)
    itm_2 = request.args(1)
    new_itm = db.items_main[itm_1]
    old_itm = db.items_main[itm_2]
    qry = "update items_det set item_idr =  " + itm_1 + " where  item_idr = " + itm_2
    db.executesql(qry)
    old_itm.delete_record()
    db.commit()
    mess = " تم دمج الصنفين مع بعضها "
    return dict(mess=mess)


@auth.requires(auth.has_membership("user2") or auth.has_membership("admin"))
def items_unmerged():
    return dict()


@auth.requires(auth.has_membership("admin"))
def negative_repair():
    qry = (
        "select  item_idr from items_det "
        " where  items_count <0 "
        " group by item_idr ORDER BY item_idr "
    )
    # print "========================="
    data = db.executesql(qry, as_dict=True)
    sum = db.items_det.items_count.sum()
    for row in data:
        # if row['item_idr']==2112 :
        sum_row_0 = (
            db(
                (db.items_det.item_idr == row["item_idr"])
                & (db.items_det.items_count < 0)
            )
            .select(sum)
            .first()[sum]
        )
        sum_row_1 = (
            db(
                (db.items_det.item_idr == row["item_idr"])
                & (db.items_det.items_count > 0)
            )
            .select(sum)
            .first()[sum]
        )
        # print sum_row_0
        # print sum_row_1
        if sum_row_1 >= (sum_row_0 * -1):
            for itm in db(db.items_det.item_idr == row["item_idr"]).select(
                orderby=db.items_det.id
            ):
                if itm.items_count == 0:
                    continue
                elif itm.items_count < 0:
                    # print "*<0"
                    itm.items_count = 0
                elif (itm.items_count > 0) & (sum_row_0 < 0):
                    # print ">0"
                    if itm.items_count >= (sum_row_0 * -1):
                        # print "---->0"
                        # print "*************"
                        # print sum_row_0
                        save_count = itm.items_count
                        itm.items_count = itm.items_count + sum_row_0
                        sum_row_0 = sum_row_0 + save_count
                        # print sum_row_0
                        # print "*************"
                itm.update_record()
        # else :
        # print "((" + str(row['item_idr'] ) +"))"
        db.commit()
        # print str(itm.id )+"--" + str(itm.items_count) +"==>" +str(sum_row_0)

    # print "========================="
    """while sum_row_0 != 0 :
                    sum_row_0 = sum_row_0 +1
                    #print '0000'
    """
    return "ok"


@can_access(3011)
def negative_items():
    qry = (
        "select  item_idr,sum(items_count) as sum ,"
        " (select name from items_main  where items_main.id= item_idr ) as name "
        " from items_det   "
        " group by item_idr  "
        " having sum(items_count) <0   "
        " ORDER BY item_idr   "
    )
    data = db.executesql(qry, as_dict=True)
    for i in data:
        itm = db.items_main(i["item_idr"])
        i["type"] = itm["item_type"].name
    return dict(data=data)


@can_access(3003)
def adjust_quantity():
    return dict()


def get_last_10():
    # qry2 = db(db.items_det.item_idr== request.args(0) ).select(orderby=~db.items_det.id , limitby=(0,5)).first()
    qry = (
        f"select * from items_det  where item_idr ={ str(request.args(0)) }"
        f" and items_count!=0 order by id desc  ; "
    )
    data = db.executesql(qry, as_dict=True)
    # app_json = json.dumps(qry2)
    return response.json(data)


import json


@can_access(3003)
def save_adjust_quantity():
    try:
        itm = request.vars.itm
        total_0 = 0.0
        total_1 = 0.0
        for i in itm:
            total_0 = total_0 + (db.items_det[i["id"]].items_count)
            total_1 = total_1 + float(i["items_count"] or 0)
        if total_0 != total_0:
            return response.json({"mess": 1})
        for i in itm:
            itm_d = db.items_det[i["id"]]
            itm_d.items_count = float(i["items_count"] or 0)
            itm_d.update_record()
        db.commit()
        return response.json({"mess": 0})
    except Exception as e:
        db.rollback()
        # print (e)
        response.json({"mess": e})


@can_access(3005)
def renameitm():
    itm_d = db.items_main[request.args(0)]
    if itm_d:
        itm_d.name = request.vars.new
        itm_d.update_record()
        return "ok"
    else:
        itm = db(db.items_main.item_id == request.args(0)).select().first()
        itm_d = db.items_main[itm.id]
        itm_d.name = request.vars.new
        itm_d.update_record()
        return "ok"


def items_sales():
    return dict()


def stop_items():
    return dict()


def rep_bystopdays():
    qry = (
        "select DISTINCT "
        "item_idr as id ,  "
        "(select name from items_main where id = itd.item_idr ) as name , "
        "(select item_type from items_main where id = itd.item_idr ) as item_type , "
        "( select name from key_type where key_type.id= "
        "(select item_type from items_main where id = itd.item_idr ) "
        ")as item_type_n  , "
        "sum(items_count) as sum "
        "from items_det as itd "
        "where "
        "itd.item_idr not in ( "
        "select DISTINCT( (select item_idr from items_det where items_det.id=invoice_details.item_number ) )   "
        f"from invoice_details where created_on > ( current_date - {request.args(0)} ) ) "
        f"and created_on < ( current_date - {request.args(0)} ) "
        "group by item_idr "
        "having  sum(items_count) > 0  "
    )
    qs = db.executesql(qry, as_dict=True)
    for r in qs:
        r["sum"] = round(r["sum"], 3)
    return response.json(qs)
    # ------------------------------------------------------------
    """
    qry = (
        " select id , name ,item_type , "
        " ( select name from key_type where key_type.id=items_main.item_type  )  as item_type_n "
        " from items_main  "
        " where id not in ( "
        " select DISTINCT( (select item_idr from items_det where items_det.id=invoice_details.item_number ) )   "
		" from invoice_details where created_on > ( current_date - "+str(request.args(0))+" ) ) "
		" and created_on < ( current_date - "+str(request.args(0))+" ) "
    )
    mydata = []
    for r in qs :
        qry =(
            " select sum(items_count) from items_det where "
            " item_idr= "+str(r['id']) 
        )
        sum1 = db.executesql(qry, as_dict=True)
        if sum1[0]['sum'] :
            if int(sum1[0]['sum']) > 0    :
                mydata.append(
                {'id': r['id'] , 'name': r['name'] ,
                'item_type':  r['item_type'] , 'sum':sum1[0]['sum'] ,
                'item_type_n':r['item_type_n'] } 
                )
        #r['sum'] = sum1[0]
    """


# ------------------------------------------------------


@auth.requires_membership("admin")
def editcountItem():
    update_qry = (
        f"update items_det set items_count =0 where item_idr = {request.args(0)}"
    )
    db.executesql(update_qry)
    db.commit()
    redirect(URL("items", "negative_items"))


def sels_item():
    qry = (
        "select * from invoice_details  where item_number IN  "
        " ( select id from items_det where item_idr=" + str(request.args(0)) + "  )"
        " order by id desc limit 100 "
    )
    data1 = db.executesql(qry, as_dict=True)
    qry = (
        "select * from inv_return_details  where item_number IN  "
        " ( select id from items_det where item_idr=" + str(request.args(0)) + "  )"
        " order by id desc limit 100 "
    )
    data2 = db.executesql(qry, as_dict=True)
    data = {"data1": data1, "data2": data2}
    return response.json(data)
