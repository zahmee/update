# type: ignore

from datetime import date, datetime
import json
import httpx
import time

def generate_csid():
    # print("zatca generate_csid")
    csr_config = db(db.csr_config.id>0).select().first()
    api_url = f"{csr_config.api_site}/zatca/generate-csid"
    req = request.vars
    headers = {}
    headers["Content-Type"] = "application/json"
    headers["accept"] = "application/json"
    resp = httpx.post(api_url, json=req, headers=headers, timeout=90.0)
    if resp.status_code != 200:
        return response.json({"error": "Failed to connect to ZATCA API", "status_code": resp.status_code, "resp":resp.json()})
    else:
        data = resp.json()
        if data["ccsid_requestID"] is not None and data["ccsid_requestID"] != "":
            step2 = json.loads(run_onboarding_steps(data))
            time.sleep(1)
            if step2["pcsid_requestID"] is not None and step2["pcsid_requestID"] != "":
                new_data = lowercase_keys_recursive(step2)
                csr_config.update_record(**new_data )
                db.commit()
                return response.json({"status":"ok"})
            else:
                return response.json(
                    {
                        "error": "Failed to connect to ZATCA API",
                        "status_code": step2 ,
                    }
                )
        else:
            return response.json(
                {
                    "error": "Failed to connect to ZATCA API",
                    "status_code": data ,
                }
            )

def run_onboarding_steps(data: dict)-> json:
    # print("zatca run_onboarding_steps")
    csr_config = db(db.csr_config.id>0).select().first()
    api_url = f"{csr_config.api_site}/zatca/run-onboarding-steps"
    req = data
    headers = {}
    headers["Content-Type"] = "application/json"
    headers["accept"] = "application/json"
    resp = httpx.post(api_url, json=req, headers=headers, timeout=90.0)
    # print(resp.text)
    if resp.status_code != 200:
        return response.json({"error": "Failed to connect to ZATCA API", "status_code": resp.status_code})
    else:
        data = resp.json()
        if data["pcsid_requestID"] is not None and data["pcsid_requestID"] != "":
            return response.json(data)
        else:
            return response.json(
                {
                    "error": "Failed to connect to ZATCA API",
                    "status_code": data ,
                }
            )

def lowercase_keys_recursive(data):
    if isinstance(data, dict):
        return {k.lower(): lowercase_keys_recursive(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [lowercase_keys_recursive(item) for item in data]
    else:
        return data
