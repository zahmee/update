# -*- coding: utf-8 -*-
#  type: ignore


@auth.requires_membership("admin")
def unit_key():
    grid = SQLFORM.grid(
        db.key_unit,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def key_invoce_type():
    grid = SQLFORM.grid(
        db.key_invoce_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def type_key():
    grid = SQLFORM.grid(
        db.key_type,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def payment_method_key():
    grid = SQLFORM.grid(
        db.key_payment_method,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def update_items_det():
    qry = "update items_det set  item_id = (select item_id from items_main where id = items_det.item_idr )"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def update_items_main1():
    qry = "update items_main set  vat = 0.0 where vat is null "
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires_membership("admin")
def print_report():
    grid = SQLFORM.grid(
        db.print_report,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@auth.requires_membership("admin")
def users():
    links = [
        lambda row: A(
            I(" ", _class="far fa-key"),
            " صلاحيات المستخدم ",
            _class="btn btn-info ",
            _title="صلاحيات المستخدم",
            _href=URL("setup", "screens_rules", args=[row.id]),
        )
    ]
    grid = SQLFORM.grid(
        db.auth_user,
        links=links,
        user_signature=True,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ====================================================================
@auth.requires(auth.has_membership("admin"))
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ===============================================
@auth.requires(auth.has_membership("admin"))
def screens():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@auth.requires(auth.has_membership("admin"))
def screens_rules():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    q = db.screens_rules.to_user == request.args(0)
    db.screens_rules.to_user.default = request.args(0)
    db.screens_rules.to_user.readable = False
    db.screens_rules.to_user.writable = False
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        orderby=db.screens_rules.screens,
        maxtextlengths={"screens_rules.screens": 250},
        args=request.args[:1],
    )
    return dict(grid=grid)


screens_code = [
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    {"systems": 1, "name": "الموردين - استعراض الموردين", "screen_code": 2001},
    {"systems": 1, "name": "الموردين - اضافة مورد جديد", "screen_code": 2002},
    {"systems": 1, "name": "الموردين - تعديل بيانات مورد", "screen_code": 2003},
    {"systems": 1, "name": "الموردين - حذف مورد", "screen_code": 2004},
    {"systems": 1, "name": "الموردين - اقفال مورد", "screen_code": 2005},
    {"systems": 1, "name": "الموردين - حركة مشتريات المورد", "screen_code": 2006},
    {"systems": 1, "name": "الموردين - كشف حساب مورد", "screen_code": 2106},
    {"systems": 1, "name": "الموردين - سدادات الموردين", "screen_code": 2107},
    {"systems": 1, "name": "الموردين - ارصدة الموردين", "screen_code": 2108},
    {"systems": 1, "name": "الموردين - مطابقات كشف الحساب", "screen_code": 2109},
    {"systems": 1, "name": "الموردين - فواتير مورد محدد", "screen_code": 2007},
    {"systems": 1, "name": "الموردين - طباعة مرتجع فاتورة", "screen_code": 2008},
    {"systems": 1, "name": "الموردين - اعتماد مرتجع فاتورة", "screen_code": 2009},
    {"systems": 1, "name": "الموردين - اضافة فاتورة جديدة", "screen_code": 2010},
    {"systems": 1, "name": "الموردين - استعراض فواتير التوريد", "screen_code": 2011},
    {"systems": 1, "name": "الموردين - طباعة الأصناف المدخلة", "screen_code": 2012},
    {"systems": 1, "name": "الموردين - طباعة الباركود للفاتورة", "screen_code": 2013},
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - الفواتير غير المعتمدة",
        "screen_code": 2014,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - ادخال اصناف - فاتورة مرتجع",
        "screen_code": 2015,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - اعتماد فاتورة مرتجع",
        "screen_code": 2016,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - الفواتير المعتمدة",
        "screen_code": 2017,
    },
    {"systems": 1, "name": "الاصناف - التصنيف الرئيسي", "screen_code": 3001},
    {"systems": 1, "name": "الاصناف - حركة الصنف", "screen_code": 3002},
    {
        "systems": 1,
        "name": "الاصناف - تعديل كمية صنف بين اكثر من فاتورة",
        "screen_code": 3003,
    },
    {"systems": 1, "name": "الاصناف - ادخال الاصناف حسب الفواتير", "screen_code": 3004},
    {
        "systems": 1,
        "name": "الاصناف - ادخال الاصناف حسب الفواتير - ادخال الاصناف",
        "screen_code": 3005,
    },
    {"systems": 1, "name": "الاصناف - تفاصيل الاصناف", "screen_code": 3006},
    {"systems": 1, "name": "الاصناف - عمليات على الاصناف", "screen_code": 3007},
    {"systems": 1, "name": "الاصناف - دمج صنفين مع بعضها", "screen_code": 3008},
    {
        "systems": 1,
        "name": "الاصناف - تقرير بالاصناف المقاربة على الانتهاء",
        "screen_code": 3009,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف التي بحاجة اعادة طلب",
        "screen_code": 3010,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف ذات الاعداد بالسالب",
        "screen_code": 3011,
    },
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض فاتورة", "screen_code": 4003},
]


#
@auth.requires(auth.has_membership("admin"))
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@auth.requires(auth.has_membership("admin"))
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@auth.requires(auth.has_membership("admin"))
def important_info():
    db.important_info.logo.readable = False
    db.important_info.logo.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


@auth.requires(auth.has_membership("admin"))
def important_info_2():
    db.important_info.name.readable = False
    db.important_info.name.writable = False
    db.important_info.vat.readable = False
    db.important_info.vat.writable = False
    db.important_info.tel.readable = False
    db.important_info.tel.writable = False
    db.important_info.mobile.readable = False
    db.important_info.mobile.writable = False
    db.important_info.address.readable = False
    db.important_info.address.writable = False
    db.important_info.msg1.readable = False
    db.important_info.msg1.writable = False
    db.important_info.msg2.readable = False
    db.important_info.msg2.writable = False
    q = db(db.important_info.id > 0).select().first()
    # db.important_info.logo.requires = IS_IMAGE(extensions=('png'), maxsize=(600, 600))
    form = SQLFORM(
        db.important_info, q, deletable=False, submit_button="حفظ", showid=False
    ).process()
    if form.accepted:
        redirect(URL("default", "index"))
    return dict(form=form)


def t1():
    return dict()


@auth.requires(auth.has_membership("admin"))
def util():
    return dict()


# ========================================================
@auth.requires_membership("admin")
def update_crus():
    qry = "CREATE EXTENSION tablefunc;"
    data = db.executesql(qry)
    return "تمت العملية"


@auth.requires(auth.has_membership("admin"))
def util_1():
    data = db().select(db.items_main.ALL, orderby=db.items_main.id)
    key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.item_reg:
            item_reg = row.item_reg.strip().upper()
        else:
            item_reg = row.id

        if row.item_type == None:
            item_type = key_type.id
        else:
            item_type = row.item_type
        if row.item_group == None:
            item_group = 0
        else:
            item_group = row.item_group
        if row.suppliers == None:
            suppliers = key_suppliers.id
        else:
            suppliers = row.suppliers

        name = row.name.strip().upper()
        row.update_record(
            name=name,
            item_reg=item_reg,
            flexible_price=False,
            item_type=item_type,
            item_group=item_group,
            suppliers=suppliers,
        )
    db.commit()
    redirect(URL("setup", "util"))


@auth.requires(auth.has_membership("admin"))
def util_2():
    data = db().select(db.suppliers.ALL, orderby=db.suppliers.id)
    # key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    # key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.name:
            name = row.name.strip().upper()
        else:
            name = row.name
        if row.address:
            address = row.address.replace("|", "")
        else:
            address = ""
        if row.tel:
            tel = row.tel.replace("|", "")
        else:
            tel = ""
        if row.note:
            note = row.note.replace("|", "")
        else:
            note = ""
        if row.bank_account:
            bank_account = row.bank_account.replace("|", "")
        else:
            bank_account = ""

        if row.stoped:
            stoped = row.stoped
        else:
            stoped = False

        row.update_record(
            name=name,
            address=address,
            tel=tel,
            note=note,
            bank_account=bank_account,
            stoped=stoped,
        )
    db.commit()
    redirect(URL("setup", "util"))
