# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime, timedelta
import re
import api_helpers as api


def _setup_json_error(message):
    return response.json({"err": 3, "mess": message})


def _valid_email(value):
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", (value or "").strip()))


def _validate_user_payload(data, user_id=None):
    errors = []
    first_name = (data.first_name or "").strip()
    last_name = (data.last_name or "").strip()
    email = (data.email or "").strip().lower()
    password = (data.password or "").strip()
    if not first_name:
        errors.append("الاسم الأول مطلوب")
    if not email or not _valid_email(email):
        errors.append("البريد الإلكتروني غير صحيح")
    if not user_id and len(password) < 4:
        errors.append("كلمة المرور مطلوبة ولا تقل عن 4 أحرف")

    existing = db(db.auth_user.email == email).select(db.auth_user.id, limitby=(0, 1)).first() if email else None
    if existing and (not user_id or int(existing.id) != int(user_id)):
        errors.append("البريد الإلكتروني مستخدم مسبقاً")

    return errors, {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "password": password,
    }


def _valid_auth_user_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.auth_user(row_id) else None


def _valid_group_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.auth_group(row_id) else None


def _valid_screen_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.screens(row_id) else None


@can_access(9301)
def index():
    return dict()


@auth.requires_membership("admin")
def manager_dashboard():
    today = datetime.now().date()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())

    stats = {}
    stats['invoices_today_all'] = db(
        (db.invoice_master.created_on >= today_start) &
        (db.invoice_master.created_on <= today_end)
    ).count()

    stats['invoices_today_me'] = db(
        (db.invoice_master.created_on >= today_start) &
        (db.invoice_master.created_on <= today_end) &
        (db.invoice_master.created_by == auth.user.id)
    ).count()

    total_row = db(
        (db.invoice_master.created_on >= today_start) &
        (db.invoice_master.created_on <= today_end)
    ).select(db.invoice_master.total_after_discount.sum()).first()
    stats['total_today'] = round(
        total_row[db.invoice_master.total_after_discount.sum()] or 0, 2
    )

    stats['total_items'] = db(db.items_main.id > 0).count()
    stats['total_customers'] = db(db.customers.id > 0).count()
    stats['active_suppliers'] = db(db.suppliers.stoped != True).count()

    return dict(stats=stats)


@auth.requires_membership("admin")
def dashboard_charts():
    today = datetime.now().date()

    sales_7days = []
    day_names = ['الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد']
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        day_start = datetime.combine(day, datetime.min.time())
        day_end = datetime.combine(day, datetime.max.time())
        total_row = db(
            (db.invoice_master.created_on >= day_start) &
            (db.invoice_master.created_on <= day_end)
        ).select(db.invoice_master.total_after_discount.sum()).first()
        day_total = round(total_row[db.invoice_master.total_after_discount.sum()] or 0, 2)
        count_row = db(
            (db.invoice_master.created_on >= day_start) &
            (db.invoice_master.created_on <= day_end)
        ).count()
        sales_7days.append({
            'date': day.strftime('%m/%d'),
            'day_name': day_names[day.weekday()],
            'total': day_total,
            'count': count_row
        })

    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    payment_methods = db(db.key_payment_method.id > 0).select()
    payment_breakdown = []
    for pm in payment_methods:
        pm_total_row = db(
            (db.invoice_master.created_on >= today_start) &
            (db.invoice_master.created_on <= today_end) &
            (db.invoice_master.payment_method == pm.id)
        ).select(db.invoice_master.total_after_discount.sum()).first()
        pm_total = round(pm_total_row[db.invoice_master.total_after_discount.sum()] or 0, 2)
        if pm_total > 0:
            payment_breakdown.append({
                'name': pm.name,
                'total': pm_total
            })

    # ===== مبيعات ومرتجعات آخر 4 أشهر =====
    from calendar import monthrange
    month_names_ar = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    sales_returns_4months = []
    for i in range(3, -1, -1):
        y = today.year
        m = today.month - i
        while m <= 0:
            m += 12
            y -= 1
        first_day = today.replace(year=y, month=m, day=1)
        last_day_num = monthrange(y, m)[1]
        last_day = first_day.replace(day=last_day_num)
        mstart = datetime.combine(first_day, datetime.min.time())
        mend = datetime.combine(last_day, datetime.max.time())

        sales_row = db(
            (db.invoice_master.created_on >= mstart) &
            (db.invoice_master.created_on <= mend)
        ).select(db.invoice_master.total_after_discount.sum()).first()
        sales_total = round(sales_row[db.invoice_master.total_after_discount.sum()] or 0, 2)

        returns_row = db(
            (db.inv_return_master.created_on >= mstart) &
            (db.inv_return_master.created_on <= mend)
        ).select(db.inv_return_master.total_after_discount.sum()).first()
        returns_total = round(returns_row[db.inv_return_master.total_after_discount.sum()] or 0, 2)

        sales_returns_4months.append({
            'month_label': month_names_ar[m - 1] + ' ' + str(y),
            'sales': sales_total,
            'returns': returns_total,
        })

    return response.json({
        'sales_7days': sales_7days,
        'payment_breakdown': payment_breakdown,
        'sales_returns_4months': sales_returns_4months,
    })


@auth.requires_membership("admin")
def employee_summary():
    period = request.vars.period or 'month'
    today = datetime.now().date()

    if period == 'today':
        start_date = today
        end_date = today
        period_label = 'اليوم'
    elif period == 'month':
        start_date = today.replace(day=1)
        end_date = today
        period_label = 'الشهر الحالي'
    else:
        start_date = None
        end_date = None
        period_label = 'الكل'

    start_dt = datetime.combine(start_date, datetime.min.time()) if start_date else None
    end_dt = datetime.combine(end_date, datetime.max.time()) if end_date else None

    emp_rows = db(db.employees.user_id != None).select(
        db.employees.id,
        db.employees.emp_name,
        db.employees.user_id,
        db.employees.job_title,
        orderby=db.employees.emp_name,
    )

    job_titles = {r.id: r.name for r in db(db.key_job_titles.id > 0).select(
        db.key_job_titles.id, db.key_job_titles.name)}

    summary = []
    for emp in emp_rows:
        uid = emp.user_id
        emp_id = emp.id

        # ===== فواتير المبيعات =====
        q_inv = db.invoice_master.created_by == uid
        if start_dt:
            q_inv &= (db.invoice_master.created_on >= start_dt) & \
                     (db.invoice_master.created_on <= end_dt)
        inv_count = db(q_inv).count()
        inv_total_row = db(q_inv).select(db.invoice_master.total_after_discount.sum()).first()
        inv_total = round(inv_total_row[db.invoice_master.total_after_discount.sum()] or 0, 2)

        # ===== تفاصيل الفواتير (الأصناف المدخلة في الفواتير) =====
        q_det = db.invoice_details.created_by == uid
        if start_dt:
            q_det &= (db.invoice_details.created_on >= start_dt) & \
                     (db.invoice_details.created_on <= end_dt)
        det_count = db(q_det).count()
        det_qty_row = db(q_det).select(db.invoice_details.item_count.sum()).first()
        det_qty = round(det_qty_row[db.invoice_details.item_count.sum()] or 0, 2)

        # ===== مرتجعات المبيعات =====
        q_ret = db.inv_return_master.created_by == uid
        if start_dt:
            q_ret &= (db.inv_return_master.created_on >= start_dt) & \
                     (db.inv_return_master.created_on <= end_dt)
        ret_count = db(q_ret).count()
        ret_total_row = db(q_ret).select(db.inv_return_master.total_after_discount.sum()).first()
        ret_total = round(ret_total_row[db.inv_return_master.total_after_discount.sum()] or 0, 2)

        # ===== فواتير التوريد المدخلة =====
        q_bill = db.suppliers_bills.created_by == uid
        if start_dt:
            q_bill &= (db.suppliers_bills.created_on >= start_dt) & \
                      (db.suppliers_bills.created_on <= end_dt)
        bill_count = db(q_bill).count()
        bill_total_row = db(q_bill).select(db.suppliers_bills.bill_total.sum()).first()
        bill_total = round(bill_total_row[db.suppliers_bills.bill_total.sum()] or 0, 2)

        # ===== الحضور (للفترة) =====
        q_att = db.attendance.employee == emp_id
        if start_date:
            q_att &= (db.attendance.att_date >= start_date) & \
                     (db.attendance.att_date <= end_date)
        att_days = db(q_att).count()
        att_hours_row = db(q_att).select(db.attendance.shift_hours.sum()).first()
        att_hours = round(att_hours_row[db.attendance.shift_hours.sum()] or 0, 2)

        # ===== حضور/انصراف اليوم =====
        today_att = db(
            (db.attendance.employee == emp_id) &
            (db.attendance.att_date == today)
        ).select().first()
        check_in = today_att.check_in.strftime('%H:%M') if today_att and today_att.check_in else None
        check_out = today_att.check_out.strftime('%H:%M') if today_att and today_att.check_out else None

        # متوسط قيمة الفاتورة
        avg_invoice = round(inv_total / inv_count, 2) if inv_count else 0

        summary.append({
            'emp_id': emp_id,
            'emp_name': emp.emp_name,
            'job_title': job_titles.get(emp.job_title, ''),
            'invoices_count': inv_count,
            'invoices_total': inv_total,
            'avg_invoice': avg_invoice,
            'items_lines': det_count,
            'items_qty': det_qty,
            'returns_count': ret_count,
            'returns_total': ret_total,
            'bills_count': bill_count,
            'bills_total': bill_total,
            'attendance_days': att_days,
            'attendance_hours': att_hours,
            'check_in_today': check_in,
            'check_out_today': check_out,
        })

    return response.json({
        'period': period,
        'period_label': period_label,
        'employees': summary,
    })


# ===========================================================================================
#  شاشات الترميزات (CRUD) — واجهة Vue موحّدة عبر قائمة بيضاء بالجداول المسموح بها
# ===========================================================================================
_LOOKUP_TABLES = {
    "unit":         {"table": "key_unit",           "title": "الوحدات",          "subtitle": "وحدات قياس الأصناف",     "field_label": "الوصف",        "deletable": False},
    "invoice_type": {"table": "key_invoce_type",    "title": "أنواع الفواتير",   "subtitle": "تصنيف أنواع الفواتير",   "field_label": "الوصف",        "deletable": False},
    "type":         {"table": "key_type",           "title": "التصنيف",          "subtitle": "تصنيفات الأصناف",        "field_label": "الوصف",        "deletable": False},
    "payment":      {"table": "key_payment_method", "title": "طريقة الدفع",      "subtitle": "طرق دفع الفواتير",       "field_label": "الوصف",        "deletable": False},
    "doc_type":     {"table": "key_doc_types",      "title": "أنواع المستندات",  "subtitle": "أنواع مستندات الموظفين", "field_label": "نوع المستند",  "deletable": True},
    "job_title":    {"table": "key_job_titles",     "title": "ترميزات الوظائف",  "subtitle": "المسميات الوظيفية للموظفين", "field_label": "المسمى الوظيفي", "deletable": True},
    "nationality":  {"table": "key_nationalities",  "title": "ترميزات الجنسيات", "subtitle": "جنسيات الموظفين",        "field_label": "الجنسية",      "deletable": True},
    "advance_type": {"table": "key_advance_types",  "title": "أنواع السلفيات",   "subtitle": "أنواع سلف الموظفين",     "field_label": "نوع السلفة",   "deletable": True},
    "allowance":    {"table": "key_allowance_deduction", "title": "البدلات والخصومات", "subtitle": "بدلات وخصومات الرواتب", "field_label": "الاسم", "deletable": True,
                     "extra": {"field": "ad_type", "label": "النوع", "options": ["بدل", "خصم"], "default": "بدل"}},
}


def _lookup_page(key):
    cfg = _LOOKUP_TABLES.get(key)
    if not cfg:
        raise HTTP(404)
    response.view = "setup/lookup_crud.html"
    return dict(lookup_key=key, cfg=cfg)


@can_access(9301)
def unit_key():
    return _lookup_page("unit")


@can_access(9301)
def key_invoce_type():
    return _lookup_page("invoice_type")


@can_access(9301)
def type_key():
    return _lookup_page("type")


@can_access(9301)
def payment_method_key():
    return _lookup_page("payment")


@can_access(9301)
def lookup_list():
    cfg = _LOOKUP_TABLES.get(request.vars.key)
    if not cfg:
        return response.json(api.api_error(mess="جدول غير معروف"))
    table = db[cfg["table"]]
    extra = cfg.get("extra")
    query = table.id > 0
    search = (request.vars.q or "").strip()
    if search:
        query &= table.name.contains(search)
    select_fields = [table.id, table.name]
    if extra:
        select_fields.append(table[extra["field"]])
    rows = db(query).select(*select_fields, orderby=table.name)
    data = []
    for r in rows:
        item = {"id": r.id, "name": r.name or ""}
        if extra:
            item["extra"] = r[extra["field"]] or ""
        data.append(item)
    return response.json(api.api_list(rows=data, count=len(data)))


@can_access(9301)
def lookup_save():
    cfg = _LOOKUP_TABLES.get(request.vars.key)
    if not cfg:
        return response.json(api.api_error(mess="جدول غير معروف"))
    table = db[cfg["table"]]
    name = (request.vars.name or "").strip()
    if not name:
        return response.json(api.api_error(mess="يجب إدخال " + cfg["field_label"]))
    values = {"name": name}
    extra = cfg.get("extra")
    if extra:
        ev = (request.vars.extra or "").strip()
        if ev not in extra["options"]:
            ev = extra.get("default") or extra["options"][0]
        values[extra["field"]] = ev
    try:
        rec_id = request.vars.id
        if rec_id and str(rec_id).isdigit() and table(int(rec_id)):
            table(int(rec_id)).update_record(**values)
        else:
            rec_id = table.insert(**values)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(data={"id": rec_id}, mess="تم الحفظ بنجاح"))


@can_access(9301)
def lookup_delete():
    cfg = _LOOKUP_TABLES.get(request.vars.key)
    if not cfg:
        return response.json(api.api_error(mess="جدول غير معروف"))
    if not cfg["deletable"]:
        return response.json(api.api_error(mess="لا يمكن حذف هذا النوع من السجلات"))
    table = db[cfg["table"]]
    rec_id = request.vars.id
    if not (rec_id and str(rec_id).isdigit() and table(int(rec_id))):
        return response.json(api.api_error(mess="السجل غير موجود"))
    try:
        db(table.id == int(rec_id)).delete()
        db.commit()
    except Exception:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر الحذف، قد يكون السجل مستخدماً في النظام"))
    return response.json(api.api_ok(mess="تم الحذف بنجاح"))


@auth.requires_membership("admin")
def invoice_sending():
    """شاشة Vue للفواتير قيد الإرسال إلى ZATCA — البيانات عبر invoice_sending_list."""
    return dict()


_INV_SENDING_PER_PAGE = 50


def _inv_type_label(v):
    return "مبيعات" if v == 1 else ("مرتجع مبيعات" if v == 2 else str(v))


@auth.requires_membership("admin")
def invoice_sending_list():
    """قائمة الفواتير قيد الإرسال — مع فلترة (الكل/قيد الإرسال/تم) وبحث وترقيم صفحات."""
    t = db.invoice_sending
    query = t.id > 0

    flt = request.vars.filter or "all"
    if flt == "pending":
        query &= (t.send == False)
    elif flt == "sent":
        query &= (t.send == True)

    search = (request.vars.q or "").strip()
    if search and search.isdigit():
        query &= (t.inv_id == int(search))

    try:
        page = max(int(request.vars.page or 1), 1)
    except (ValueError, TypeError):
        page = 1

    per_page = _INV_SENDING_PER_PAGE
    total = db(query).count()
    rows = db(query).select(
        t.id, t.inv_id, t.inv_type, t.inv_date, t.inv_time, t.total_sum, t.send,
        orderby=~t.id,
        limitby=((page - 1) * per_page, page * per_page),
    )

    data = []
    for r in rows:
        data.append({
            "id": r.id,
            "inv_id": r.inv_id,
            "inv_type": r.inv_type,
            "inv_type_label": _inv_type_label(r.inv_type),
            "inv_date": str(r.inv_date)[:10] if r.inv_date else "",
            "inv_time": str(r.inv_time)[:5] if r.inv_time else "",
            "total_sum": r.total_sum or 0,
            "send": bool(r.send),
        })

    stats = {
        "pending": db(t.send == False).count(),
        "sent": db(t.send == True).count(),
    }
    return response.json(api.api_list(
        rows=data, count=total, stats=stats, page=page, per_page=per_page))


@auth.requires_membership("admin")
def invoice_sending_delete():
    """حذف سجل واحد من قائمة الإرسال — بدون رسالة تحذير في الواجهة."""
    rec_id = request.vars.id
    if not (rec_id and str(rec_id).isdigit() and db.invoice_sending(int(rec_id))):
        return response.json(api.api_error(mess="السجل غير موجود"))
    try:
        db(db.invoice_sending.id == int(rec_id)).delete()
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(mess="تم الحذف"))


@can_access(9301)
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9301)
def update_items_det():
    qry = "update items_det set  item_id = (select item_id from items_main where id = items_det.item_idr )"
    data = db.executesql(qry)
    return "تمت العملية"


@can_access(9301)
def update_items_main1():
    qry = "update items_main set  vat = 0.0 where vat is null "
    data = db.executesql(qry)
    return "تمت العملية"


@can_access(9301)
def print_report():
    grid = SQLFORM.grid(
        db.print_report,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9302)
def users():
    links = [
        lambda row: A(
            I(" ", _class="far fa-key"),
            " صلاحيات المستخدم ",
            _class="btn btn-info ",
            _title="صلاحيات المستخدم",
            _href=URL("setup", "screens_rules", args=[row.id]),
        )
    ]
    grid = SQLFORM.grid(
        db.auth_user,
        links=links,
        user_signature=True,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ====================================================================
@can_access(9302)
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


# ===============================================
def _sync_screens():
    valid_codes = {r["screen_code"] for r in screens_code}
    # إضافة الشاشات الناقصة
    for r in screens_code:
        if not db(db.screens.screen_code == r["screen_code"]).select().first():
            db.screens.insert(systems=r["systems"], name=r["name"], screen_code=r["screen_code"])
    # حذف الشاشات التي لم تعد موجودة في القائمة
    for row in db(~db.screens.screen_code.belongs(list(valid_codes))).select():
        db(db.screens_rules.screens == row.id).delete()
        row.delete_record()
    db.commit()


@can_access(9302)
def screens():
    _sync_screens()
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@can_access(9302)
def screens_rules():
    _sync_screens()
    q = db.screens_rules.to_user == request.args(0)
    db.screens_rules.to_user.default = request.args(0)
    db.screens_rules.to_user.readable = False
    db.screens_rules.to_user.writable = False
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        orderby=db.screens_rules.screens,
        maxtextlengths={"screens_rules.screens": 250},
        args=request.args[:1],
    )
    return dict(grid=grid)


screens_code = [
    {"systems": 1, "name": "العملاء - استعراض العملاء", "screen_code": 1001},
    {"systems": 1, "name": "العملاء - فواتير العملاء", "screen_code": 1002},
    {"systems": 1, "name": "العملاء - سدادات العملاء فردي", "screen_code": 1003},
    {"systems": 1, "name": "العملاء - سدادات العملاء الجميع", "screen_code": 1004},
    {"systems": 1, "name": "العملاء - تسوية حسابات العملاء", "screen_code": 1005},
    {"systems": 1, "name": "العملاء - تقرير حالة العميل", "screen_code": 1006},
    {"systems": 1, "name": "الموردين - استعراض الموردين", "screen_code": 2001},
    {"systems": 1, "name": "الموردين - اضافة مورد جديد", "screen_code": 2002},
    {"systems": 1, "name": "الموردين - تعديل بيانات مورد", "screen_code": 2003},
    {"systems": 1, "name": "الموردين - اقفال مورد", "screen_code": 2005},
    {"systems": 1, "name": "الموردين - حركة مشتريات المورد", "screen_code": 2006},
    {"systems": 1, "name": "الموردين - كشف حساب مورد", "screen_code": 2106},
    {"systems": 1, "name": "الموردين - سدادات الموردين", "screen_code": 2107},
    {"systems": 1, "name": "الموردين - ارصدة الموردين", "screen_code": 2108},
    {"systems": 1, "name": "الموردين - مطابقات كشف الحساب", "screen_code": 2109},
    {"systems": 1, "name": "الموردين - تقارير مشتريات الموردين", "screen_code": 2110},
    {"systems": 1, "name": "الموردين - تقارير الموردين", "screen_code": 2111},
    {"systems": 1, "name": "الموردين - طباعة مرتجع فاتورة", "screen_code": 2008},
    {"systems": 1, "name": "الموردين - اعتماد مرتجع فاتورة", "screen_code": 2009},
    {"systems": 1, "name": "الموردين - اضافة فاتورة جديدة", "screen_code": 2010},
    {"systems": 1, "name": "الموردين - استعراض فواتير التوريد", "screen_code": 2011},
    {"systems": 1, "name": "الموردين - طباعة الأصناف المدخلة", "screen_code": 2012},
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - ادخال اصناف - فاتورة مرتجع",
        "screen_code": 2015,
    },
    {
        "systems": 1,
        "name": "الموردين - مرتجع الفواتير - اعتماد فاتورة مرتجع",
        "screen_code": 2016,
    },
    {"systems": 1, "name": "الاصناف - التصنيف الرئيسي", "screen_code": 3001},
    {"systems": 1, "name": "الاصناف - حركة الصنف", "screen_code": 3002},
    {
        "systems": 1,
        "name": "الاصناف - تعديل كمية صنف بين اكثر من فاتورة",
        "screen_code": 3003,
    },
    {"systems": 1, "name": "الاصناف - ادخال الاصناف حسب الفواتير", "screen_code": 3004},
    {
        "systems": 1,
        "name": "الاصناف - ادخال الاصناف حسب الفواتير - ادخال الاصناف",
        "screen_code": 3005,
    },
    {"systems": 1, "name": "الاصناف - تفاصيل الاصناف", "screen_code": 3006},
    {"systems": 1, "name": "الاصناف - عمليات على الاصناف", "screen_code": 3007},
    {"systems": 1, "name": "الاصناف - دمج صنفين مع بعضها", "screen_code": 3008},
    {
        "systems": 1,
        "name": "الاصناف - تقرير بالاصناف المقاربة على الانتهاء",
        "screen_code": 3009,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف التي بحاجة اعادة طلب",
        "screen_code": 3010,
    },
    {
        "systems": 1,
        "name": "الاصناف - الاصناف ذات الاعداد بالسالب",
        "screen_code": 3011,
    },
    {"systems": 1, "name": "الاصناف - الاصناف الموقوفة", "screen_code": 3012},
    {"systems": 1, "name": "الاصناف - تقرير الاصناف بالتاريخ", "screen_code": 3013},
    {"systems": 1, "name": "المبيعات - المبيعات اليومية", "screen_code": 4001},
    {"systems": 1, "name": "المبيعات - مرتجع المبيعات", "screen_code": 4002},
    {"systems": 1, "name": "المبيعات - استعراض قائمة الفواتير", "screen_code": 4004},
    {"systems": 1, "name": "المبيعات - استعراض قائمة المرتجع", "screen_code": 4005},
    {"systems": 1, "name": "المبيعات - حذف فاتورة", "screen_code": 4006},
    {"systems": 1, "name": "الصندوق - مراقبة مصروفات الصندوق", "screen_code": 5001},
    {"systems": 1, "name": "الصندوق - اعتماد حركات الصندوق", "screen_code": 5002},
    {"systems": 1, "name": "الجرد - جرد المخزون", "screen_code": 5200},
    {"systems": 1, "name": "طلبات الأصناف الجديدة", "screen_code": 6001},
    # شؤون الموظفين
    {"systems": 1, "name": "الحضور والانصراف", "screen_code": 7001},
    {"systems": 1, "name": "استعراض الموظفين", "screen_code": 7002},
    {"systems": 1, "name": "المرتبات", "screen_code": 7003},
    {"systems": 1, "name": "السلف", "screen_code": 7004},
    {"systems": 1, "name": "الإجازات", "screen_code": 7005},
    {"systems": 1, "name": "كشف الرواتب", "screen_code": 7006},
    {"systems": 1, "name": "ملفاتي", "screen_code": 7007},
    # إقفال الفترات
    {"systems": 1, "name": "إقفال الفترات", "screen_code": 8001},
    # تقارير المبيعات
    {"systems": 1, "name": "تقارير المبيعات - التقرير 1", "screen_code": 8101},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 2", "screen_code": 8102},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 3", "screen_code": 8103},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 4", "screen_code": 8104},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 5", "screen_code": 8105},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 6", "screen_code": 8106},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 7", "screen_code": 8107},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 8", "screen_code": 8108},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 10", "screen_code": 8110},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 11", "screen_code": 8111},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 12", "screen_code": 8112},
    # تقارير الأصناف
    {"systems": 1, "name": "تقارير الأصناف - التقرير 1", "screen_code": 8201},
    {"systems": 1, "name": "تقارير الأصناف - تقرير التجهيز", "screen_code": 8202},
    # الضريبة
    {"systems": 1, "name": "الضريبة - التقرير الرئيسي", "screen_code": 9001},
    {"systems": 1, "name": "الضريبة - تقرير 11", "screen_code": 9002},
    {"systems": 1, "name": "الضريبة - تقرير 12", "screen_code": 9003},
    {"systems": 1, "name": "الضريبة - تقرير 13", "screen_code": 9004},
    # زاتكا
    {"systems": 1, "name": "زاتكا - حالة الربط", "screen_code": 9101},
    {"systems": 1, "name": "زاتكا - توليد CSR وطلب CSID", "screen_code": 9102},
    {"systems": 1, "name": "زاتكا - التسجيل الإنتاجي", "screen_code": 9103},
    # الإعداد
    {"systems": 1, "name": "الإعداد - إعدادات النظام", "screen_code": 9301},
    {"systems": 1, "name": "الإعداد - إدارة المستخدمين والصلاحيات", "screen_code": 9302},
]


#
@can_access(9302)
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@can_access(9302)
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
            )
    db.commit()
    redirect(URL("screens_rules/" + request.args(0)))


@can_access(9301)
def important_info():
    q = db(db.important_info.id > 0).select().first()
    info = {
        "name": "", "vat": "", "tel": "", "mobile": "",
        "address": "", "msg1": "", "msg2": "", "change_count": False,
        "change_count_amount": 0,
    }
    if q:
        info = {
            "name": q.name or "",
            "vat": q.vat or "",
            "tel": q.tel or "",
            "mobile": q.mobile or "",
            "address": (q.address or "").strip(),
            "msg1": (q.msg1 or "").strip(),
            "msg2": (q.msg2 or "").strip(),
            "change_count": bool(q.change_count),
            "change_count_amount": float(q.change_count_amount or 0),
        }
    return dict(info=info)


def _validate_important_info(data):
    """التحقق من قيم حقول معلومات الجهة (يُستخدم في الحفظ على السيرفر)."""
    errors = []
    name = (data.name or "").strip()
    vat = (data.vat or "").strip()
    tel = (data.tel or "").strip()
    mobile = (data.mobile or "").strip()
    address = (data.address or "").strip()
    msg1 = (data.msg1 or "").strip()
    msg2 = (data.msg2 or "").strip()

    if not name:
        errors.append("الاسم مطلوب")
    if not vat:
        errors.append("الرقم الضريبي مطلوب")
    elif not (vat.isdigit() and len(vat) == 15 and vat.startswith("3") and vat.endswith("3")):
        errors.append("الرقم الضريبي يجب أن يكون 15 رقماً ويبدأ وينتهي بالرقم 3")
    if not tel:
        errors.append("رقم الهاتف الأرضي مطلوب")
    elif not re.match(r"^0\d{8,9}$", tel):
        errors.append("رقم الهاتف الأرضي غير صحيح")
    if not mobile:
        errors.append("رقم الجوال مطلوب")
    elif not re.match(r"^05\d{8}$", mobile):
        errors.append("رقم الجوال يجب أن يكون بصيغة 05XXXXXXXX")
    if not address:
        errors.append("العنوان مطلوب")
    if not msg1:
        errors.append("رسالة العميل مطلوبة")
    if not msg2:
        errors.append("رسالة آخر الفاتورة مطلوبة")

    amount_str = str(data.change_count_amount or "").strip()
    amount_val = 0.0
    if amount_str:
        try:
            amount_val = float(amount_str)
            if amount_val < 0:
                errors.append("مبلغ فاتورة تعديل الكمية لا يمكن أن يكون سالباً")
        except ValueError:
            errors.append("مبلغ فاتورة تعديل الكمية يجب أن يكون رقماً")

    vals = dict(
        name=name, vat=vat, tel=tel, mobile=mobile,
        address=address, msg1=msg1, msg2=msg2,
        change_count=str(data.change_count) in ("1", "true", "True", "on"),
        change_count_amount=amount_val,
    )
    return errors, vals


@can_access(9301)
def important_info_save():
    data = request.vars
    errors, vals = _validate_important_info(data)
    if errors:
        return response.json(api.api_error(mess=" | ".join(errors)))
    try:
        q = db(db.important_info.id > 0).select().first()
        if q:
            q.update_record(**vals)
        else:
            db.important_info.insert(**vals)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(mess="تم حفظ المعلومات بنجاح"))


@can_access(9301)
def important_info_2():
    q = db(db.important_info.id > 0).select().first()
    logo = (q.logo or "") if q else ""
    info = {
        "logo": logo,
        "logo_url": URL("default", "download", args=[logo]) if logo else "",
    }
    return dict(info=info)


@can_access(9301)
def important_info_2_save():
    data = request.vars
    q = db(db.important_info.id > 0).select().first()
    if not q:
        return response.json(api.api_error(mess="لا يوجد سجل لمعلومات النظام"))
    if not (data.logo is not None and hasattr(data.logo, "file")):
        return response.json(api.api_error(mess="يرجى اختيار ملف الشعار"))

    fname = data.logo.filename or ""
    ext = fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
    if ext not in ("png", "jpg", "jpeg", "gif", "webp", "svg"):
        return response.json(api.api_error(mess="صيغة الصورة غير مدعومة (PNG, JPG, GIF, WEBP, SVG)"))

    try:
        stored = db.important_info.logo.store(data.logo.file, data.logo.filename)
        q.update_record(logo=stored)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(
        data={"logo": stored, "logo_url": URL("default", "download", args=[stored])},
        mess="تم حفظ الشعار بنجاح",
    ))


@can_access(9301)
def t1():
    return dict()


@can_access(9301)
def util():
    return dict()


# ========================================================
@can_access(9301)
def update_crus():
    qry = "CREATE EXTENSION tablefunc;"
    data = db.executesql(qry)
    return "تمت العملية"


@can_access(9301)
def util_1():
    data = db().select(db.items_main.ALL, orderby=db.items_main.id)
    key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.item_reg:
            item_reg = row.item_reg.strip().upper()
        else:
            item_reg = row.id

        if row.item_type == None:
            item_type = key_type.id
        else:
            item_type = row.item_type
        if row.item_group == None:
            item_group = 0
        else:
            item_group = row.item_group
        if row.suppliers == None:
            suppliers = key_suppliers.id
        else:
            suppliers = row.suppliers

        name = row.name.strip().upper()
        row.update_record(
            name=name,
            item_reg=item_reg,
            flexible_price=False,
            item_type=item_type,
            item_group=item_group,
            suppliers=suppliers,
        )
    db.commit()
    redirect(URL("setup", "util"))


@can_access(9301)
def util_2():
    data = db().select(db.suppliers.ALL, orderby=db.suppliers.id)
    # key_type = db().select(db.key_type.ALL, orderby=db.key_type.id).first()
    # key_suppliers = db().select(db.suppliers.ALL, orderby=db.suppliers.id).first()
    for row in data:
        if row.name:
            name = row.name.strip().upper()
        else:
            name = row.name
        if row.address:
            address = row.address.replace("|", "")
        else:
            address = ""
        if row.tel:
            tel = row.tel.replace("|", "")
        else:
            tel = ""
        if row.note:
            note = row.note.replace("|", "")
        else:
            note = ""
        if row.bank_account:
            bank_account = row.bank_account.replace("|", "")
        else:
            bank_account = ""

        if row.stoped:
            stoped = row.stoped
        else:
            stoped = False

        row.update_record(
            name=name,
            address=address,
            tel=tel,
            note=note,
            bank_account=bank_account,
            stoped=stoped,
        )
    db.commit()
    redirect(URL("setup", "util"))
#===============================================
@can_access(9301)
def csr_config():
    return dict(csr=[])


@can_access(9301)
def git_csr_config():
    q = db(db.csr_config.id > 0).select().first()
    if q:
        q.otp = ""
        return response.json(q)
    else:
        return response.json(
            {
                "otp": "",
                "serial_number": "",
                "common_name": "",
                "organization_name": "",
                "organization_identifier": "",
                "organization_unit_name": "1",
                "country_name": "SA",
                "invoice_type": "1100",
                "location_address": "",
                "business_category": "",
                "address_city_name": "",
                "address_street_name": "",
                "address_postal_zone": "",
                "address_building_number": "",
                "address_neighborhood": "",
                "company_id": "",
                "environment": "nonproduction",
                "api_site": "http://localhost:8011",
                "privatekey": "",
                "csr": "",
                "egs_uuid": "",
                "ccsid_requestid": "",
                "ccsid_binarysecuritytoken": "",
                "ccsid_secret": "",
                "pcsid_requestid": "",
                "pcsid_binarysecuritytoken": "",
                "pcsid_secret": "",
                "icv": 1,
                "pih": "",
            }
        )


@can_access(9301)
def update_csr_config():
    try:
        data = request.vars
        q = db(db.csr_config.id > 0).select().first()
        if q:
            q.update_record(
                otp=data.otp,
                environment = data.environment ,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.organization_name if "common_name" in data else "",
                organization_name=(
                    data.organization_name if "organization_name" in data else ""
                ),
                organization_identifier=(
                    data.organization_identifier
                    if "organization_identifier" in data
                    else ""
                ),
                organization_unit_name=(
                    data.organization_unit_name
                    if "organization_unit_name" in data
                    else ""
                ),
                country_name="SA",
                invoice_type="1100",
                location_address=(
                    data.location_address if "location_address" in data else ""
                ),
                business_category=(
                    data.business_category if "business_category" in data else ""
                ),
                address_city_name=(
                    data.address_city_name if "address_city_name" in data else ""
                ),
                address_street_name=(
                    data.address_street_name if "address_street_name" in data else ""
                ),
                address_postal_zone=(
                    data.address_postal_zone if "address_postal_zone" in data else ""
                ),
                address_building_number=(
                    data.address_building_number
                    if "address_building_number" in data
                    else ""
                ),
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=(
                    data.address_neighborhood if "address_neighborhood" in data else ""
                ),
                privatekey=data.privatekey if "privatekey" in data else privatekey,
                csr=data.csr if "csr" in data else csr,
                csr_src=data.csr_src if "csr_src" in data else csr_src,
                egs_uuid=data.egs_uuid if "egs_uuid" in data else egs_uuid,
                ccsid_requestid=(
                    data.ccsid_requestid
                    if "ccsid_requestid" in data
                    else ccsid_requestid
                ),
                ccsid_binarysecuritytoken=(
                    data.ccsid_binarysecuritytoken
                    if "ccsid_binarysecuritytoken" in data
                    else ccsid_binarysecuritytoken
                ),
                ccsid_secret=(
                    data.ccsid_secret if "ccsid_secret" in data else ccsid_secret
                ),
                pcsid_requestid=(
                    data.pcsid_requestid
                    if "pcsid_requestid" in data
                    else pcsid_requestid
                ),
                pcsid_binarysecuritytoken=(
                    data.pcsid_binarysecuritytoken
                    if "pcsid_binarysecuritytoken" in data
                    else pcsid_binarysecuritytoken
                ),
                pcsid_secret=(
                    data.pcsid_secret if "pcsid_secret" in data else pcsid_secret
                ),
                api_site=data.api_site if "api_site" in data else "https://api.aseerkayan.net/",
            )
            db.commit()
        else:
            db.csr_config.validate_and_insert(
                otp=data.otp,
                serial_number=data.serial_number if "serial_number" in data else "",
                common_name=data.common_name if "common_name" in data else "",
                organization_name=data.organization_name if "organization_name" in data else "",
                organization_identifier=data.organization_identifier if "organization_identifier" in data else "",
                organization_unit_name=data.organization_unit_name if "organization_unit_name" in data else "",
                country_name="SA",
                invoice_type="1100",
                location_address=data.location_address if "location_address" in data else "",
                business_category=data.business_category if "business_category" in data else "",
                address_city_name=data.address_city_name if "address_city_name" in data else "",    
                address_street_name=data.address_street_name if "address_street_name" in data else "",
                address_postal_zone=data.address_postal_zone if "address_postal_zone" in data else "",
                address_building_number=data.address_building_number if "address_building_number" in data else "",
                company_id=data.company_id if "company_id" in data else "",
                address_neighborhood=data.address_neighborhood if "address_neighborhood" in data else "",
                privatekey=data.privatekey if "privatekey" in data else "",
                csr=data.csr if "csr" in data else "" ,
                csr_src=data.csr_src if "csr_src" in data else "",
                egs_uuid=data.egs_uuid if "egs_uuid" in data else "",
                ccsid_requestid=data.ccsid_requestid if "ccsid_requestid" in data else "",
                ccsid_binarysecuritytoken=data.ccsid_binarysecuritytoken if "ccsid_binarysecuritytoken" in data else "",
                ccsid_secret= data.ccsid_secret if "ccsid_secret" in data else ""  ,
                pcsid_requestid=data.pcsid_requestid if "pcsid_requestid" in data else "",
                pcsid_binarysecuritytoken=  data.pcsid_binarysecuritytoken if "pcsid_binarysecuritytoken" in data else "",
                pcsid_secret= data.pcsid_secret if "pcsid_secret" in data else "" ,

            )
            db.commit()
            # imp_info = db(db.important_info.id > 0).select().first()
            # imp_info.update_record(
            #     name=data.common_name,
            #     vat=data.organization_identifier,
            # )
            # db.commit()
        return response.json("0")
    except Exception as e:
        db.rollback()
        ret = {"mess": str(e)}
        return response.json(ret)


@can_access(9301)
def doc_types():
    return _lookup_page("doc_type")


@can_access(9301)
def job_titles():
    return _lookup_page("job_title")


@can_access(9301)
def nationalities():
    return _lookup_page("nationality")


@can_access(9301)
def advance_types():
    return _lookup_page("advance_type")


@can_access(9301)
def allowance_deduction():
    return _lookup_page("allowance")


@can_access(9301)
def seed_data():
    return dict()


@can_access(9301)
def run_seed_data():
    """API: تشغيل التهيئة وإرجاع النتائج"""
    results = []

    # 1) الترميزات الأساسية
    if db(db.key_unit.id > 0).isempty():
        for n in ["حبة", "علبة", "كرتون", "ملل", "شنطة"]:
            db.key_unit.insert(name=n)
        results.append("الوحدات")

    if db(db.key_payment_method.id > 0).isempty():
        for n in ["نقدي", "شبكة الكترونية", "آجل", "تحويل في الحساب", "شيك", "خصم من الرصيد"]:
            db.key_payment_method.insert(name=n)
        results.append("طرق الدفع")

    if db(db.key_cust.id > 0).isempty():
        for n in ["عميل عام", "عميل جمعية البر"]:
            db.key_cust.insert(name=n)
        results.append("أنواع العملاء")

    if db(db.auth_group.id > 0).isempty():
        for r in ["admin", "user", "account", "report"]:
            db.auth_group.insert(role=r)
        results.append("مجموعات الصلاحيات")

    if db(db.auth_user.id > 0).isempty():
        password = db.auth_user.password.validate("admin")[0]
        user_id = db.auth_user.insert(
            first_name="admin", last_name="user", password=password, email="admin@user.com"
        )
        results.append("المستخدم الافتراضي (admin)")
        if db(db.auth_membership.id > 0).isempty():
            db.auth_membership.insert(
                user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
            )
            results.append("ربط المستخدم بالصلاحيات")

    if db(db.key_type.id > 0).isempty():
        for n in ["ادوات تجميل", "ادوات طبية", "ادوية", "اطفال", "اسنان"]:
            db.key_type.insert(name=n)
        results.append("التصنيفات")

    if db(db.key_payment_type.id > 0).isempty():
        for n in ["سداد مستحقات", "خصم مكتسب", "مرتجعات/فاتورة", "مرتجعات/اصناف"]:
            db.key_payment_type.insert(name=n)
        results.append("أنواع سداد المورد")

    if db(db.key_invoce_type.id > 0).isempty():
        for n in ["مشتريات", "تعويض", "هدايا"]:
            db.key_invoce_type.insert(name=n)
        results.append("تصنيف الفواتير")

    # 2) البيانات الافتتاحية للأعمال
    if db(db.suppliers.id > 0).isempty():
        db.suppliers.insert(name="مورد عام - مورد نقدي")
        results.append("المورد الافتراضي")

    if db(db.items_main.id > 0).isempty():
        db.items_main.insert(
            item_id="1", name="هلل", item_reg="1", flexible_price=True, public_price=0.01
        )
        results.append("الصنف الافتراضي")

    if db(db.customers.id > 0).isempty():
        db.customers.insert(name="عميل عام - نفدي", mobile="0")
        results.append("العميل الافتراضي")

    # 3) بيانات التشغيل
    if db(db.systems.id > 0).isempty():
        db.systems.insert(name="نظام الصيدلية")
        results.append("النظام")

    if db(db.csr_config.id > 0).isempty():
        db.csr_config.insert(otp="123456")
        results.append("إعدادات ZATCA")

    # 4) بيانات المنشأة
    if db(db.important_info.id > 0).isempty():
        db.important_info.insert(
            name="نظام ؟؟؟؟؟؟؟؟؟", vat="0", tel="0",
            mobile="05", address="العنوان", msg1="----", msg2="----",
        )
        results.append("المعلومات الرسمية")

    # 5) ترميزات الموارد البشرية
    if db(db.key_doc_types.id > 0).isempty():
        for n in ["اوراق المؤسسة الرسمية", "اقامة", "جواز سفر", "عقد عمل", "ترخيص مزاولة مهنة"]:
            db.key_doc_types.insert(name=n)
        results.append("أنواع المستندات")

    if db(db.key_job_titles.id > 0).isempty():
        for n in ["صيدلي", "فني صيدلة", "محاسب", "مدير", "بائع"]:
            db.key_job_titles.insert(name=n)
        results.append("المسميات الوظيفية")

    if db(db.key_nationalities.id > 0).isempty():
        for n in ["سعودي", "مصري", "يمني", "سوداني", "هندي", "باكستاني", "بنغلاديشي", "فلبيني"]:
            db.key_nationalities.insert(name=n)
        results.append("الجنسيات")

    if db(db.key_advance_types.id > 0).isempty():
        for n in ["سلفة راتب", "سلفة شخصية", "سلفة طارئة"]:
            db.key_advance_types.insert(name=n)
        results.append("أنواع السلف")

    if db(db.key_allowance_deduction.id > 0).isempty():
        for n, t in [("بدل سكن", "بدل"), ("بدل نقل", "بدل"), ("بدل إضافي", "بدل"),
                     ("خصم غياب", "خصم"), ("خصم تأخير", "خصم"), ("خصم سلفة", "خصم")]:
            db.key_allowance_deduction.insert(name=n, ad_type=t)
        results.append("البدلات والخصومات")

    if db(db.key_emp_status.id > 0).isempty():
        for n in ["على رأس العمل", "في إجازة", "منقطع", "مفصول"]:
            db.key_emp_status.insert(name=n)
        results.append("حالات الموظفين")

    # 6) تصنيفات حركات الصندوق (مصروفات/إيداعات)
    if db(db.key_fund_category.id > 0).isempty():
        for code, name_ar, kind in [
            ("RENT",     "إيجار",                    "expense"),
            ("ELEC",     "كهرباء",                   "expense"),
            ("WATER",    "ماء",                      "expense"),
            ("TELE",     "اتصالات وإنترنت",          "expense"),
            ("SAL",      "رواتب",                    "expense"),
            ("ADV",      "سلف موظفين",               "expense"),
            ("MAINT",    "صيانة",                    "expense"),
            ("TRANS",    "مواصلات",                  "expense"),
            ("MISC",     "نثرية",                    "expense"),
            ("SUP",      "دفعات موردين",             "expense"),
            ("GOV",      "رسوم حكومية",              "expense"),
            ("OTHER_EX", "مصروفات أخرى",             "expense"),
            ("DEPOSIT",  "إيداع نقدي",               "deposit"),
            ("RETURN",   "استرداد من مورد/جهة",      "deposit"),
            ("OTHER_DP", "إيداعات أخرى",             "deposit"),
            ("LEGACY",   "مُرحَّل من النظام القديم", "expense"),
        ]:
            db.key_fund_category.insert(code=code, name_ar=name_ar, kind=kind, is_active=True)
        results.append("تصنيفات حركات الصندوق")

    db.commit()

    # 7) امتداد البحث الضبابي + فهرس وسوم الأصناف (item_tags)
    #    يُنفَّذ هنا لأن CREATE EXTENSION يحتاج صلاحية عالية ويُعمل مرة واحدة،
    #    وفهرس gin_trgm_ops لا يستطيع DAL إنشاءه.
    for label, sql in [
        ("امتداد البحث الضبابي pg_trgm",
         "CREATE EXTENSION IF NOT EXISTS pg_trgm"),
        ("فهرس وسوم الأصناف (trigram)",
         "CREATE INDEX IF NOT EXISTS idx_item_tags_trgm"
         " ON item_tags USING gin (tags gin_trgm_ops)"),
        ("فهرس سجل المحادثات (sender)",
         "CREATE INDEX IF NOT EXISTS conversation_log_sender_idx"
         " ON conversation_log (sender_id, created_on)"),
        ("فهرس سجل المحادثات (created)",
         "CREATE INDEX IF NOT EXISTS conversation_log_created_idx"
         " ON conversation_log (created_on)"),
        ("فهرس سجل المحادثات (customer)",
         "CREATE INDEX IF NOT EXISTS conversation_log_customer_idx"
         " ON conversation_log (customer_id)"),
    ]:
        try:
            db.executesql(sql)
            db.commit()
            results.append(label)
        except Exception as e:
            db.rollback()
            results.append("%s — فشل: %s" % (label, str(e)[:120]))

    return response.json(dict(results=results))


@can_access(9301)
def reset_zatca():
    """حذف بيانات الربط بالهيئة مع الإبقاء على بيانات المؤسسة"""
    try:
        confirm = request.vars.get("confirm")
        if confirm != "DELETE_ZATCA":
            return response.json(dict(ok=False, mess="تأكيد غير صحيح"))

        q = db(db.csr_config.id > 0).select().first()
        if not q:
            return response.json(dict(ok=False, mess="لا توجد بيانات ربط لحذفها"))

        q.update_record(
            otp="",
            privatekey="",
            csr="",
            csr_src="",
            egs_uuid="",
            ccsid_requestid="",
            ccsid_binarysecuritytoken="",
            ccsid_secret="",
            pcsid_requestid="",
            pcsid_binarysecuritytoken="",
            pcsid_secret="",
            icv=1,
            pih="",
            api_site="http://localhost:8011",
            environment="nonproduction",
        )
        db.commit()
        return response.json(dict(ok=True, mess="تم حذف بيانات الربط بالهيئة بنجاح"))
    except Exception as e:
        return response.json(dict(ok=False, mess=str(e)))


# ============================================================================
#         إدارة المستخدمين والصلاحيات - Users Management (Vue.js)
# ============================================================================

@can_access(9302)
def users_management():
    return dict()


@can_access(9302)
def get_users():
    """جلب المستخدمين مع pagination وبحث وفلتر الحالة"""
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    search = request.vars.SearchText or ""
    status_filter = request.vars.status_filter or "all"
    offset = pg * rc

    conditions = []
    params = []
    if search.strip():
        pattern = "%" + search.strip() + "%"
        conditions.append(
            "(first_name LIKE %s OR last_name LIKE %s OR email LIKE %s)"
        )
        params.extend([pattern, pattern, pattern])

    if status_filter == "active":
        conditions.append("(registration_key IS NULL OR registration_key = '')")
    elif status_filter == "disabled":
        conditions.append("(registration_key IS NOT NULL AND registration_key != '')")

    where = ""
    if conditions:
        where = "WHERE " + " AND ".join(conditions)

    sql = (
        "SELECT id, first_name, last_name, email, registration_key, "
        "COALESCE(NULLIF(first_name || ' ' || last_name, ' '), first_name, last_name, email) as full_name "
        "FROM auth_user " + where + " ORDER BY id LIMIT %s OFFSET %s"
    )
    params.extend([rc, offset])
    rows = db.executesql(sql, placeholders=params, as_dict=True)

    count_sql = "SELECT COUNT(*) FROM auth_user " + where
    if conditions:
        count_params = params[:-2]
        count_rows = db.executesql(count_sql, placeholders=count_params, as_dict=False)
    else:
        count_rows = db.executesql(count_sql, as_dict=False)
    count = count_rows[0][0]

    return response.json({"data": rows, "count": count})


@can_access(9302)
def save_user():
    """إضافة أو تعديل مستخدم"""
    try:
        data = request.vars
        user_id = data.get("id")
        if user_id:
            row = db.auth_user[user_id]
            if not row:
                return _setup_json_error("المستخدم غير موجود")
            errors, clean = _validate_user_payload(data, user_id=user_id)
            if errors:
                return _setup_json_error(" | ".join(errors))
            row.update_record(
                first_name=clean["first_name"],
                last_name=clean["last_name"],
                email=clean["email"],
            )
            if clean["password"]:
                row.update_record(password=db.auth_user.password.validate(clean["password"])[0])
        else:
            errors, clean = _validate_user_payload(data)
            if errors:
                return _setup_json_error(" | ".join(errors))
            password = db.auth_user.password.validate(clean["password"])[0]
            user_id = db.auth_user.insert(
                first_name=clean["first_name"],
                last_name=clean["last_name"],
                email=clean["email"],
                password=password,
            )
        db.commit()
        return response.json({"err": 0, "id": user_id})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def delete_user():
    """حذف/تعطيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if not row:
            return _setup_json_error("المستخدم غير موجود")
        row.update_record(registration_key="disabled")
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def enable_user():
    """تفعيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if not row:
            return _setup_json_error("المستخدم غير موجود")
        row.update_record(registration_key=None)
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def get_groups():
    """جلب كل المجموعات"""
    rows = db(db.auth_group.id > 0).select(db.auth_group.id, db.auth_group.role, orderby=db.auth_group.role)
    return response.json(rows.as_list())


@can_access(9302)
def get_user_membership():
    """جلب عضويات المستخدم"""
    user_id = request.args(0)
    sql = (
        "SELECT am.id, am.user_id, am.group_id, ag.role "
        "FROM auth_membership am "
        "JOIN auth_group ag ON ag.id = am.group_id "
        "WHERE am.user_id = %s"
    )
    rows = db.executesql(sql, placeholders=[user_id], as_dict=True)
    return response.json(rows)


@can_access(9302)
def save_membership():
    """حفظ أو حذف عضوية"""
    try:
        data = request.vars
        user_id = data.get("user_id")
        group_id = data.get("group_id")
        checked = data.get("checked") == "true"
        user_id = _valid_auth_user_id(user_id)
        group_id = _valid_group_id(group_id)
        if not user_id:
            return _setup_json_error("المستخدم غير موجود")
        if not group_id:
            return _setup_json_error("المجموعة غير موجودة")

        if checked:
            existing = db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).select().first()
            if not existing:
                db.auth_membership.insert(user_id=user_id, group_id=group_id)
        else:
            db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).delete()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ===================== API for screens_rules Vue.js =====================

@can_access(9302)
def get_screens_rules():
    """جلب صلاحيات الشاشات للمستخدم مع pagination"""
    user_id = request.args(0)
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    offset = pg * rc
    sql = (
        "SELECT sr.id, sr.screens, sr.can_log_in, sr.can_add, sr.can_edit, sr.can_delete, "
        "s.name as screen_name, s.screen_code "
        "FROM screens_rules sr "
        "JOIN screens s ON s.id = sr.screens "
        "WHERE sr.to_user = %s "
        "ORDER BY s.screen_code "
        "LIMIT %s OFFSET %s"
    )
    rows = db.executesql(sql, placeholders=[user_id, rc, offset], as_dict=True)
    count_sql = "SELECT COUNT(*) FROM screens_rules WHERE to_user = %s"
    count = db.executesql(count_sql, placeholders=[user_id])[0][0]
    return response.json({"data": rows, "count": count})


@can_access(9302)
def get_available_screens():
    """جلب الشاشات غير المضافة للمستخدم"""
    user_id = request.args(0)
    sql = (
        "SELECT s.id, s.name, s.screen_code "
        "FROM screens s "
        "WHERE s.id NOT IN ("
        "   SELECT screens FROM screens_rules WHERE to_user = %s"
        ") ORDER BY s.screen_code"
    )
    rows = db.executesql(sql, placeholders=[user_id], as_dict=True)
    return response.json(rows)


@can_access(9302)
def save_rule():
    """حفظ أو تحديث صلاحية"""
    try:
        data = request.vars
        rule_id = data.get("id")
        if rule_id:
            row = db.screens_rules[rule_id]
            if not row:
                return _setup_json_error("الصلاحية غير موجودة")
            row.update_record(
                can_log_in=data.get("can_log_in") == "true",
                can_add=data.get("can_add") == "true",
                can_edit=data.get("can_edit") == "true",
                can_delete=data.get("can_delete") == "true",
            )
        else:
            user_id = _valid_auth_user_id(data.get("to_user"))
            screen_id = _valid_screen_id(data.get("screens"))
            if not user_id:
                return _setup_json_error("المستخدم غير موجود")
            if not screen_id:
                return _setup_json_error("الشاشة غير موجودة")
            db.screens_rules.insert(
                to_user=user_id,
                screens=screen_id,
                can_log_in=data.get("can_log_in") == "true",
                can_add=data.get("can_add") == "true",
                can_edit=data.get("can_edit") == "true",
                can_delete=data.get("can_delete") == "true",
            )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def delete_rule():
    """حذف صلاحية"""
    try:
        row = db.screens_rules[request.args(0)]
        if not row:
            return _setup_json_error("الصلاحية غير موجودة")
        row.delete_record()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ===================== API grant_all / delete_all / add_missing for Vue.js =====================

@can_access(9302)
def api_grant_all():
    """منح جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=True, can_add=True, can_edit=True, can_delete=True
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=True,
                    can_add=True,
                    can_edit=True,
                    can_delete=True,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def api_delete_all():
    """حذف جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=False, can_add=False, can_edit=False, can_delete=False
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=False,
                    can_add=False,
                    can_edit=False,
                    can_delete=False,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def api_add_missing_screens():
    """مزامنة شاشات المستخدم: إضافة الناقصة بدون صلاحيات + حذف المُلغاة"""
    try:
        user_id = request.args(0)
        _sync_screens()
        valid_codes = {r["screen_code"] for r in screens_code}

        # حذف screens_rules للشاشات غير الموجودة في القائمة
        removed = 0
        for row in db(db.screens_rules.to_user == user_id).select():
            screen = db.screens[row.screens]
            if not screen or screen.screen_code not in valid_codes:
                row.delete_record()
                removed += 1

        # إضافة الشاشات الناقصة بدون صلاحيات
        added = 0
        for r in db(db.screens.id > 0).select():
            acc = db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == user_id)
            ).select().first()
            if not acc:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=False,
                    can_add=False,
                    can_edit=False,
                    can_delete=False,
                )
                added += 1

        db.commit()
        return response.json({"err": 0, "added": added, "removed": removed})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
