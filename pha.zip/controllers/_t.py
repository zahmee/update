# -*- coding: utf-8 -*-
#  type: ignore

import os
import threading
import sys

def fix():
    qry = ('PGPASSWORD=\'5445za\' psql -h localhost -U admin -d pha -c " GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to admin ; " ')
    s = os.popen(qry)
    preprocessed = s.read()
    s.close()
    return preprocessed

def db():
    _appPath = request.folder
    backupdir=_appPath + '/static/db.tar'
    configuration = AppConfig(reload=True)
    dbname = configuration.get('db.uri').split("/")
    #backupdir = os.path.dirname(os.path.realpath(__file__)) + '/../static/dbbackup/db.tar'
    # return (backupdir)
    # backupdir='/home/web2py/web2py/applications/acc/static/dbbackup/db.tar'
    script = ("PGPASSWORD='5445za' pg_dump -h localhost -U admin -F t "+dbname[-1]+" >  %s" % (backupdir))
    s = os.popen(script)
    preprocessed = s.read()
    s.close()
    #return script
    return redirect(URL('static','db.tar'))


"""
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to jerry;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to jerry;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to jerry;
"""

#===========================================
def up():
    try :
        _appPath = request.folder
        saved_file = _appPath+"/up.zip " 
        my_script = ("wget  -O  "+saved_file +
                    " http://az10.ws/update/static/pha.zip &&" +
                    " unzip -o -d  "+_appPath +" "+saved_file +
                    " && rm "+ saved_file  )
        # s = os.popen("wget -O /home/web2py/web2py/applications/pha/up.zip http://az10.ws/welcome/static/update_2021_05_26.zip &&  unzip -o -d /home/web2py/web2py/applications/pha/ /home/web2py/web2py/applications/pha/up.zip && rm /home/web2py/web2py/applications/pha/up.zip" )
        s = os.popen(my_script) 
        preprocessed = s.read()
        s.close()
        return dict(info = "updated done " )
    except Exception as e:
        return dict(info = e[0] ) 
