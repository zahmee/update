# -*- coding: utf-8 -*-
# type: ignore
"""
Invoice processor: render JSON invoice data → XML → sign → submit to ZATCA.
Replaces the external proxy's process-one endpoint.
"""

import base64
import json
import logging
import uuid
from decimal import Decimal, ROUND_HALF_UP
from xml.sax.saxutils import escape

import importlib
etree = importlib.import_module("lxml.etree")

from zatca_direct.api_client import build_urls, submit_reporting, submit_clearance
from zatca_direct.signer import sign_invoice, extract_qr_from_xml

logger = logging.getLogger(__name__)

# Document type matrix: prefix → (type_code, description, instruction_note)
DOC_TYPE_MATRIX = {
    "STDSI": ("388", "Standard Invoice", ""),
    "STDCN": ("383", "Standard CreditNote", "InstructionNotes for Standard CreditNote"),
    "STDDN": ("381", "Standard DebitNote", "InstructionNotes for Standard DebitNote"),
    "SIMSI": ("388", "Simplified Invoice", ""),
    "SIMCN": ("383", "Simplified CreditNote", "InstructionNotes for Simplified CreditNote"),
    "SIMDN": ("381", "Simplified DebitNote", "InstructionNotes for Simplified DebitNote"),
}

NS = {
    "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
    "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
}


def _fmt2(x):
    return f"{float(x):.2f}"


def _fmt6(x):
    return f"{float(x):.6f}"


def _render_invoice_xml(inv):
    """Render invoice dict to ZATCA-compliant XML string."""
    # Additional document references (ICV, PIH)
    add_refs = ""
    for doc in (inv.get("AdditionalDocumentReferences") or []):
        if doc["ID"] == "ICV":
            add_refs += f"""
    <cac:AdditionalDocumentReference>
        <cbc:ID>ICV</cbc:ID>
        <cbc:UUID>{escape(str(doc.get("UUID", "")))}</cbc:UUID>
    </cac:AdditionalDocumentReference>"""
        elif doc["ID"] == "PIH":
            add_refs += f"""
    <cac:AdditionalDocumentReference>
        <cbc:ID>PIH</cbc:ID>
        <cac:Attachment>
            <cbc:EmbeddedDocumentBinaryObject mimeCode="text/plain">{escape(doc.get("Attachment", ""))}</cbc:EmbeddedDocumentBinaryObject>
        </cac:Attachment>
    </cac:AdditionalDocumentReference>"""

    # Invoice lines
    lines_xml = ""
    for line in inv.get("InvoiceLines", []):
        lines_xml += f"""
    <cac:InvoiceLine>
        <cbc:ID>{escape(str(line["ID"]))}</cbc:ID>
        <cbc:InvoicedQuantity unitCode="{escape(line.get("UnitCode", "PCE"))}">{_fmt6(line["Quantity"])}</cbc:InvoicedQuantity>
        <cbc:LineExtensionAmount currencyID="SAR">{_fmt2(line["LineExtensionAmount"])}</cbc:LineExtensionAmount>
        <cac:TaxTotal>
            <cbc:TaxAmount currencyID="SAR">{_fmt2(line["TaxAmount"])}</cbc:TaxAmount>
            <cbc:RoundingAmount currencyID="SAR">{_fmt2(line["RoundingAmount"])}</cbc:RoundingAmount>
        </cac:TaxTotal>
        <cac:Item>
            <cbc:Name>{escape(line["Name"])}</cbc:Name>
            <cac:ClassifiedTaxCategory>
                <cbc:ID>{escape(line.get("TaxCategoryID", "S"))}</cbc:ID>
                <cbc:Percent>{_fmt2(line.get("TaxPercent", 15))}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:ClassifiedTaxCategory>
        </cac:Item>
        <cac:Price>
            <cbc:PriceAmount currencyID="SAR">{_fmt2(line["PriceAmount"])}</cbc:PriceAmount>
        </cac:Price>
    </cac:InvoiceLine>"""

    # Optional note
    note_xml = ""
    if inv.get("Note"):
        note_xml = f'\n    <cbc:Note languageID="ar">{escape(inv["Note"])}</cbc:Note>'

    # BillingReference
    billing_ref_xml = ""
    if inv.get("BillingReference"):
        billing_ref_xml = f"""
    <cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>{escape(inv["BillingReference"])}</cbc:ID>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>"""

    # Credit note reference
    credit_note_ref = ""
    if inv.get("InvoiceTypeCode") == "383":
        credit_note_ref = """
    <cac:BillingReference>
        <cac:InvoiceDocumentReference>
            <cbc:ID>1001</cbc:ID>
        </cac:InvoiceDocumentReference>
    </cac:BillingReference>"""

    # Header AllowanceCharge
    ac = inv.get("AllowanceCharge", {})
    header_allowance_taxcats = ""
    for tc in (ac.get("TaxCategories") or []):
        header_allowance_taxcats += f"""
        <cac:TaxCategory>
            <cbc:ID schemeID="UN/ECE 5305" schemeAgencyID="6">{escape(tc.get("ID", "S"))}</cbc:ID>
            <cbc:Percent>{_fmt2(tc.get("Percent", 15))}</cbc:Percent>
            <cac:TaxScheme>
                <cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">{escape(tc.get("SchemeID", "VAT"))}</cbc:ID>
            </cac:TaxScheme>
        </cac:TaxCategory>"""

    charge_indicator = "true" if ac.get("ChargeIndicator") in (True, "True", "true") else "false"
    header_allowance_xml = f"""
    <cac:AllowanceCharge>
        <cbc:ChargeIndicator>{charge_indicator}</cbc:ChargeIndicator>
        <cbc:AllowanceChargeReason>{escape(ac.get("Reason", "discount"))}</cbc:AllowanceChargeReason>
        <cbc:Amount currencyID="SAR">{_fmt2(ac.get("Amount", 0))}</cbc:Amount>{header_allowance_taxcats}
    </cac:AllowanceCharge>"""

    # Zero-tax subtotal (medicines)
    zero_lines = [ln for ln in inv.get("InvoiceLines", []) if ln.get("TaxPercent", 15) == 0]
    taxsubtotal_zero = ""
    if zero_lines:
        zero_taxable = sum(ln["LineExtensionAmount"] for ln in zero_lines)
        taxsubtotal_zero = f"""<cac:TaxSubtotal>
            <cbc:TaxableAmount currencyID="SAR">{_fmt2(zero_taxable)}</cbc:TaxableAmount>
            <cbc:TaxAmount currencyID="SAR">0.00</cbc:TaxAmount>
            <cac:TaxCategory>
                <cbc:ID>Z</cbc:ID>
                <cbc:Percent>0.00</cbc:Percent>
                <cbc:TaxExemptionReasonCode>VATEX-SA-35</cbc:TaxExemptionReasonCode>
                <cbc:TaxExemptionReason>Medicines and medical equipment | الأدوية والمعدات الطبية</cbc:TaxExemptionReason>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>"""

    xml_text = f"""<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">
    <cbc:ProfileID>{escape(inv.get("ProfileID", "reporting:1.0"))}</cbc:ProfileID>
    <cbc:ID>{escape(inv.get("ID", ""))}</cbc:ID>
    <cbc:UUID>{escape(inv.get("UUID", ""))}</cbc:UUID>
    <cbc:IssueDate>{escape(inv.get("IssueDate", ""))}</cbc:IssueDate>
    <cbc:IssueTime>{escape(inv.get("IssueTime", ""))}</cbc:IssueTime>
    <cbc:InvoiceTypeCode name="{escape(inv.get("InvoiceTypeCodeName", "0200000"))}">{escape(inv.get("InvoiceTypeCode", "388"))}</cbc:InvoiceTypeCode>{note_xml}
    <cbc:DocumentCurrencyCode>{escape(inv.get("DocumentCurrencyCode", "SAR"))}</cbc:DocumentCurrencyCode>
    <cbc:TaxCurrencyCode>{escape(inv.get("TaxCurrencyCode", "SAR"))}</cbc:TaxCurrencyCode>{billing_ref_xml}
    {credit_note_ref}
    {add_refs}
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="{escape(inv.get("SupplierSchemeID", "CRN"))}">{escape(inv.get("SupplierCRN", ""))}</cbc:ID>
            </cac:PartyIdentification>
            <cac:PostalAddress>
                <cbc:StreetName>{escape(inv.get("SupplierStreetName", ""))}</cbc:StreetName>
                <cbc:BuildingNumber>{escape(inv.get("SupplierBuildingNumber", ""))}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{escape(inv.get("SupplierDistrict", ""))}</cbc:CitySubdivisionName>
                <cbc:CityName>{escape(inv.get("SupplierCityName", ""))}</cbc:CityName>
                <cbc:PostalZone>{escape(inv.get("SupplierPostalZone", ""))}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>{escape(inv.get("SupplierCountryCode", "SA"))}</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{escape(inv.get("SupplierVAT", ""))}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{escape(inv.get("SupplierName", ""))}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PostalAddress>
                <cbc:StreetName>{escape(inv.get("CustomerStreetName", ""))}</cbc:StreetName>
                <cbc:BuildingNumber>{escape(inv.get("CustomerBuildingNumber", ""))}</cbc:BuildingNumber>
                <cbc:CitySubdivisionName>{escape(inv.get("CustomerDistrict", ""))}</cbc:CitySubdivisionName>
                <cbc:CityName>{escape(inv.get("CustomerCityName", ""))}</cbc:CityName>
                <cbc:PostalZone>{escape(inv.get("CustomerPostalZone", ""))}</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>{escape(inv.get("CustomerCountryCode", "SA"))}</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>{escape(inv.get("CustomerVAT", ""))}</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>{escape(inv.get("CustomerName", ""))}</cbc:RegistrationName>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingCustomerParty>
    <cac:Delivery>
        <cbc:ActualDeliveryDate>{escape(inv.get("DeliveryDate", ""))}</cbc:ActualDeliveryDate>
    </cac:Delivery>
    <cac:PaymentMeans>
        <cbc:PaymentMeansCode>{escape(inv.get("PaymentMeansCode", "10"))}</cbc:PaymentMeansCode>
    </cac:PaymentMeans>
    {header_allowance_xml}
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{_fmt2(inv.get("TaxAmount", 0))}</cbc:TaxAmount>
    </cac:TaxTotal>
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="SAR">{_fmt2(inv.get("TaxAmount", 0))}</cbc:TaxAmount>
        {taxsubtotal_zero}
        <cac:TaxSubtotal>
            <cbc:TaxableAmount currencyID="SAR">{_fmt2(inv.get("TaxableAmount", 0))}</cbc:TaxableAmount>
            <cbc:TaxAmount currencyID="SAR">{_fmt2(inv.get("TaxAmount", 0))}</cbc:TaxAmount>
            <cac:TaxCategory>
                <cbc:ID schemeID="UN/ECE 5305" schemeAgencyID="6">S</cbc:ID>
                <cbc:Percent>{_fmt2(inv.get("TaxPercent", 15))}</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID schemeID="UN/ECE 5153" schemeAgencyID="6">VAT</cbc:ID>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>
    </cac:TaxTotal>
    <cac:LegalMonetaryTotal>
        <cbc:LineExtensionAmount currencyID="SAR">{_fmt2(inv.get("LineExtensionAmount", 0))}</cbc:LineExtensionAmount>
        <cbc:TaxExclusiveAmount currencyID="SAR">{_fmt2(inv.get("TaxExclusiveAmount", 0))}</cbc:TaxExclusiveAmount>
        <cbc:TaxInclusiveAmount currencyID="SAR">{_fmt2(inv.get("TaxInclusiveAmount", 0))}</cbc:TaxInclusiveAmount>
        <cbc:AllowanceTotalAmount currencyID="SAR">{_fmt2(inv.get("AllowanceTotalAmount", 0))}</cbc:AllowanceTotalAmount>
        <cbc:PrepaidAmount currencyID="SAR">{_fmt2(inv.get("PrepaidAmount", 0))}</cbc:PrepaidAmount>
        <cbc:PayableAmount currencyID="SAR">{_fmt2(inv.get("PayableAmount", 0))}</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>
    {lines_xml}
</Invoice>"""
    return "\n".join(ln for ln in xml_text.splitlines() if ln.strip())


def _modify_xml_doc(xml_doc, doc_type, icv, pih):
    """Apply ICV, PIH, UUID, and type-specific modifications to parsed XML."""
    root = xml_doc.getroot()

    # Generate new UUID
    node = root.find(".//cbc:UUID", namespaces=NS)
    if node is not None:
        node.text = str(uuid.uuid4()).upper()

    # Set InvoiceTypeCode name attribute
    is_simplified = doc_type.startswith("SIM")
    type_code_name = "0200000" if is_simplified else "0100000"
    node = root.find(".//cbc:InvoiceTypeCode", namespaces=NS)
    if node is not None:
        node.set("name", type_code_name)

    # ICV
    node = root.find(
        ".//cac:AdditionalDocumentReference[cbc:ID='ICV']/cbc:UUID",
        namespaces=NS,
    )
    if node is not None:
        node.text = str(icv)

    # PIH
    node = root.find(
        ".//cac:AdditionalDocumentReference[cbc:ID='PIH']/cac:Attachment/cbc:EmbeddedDocumentBinaryObject",
        namespaces=NS,
    )
    if node is not None:
        node.text = pih

    # Instruction note for credit/debit notes
    type_code, _, instruction_note = DOC_TYPE_MATRIX.get(doc_type, ("388", "", ""))
    if instruction_note:
        payment_means = root.find(".//cac:PaymentMeans", namespaces=NS)
        if payment_means is not None:
            note_el = etree.Element(
                "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}InstructionNote"
            )
            note_el.text = instruction_note
            payment_means.append(note_el)

    return xml_doc


def sign_only(invoice_data):
    """
    Sign invoice locally — NO submission to ZATCA.
    Returns: {pih_base64, qr_value, signed_payload}
    """
    cert_info = invoice_data["cert_info"]
    doc_type = invoice_data["document_type"]
    inv = invoice_data["invoice"]
    icv = invoice_data.get("icv_start", 1)
    pih = invoice_data.get("pih_base64", "")

    is_simplified = doc_type.startswith("SIM")

    xml_string = _render_invoice_xml(inv)
    parser = etree.XMLParser(remove_blank_text=False)
    xml_doc = etree.fromstring(xml_string.encode("utf-8"), parser=parser).getroottree()
    xml_doc = _modify_xml_doc(xml_doc, doc_type, icv, pih)

    x509_cert = base64.b64decode(
        cert_info.get("pcsid_binarySecurityToken", "")
    ).decode("utf-8")
    private_key = cert_info.get("privateKey", "")

    signed_json_str = sign_invoice(xml_doc, x509_cert, private_key)
    signed_payload = json.loads(signed_json_str)

    new_pih = signed_payload.get("invoiceHash", pih)

    qr_value = ""
    if is_simplified:
        qr_value = extract_qr_from_xml(signed_payload.get("invoice", "")) or ""

    return {
        "pih_base64": new_pih,
        "qr_value": qr_value,
        "signed_payload": signed_payload,
    }


def process_invoice(invoice_data):
    """
    Process a single invoice: render XML → sign → submit to ZATCA.

    invoice_data: dict from generate_invoice_json() with keys:
        cert_info: {privateKey, pcsid_binarySecurityToken, pcsid_secret, environment, ...}
        document_type: "SIMSI", "STDSI", etc.
        invoice: {ID, UUID, IssueDate, ...all invoice fields}
        icv_start: int
        pih_base64: str

    Returns dict: {pih_base64, qr_value, raw_response}
    """
    cert_info = invoice_data["cert_info"]
    doc_type = invoice_data["document_type"]
    inv = invoice_data["invoice"]
    icv = invoice_data.get("icv_start", 1)
    pih = invoice_data.get("pih_base64", "")

    is_simplified = doc_type.startswith("SIM")
    urls = build_urls(cert_info.get("environment", "simulation"))

    # 1. Render invoice dict to XML string
    xml_string = _render_invoice_xml(inv)

    # 2. Parse XML
    parser = etree.XMLParser(remove_blank_text=False)
    xml_doc = etree.fromstring(xml_string.encode("utf-8"), parser=parser).getroottree()

    # 3. Modify XML (UUID, ICV, PIH, type name)
    xml_doc = _modify_xml_doc(xml_doc, doc_type, icv, pih)

    # 4. Decode certificate
    x509_cert = base64.b64decode(
        cert_info.get("pcsid_binarySecurityToken", "")
    ).decode("utf-8")
    private_key = cert_info.get("privateKey", "")

    # 5. Sign
    signed_json_str = sign_invoice(xml_doc, x509_cert, private_key)
    signed_payload = json.loads(signed_json_str)

    json_payload_str = json.dumps(signed_payload)

    # 6. Submit to ZATCA
    pcsid_token = cert_info.get("pcsid_binarySecurityToken", "")
    pcsid_secret = cert_info.get("pcsid_secret", "")

    if is_simplified:
        raw_response = submit_reporting(
            pcsid_token, pcsid_secret, json_payload_str, urls["reportingUrl"]
        )
    else:
        raw_response = submit_clearance(
            pcsid_token, pcsid_secret, json_payload_str, urls["clearanceUrl"]
        )

    # 7. Check status
    status_key = "reportingStatus" if is_simplified else "clearanceStatus"
    status = raw_response.get(status_key, "")

    new_pih = pih
    if "REPORTED" in status or "CLEARED" in status:
        new_pih = signed_payload.get("invoiceHash", pih)

    # 8. Extract QR
    qr_value = ""
    if is_simplified:
        qr_value = extract_qr_from_xml(signed_payload.get("invoice", "")) or ""
    else:
        cleared_invoice = raw_response.get("clearedInvoice", "")
        if cleared_invoice:
            qr_value = extract_qr_from_xml(cleared_invoice) or ""

    return {
        "pih_base64": new_pih,
        "qr_value": qr_value,
        "raw_response": raw_response,
        "status": status,
    }
