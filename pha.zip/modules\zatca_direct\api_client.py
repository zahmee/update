# -*- coding: utf-8 -*-
"""
Direct HTTP calls to ZATCA API endpoints.
"""

import json
import time
import logging
import importlib
requests = importlib.import_module("requests")
HTTPBasicAuth = importlib.import_module("requests.auth").HTTPBasicAuth

logger = logging.getLogger(__name__)

_ENV_API_PATHS = {
    "nonproduction": "developer-portal",
    "simulation": "simulation",
    "production": "core",
}
_ZATCA_BASE = "https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}"


def build_urls(environment_type):
    """Build all ZATCA endpoint URLs for a given environment."""
    api_path = _ENV_API_PATHS.get(environment_type.lower(), "developer-portal")
    base = _ZATCA_BASE.format(api_path=api_path)
    return {
        "complianceCsidUrl": f"{base}/compliance",
        "complianceChecksUrl": f"{base}/compliance/invoices",
        "productionCsidUrl": f"{base}/production/csids",
        "reportingUrl": f"{base}/invoices/reporting/single",
        "clearanceUrl": f"{base}/invoices/clearance/single",
    }


def _post_with_retry(url, headers, payload, auth=None, retries=3, backoff=1, timeout=30):
    """POST with exponential backoff retry."""
    last_error = None
    for attempt in range(retries):
        try:
            resp = requests.post(url, headers=headers, data=payload, auth=auth, timeout=timeout)
            if resp.status_code != 200:
                raise ZatcaApiError(resp.status_code, resp.text)
            return resp.text
        except ZatcaApiError:
            raise
        except requests.exceptions.ConnectionError as e:
            last_error = e
            if attempt < retries - 1:
                time.sleep(backoff * (2 ** attempt))
            else:
                raise ZatcaConnectionError(f"تعذر الاتصال بـ ZATCA بعد {retries} محاولات: {e}")
        except requests.exceptions.Timeout as e:
            last_error = e
            if attempt < retries - 1:
                time.sleep(backoff * (2 ** attempt))
            else:
                raise ZatcaConnectionError(f"انتهت مهلة الاتصال بـ ZATCA: {e}")
        except Exception as e:
            raise ZatcaApiError(500, str(e))
    raise ZatcaConnectionError(str(last_error))


class ZatcaApiError(Exception):
    def __init__(self, status_code, detail):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"ZATCA API Error ({status_code}): {detail}")


class ZatcaConnectionError(Exception):
    pass


# --- Public API functions ---

def request_compliance_csid(csr_base64, otp, url):
    """Send CSR to ZATCA and get Compliance CSID."""
    headers = {
        "accept": "application/json",
        "accept-language": "en",
        "OTP": str(otp),
        "Accept-Version": "V2",
        "Content-Type": "application/json",
    }
    payload = json.dumps({"csr": csr_base64})
    resp_text = _post_with_retry(url, headers, payload)
    return json.loads(resp_text)


def request_production_csid(ccsid_request_id, ccsid_token, ccsid_secret, url):
    """Request Production CSID using Compliance credentials."""
    headers = {
        "accept": "application/json",
        "accept-language": "en",
        "Accept-Version": "V2",
        "Content-Type": "application/json",
    }
    payload = json.dumps({"compliance_request_id": ccsid_request_id})
    auth = HTTPBasicAuth(ccsid_token, ccsid_secret)
    resp_text = _post_with_retry(url, headers, payload, auth=auth)
    return json.loads(resp_text)


def submit_compliance_check(ccsid_token, ccsid_secret, json_payload, url):
    """Submit invoice for compliance check."""
    headers = {
        "accept": "application/json",
        "accept-language": "en",
        "Accept-Version": "V2",
        "Content-Type": "application/json",
    }
    auth = HTTPBasicAuth(ccsid_token, ccsid_secret)
    resp_text = _post_with_retry(url, headers, json_payload, auth=auth)
    return json.loads(resp_text)


def submit_reporting(pcsid_token, pcsid_secret, json_payload, url):
    """Submit simplified invoice for reporting."""
    headers = {
        "accept": "application/json",
        "accept-language": "en",
        "Accept-Version": "V2",
        "Content-Type": "application/json",
    }
    auth = HTTPBasicAuth(pcsid_token, pcsid_secret)
    resp_text = _post_with_retry(url, headers, json_payload, auth=auth, timeout=50)
    return json.loads(resp_text)


def submit_clearance(pcsid_token, pcsid_secret, json_payload, url):
    """Submit standard invoice for clearance."""
    headers = {
        "accept": "application/json",
        "accept-language": "en",
        "Clearance-Status": "1",
        "Accept-Version": "V2",
        "Content-Type": "application/json",
    }
    auth = HTTPBasicAuth(pcsid_token, pcsid_secret)
    resp_text = _post_with_retry(url, headers, json_payload, auth=auth, timeout=50)
    return json.loads(resp_text)
