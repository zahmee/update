# -*- coding: utf-8 -*-
# type: ignore
"""
إدارة وسوم الأصناف (item_tags):
- get_tags / save_tags    : عرض وتعديل يدوي (source='manual' فلا يلمسه التوليد الآلي)
- generate_one            : توليد/إعادة توليد آلي لصنف واحد
- manage / backfill       : التعبئة المجمّعة لجميع الأصناف غير المُوسَّمة (admin)

التوليد الفعلي في modules/item_tagger.py. المفتاح والنموذج من db.py
(ai_api_key / ai_model) المقروءين من appconfig.ini قسم [ai].
"""
import api_helpers as api
import item_tagger


def _untagged_count():
    return db.executesql(
        "SELECT count(*) FROM items_main m"
        " WHERE NOT EXISTS (SELECT 1 FROM item_tags t WHERE t.item_idr = m.id)"
    )[0][0]


# ===========================================================================
# عرض/تعديل وسوم صنف واحد (متاح لمن يملك صلاحية شاشة الأصناف)
# ===========================================================================
@can_access(3001)
def get_tags():
    item_id = request.vars.item_id
    if not item_id or not str(item_id).isdigit():
        return response.json(api.api_error(mess="رقم الصنف مطلوب"))
    row = db(db.item_tags.item_idr == int(item_id)).select().first()
    return response.json(api.api_ok(data={
        "item_idr": int(item_id),
        "tags": row.tags if row else "",
        "source": row.source if row else None,
        "updated_on": str(row.updated_on) if (row and row.updated_on) else None,
    }))


@can_access(3001)
def save_tags():
    """حفظ يدوي — يثبّت source='manual'."""
    item_id = request.vars.item_id
    if not item_id or not str(item_id).isdigit():
        return response.json(api.api_error(mess="رقم الصنف مطلوب"))
    tags = (request.vars.tags or "").strip()
    try:
        item_tagger.store_tags(db, int(item_id), tags, source="manual")
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(data={
        "item_idr": int(item_id), "tags": tags, "source": "manual"}))


@can_access(3001)
def generate_one():
    """توليد (أو إعادة توليد) آلي لصنف واحد. لا يكتب فوق تعديل يدوي إلا بطلب صريح."""
    item_id = request.vars.item_id
    if not item_id or not str(item_id).isdigit():
        return response.json(api.api_error(mess="رقم الصنف مطلوب"))
    item = db.items_main(int(item_id))
    if not item:
        return response.json(api.api_error(mess="الصنف غير موجود"))
    try:
        tags = item_tagger.tag_and_store(db, item, ai_api_key, ai_model, source="ai")
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(data={
        "item_idr": item.id, "tags": tags, "source": "ai"}))


# ===========================================================================
# التعبئة المجمّعة (admin) — مجزّأة وقابلة للاستئناف
# ===========================================================================
@auth.requires_membership("admin")
def manage():
    """صفحة إدارة التعبئة المجمّعة."""
    return dict(
        total=db(db.items_main.id > 0).count(),
        untagged=_untagged_count(),
        key_set=bool(ai_api_key),
    )


@auth.requires_membership("admin")
def backfill():
    """
    يعالج دفعة من الأصناف غير المُوسَّمة. يُستدعى تكراراً من الواجهة حتى remaining=0.
    آمن عند التكرار: يختار فقط ما لا وسم له (NOT EXISTS).
    """
    if not ai_api_key:
        return response.json(api.api_error(
            mess="مفتاح الذكاء الاصطناعي غير مُعدّ في appconfig.ini [ai]"))
    try:
        batch = min(int(request.vars.batch or 20), 50)
    except (TypeError, ValueError):
        batch = 20

    rows = db.executesql(
        "SELECT m.id FROM items_main m"
        " WHERE NOT EXISTS (SELECT 1 FROM item_tags t WHERE t.item_idr = m.id)"
        " ORDER BY m.id LIMIT %s",
        placeholders=[batch], as_dict=True,
    )

    done = 0
    failed = []
    for r in rows:
        item = db.items_main(r["id"])
        if not item:
            continue
        try:
            item_tagger.tag_and_store(db, item, ai_api_key, ai_model, source="ai")
            db.commit()
            done += 1
        except Exception as e:
            db.rollback()
            failed.append({"id": r["id"], "error": str(e)})

    return response.json(api.api_ok(data={
        "processed": done,
        "failed": failed,
        "remaining": _untagged_count(),
    }))
