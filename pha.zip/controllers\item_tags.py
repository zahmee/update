# -*- coding: utf-8 -*-
# type: ignore
"""
إدارة وسوم الأصناف (item_tags):
- get_tags / save_tags : عرض وتعديل يدوي (source='manual')
- generate_one         : توليد آلي لصنف واحد  → Claude  (دقة للسجل الواحد)
- manage / backfill     : تعبئة مجمّعة لكل الأصناف → DeepSeek (دفعات متوازية، أرخص وأسرع)

التوليد في modules/item_tagger.py. الإعدادات من db.py (قسم [ai]):
- Claude  : ai_anthropic_key / ai_anthropic_model
- DeepSeek: ai_openai_key / ai_openai_base_url / ai_openai_model
- ضبط الدفعات: ai_batch_items (أسماء لكل نداء) و ai_concurrency (نداءات متوازية)
"""
from concurrent.futures import ThreadPoolExecutor

import api_helpers as api
import item_tagger


def _cfg(role):
    """يبني cfg للعملية (single|bulk) حسب ai_provider في appconfig.ini."""
    return item_tagger.cfg_for(
        role, ai_provider,
        anthropic_model=ai_anthropic_model, anthropic_key=ai_anthropic_key,
        openai_model=ai_openai_model, openai_key=ai_openai_key,
        openai_base_url=ai_openai_base_url)


def _untagged_count():
    return db.executesql(
        "SELECT count(*) FROM items_main m"
        " WHERE NOT EXISTS (SELECT 1 FROM item_tags t WHERE t.item_idr = m.id)"
    )[0][0]


# ===========================================================================
# عرض/تعديل وسوم صنف واحد
# ===========================================================================
@can_access(3001)
def get_tags():
    item_id = request.vars.item_id
    if not item_id or not str(item_id).isdigit():
        return response.json(api.api_error(mess="رقم الصنف مطلوب"))
    row = db(db.item_tags.item_idr == int(item_id)).select().first()
    return response.json(api.api_ok(data={
        "item_idr": int(item_id),
        "tags": row.tags if row else "",
        "source": row.source if row else None,
        "updated_on": str(row.updated_on) if (row and row.updated_on) else None,
    }))


@can_access(3001)
def save_tags():
    """حفظ يدوي — يثبّت source='manual'."""
    item_id = request.vars.item_id
    if not item_id or not str(item_id).isdigit():
        return response.json(api.api_error(mess="رقم الصنف مطلوب"))
    tags = (request.vars.tags or "").strip()
    try:
        item_tagger.store_tags(db, int(item_id), tags, source="manual")
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(data={
        "item_idr": int(item_id), "tags": tags, "source": "manual"}))


@can_access(3001)
def generate_one():
    """توليد/إعادة توليد آلي لصنف واحد عبر Claude."""
    item_id = request.vars.item_id
    if not item_id or not str(item_id).isdigit():
        return response.json(api.api_error(mess="رقم الصنف مطلوب"))
    item = db.items_main(int(item_id))
    if not item:
        return response.json(api.api_error(mess="الصنف غير موجود"))
    try:
        tags = item_tagger.tag_and_store(db, item, _cfg("single"), source="ai")
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(data={
        "item_idr": item.id, "tags": tags, "source": "ai"}))


# ===========================================================================
# التعبئة المجمّعة (admin) — DeepSeek، دفعات متوازية
# ===========================================================================
@auth.requires_membership("admin")
def manage():
    bulk = _cfg("bulk")
    return dict(
        total=db(db.items_main.id > 0).count(),
        untagged=_untagged_count(),
        key_set=bool(bulk.get("api_key")),
        bulk_model=bulk.get("model"),
        bulk_provider=bulk.get("provider"),
        batch_items=ai_batch_items,
        concurrency=ai_concurrency,
    )


@auth.requires_membership("admin")
def backfill():
    """
    موجة واحدة: تختار حتى (batch_items × concurrency) صنفاً غير مُوسَّم،
    تقسّمها مجموعات من batch_items، وترسل كل مجموعة في نداء واحد، بالتوازي.
    آمنة عند التكرار (NOT EXISTS) وقابلة للاستئناف. تُستدعى تكراراً من الواجهة.
    """
    cfg = _cfg("bulk")
    if not cfg.get("api_key"):
        return response.json(api.api_error(
            mess="مفتاح مزوّد التعبئة غير مُعدّ في appconfig.ini [ai]"))

    batch_items = max(1, int(ai_batch_items or 50))
    concurrency = max(1, int(ai_concurrency or 8))
    wave = batch_items * concurrency
    try:
        cap = int(request.vars.max) if request.vars.max else wave
    except (TypeError, ValueError):
        cap = wave
    take = max(1, min(wave, cap))

    rows = db.executesql(
        "SELECT m.id, m.name, m.generic_name, m.item_type FROM items_main m"
        " WHERE NOT EXISTS (SELECT 1 FROM item_tags t WHERE t.item_idr = m.id)"
        " ORDER BY m.id LIMIT %s",
        placeholders=[take], as_dict=True,
    )
    if not rows:
        return response.json(api.api_ok(data={
            "processed": 0, "failed": [], "remaining": 0}))

    # أسماء التصنيفات دفعة واحدة (بدل استعلام لكل صنف)
    type_ids = list({r["item_type"] for r in rows if r["item_type"]})
    type_map = {}
    if type_ids:
        for t in db.executesql(
            "SELECT id, name FROM key_type WHERE id = ANY(%s)",
            placeholders=[type_ids], as_dict=True,
        ):
            type_map[t["id"]] = t["name"]

    items = [{
        "id": r["id"], "name": r["name"], "generic_name": r["generic_name"],
        "item_type": type_map.get(r["item_type"]),
    } for r in rows]

    # تقسيم إلى مجموعات + معالجة متوازية (HTTP فقط داخل الخيوط، بلا DAL)
    chunks = [items[i:i + batch_items] for i in range(0, len(items), batch_items)]
    results = {}
    failed = []
    with ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = [ex.submit(item_tagger.generate_tags_batch, c, cfg) for c in chunks]
        for idx, f in enumerate(futures):
            try:
                results.update(f.result())
            except Exception as e:
                failed.append({"chunk": idx, "error": str(e)[:200]})

    # الحفظ في الخيط الرئيسي (DAL غير آمن للخيوط)
    done = 0
    for it in items:
        tags = results.get(it["id"])
        if tags:
            item_tagger.store_tags(db, it["id"], tags, source="ai")
            done += 1
    db.commit()

    missing = [it["id"] for it in items if it["id"] not in results]
    if missing:
        failed.append({"missing_count": len(missing),
                       "error": "لم يُرجع النموذج وسوماً لبعض الأصناف (تُعاد لاحقاً)"})

    return response.json(api.api_ok(data={
        "processed": done, "failed": failed, "remaining": _untagged_count()}))
