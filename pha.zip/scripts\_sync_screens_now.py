# -*- coding: utf-8 -*-
"""
مزامنة فورية لجدول الشاشات مع قائمة screens_code في controllers/setup.py
(نفس منطق _sync_screens): إضافة الناقص + حذف الزائد مع صلاحياته.
تشغيل: uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/_sync_screens_now.py
"""
import os, re

setup_path = os.path.join(request.folder, "controllers", "setup.py")
src = open(setup_path, encoding="utf-8").read()
m = re.search(r"screens_code\s*=\s*\[(.*?)\n\]", src, re.S)
registry = {}
for name, code in re.findall(
    r'\{[^{}]*?"name"\s*:\s*"([^"]+)"[^{}]*?"screen_code"\s*:\s*(\d+)[^{}]*?\}', m.group(1)
):
    registry[int(code)] = name
valid_codes = set(registry)

added = 0
for code, name in sorted(registry.items()):
    if not db(db.screens.screen_code == code).select().first():
        db.screens.insert(systems=1, name=name, screen_code=code)
        added += 1
        print("أُضيفت:", code, name)

removed = 0
removed_rules = 0
for row in db(~db.screens.screen_code.belongs(list(valid_codes))).select():
    n = db(db.screens_rules.screens == row.id).delete()
    removed_rules += n
    print("حُذفت:", row.screen_code, row.name, "(صلاحيات محذوفة: %d)" % n)
    row.delete_record()
    removed += 1

db.commit()
print("=" * 50)
print("شاشات مضافة:", added, "| شاشات محذوفة:", removed, "| صلاحيات محذوفة:", removed_rules)
print("عدد الشاشات الآن:", db(db.screens.id > 0).count())
