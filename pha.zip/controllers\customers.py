# -*- coding: utf-8 -*-
#  type: ignore

import os
import sys

'''
p = send_sms.SMS()
p.getbalance()
ms = """
كيفكم
نجرب

تحية 
"""
print(p.send('966557565667', ms))
p.getbalance()
'''


# @auth.requires_membership("user1")
@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


@can_access(1001)
def unit_key():
    grid = SQLFORM.grid(
        db.unit_key,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(1002)
def purchase():
    q = db(db.invoice_master.customer == request.args(0)).select(
        orderby=~db.invoice_master.id, limitby=(0, 50)
    )
    return dict(data=q)


@can_access(1003)
def customers_pay():
    sc = screens_rules(1003)
    try:
        customer_id = int(request.args(0))
    except (ValueError, TypeError):
        redirect(URL('customers', 'index'))
    customer = db.customers[customer_id]
    return dict(
        customer=customer,
        customer_id=customer_id,
        can_add=sc.can_add,
        can_edit=sc.can_edit,
        can_delete=sc.can_delete,
    )


@can_access(1004)
def customers_pay_all():
    sc = screens_rules(1004)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    q = db.customers_pay  # .customers_id == request.args(0)
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=can_edit,
        deletable=can_delete,
        create=can_add,
        csv=False,
        searchable=True,
        showbuttontext=False,
    )
    return dict(grid=grid)


@can_access(1005)
def customers_accounts_settlement():
    return dict()


@can_access(1005)
def accounts_settlement():
    ts = db(db.customers_accounts_settlement.customers_id == request.args(0)).select()
    if ts:
        sd = ts.last().settlement_data
        qry = (
            "select sum(total_after_discount) from invoice_master where customer ="
            " %s and payment_method=3 and created_on>= %s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0), str(sd)])
        mm1 = qs[0][0]
        mm1 = (mm1) and mm1 or 0
        qry = (
            "select sum(amount) from customers_pay where customers_id ="
            " %s and created_on>= %s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0), str(sd)])
        mm2 = qs[0][0]
        mm2 = (mm2) and mm2 or 0
        if (int(mm1) == int(mm2)) and (int(mm1) == int(mm2) != 0):
            db.customers_accounts_settlement.insert(customers_id=request.args(0))
        return redirect(URL("customers", "index"))
    else:
        qry = (
            "select sum(total_after_discount) from invoice_master where payment_method=3 and customer ="
            " %s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0)])
        m1 = qs[0][0]
        qry = (
            "select sum(amount) from customers_pay where customers_id ="
            " %s"
        )
        qs = db.executesql(qry, placeholders=[request.args(0)])
        m2 = qs[0][0]
        if int(m1) == int(m2) and (int(m1) == int(m2) != 0):
            db.customers_accounts_settlement.insert(customers_id=request.args(0))
        return redirect(URL("customers", "index"))


@can_access(1001)
def customers_accounts_calc():
    qry = (
        "update customers set total = (select round( CAST(COALESCE(sum(total_after_discount) ,0) as numeric) ,2) from invoice_master "
        " where payment_method=3 and customer = %s ) ,  "
        " payed=( select round( CAST( COALESCE(sum(amount),0) as numeric) ,2) from customers_pay where customers_id ="
        " %s) , "
        " returns = (select round( CAST(COALESCE(sum(total_after_discount),0) as numeric) ,2) from inv_return_master where payment_method=3 and customer ="
        " %s ) , "
        " amount = round( CAST((select COALESCE(sum(total_after_discount),0) from invoice_master where payment_method=3 and customer ="
        " %s ) "
        " - ( select COALESCE(sum(amount),0) from customers_pay where customers_id ="
        " %s) "
        " - (select COALESCE(sum(total_after_discount),0) from inv_return_master where payment_method=3 and customer ="
        " %s ) as numeric) ,2)  "
        " where id = %s"
    )
    db.executesql(qry, placeholders=[request.args(0), request.args(0), request.args(0), request.args(0), request.args(0), request.args(0), request.args(0)])
    return redirect(URL("customers", "index"))


## ========================= Ver 4.0 ==============================
# ===================================================================


@can_access(1006)
def customer_status_rep():
    customer_id = int(request.args(0))
    customer = db.customers[customer_id]

    ct_cols = (
        ' AS ct ( fcount int, "1" float, "2" float, "3" float, "4" float,'
        ' "5" float, "6" float, "7" float, "8" float,'
        ' "9" float, "10" float, "11" float, "12" float )'
    )

    # 1) المشتريات النقدية (payment_method=1) - crosstab
    qry_cash = (
        "SELECT * FROM crosstab("
        " 'SELECT EXTRACT(YEAR FROM created_on)::integer,"
        " EXTRACT(MONTH FROM created_on)::integer,"
        " SUM(total_after_discount)::numeric(10,2)"
        " FROM invoice_master WHERE customer = " + str(customer_id) +
        " AND payment_method = 1"
        " GROUP BY 1,2 ORDER BY 1,2',"
        " 'SELECT * FROM generate_series(1,12)')"
        + ct_cols
    )
    cash_yearly = db.executesql(qry_cash, as_dict=True)

    qry_cash_totals = (
        "SELECT a.n,"
        " (SELECT SUM(total_after_discount)::float FROM invoice_master"
        "  WHERE customer = %s AND payment_method = 1"
        "  AND EXTRACT(MONTH FROM created_on)::integer = a.n) AS fcount"
        " FROM generate_series(1, 12) AS a(n)"
    )
    cash_monthly = db.executesql(qry_cash_totals, placeholders=[customer_id], as_dict=True)

    # 2) المشتريات الآجلة (payment_method=3) - crosstab
    qry_credit = (
        "SELECT * FROM crosstab("
        " 'SELECT EXTRACT(YEAR FROM created_on)::integer,"
        " EXTRACT(MONTH FROM created_on)::integer,"
        " SUM(total_after_discount)::numeric(10,2)"
        " FROM invoice_master WHERE customer = " + str(customer_id) +
        " AND payment_method = 3"
        " GROUP BY 1,2 ORDER BY 1,2',"
        " 'SELECT * FROM generate_series(1,12)')"
        + ct_cols
    )
    credit_yearly = db.executesql(qry_credit, as_dict=True)

    qry_credit_totals = (
        "SELECT a.n,"
        " (SELECT SUM(total_after_discount)::float FROM invoice_master"
        "  WHERE customer = %s AND payment_method = 3"
        "  AND EXTRACT(MONTH FROM created_on)::integer = a.n) AS fcount"
        " FROM generate_series(1, 12) AS a(n)"
    )
    credit_monthly = db.executesql(qry_credit_totals, placeholders=[customer_id], as_dict=True)

    # 3) السدادات - crosstab من customers_pay (كان خطأ يستعلم من invoice_master)
    qry_pay = (
        "SELECT * FROM crosstab("
        " 'SELECT EXTRACT(YEAR FROM created_on)::integer,"
        " EXTRACT(MONTH FROM created_on)::integer,"
        " SUM(amount)::numeric(10,2)"
        " FROM customers_pay WHERE customers_id = " + str(customer_id) +
        " GROUP BY 1,2 ORDER BY 1,2',"
        " 'SELECT * FROM generate_series(1,12)')"
        + ct_cols
    )
    pay_yearly = db.executesql(qry_pay, as_dict=True)

    qry_pay_totals = (
        "SELECT a.n,"
        " (SELECT SUM(amount)::float FROM customers_pay"
        "  WHERE customers_id = %s"
        "  AND EXTRACT(MONTH FROM created_on)::integer = a.n) AS fcount"
        " FROM generate_series(1, 12) AS a(n)"
    )
    pay_monthly = db.executesql(qry_pay_totals, placeholders=[customer_id], as_dict=True)

    def row_sum(row):
        total = 0.0
        for m in range(1, 13):
            val = row.get(str(m))
            if val:
                total += float(val)
        return round(total, 2)

    def month_total(monthly_data):
        total = 0.0
        for item in monthly_data:
            val = item.get('fcount') or item.get('sum') or 0
            total += float(val)
        return round(total, 2)

    months = ['1','2','3','4','5','6','7','8','9','10','11','12']

    return dict(
        customer=customer,
        cash_yearly=cash_yearly, cash_monthly=cash_monthly,
        credit_yearly=credit_yearly, credit_monthly=credit_monthly,
        pay_yearly=pay_yearly, pay_monthly=pay_monthly,
        row_sum=row_sum, month_total=month_total, months=months,
    )


@can_access(1003)
def pay_print():
    return dict()


@can_access(1001)
def report_cost_1():
    return dict()


@can_access(1001)
def report_cost_2():
    return dict()


@can_access(1001)
def report_cost_3():
    return dict()


@can_access(1001)
def report_cost_4():
    return dict()
