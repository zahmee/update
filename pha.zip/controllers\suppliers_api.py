# -*- coding: utf-8 -*-
#  type: ignore

#====================================================================
#def get_supp():
#    q  = db(db.suppliers.id>0).select(db.suppliers.id ,db.suppliers.name , db.suppliers.stoped , orderby=[db.suppliers.stoped,db.suppliers.name ])
#    return response.json(q)

# from asyncio.windows_events import NULL
from datetime import datetime
import json
import re
import api_helpers as api


def _returned_supply_summary(ret_id):
    inv = db.returned_supply[ret_id]
    if not inv:
        return None
    rows = db(db.returned_supply_det.returned_supply == ret_id).select()
    purchase_net = 0.0
    purchase_vat = 0.0
    sale_net = 0.0
    sale_vat = 0.0
    qty_sum = 0.0
    for row in rows:
        vat_rate = float(row.vat or 0)
        row_purchase_net = float(row.total or 0)
        purchase_net += row_purchase_net
        purchase_vat += row_purchase_net * vat_rate
        qty_sum += float(row.item_count or 0)

        item_det = db.items_det[row.item_id]
        row_sale_base = float(row.total_2 or 0)
        vat_in_sale = item_det.vat_in_public_price in (True, "T", "true", "True", 1, "1") if item_det else False
        if vat_in_sale and vat_rate:
            row_sale_net = row_sale_base / (1 + vat_rate)
            row_sale_vat = row_sale_base - row_sale_net
        else:
            row_sale_net = row_sale_base
            row_sale_vat = row_sale_net * vat_rate
        sale_net += row_sale_net
        sale_vat += row_sale_vat

    supplier = db.suppliers[inv.supplier] if inv.supplier else None
    purchase_total = purchase_net + purchase_vat
    sale_total = sale_net + sale_vat
    return {
        "id": inv.id,
        "name": inv.name,
        "supplier": inv.supplier,
        "supplier_name": supplier.name if supplier else "",
        "ret_date": str(inv.ret_date) if inv.ret_date else "",
        "admin_accept": inv.admin_accept,
        "detail_count": len(rows),
        "qty_sum": round(qty_sum, 2),
        "purchase_net": round(purchase_net, 2),
        "purchase_vat": round(purchase_vat, 2),
        "purchase_total": round(purchase_total, 2),
        "supplier_refund_amount": round(purchase_total, 2),
        "sale_net": round(sale_net, 2),
        "sale_vat": round(sale_vat, 2),
        "sale_total": round(sale_total, 2),
        "profit_net": round(sale_net - purchase_net, 2),
        "profit_total": round(sale_total - purchase_total, 2),
        "vat_due": round(sale_vat - purchase_vat, 2),
    }


def _returned_supply_det_payload(row):
    item_det = db.items_det[row.item_id] if row and row.item_id else None
    vat_in_public_price = False
    if item_det:
        vat_in_public_price = item_det.vat_in_public_price in (True, "T", "true", "True", 1, "1")
    return {
        "id": row.id,
        "returned_supply": row.returned_supply,
        "item_id": row.item_id,
        "item_name": row.item_name,
        "vat": row.vat or 0,
        "vat_in_public_price": vat_in_public_price,
        "item_count": row.item_count or 0,
        "inv_price": row.inv_price or 0,
        "inv_bay": row.inv_bay or 0,
        "total": row.total or 0,
        "total_2": row.total_2 or 0,
    }


@can_access(2001)
def get_supp():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( name LIKE %s OR tel LIKE %s OR address LIKE %s )")
            params.extend([pattern, pattern, pattern])
    if ReqVar.StopStatus:
        if ReqVar.StopStatus == "active":
            conditions.append("( stoped = %s )")
            params.append("F")
        elif ReqVar.StopStatus == "stopped":
            conditions.append("( stoped = %s )")
            params.append("T")
    allowed_sort_columns = {'id', 'name', 'tel', 'address', 'stoped', 'note', 'bank_account'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'DESC'
    else :
        sa = 'ASC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    sql = f" SELECT id,name,tel, address ,stoped ,note,bank_account  FROM suppliers {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; "
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers {where} ; "
    params_count = params[:-2]  # exclude LIMIT/OFFSET params
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


#====================================================================
@can_access(2005)
def supply_lock():
    q = db.suppliers[request.args(0)]
    if q.stoped == True :
        q.stoped = False 
    else : 
        q.stoped = True
    q.update_record()
    db.commit()
    return response.json(api.api_ok(mess="تم التحديث"))
#====================================================================
@can_access(2001)
def get_supp_id():
    q  = db.suppliers[request.args(0)]
    return response.json(api.api_ok(data=q))
#====================================================================
@can_access(2003)
def update_supplier():
    data = request.vars
    row = db.suppliers[data.id]
    row.name = data.name 
    row.bank_account = data.bank_account
    row.note = data.note 
    row.tel = data.tel 
    row.address = data.address
    row.stoped = data.stoped
    row.update_record()
    db.commit()
    return response.json(api.api_ok(data=row))
#====================================================================
#@auth.requires(auth.has_membership('user1') or auth.has_membership('admin') or auth.has_membership('secretarial'))
@can_access(2002)
def new_supplier():
    data = request.vars
    def clean_text(value):
        return (value or "").strip()

    def clean_list(value):
        if value is None:
            return []
        if isinstance(value, list):
            raw_values = value
        else:
            try:
                raw_values = json.loads(value)
                if not isinstance(raw_values, list):
                    raw_values = [raw_values]
            except (TypeError, ValueError):
                raw_values = [value]
        return [clean_text(v) for v in raw_values if clean_text(v)]

    name = clean_text(data.name)
    administrator_name = clean_list(data.administrator_name)
    tel = clean_list(data.tel)
    address = clean_text(data.address)

    try:
        total_amount = float(data.total_amount or 0)
    except (TypeError, ValueError):
        total_amount = -1

    errors = []
    if not name:
        errors.append("اسم المورد مطلوب")
    if not administrator_name:
        errors.append("يجب إدخال اسم مسؤول واحد على الأقل")
    if total_amount < 0:
        errors.append("المبلغ المستحق يجب أن يكون رقماً ولا يقل عن صفر")
    if not address:
        errors.append("العنوان مطلوب")
    if not tel:
        errors.append("يجب إدخال رقم هاتف واحد على الأقل")
    elif any(not re.match(r"^[0-9+ -]{7,20}$", t) for t in tel):
        errors.append("رقم الهاتف يجب أن يحتوي أرقاماً فقط ويمكن أن يبدأ بـ +")

    if errors:
        return response.json(api.api_error(mess=" | ".join(errors)))

    if data.stoped is None:
        data.stoped = False

    nid = db.suppliers.insert(
                    name=name,
                    administrator_name=administrator_name,
                    total_amount=total_amount,
                    bank_account=clean_text(data.bank_account),
                    note=clean_text(data.note),
                    tel="\n".join(tel),
                    address=address,
                    stoped=data.stoped
                    )
    db.commit()
    return response.json(api.api_ok(data={"id":str(nid)}))
#====================================================================
#@auth.requires(auth.has_membership('admin') )
# @can_access(2004)
# def delete_supplier():
#     try :
#         data = request.vars
#         row = db.suppliers[data.id]
#         row.delete_record()
#         db.commit()
#         return 0
#     except Exception :
#         db.rollback()
#         print ( e )
#         return e
#====================================================================
@can_access(2010)
def get_invoce_type():
    q  = db(db.key_invoce_type.id>0).select(db.key_invoce_type.id ,db.key_invoce_type.name , orderby=[db.key_invoce_type.id ])
    return response.json(api.api_ok(data=q))
#====================================================================
@can_access(2010)
def getSuppInvoce():
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( sb.bill_no LIKE %s OR CAST(sb.id AS text) LIKE %s OR CAST(sb.bill_total AS text) LIKE %s OR CAST(sb.bill_vat AS text) LIKE %s OR CAST(sb.bill_date AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier :
        if ( (ReqVar.supplier is not None) or (ReqVar.supplier !=''))  :
            conditions.append("( sb.supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.types  and (ReqVar.types != '0' )  :
        if ( (ReqVar.types is not None) or (ReqVar.types !=''))  :
            conditions.append("( sb.invoce_type = %s )")
            params.append(int(ReqVar.types))
    allowed_sort_columns = {'id', 'bill_no', 'bill_date', 'bill_total', 'bill_net_amount', 'bill_vat', 'bill_confirmation', 'return_confirmation', 'supplier', 'payment_method', 'invoce_type'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'DESC'
    else :
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    sql = f"""
        SELECT sb.id, sb.bill_no, sb.bill_date, sb.bill_total, sb.bill_net_amount,
               sb.bill_vat, sb.bill_confirmation, sb.return_confirmation,
               s.name AS s_name,
               kt.name AS t_name,
               COALESCE(itm.itm_count, 0) AS itm_count,
               COALESCE(itm.itm_r_count, 0) AS itm_r_count,
               COALESCE(fc.f_count, 0) AS f_count,
               pm.name AS m_name,
               sb.supplier, sb.payment_method, sb.invoce_type
        FROM suppliers_bills sb
        LEFT JOIN suppliers s ON s.id = sb.supplier
        LEFT JOIN key_invoce_type kt ON kt.id = sb.invoce_type
        LEFT JOIN key_payment_method pm ON pm.id = sb.payment_method
        LEFT JOIN (
            SELECT supplier_inv,
                   COUNT(*) AS itm_count,
                   COUNT(*) FILTER (WHERE return_count > 0) AS itm_r_count
            FROM items_det GROUP BY supplier_inv
        ) itm ON itm.supplier_inv = sb.id
        LEFT JOIN (
            SELECT suppliers_bills_id, COUNT(*) AS f_count
            FROM suppliers_bills_files GROUP BY suppliers_bills_id
        ) fc ON fc.suppliers_bills_id = sb.id
        {where} ORDER BY sb.{sc} {sa} LIMIT %s OFFSET %s
    """
    params_count = list(params)  # copy for count query (without LIMIT/OFFSET)
    params.extend([rc, pg])
    sql2 = f"SELECT count(*) FROM suppliers_bills sb {where}"
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))
#====================================================================
def _validate_supplier_bill_payload(data):
    errors = []

    try:
        day = json.loads(data.day)
        bill_date = datetime(int(day["year"]), int(day["month"]), int(day["day"]), 0, 0)
        if bill_date.date() > request.now.date():
            errors.append("لا يمكن تسجيل تاريخ مستقبلي")
    except Exception:
        bill_date = None
        errors.append("تاريخ الفاتورة غير صحيح")

    try:
        suppliers = json.loads(data.suppliers)
        supplier_id = int(suppliers.get("value") or 0)
    except Exception:
        supplier_id = 0
    if not supplier_id or not db.suppliers[supplier_id]:
        errors.append("المورد مطلوب")

    try:
        payment_method = int(data.payment_method or 0)
    except (TypeError, ValueError):
        payment_method = 0
    if not payment_method or not db.key_payment_method[payment_method]:
        errors.append("طريقة الدفع مطلوبة")

    try:
        invoce_type = int(data.invoce_type or 0)
    except (TypeError, ValueError):
        invoce_type = 0
    if not invoce_type or not db.key_invoce_type[invoce_type]:
        errors.append("نوع الفاتورة مطلوب")

    bill_no = (data.bill_no or "").strip()
    if not bill_no:
        errors.append("رقم فاتورة المورد مطلوب")

    try:
        bill_total = float(data.bill_total or 0)
    except (TypeError, ValueError):
        bill_total = 0
    if bill_total <= 0:
        errors.append("إجمالي الفاتورة يجب أن يكون أكبر من صفر")

    try:
        bill_vat = float(data.bill_vat or 0)
    except (TypeError, ValueError):
        bill_vat = -1
    if bill_vat < 0:
        errors.append("ضريبة الفاتورة لا يمكن أن تكون سالبة")
    elif bill_total > 0 and bill_vat > bill_total:
        errors.append("ضريبة الفاتورة لا يمكن أن تكون أكبر من الإجمالي")

    return errors, {
        "supplier": supplier_id,
        "payment_method": payment_method,
        "invoce_type": invoce_type,
        "bill_no": bill_no,
        "bill_date": bill_date,
        "bill_total": bill_total,
        "bill_vat": bill_vat,
        "bill_net_amount": round(bill_total - bill_vat, 2),
    }


def _parse_form_day(day_json, label):
    try:
        day = json.loads(day_json)
        parsed_date = datetime(int(day["year"]), int(day["month"]), int(day["day"]), 0, 0)
        if parsed_date.date() > request.now.date():
            return None, "%s لا يمكن أن يكون مستقبلياً" % label
        return parsed_date, None
    except Exception:
        return None, "%s غير صحيح" % label


def _valid_supplier_id(value):
    try:
        supplier_id = int(value)
    except (TypeError, ValueError):
        return None
    return supplier_id if db.suppliers[supplier_id] else None


def _valid_lookup_id(table_name, value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db[table_name][row_id] else None


#====================================================================
@can_access(2010)
def new_bill():
    try :
        data = request.vars
        errors, clean_data = _validate_supplier_bill_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.suppliers_bills.insert(
                        supplier=clean_data["supplier"],
                        payment_method=clean_data["payment_method"],
                        bill_no=clean_data["bill_no"],
                        bill_date=clean_data["bill_date"],
                        bill_total=clean_data["bill_total"],
                        bill_vat=clean_data["bill_vat"],
                        bill_net_amount=clean_data["bill_net_amount"],
                        invoce_type=clean_data["invoce_type"]
                        )
        inserted = db.suppliers_bills[nid]
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@can_access(2010)
def edit_bill():
    try :
        data = request.vars
        q = db.suppliers_bills[data.id]
        if not q:
            return response.json(api.api_error(mess="الفاتورة غير موجودة"))
        if q.bill_confirmation==False :
            errors, clean_data = _validate_supplier_bill_payload(data)
            if errors:
                return response.json(api.api_error(mess=" | ".join(errors)))
            q.supplier = clean_data["supplier"]
            q.payment_method = clean_data["payment_method"]
            q.bill_no = clean_data["bill_no"]
            q.bill_date = clean_data["bill_date"]
            q.bill_total = clean_data["bill_total"]
            q.bill_vat = clean_data["bill_vat"]
            q.bill_net_amount = clean_data["bill_net_amount"]
            q.invoce_type = clean_data["invoce_type"]
            q.update_record()
            db.commit()
            return response.json(api.api_ok(data=q))
        else :
            return response.json(api.api_error(mess='لايمكن الحفظ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#================================================================
# ----------------->  returned_supply                  <=========
#================================================================
@can_access(2008)
def getRetSuppInvoce():
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( name LIKE %s OR CAST(id AS text) LIKE %s OR CAST(total AS text) LIKE %s OR CAST(item_count AS text) LIKE %s OR CAST(ret_date AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier :
        if ( (ReqVar.supplier is not None) or (ReqVar.supplier !=''))  :
            conditions.append("( supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.ApprovalStatus:
        if ReqVar.ApprovalStatus == "approved":
            conditions.append("( admin_accept = %s )")
            params.append("T")
        elif ReqVar.ApprovalStatus == "pending":
            conditions.append("( admin_accept = %s )")
            params.append("F")
    allowed_sort_columns = {'id', 'name', 'supplier', 'ret_date', 'real_total', 'admin_accept', 'item_count'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'DESC'
    else :
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq3 = "(select count(*) from returned_supply_det where returned_supply=returned_supply.id) as itm_count"
    subq4 = "(select sum(item_count) from returned_supply_det where returned_supply=returned_supply.id ) as itm_r_count"
    sql = ( f" SELECT id,name ,supplier ,ret_date ,round(CAST(real_total AS decimal ) ,2) as real_total , admin_accept,"
            f" {subq1} ,{subq3},{subq4} FROM returned_supply "
            f" {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; ")
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM returned_supply {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))
#====================================================================
@can_access(2008)
def new_RetSupInv():
    try :
        data = request.vars
        errors = []
        ret_date, date_error = _parse_form_day(data.day, "تاريخ المرتجع")
        if date_error:
            errors.append(date_error)
        try:
            suppliers = json.loads(data.suppliers)
            supplier_id = _valid_supplier_id(suppliers.get("value"))
        except Exception:
            supplier_id = None
        if not supplier_id:
            errors.append("المورد مطلوب")
        name = (data.name or "").strip()
        if not name:
            errors.append("اسم/رقم فاتورة المرتجع مطلوب")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.returned_supply.insert(
                        supplier=supplier_id,
                        name=name,
                        ret_date=ret_date,
                        admin_accept = False 
                        )
        inserted = db.returned_supply[nid]
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@can_access(2008)
def edit_RetSupInv():
    try :
        data = request.vars
        q = db.returned_supply[data.id]
        if q.admin_accept==False :
            errors = []
            ret_date, date_error = _parse_form_day(data.day, "تاريخ المرتجع")
            if date_error:
                errors.append(date_error)
            try:
                suppliers = json.loads(data.suppliers)
                supplier_id = _valid_supplier_id(suppliers.get("value"))
            except Exception:
                supplier_id = None
            if not supplier_id:
                errors.append("المورد مطلوب")
            name = (data.name or "").strip()
            if not name:
                errors.append("اسم/رقم فاتورة المرتجع مطلوب")
            if errors:
                return response.json(api.api_error(mess=" | ".join(errors)))
            q.supplier = supplier_id
            q.ret_date = ret_date
            q.name = name
            q.update_record()
            db.commit()
            return response.json(api.api_ok(data=q))
        else :
            return response.json(api.api_error(mess='لايمكن الحفظ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))


@can_access(2016)
def ret_sup_approval_summary():
    try:
        ret_id = int(request.args(0))
        summary = _returned_supply_summary(ret_id)
        if not summary:
            return response.json(api.api_error(mess="لم يتم العثور على الفاتورة"))
        return response.json(api.api_ok(data=summary))
    except Exception as e:
        return response.json(api.api_error(mess=str(e)))


@can_access(2016)
def approve_RetSupInv():
    try:
        ret_id = int(request.args(0))
        inv = db.returned_supply[ret_id]
        if not inv:
            return response.json(api.api_error(mess="لم يتم العثور على الفاتورة"))
        if inv.admin_accept:
            return response.json(api.api_error(mess="لقد تم اعتماد هذه الفاتورة مسبقا"))

        rows = db(db.returned_supply_det.returned_supply == ret_id).select()
        if len(rows) == 0:
            return response.json(api.api_error(mess="لا يمكن اعتماد فاتورة بدون أصناف"))

        total = 0.0
        for row in rows:
            item_det = db.items_det(row.item_id)
            if not item_det:
                db.rollback()
                return response.json(api.api_error(mess="يوجد صنف غير موجود في تفاصيل المخزون"))
            db(db.items_det.id == row.item_id).update(
                items_count=(db.items_det.items_count - row.item_count)
            )
            db.items_movement.insert(
                item_main=item_det.item_idr,
                item_det=int(row.item_id),
                move_type="مرتجع توريد",
                move_date=request.now,
                qty_in=0,
                qty_out=float(row.item_count or 0),
                unit_price=float(row.inv_price or 0),
                reference=inv.name or "",
                ref_no=str(ret_id),
            )
            total += (row.total or 0) + ((row.total or 0) * (row.vat or 0))

        db(db.returned_supply.id == ret_id).update(admin_accept=True)
        db.suppliers_bills_pay.insert(
            supplier=inv.supplier,
            payment_method=4,
            payment_type=4,
            pay_total=round(total, 2),
            pay_date=datetime.now().date(),
            note="مرتجع اصناف  رقم :" + str(ret_id),
        )
        db.commit()

        summary = _returned_supply_summary(ret_id)
        return response.json(api.api_ok(data=summary, mess="تم اعتماد الفاتورة بنجاح"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))

#================================================================
# ----------------->  returned_supply detail           <=========
#================================================================
@can_access(2008)
def getRetSuppInvoceDet():
    qry = db(db.returned_supply_det.returned_supply==request.args(0) ).select()
    rows = [_returned_supply_det_payload(row) for row in qry]
    return response.json(api.api_ok(data=rows))
#====================================================================
@can_access(2008)
def getit():
    qry = ("select id as item_id ,item_idr,supplier_inv ,expiration_date ,buy_price ,vat ,vat_in_public_price, "
        " ( select name from suppliers where suppliers.id=(select supplier  from suppliers_bills where suppliers_bills.id=supplier_inv)) as s_name , "
        " ( select name from items_main where items_main.id= items_det.item_idr ) as it_name "
        " from items_det  where id=%s")
    data = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(api.api_ok(data=data))
#====================================================================
@can_access(2008)
def new_RetSupInvDet():
    try :
        data = request.vars
        ret = db.returned_supply[data.returned_supply]
        if not ret:
            return response.json(api.api_error(mess="فاتورة المرتجع غير موجودة"))
        if ret.admin_accept:
            return response.json(api.api_error(mess="لا يمكن تعديل مرتجع معتمد"))
        items_det = db.items_det[data.item_id]
        if not items_det:
            return response.json(api.api_error(mess="الصنف غير موجود"))
        try:
            item_count = float(data.item_count or 0)
        except (TypeError, ValueError):
            item_count = 0
        if item_count <= 0:
            return response.json(api.api_error(mess="الكمية يجب أن تكون أكبر من صفر"))
        # يُسمح بكمية مرتجع أكبر من المتاح عمداً، ليُستخدم المرتجع كأداة تصحيح للكميات.
        total = item_count * float(items_det.buy_price)
        total_2 = item_count * float(items_det.public_price)
        nid = db.returned_supply_det.insert(
                        returned_supply=data.returned_supply  , 
                        item_count = item_count  ,
                        item_id = data.item_id ,
                        vat  =  items_det.vat  , 
                        inv_price = items_det.buy_price ,
                        inv_bay = items_det.public_price ,
                        total = total,
                        total_2 = total_2 ,
                        )
        inserted = db.returned_supply_det[nid]
        db.commit()
        qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply=%s) ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply=%s ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply=%s ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply=%s ) "
            " where id = %s"
        )
        qs = db.executesql(qry, placeholders=[data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply])
        return response.json(api.api_ok(data=_returned_supply_det_payload(inserted)))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@can_access(2008)
def edit_RetSupInvDet():
    try :
        data = request.vars
        q = db.returned_supply[data.returned_supply]
        if q.admin_accept==False :
            edit_row = db.returned_supply_det[data.id]
            items_det = db.items_det[data.item_id]
            if not edit_row:
                return response.json(api.api_error(mess="سطر المرتجع غير موجود"))
            if not items_det:
                return response.json(api.api_error(mess="الصنف غير موجود"))
            try:
                item_count = float(data.item_count or 0)
            except (TypeError, ValueError):
                item_count = 0
            if item_count <= 0:
                return response.json(api.api_error(mess="الكمية يجب أن تكون أكبر من صفر"))
            # يُسمح بكمية مرتجع أكبر من المتاح عمداً، ليُستخدم المرتجع كأداة تصحيح للكميات.
            total = item_count * float(items_det.buy_price)
            total_2 = item_count * float(items_det.public_price)
            #
            edit_row.item_count = item_count
            edit_row.item_name =  db.items_main[items_det.item_idr].name
            edit_row.item_id = data.item_id 
            edit_row.vat  =  items_det.vat  
            edit_row.inv_price = items_det.buy_price 
            edit_row.inv_bay = items_det.public_price 
            edit_row.total = total
            edit_row.total_2 = total_2 
            edit_row.update_record() 
            db.commit()
            qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply=%s) ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply=%s ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply=%s ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply=%s ) "
            " where id = %s"
            )
            qs = db.executesql(qry, placeholders=[data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply])
            return response.json(api.api_ok(data=_returned_supply_det_payload(edit_row)))
        else :
            return response.json(api.api_error(mess='لايمكن الحفظ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@can_access(2008)
def delete_RetSupInvDet():
    try :
        edit_row = db.returned_supply_det[request.args(0)]
        q = db.returned_supply[edit_row.returned_supply]
        q_id = str(q.id)
        if q.admin_accept==False :
            edit_row.delete_record()
            db.commit()
            qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply=%s) ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply=%s ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply=%s ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply=%s ) "
            " where id = %s"
            )
            qs = db.executesql(qry, placeholders=[q_id, q_id, q_id, q_id, q_id])
            return response.json(api.api_ok(mess="تم الحذف"))
        else :
            return response.json(api.api_error(mess='حصل خطأ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))


#================================================================
# ----------------->     suppliers_payment             <=========
#================================================================

@can_access(2107)
def get_payment_type():
    q = db(db.key_payment_type.id > 0).select(db.key_payment_type.id,
                                             db.key_payment_type.name, orderby=[db.key_payment_type.id])
    return response.json(api.api_ok(data=q))


@can_access(2107)
def getSuppPyment():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( note LIKE %s OR CAST(id AS text) LIKE %s OR CAST(supplier AS text) LIKE %s OR CAST(pay_total AS text) LIKE %s OR CAST(pay_date AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier:
        if ((ReqVar.supplier is not None) or (ReqVar.supplier != '')):
            conditions.append("( supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.types and (ReqVar.types != '0'):
        if ((ReqVar.types is not None) or (ReqVar.types != '')):
            conditions.append("( payment_type = %s )")
            params.append(int(ReqVar.types))
    allowed_sort_columns = {'id', 'supplier', 'payment_method', 'payment_type', 'pay_total', 'pay_date', 'note'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'DESC'
    else:
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq2 = "(select name from key_payment_type where id=payment_type) as t_name"
    subq5 = "(select name from key_payment_method where id=payment_method) as m_name"
    sql = (f" SELECT id,supplier, payment_method, payment_type,pay_total,pay_date,note,"
           f" {subq1} ,{subq2},{subq5} FROM suppliers_bills_pay "
           f" {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; ")
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers_bills_pay {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))

#====================================================================
@can_access(2107)
def new_SP():
    try :
        data = request.vars
        errors = []
        bill_date, date_error = _parse_form_day(data.day, "تاريخ السداد")
        if date_error:
            errors.append(date_error)
        supplier_id = _valid_supplier_id(data.supplier)
        if not supplier_id:
            errors.append("المورد مطلوب")
        payment_method = _valid_lookup_id("key_payment_method", data.payment_method)
        if not payment_method:
            errors.append("طريقة الدفع مطلوبة")
        payment_type = _valid_lookup_id("key_payment_type", data.payment_type)
        if not payment_type:
            errors.append("نوع السداد مطلوب")
        try:
            pay_total = float(data.pay_total or 0)
        except (TypeError, ValueError):
            pay_total = 0
        if pay_total <= 0:
            errors.append("مبلغ السداد يجب أن يكون أكبر من صفر")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.suppliers_bills_pay.insert(
                        supplier=supplier_id,
                        payment_method=payment_method,
                        pay_date =  bill_date  , 
                        pay_total=pay_total,
                        note = data.note   ,
                        payment_type=payment_type
                        )
        inserted = db.suppliers_bills_pay[nid]
        inserted.s_name = inserted.supplier.name
        inserted.m_name = inserted.payment_method.name
        inserted.t_name = inserted.payment_type.name
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#------------------------------------------------------------------
@can_access(2107)
def edit_SP():
    try :
        data = request.vars
        row = db.suppliers_bills_pay[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        errors = []
        bill_date, date_error = _parse_form_day(data.day, "تاريخ السداد")
        if date_error:
            errors.append(date_error)
        supplier_id = _valid_supplier_id(data.supplier)
        if not supplier_id:
            errors.append("المورد مطلوب")
        payment_method = _valid_lookup_id("key_payment_method", data.payment_method)
        if not payment_method:
            errors.append("طريقة الدفع مطلوبة")
        payment_type = _valid_lookup_id("key_payment_type", data.payment_type)
        if not payment_type:
            errors.append("نوع السداد مطلوب")
        try:
            pay_total = float(data.pay_total or 0)
        except (TypeError, ValueError):
            pay_total = 0
        if pay_total <= 0:
            errors.append("مبلغ السداد يجب أن يكون أكبر من صفر")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.supplier=supplier_id
        row.payment_method = payment_method
        row.pay_date =  bill_date  
        row.pay_total = pay_total
        row.note = data.note  
        row.payment_type = payment_type
        row.update_record()
        inserted = db.suppliers_bills_pay[data.id]
        inserted.s_name = inserted.supplier.name
        inserted.m_name = inserted.payment_method.name
        inserted.t_name = inserted.payment_type.name
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#================================================================
# ----------------->     opening_balance               <=========
#================================================================

@can_access(2108)
def get_opening_balance():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( CAST(supplier AS text) LIKE %s OR CAST(account AS text) LIKE %s OR CAST(year_balance AS text) LIKE %s OR supplier IN (SELECT id FROM suppliers WHERE name ILIKE %s) )")
            params.extend([pattern, pattern, pattern, pattern])
    if ReqVar.supplier:
        conditions.append("supplier = %s")
        params.append(int(ReqVar.supplier))
    allowed_sort_columns = {'id', 'year_balance', 'supplier', 'account', 'note'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'DESC'
    else:
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    sql = (
            f" SELECT id,year_balance,supplier, account , note,"
            f" (select name from suppliers where id=supplier) as supplier_n "
            f"  FROM suppliers_opening_balance {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; "
    )
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers_opening_balance {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(2108)
def new_o_b():
    try:
        data = request.vars
        errors = []
        try:
            data.supplier = json.loads(data.supplier)
            supplier_id = _valid_supplier_id(data.supplier.get("value"))
        except Exception:
            supplier_id = None
        if not supplier_id:
            errors.append("المورد مطلوب")
        try:
            year_balance = int(data.year_balance)
        except (TypeError, ValueError):
            year_balance = 0
        if year_balance < 2000 or year_balance > 2100:
            errors.append("السنة غير صحيحة")
        try:
            account = float(data.account or 0)
        except (TypeError, ValueError):
            account = None
        if account is None:
            errors.append("الرصيد يجب أن يكون رقماً")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        q = db(
            (db.suppliers_opening_balance.year_balance == year_balance)
            & 
            (db.suppliers_opening_balance.supplier == supplier_id)
            ).select()
        if (q) :
            return response.json(api.api_error(mess="هذا السجل مسجل مسبقا"))
        else :
            nid = db.suppliers_opening_balance.insert(
                supplier=supplier_id,
                year_balance=year_balance,
                account=account,
                note=data.note
            )
            inserted = db.suppliers_opening_balance[nid]
            inserted.supplier_n = inserted.supplier.name
            db.commit()
            return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(2108)
def edit_o_b():
    try:
        data = request.vars
        row = db.suppliers_opening_balance[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        errors = []
        try:
            data.supplier = json.loads(data.supplier)
            supplier_id = _valid_supplier_id(data.supplier.get("value"))
        except Exception:
            supplier_id = None
        if not supplier_id:
            errors.append("المورد مطلوب")
        try:
            year_balance = int(data.year_balance)
        except (TypeError, ValueError):
            year_balance = 0
        if year_balance < 2000 or year_balance > 2100:
            errors.append("السنة غير صحيحة")
        try:
            account = float(data.account or 0)
        except (TypeError, ValueError):
            account = None
        if account is None:
            errors.append("الرصيد يجب أن يكون رقماً")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        if (row.supplier != supplier_id) or (row.year_balance != year_balance):
            q = db(
                (db.suppliers_opening_balance.year_balance == year_balance)
                &
                (db.suppliers_opening_balance.supplier == supplier_id)
            ).select()
            if (q):
                return response.json(api.api_error(mess="هذا السجل مسجل مسبقا"))
        row.supplier = supplier_id
        row.year_balance = year_balance
        row.account = account
        row.note = data.note
        row.update_record()
        row.supplier_n = db.suppliers[supplier_id].name
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


#======================================================================
# ----->      suppliers_balance_reconciliation               <=========
#======================================================================

@can_access(2109)
def get_B_R():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( note LIKE %s OR CAST(id AS text) LIKE %s OR CAST(supplier AS text) LIKE %s OR CAST(balance_date AS text) LIKE %s OR CAST(balance_def AS text) LIKE %s OR supplier IN (SELECT id FROM suppliers WHERE name ILIKE %s) )")
            params.extend([pattern, pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier:
        if ((ReqVar.supplier is not None) and (ReqVar.supplier != '')):
            conditions.append("( supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.types and (ReqVar.types != '0'):
        if ((ReqVar.types is not None) and (ReqVar.types != '')):
            conditions.append("( balance = %s )")
            params.append(int(ReqVar.types))
    allowed_sort_columns = {'id', 'supplier', 'balance_date', 'balance', 'balance_def', 'note'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'DESC'
    else:
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    sql = (f" SELECT id,supplier, balance_date ,balance ,balance_def ,note,"
           f" {subq1}  FROM suppliers_balance_reconciliation "
           f" {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; ")
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers_balance_reconciliation {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))

@can_access(2109)
def new_B_R():
    try :
        data = request.vars
        errors = []
        bill_date, date_error = _parse_form_day(data.day, "تاريخ المطابقة")
        if date_error:
            errors.append(date_error)
        supplier_id = _valid_supplier_id(data.supplier)
        if not supplier_id:
            errors.append("المورد مطلوب")
        try:
            balance = int(data.balance)
        except (TypeError, ValueError):
            balance = 0
        if balance not in (1, 2):
            errors.append("حالة المطابقة غير صحيحة")
        try:
            balance_def = float(data.balance_def or 0)
        except (TypeError, ValueError):
            balance_def = 0
        if balance_def < 0:
            errors.append("فرق المطابقة لا يمكن أن يكون سالباً")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.suppliers_balance_reconciliation.insert(
                        supplier=supplier_id,
                        balance=balance,
                        balance_date =  bill_date  , 
                        balance_def=balance_def,
                        note = data.note   ,
                        )
        inserted = db.suppliers_balance_reconciliation[nid]
        inserted.s_name = inserted.supplier.name
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

@can_access(2109)
def edit_B_R():
    try :
        data = request.vars
        row = db.suppliers_balance_reconciliation[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        errors = []
        bill_date, date_error = _parse_form_day(data.day, "تاريخ المطابقة")
        if date_error:
            errors.append(date_error)
        supplier_id = _valid_supplier_id(data.supplier)
        if not supplier_id:
            errors.append("المورد مطلوب")
        try:
            balance = int(data.balance)
        except (TypeError, ValueError):
            balance = 0
        if balance not in (1, 2):
            errors.append("حالة المطابقة غير صحيحة")
        try:
            balance_def = float(data.balance_def or 0)
        except (TypeError, ValueError):
            balance_def = 0
        if balance_def < 0:
            errors.append("فرق المطابقة لا يمكن أن يكون سالباً")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.supplier=supplier_id
        row.balance_date =  bill_date  
        row.balance = balance
        row.balance_def = balance_def
        row.note = data.note  
        row.update_record()
        db.commit()
        inserted = db.suppliers_balance_reconciliation[data.id]
        inserted.s_name = db.suppliers[supplier_id].name
        #print(row)
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#------------------------------------------------------------------

@can_access(2109)
def is_float(value):
  try:
    float(value)
    return True
  except:
    return False
