# -*- coding: utf-8 -*-
#  type: ignore

#====================================================================
#def get_supp():
#    q  = db(db.suppliers.id>0).select(db.suppliers.id ,db.suppliers.name , db.suppliers.stoped , orderby=[db.suppliers.stoped,db.suppliers.name ])
#    return response.json(q)

# from asyncio.windows_events import NULL
from datetime import datetime
import json
import api_helpers as api


@can_access(2001)
def get_supp():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( name LIKE %s OR tel LIKE %s OR address LIKE %s )")
            params.extend([pattern, pattern, pattern])
    allowed_sort_columns = {'id', 'name', 'tel', 'address', 'stoped', 'note', 'bank_account'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'DESC'
    else :
        sa = 'ASC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    sql = f" SELECT id,name,tel, address ,stoped ,note,bank_account  FROM suppliers {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; "
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers {where} ; "
    params_count = params[:-2]  # exclude LIMIT/OFFSET params
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


#====================================================================
@can_access(2005)
def supply_lock():
    q = db.suppliers[request.args(0)]
    if q.stoped == True :
        q.stoped = False 
    else : 
        q.stoped = True
    q.update_record()
    db.commit()
    return response.json(api.api_ok(mess="تم التحديث"))
#====================================================================
@auth.requires_login()
def get_supp_id():
    q  = db.suppliers[request.args(0)]
    return response.json(api.api_ok(data=q))
#====================================================================
@can_access(2003)
def update_supplier():
    data = request.vars
    row = db.suppliers[data.id]
    row.name = data.name 
    row.bank_account = data.bank_account
    row.note = data.note 
    row.tel = data.tel 
    row.address = data.address
    row.stoped = data.stoped
    row.update_record()
    db.commit()
    return response.json(api.api_ok(data=row))
#====================================================================
#@auth.requires(auth.has_membership('user1') or auth.has_membership('admin') or auth.has_membership('secretarial'))
@can_access(2002)
def new_supplier():
    data = request.vars
    if data.stoped==None :
        data.stoped = False 

    nid = db.suppliers.insert(
                    name=data.name  , 
                    bank_account = data.bank_account ,
                    note =  data.note   , 
                    tel = data.tel , 
                    address = data.address ,
                    stoped = data.stoped  
                    )
    db.commit()
    return response.json(api.api_ok(data={"id":str(nid)}))
#====================================================================
#@auth.requires(auth.has_membership('admin') )
# @can_access(2004)
# def delete_supplier():
#     try :
#         data = request.vars
#         row = db.suppliers[data.id]
#         row.delete_record()
#         db.commit()
#         return 0
#     except Exception :
#         db.rollback()
#         print ( e )
#         return e
#====================================================================
@auth.requires_login()
def get_invoce_type():
    q  = db(db.key_invoce_type.id>0).select(db.key_invoce_type.id ,db.key_invoce_type.name , orderby=[db.key_invoce_type.id ])
    return response.json(api.api_ok(data=q))
#====================================================================
@auth.requires_login()
def getSuppInvoce():
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( sb.bill_no LIKE %s OR CAST(sb.id AS text) LIKE %s OR CAST(sb.bill_total AS text) LIKE %s OR CAST(sb.bill_vat AS text) LIKE %s OR CAST(sb.bill_date AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier :
        if ( (ReqVar.supplier is not None) or (ReqVar.supplier !=''))  :
            conditions.append("( sb.supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.types  and (ReqVar.types != '0' )  :
        if ( (ReqVar.types is not None) or (ReqVar.types !=''))  :
            conditions.append("( sb.invoce_type = %s )")
            params.append(int(ReqVar.types))
    allowed_sort_columns = {'id', 'bill_no', 'bill_date', 'bill_total', 'bill_net_amount', 'bill_vat', 'bill_confirmation', 'return_confirmation', 'supplier', 'payment_method', 'invoce_type'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'DESC'
    else :
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    sql = f"""
        SELECT sb.id, sb.bill_no, sb.bill_date, sb.bill_total, sb.bill_net_amount,
               sb.bill_vat, sb.bill_confirmation, sb.return_confirmation,
               s.name AS s_name,
               kt.name AS t_name,
               COALESCE(itm.itm_count, 0) AS itm_count,
               COALESCE(itm.itm_r_count, 0) AS itm_r_count,
               COALESCE(fc.f_count, 0) AS f_count,
               pm.name AS m_name,
               sb.supplier, sb.payment_method, sb.invoce_type
        FROM suppliers_bills sb
        LEFT JOIN suppliers s ON s.id = sb.supplier
        LEFT JOIN key_invoce_type kt ON kt.id = sb.invoce_type
        LEFT JOIN key_payment_method pm ON pm.id = sb.payment_method
        LEFT JOIN (
            SELECT supplier_inv,
                   COUNT(*) AS itm_count,
                   COUNT(*) FILTER (WHERE return_count > 0) AS itm_r_count
            FROM items_det GROUP BY supplier_inv
        ) itm ON itm.supplier_inv = sb.id
        LEFT JOIN (
            SELECT suppliers_bills_id, COUNT(*) AS f_count
            FROM suppliers_bills_files GROUP BY suppliers_bills_id
        ) fc ON fc.suppliers_bills_id = sb.id
        {where} ORDER BY sb.{sc} {sa} LIMIT %s OFFSET %s
    """
    params_count = list(params)  # copy for count query (without LIMIT/OFFSET)
    params.extend([rc, pg])
    sql2 = f"SELECT count(*) FROM suppliers_bills sb {where}"
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))
#====================================================================
@can_access(2010)
def new_bill():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        bill_net_amount = round((float(data.bill_total) - float(data.bill_vat)) , 2)
        nid = db.suppliers_bills.insert(
                        supplier=data.suppliers['value']  , 
                        payment_method = data.payment_method ,
                        bill_no =  data.bill_no   , 
                        bill_date =  bill_date  , 
                        bill_total = data.bill_total ,
                        bill_vat = data.bill_vat   ,
                        bill_net_amount = bill_net_amount  ,
                        invoce_type = data.invoce_type
                        )
        inserted = db.suppliers_bills[nid]
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@can_access(2010)
def edit_bill():
    try :
        data = request.vars
        q = db.suppliers_bills[data.id]
        if q.bill_confirmation==False :
            data.day = json.loads(data.day)
            suppliers = json.loads(data.suppliers)
            bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
            bill_net_amount = round((float(data.bill_total) - float(data.bill_vat)) , 2)
            q.supplier = suppliers['value']
            q.payment_method = int(data.payment_method) 
            q.bill_no =  data.bill_no   
            q.bill_date =  bill_date  
            q.bill_total = float(data.bill_total) 
            q.bill_vat = float(data.bill_vat)   
            q.bill_net_amount = float(bill_net_amount)  
            q.invoce_type = data.invoce_type
            q.update_record()
            db.commit()
            return response.json(api.api_ok(data=q))
        else :
            return response.json(api.api_error(mess='لايمكن الحفظ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#================================================================
# ----------------->  returned_supply                  <=========
#================================================================
@auth.requires_login()
def getRetSuppInvoce():
    ReqVar = request.vars
    if ReqVar.page :
        pg = ReqVar.page
    else :
        pg = 0
    if ReqVar.RecordCount :
        rc = ReqVar.RecordCount
    else :
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText!='' :
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( name LIKE %s OR CAST(id AS text) LIKE %s OR CAST(total AS text) LIKE %s OR CAST(item_count AS text) LIKE %s OR CAST(ret_date AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier :
        if ( (ReqVar.supplier is not None) or (ReqVar.supplier !=''))  :
            conditions.append("( supplier = %s )")
            params.append(int(ReqVar.supplier))
    allowed_sort_columns = {'id', 'name', 'supplier', 'ret_date', 'real_total', 'admin_accept', 'item_count'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else :
        sc = 'id'
    if ReqVar.sequence :
        if ReqVar.sequence =='true' :
            sa = 'ASC'
        else:
            sa = 'DESC'
    else :
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq3 = "(select count(*) from returned_supply_det where returned_supply=returned_supply.id) as itm_count"
    subq4 = "(select sum(item_count) from returned_supply_det where returned_supply=returned_supply.id ) as itm_r_count"
    sql = ( f" SELECT id,name ,supplier ,ret_date ,round(CAST(real_total AS decimal ) ,2) as real_total , admin_accept,"
            f" {subq1} ,{subq3},{subq4} FROM returned_supply "
            f" {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; ")
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM returned_supply {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))
#====================================================================
@auth.requires_login()
def new_RetSupInv():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        nid = db.returned_supply.insert(
                        supplier=data.suppliers['value']  , 
                        name = data.name ,
                        ret_date =  bill_date  , 
                        admin_accept = False 
                        )
        inserted = db.returned_supply[nid]
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@auth.requires_login()
def edit_RetSupInv():
    try :
        data = request.vars
        q = db.returned_supply[data.id]
        if q.admin_accept==False :
            data.day = json.loads(data.day)
            suppliers = json.loads(data.suppliers)
            ret_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
            q.supplier = suppliers['value']
            q.ret_date =  ret_date  
            q.name = data.name
            q.update_record()
            db.commit()
            return response.json(api.api_ok(data=q))
        else :
            return response.json(api.api_error(mess='لايمكن الحفظ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#================================================================
# ----------------->  returned_supply detail           <=========
#================================================================
@auth.requires_login()
def getRetSuppInvoceDet():
    qry = db(db.returned_supply_det.returned_supply==request.args(0) ).select()
    return response.json(api.api_ok(data=qry))
#====================================================================
@auth.requires_login()
def getit():
    qry = ("select id as item_id ,item_idr,supplier_inv ,expiration_date ,buy_price ,vat ,vat_in_public_price, "
        " ( select name from suppliers where suppliers.id=(select supplier  from suppliers_bills where suppliers_bills.id=supplier_inv)) as s_name , "
        " ( select name from items_main where items_main.id= items_det.item_idr ) as it_name "
        " from items_det  where id=%s")
    data = db.executesql(qry, placeholders=[request.args(0)], as_dict=True)
    return response.json(api.api_ok(data=data))
#====================================================================
@auth.requires_login()
def new_RetSupInvDet():
    try :
        data = request.vars
        items_det = db.items_det[data.item_id]
        total = float(data.item_count) * float(items_det.buy_price)
        total_2 = float(data.item_count) * float(items_det.public_price)
        nid = db.returned_supply_det.insert(
                        returned_supply=data.returned_supply  , 
                        item_count = data.item_count  ,
                        item_id = data.item_id ,
                        vat  =  items_det.vat  , 
                        inv_price = items_det.buy_price ,
                        inv_bay = items_det.public_price ,
                        total = total,
                        total_2 = total_2 ,
                        )
        inserted = db.returned_supply_det[nid]
        db.commit()
        qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply=%s) ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply=%s ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply=%s ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply=%s ) "
            " where id = %s"
        )
        qs = db.executesql(qry, placeholders=[data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply])
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@auth.requires_login()
def edit_RetSupInvDet():
    try :
        data = request.vars
        q = db.returned_supply[data.returned_supply]
        if q.admin_accept==False :
            edit_row = db.returned_supply_det[data.id]
            items_det = db.items_det[data.item_id]
            total = float(data.item_count) * float(items_det.buy_price)
            total_2 = float(data.item_count) * float(items_det.public_price)
            #
            edit_row.item_count = data.item_count  
            edit_row.item_name =  db.items_main[items_det.item_idr].name
            edit_row.item_id = data.item_id 
            edit_row.vat  =  items_det.vat  
            edit_row.inv_price = items_det.buy_price 
            edit_row.inv_bay = items_det.public_price 
            edit_row.total = total
            edit_row.total_2 = total_2 
            edit_row.update_record() 
            db.commit()
            qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply=%s) ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply=%s ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply=%s ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply=%s ) "
            " where id = %s"
            )
            qs = db.executesql(qry, placeholders=[data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply, data.returned_supply])
            return response.json(api.api_ok(data=edit_row))
        else :
            return response.json(api.api_error(mess='لايمكن الحفظ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#====================================================================
@auth.requires_login()
def delete_RetSupInvDet():
    try :
        edit_row = db.returned_supply_det[request.args(0)]
        q = db.returned_supply[edit_row.returned_supply]
        q_id = str(q.id)
        if q.admin_accept==False :
            edit_row.delete_record()
            db.commit()
            qry = ("update returned_supply set  item_count= (select count(*) from returned_supply_det where returned_supply=%s) ,"
            " item_sum=(select sum(item_count) from returned_supply_det where returned_supply=%s ) ,"
            " real_total =(select sum(total) from returned_supply_det where returned_supply=%s ) , "
            " real_total2 =(select sum(total_2) from returned_supply_det where returned_supply=%s ) "
            " where id = %s"
            )
            qs = db.executesql(qry, placeholders=[q_id, q_id, q_id, q_id, q_id])
            return response.json(api.api_ok(mess="تم الحذف"))
        else :
            return response.json(api.api_error(mess='حصل خطأ'))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))


#================================================================
# ----------------->     suppliers_payment             <=========
#================================================================

@auth.requires_login()
def get_payment_type():
    q = db(db.key_payment_type.id > 0).select(db.key_payment_type.id,
                                             db.key_payment_type.name, orderby=[db.key_payment_type.id])
    return response.json(api.api_ok(data=q))


@auth.requires_login()
def getSuppPyment():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( note LIKE %s OR CAST(id AS text) LIKE %s OR CAST(supplier AS text) LIKE %s OR CAST(pay_total AS text) LIKE %s OR CAST(pay_date AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier:
        if ((ReqVar.supplier is not None) or (ReqVar.supplier != '')):
            conditions.append("( supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.types and (ReqVar.types != '0'):
        if ((ReqVar.types is not None) or (ReqVar.types != '')):
            conditions.append("( payment_type = %s )")
            params.append(int(ReqVar.types))
    allowed_sort_columns = {'id', 'supplier', 'payment_method', 'payment_type', 'pay_total', 'pay_date', 'note'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'DESC'
    else:
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    subq2 = "(select name from key_payment_type where id=payment_type) as t_name"
    subq5 = "(select name from key_payment_method where id=payment_method) as m_name"
    sql = (f" SELECT id,supplier, payment_method, payment_type,pay_total,pay_date,note,"
           f" {subq1} ,{subq2},{subq5} FROM suppliers_bills_pay "
           f" {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; ")
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers_bills_pay {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))

#====================================================================
@auth.requires_login()
def new_SP():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        nid = db.suppliers_bills_pay.insert(
                        supplier=data.supplier , 
                        payment_method = data.payment_method ,
                        pay_date =  bill_date  , 
                        pay_total = data.pay_total ,
                        note = data.note   ,
                        payment_type = data.payment_type
                        )
        inserted = db.suppliers_bills_pay[nid]
        inserted.s_name = inserted.supplier.name
        inserted.m_name = inserted.payment_method.name
        inserted.t_name = inserted.payment_type.name
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))
#------------------------------------------------------------------
@auth.requires_login()
def edit_SP():
    try :
        data = request.vars
        row = db.suppliers_bills_pay[data.id]
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        row.supplier=data.supplier 
        row.payment_method = data.payment_method
        row.pay_date =  bill_date  
        row.pay_total = data.pay_total
        row.note = data.note  
        row.payment_type = data.payment_type
        row.update_record()
        inserted = db.suppliers_bills_pay[data.id]
        inserted.s_name = inserted.supplier.name
        inserted.m_name = inserted.payment_method.name
        inserted.t_name = inserted.payment_type.name
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#================================================================
# ----------------->     opening_balance               <=========
#================================================================

@auth.requires_login()
def get_opening_balance():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( CAST(supplier AS text) LIKE %s OR CAST(account AS text) LIKE %s OR CAST(year_balance AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern])
    allowed_sort_columns = {'id', 'year_balance', 'supplier', 'account', 'note'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'DESC'
    else:
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    sql = (
            f" SELECT id,year_balance,supplier, account , note,"
            f" (select name from suppliers where id=supplier) as supplier_n "
            f"  FROM suppliers_opening_balance {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; "
    )
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers_opening_balance {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@auth.requires_login()
def new_o_b():
    try:
        data = request.vars
        data.supplier = json.loads(data.supplier)
        q = db(
            (db.suppliers_opening_balance.year_balance == data.year_balance) 
            & 
            (db.suppliers_opening_balance.supplier == data.supplier['value'])
            ).select()
        if (q) :
            return response.json(api.api_error(mess="هذا السجل مسجل مسبقا"))
        else :
            nid = db.suppliers_opening_balance.insert(
                supplier=data.supplier['value'],
                year_balance=data.year_balance,
                account=data.account,
                note=data.note
            )
            inserted = db.suppliers_opening_balance[nid]
            inserted.supplier_n = inserted.supplier.name
            db.commit()
            return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def edit_o_b():
    try:
        data = request.vars
        data.supplier = json.loads(data.supplier)
        row = db.suppliers_opening_balance[data.id]
        if (row.supplier != int(data.supplier['value'])) or (row.year_balance != int(data.year_balance)):
            q = db(
                (db.suppliers_opening_balance.year_balance == data.year_balance)
                &
                (db.suppliers_opening_balance.supplier == data.supplier['value'])
            ).select()
            if (q):
                return response.json(api.api_error(mess="هذا السجل مسجل مسبقا"))
        row.supplier = data.supplier['value']
        row.year_balance = data.year_balance
        row.account = data.account
        row.note = data.note
        row.update_record()
        row.supplier_n = db.suppliers[data.supplier['value']].name
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


#======================================================================
# ----->      suppliers_balance_reconciliation               <=========
#======================================================================

@auth.requires_login()
def get_B_R():
    ReqVar = request.vars
    if ReqVar.page:
        pg = ReqVar.page
    else:
        pg = 0
    if ReqVar.RecordCount:
        rc = ReqVar.RecordCount
    else:
        rc = 20
    conditions = []
    params = []
    if ReqVar.SearchText and ReqVar.SearchText != '':
        st = ReqVar.SearchText
        srt = st.split()
        for i in range(len(srt)):
            pattern = '%' + srt[i] + '%'
            conditions.append("( note LIKE %s OR CAST(id AS text) LIKE %s OR CAST(supplier AS text) LIKE %s OR CAST(balance_date AS text) LIKE %s OR CAST(balance_def AS text) LIKE %s )")
            params.extend([pattern, pattern, pattern, pattern, pattern])
    if ReqVar.supplier:
        if ((ReqVar.supplier is not None) or (ReqVar.supplier != '')):
            conditions.append("( supplier = %s )")
            params.append(int(ReqVar.supplier))
    if ReqVar.types and (ReqVar.types != '0'):
        if ((ReqVar.types is not None) or (ReqVar.types != '')):
            conditions.append("( balance = %s )")
            params.append(int(ReqVar.types))
    allowed_sort_columns = {'id', 'supplier', 'balance_date', 'balance', 'balance_def', 'note'}
    if ReqVar.SortBy and ReqVar.SortBy in allowed_sort_columns:
        sc = ReqVar.SortBy
    else:
        sc = 'id'
    if ReqVar.sequence:
        if ReqVar.sequence == 'true':
            sa = 'ASC'
        else:
            sa = 'DESC'
    else:
        sa = 'DESC'
    pg = int(int(pg) * int(rc))
    rc = int(rc)
    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)
    subq1 = "(select name from suppliers where id=supplier) as s_name"
    sql = (f" SELECT id,supplier, balance_date ,balance ,balance_def ,note,"
           f" {subq1}  FROM suppliers_balance_reconciliation "
           f" {where} ORDER BY {sc} {sa} LIMIT %s OFFSET %s ; ")
    params_count = list(params)
    params.extend([rc, pg])
    sql2 = f" SELECT count(*) FROM suppliers_balance_reconciliation {where} ; "
    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))

@auth.requires_login()
def new_B_R():
    try :
        data = request.vars
        data.day = json.loads(data.day)
        data.suppliers = json.loads(data.suppliers)
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        nid = db.suppliers_balance_reconciliation.insert(
                        supplier=data.supplier , 
                        balance = data.balance ,
                        balance_date =  bill_date  , 
                        balance_def = data.balance_def ,
                        note = data.note   ,
                        )
        inserted = db.suppliers_balance_reconciliation[nid]
        inserted.s_name = inserted.supplier.name
        db.commit()
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

@auth.requires_login()
def edit_B_R():
    try :
        data = request.vars
        row = db.suppliers_balance_reconciliation[data.id]
        data.day = json.loads(data.day)
        #data.suppliers = json.loads(data.suppliers)
        if is_float(data.balance_def) == False :
            data.balance_def = 0 
        bill_date = datetime(int(data['day']['year']) , int(data['day']['month']) , int(data['day']['day']) , 0, 0)
        row.supplier=data.supplier 
        row.payment_method = data.payment_method
        row.balance_date =  bill_date  
        row.balance = data.balance
        row.balance_def = data.balance_def or 0
        row.note = data.note  
        row.update_record()
        db.commit()
        inserted = db.suppliers_balance_reconciliation[data.id]
        inserted.s_name = db.suppliers[data.supplier].name
        #print(row)
        return response.json(api.api_ok(data=inserted))
    except Exception as e:
        db.rollback()
        print ( e )
        return response.json(api.api_error(mess=e))

#------------------------------------------------------------------

@auth.requires_login()
def is_float(value):
  try:
    float(value)
    return True
  except:
    return False
