# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
import send_sms as sms
import api_helpers as api
import re


def _clean_text(value):
    return (value or "").strip()


def _validate_customer_payload(data, row_id=None):
    name = _clean_text(data.name)
    mobile = _clean_text(data.mobile)
    address = _clean_text(data.address)
    try:
        cust_type = int(data.cust_type or 0)
    except (TypeError, ValueError):
        cust_type = 0

    errors = []
    if not name:
        errors.append("اسم العميل مطلوب")
    if not re.match(r"^05\d{8}$", mobile):
        errors.append("رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05")

    duplicate_query = db.customers.mobile == mobile
    if row_id:
        duplicate_query &= db.customers.id != row_id
    if mobile and db(duplicate_query).select(db.customers.id, limitby=(0, 1)).first():
        errors.append("يوجد هذا الرقم مسجل مسبقا")

    return errors, {
        "name": name.lower(),
        "mobile": mobile,
        "address": address,
        "cust_type": cust_type,
    }

@can_access(1001)
def get_customers():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)
    ut = int(ReqVar.userType    or 0)

    allowed_sort = {'id', 'name', 'mobile', 'cust_type'}
    sort_col = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    conditions = []
    params      = []

    # بحث نصي — parameterized (لا SQL injection)
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append("(c.name LIKE %s OR c.mobile LIKE %s)")
            params.extend([pattern, pattern])

    # فلتر نوع العميل — إصلاح: كان يضيف WHERE بعد WHERE مما ينتج SQL مكسور
    if ut != 0:
        conditions.append("c.cust_type = %s")
        params.append(ut)

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف × 2
    data_sql = f"""
        SELECT
            c.id, c.name, c.mobile, c.address, c.cust_type,
            CASE WHEN c.cust_type = 10 THEN 'دعم الجمعية' ELSE 'عام' END AS cust_type_name,
            COALESCE(inv.total, 0) AS cus_inv,
            COALESCE(pay.total, 0) AS cus_pay
        FROM customers c
        LEFT JOIN (
            SELECT customer, SUM(total_after_discount) AS total
            FROM   invoice_master
            WHERE  payment_method = 3
            GROUP BY customer
        ) inv ON inv.customer = c.id
        LEFT JOIN (
            SELECT customers_id, SUM(amount) AS total
            FROM   customers_pay
            GROUP BY customers_id
        ) pay ON pay.customers_id = c.id
        {where}
        ORDER BY c.{sort_col} {sa}
        LIMIT {rc} OFFSET {offset}
    """
    count_sql = f"SELECT COUNT(*) FROM customers c {where}"

    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(1001)
def new_customer():
    try:
        data = request.vars
        errors, clean_data = _validate_customer_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.customers.validate_and_insert(**clean_data)
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        db.commit()
        return response.json(api.api_ok(data=nid))
    except Exception as e :
        print(e)
        db.rollback()
        return response.json(api.api_error(mess=e))

@can_access(1001)
def edit_customer():
    try:
        data = request.vars
        row = db.customers[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        errors, clean_data = _validate_customer_payload(data, row_id=row.id)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.update_record(**clean_data)
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e :
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1001)
def get_fast_data():
    try:
        #
        qry1 = db(
                db.customers_pay.customers_id ==  request.args(0) 
            ).select(
                orderby= ~db.customers_pay.id  ,
                limitby= (0,10) ,
            )
        qry2 = db(
                db.invoice_master.customer ==  request.args(0) 
            ).select(
                orderby= ~db.invoice_master.id  ,
                limitby= (0,10) ,
            )
        for q2 in qry2:
            q2["payment_method"] = q2.payment_method.name

        return response.json(api.api_ok(data={"in": qry1, "out": qry2}))
    except Exception as e :
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1003)
def save_coust_pay():
    try:
        data = request.vars
        # print(data)
        now_date = request.now.strftime("%Y-%m-%d")
        nid = db.customers_pay.validate_and_insert(
            customers_id=data.coust,
            amount=data.mount,
            customers_pay_data=now_date,
            note=data.note,
            pay_note=data.pay_note,
            pay_type=data.type,
        )
        if nid["errors"]:
            return response.json(api.api_error(mess=str(nid.errors)))
        db.commit()
        # ==========================
        costmer = db.customers[data.coust]
        data_sms = "" 
        if data.type=="10" :
            data_sms = "دعم الجمعية الخيرية \r\n "
        else :
            data_sms = " سداد نقدي \r\n "
        if costmer.mobile:
            if len(costmer.mobile) == 10:
                configuration = db(db.important_info.id > 0).select().first()
                p = sms.SMS(sms_authorization, sms_sender)
                ms = (
                    "تم اضافة "
                    + data.mount
                    + " ريال "
                    + " الى حسابك "
                    + " \r\n "
                    + data_sms
                    + data.pay_note
                    + " \r\n "
                    + configuration.name
                )
                re_ms = p.send("+966" + costmer.mobile[1:], ms)
                nid["sms"] = re_ms
        # ==========================
        return response.json(api.api_ok(data=nid))
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1003)
def get_customers_pay():
    customer_id = int(request.vars.customer_id or 0)
    if not customer_id:
        return response.json(api.api_error(mess="معرف العميل مطلوب"))

    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 15)
    offset = pg * rc

    data_sql = """
        SELECT id, amount, pay_note, pay_type, created_on
        FROM customers_pay
        WHERE customers_id = %s
        ORDER BY id DESC
        LIMIT %s OFFSET %s
    """
    count_sql = "SELECT COUNT(*) FROM customers_pay WHERE customers_id = %s"
    total_sql = "SELECT COALESCE(SUM(amount), 0) FROM customers_pay WHERE customers_id = %s"

    rows = db.executesql(data_sql, placeholders=[customer_id, rc, offset], as_dict=True)
    count = db.executesql(count_sql, placeholders=[customer_id])[0][0]
    total = db.executesql(total_sql, placeholders=[customer_id])[0][0]

    return response.json(api.api_list(rows=rows, count=count, total_amount=float(total or 0)))


@can_access(1003)
def edit_customers_pay():
    try:
        data = request.vars
        row = db.customers_pay[int(data.id)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.update_record(
            amount=data.amount,
            pay_note=data.pay_note,
            pay_type=int(data.pay_type or 0),
        )
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@can_access(1003)
def delete_customers_pay():
    try:
        pay_id = int(request.vars.id or 0)
        row = db.customers_pay[pay_id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
