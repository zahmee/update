# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
import send_sms as sms
import api_helpers as api
import math
import re


def _clean_text(value):
    return (value or "").strip()


def _money(value):
    """مبلغ من الطلب مقرّباً لخانتين، أو None إن لم يكن رقماً صالحاً."""
    try:
        amount = round(float(value), 2)
    except (TypeError, ValueError):
        return None
    return amount if math.isfinite(amount) else None


def _customer_balance(customer_id):
    """رصيد العميل بمعادلة شاشة العملاء نفسها: الآجل ناقص كل قيود customers_pay."""
    rows = db.executesql(
        """
        SELECT ROUND((
            COALESCE((SELECT SUM(total_after_discount) FROM invoice_master
                       WHERE payment_method = 3 AND customer = %s), 0)
          - COALESCE((SELECT SUM(amount) FROM customers_pay WHERE customers_id = %s), 0)
        )::numeric, 2)::float8
        """,
        placeholders=[customer_id, customer_id],
    )
    return float(rows[0][0] or 0)


def _validate_customer_payload(data, row_id=None):
    name = _clean_text(data.name)
    mobile = _clean_text(data.mobile)
    address = _clean_text(data.address)
    try:
        cust_type = int(data.cust_type or 0)
    except (TypeError, ValueError):
        cust_type = 0

    errors = []
    if not name:
        errors.append("اسم العميل مطلوب")
    if not re.match(r"^05\d{8}$", mobile):
        errors.append("رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05")

    duplicate_query = db.customers.mobile == mobile
    if row_id:
        duplicate_query &= db.customers.id != row_id
    if mobile and db(duplicate_query).select(db.customers.id, limitby=(0, 1)).first():
        errors.append("يوجد هذا الرقم مسجل مسبقا")

    return errors, {
        "name": name.lower(),
        "mobile": mobile,
        "address": address,
        "cust_type": cust_type,
    }

@can_access(1001)
def get_customers():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)
    ut = int(ReqVar.userType    or 0)

    allowed_sort = {'id', 'name', 'mobile', 'cust_type', 'bal'}
    sort_col = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'
    # حالة الرصيد: عليه مديونية / له رصيد (سالب) / صفر
    bal_filters = {'debit': 'bal > 0', 'credit': 'bal < 0', 'zero': 'bal = 0'}
    bal_where = bal_filters.get(ReqVar.balState or '')

    conditions = []
    params      = []

    # بحث نصي — parameterized (لا SQL injection)
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append("(c.name LIKE %s OR c.mobile LIKE %s)")
            params.extend([pattern, pattern])

    # فلتر نوع العميل — إصلاح: كان يضيف WHERE بعد WHERE مما ينتج SQL مكسور
    if ut != 0:
        conditions.append("c.cust_type = %s")
        params.append(ut)

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف × 2
    base_sql = f"""
        WITH b AS (
            SELECT
                c.id, c.name, c.mobile, c.address, c.cust_type,
                CASE WHEN c.cust_type = 10 THEN 'دعم الجمعية' ELSE 'عام' END AS cust_type_name,
                COALESCE(inv.total, 0) AS cus_inv,
                COALESCE(pay.total, 0) AS cus_pay,
                ROUND((COALESCE(inv.total, 0) - COALESCE(pay.total, 0))::numeric, 2)::float8 AS bal
            FROM customers c
            LEFT JOIN (
                SELECT customer, SUM(total_after_discount) AS total
                FROM   invoice_master
                WHERE  payment_method = 3
                GROUP BY customer
            ) inv ON inv.customer = c.id
            LEFT JOIN (
                SELECT customers_id, SUM(amount) AS total
                FROM   customers_pay
                GROUP BY customers_id
            ) pay ON pay.customers_id = c.id
            {where}
        )
    """
    bal_clause = f"WHERE {bal_where}" if bal_where else ""
    data_sql = base_sql + f"""
        SELECT * FROM b {bal_clause}
        ORDER BY {sort_col} {sa}, id
        LIMIT {rc} OFFSET {offset}
    """
    if bal_where:
        count_sql = base_sql + f"SELECT COUNT(*) FROM b {bal_clause}"
    else:
        count_sql = f"SELECT COUNT(*) FROM customers c {where}"

    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(1001)
def new_customer():
    try:
        data = request.vars
        errors, clean_data = _validate_customer_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.customers.validate_and_insert(**clean_data)
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        db.commit()
        return response.json(api.api_ok(data=nid))
    except Exception as e :
        print(e)
        db.rollback()
        return response.json(api.api_error(mess=e))

@can_access(1001)
def edit_customer():
    try:
        data = request.vars
        row = db.customers[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        errors, clean_data = _validate_customer_payload(data, row_id=row.id)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.update_record(**clean_data)
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e :
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1001)
def get_fast_data():
    try:
        #
        qry1 = db(
                db.customers_pay.customers_id ==  request.args(0) 
            ).select(
                orderby= ~db.customers_pay.id  ,
                limitby= (0,10) ,
            )
        qry2 = db(
                db.invoice_master.customer ==  request.args(0) 
            ).select(
                orderby= ~db.invoice_master.id  ,
                limitby= (0,10) ,
            )
        for q2 in qry2:
            q2["payment_method"] = q2.payment_method.name

        return response.json(api.api_ok(data={"in": qry1, "out": qry2}))
    except Exception as e :
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1003)
def save_coust_pay():
    try:
        data = request.vars
        if str(data.coust) == "1":
            return response.json(api.api_error(
                mess="لا يمكن تسجيل سداد للعميل النقدي الافتراضي"))
        # التسوية لا تدخل في إقفال الوردية، فلا يُقبل نوعها (ولا نوع مجهول) من شاشة السداد
        try:
            pay_type = int(data.type or 0)
        except (TypeError, ValueError):
            pay_type = None
        if pay_type not in CUSTOMER_PAY_ENTRY_TYPES:
            return response.json(api.api_error(mess="نوع السداد غير صحيح"))
        now_date = request.now.strftime("%Y-%m-%d")
        nid = db.customers_pay.validate_and_insert(
            customers_id=data.coust,
            amount=data.mount,
            customers_pay_data=now_date,
            note=data.note,
            pay_note=data.pay_note,
            pay_type=pay_type,
        )
        if nid["errors"]:
            return response.json(api.api_error(mess=str(nid.errors)))
        db.commit()
        # === الدفعة محفوظة الآن. إرسال SMS معزول حتى لا يُفشل الدفعة المحفوظة ===
        # الرسالة اختيارية من الشاشة (مفعّلة افتراضياً)؛ غياب send_sms يعني الإرسال كما كان
        send_sms = str(data.send_sms if data.send_sms is not None else "1").strip().lower() in (
            "1", "true", "on", "yes")
        sms_status = "off"
        if send_sms:
            sms_status = "no_mobile"
            try:
                costmer = db.customers[data.coust]
                if costmer and costmer.mobile and len(costmer.mobile) == 10:
                    data_sms = "دعم الجمعية الخيرية \r\n " if pay_type == CUSTOMER_PAY_CHARITY else " سداد نقدي \r\n "
                    configuration = db(db.important_info.id > 0).select().first()
                    p = sms.SMS(sms_authorization, sms_sender)
                    ms = (
                        "تم اضافة "
                        + str(data.mount)
                        + " ريال "
                        + " الى حسابك "
                        + " \r\n "
                        + data_sms
                        + str(data.pay_note or "")
                        + " \r\n "
                        + configuration.name
                    )
                    nid["sms"] = p.send("+966" + costmer.mobile[1:], ms)
                    sms_status = "sent"
            except Exception:
                sms_status = "failed"  # فشل الرسالة لا يُلغي الدفعة المحفوظة
        mess = {
            "sent": "تم حفظ السداد وإرسال رسالة للعميل",
            "off": "تم حفظ السداد دون إرسال رسالة",
            "no_mobile": "تم حفظ السداد، ولم تُرسل رسالة لعدم وجود رقم جوال صالح",
            "failed": "تم حفظ السداد، لكن تعذّر إرسال الرسالة",
        }[sms_status]
        return response.json(api.api_ok(data=nid, mess=mess, sms_status=sms_status))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1003)
def get_customers_pay():
    customer_id = int(request.vars.customer_id or 0)
    if not customer_id:
        return response.json(api.api_error(mess="معرف العميل مطلوب"))

    pg = max(int(request.vars.page or 0), 0)
    rc = min(max(int(request.vars.RecordCount or 15), 1), 100)
    offset = pg * rc

    # فلتر النوع؛ «نقدي» يشمل السجلات القديمة بلا نوع (NULL)
    conditions = ["cp.customers_id = %s"]
    params = [customer_id]
    kind = request.vars.kind or ""
    if kind == "cash":
        conditions.append("COALESCE(cp.pay_type, 0) NOT IN (%s, %s)")
        params += [CUSTOMER_PAY_CHARITY, CUSTOMER_PAY_ADJUST]
    elif kind == "charity":
        conditions.append("cp.pay_type = %s")
        params.append(CUSTOMER_PAY_CHARITY)
    elif kind == "adjust":
        conditions.append("cp.pay_type = %s")
        params.append(CUSTOMER_PAY_ADJUST)
    where = " AND ".join(conditions)

    data_sql = f"""
        SELECT cp.id, cp.amount, cp.pay_note, cp.note, cp.pay_type, cp.created_on,
               TRIM(COALESCE(au.first_name, '') || ' ' || COALESCE(au.last_name, '')) AS user_name
        FROM customers_pay cp
        LEFT JOIN auth_user au ON au.id = cp.created_by
        WHERE {where}
        ORDER BY cp.id DESC
        LIMIT %s OFFSET %s
    """
    count_sql = f"SELECT COUNT(*) FROM customers_pay cp WHERE {where}"
    # مجاميع العميل كله (لا يغيّرها الفلتر). التسويات منفصلة: «إجمالي المسدد» نقد ودعم فعلي
    stats_sql = """
        SELECT COALESCE(SUM(amount) FILTER (WHERE COALESCE(pay_type, 0) <> %s), 0),
               COALESCE(SUM(amount) FILTER (WHERE pay_type = %s), 0),
               COUNT(*),
               COUNT(*) FILTER (WHERE COALESCE(pay_type, 0) NOT IN (%s, %s)),
               COUNT(*) FILTER (WHERE pay_type = %s),
               COUNT(*) FILTER (WHERE pay_type = %s)
        FROM customers_pay WHERE customers_id = %s
    """
    credit_sql = """
        SELECT COALESCE(SUM(total_after_discount), 0) FROM invoice_master
        WHERE payment_method = 3 AND customer = %s
    """

    rows = db.executesql(data_sql, placeholders=params + [rc, offset], as_dict=True)
    count = db.executesql(count_sql, placeholders=params)[0][0]
    total, adjust, n_all, n_cash, n_charity, n_adjust = db.executesql(stats_sql, placeholders=[
        CUSTOMER_PAY_ADJUST, CUSTOMER_PAY_ADJUST,
        CUSTOMER_PAY_CHARITY, CUSTOMER_PAY_ADJUST, CUSTOMER_PAY_CHARITY, CUSTOMER_PAY_ADJUST,
        customer_id])[0]
    credit = float(db.executesql(credit_sql, placeholders=[customer_id])[0][0] or 0)
    total, adjust = float(total or 0), float(adjust or 0)

    return response.json(api.api_list(
        rows=rows, count=count,
        total_amount=total, adjust_amount=adjust, credit_total=credit,
        balance=round(credit - total - adjust, 2),
        counts={"all": n_all, "cash": n_cash, "charity": n_charity, "adjust": n_adjust}))


@can_access(1003)
def edit_customers_pay():
    try:
        data = request.vars
        row = db.customers_pay[int(data.id)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.pay_type == CUSTOMER_PAY_ADJUST:
            return response.json(api.api_error(
                mess="قيد التسوية لا يُعدَّل. احذفه ثم سجّل تسوية جديدة"))
        try:
            pay_type = int(data.pay_type or 0)
        except (TypeError, ValueError):
            pay_type = None
        if pay_type not in CUSTOMER_PAY_ENTRY_TYPES:
            return response.json(api.api_error(mess="نوع السداد غير صحيح"))
        amount = _money(data.amount)
        if amount is None or amount <= 0 or amount > 100000:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        row.update_record(
            amount=amount,
            pay_note=data.pay_note,
            pay_type=pay_type,
        )
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@can_access(1003)
def delete_customers_pay():
    try:
        pay_id = int(request.vars.id or 0)
        row = db.customers_pay[pay_id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.pay_type == CUSTOMER_PAY_ADJUST and not auth.has_membership("admin"):
            return response.json(api.api_error(mess="حذف قيد التسوية للمدير فقط"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


# ============================ تسوية أرصدة العملاء ============================
# الرصيد لا يُصفَّر بحذف السدادات أو تعديلها؛ تُسجَّل له تسوية مستقلة (pay_type=20)
# بسبب مكتوب، فيبقى كشف العميل مفهوماً. المدير فقط، وPOST فقط.

SMALL_CREDIT_MAX = 50  # أعلى حد للتسوية الجماعية؛ ما فوقه يُسوّى عميلاً عميلاً
SMALL_CREDIT_LOCK_KEY = 918273646  # قفل استشاري يمنع تسويتين جماعيتين متزامنتين


def _adjust_reason(value):
    """سبب التسوية بعد التنظيف، أو رسالة خطأ. الحقل pay_note طوله 100."""
    reason = _clean_text(value)
    if len(reason) < 3:
        return None, "سبب التسوية مطلوب"
    if len(reason) > 100:
        return None, "سبب التسوية أطول من 100 حرف"
    return reason, None


def _insert_adjustment(customer_id, amount, reason):
    return db.customers_pay.insert(
        customers_id=customer_id,
        amount=amount,
        customers_pay_data=request.now.strftime("%Y-%m-%d"),
        pay_type=CUSTOMER_PAY_ADJUST,
        pay_note=reason,
        note="تسوية رصيد",
    )


@auth.requires_membership("admin")
def get_balance():
    """الرصيد الحالي من القاعدة لنافذة التسوية، بدل رقم القائمة الذي قد يكون قديماً."""
    try:
        customer_id = int(request.vars.customer_id or 0)
    except (TypeError, ValueError):
        customer_id = 0
    if not customer_id or not db.customers(customer_id):
        return response.json(api.api_error(mess="العميل غير موجود"))
    return response.json(api.api_ok(data={"balance": _customer_balance(customer_id)}))


@auth.requires_membership("admin")
def adjust_balance():
    """تسوية رصيد عميل واحد.

    amount موجب دائماً (مقدار التسوية) وتؤخذ الإشارة من الرصيد نفسه، فلا تتجاوز التسوية
    الصفر ولا تقلب الرصيد. expected_balance هو الرصيد الذي رآه المدير عند فتح النافذة؛
    إن تغيّر بعدها (فاتورة أو سداد جديد) يُرفض الطلب بدل تسوية رقم لم يره.
    """
    if request.env.request_method != "POST":
        return response.json(api.api_error(mess="طريقة الطلب غير صحيحة"))
    try:
        data = request.vars
        try:
            customer_id = int(data.customer_id or 0)
        except (TypeError, ValueError):
            customer_id = 0
        amount = _money(data.amount)
        expected = _money(data.expected_balance)
        reason, err = _adjust_reason(data.reason)
        if not customer_id or expected is None:
            return response.json(api.api_error(mess="بيانات العميل ناقصة"))
        if amount is None or amount <= 0:
            return response.json(api.api_error(mess="مبلغ التسوية يجب أن يكون أكبر من صفر"))
        if err:
            return response.json(api.api_error(mess=err))

        # قفل صف العميل: تسويتان متزامنتان للعميل نفسه تُنفَّذان بالتتابع، والثانية ترى الرصيد الجديد
        if not db.executesql("SELECT id FROM customers WHERE id = %s FOR UPDATE",
                             placeholders=[customer_id]):
            db.rollback()
            return response.json(api.api_error(mess="العميل غير موجود"))
        balance = _customer_balance(customer_id)
        if abs(balance - expected) > 0.005:
            db.rollback()
            return response.json(api.api_error(
                mess="تغيّر رصيد العميل منذ فتح النافذة، وأصبح %.2f. أعد فتحها ثم حاول" % balance))
        if abs(balance) < 0.005:
            db.rollback()
            return response.json(api.api_error(mess="رصيد العميل صفر، لا يحتاج تسوية"))
        if amount > abs(balance) + 0.005:
            db.rollback()
            return response.json(api.api_error(
                mess="مبلغ التسوية أكبر من الرصيد %.2f" % abs(balance)))

        signed = amount if balance > 0 else -amount
        new_id = _insert_adjustment(customer_id, signed, reason)
        db.commit()
        return response.json(api.api_ok(data={
            "id": int(new_id), "amount": signed, "balance": round(balance - signed, 2)}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


def _small_credit_limit(value):
    limit_amount = _money(value)
    if limit_amount is None or limit_amount <= 0 or limit_amount > SMALL_CREDIT_MAX:
        return None
    return limit_amount


def _small_credit_rows(limit_amount):
    """العملاء الذين لهم رصيد صغير (سالب وأقل من الحد).

    يُستثنى عملاء دعم الجمعية: المتبقي من دعمهم يُرحَّل للشهر التالي ولا يُسوّى
    (قرار المالك 2026-09-18). والمديونيات الصغيرة لا تدخل: كثير منها فرق فاتورة
    تجاوزت الدعم ويسدده العميل فعلاً.
    """
    return db.executesql(
        """
        WITH b AS (
            SELECT c.id, c.name, c.mobile,
                   ROUND((COALESCE(inv.total, 0) - COALESCE(pay.total, 0))::numeric, 2)::float8 AS bal
            FROM customers c
            LEFT JOIN (
                SELECT customer, SUM(total_after_discount) AS total
                FROM invoice_master WHERE payment_method = 3 GROUP BY customer
            ) inv ON inv.customer = c.id
            LEFT JOIN (
                SELECT customers_id, SUM(amount) AS total
                FROM customers_pay GROUP BY customers_id
            ) pay ON pay.customers_id = c.id
            WHERE COALESCE(c.cust_type, 0) <> %s
        )
        SELECT id, name, mobile, bal FROM b
        WHERE bal < 0 AND bal > %s
        ORDER BY bal, id
        """,
        placeholders=[CUSTOMER_TYPE_CHARITY, -limit_amount],
        as_dict=True,
    )


@auth.requires_membership("admin")
def small_credits():
    """معاينة التسوية الجماعية للأرصدة الصغيرة. لا تكتب شيئاً."""
    limit_amount = _small_credit_limit(request.vars.limit_amount or 5)
    if limit_amount is None:
        return response.json(api.api_error(
            mess="الحد يجب أن يكون أكبر من صفر ولا يتجاوز %d ريال" % SMALL_CREDIT_MAX))
    rows = _small_credit_rows(limit_amount)
    total = round(sum(r["bal"] for r in rows), 2)
    return response.json(api.api_list(rows=rows, count=len(rows), total=total))


@auth.requires_membership("admin")
def settle_small_credits():
    """تنفيذ التسوية الجماعية: قيد تسوية لكل عميل يصفّر رصيده.

    يعيد حساب القائمة بعد القفل ويرفض إن اختلف عددها أو مجموعها عمّا عاينه المدير.
    """
    if request.env.request_method != "POST":
        return response.json(api.api_error(mess="طريقة الطلب غير صحيحة"))
    try:
        data = request.vars
        limit_amount = _small_credit_limit(data.limit_amount)
        if limit_amount is None:
            return response.json(api.api_error(
                mess="الحد يجب أن يكون أكبر من صفر ولا يتجاوز %d ريال" % SMALL_CREDIT_MAX))
        try:
            expected_count = int(data.expected_count)
        except (TypeError, ValueError):
            expected_count = None
        expected_total = _money(data.expected_total)
        if expected_count is None or expected_total is None:
            return response.json(api.api_error(mess="اعرض القائمة أولاً"))
        reason, err = _adjust_reason(data.reason)
        if err:
            return response.json(api.api_error(mess=err))

        if not db.executesql("SELECT pg_try_advisory_xact_lock(%s)",
                             placeholders=[SMALL_CREDIT_LOCK_KEY])[0][0]:
            db.rollback()
            return response.json(api.api_error(mess="تسوية جماعية أخرى قيد التنفيذ الآن"))
        ids = [r["id"] for r in _small_credit_rows(limit_amount)]
        if ids:
            db.executesql("SELECT id FROM customers WHERE id = ANY(%s) ORDER BY id FOR UPDATE",
                          placeholders=[ids])
        rows = _small_credit_rows(limit_amount)
        total = round(sum(r["bal"] for r in rows), 2)
        if len(rows) != expected_count or abs(total - expected_total) > 0.005:
            db.rollback()
            return response.json(api.api_error(
                mess="تغيّرت القائمة منذ عرضها. اعرضها مرة أخرى ثم نفّذ"))
        if not rows:
            db.rollback()
            return response.json(api.api_error(mess="لا يوجد عملاء ضمن الحد"))

        for r in rows:
            _insert_adjustment(r["id"], r["bal"], reason)
        db.commit()
        return response.json(api.api_ok(data={"count": len(rows), "total": total}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
