# -*- coding: utf-8 -*-
"""Run once on each existing installation before reopening access after deployment.

Moves static/db.tar into private/backups/ without changing its contents.
Can be run with plain Python; does not load application models or connect to the DB.
"""

import sys
from pathlib import Path


if __name__ == "__main__":
    app_folder = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(app_folder / "modules"))
    from database_backups import migrate_public_backup

    name = migrate_public_backup(app_folder)
    print("Moved legacy backup to private/backups/%s" % name if name
          else "No public database backup remains.")
