# -*- coding: utf-8 -*-
"""
CSR Generation + Compliance CSID request.
Uses OpenSSL subprocess for key generation.
"""

import base64
import logging
import os
import random
import re
import shutil
import string
import subprocess
import tempfile
import uuid
from pathlib import Path

from zatca_direct.api_client import build_urls, request_compliance_csid

logger = logging.getLogger(__name__)


def _find_openssl():
    """Find OpenSSL executable (cross-platform)."""
    exe = shutil.which("openssl")
    if exe:
        return exe
    if os.name == "nt":
        for p in [
            r"C:\Program Files\OpenSSL-Win64\bin\openssl.exe",
            r"C:\Program Files\OpenSSL-Win32\bin\openssl.exe",
            r"C:\Program Files\Git\usr\bin\openssl.exe",
        ]:
            if Path(p).exists():
                return p
    raise FileNotFoundError("لم يتم العثور على OpenSSL. يجب تثبيته أو إضافته إلى PATH.")


try:
    OPENSSL = _find_openssl()
except FileNotFoundError:
    OPENSSL = "openssl"


def _run_cmd(cmd, cwd=None):
    """Run a subprocess command; raises RuntimeError on failure."""
    result = subprocess.run(
        cmd, cwd=cwd,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="ignore",
    )
    if result.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\n{result.stderr}")
    return result.stdout


def _random_code(length=6):
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


def _clean_pem(pem_content):
    """Strip PEM headers/footers and newlines."""
    match = re.search(r"-----BEGIN(?:.*?)-----(.*?)-----END(?:.*?)-----", pem_content, re.DOTALL)
    raw = match.group(1) if match else pem_content
    return raw.replace("\n", "").replace("\r", "").strip()


def _make_cnf(tmpdir, config, egs_uuid):
    """Create OpenSSL CSR config file."""
    sn = f"1-{config['VAT']}|2-{config['CRN']}|3-{_random_code()}"
    cert_template = (
        "ASN1:PRINTABLESTRING:ZATCA-Code-Signing"
        if config["environmentType"].lower() == "production"
        else "ASN1:PRINTABLESTRING:PREZATCA-Code-Signing"
    )
    tmpl = f"""\
oid_section = OIDs
[OIDs]
certificateTemplateName = 1.3.6.1.4.1.311.20.2

[req]
default_bits = 2048
emailAddress = zahmee@gmail.com
prompt = no
default_md = sha256
req_extensions = req_ext
distinguished_name = dn

[dn]
C  = {config['C']}
O  = {config['O']}
OU = {config['OU']}
CN = {config['CN']}

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment

[req_ext]
certificateTemplateName = {cert_template}
subjectAltName = dirName:alt_names

[alt_names]
SN = {sn}
UID = {config['VAT']}
title = {config.get('TITLE', '1100')}
registeredAddress = {config['ADDRESS']}
businessCategory = {config['CATEGORY']}
"""
    cnf_path = Path(tmpdir) / "config.cnf"
    cnf_path.write_text(tmpl, encoding="utf-8")
    return str(cnf_path)


def build_zatca_urls(environment_type):
    """Public wrapper for building ZATCA URLs."""
    return build_urls(environment_type)


def generate_keys_and_csid(config):
    """
    Generate EC private key + CSR, then request Compliance CSID from ZATCA.

    config dict keys: environmentType, C, O, OU, CN, VAT, CRN, ADDRESS, CATEGORY, TITLE, OTP

    Returns dict with: privateKey, csr, csr_src, egs_uuid,
                       ccsid_requestID, ccsid_binarySecurityToken, ccsid_secret,
                       + all URL endpoints
    """
    vat = config.get("VAT", "")
    if not (vat.isdigit() and len(vat) == 15):
        logger.warning(f"VAT should be 15 digits. Got: {vat}")

    egs_uuid = str(uuid.uuid4())
    urls = build_urls(config["environmentType"])

    with tempfile.TemporaryDirectory() as td:
        cnf = _make_cnf(td, config, egs_uuid)
        key_path = os.path.join(td, "private_key.pem")
        csr_path = os.path.join(td, "csr_zatca.csr")

        # 1) Generate EC private key (secp256k1)
        _run_cmd([OPENSSL, "ecparam", "-name", "secp256k1", "-genkey", "-noout", "-out", key_path])

        # 2) Generate CSR
        _run_cmd([OPENSSL, "req", "-new", "-sha256", "-key", key_path, "-config", cnf, "-out", csr_path])

        private_key_pem = Path(key_path).read_text(encoding="utf-8")
        csr_pem = Path(csr_path).read_text(encoding="utf-8")
        csr_bytes = Path(csr_path).read_bytes()

    csr_base64 = base64.b64encode(csr_bytes).decode("utf-8")

    result = {
        "privatekey": _clean_pem(private_key_pem),
        "csr": csr_base64,
        "csr_src": _clean_pem(csr_pem),
        "egs_uuid": egs_uuid,
        **urls,
    }

    # 3) Request Compliance CSID from ZATCA
    csid_data = request_compliance_csid(csr_base64, config["OTP"], urls["complianceCsidUrl"])

    if csid_data.get("requestID"):
        result["ccsid_requestid"] = str(csid_data["requestID"])
        result["ccsid_binarysecuritytoken"] = csid_data.get("binarySecurityToken", "")
        result["ccsid_secret"] = csid_data.get("secret", "")
    else:
        raise Exception(f"ZATCA لم ترجع requestID: {csid_data}")

    return result
