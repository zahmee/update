// من الخادم لا من location.href، فيبقى صحيحاً مع ?emp=<id> في العنوان
var API_BASE = SAL_BASE;

function postForm(url, fields) {
    var body = new FormData();
    Object.keys(fields || {}).forEach(function (k) {
        body.append(k, fields[k] === null || fields[k] === undefined ? '' : fields[k]);
    });
    return fetch(url, { method: 'POST', body: body }).then(function (r) { return r.json(); });
}

function toast(text) {
    Swal.fire({ toast: true, position: 'top', icon: 'success', title: text, timer: 2500, showConfirmButton: false });
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'emp_name',
            sortAsc: true,
        },
        data_row_count: 0,
        listSeq: 0,
        selectedRow: -1,
        edit_row_data: { employee: '', basic_salary: '' },
        savingSalary: false,
        pendingCard: null,
        // lookups
        employees_list: [],
        ad_types: [],
        with_salary: [],
        loading: false,
        // بطاقة الراتب
        card: null,
        cardEmployee: null,
        cardLoading: false,
        cardError: '',
        cardSeq: 0,
        cardTrigger: null,
        basicEdit: { active: false, value: '', saving: false },
        itemEdit: null,
        busy: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        cardTitle: function () {
            if (this.card) return this.card.employee.emp_name;
            var row = this.data.find(function (r) { return r.employee === this.cardEmployee; }.bind(this));
            return row ? row.emp_name : 'بطاقة الراتب';
        },
        cardBusy: function () {
            return this.cardLoading || this.busy || this.basicEdit.saving || !!(this.itemEdit && this.itemEdit.saving);
        },
        panels: function () {
            var items = this.card ? this.card.items : [];
            return [
                { key: 'allow', type: 'بدل', title: 'البدلات', single: 'بدل', icon: 'fad fa-plus-circle',
                  items: items.filter(function (i) { return i.ad_type === 'بدل'; }),
                  total: this.card ? this.card.total_allowances : 0 },
                { key: 'deduct', type: 'خصم', title: 'الخصومات', single: 'خصم', icon: 'fad fa-minus-circle',
                  items: items.filter(function (i) { return i.ad_type === 'خصم'; }),
                  total: this.card ? this.card.total_deductions : 0 },
            ];
        },
    },
    created: function () {
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var d = Api.getData(data) || {};
                this.employees_list = d.employees || [];
                this.ad_types = d.ad_types || [];
                this.with_salary = d.with_salary || [];
            }.bind(this));
        this.reload().then(function () {
            // رابط مباشر: salaries/index?emp=<رقم الموظف> يفتح بطاقته
            var emp = parseInt(new URLSearchParams(window.location.search).get('emp'), 10);
            if (emp > 0) this.openCard(emp);
        }.bind(this));
    },
    mounted: function () {
        document.getElementById('salaryCardModal').addEventListener('hidden.bs.modal', this.closeCard);
        document.getElementById('salaryModal').addEventListener('hidden.bs.modal', function () {
            var emp = this.pendingCard;
            this.pendingCard = null;
            if (emp) this.openCard(emp);
        }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
            };
            var url = new URL(API_BASE + 'get_salaries', window.location.origin);
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        reload: function (silent) {
            var seq = ++this.listSeq;
            if (!silent) this.loading = true;
            return this.fetchData().then(function (data) {
                if (seq !== this.listSeq) return;  // ردّ بحث أقدم وصل بعد الأحدث
                this.data = data.data || [];
                this.data_row_count = data.count || 0;
                this.selectedRow = this.cardEmployee ? this.rowIndexOf(this.cardEmployee) : -1;
            }.bind(this)).catch(function () {
                if (seq === this.listSeq) Swal.fire('خطأ', 'تعذر تحميل الرواتب', 'error');
            }.bind(this)).finally(function () {
                if (seq === this.listSeq) this.loading = false;
            }.bind(this));
        },
        onChange: function () {
            this.getData.page = 0;
            this.reload();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.reload();
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowIndexOf: function (employeeId) {
            return this.data.findIndex(function (r) { return r.employee === employeeId; });
        },
        hasSalary: function (employeeId) {
            return this.with_salary.indexOf(employeeId) > -1;
        },
        showModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show();
        },
        hideModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).hide();
        },
        // رسالة داخل النافذة المفتوحة حتى لا تسحب مصيدة تركيزها أزرار الرسالة
        alertIn: function (modalId, text) {
            Swal.fire({ title: 'تنبيه', text: text, icon: 'error', target: document.getElementById(modalId) });
        },
        cardAlert: function (text) {
            this.alertIn('salaryCardModal', text);
        },

        // ====== بطاقة الراتب ======
        rowSelect: function (index, row, event) {
            // انتظر حتى تنتهي النافذة السابقة وخلفيتها من الإغلاق
            if (document.body.classList.contains('modal-open')) return;
            this.cardTrigger = event.currentTarget.querySelector('.salary-name-btn');
            this.openCard(row.employee);
        },
        openCard: function (employeeId) {
            this.cardEmployee = employeeId;
            this.card = null;
            this.itemEdit = null;
            this.cancelBasic();
            this.selectedRow = this.rowIndexOf(employeeId);
            this.loadCard(employeeId);
            this.$nextTick(function () { this.showModal('salaryCardModal'); });
        },
        loadCard: function (employeeId) {
            var seq = ++this.cardSeq;
            this.cardLoading = true;
            this.cardError = '';
            return fetch(API_BASE + 'get_salary_card/' + employeeId, { headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (seq !== this.cardSeq) return;  // استجابة لبطاقة أُغلقت أو استُبدلت
                    if (Api.isOk(data)) {
                        this.card = Api.getData(data);
                        this.patchRow(this.card);
                    } else {
                        this.card = null;
                        this.cardError = Api.getError(data) || 'تعذر تحميل بطاقة الراتب';
                    }
                }.bind(this))
                .catch(function () {
                    if (seq === this.cardSeq) this.cardError = 'تعذر الاتصال بالخادم';
                }.bind(this))
                .finally(function () {
                    if (seq === this.cardSeq) this.cardLoading = false;
                }.bind(this));
        },
        // مجاميع الصف في الجدول من البطاقة، دون إعادة ترتيب القائمة أثناء العمل
        patchRow: function (card) {
            var row = this.data[this.rowIndexOf(card.employee.id)];
            if (!row) return;
            row.basic_salary = card.basic_salary;
            row.total_allowances = card.total_allowances;
            row.total_deductions = card.total_deductions;
            row.net_salary = card.net_salary;
        },
        closeCard: function () {
            this.cardSeq++;
            this.card = null;
            this.cardEmployee = null;
            this.cardLoading = false;
            this.cardError = '';
            this.itemEdit = null;
            this.cancelBasic();
            this.selectedRow = -1;
            if (this.cardTrigger && document.contains(this.cardTrigger)) this.cardTrigger.focus();
            this.cardTrigger = null;
        },
        // بعد أي حفظ: حدّث البطاقة إن بقيت مفتوحة، وإلا فالجدول
        afterChange: function (employeeId) {
            if (this.cardEmployee === employeeId) this.loadCard(employeeId);
            else this.reload(true);
        },
        focusInCard: function (selector) {
            this.$nextTick(function () {
                var el = document.querySelector('#salaryCardModal ' + selector);
                if (el) el.focus();
            });
        },

        // ── الراتب الأساسي ──
        startBasicEdit: function () {
            if (!this.card) return;
            this.itemEdit = null;
            this.basicEdit = { active: true, value: this.card.basic_salary, saving: false };
            this.focusInCard('.salary-basic-form input');
        },
        cancelBasic: function () {
            this.basicEdit = { active: false, value: '', saving: false };
        },
        saveBasic: function () {
            var edit = this.basicEdit;
            if (edit.saving) return;
            var value = parseFloat(edit.value);
            if (isNaN(value) || value < 0) { this.cardAlert('أدخل راتباً أساسياً صحيحاً'); return; }
            var emp = this.cardEmployee;
            edit.saving = true;
            postForm(API_BASE + 'save_salary', { employee: emp, basic_salary: value }).then(function (data) {
                if (Api.isOk(data)) {
                    toast('تم حفظ الراتب الأساسي');
                    if (this.basicEdit === edit) this.cancelBasic();
                    this.afterChange(emp);
                } else {
                    this.cardAlert(Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحفظ الراتب');
            }.bind(this)).finally(function () { edit.saving = false; });
        },

        // ── البدلات والخصومات ──
        typeOptions: function (type) {
            return this.ad_types.filter(function (a) { return a.ad_type === type; });
        },
        panelRows: function (p) {
            var rows = p.items.slice();
            if (this.itemEdit && !this.itemEdit.id && this.itemEdit.ad_type === p.type) rows.push({ id: 0 });
            return rows;
        },
        isEditing: function (it) {
            return !!this.itemEdit && this.itemEdit.id === it.id;
        },
        startItemAdd: function (type) {
            this.cancelBasic();
            this.itemEdit = { id: 0, ad_type: type, allowance_deduction: '', amount: '', notes: '', saving: false };
            this.focusInCard('.salary-item-select');
        },
        startItemEdit: function (it) {
            this.cancelBasic();
            this.itemEdit = {
                id: it.id,
                ad_type: it.ad_type,
                allowance_deduction: it.allowance_deduction,
                amount: it.amount,
                notes: it.notes || '',
                saving: false
            };
            this.focusInCard('.salary-amount-input');
        },
        cancelItem: function () {
            this.itemEdit = null;
        },
        saveItem: function () {
            var edit = this.itemEdit;
            if (!edit || edit.saving) return;
            if (!edit.allowance_deduction) { this.cardAlert('اختر البند'); return; }
            var amount = parseFloat(edit.amount);
            if (!(amount > 0)) { this.cardAlert('أدخل مبلغاً أكبر من صفر'); return; }
            var emp = this.cardEmployee;
            var fields = {
                employee: emp,
                allowance_deduction: edit.allowance_deduction,
                amount: amount,
                notes: (edit.notes || '').trim()
            };
            if (edit.id) fields.id = edit.id;
            edit.saving = true;
            postForm(API_BASE + (edit.id ? 'update_detail' : 'add_detail'), fields).then(function (data) {
                if (Api.isOk(data)) {
                    toast(edit.id ? 'تم تعديل البند' : 'تمت إضافة البند');
                    if (this.itemEdit === edit) this.itemEdit = null;
                    this.afterChange(emp);
                } else {
                    this.cardAlert(Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحفظ البند');
            }.bind(this)).finally(function () { edit.saving = false; });
        },
        deleteItem: function (it) {
            var emp = this.cardEmployee;
            Swal.fire({
                title: 'حذف ' + it.ad_name,
                text: 'حذف ' + (it.ad_type === 'بدل' ? 'البدل' : 'الخصم') + ' بمبلغ ' + this.money(it.amount)
                    + ' من هيكل راتب الموظف؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('salaryCardModal')
            }).then(function (result) {
                if (!result.isConfirmed) return;
                if (this.itemEdit && this.itemEdit.id === it.id) this.itemEdit = null;
                this.busy = true;
                postForm(API_BASE + 'delete_detail/' + it.id).then(function (data) {
                    if (Api.isOk(data)) {
                        toast('تم حذف البند');
                        this.afterChange(emp);
                    } else {
                        this.cardAlert(Api.getError(data));
                    }
                }.bind(this)).catch(function () {
                    this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحذف البند');
                }.bind(this)).finally(function () { this.busy = false; }.bind(this));
            }.bind(this));
        },

        // ── حذف الراتب ──
        deleteSalary: function () {
            var card = this.card;
            if (!card) return;
            var count = card.items.length;
            Swal.fire({
                title: 'حذف راتب ' + card.employee.emp_name,
                text: 'سيُحذف الراتب الأساسي' + (count ? ' مع بنوده من البدلات والخصومات (' + count + ')' : '')
                    + '. المسيرات المنشأة سابقاً لا تتأثر.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('salaryCardModal')
            }).then(function (result) {
                if (!result.isConfirmed) return;
                this.busy = true;
                postForm(API_BASE + 'delete_salary/' + card.salary_id).then(function (data) {
                    if (Api.isOk(data)) {
                        var emp = card.employee.id;
                        this.with_salary = this.with_salary.filter(function (e) { return e !== emp; });
                        toast('تم حذف الراتب');
                        this.hideModal('salaryCardModal');
                        this.reload(true);
                    } else {
                        this.cardAlert(Api.getError(data));
                    }
                }.bind(this)).catch(function () {
                    this.cardAlert('تعذر الاتصال بالخادم؛ لم يُحذف الراتب');
                }.bind(this)).finally(function () { this.busy = false; }.bind(this));
            }.bind(this));
        },

        // ====== إضافة راتب جديد ======
        new_row_click: function () {
            this.edit_row_data = { employee: '', basic_salary: '' };
            this.showModal('salaryModal');
        },
        save_salary: function () {
            if (this.savingSalary) return;
            var emp = parseInt(this.edit_row_data.employee, 10);
            if (!emp) { this.alertIn('salaryModal', 'يجب اختيار الموظف'); return; }
            var basic = this.edit_row_data.basic_salary;
            if (basic === '' || basic === null || basic === undefined || isNaN(parseFloat(basic))) {
                this.alertIn('salaryModal', 'يجب إدخال الراتب الأساسي');
                return;
            }
            this.savingSalary = true;
            postForm(API_BASE + 'save_salary', { employee: emp, basic_salary: basic }).then(function (data) {
                if (Api.isOk(data)) {
                    if (!this.hasSalary(emp)) this.with_salary.push(emp);
                    toast('تم حفظ الراتب؛ أضف بدلاته وخصوماته');
                    this.pendingCard = emp;  // تُفتح بطاقته بعد إغلاق نافذة الإضافة
                    this.hideModal('salaryModal');
                    this.reload(true);
                } else {
                    this.alertIn('salaryModal', Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.alertIn('salaryModal', 'تعذر الاتصال بالخادم؛ لم يُحفظ الراتب');
            }.bind(this)).finally(function () { this.savingSalary = false; }.bind(this));
        },

        formatNum: function (n) {
            if (n === null || n === undefined) return '0.00';
            return parseFloat(n).toFixed(2);
        },
        money: function (n) {
            return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
    }
});
