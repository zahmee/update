# -*- coding: utf-8 -*-
"""Isolated backup regressions; no application models or operational DB are loaded.

Run: python -B scripts/test_database_backups.py
Uses the enclosing Web2py runtime for its real authorization/signature/stream code.
"""

import subprocess
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit


APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP.parents[1]))
sys.path.insert(0, str(APP / "modules"))

import database_backups as backups
from gluon import HTTP, URL, current, redirect
from gluon.globals import Request, Response, Session
from gluon.storage import List, Storage
from gluon.template import render
from gluon.tools import Auth


NOW = datetime(2026, 9, 21, 12, 30)
NAME = "db_20260921_123000_" + "a" * 32 + ".tar"
CONNECTION = dict(host="localhost", port="5432", user="fixture", password="fixture-secret", dbname="fixture")


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        (self.folder / "static").mkdir()

    def fake_dump(self, args, **kwargs):
        self.assertNotIn(CONNECTION["password"], args)
        self.assertEqual(kwargs["env"]["PGPASSWORD"], CONNECTION["password"])
        kwargs["stdout"].write(b"completed archive")
        return subprocess.CompletedProcess(args, 0, stderr=b"")

    def test_successful_archives_are_private_and_unique(self):
        with patch.object(backups.subprocess, "run", side_effect=self.fake_dump):
            first = backups.create_backup(self.folder, CONNECTION, NOW)
            second = backups.create_backup(self.folder, CONNECTION, NOW)
        self.assertNotEqual(first, second)
        for name in (first, second):
            path = Path(backups.backup_path(self.folder, name))
            self.assertEqual(path.parent, self.folder / "private" / "backups")
            self.assertEqual(path.read_bytes(), b"completed archive")
        self.assertEqual(list((self.folder / "static").iterdir()), [])
        self.assertEqual(list((self.folder / "private" / "backups").glob("*.part")), [])

    def test_failed_dump_keeps_prior_archive_and_removes_partial(self):
        directory = self.folder / "private" / "backups"
        directory.mkdir(parents=True)
        prior = directory / NAME
        prior.write_bytes(b"previous good archive")

        def fail(args, **kwargs):
            kwargs["stdout"].write(b"incomplete")
            return subprocess.CompletedProcess(args, 1, stderr=b"failure")

        with patch.object(backups.subprocess, "run", side_effect=fail):
            with self.assertRaises(backups.BackupError):
                backups.create_backup(self.folder, CONNECTION, NOW)
        self.assertEqual(prior.read_bytes(), b"previous good archive")
        self.assertEqual(list(directory.iterdir()), [prior])

    def test_timeout_missing_tool_and_empty_dump_leave_no_archive(self):
        failures = [subprocess.TimeoutExpired("pg_dump", 900), FileNotFoundError("pg_dump")]
        for failure in failures:
            with self.subTest(failure=type(failure).__name__):
                with patch.object(backups.subprocess, "run", side_effect=failure):
                    with self.assertRaises(backups.BackupError):
                        backups.create_backup(self.folder, CONNECTION, NOW)
                self.assertEqual(list((self.folder / "private" / "backups").iterdir()), [])
        with patch.object(backups.subprocess, "run", return_value=subprocess.CompletedProcess([], 0)):
            with self.assertRaises(backups.BackupError):
                backups.create_backup(self.folder, CONNECTION, NOW)
        self.assertEqual(list((self.folder / "private" / "backups").iterdir()), [])

    def test_legacy_migration_preserves_bytes_and_is_idempotent(self):
        old = self.folder / "static" / "db.tar"
        old.write_bytes(b"legacy backup contents")
        name = backups.migrate_public_backup(self.folder, NOW)
        self.assertFalse(old.exists())
        self.assertEqual(Path(backups.backup_path(self.folder, name)).read_bytes(), b"legacy backup contents")
        self.assertIsNone(backups.migrate_public_backup(self.folder, NOW))

    def test_missing_invalid_partial_and_traversal_paths_are_rejected(self):
        for name in (NAME, "../appconfig.ini", "..\\appconfig.ini", "/etc/passwd", "db.tar", NAME + ".part", None):
            with self.subTest(name=name), self.assertRaises(FileNotFoundError):
                backups.backup_path(self.folder, name)


class EndpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.role = "admin"
        self.request = Request({"request_method": "POST", "http_host": "localhost"})
        self.request.application = "asbab5"
        self.request.controller = "_t"
        self.request.function = "db_backup"
        self.request.folder = str(self.folder)
        self.request.now = NOW
        self.request.args = List()
        self.response = Response()
        self.response.delimiters = ("{{{", "}}}")
        self.session = Session()
        self.session.auth = Storage(user=Storage(id=1), last_visit=NOW, expiration=3600,
                                    hmac_key="isolated-session-signing-key")
        current.request = self.request
        current.response = self.response
        current.session = self.session
        current.T = lambda text: text
        self.auth = Auth(None)
        # Exercise real Web2py decorators; supply only the role lookup without a DB.
        self.auth.has_membership = lambda group_id=None, role=None: bool(
            self.auth.user and (role or group_id) == self.role
        )
        self.env = dict(auth=self.auth, request=self.request, response=self.response,
                        HTTP=HTTP, URL=URL, redirect=redirect)
        exec(compile((APP / "controllers" / "_t.py").read_text(encoding="utf-8"), "_t.py", "exec"), self.env)
        self.env["_db_conn_info"] = lambda: CONNECTION

    def sign(self):
        url = URL("_t", "db_backup", user_signature=True)
        self.request._get_vars = Storage({k: v[0] for k, v in parse_qs(urlsplit(url).query).items()})
        self.request._vars = None

    def prepare_download(self):
        directory = self.folder / "private" / "backups"
        directory.mkdir(parents=True, exist_ok=True)
        (directory / NAME).write_bytes(b"private archive contents")
        self.request.function = "download_backup"
        self.request.env.request_method = "GET"
        self.request.args = List([NAME])

    def test_anonymous_and_nonadmin_cannot_create_or_download(self):
        for role in ("user", None):
            self.role = role
            if role is None:
                self.auth.user = None
                self.session.auth = None
            for endpoint in ("db_backup", "download_backup"):
                with self.subTest(role=role, endpoint=endpoint):
                    with patch.object(backups, "create_backup") as create, patch.object(backups, "backup_path") as resolve:
                        with self.assertRaises(HTTP) as error:
                            self.env[endpoint]()
                        self.assertIn(error.exception.status, (303, 403))
                        create.assert_not_called()
                        resolve.assert_not_called()

    def test_admin_requires_signed_post(self):
        with patch.object(backups, "create_backup") as create:
            with self.assertRaises(HTTP) as error:
                self.env["db_backup"]()
            self.assertIn(error.exception.status, (303, 403))
            self.sign()
            self.request.env.request_method = "GET"
            with self.assertRaises(HTTP) as error:
                self.env["db_backup"]()
            self.assertEqual(error.exception.status, 405)
            create.assert_not_called()

    def test_signature_from_another_session_is_rejected(self):
        self.sign()
        self.session.auth.hmac_key = "another-isolated-session-key"
        with patch.object(backups, "create_backup") as create:
            with self.assertRaises(HTTP) as error:
                self.env["db_backup"]()
            self.assertIn(error.exception.status, (303, 403))
            create.assert_not_called()

    def test_signed_admin_creation_redirects_to_protected_download(self):
        self.sign()
        with patch.object(backups, "create_backup", return_value=NAME) as create:
            with self.assertRaises(HTTP) as error:
                self.env["db_backup"]()
        self.assertEqual(error.exception.status, 303)
        self.assertEqual(error.exception.headers["Location"], "/asbab5/_t/download_backup/" + NAME)
        create.assert_called_once_with(str(self.folder), CONNECTION, NOW)

    def test_admin_download_streams_attachment_without_caching(self):
        self.prepare_download()
        with self.assertRaises(HTTP) as result:
            self.env["download_backup"]()
        self.assertEqual(result.exception.status, 200)
        self.assertEqual(b"".join(result.exception.body), b"private archive contents")
        self.assertEqual(result.exception.headers["Cache-Control"], "private, no-store")
        self.assertIn("attachment", result.exception.headers["Content-Disposition"])

    def test_download_rejects_traversal_and_extra_arguments(self):
        self.prepare_download()
        for args in (["../appconfig.ini"], [NAME, "extra"], []):
            self.request.args = List(args)
            with self.subTest(args=args), self.assertRaises(HTTP) as error:
                self.env["download_backup"]()
            self.assertEqual(error.exception.status, 404)

    def test_about_button_is_signed_post_and_hidden_from_nonadmins(self):
        view = (APP / "views" / "default" / "about.html").read_text(encoding="utf-8")
        start = view.index('{{{if auth.has_membership("admin"):}}}')
        end = view.index("{{{pass}}}", start) + len("{{{pass}}}")
        fragment = view[start:end]
        context = dict(auth=self.auth, URL=URL, response=self.response)
        admin_html = render(content=fragment, context=context, delimiters=("{{{", "}}}"))
        self.assertIn('method="post"', admin_html)
        self.assertIn("_signature=", admin_html)
        self.role = "user"
        user_html = render(content=fragment, context=context, delimiters=("{{{", "}}}"))
        self.assertNotIn("db_backup", user_html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
