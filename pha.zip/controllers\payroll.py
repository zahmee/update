# -*- coding: utf-8 -*-
#  type: ignore
import api_helpers as api


def _parse_payroll_period(data):
    errors = []
    try:
        pay_month = int(data.pay_month)
    except (TypeError, ValueError):
        pay_month = 0
    try:
        pay_year = int(data.pay_year)
    except (TypeError, ValueError):
        pay_year = 0
    if pay_month < 1 or pay_month > 12:
        errors.append("الشهر غير صحيح")
    if pay_year < 2000 or pay_year > 2100:
        errors.append("السنة غير صحيحة")
    return errors, pay_month, pay_year


def _valid_employee_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.employees(row_id) else None


def _valid_allowance_deduction_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.key_allowance_deduction(row_id) else None


def _amount_value(value, allow_zero=False):
    try:
        amount = float(value)
    except (TypeError, ValueError):
        return None
    if amount < 0 or (not allow_zero and amount <= 0):
        return None
    return amount


@can_access(7006)
def index():
    return dict()


@can_access(7006)
def view_month():
    return dict()


@can_access(7006)
def print_month():
    """Read-only, complete monthly payroll with every allowance/deduction."""
    from datetime import datetime, timedelta, timezone
    from decimal import Decimal

    try:
        pay_month, pay_year = int(request.args(0)), int(request.args(1))
    except (TypeError, ValueError):
        raise HTTP(400, "فترة الرواتب غير صحيحة")
    if not (1 <= pay_month <= 12 and 2000 <= pay_year <= 2100):
        raise HTTP(400, "فترة الرواتب غير صحيحة")

    period = db((db.payroll_period.pay_month == pay_month) &
                (db.payroll_period.pay_year == pay_year)).select().first()
    if not period:
        raise HTTP(404, "فترة الرواتب غير موجودة")

    # One joined snapshot: no pagination, search filter or per-employee requests.
    rows = db((db.payroll.pay_month == pay_month) &
              (db.payroll.pay_year == pay_year)).select(
        db.payroll.id, db.payroll.employee, db.payroll.basic_salary,
        db.employees.emp_name, db.payroll_detail.id,
        db.payroll_detail.amount, db.payroll_detail.notes,
        db.key_allowance_deduction.name, db.key_allowance_deduction.ad_type,
        left=[db.employees.on(db.employees.id == db.payroll.employee),
              db.payroll_detail.on(db.payroll_detail.payroll_id == db.payroll.id),
              db.key_allowance_deduction.on(
                  db.key_allowance_deduction.id == db.payroll_detail.allowance_deduction)],
        orderby=~db.payroll.id | db.payroll_detail.id,
    )
    payrolls = {}
    for row in rows:
        p, detail, ad = row.payroll, row.payroll_detail, row.key_allowance_deduction
        if p.id not in payrolls:
            payrolls[p.id] = dict(
                id=p.id, employee=p.employee,
                emp_name=row.employees.emp_name or "موظف غير متاح",
                basic_salary=Decimal(str(p.basic_salary or 0)),
                total_allowances=Decimal('0'), total_deductions=Decimal('0'),
                details=[],
            )
        item = payrolls[p.id]
        if detail.id:
            amount = Decimal(str(detail.amount or 0))
            item['details'].append(dict(
                name=ad.name or "بند غير مصنف", ad_type=ad.ad_type or "غير مصنف",
                amount=amount, notes=detail.notes or '',
            ))
            if ad.ad_type == 'بدل':
                item['total_allowances'] += amount
            elif ad.ad_type == 'خصم':
                item['total_deductions'] += amount

    totals = dict.fromkeys(('basic_salary', 'total_allowances', 'total_deductions', 'net_salary'), Decimal('0'))
    for item in payrolls.values():
        item['net_salary'] = item['basic_salary'] + item['total_allowances'] - item['total_deductions']
        for key in totals:
            totals[key] += item[key]
    months = ('يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
              'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر')
    response.headers['Cache-Control'] = 'no-store'
    return dict(
        payrolls=list(payrolls.values()), totals=totals, period=period,
        period_label='%s %s' % (months[pay_month - 1], pay_year),
        configuration=db(db.important_info.id > 0).select().first(),
        printed_at=datetime.now(timezone(timedelta(hours=3))).strftime('%Y/%m/%d %H:%M'),
        money=lambda value: format(value, ',.2f'),
    )


@can_access(7006)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    ad_types = db(db.key_allowance_deduction.id > 0).select(
        db.key_allowance_deduction.id,
        db.key_allowance_deduction.name,
        db.key_allowance_deduction.ad_type,
        orderby=db.key_allowance_deduction.name
    )
    return response.json(api.api_ok(data={
        "employees": employees,
        "ad_types": ad_types,
    }))


@can_access(7006)
def get_periods():
    ReqVar = request.vars

    conditions = []
    params = []

    if ReqVar.year_filter and ReqVar.year_filter != '0':
        conditions.append("( pp.pay_year = %s )")
        params.append(int(ReqVar.year_filter))

    if ReqVar.status_filter == 'approved':
        conditions.append("( pp.is_approved = 'T' )")
    elif ReqVar.status_filter == 'not_approved':
        conditions.append("( pp.is_approved = 'F' OR pp.is_approved IS NULL )")

    allowed_sort_columns = {'pay_month', 'pay_year'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'pay_year'
    sort_map = {
        'pay_month': 'pp.pay_month',
        'pay_year': 'pp.pay_year',
    }
    sort_col = sort_map.get(sc, 'pp.pay_year')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT pp.id, pp.pay_month, pp.pay_year, pp.is_approved, "
        f"COALESCE(("
        f"  SELECT COUNT(*) FROM payroll p WHERE p.pay_month = pp.pay_month AND p.pay_year = pp.pay_year"
        f"), 0) AS emp_count, "
        f"COALESCE(("
        f"  SELECT SUM(p.net_salary) FROM payroll p WHERE p.pay_month = pp.pay_month AND p.pay_year = pp.pay_year"
        f"), 0) AS total_net "
        f"FROM payroll_period pp "
        f"{where} ORDER BY {sort_col} {sa}, pp.pay_month DESC"
    )

    qry = db.executesql(sql, placeholders=params if params else None, as_dict=True)
    return response.json(api.api_ok(data=qry))


@can_access(7006)
def new_period():
    try:
        data = request.vars
        errors, pay_month, pay_year = _parse_payroll_period(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        existing = db((db.payroll_period.pay_month == pay_month) &
                       (db.payroll_period.pay_year == pay_year)).select().first()
        if existing:
            return response.json(api.api_error(mess="توجد فترة لنفس الشهر والسنة"))

        db.payroll_period.insert(
            pay_month=pay_month,
            pay_year=pay_year,
            is_approved=False,
        )
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def approve_period():
    try:
        data = request.vars
        row = db.payroll_period[data.id]
        if not row:
            return response.json(api.api_error(mess="الفترة غير موجودة"))

        is_approved = (data.is_approved == 'true')

        # عند الاعتماد: خصم السلفة يُضاف للمسدد من السلفة المفتوحة
        if is_approved:
            _apply_advance_deductions(row.pay_month, row.pay_year)

        row.update_record(is_approved=is_approved)
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


def _apply_advance_deductions(pay_month, pay_year):
    """عند اعتماد المسير: إضافة مبلغ خصم السلفة إلى المسدد من السلفيات المفتوحة"""
    # جلب id بند "خصم سلفة"
    advance_deduction = db(
        (db.key_allowance_deduction.name == 'خصم سلفة') &
        (db.key_allowance_deduction.ad_type == 'خصم')
    ).select().first()
    if not advance_deduction:
        return

    # جلب جميع مسيرات هذه الفترة
    payrolls = db((db.payroll.pay_month == pay_month) &
                   (db.payroll.pay_year == pay_year)).select()

    for p in payrolls:
        # جلب مبلغ خصم السلفة من تفاصيل المسير
        detail = db((db.payroll_detail.payroll_id == p.id) &
                     (db.payroll_detail.allowance_deduction == advance_deduction.id)
                     ).select().first()
        if not detail or float(detail.amount or 0) <= 0:
            continue

        deduction_amount = float(detail.amount)

        # جلب السلفيات المفتوحة للموظف (الأقدم أولاً)
        open_advances = db(
            (db.emp_advances.employee == p.employee) &
            ((db.emp_advances.is_closed == False) | (db.emp_advances.is_closed == None))
        ).select(orderby=db.emp_advances.advance_date)

        remaining = deduction_amount
        for adv in open_advances:
            if remaining <= 0:
                break
            adv_remaining = float(adv.amount or 0) - float(adv.paid_amount or 0)
            if adv_remaining <= 0:
                continue
            pay_now = min(remaining, adv_remaining)
            new_paid = float(adv.paid_amount or 0) + pay_now
            is_closed = (new_paid >= float(adv.amount or 0))
            adv.update_record(
                paid_amount=new_paid,
                is_closed=is_closed,
                closed_date=request.now if is_closed else adv.closed_date,
            )
            remaining -= pay_now


@can_access(7006)
def delete_period():
    try:
        row = db.payroll_period[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="الفترة غير موجودة"))

        # حذف جميع مسيرات هذه الفترة وتفاصيلها
        payrolls = db((db.payroll.pay_month == row.pay_month) &
                       (db.payroll.pay_year == row.pay_year)).select()
        for p in payrolls:
            db(db.payroll_detail.payroll_id == p.id).delete()
            p.delete_record()

        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def get_payrolls():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append("( emp.emp_name LIKE %s )")
            params.append(pattern)

    if ReqVar.emp_filter and ReqVar.emp_filter != '0':
        conditions.append("( p.employee = %s )")
        params.append(int(ReqVar.emp_filter))

    if ReqVar.month_filter and ReqVar.month_filter != '0':
        conditions.append("( p.pay_month = %s )")
        params.append(int(ReqVar.month_filter))

    if ReqVar.year_filter and ReqVar.year_filter != '0':
        conditions.append("( p.pay_year = %s )")
        params.append(int(ReqVar.year_filter))

    allowed_sort_columns = {'id', 'emp_name', 'pay_month', 'pay_year', 'basic_salary', 'total_allowances', 'total_deductions', 'net_salary'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'

    sort_map = {
        'id': 'p.id',
        'emp_name': 'emp.emp_name',
        'pay_month': 'p.pay_month',
        'pay_year': 'p.pay_year',
        'basic_salary': 'p.basic_salary',
        'total_allowances': 'total_allowances',
        'total_deductions': 'total_deductions',
        'net_salary': 'net_salary',
    }
    sort_col = sort_map.get(sc, 'p.id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT p.id, p.employee, p.pay_month, p.pay_year, p.basic_salary, "
        f"emp.emp_name, "
        f"COALESCE(("
        f"  SELECT SUM(pd.amount) FROM payroll_detail pd "
        f"  JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        f"  WHERE pd.payroll_id = p.id AND ad.ad_type = 'بدل'"
        f"), 0) AS total_allowances, "
        f"COALESCE(("
        f"  SELECT SUM(pd.amount) FROM payroll_detail pd "
        f"  JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        f"  WHERE pd.payroll_id = p.id AND ad.ad_type = 'خصم'"
        f"), 0) AS total_deductions, "
        f"p.basic_salary + COALESCE(("
        f"  SELECT SUM(pd.amount) FROM payroll_detail pd "
        f"  JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        f"  WHERE pd.payroll_id = p.id AND ad.ad_type = 'بدل'"
        f"), 0) - COALESCE(("
        f"  SELECT SUM(pd.amount) FROM payroll_detail pd "
        f"  JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        f"  WHERE pd.payroll_id = p.id AND ad.ad_type = 'خصم'"
        f"), 0) AS net_salary, "
        f"COALESCE(("
        f"  SELECT SUM(adv.amount - adv.paid_amount) FROM emp_advances adv "
        f"  WHERE adv.employee = p.employee AND (adv.is_closed = 'F' OR adv.is_closed IS NULL)"
        f"), 0) AS advance_remaining "
        f"FROM payroll p "
        f"JOIN employees emp ON emp.id = p.employee "
        f"{where} ORDER BY {sort_col} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM payroll p "
        f"JOIN employees emp ON emp.id = p.employee "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7006)
def add_all_employees():
    """إضافة جميع الموظفين للمسير دفعة واحدة"""
    try:
        data = request.vars
        errors, pay_month, pay_year = _parse_payroll_period(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        # جلب جميع الموظفين
        employees = db(db.employees.id > 0).select(db.employees.id)
        added = 0
        skipped = 0

        for emp in employees:
            employee_id = emp.id

            # فحص عدم التكرار
            existing = db((db.payroll.employee == employee_id) &
                           (db.payroll.pay_month == pay_month) &
                           (db.payroll.pay_year == pay_year)).select().first()
            if existing:
                skipped += 1
                continue

            # جلب الراتب الأساسي
            salary = db(db.emp_salary.employee == employee_id).select().first()
            basic_salary = float(salary.basic_salary) if salary else 0

            pid = db.payroll.insert(
                employee=employee_id,
                pay_month=pay_month,
                pay_year=pay_year,
                basic_salary=basic_salary,
                net_salary=basic_salary,
            )

            # نسخ البدلات والخصومات من emp_salary_detail
            details = db(db.emp_salary_detail.employee == employee_id).select()
            total_allow = 0
            total_deduct = 0
            for d in details:
                db.payroll_detail.insert(
                    payroll_id=pid,
                    allowance_deduction=d.allowance_deduction,
                    amount=float(d.amount or 0),
                    notes=d.notes or '',
                )
                ad = db.key_allowance_deduction(d.allowance_deduction)
                if ad and ad.ad_type == 'بدل':
                    total_allow += float(d.amount or 0)
                elif ad and ad.ad_type == 'خصم':
                    total_deduct += float(d.amount or 0)

            net = basic_salary + total_allow - total_deduct
            db(db.payroll.id == pid).update(net_salary=net)
            added += 1

        db.commit()
        return response.json(api.api_ok(data={
            "added": added,
            "skipped": skipped,
        }))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def new_payroll():
    try:
        data = request.vars
        employee_id = _valid_employee_id(data.employee)
        if not employee_id:
            return response.json(api.api_error(mess="الموظف غير موجود"))
        errors, pay_month, pay_year = _parse_payroll_period(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        # فحص عدم التكرار
        existing = db((db.payroll.employee == employee_id) &
                       (db.payroll.pay_month == pay_month) &
                       (db.payroll.pay_year == pay_year)).select().first()
        if existing:
            return response.json(api.api_error(mess="يوجد مسير لهذا الموظف في نفس الشهر والسنة"))

        # جلب الراتب الأساسي من emp_salary
        salary = db(db.emp_salary.employee == employee_id).select().first()
        basic_salary = float(salary.basic_salary) if salary else 0

        pid = db.payroll.insert(
            employee=employee_id,
            pay_month=pay_month,
            pay_year=pay_year,
            basic_salary=basic_salary,
            net_salary=basic_salary,
        )

        # نسخ البدلات والخصومات من emp_salary_detail
        details = db(db.emp_salary_detail.employee == employee_id).select()
        total_allow = 0
        total_deduct = 0
        for d in details:
            db.payroll_detail.insert(
                payroll_id=pid,
                allowance_deduction=d.allowance_deduction,
                amount=float(d.amount or 0),
                notes=d.notes or '',
            )
            ad = db.key_allowance_deduction(d.allowance_deduction)
            if ad and ad.ad_type == 'بدل':
                total_allow += float(d.amount or 0)
            elif ad and ad.ad_type == 'خصم':
                total_deduct += float(d.amount or 0)

        # تحديث الإجمالي
        net = basic_salary + total_allow - total_deduct
        db(db.payroll.id == pid).update(net_salary=net)
        db.commit()

        return response.json(api.api_ok(data={"id": pid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def update_payroll():
    try:
        data = request.vars
        row = db.payroll[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        basic_salary = _amount_value(data.basic_salary or 0, allow_zero=True)
        if basic_salary is None:
            return response.json(api.api_error(mess="الراتب الأساسي لا يمكن أن يكون سالباً"))

        row.update_record(basic_salary=basic_salary)
        _recalc_net(row.id)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def get_payroll_details():
    payroll_id = request.args(0)
    if not payroll_id:
        return response.json(api.api_ok(data=[]))

    sql = (
        "SELECT pd.id, pd.payroll_id, pd.allowance_deduction, pd.amount, pd.notes, "
        "ad.name AS ad_name, ad.ad_type "
        "FROM payroll_detail pd "
        "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        "WHERE pd.payroll_id = %s "
        "ORDER BY ad.ad_type, ad.name"
    )
    qry = db.executesql(sql, placeholders=[payroll_id], as_dict=True)
    return response.json(api.api_ok(data=qry))


@can_access(7006)
def add_detail():
    try:
        data = request.vars
        try:
            payroll_id = int(data.payroll_id)
        except (TypeError, ValueError):
            return response.json(api.api_error(mess="المسير غير موجود"))
        if not db.payroll(payroll_id):
            return response.json(api.api_error(mess="المسير غير موجود"))
        allowance_deduction = _valid_allowance_deduction_id(data.allowance_deduction)
        if not allowance_deduction:
            return response.json(api.api_error(mess="البند غير موجود"))
        amount = _amount_value(data.amount)
        if amount is None:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        db.payroll_detail.insert(
            payroll_id=payroll_id,
            allowance_deduction=allowance_deduction,
            amount=amount,
            notes=data.notes or '',
        )
        _recalc_net(payroll_id)
        db.commit()
        return response.json(api.api_ok(data={"id": payroll_id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def update_detail():
    try:
        data = request.vars
        row = db.payroll_detail[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        allowance_deduction = _valid_allowance_deduction_id(data.allowance_deduction)
        if not allowance_deduction:
            return response.json(api.api_error(mess="البند غير موجود"))
        amount = _amount_value(data.amount)
        if amount is None:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        row.update_record(
            allowance_deduction=allowance_deduction,
            amount=amount,
            notes=data.notes or '',
        )
        _recalc_net(row.payroll_id)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def delete_detail():
    try:
        row = db.payroll_detail[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        pid = row.payroll_id
        row.delete_record()
        _recalc_net(pid)
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def delete_payroll():
    try:
        row = db.payroll[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        db(db.payroll_detail.payroll_id == row.id).delete()
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


def _recalc_net(payroll_id):
    """إعادة حساب إجمالي الراتب"""
    row = db.payroll[payroll_id]
    if not row:
        return
    result = db.executesql(
        "SELECT "
        "COALESCE(SUM(CASE WHEN ad.ad_type = 'بدل' THEN pd.amount ELSE 0 END), 0) AS allow_sum, "
        "COALESCE(SUM(CASE WHEN ad.ad_type = 'خصم' THEN pd.amount ELSE 0 END), 0) AS deduct_sum "
        "FROM payroll_detail pd "
        "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        "WHERE pd.payroll_id = %s",
        placeholders=[payroll_id], as_dict=True
    )
    allow_sum = float(result[0]['allow_sum']) if result else 0
    deduct_sum = float(result[0]['deduct_sum']) if result else 0
    net = float(row.basic_salary or 0) + allow_sum - deduct_sum
    row.update_record(net_salary=net)
