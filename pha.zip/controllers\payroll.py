# -*- coding: utf-8 -*-
#  type: ignore
import json

import api_helpers as api
import advance_ledger


def _parse_payroll_period(data):
    errors = []
    try:
        pay_month = int(data.pay_month)
    except (TypeError, ValueError):
        pay_month = 0
    try:
        pay_year = int(data.pay_year)
    except (TypeError, ValueError):
        pay_year = 0
    if pay_month < 1 or pay_month > 12:
        errors.append("الشهر غير صحيح")
    if pay_year < 2000 or pay_year > 2100:
        errors.append("السنة غير صحيحة")
    return errors, pay_month, pay_year


def _valid_employee_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.employees(row_id) else None


def _valid_allowance_deduction_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.key_allowance_deduction(row_id) else None


def _amount_value(value, allow_zero=False):
    try:
        amount = float(value)
    except (TypeError, ValueError):
        return None
    if amount < 0 or (not allow_zero and amount <= 0):
        return None
    return amount


_MONTHS = ('يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
           'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر')


def _post_only():
    """التعديل والحذف بطلب POST فقط، فلا يُنفَّذ برابط يُفتح في المتصفح."""
    if request.env.request_method != "POST":
        raise HTTP(405)


def _locked_period(pay_month, pay_year):
    """رسالة الرفض إن كانت فترة الشهر معتمدة، وإلا None.
    FOR SHARE يجعل الاعتماد (FOR UPDATE في approve_period) ينتظر انتهاء هذا التعديل، والعكس."""
    rows = db.executesql(
        "SELECT is_approved FROM payroll_period WHERE pay_month = %s AND pay_year = %s FOR SHARE",
        placeholders=[pay_month, pay_year])
    if any(r[0] == 'T' for r in rows):
        return "فترة %s %s معتمدة؛ ألغِ اعتمادها من شاشة الفترات أولاً ثم عدّل" % (
            _MONTHS[pay_month - 1] if 1 <= pay_month <= 12 else pay_month, pay_year)
    return None


# مسيرات الشهر مع المجاميع من البنود ومقارنتها بهيكل الراتب الحالي والسلف المفتوحة.
# أول معامل: بند «خصم سلفة» (advance_ledger.deduction_item_id)، ثم معاملات {where}.
_PAYROLL_CTE = (
    "WITH base AS ("
    " SELECT p.id, p.employee, p.pay_month, p.pay_year, COALESCE(p.basic_salary, 0) AS basic_salary,"
    " emp.emp_name, jt.name AS job_title_name,"
    " COALESCE(l.allow, 0) AS total_allowances, COALESCE(l.deduct, 0) AS total_deductions,"
    " COALESCE(l.adv, 0) AS advance_deduction, COALESCE(l.cnt, 0) AS line_count,"
    " s.id AS structure_id, COALESCE(s.basic_salary, 0) AS structure_basic,"
    " COALESCE(a.remaining, 0) AS advance_remaining,"
    " COALESCE((SELECT bool_or(pp.is_approved = 'T') FROM payroll_period pp"
    "           WHERE pp.pay_month = p.pay_month AND pp.pay_year = p.pay_year), FALSE) AS approved"
    " FROM payroll p"
    " JOIN employees emp ON emp.id = p.employee"
    " LEFT JOIN key_job_titles jt ON jt.id = emp.job_title"
    " LEFT JOIN emp_salary s ON s.employee = p.employee"
    " LEFT JOIN LATERAL ("
    "   SELECT SUM(CASE WHEN ad.ad_type = 'بدل' THEN pd.amount ELSE 0 END) AS allow,"
    "   SUM(CASE WHEN ad.ad_type = 'خصم' THEN pd.amount ELSE 0 END) AS deduct,"
    "   SUM(CASE WHEN pd.allowance_deduction = %s THEN pd.amount ELSE 0 END) AS adv, COUNT(*) AS cnt"
    "   FROM payroll_detail pd JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction"
    "   WHERE pd.payroll_id = p.id) l ON TRUE"
    " LEFT JOIN LATERAL ("
    "   SELECT SUM(COALESCE(adv.amount, 0) - COALESCE(adv.paid_amount, 0)) AS remaining FROM emp_advances adv"
    "   WHERE adv.employee = p.employee AND COALESCE(adv.is_closed, 'F') <> 'T') a ON TRUE"
    " {where}"
    "), f AS ("
    " SELECT b.*, b.basic_salary + b.total_allowances - b.total_deductions AS net_salary,"
    " (b.basic_salary + b.total_allowances - b.total_deductions) < -0.005 AS f_negative,"
    " (NOT b.approved AND b.advance_deduction > b.advance_remaining + 0.005) AS f_excess,"
    " (NOT b.approved AND b.advance_remaining > 0.005 AND b.advance_deduction <= 0) AS f_no_installment,"
    " (b.structure_id IS NULL OR ABS(b.structure_basic - b.basic_salary) > 0.005) AS f_structure"
    " FROM base b"
    "), g AS ("
    " SELECT f.*, CASE WHEN f_negative OR f_excess THEN 'danger'"
    " WHEN f_structure OR f_no_installment THEN 'warning' ELSE '' END AS level FROM f"
    ") "
)
_FLAG_FILTERS = {
    "danger": "level = 'danger'",
    "warning": "level = 'warning'",
    "advance": "advance_remaining > 0.005",
}


def _payroll_where(conditions):
    return (" WHERE " + " AND ".join(conditions)) if conditions else ""


def _deduction_id():
    return advance_ledger.deduction_item_id(db) or 0


@can_access(7006)
def index():
    return dict()


@can_access(7006)
def view_month():
    try:
        pay_month, pay_year = int(request.args(0)), int(request.args(1))
    except (TypeError, ValueError):
        redirect(URL('payroll', 'index'))
    if not (1 <= pay_month <= 12 and 2000 <= pay_year <= 2100):
        redirect(URL('payroll', 'index'))
    sc = screens_rules(7003)
    # json.dumps لا response.json: الأخيرة تجعل نوع الصفحة كلها application/json فلا يعرضها المتصفح
    pm_config = json.dumps({
        "base": URL('payroll', 'index').rsplit('/', 1)[0] + '/',
        "salaries": URL('salaries', 'index'),
        "month": pay_month, "year": pay_year,
    }).replace("</", "<\\/")
    return dict(pay_month=pay_month, pay_year=pay_year, month_name=_MONTHS[pay_month - 1],
                can_salaries=bool(sc and sc.can_log_in), pm_config=pm_config)


@can_access(7006)
def print_month():
    """Read-only, complete monthly payroll with every allowance/deduction."""
    from datetime import datetime, timedelta, timezone
    from decimal import Decimal

    try:
        pay_month, pay_year = int(request.args(0)), int(request.args(1))
    except (TypeError, ValueError):
        raise HTTP(400, "فترة الرواتب غير صحيحة")
    if not (1 <= pay_month <= 12 and 2000 <= pay_year <= 2100):
        raise HTTP(400, "فترة الرواتب غير صحيحة")

    period = db((db.payroll_period.pay_month == pay_month) &
                (db.payroll_period.pay_year == pay_year)).select().first()
    if not period:
        raise HTTP(404, "فترة الرواتب غير موجودة")

    # One joined snapshot: no pagination, search filter or per-employee requests.
    rows = db((db.payroll.pay_month == pay_month) &
              (db.payroll.pay_year == pay_year)).select(
        db.payroll.id, db.payroll.employee, db.payroll.basic_salary,
        db.employees.emp_name, db.payroll_detail.id,
        db.payroll_detail.amount, db.payroll_detail.notes,
        db.key_allowance_deduction.name, db.key_allowance_deduction.ad_type,
        left=[db.employees.on(db.employees.id == db.payroll.employee),
              db.payroll_detail.on(db.payroll_detail.payroll_id == db.payroll.id),
              db.key_allowance_deduction.on(
                  db.key_allowance_deduction.id == db.payroll_detail.allowance_deduction)],
        orderby=~db.payroll.id | db.payroll_detail.id,
    )
    payrolls = {}
    for row in rows:
        p, detail, ad = row.payroll, row.payroll_detail, row.key_allowance_deduction
        if p.id not in payrolls:
            payrolls[p.id] = dict(
                id=p.id, employee=p.employee,
                emp_name=row.employees.emp_name or "موظف غير متاح",
                basic_salary=Decimal(str(p.basic_salary or 0)),
                total_allowances=Decimal('0'), total_deductions=Decimal('0'),
                details=[],
            )
        item = payrolls[p.id]
        if detail.id:
            amount = Decimal(str(detail.amount or 0))
            item['details'].append(dict(
                name=ad.name or "بند غير مصنف", ad_type=ad.ad_type or "غير مصنف",
                amount=amount, notes=detail.notes or '',
            ))
            if ad.ad_type == 'بدل':
                item['total_allowances'] += amount
            elif ad.ad_type == 'خصم':
                item['total_deductions'] += amount

    totals = dict.fromkeys(('basic_salary', 'total_allowances', 'total_deductions', 'net_salary'), Decimal('0'))
    for item in payrolls.values():
        item['net_salary'] = item['basic_salary'] + item['total_allowances'] - item['total_deductions']
        for key in totals:
            totals[key] += item[key]
    response.headers['Cache-Control'] = 'no-store'
    return dict(
        payrolls=list(payrolls.values()), totals=totals, period=period,
        period_label='%s %s' % (_MONTHS[pay_month - 1], pay_year),
        configuration=db(db.important_info.id > 0).select().first(),
        printed_at=datetime.now(timezone(timedelta(hours=3))).strftime('%Y/%m/%d %H:%M'),
        money=lambda value: format(value, ',.2f'),
    )


@can_access(7006)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    ad_types = db(db.key_allowance_deduction.id > 0).select(
        db.key_allowance_deduction.id,
        db.key_allowance_deduction.name,
        db.key_allowance_deduction.ad_type,
        orderby=db.key_allowance_deduction.name
    )
    return response.json(api.api_ok(data={
        "employees": employees,
        "ad_types": ad_types,
    }))


@can_access(7006)
def get_periods():
    ReqVar = request.vars

    conditions = []
    params = []

    if ReqVar.year_filter and ReqVar.year_filter != '0':
        conditions.append("( pp.pay_year = %s )")
        params.append(int(ReqVar.year_filter))

    if ReqVar.status_filter == 'approved':
        conditions.append("( pp.is_approved = 'T' )")
    elif ReqVar.status_filter == 'not_approved':
        conditions.append("( pp.is_approved = 'F' OR pp.is_approved IS NULL )")

    allowed_sort_columns = {'pay_month', 'pay_year'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'pay_year'
    sort_map = {
        'pay_month': 'pp.pay_month',
        'pay_year': 'pp.pay_year',
    }
    sort_col = sort_map.get(sc, 'pp.pay_year')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT pp.id, pp.pay_month, pp.pay_year, pp.is_approved, "
        f"COALESCE(("
        f"  SELECT COUNT(*) FROM payroll p WHERE p.pay_month = pp.pay_month AND p.pay_year = pp.pay_year"
        f"), 0) AS emp_count, "
        f"COALESCE(("
        f"  SELECT SUM(p.net_salary) FROM payroll p WHERE p.pay_month = pp.pay_month AND p.pay_year = pp.pay_year"
        f"), 0) AS total_net "
        f"FROM payroll_period pp "
        f"{where} ORDER BY {sort_col} {sa}, pp.pay_month DESC"
    )

    qry = db.executesql(sql, placeholders=params if params else None, as_dict=True)
    return response.json(api.api_ok(data=qry))


@can_access(7006)
def new_period():
    _post_only()
    try:
        data = request.vars
        errors, pay_month, pay_year = _parse_payroll_period(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        existing = db((db.payroll_period.pay_month == pay_month) &
                       (db.payroll_period.pay_year == pay_year)).select().first()
        if existing:
            return response.json(api.api_error(mess="توجد فترة لنفس الشهر والسنة"))

        db.payroll_period.insert(
            pay_month=pay_month,
            pay_year=pay_year,
            is_approved=False,
        )
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def approve_period():
    """الاعتماد يسجّل «خصم سلفة» في سجل سداد السلف، وإلغاؤه يعكسه (modules/advance_ledger.py).
    كلاهما آمن للتكرار: لا خصم مكرر عند إعادة الاعتماد."""
    _post_only()
    try:
        data = request.vars
        row = db.payroll_period[data.id]
        if not row:
            return response.json(api.api_error(mess="الفترة غير موجودة"))
        # يسلسل اعتماد الفترة نفسها وإلغاءه بين طلبين متزامنين
        db.executesql("SELECT id FROM payroll_period WHERE id = %s FOR UPDATE", placeholders=[row.id])
        row = db.payroll_period[row.id]

        is_approved = (data.is_approved == 'true')
        today = request.now.date()
        mess = ""
        if is_approved:
            res = advance_ledger.apply_period(db, row, today)
            if res["amount"]:
                mess = "خُصم من السلف %.2f" % res["amount"]
            if res["excess"]:
                names = {e.id: e.emp_name for e in db(db.employees.id.belongs(
                    [e for e, _ in res["excess"]])).select(db.employees.id, db.employees.emp_name)}
                mess += (" — تنبيه: «خصم سلفة» أكبر من المتبقي على: " + "، ".join(
                    "%s (%.2f)" % (names.get(e, e), v) for e, v in res["excess"]))
        else:
            res = advance_ledger.reverse_period(db, row, today)
            if res["amount"]:
                mess = "أُعيد إلى أرصدة السلف %.2f" % res["amount"]

        row.update_record(is_approved=is_approved)
        db.commit()
        return response.json(api.api_ok(data=res, mess=mess.strip(" —")))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


def _period_approved(pay_month, pay_year):
    return not db((db.payroll_period.pay_month == pay_month) & (db.payroll_period.pay_year == pay_year)
                  & (db.payroll_period.is_approved == True)).isempty()


@can_access(7006)
def delete_period():
    _post_only()
    try:
        row = db.payroll_period[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="الفترة غير موجودة"))
        if row.is_approved:
            return response.json(api.api_error(
                mess="الفترة معتمدة؛ ألغِ اعتمادها أولاً حتى تُعكس خصومات السلف"))

        # حذف جميع مسيرات هذه الفترة وتفاصيلها
        payrolls = db((db.payroll.pay_month == row.pay_month) &
                       (db.payroll.pay_year == row.pay_year)).select()
        for p in payrolls:
            db(db.payroll_detail.payroll_id == p.id).delete()
            p.delete_record()

        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def get_payrolls():
    ReqVar = request.vars
    try:
        pg = max(int(ReqVar.page or 0), 0)
        rc = min(max(int(ReqVar.RecordCount or 20), 1), 100)
    except (TypeError, ValueError):
        pg, rc = 0, 20

    conditions = []
    params = []

    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append("( emp.emp_name LIKE %s )")
            params.append(pattern)

    try:
        emp_filter = int(ReqVar.emp_filter or 0)
        month_filter = int(ReqVar.month_filter or 0)
        year_filter = int(ReqVar.year_filter or 0)
    except (TypeError, ValueError):
        emp_filter = month_filter = year_filter = 0
    if emp_filter:
        conditions.append("( p.employee = %s )")
        params.append(emp_filter)
    if month_filter:
        conditions.append("( p.pay_month = %s )")
        params.append(month_filter)
    if year_filter:
        conditions.append("( p.pay_year = %s )")
        params.append(year_filter)

    sort_map = {
        'id': 'id',
        'emp_name': 'emp_name',
        'pay_month': 'pay_month',
        'pay_year': 'pay_year',
        'basic_salary': 'basic_salary',
        'total_allowances': 'total_allowances',
        'total_deductions': 'total_deductions',
        'net_salary': 'net_salary',
        'advance_remaining': 'advance_remaining',
    }
    sort_col = sort_map.get(ReqVar.SortBy, 'id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    cte = _PAYROLL_CTE.replace("{where}", _payroll_where(conditions))
    flag_where = (" WHERE " + _FLAG_FILTERS[ReqVar.flag]) if ReqVar.flag in _FLAG_FILTERS else ""
    base_params = [_deduction_id()] + params

    qry = db.executesql(
        cte + "SELECT * FROM g" + flag_where + " ORDER BY " + sort_col + " " + sa + ", id " + sa
        + " LIMIT %s OFFSET %s", placeholders=base_params + [rc, pg * rc], as_dict=True)
    totals = db.executesql(
        cte + "SELECT COUNT(*) AS count, COALESCE(SUM(basic_salary), 0) AS basic_salary,"
        " COALESCE(SUM(total_allowances), 0) AS total_allowances,"
        " COALESCE(SUM(total_deductions), 0) AS total_deductions,"
        " COALESCE(SUM(net_salary), 0) AS net_salary,"
        " COUNT(*) FILTER (WHERE level = 'danger') AS danger,"
        " COUNT(*) FILTER (WHERE level = 'warning') AS warning FROM g" + flag_where,
        placeholders=base_params, as_dict=True)[0]

    extra = {"totals": totals}
    if 1 <= month_filter <= 12 and year_filter:
        # حالة الفترة ومن لم يُضَف بعد من الموظفين (مثل «إضافة جميع الموظفين»)
        period = db.executesql(
            "SELECT id, COALESCE(is_approved, 'F') = 'T' AS is_approved FROM payroll_period "
            "WHERE pay_month = %s AND pay_year = %s ORDER BY id LIMIT 1",
            placeholders=[month_filter, year_filter], as_dict=True)
        missing = db.executesql(
            "SELECT COUNT(*) FROM employees e WHERE NOT EXISTS (SELECT 1 FROM payroll p "
            "WHERE p.employee = e.id AND p.pay_month = %s AND p.pay_year = %s)",
            placeholders=[month_filter, year_filter])[0][0]
        in_month = [r[0] for r in db.executesql(
            "SELECT DISTINCT employee FROM payroll WHERE pay_month = %s AND pay_year = %s",
            placeholders=[month_filter, year_filter])]
        extra["period"] = dict(period[0] if period else {"id": None, "is_approved": False},
                               month_name=_MONTHS[month_filter - 1], missing=missing, in_month=in_month)
    return response.json(api.api_list(rows=qry, count=totals["count"], **extra))


@can_access(7006)
def get_payroll_card():
    """بطاقة مسير موظف في الشهر: المجاميع، البنود، المقارنة بهيكل راتبه الحالي، والسلف."""
    try:
        payroll_id = int(request.args(0))
    except (TypeError, ValueError):
        payroll_id = 0
    cte = _PAYROLL_CTE.replace("{where}", " WHERE p.id = %s")
    rows = db.executesql(cte + "SELECT * FROM g", placeholders=[_deduction_id(), payroll_id], as_dict=True)
    if not rows:
        return response.json(api.api_error(mess="المسير غير موجود"))
    p = rows[0]
    emp = db.executesql(
        "SELECT e.id_number, e.mobile, st.name AS status_name FROM employees e "
        "LEFT JOIN key_emp_status st ON st.id = e.emp_status WHERE e.id = %s",
        placeholders=[p["employee"]], as_dict=True)[0]
    items = db.executesql(
        "SELECT pd.id, pd.allowance_deduction, COALESCE(pd.amount, 0) AS amount, COALESCE(pd.notes, '') AS notes, "
        "ad.name AS ad_name, ad.ad_type FROM payroll_detail pd "
        "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        "WHERE pd.payroll_id = %s ORDER BY ad.name, pd.id",
        placeholders=[payroll_id], as_dict=True)
    structure = None
    if p["structure_id"]:
        allow, deduct = db.executesql(
            "SELECT COALESCE(SUM(CASE WHEN ad.ad_type = 'بدل' THEN sd.amount ELSE 0 END), 0), "
            "COALESCE(SUM(CASE WHEN ad.ad_type = 'خصم' THEN sd.amount ELSE 0 END), 0) "
            "FROM emp_salary_detail sd JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
            "WHERE sd.employee = %s", placeholders=[p["employee"]])[0]
        structure = {"basic": p["structure_basic"], "allowances": allow, "deductions": deduct,
                     "net": p["structure_basic"] + allow - deduct}

    alerts = []
    if p["f_negative"]:
        alerts.append({"level": "warn", "text": "الخصومات أكبر من الراتب، فالصافي سالب"})
    if p["f_excess"]:
        alerts.append({"level": "warn", "text": "«خصم سلفة» %.2f أكبر من المتبقي على سلفه %.2f؛ "
                                                "لا يُخصم عند الاعتماد إلا المتبقي" % (
                                                    p["advance_deduction"], p["advance_remaining"])})
    if p["f_no_installment"]:
        alerts.append({"level": "info", "text": "عليه سلف متبقية %.2f ولا يوجد «خصم سلفة» في هذا المسير" % (
            p["advance_remaining"])})
    if not structure:
        alerts.append({"level": "info", "text": "لا يوجد له راتب مسجل في شاشة الرواتب"})
    elif p["f_structure"]:
        alerts.append({"level": "info", "text": "الأساسي في المسير %.2f، وفي هيكل راتبه الحالي %.2f" % (
            p["basic_salary"], structure["basic"])})
    status = emp["status_name"] or ""
    if status and status not in ("على رأس العمل", "في إجازة"):
        alerts.append({"level": "warn", "text": "حالة الموظف في بياناته «%s»" % status})

    return response.json(api.api_ok(data={
        "payroll": p,
        "month_name": _MONTHS[p["pay_month"] - 1] if 1 <= (p["pay_month"] or 0) <= 12 else p["pay_month"],
        "employee": emp,
        "items": items,
        "structure": structure,
        "alerts": alerts,
    }))


@can_access(7006)
def add_all_employees():
    """إضافة جميع الموظفين للمسير دفعة واحدة"""
    _post_only()
    try:
        data = request.vars
        errors, pay_month, pay_year = _parse_payroll_period(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        locked = _locked_period(pay_month, pay_year)
        if locked:
            return response.json(api.api_error(mess=locked))

        # جلب جميع الموظفين
        employees = db(db.employees.id > 0).select(db.employees.id)
        added = 0
        skipped = 0

        for emp in employees:
            employee_id = emp.id

            # فحص عدم التكرار
            existing = db((db.payroll.employee == employee_id) &
                           (db.payroll.pay_month == pay_month) &
                           (db.payroll.pay_year == pay_year)).select().first()
            if existing:
                skipped += 1
                continue

            # جلب الراتب الأساسي
            salary = db(db.emp_salary.employee == employee_id).select().first()
            basic_salary = float(salary.basic_salary) if salary else 0

            pid = db.payroll.insert(
                employee=employee_id,
                pay_month=pay_month,
                pay_year=pay_year,
                basic_salary=basic_salary,
                net_salary=basic_salary,
            )

            # نسخ البدلات والخصومات من emp_salary_detail
            details = db(db.emp_salary_detail.employee == employee_id).select()
            total_allow = 0
            total_deduct = 0
            for d in details:
                db.payroll_detail.insert(
                    payroll_id=pid,
                    allowance_deduction=d.allowance_deduction,
                    amount=float(d.amount or 0),
                    notes=d.notes or '',
                )
                ad = db.key_allowance_deduction(d.allowance_deduction)
                if ad and ad.ad_type == 'بدل':
                    total_allow += float(d.amount or 0)
                elif ad and ad.ad_type == 'خصم':
                    total_deduct += float(d.amount or 0)

            net = basic_salary + total_allow - total_deduct
            db(db.payroll.id == pid).update(net_salary=net)
            added += 1

        db.commit()
        return response.json(api.api_ok(data={
            "added": added,
            "skipped": skipped,
        }))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def new_payroll():
    _post_only()
    try:
        data = request.vars
        employee_id = _valid_employee_id(data.employee)
        if not employee_id:
            return response.json(api.api_error(mess="الموظف غير موجود"))
        errors, pay_month, pay_year = _parse_payroll_period(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        locked = _locked_period(pay_month, pay_year)
        if locked:
            return response.json(api.api_error(mess=locked))

        # فحص عدم التكرار
        existing = db((db.payroll.employee == employee_id) &
                       (db.payroll.pay_month == pay_month) &
                       (db.payroll.pay_year == pay_year)).select().first()
        if existing:
            return response.json(api.api_error(mess="يوجد مسير لهذا الموظف في نفس الشهر والسنة"))

        # جلب الراتب الأساسي من emp_salary
        salary = db(db.emp_salary.employee == employee_id).select().first()
        basic_salary = float(salary.basic_salary) if salary else 0

        pid = db.payroll.insert(
            employee=employee_id,
            pay_month=pay_month,
            pay_year=pay_year,
            basic_salary=basic_salary,
            net_salary=basic_salary,
        )

        # نسخ البدلات والخصومات من emp_salary_detail
        details = db(db.emp_salary_detail.employee == employee_id).select()
        total_allow = 0
        total_deduct = 0
        for d in details:
            db.payroll_detail.insert(
                payroll_id=pid,
                allowance_deduction=d.allowance_deduction,
                amount=float(d.amount or 0),
                notes=d.notes or '',
            )
            ad = db.key_allowance_deduction(d.allowance_deduction)
            if ad and ad.ad_type == 'بدل':
                total_allow += float(d.amount or 0)
            elif ad and ad.ad_type == 'خصم':
                total_deduct += float(d.amount or 0)

        # تحديث الإجمالي
        net = basic_salary + total_allow - total_deduct
        db(db.payroll.id == pid).update(net_salary=net)
        db.commit()

        return response.json(api.api_ok(data={"id": pid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def update_payroll():
    _post_only()
    try:
        data = request.vars
        row = db.payroll[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        locked = _locked_period(row.pay_month, row.pay_year)
        if locked:
            return response.json(api.api_error(mess=locked))

        basic_salary = _amount_value(data.basic_salary or 0, allow_zero=True)
        if basic_salary is None:
            return response.json(api.api_error(mess="الراتب الأساسي لا يمكن أن يكون سالباً"))

        row.update_record(basic_salary=basic_salary)
        _recalc_net(row.id)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def get_payroll_details():
    payroll_id = request.args(0)
    if not payroll_id:
        return response.json(api.api_ok(data=[]))

    sql = (
        "SELECT pd.id, pd.payroll_id, pd.allowance_deduction, pd.amount, pd.notes, "
        "ad.name AS ad_name, ad.ad_type "
        "FROM payroll_detail pd "
        "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        "WHERE pd.payroll_id = %s "
        "ORDER BY ad.ad_type, ad.name"
    )
    qry = db.executesql(sql, placeholders=[payroll_id], as_dict=True)
    return response.json(api.api_ok(data=qry))


@can_access(7006)
def add_detail():
    _post_only()
    try:
        data = request.vars
        try:
            payroll_id = int(data.payroll_id)
        except (TypeError, ValueError):
            return response.json(api.api_error(mess="المسير غير موجود"))
        payroll = db.payroll(payroll_id)
        if not payroll:
            return response.json(api.api_error(mess="المسير غير موجود"))
        locked = _locked_period(payroll.pay_month, payroll.pay_year)
        if locked:
            return response.json(api.api_error(mess=locked))
        allowance_deduction = _valid_allowance_deduction_id(data.allowance_deduction)
        if not allowance_deduction:
            return response.json(api.api_error(mess="البند غير موجود"))
        amount = _amount_value(data.amount)
        if amount is None:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        db.payroll_detail.insert(
            payroll_id=payroll_id,
            allowance_deduction=allowance_deduction,
            amount=amount,
            notes=data.notes or '',
        )
        _recalc_net(payroll_id)
        db.commit()
        return response.json(api.api_ok(data={"id": payroll_id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def update_detail():
    _post_only()
    try:
        data = request.vars
        row = db.payroll_detail[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        payroll = db.payroll(row.payroll_id)
        locked = payroll and _locked_period(payroll.pay_month, payroll.pay_year)
        if locked:
            return response.json(api.api_error(mess=locked))
        allowance_deduction = _valid_allowance_deduction_id(data.allowance_deduction)
        if not allowance_deduction:
            return response.json(api.api_error(mess="البند غير موجود"))
        amount = _amount_value(data.amount)
        if amount is None:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        row.update_record(
            allowance_deduction=allowance_deduction,
            amount=amount,
            notes=data.notes or '',
        )
        _recalc_net(row.payroll_id)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def delete_detail():
    _post_only()
    try:
        row = db.payroll_detail[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        pid = row.payroll_id
        payroll = db.payroll(pid)
        locked = payroll and _locked_period(payroll.pay_month, payroll.pay_year)
        if locked:
            return response.json(api.api_error(mess=locked))
        row.delete_record()
        _recalc_net(pid)
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7006)
def delete_payroll():
    _post_only()
    try:
        row = db.payroll[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if _period_approved(row.pay_month, row.pay_year):
            return response.json(api.api_error(
                mess="فترة هذا المسير معتمدة؛ ألغِ اعتمادها أولاً حتى تُعكس خصومات السلف"))
        db(db.payroll_detail.payroll_id == row.id).delete()
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


def _recalc_net(payroll_id):
    """إعادة حساب إجمالي الراتب"""
    row = db.payroll[payroll_id]
    if not row:
        return
    result = db.executesql(
        "SELECT "
        "COALESCE(SUM(CASE WHEN ad.ad_type = 'بدل' THEN pd.amount ELSE 0 END), 0) AS allow_sum, "
        "COALESCE(SUM(CASE WHEN ad.ad_type = 'خصم' THEN pd.amount ELSE 0 END), 0) AS deduct_sum "
        "FROM payroll_detail pd "
        "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        "WHERE pd.payroll_id = %s",
        placeholders=[payroll_id], as_dict=True
    )
    allow_sum = float(result[0]['allow_sum']) if result else 0
    deduct_sum = float(result[0]['deduct_sum']) if result else 0
    net = float(row.basic_salary or 0) + allow_sum - deduct_sum
    row.update_record(net_salary=net)
