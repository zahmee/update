# -*- coding: utf-8 -*-
import sys
import psycopg2
import psycopg2.extras
import psycopg2.extensions
import os
import datetime
import math
import _db_config

THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))
my_file = os.path.join(THIS_FOLDER, "reorder_run_result.txt")
text_file = open(my_file, "w")
text_file.write("===============================")
text_file.write("\n")
text_file.write(str(sys.argv[1]))
text_file.write("\n")
text_file.write("===============================")
text_file.write("\n")
text_file.write(datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
text_file.write("\n")
text_file.write("open script ")
text_file.write("\n")
psycopg2.extensions.register_type(psycopg2.extensions.UNICODE)
psycopg2.extensions.register_type(psycopg2.extensions.UNICODEARRAY)
if sys.argv[1]:
    conn = psycopg2.connect(_db_config.get_conn_string(sys.argv[2]))
    conn.set_client_encoding("utf-8")
    ReOrderId = sys.argv[1]
    try:
        text_file.write("connect to database ok ")
        text_file.write("\n")
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute("SELECT * FROM items_reorder where id=%s", (ReOrderId,))
            Order = cur.fetchone()
            start_time = datetime.datetime.now().strftime("%H:%M:%S")
            avrg_by = Order["avrg_by"]

            # ── بناء شرط الفلتر على items_main ──────────────────────────────
            if (Order["supplier"]) and (Order["key_type"]):
                items_filter = "im.suppliers = %s AND im.item_type = %s"
                filter_params = (Order["supplier"], Order["key_type"])
            elif Order["key_type"] is not None:
                items_filter = "im.item_type = %s"
                filter_params = (Order["key_type"],)
            elif Order["supplier"] != "":
                items_filter = "im.suppliers = %s"
                filter_params = (Order["supplier"],)
            else:
                items_filter = "TRUE"
                filter_params = ()

            # ── استعلام CTE واحد يجمع كل البيانات دفعة واحدة ───────────────
            # بدلاً من 3 استعلامات × عدد الأصناف
            big_query = f"""
                WITH filtered_items AS (
                    SELECT id, suppliers, item_type
                    FROM items_main im
                    WHERE {items_filter}
                ),
                current_stock AS (
                    SELECT d.item_idr,
                           COALESCE(SUM(d.items_count), 0) AS total_stock
                    FROM items_det d
                    WHERE d.item_idr IN (SELECT id FROM filtered_items)
                    GROUP BY d.item_idr
                ),
                pending_returns AS (
                    SELECT det.item_idr,
                           COALESCE(SUM(rsd.item_count), 0) AS return_qty
                    FROM returned_supply_det rsd
                    JOIN returned_supply rs ON rs.id = rsd.returned_supply
                    JOIN items_det det ON det.id = CAST(rsd.item_id AS INTEGER)
                    WHERE (rs.admin_accept = 'F' OR rs.admin_accept IS NULL)
                      AND det.item_idr IN (SELECT id FROM filtered_items)
                    GROUP BY det.item_idr
                ),
                avg_sales AS (
                    SELECT d.item_idr,
                           COALESCE(SUM(inv.item_count), 0) AS total_sales
                    FROM invoice_details inv
                    JOIN items_det d ON d.id = inv.item_number
                    WHERE d.item_idr IN (SELECT id FROM filtered_items)
                      AND inv.created_on > date_trunc('month', CURRENT_DATE)
                                          - (%s * INTERVAL '1 month')
                    GROUP BY d.item_idr
                ),
                best_prices AS (
                    SELECT d.item_idr,
                           MIN(d.buy_price) AS best_price
                    FROM items_det d
                    WHERE d.item_idr IN (SELECT id FROM filtered_items)
                      AND d.buy_price > 0
                      AND d.created_on > date_trunc('month', CURRENT_DATE)
                                         - (%s * INTERVAL '1 month')
                    GROUP BY d.item_idr
                )
                SELECT
                    fi.id,
                    fi.suppliers,
                    fi.item_type,
                    COALESCE(cs.total_stock, 0) - COALESCE(pr.return_qty, 0) AS current_stock,
                    COALESCE(avs.total_sales, 0) AS total_sales,
                    COALESCE(bp.best_price,   0) AS best_price
                FROM filtered_items fi
                LEFT JOIN current_stock    cs  ON cs.item_idr  = fi.id
                LEFT JOIN pending_returns  pr  ON pr.item_idr  = fi.id
                LEFT JOIN avg_sales        avs ON avs.item_idr = fi.id
                LEFT JOIN best_prices      bp  ON bp.item_idr  = fi.id
                ORDER BY fi.id
            """
            cur.execute(big_query, filter_params + (avrg_by, avrg_by))
            all_items = cur.fetchall()
            row_count = len(all_items)

            # ── حذف التفاصيل القديمة ─────────────────────────────────────────
            cur.execute(
                "DELETE FROM items_reorder_detail WHERE items_reorder = %s",
                (Order["id"],),
            )
            conn.commit()

            text_file.write(
                "get all items to work :"
                + datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
            )
            text_file.write("\n")

            # ── حساب القيم وتجميع الإدخالات في قائمة واحدة ──────────────────
            insert_rows = []
            for row in all_items:
                sum_row    = round(float(row["current_stock"]), 2)
                avrg_item  = ((row["total_sales"] or 0) / avrg_by) or 0
                best_price = round(float(row["best_price"] or 0), 2)

                order_items = (avrg_item * Order["order_by"]) - sum_row
                if order_items < (avrg_item / 2):
                    order_items = 0
                if order_items < 0:
                    order_items = 0

                insert_rows.append((
                    Order["id"],
                    row["id"],
                    row["suppliers"],   # قد يكون None → يُحفظ كـ NULL
                    row["item_type"],   # قد يكون None → يُحفظ كـ NULL
                    sum_row,
                    round(avrg_item, 2),
                    math.ceil(order_items),
                    best_price,
                ))

            # ── إدخال جماعي واحد بدلاً من إدخال لكل صنف على حدة ────────────
            cur.executemany(
                """
                INSERT INTO items_reorder_detail
                    (items_reorder, items_main, supplier, key_type,
                     quantity, avrg_items, order_items, best_price)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """,
                insert_rows,
            )
            conn.commit()   # commit واحد فقط بعد كل الإدخالات

            end_time = datetime.datetime.now().strftime("%H:%M:%S")
            cur.execute(
                "UPDATE items_reorder SET jop_end_time=%s, jop_start_time=%s, row_count=%s WHERE id=%s",
                (end_time, start_time, row_count, ReOrderId),
            )
            conn.commit()

            text_file.write("write to database ok ")
            text_file.write("\n")
            text_file.write("finsh all the work .")
            text_file.write("\n")
            text_file.write(datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
            text_file.write("\n")

        conn.close()
    except:
        print("Unexpected error:", sys.exc_info())
        my_file2 = os.path.join(THIS_FOLDER, "reorder_err.txt")
        text_file2 = open(my_file2, "w")
        text_file2.write(str(sys.exc_info()[0]))
        text_file2.write("\n")
        text_file2.write(str(sys.exc_info()))
        text_file2.close()
    finally:
        if conn is not None:
            conn.close()
    text_file.close()
