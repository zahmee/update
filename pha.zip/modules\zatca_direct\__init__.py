# -*- coding: utf-8 -*-
"""
zatca_direct - Direct ZATCA Phase 2 Integration
No external proxy needed - connects directly to ZATCA API.
"""

from zatca_direct.csr import generate_keys_and_csid, build_zatca_urls
from zatca_direct.onboarding import run_onboarding
from zatca_direct.invoice_processor import process_invoice
