(function () {
  'use strict';

  var hub = document.getElementById('setup-hub');
  if (!hub) return;

  var search = hub.querySelector('#setup-search');
  var clearSearch = hub.querySelector('#setup-clear-search');
  var resultLabel = hub.querySelector('#setup-results');
  var emptyState = hub.querySelector('#setup-empty');
  var filters = Array.from(hub.querySelectorAll('[data-setup-filter]'));
  var selectedGroup = 'all';
  var digits = '٠١٢٣٤٥٦٧٨٩';

  function normalize(text) {
    return text.toLowerCase()
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/ة/g, 'ه');
  }

  function arabicNumber(number) {
    return String(number).replace(/[0-9]/g, function (digit) { return digits[Number(digit)]; });
  }

  var groups = Array.from(hub.querySelectorAll('[data-setup-group]')).map(function (element) {
    return {
      element: element,
      key: element.dataset.setupGroup,
      count: element.querySelector('.setup-group-count'),
      items: Array.from(element.querySelectorAll('[data-setup-item]')).map(function (item) {
        return { element: item, text: normalize(item.dataset.setupSearch || item.textContent) };
      })
    };
  });

  function update() {
    var query = normalize(search.value).trim();
    var words = query ? query.split(/\s+/) : [];
    var total = 0;

    groups.forEach(function (group) {
      var inSelectedGroup = selectedGroup === 'all' || selectedGroup === group.key;
      var visibleCount = 0;
      group.items.forEach(function (item) {
        var visible = inSelectedGroup && words.every(function (word) { return item.text.indexOf(word) !== -1; });
        item.element.hidden = !visible;
        if (visible) visibleCount += 1;
      });
      group.element.hidden = visibleCount === 0;
      if (group.count) group.count.textContent = arabicNumber(visibleCount);
      total += visibleCount;
    });

    filters.forEach(function (button) {
      var active = button.dataset.setupFilter === selectedGroup;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    clearSearch.hidden = search.value.length === 0;
    emptyState.hidden = total !== 0;
    resultLabel.textContent = 'النتائج: ' + arabicNumber(total);
  }

  filters.forEach(function (button) {
    button.addEventListener('click', function () {
      selectedGroup = button.dataset.setupFilter;
      update();
    });
  });

  search.addEventListener('input', update);
  search.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && search.value) {
      event.preventDefault();
      search.value = '';
      update();
    }
  });

  clearSearch.addEventListener('click', function () {
    search.value = '';
    update();
    search.focus();
  });

  hub.querySelector('#setup-reset-filters').addEventListener('click', function () {
    search.value = '';
    selectedGroup = 'all';
    update();
    search.focus();
  });

  hub.classList.add('is-enhanced');
  hub.querySelectorAll('[data-setup-controls]').forEach(function (control) { control.hidden = false; });
  update();
})();
