Vue.component('v-select', VueSelect.VueSelect);

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data2: [],
        account: '',
        start_date: {
            day: 1,
            month: 1,
            year: 2019
        },
        end_date: {
            day: 31,
            month: 12,
            year: 2019
        },
        suppliers: [],
    },
    created: function () {
        var start = new Date();
        var end = new Date(start.getFullYear(), start.getMonth() + 1, 0);
        this.start_date.month = start.getMonth() + 1;
        this.start_date.year = start.getFullYear();
        this.end_date.month = start.getMonth() + 1;
        this.end_date.year = start.getFullYear();
        this.end_date.day = end.getDate();

        this.$http.get(purl + '/../../api_1/min_suppliers_1').then(response => {
            if (Api.isOk(response.body)) {
                this.suppliers = Api.getData(response.body);
            }
        });
    },
    methods: {
        show4() {
            var report_data = {};
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep4?da1=" + report_data.start_date + "&da2=" + report_data.end_date, '_blank');
        },
        show3() {
            if (!this.account) {
                Swal.fire('تنبيه', 'يجب اختيار المورد لعرض التقرير !!', 'error');
                return;
            }
            var report_data = {};
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep3?da1=" + report_data.start_date + "&da2=" + report_data.end_date + "&sup=" + this.account.id, '_blank');
        },
        show2() {
            if (!this.account) {
                Swal.fire('تنبيه', 'يجب اختيار المورد لعرض التقرير !!', 'error');
                return;
            }
            var report_data = {};
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep2?da1=" + report_data.start_date + "&da2=" + report_data.end_date + "&sup=" + this.account.id, '_blank');
        },
        show5() {
            if (!this.account) {
                Swal.fire('تنبيه', 'يجب اختيار المورد لعرض التقرير !!', 'error');
                return;
            }
            var report_data = {};
            report_data.start_date = [this.start_date.day, this.start_date.month, this.start_date.year];
            report_data.end_date = [this.end_date.day, this.end_date.month, this.end_date.year];
            window.open(purl + "/../rep5?da1=" + report_data.start_date + "&da2=" + report_data.end_date + "&sup=" + this.account.id, '_blank');
        },
        show6() {
            if (!this.account) {
                Swal.fire('تنبيه', 'يجب اختيار المورد لعرض التقرير !!', 'error');
                return;
            }
            window.open(purl + "/../supplier_items_sales/" + this.account.id, '_blank');
        },
    }
});
