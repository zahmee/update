// من الخادم لا من location.href، فيبقى صحيحاً مع ?leave_id=<id> في العنوان
var API_BASE = LV_BASE;

var STATE_LABELS = { current: 'جارية', upcoming: 'قادمة', ended: 'منتهية', unknown: 'بلا تاريخ' };

function postForm(url, fields) {
    var body = new FormData();
    Object.keys(fields || {}).forEach(function (k) {
        body.append(k, fields[k] === null || fields[k] === undefined ? '' : fields[k]);
    });
    return fetch(url, { method: 'POST', body: body }).then(function (r) { return r.json(); });
}

function toast(text) {
    Swal.fire({ toast: true, position: 'top', icon: 'success', title: text, timer: 2500, showConfirmButton: false });
}

// عدد الأيام بقواعد العربية: يوم، يومان، 3-10 أيام، 11 فأكثر يوماً
function daysText(n) {
    n = Math.abs(parseInt(n, 10) || 0);
    if (n === 1) return 'يوم';
    if (n === 2) return 'يومان';
    return n + (n >= 3 && n <= 10 ? ' أيام' : ' يوماً');
}

function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function calendarDays(start, end) {
    if (!start || !end) return 0;
    var diff = Math.round((new Date(end + 'T00:00:00') - new Date(start + 'T00:00:00')) / 86400000);
    return diff >= 0 ? diff + 1 : 0;
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        totals: { count: 0, current: 0, upcoming: 0, days: 0 },
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            state: '',
            dues: '',
            SortBy: 'start_date',
            sortAsc: false,
        },
        data_row_count: 0,
        listSeq: 0,
        searchTimer: null,
        loading: false,
        employees_list: [],
        selectedRow: -1,
        // بطاقة الإجازة
        card: null,
        cardId: null,
        cardLoading: false,
        cardError: '',
        cardSeq: 0,
        cardTrigger: null,
        pendingModal: null,
        returnToCard: false,
        pendingCard: null,
        busy: false,
        // نافذة الإضافة والتعديل
        new_row: true,
        edit_row_data: {},
        saving: false,
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        pageDays: function () {
            return this.data.reduce(function (s, r) { return s + (parseInt(r.days_count, 10) || 0); }, 0);
        },
        cardTitle: function () {
            if (this.card) return this.card.leave.emp_name;
            var row = this.data.find(function (r) { return r.id === this.cardId; }.bind(this));
            return row ? row.emp_name : 'بطاقة الإجازة';
        },
        formCalendarDays: function () {
            return calendarDays(this.edit_row_data.start_date, this.edit_row_data.end_date);
        },
        formDaysDiffer: function () {
            var days = parseInt(this.edit_row_data.days_count, 10);
            return !!this.formCalendarDays && !!days && days !== this.formCalendarDays;
        },
    },
    created: function () {
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.employees_list = (Api.getData(data) || {}).employees || [];
            }.bind(this));
        this.reload().then(function () {
            // رابط مباشر: leaves/index?leave_id=<رقم الإجازة> يفتح بطاقتها
            var id = parseInt(new URLSearchParams(window.location.search).get('leave_id'), 10);
            if (id > 0) this.openCard(id);
        }.bind(this));
    },
    mounted: function () {
        var cardEl = document.getElementById('leaveCardModal');
        cardEl.addEventListener('shown.bs.modal', function () {
            // يتجاهل Bootstrap الإغلاق أثناء حركة الفتح، فيُعاد هنا
            if (this.pendingModal) this.hideModal('leaveCardModal');
        }.bind(this));
        cardEl.addEventListener('hidden.bs.modal', function () {
            var next = this.pendingModal;
            this.pendingModal = null;
            if (next) this.showModal(next);
            else this.closeCard();
        }.bind(this));
        document.getElementById('leaveModal').addEventListener('hidden.bs.modal', function () {
            var id = this.pendingCard || (this.returnToCard ? this.cardId : null);
            this.pendingCard = null;
            this.returnToCard = false;
            if (id) this.openCard(id);
            else this.closeCard();
        }.bind(this));
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                state: this.getData.state,
                dues: this.getData.dues,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
            };
            var url = new URL(API_BASE + 'get_leaves', window.location.origin);
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, { headers: { 'Accept': 'application/json' } }).then(function (r) { return r.json(); });
        },
        reload: function (silent) {
            var seq = ++this.listSeq;
            if (!silent) this.loading = true;
            return this.fetchData().then(function (data) {
                if (seq !== this.listSeq) return;  // ردّ بحث أقدم وصل بعد الأحدث
                this.data = Api.getData(data) || [];
                this.data_row_count = data.count || 0;
                this.totals = data.totals || { count: 0, current: 0, upcoming: 0, days: 0 };
                this.selectedRow = this.cardId ? this.rowIndexOf(this.cardId) : -1;
            }.bind(this)).catch(function () {
                if (seq === this.listSeq) Swal.fire('خطأ', 'تعذر تحميل الإجازات', 'error');
            }.bind(this)).finally(function () {
                if (seq === this.listSeq) this.loading = false;
            }.bind(this));
        },
        onChange: function () {
            this.getData.page = 0;
            this.reload();
        },
        debouncedSearch: function () {
            clearTimeout(this.searchTimer);
            this.searchTimer = setTimeout(this.onChange, 300);
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.reload();
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowIndexOf: function (id) {
            return this.data.findIndex(function (r) { return r.id === id; });
        },
        rowClass: function (index, row) {
            if (index === this.selectedRow) return 'lv-row-selected';
            if (row.state === 'current') return 'lv-row-current';
            if (row.state === 'upcoming') return 'lv-row-upcoming';
            return '';
        },
        // تمييز العدد بعد رقم: 3-10 أيام، 11 فأكثر يوماً
        dayUnit: function (n) {
            n = Math.abs(parseInt(n, 10) || 0);
            return n >= 3 && n <= 10 ? 'أيام' : n >= 11 ? 'يوماً' : 'يوم';
        },
        stateLabel: function (state) {
            return STATE_LABELS[state] || STATE_LABELS.unknown;
        },
        // نص قصير للجدول
        stateText: function (row) {
            if (row.state === 'current') return 'جارية · باقي ' + daysText(row.days_left);
            if (row.state === 'upcoming') return row.starts_in === 1 ? 'تبدأ غداً' : 'بعد ' + daysText(row.starts_in);
            return this.stateLabel(row.state);
        },
        // نص البطاقة
        stateDetail: function (lv) {
            if (lv.state === 'current') return 'باقي ' + daysText(lv.days_left);
            if (lv.state === 'upcoming') return lv.starts_in === 1 ? 'تبدأ غداً' : 'تبدأ بعد ' + daysText(lv.starts_in);
            if (lv.state === 'ended') return lv.ended_ago === 0 ? 'انتهت اليوم' : 'انتهت قبل ' + daysText(lv.ended_ago);
            return 'بلا تاريخ';
        },
        showModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show();
        },
        hideModal: function (id) {
            bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).hide();
        },
        // رسالة داخل النافذة المفتوحة حتى لا تسحب مصيدة تركيزها أزرار الرسالة
        alertIn: function (modalId, text) {
            return Swal.fire({ title: 'تنبيه', text: text, icon: 'error', target: document.getElementById(modalId) });
        },

        // ====== بطاقة الإجازة ======
        rowSelect: function (index, row, event) {
            // انتظر حتى تنتهي النافذة السابقة وخلفيتها من الإغلاق
            if (document.body.classList.contains('modal-open')) return;
            this.cardTrigger = event.currentTarget.querySelector('.lv-name-button');
            this.openCard(row.id);
        },
        openCard: function (id) {
            this.cardId = id;
            this.card = null;
            this.selectedRow = this.rowIndexOf(id);
            this.loadCard(id);
            this.$nextTick(function () { this.showModal('leaveCardModal'); });
        },
        loadCard: function (id) {
            var seq = ++this.cardSeq;
            this.cardLoading = true;
            this.cardError = '';
            return fetch(API_BASE + 'get_leave_card/' + id, { headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (seq !== this.cardSeq) return;  // استجابة لبطاقة أُغلقت أو استُبدلت
                    if (Api.isOk(data)) {
                        this.card = Api.getData(data);
                        this.patchRow(this.card.leave);
                    } else {
                        this.card = null;
                        this.cardError = Api.getError(data) || 'تعذر تحميل بطاقة الإجازة';
                    }
                }.bind(this))
                .catch(function () {
                    if (seq === this.cardSeq) this.cardError = 'تعذر الاتصال بالخادم';
                }.bind(this))
                .finally(function () {
                    if (seq === this.cardSeq) this.cardLoading = false;
                }.bind(this));
        },
        switchCard: function (id) {
            if (!this.card || id === this.card.leave.id || this.cardLoading) return;
            this.cardId = id;
            this.selectedRow = this.rowIndexOf(id);
            this.loadCard(id);
        },
        // يحدّث صف الجدول من البطاقة دون إعادة ترتيب القائمة
        patchRow: function (lv) {
            var i = this.rowIndexOf(lv.id);
            if (i > -1) this.$set(this.data, i, Object.assign({}, this.data[i], lv));
        },
        closeCard: function () {
            this.cardSeq++;
            this.card = null;
            this.cardId = null;
            this.cardLoading = false;
            this.cardError = '';
            this.selectedRow = -1;
            if (this.cardTrigger && document.contains(this.cardTrigger)) this.cardTrigger.focus();
            this.cardTrigger = null;
        },
        // من البطاقة إلى نافذة أخرى، ثم العودة إليها عند إغلاقها
        leaveCardTo: function (modalId) {
            this.returnToCard = true;
            this.pendingModal = modalId;
            this.hideModal('leaveCardModal');
        },
        edit_row: function () {
            if (!this.card) return;
            var lv = this.card.leave;
            this.new_row = false;
            this.edit_row_data = {
                id: lv.id,
                employee: lv.employee,
                start_date: lv.start_date || '',
                end_date: lv.end_date || '',
                days_count: lv.days_count,
                tickets_paid: !!lv.tickets_paid,
                allowance_paid: !!lv.allowance_paid,
            };
            this.leaveCardTo('leaveModal');
        },
        markPaid: function (what) {
            var lv = this.card && this.card.leave;
            if (!lv || this.busy) return;
            var id = lv.id;
            this.busy = true;
            postForm(API_BASE + 'mark_paid', { id: id, what: what }).then(function (data) {
                if (Api.isOk(data)) {
                    toast(data.mess || 'تم التسجيل');
                    if (this.cardId === id) this.loadCard(id);
                    this.reload(true);
                } else {
                    this.alertIn('leaveCardModal', Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.alertIn('leaveCardModal', 'تعذر الاتصال بالخادم؛ لم يُسجَّل الصرف');
            }.bind(this)).finally(function () { this.busy = false; }.bind(this));
        },
        delete_leave: function () {
            var lv = this.card && this.card.leave;
            if (!lv) return;
            Swal.fire({
                title: 'حذف إجازة ' + lv.emp_name,
                text: 'حذف الإجازة من ' + (lv.start_date || '—') + ' إلى ' + (lv.end_date || '—')
                    + ' (' + daysText(lv.days_count) + ')؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                target: document.getElementById('leaveCardModal')
            }).then(function (result) {
                if (!result.isConfirmed) return;
                this.busy = true;
                postForm(API_BASE + 'delete_leave/' + lv.id).then(function (data) {
                    if (Api.isOk(data)) {
                        toast('تم حذف الإجازة');
                        this.hideModal('leaveCardModal');
                        this.reload(true);
                    } else {
                        this.alertIn('leaveCardModal', Api.getError(data));
                    }
                }.bind(this)).catch(function () {
                    this.alertIn('leaveCardModal', 'تعذر الاتصال بالخادم؛ لم تُحذف الإجازة');
                }.bind(this)).finally(function () { this.busy = false; }.bind(this));
            }.bind(this));
        },

        // ====== الإضافة والتعديل ======
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = { employee: '', start_date: '', end_date: '', days_count: '', tickets_paid: false, allowance_paid: false };
            this.showModal('leaveModal');
        },
        calcDays: function () {
            var days = calendarDays(this.edit_row_data.start_date, this.edit_row_data.end_date);
            if (days) this.edit_row_data.days_count = days;
        },
        save_data: function (confirmOverlap) {
            if (this.saving) return;
            var d = this.edit_row_data;
            if (!d.employee) { this.alertIn('leaveModal', 'يجب اختيار الموظف'); return; }
            if (!d.start_date || !d.end_date) { this.alertIn('leaveModal', 'أدخل تاريخ بداية الإجازة ونهايتها'); return; }
            if (d.end_date < d.start_date) { this.alertIn('leaveModal', 'تاريخ النهاية قبل تاريخ البداية'); return; }
            if (!(parseInt(d.days_count, 10) > 0)) { this.alertIn('leaveModal', 'أدخل عدد الأيام'); return; }

            var isNew = this.new_row;
            var fields = {
                employee: d.employee,
                start_date: d.start_date,
                end_date: d.end_date,
                days_count: d.days_count,
                tickets_paid: d.tickets_paid ? 'true' : 'false',
                allowance_paid: d.allowance_paid ? 'true' : 'false',
                confirm_overlap: confirmOverlap ? '1' : '',
            };
            if (!isNew) fields.id = d.id;
            this.saving = true;
            postForm(API_BASE + (isNew ? 'new_leave' : 'update_leave'), fields).then(function (data) {
                if (Api.isOk(data)) {
                    var rec = Api.getData(data) || {};
                    toast(isNew ? 'تمت إضافة الإجازة' : 'تم حفظ التعديل');
                    if (isNew) this.pendingCard = rec.id;  // تُفتح بطاقتها بعد إغلاق النافذة
                    this.hideModal('leaveModal');
                    this.reload(true);
                } else if (data && data.need_confirm) {
                    Swal.fire({
                        title: 'تداخل مع إجازة أخرى',
                        html: (data.warnings || []).map(escapeHtml).join('<br>') + '<br><br>هل تريد الحفظ رغم ذلك؟',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'احفظ',
                        cancelButtonText: 'تراجع',
                        target: document.getElementById('leaveModal')
                    }).then(function (result) {
                        if (result.isConfirmed) this.save_data(true);
                    }.bind(this));
                } else {
                    this.alertIn('leaveModal', Api.getError(data));
                }
            }.bind(this)).catch(function () {
                this.alertIn('leaveModal', 'تعذر الاتصال بالخادم؛ لم تُحفظ الإجازة');
            }.bind(this)).finally(function () { this.saving = false; }.bind(this));
        },
    }
});
