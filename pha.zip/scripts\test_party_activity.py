# -*- coding: utf-8 -*-
"""Isolated card activity regressions; no application models or operational DB.

Run: python -B scripts/test_party_activity.py
"""
import ast
import json
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP.parents[1]))
sys.path.insert(0, str(APP / "modules"))
from gluon import DAL, Field, HTTP, URL, current, redirect
from gluon.globals import Request, Response
from gluon.storage import List, Storage
import party_activity as activity

NOW = datetime(2026, 9, 22, 12)


class ActivityFixture(unittest.TestCase):
    def setUp(self):
        self.db = db = DAL("sqlite:memory")
        for name in ("customers", "suppliers"):
            db.define_table(name, Field("name"))
            db[name].insert(name="First")
            db[name].insert(name="Other")
        db.define_table("key_payment_method", Field("name"))
        for name in ("نقدي", "شبكة", "آجل", "حوالة"):
            db.key_payment_method.insert(name=name)
        for name in ("invoice_master", "inv_return_master"):
            db.define_table(name, Field("customer", "integer"), Field("created_on", "datetime"),
                            Field("total_after_discount", "double"), Field("payment_method", "integer"))
        db.define_table("customers_pay", Field("customers_id", "integer"), Field("created_on", "datetime"),
                        Field("amount", "double"), Field("pay_type", "integer"))
        db.define_table("suppliers_bills", Field("supplier", "integer"), Field("bill_date", "date"),
                        Field("bill_total", "double"), Field("bill_no"), Field("invoce_type", "integer", default=1),
                        Field("bill_confirmation", "boolean"), Field("payment_method", "integer"))
        db.define_table("suppliers_bills_pay", Field("supplier", "integer"), Field("pay_date", "date"),
                        Field("pay_total", "double"), Field("payment_type", "integer"), Field("payment_method", "integer"))
        db.define_table("returned_supply", Field("supplier", "integer"), Field("admin_accept", "boolean"))
        self.tables = list(db.tables)

    def tearDown(self):
        self.db.close()

    def customer(self, number=1):
        return activity.customer_activity(self.db, number, NOW)

    def supplier(self, number=1):
        return activity.supplier_activity(self.db, number, NOW)

    def events(self, result):
        return {event["key"]: event for event in result["events"]}

    def invoice(self, **values):
        row = dict(customer=1, created_on=NOW, total_after_discount=100, payment_method=1)
        row.update(values)
        return self.db.invoice_master.insert(**row)

    def bill(self, **values):
        row = dict(supplier=1, bill_date=NOW.date(), bill_total=100, bill_no="B-1", invoce_type=1,
                   bill_confirmation=True, payment_method=3)
        row.update(values)
        return self.db.suppliers_bills.insert(**row)

class ActivityTests(ActivityFixture):
    def test_empty_parties_report_absence_without_fabricating_transactions(self):
        for result in (self.customer(), self.supplier()):
            self.assertEqual(len(result["events"]), 3)
            for event in result["events"]:
                self.assertIsNone(event["latest"])
                self.assertEqual(event["period"]["count"], 0)
                self.assertEqual(event["period"]["amount"], 0)

    def test_latest_is_scoped_and_ordered_by_date_then_id(self):
        latest_id = self.invoice(created_on=NOW - timedelta(days=1), total_after_discount=12.5)
        self.invoice(created_on=NOW - timedelta(days=20), total_after_discount=90)
        self.invoice(customer=2, total_after_discount=999)
        self.invoice(created_on=None, total_after_discount=777)
        event = self.events(self.customer())["invoice"]
        self.assertEqual(event["latest"]["id"], latest_id)
        self.assertEqual(event["period"]["amount"], 102.5)
        tie = self.invoice(created_on=NOW - timedelta(days=1), total_after_discount=15)
        self.assertEqual(self.events(self.customer())["invoice"]["latest"]["id"], tie)

    def test_missing_date_is_unknown_and_future_is_flagged_not_in_period(self):
        self.invoice(created_on=None)
        event = self.events(self.customer())["invoice"]
        self.assertIsNone(event["latest"]["date"])
        self.assertEqual(event["period"]["count"], 0)
        self.invoice(created_on=NOW + timedelta(days=2), total_after_discount=50)
        event = self.events(self.customer())["invoice"]
        self.assertTrue(event["latest"]["future"])
        self.assertEqual(event["period"]["count"], 0)

    def test_period_includes_exactly_ninety_calendar_days(self):
        start = NOW.replace(hour=0) - timedelta(days=89)
        end = NOW.replace(hour=0) + timedelta(days=1)
        self.invoice(created_on=start - timedelta(seconds=1), total_after_discount=1)
        self.invoice(created_on=start, total_after_discount=2)
        self.invoice(created_on=end - timedelta(seconds=1), total_after_discount=3)
        self.invoice(created_on=end, total_after_discount=4)
        period = self.events(self.customer())["invoice"]["period"]
        self.assertEqual(period["count"], 2)
        self.assertEqual(period["amount"], 5)

    def test_legacy_date_outside_python_range_does_not_break_the_card(self):
        bill_id = self.bill()
        # Reproduce historical SQL imports that bypassed DAL date validation.
        self.db.executesql("UPDATE suppliers_bills SET bill_date = ? WHERE id = ?",
                           placeholders=["20019-11-26", bill_id])
        event = self.events(self.supplier())["invoice"]
        self.assertEqual(event["latest"]["date"], "20019-11-26")
        self.assertTrue(event["latest"]["invalid_date"])
        self.assertEqual(event["period"]["count"], 0)

    def test_customer_returns_and_payments_exclude_other_customers_and_adjustments(self):
        self.db.inv_return_master.insert(customer=1, created_on=NOW, total_after_discount=8, payment_method=1)
        self.db.inv_return_master.insert(customer=2, created_on=NOW, total_after_discount=900)
        self.db.customers_pay.insert(customers_id=1, created_on=NOW - timedelta(days=2), amount=20, pay_type=None)
        last = self.db.customers_pay.insert(customers_id=1, created_on=NOW - timedelta(days=1), amount=30, pay_type=10)
        self.db.customers_pay.insert(customers_id=1, created_on=NOW, amount=-100, pay_type=20)
        self.db.customers_pay.insert(customers_id=2, created_on=NOW, amount=999, pay_type=0)
        events = self.events(self.customer())
        self.assertEqual(events["return"]["period"]["amount"], 8)
        self.assertEqual(events["payment"]["latest"]["id"], last)
        self.assertEqual(events["payment"]["latest"]["detail"], "دعم الجمعية")
        self.assertEqual(events["payment"]["period"]["amount"], 50)
        self.assertEqual(events["payment"]["period"]["count"], 2)

    def test_supplier_returns_are_counted_once_and_not_mixed_with_payments(self):
        for kind, amount in ((1, 100), (2, 10), (3, 20), (4, 30)):
            self.db.suppliers_bills_pay.insert(supplier=1, pay_date=NOW.date(), pay_total=amount, payment_type=kind, payment_method=4)
        self.db.suppliers_bills_pay.insert(supplier=2, pay_date=NOW.date(), pay_total=999, payment_type=4)
        self.db.returned_supply.insert(supplier=1, admin_accept=True)
        events = self.events(self.supplier())
        self.assertEqual(events["return"]["period"]["count"], 2)
        self.assertEqual(events["return"]["period"]["amount"], 50)
        self.assertEqual(events["return"]["latest"]["reference_label"], "رقم القيد")
        self.assertEqual(events["payment"]["period"]["count"], 1)
        self.assertEqual(events["payment"]["period"]["amount"], 100)

    def test_supplier_purchase_approval_and_other_document_types_remain_distinct(self):
        self.bill(bill_date=NOW.date() - timedelta(days=1), bill_total=100)
        last = self.bill(bill_confirmation=False, bill_total=50, bill_no="Pending")
        self.bill(invoce_type=5, bill_total=1000)
        self.bill(invoce_type=2, bill_total=2000)
        self.bill(supplier=2, bill_total=3000)
        self.db.returned_supply.insert(supplier=1, admin_accept=False)
        self.db.returned_supply.insert(supplier=2, admin_accept=False)
        result = self.supplier()
        invoice = self.events(result)["invoice"]
        self.assertEqual(invoice["latest"]["id"], last)
        self.assertEqual(invoice["latest"]["reference"], "Pending")
        self.assertEqual(invoice["latest"]["badges"][0]["text"], "قيد الاعتماد")
        self.assertEqual(invoice["period"]["amount"], 100)
        self.assertEqual(invoice["period"]["count"], 1)
        self.assertEqual([item["count"] for item in result["pending"]], [1, 1])

    def test_null_amount_is_not_displayed_as_zero(self):
        self.invoice(total_after_discount=0)
        self.invoice(total_after_discount=None)
        event = self.events(self.customer())["invoice"]
        self.assertIsNone(event["latest"]["amount"])
        self.assertEqual(event["period"]["amount"], 0)
        self.assertEqual(event["period"]["missing_amounts"], 1)

    def test_reading_activity_does_not_change_records(self):
        self.invoice()
        self.bill()
        before = {name: self.db(self.db[name].id > 0).select().as_list() for name in self.tables}
        self.customer()
        self.supplier()
        after = {name: self.db(self.db[name].id > 0).select().as_list() for name in self.tables}
        self.assertEqual(before, after)

    def test_invalid_and_missing_ids_have_explicit_errors(self):
        for value in (None, "0", "-1", "1 OR 1=1", "1.0", "2147483648"):
            with self.subTest(value=value), self.assertRaises(activity.ActivityError) as error:
                self.customer(value)
            self.assertEqual(error.exception.status, 400)
        with self.assertRaises(activity.ActivityError) as error:
            self.supplier(999)
        self.assertEqual(error.exception.status, 404)


class EndpointTests(ActivityFixture):
    def setUp(self):
        super().setUp()
        self.request, self.response = Request({}), Response()
        self.request.application = "asbab5"
        self.request.controller = "customers_api"
        self.request.now = NOW
        self.request.args = List(["1"])
        self.request.env.request_method = "GET"
        current.request, current.response = self.request, self.response
        self.db.define_table("screens", Field("screen_code", "integer"))
        self.db.define_table("screens_rules", Field("screens", "integer"), Field("to_user", "integer"), Field("can_log_in", "boolean"))
        self.db.screens.insert(screen_code=1001)
        self.db.screens.insert(screen_code=2001)
        self.db.screens_rules.insert(screens=1, to_user=1, can_log_in=True)
        auth = Storage(user=Storage(id=1, first_name="Fixture"), has_membership=lambda role: False)
        self.env = dict(db=self.db, request=self.request, response=self.response, auth=auth, URL=URL, redirect=redirect)
        model = ast.parse((APP / "models/db_4_access.py").read_text(encoding="utf-8-sig"))
        access = next(node for node in model.body if isinstance(node, ast.FunctionDef) and node.name == "can_access")
        exec(compile(ast.Module(body=[access], type_ignores=[]), "access", "exec"), self.env)
        self.actions = {}
        for controller in ("customers_api", "suppliers_api"):
            source = ast.parse((APP / "controllers" / (controller + ".py")).read_text(encoding="utf-8-sig"))
            action = next(node for node in source.body if isinstance(node, ast.FunctionDef) and node.name == "card_activity")
            exec(compile(ast.Module(body=[action], type_ignores=[]), controller, "exec"), self.env)
            self.actions[controller] = self.env["card_activity"]

    def test_screen_permission_and_anonymous_requests_are_enforced(self):
        self.assertTrue(json.loads(self.actions["customers_api"]())["ok"])
        self.assertEqual(self.response.headers["Cache-Control"], "private, no-store")
        with self.assertRaises(HTTP):
            self.actions["suppliers_api"]()
        self.db.screens_rules.insert(screens=2, to_user=1, can_log_in=True)
        self.assertTrue(json.loads(self.actions["suppliers_api"]())["ok"])
        self.env["auth"].user = None
        for action in self.actions.values():
            with self.assertRaises(HTTP):
                action()

    def test_endpoint_rejects_post_and_invalid_id(self):
        self.request.env.request_method = "POST"
        self.assertFalse(json.loads(self.actions["customers_api"]())["ok"])
        self.assertEqual(self.response.status, 405)
        self.request.env.request_method = "GET"
        self.request.args = List(["invalid"])
        self.assertFalse(json.loads(self.actions["customers_api"]())["ok"])
        self.assertEqual(self.response.status, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
