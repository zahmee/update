# -*- coding: utf-8 -*-
"""القيد الفريد على الرقم المميز للفواتير (uuid) — المنطق المشترك.

يستورده كلٌّ من:
  - scripts/uuid_unique_migrate.py   (سطر الأوامر، للخوادم ذات الوصول الطرفي)
  - controllers/setup.py             (شاشة إدارية، لمن يدير الفرع من المتصفح)

فلا يوجد تنفيذان قد يفترقان مع الوقت.

الخلفية: العميل يولّد رقماً مميزاً واحداً للفاتورة ويرسله مع كل محاولة حفظ،
والخادم يرفض ما سبق حفظه. لكن الفحص "ابحث ثم أدرج" وبين الخطوتين فجوة
(قفل الدفعات، خصم المخزون، إدراج الأسطر) يمكن أن يمر منها طلبان متزامنان
بنفس الرقم — فتُحفظ الفاتورة مرتين ويُخصم المخزون مرتين ويصل للهيئة إقرار
مضاعف. القيد الفريد يغلق الفجوة لأن الرفض يصير جزءاً من الكتابة نفسها.

لا شيء هنا يكتب في القاعدة إلا apply_table/apply_all.
"""

import json
import os
from datetime import datetime

# أسماء الجداول والفهارس ثابتة هنا ولا تأتي من المستخدم إطلاقاً،
# فدمجها في نص الاستعلام آمن. أي قيمة قادمة من الخارج تمر بـ placeholders.
# redundant: فهارس غير فريدة على نفس العمود صارت تكراراً محضاً بعد القيد
# الفريد — الفهرس الفريد يخدم كل استعلام يخدمه أي منها. إبقاؤها يكلّف
# تحديثاً إضافياً لكل فهرس مع كل فاتورة تُحفظ، أي على مسار الكاشير مباشرة،
# ومساحة تعادل حجم الفهرس الفريد نفسه لكل نسخة.
# لا تُحذف أبداً إلا بعد التأكد من وجود القيد الفريد (انظر apply_table).
TABLES = [
    {
        "table": "invoice_master",
        "index": "idx_invoice_master_uuid_uniq",
        "label": "فواتير البيع",
        "redundant": ["idx_invoice_master_uuid", "uuis_index"],
        # dup_index: فهرس مكرر حرفياً لفهرس آخر (نفس العمود ونفس النوع)،
        # لا علاقة له بالقيد الفريد. يُحذف drop ويُبقى keep — وهو الذي
        # تنشئه modules/system_readiness.py، فيبقى مصدر الحقيقة هو الكود لا القاعدة.
        # لا يُحذف إطلاقاً إن كان keep غائباً، حتى لا يبقى العمود بلا فهرس.
        "dup_index": [
            {"drop": "invoice_master_customer_idx",
             "keep": "idx_invoice_master_customer"},
        ],
    },
    {
        "table": "inv_return_master",
        "index": "idx_inv_return_master_uuid_uniq",
        "label": "مرتجعات البيع",
        "redundant": ["idx_inv_return_master_uuid"],
    },
]


def _q(db, sql, ph=None):
    return db.executesql(sql, placeholders=ph or [], as_dict=True)


def index_exists(db, table, index):
    """هل القيد الفريد موجود فعلاً؟ (لا يصح الافتراض — الإنشاء التلقائي يتخطى الجداول الكبيرة والمكرر)"""
    return bool(_q(
        db,
        "SELECT 1 FROM pg_indexes WHERE tablename = %s AND indexname = %s"
        " AND indexdef ILIKE '%%UNIQUE%%'",
        [table, index],
    ))


def redundant_present(db, cfg):
    """أي الفهارس الزائدة ما زالت موجودة فعلاً في هذا الفرع؟

    يستثني أي فهرس مسنود بقيد (مفتاح أساسي/قيد فريد) — تلك لا تُحذف
    بـ DROP INDEX أصلاً، ولا يصح المساس بها.
    """
    names = cfg.get("redundant") or []
    if not names:
        return []
    return [r["indexname"] for r in _q(
        db,
        "SELECT i.indexname FROM pg_indexes i"
        " WHERE i.tablename = %s AND i.indexname = ANY(%s)"
        "   AND NOT EXISTS (SELECT 1 FROM pg_constraint c"
        "                   WHERE c.conindid = (quote_ident(i.indexname))::regclass)"
        " ORDER BY i.indexname",
        [cfg["table"], names],
    )]


def dup_index_present(db, cfg):
    """الفهارس المكررة القابلة للحذف الآن.

    لا يُدرج فهرس إلا إذا كان توأمه (keep) موجوداً فعلاً — وإلا لبقي
    العمود بلا أي فهرس. ويُستثنى المسنود بقيد كما في redundant_present.
    """
    out = []
    for pair in (cfg.get("dup_index") or []):
        rows = _q(
            db,
            "SELECT i.indexname FROM pg_indexes i"
            " WHERE i.tablename = %s AND i.indexname = ANY(%s)"
            "   AND NOT EXISTS (SELECT 1 FROM pg_constraint c"
            "                   WHERE c.conindid = (quote_ident(i.indexname))::regclass)",
            [cfg["table"], [pair["drop"], pair["keep"]]],
        )
        names = {r["indexname"] for r in rows}
        if pair["drop"] in names and pair["keep"] in names:
            out.append(pair["drop"])
    return out


def dup_uuids(db, table):
    return [r["uuid"] for r in _q(
        db,
        "SELECT uuid FROM " + table +
        " WHERE uuid IS NOT NULL AND uuid <> ''"
        " GROUP BY uuid HAVING COUNT(*) > 1",
    )]


def extra_ids(db, table, uuids):
    """أرقام الصفوف الزائدة: كل صفوف المجموعة عدا الأخير.

    يُبقى الأخير لأنه صاحب المبلغ الكامل وعلامة الإرسال للهيئة.
    """
    if not uuids:
        return []
    return [r["id"] for r in _q(
        db,
        "SELECT id FROM " + table + " m WHERE uuid = ANY(%s)"
        " AND id <> (SELECT MAX(id) FROM " + table + " x WHERE x.uuid = m.uuid)"
        " ORDER BY id",
        [uuids],
    )]


def table_status(db, cfg):
    """حالة جدول واحد — قراءة فقط."""
    table, index = cfg["table"], cfg["index"]
    out = {
        "table": table, "index": index, "label": cfg["label"],
        "protected": index_exists(db, table, index),
        "total": 0, "blanks": 0, "dup_groups": 0,
        "extra_rows": 0, "extra_amount": 0.0, "extra_sent": 0,
        "redundant": redundant_present(db, cfg) + dup_index_present(db, cfg),
        "ready": False, "note": "",
    }
    if out["protected"]:
        if out["redundant"]:
            out["ready"] = True
            out["note"] = ("محمي — ويوجد %s فهرس زائد يمكن حذفه"
                           % len(out["redundant"]))
        else:
            out["note"] = "محمي — القيد الفريد موجود ولا فهارس زائدة"
        return out

    s = _q(db, "SELECT COUNT(*) AS total,"
               " COUNT(*) FILTER (WHERE uuid IS NULL OR uuid = '') AS blanks"
               " FROM " + table)[0]
    out["total"] = int(s["total"] or 0)
    out["blanks"] = int(s["blanks"] or 0)

    uuids = dup_uuids(db, table)
    ids = extra_ids(db, table, uuids)
    out["dup_groups"] = len(uuids)
    out["extra_rows"] = len(ids)

    if ids:
        a = _q(db, "SELECT ROUND(COALESCE(SUM(total),0)::numeric,2) AS s,"
                   " COUNT(*) FILTER (WHERE send_to_zatca='T') AS sent"
                   " FROM " + table + " WHERE id = ANY(%s)", [ids])[0]
        out["extra_amount"] = float(a["s"] or 0)
        out["extra_sent"] = int(a["sent"] or 0)

    extra_note = ("، مع حذف %s فهرس زائد" % len(out["redundant"])) if out["redundant"] else ""
    if out["blanks"] > 1:
        out["note"] = ("يوجد %s سجل بلا رقم مميز — القيد سيرفضها."
                       " عالجها يدوياً أولاً." % out["blanks"])
    elif out["extra_sent"]:
        out["note"] = ("%s من الصفوف الزائدة مُرسل للهيئة — لا يُحذف تلقائياً."
                       " راجعه يدوياً." % out["extra_sent"])
    elif out["extra_rows"]:
        out["ready"] = True
        out["note"] = ("جاهز: يُحذف %s صفاً ثم يُنشأ القيد%s"
                       % (out["extra_rows"], extra_note))
    else:
        out["ready"] = True
        out["note"] = "نظيف: يُنشأ القيد مباشرة بلا حذف" + extra_note
    return out


def status(db):
    return [table_status(db, c) for c in TABLES]


def apply_table(db, cfg, backup_dir=None, stamp=None):
    """ينفّذ على جدول واحد: نسخة احتياطية ← حذف ← إنشاء القيد ← تحقق.

    يعيد قاموس النتيجة. لا يحذف أبداً صفاً مُرسلاً للهيئة.
    """
    st = table_status(db, cfg)
    res = {"label": cfg["label"], "table": cfg["table"],
           "deleted": 0, "backup": "", "dropped": [],
           "protected": st["protected"],
           "ok": st["protected"], "mess": st["note"]}
    if not st["ready"]:
        return res

    table, index = cfg["table"], cfg["index"]

    if st["protected"]:
        # لا عمل على القيد نفسه — يبقى تنظيف الفهارس الزائدة فقط
        res["dropped"] = _drop_redundant(db, cfg)
        res["ok"] = True
        res["mess"] = ("حُذف %s فهرس زائد" % len(res["dropped"])
                       if res["dropped"] else "لا شيء لعمله")
        return res

    ids = extra_ids(db, table, dup_uuids(db, table))

    if ids:
        rows = _q(db, "SELECT * FROM " + table + " WHERE id = ANY(%s) ORDER BY id", [ids])
        if backup_dir:
            stamp = stamp or datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(backup_dir,
                                "uuid_dup_backup_%s_%s.json" % (table, stamp))
            with open(path, "w", encoding="utf-8") as fh:
                for r in rows:
                    fh.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
            res["backup"] = path
        db.executesql("DELETE FROM " + table + " WHERE id = ANY(%s)", placeholders=[ids])
        db.commit()
        res["deleted"] = len(ids)

    left = dup_uuids(db, table)
    if left:
        res["mess"] = "ما زال هناك %s رقم مكرر — لم يُنشأ القيد" % len(left)
        return res

    try:
        db.executesql("CREATE UNIQUE INDEX IF NOT EXISTS " + index +
                      " ON " + table + "(uuid)")
        db.commit()
    except Exception as e:
        db.rollback()
        res["mess"] = "فشل إنشاء القيد: %s" % str(e).split("\n")[0]
        return res

    # التحقق إلزامي لا تجميلي: الإنشاء قد يفشل بصمت في مسارات أخرى
    if index_exists(db, table, index):
        res["ok"] = True
        res["protected"] = True
        res["mess"] = ("حُذف %s صفاً وأُنشئ القيد وتم التحقق منه" % res["deleted"]
                       if res["deleted"] else "أُنشئ القيد وتم التحقق منه")
        # الترتيب مقصود: لا تُحذف الفهارس الزائدة إلا بعد ثبوت القيد الفريد،
        # وإلا بقي العمود بلا فهرس وصار فحص التكرار مسحاً كاملاً للجدول.
        res["dropped"] = _drop_redundant(db, cfg)
        if res["dropped"]:
            res["mess"] += "، وحُذف %s فهرس زائد" % len(res["dropped"])
    else:
        res["mess"] = "القيد غير موجود بعد المحاولة — راجع يدوياً"
    return res


def _drop_redundant(db, cfg):
    """يحذف الفهارس الزائدة والمكررة.

    فهارس uuid لا تُحذف إلا والقيد الفريد ثابت الوجود (وإلا بقي العمود
    بلا فهرس). أما المكررة فحارسها الخاص داخل dup_index_present: لا تُحذف
    إلا وتوأمها موجود.
    """
    dropped = []
    names = list(dup_index_present(db, cfg))
    if index_exists(db, cfg["table"], cfg["index"]):
        names = redundant_present(db, cfg) + names
    for name in names:
        try:
            # الاسم من قائمة ثابتة في هذا الملف، لا من إدخال مستخدم
            db.executesql('DROP INDEX IF EXISTS "%s"' % name)
            db.commit()
            dropped.append(name)
        except Exception:
            db.rollback()
    return dropped


def apply_all(db, backup_dir=None):
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return [apply_table(db, c, backup_dir, stamp) for c in TABLES]
