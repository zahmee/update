# -*- coding: utf-8 -*-
#  type: ignore
import api_helpers as api


@can_access(7004)
def index():
    return dict()


@can_access(7004)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    advance_types = db(db.key_advance_types.id > 0).select(
        db.key_advance_types.id, db.key_advance_types.name,
        orderby=db.key_advance_types.name
    )
    return response.json(api.api_ok(data={
        "employees": employees,
        "advance_types": advance_types,
    }))


@can_access(7004)
def get_advances():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append(
                "( emp.emp_name LIKE %s OR CAST(a.amount AS text) LIKE %s "
                "OR CAST(a.advance_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])

    # فلتر الحالة
    if ReqVar.status_filter and ReqVar.status_filter != '0':
        if ReqVar.status_filter == 'open':
            conditions.append("( a.is_closed = 'F' OR a.is_closed IS NULL )")
        elif ReqVar.status_filter == 'closed':
            conditions.append("( a.is_closed = 'T' )")

    # ترتيب
    allowed_sort_columns = {'id', 'emp_name', 'advance_type', 'amount', 'paid_amount', 'advance_date', 'is_closed'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'id'

    sort_map = {
        'id': 'a.id',
        'emp_name': 'emp.emp_name',
        'advance_type': 'at.name',
        'amount': 'a.amount',
        'paid_amount': 'a.paid_amount',
        'advance_date': 'a.advance_date',
        'is_closed': 'a.is_closed',
    }
    sort_col = sort_map.get(sc, 'a.id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' WHERE ' + ' AND '.join(conditions)

    sql = (
        f"SELECT a.id, a.employee, a.advance_type, a.amount, a.paid_amount, "
        f"a.advance_date, a.is_closed, a.closed_date, "
        f"emp.emp_name, at.name AS advance_type_name "
        f"FROM emp_advances a "
        f"JOIN employees emp ON emp.id = a.employee "
        f"LEFT JOIN key_advance_types at ON at.id = a.advance_type "
        f"{where} ORDER BY {sort_col} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM emp_advances a "
        f"JOIN employees emp ON emp.id = a.employee "
        f"LEFT JOIN key_advance_types at ON at.id = a.advance_type "
        f"{where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7004)
def new_advance():
    try:
        data = request.vars

        advance_date = None
        if data.advance_date and data.advance_date != '':
            advance_date = data.advance_date

        nid = db.emp_advances.insert(
            employee=int(data.employee),
            advance_type=int(data.advance_type) if data.advance_type else None,
            amount=float(data.amount or 0),
            paid_amount=0,
            advance_date=advance_date,
            is_closed=False,
            closed_date=None,
        )
        db.commit()

        inserted = db.executesql(
            "SELECT a.id, a.employee, a.advance_type, a.amount, a.paid_amount, "
            "a.advance_date, a.is_closed, a.closed_date, "
            "emp.emp_name, at.name AS advance_type_name "
            "FROM emp_advances a "
            "JOIN employees emp ON emp.id = a.employee "
            "LEFT JOIN key_advance_types at ON at.id = a.advance_type "
            "WHERE a.id = %s",
            placeholders=[nid], as_dict=True
        )
        return response.json(api.api_ok(data=inserted[0] if inserted else {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7004)
def update_advance():
    try:
        data = request.vars
        row = db.emp_advances[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        row.employee = int(data.employee)
        row.advance_type = int(data.advance_type) if data.advance_type else None
        row.amount = float(data.amount or 0)
        row.paid_amount = float(data.paid_amount or 0)

        if data.advance_date and data.advance_date != '':
            row.advance_date = data.advance_date
        else:
            row.advance_date = None

        # إقفال تلقائي إذا المبلغ المسدد >= المبلغ
        if row.paid_amount >= row.amount and row.amount > 0:
            row.is_closed = True
            if not row.closed_date:
                from datetime import date
                row.closed_date = date.today()
        else:
            if data.is_closed == 'true' or data.is_closed == 'on':
                row.is_closed = True
                if not row.closed_date:
                    from datetime import date
                    row.closed_date = date.today()
            else:
                row.is_closed = False
                row.closed_date = None

        if data.closed_date and data.closed_date != '':
            row.closed_date = data.closed_date

        row.update_record()
        db.commit()

        updated = db.executesql(
            "SELECT a.id, a.employee, a.advance_type, a.amount, a.paid_amount, "
            "a.advance_date, a.is_closed, a.closed_date, "
            "emp.emp_name, at.name AS advance_type_name "
            "FROM emp_advances a "
            "JOIN employees emp ON emp.id = a.employee "
            "LEFT JOIN key_advance_types at ON at.id = a.advance_type "
            "WHERE a.id = %s",
            placeholders=[data.id], as_dict=True
        )
        return response.json(api.api_ok(data=updated[0] if updated else {"id": data.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7004)
def delete_advance():
    try:
        row = db.emp_advances[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
