# -*- coding: utf-8 -*-
#  type: ignore
import json
import math
from datetime import datetime
import api_helpers as api
import advance_ledger as ledger

# المسدد (paid_amount) مجموع سجل emp_advance_payment ولا يُكتب إلا عبر modules/advance_ledger.py:
# خصم المسير يُسجَّل عند اعتماده، والسداد المباشر والتسوية من بطاقة السلفة هنا.

_ADVANCE_SELECT = (
    "SELECT a.id, a.employee, a.advance_type, a.amount, a.paid_amount, "
    "a.advance_date, a.is_closed, a.closed_date, "
    "emp.emp_name, at.name AS advance_type_name, "
    "(SELECT MAX(p.pay_date) FROM emp_advance_payment p "
    " WHERE p.advance = a.id AND p.amount > 0) AS last_pay_date "
    "FROM emp_advances a "
    "JOIN employees emp ON emp.id = a.employee "
    "LEFT JOIN key_advance_types at ON at.id = a.advance_type "
)


def _post_only():
    if request.env.request_method != "POST":
        raise HTTP(405, "POST only")


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _money(value):
    return round(float(value or 0), 2)


def _advance_row(advance_id):
    rows = db.executesql(_ADVANCE_SELECT + "WHERE a.id = %s", placeholders=[advance_id], as_dict=True)
    return rows[0] if rows else None


def _validate_advance_payload(data):
    errors = []

    employee = _int(data.employee)
    if not employee or not db.employees[employee]:
        errors.append("الموظف مطلوب")

    advance_type = _int(data.advance_type)
    if not advance_type or not db.key_advance_types[advance_type]:
        errors.append("نوع السلفة مطلوب")

    try:
        amount = _money(data.amount)
    except (TypeError, ValueError):
        amount = 0
    if amount <= 0:
        errors.append("مبلغ السلفة يجب أن يكون أكبر من صفر")

    advance_date = None
    if data.advance_date:
        try:
            advance_date = datetime.strptime(str(data.advance_date), "%Y-%m-%d").date()
            if advance_date > request.now.date():
                errors.append("تاريخ السلفة لا يمكن أن يكون مستقبلياً")
        except Exception:
            errors.append("تاريخ السلفة غير صحيح")

    return errors, {
        "employee": employee,
        "advance_type": advance_type,
        "amount": amount,
        "advance_date": advance_date,
    }


@can_access(7004)
def index():
    return dict(adv_flags=json.dumps({
        "is_admin": bool(auth.has_membership("admin")),
        # من الخادم لا من location.href، فيبقى صحيحاً مع ?adv=<id> في العنوان
        "base": URL("advances", "index").rsplit("/", 1)[0] + "/",
    }))


@can_access(7004)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    advance_types = db(db.key_advance_types.id > 0).select(
        db.key_advance_types.id, db.key_advance_types.name,
        orderby=db.key_advance_types.name
    )
    return response.json(api.api_ok(data={
        "employees": employees,
        "advance_types": advance_types,
    }))


@can_access(7004)
def get_advances():
    ReqVar = request.vars
    pg = max(_int(ReqVar.page), 0)
    rc = min(max(_int(ReqVar.RecordCount) or 20, 1), 100)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        for word in ReqVar.SearchText.split():
            pattern = '%' + word + '%'
            conditions.append(
                "( emp.emp_name LIKE %s OR CAST(a.amount AS text) LIKE %s "
                "OR CAST(a.advance_date AS text) LIKE %s OR CAST(a.id AS text) = %s )"
            )
            params.extend([pattern, pattern, pattern, word])

    # فلتر الحالة
    if ReqVar.status_filter == 'open':
        conditions.append("( a.is_closed = 'F' OR a.is_closed IS NULL )")
    elif ReqVar.status_filter == 'closed':
        conditions.append("( a.is_closed = 'T' )")

    sort_map = {
        'id': 'a.id',
        'emp_name': 'emp.emp_name',
        'advance_type': 'at.name',
        'amount': 'a.amount',
        'paid_amount': 'a.paid_amount',
        'remaining': "(COALESCE(a.amount, 0) - COALESCE(a.paid_amount, 0))",
        'advance_date': 'a.advance_date',
        'last_pay_date': 'last_pay_date',
        'is_closed': 'a.is_closed',
    }
    sort_col = sort_map.get(ReqVar.SortBy, 'a.id')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    where = (' WHERE ' + ' AND '.join(conditions)) if conditions else ''

    qry = db.executesql(
        _ADVANCE_SELECT + where + f" ORDER BY {sort_col} {sa} NULLS LAST, a.id DESC LIMIT %s OFFSET %s",
        placeholders=params + [rc, pg * rc], as_dict=True)

    totals = db.executesql(
        "SELECT count(*) AS count, "
        "count(*) FILTER (WHERE COALESCE(a.is_closed, 'F') <> 'T') AS open_count, "
        "COALESCE(SUM(a.amount), 0) AS amount, COALESCE(SUM(a.paid_amount), 0) AS paid, "
        "COALESCE(SUM(COALESCE(a.amount, 0) - COALESCE(a.paid_amount, 0)) "
        "         FILTER (WHERE COALESCE(a.is_closed, 'F') <> 'T'), 0) AS remaining "
        "FROM emp_advances a "
        "JOIN employees emp ON emp.id = a.employee "
        "LEFT JOIN key_advance_types at ON at.id = a.advance_type" + where,
        placeholders=params or None, as_dict=True)[0]

    return response.json(api.api_list(rows=qry, count=totals["count"], totals={
        "open_count": totals["open_count"],
        "amount": _money(totals["amount"]),
        "paid": _money(totals["paid"]),
        "remaining": _money(totals["remaining"]),
    }))


def _user_names(ids):
    ids = sorted({i for i in ids if i})
    if not ids:
        return {}
    rows = db(db.auth_user.id.belongs(ids)).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name)
    return {r.id: ("%s %s" % (r.first_name or "", r.last_name or "")).strip() for r in rows}


def _month_label(month, year):
    if not month or not year:
        return ""
    return "%s %s" % (HR_MONTHS[int(month) - 1], year)


def _add_months(month, year, count):
    index = year * 12 + (month - 1) + count
    return index % 12 + 1, index // 12


@can_access(7004)
def get_advance_card():
    """بطاقة السلفة: بياناتها، وسجل سداداتها برصيد متحرك، وخطة سدادها من قسط الراتب،
    وسلف الموظف الأخرى، وخصومات في مسيرات لم تُعتمد بعد."""
    advance_id = _int(request.args(0))
    adv = db.emp_advances(advance_id)
    if not adv:
        return response.json(api.api_error(mess="السلفة غير موجودة"))
    # السجل يُملأ من المسيرات المعتمدة مرة واحدة لكل فرع قبل أول عرض أو كتابة
    if ledger.ensure_backfill(db, request.now.date()):
        db.commit()
        adv = db.emp_advances(advance_id)

    today = request.now.date()
    emp = db.employees(adv.employee)
    job = db.key_job_titles(emp.job_title) if emp and emp.job_title else None
    adv_type = db.key_advance_types(adv.advance_type) if adv.advance_type else None
    amount, paid = _money(adv.amount), _money(adv.paid_amount)
    remaining = _money(amount - paid)

    t = db.emp_advance_payment
    pays = db(t.advance == adv.id).select(orderby=t.pay_date | t.id)
    names = _user_names([p.created_by for p in pays] + [adv.created_by, adv.modified_by])
    payments, running, breakdown = [], 0.0, {k: 0.0 for k in ledger.SOURCES}
    for p in pays:
        running = _money(running + p.amount)
        breakdown[p.source] = _money(breakdown.get(p.source, 0) + p.amount)
        payments.append({
            "id": p.id, "pay_date": p.pay_date, "amount": _money(p.amount), "source": p.source,
            "source_name": ledger.SOURCES.get(p.source, p.source),
            "period": _month_label(p.pay_month, p.pay_year), "note": p.note or "",
            "user": names.get(p.created_by, ""), "created_on": p.created_on,
            "paid_after": running, "remaining_after": _money(amount - running),
            "deletable": p.source in ledger.MANUAL,
        })

    # الخطة: القسط الشهري «خصم سلفة» في هيكل الراتب يُخصم من السلف المفتوحة الأقدم أولاً
    installment = _money(db.executesql(
        "SELECT COALESCE(SUM(d.amount), 0) FROM emp_salary_detail d "
        "JOIN key_allowance_deduction ad ON ad.id = d.allowance_deduction "
        "WHERE d.employee = %s AND ad.name = %s AND ad.ad_type = 'خصم'",
        placeholders=[adv.employee, ledger.DEDUCTION_NAME])[0][0])
    others = db.executesql(
        "SELECT a.id, a.advance_date, COALESCE(a.amount, 0) AS amount, "
        "COALESCE(a.paid_amount, 0) AS paid, COALESCE(a.is_closed, 'F') = 'T' AS closed, "
        "kt.name AS type_name "
        "FROM emp_advances a LEFT JOIN key_advance_types kt ON kt.id = a.advance_type "
        "WHERE a.employee = %s ORDER BY a.advance_date NULLS LAST, a.id",
        placeholders=[adv.employee], as_dict=True)
    ahead, emp_remaining, before = 0.0, 0.0, True
    for o in others:
        o["remaining"] = _money(float(o["amount"]) - float(o["paid"]))
        if not o["closed"] and o["remaining"] > ledger.EPS:
            emp_remaining += o["remaining"]
            if o["id"] == adv.id:
                before = False
            elif before:
                ahead += o["remaining"]
    ahead, emp_remaining = _money(ahead), _money(emp_remaining)

    last_period = db.executesql(
        "SELECT pay_month, pay_year FROM payroll_period WHERE is_approved = 'T' "
        "ORDER BY pay_year DESC, pay_month DESC LIMIT 1", as_dict=True)
    pending = db.executesql(
        "SELECT p.pay_month, p.pay_year, SUM(pd.amount) AS amount FROM payroll p "
        "JOIN payroll_detail pd ON pd.payroll_id = p.id "
        "JOIN key_allowance_deduction ad ON ad.id = pd.allowance_deduction "
        "LEFT JOIN payroll_period pp ON pp.pay_month = p.pay_month AND pp.pay_year = p.pay_year "
        "WHERE p.employee = %s AND ad.name = %s AND ad.ad_type = 'خصم' "
        "AND COALESCE(pp.is_approved, 'F') <> 'T' "
        "GROUP BY p.pay_month, p.pay_year HAVING SUM(pd.amount) > 0 "
        "ORDER BY p.pay_year, p.pay_month",
        placeholders=[adv.employee, ledger.DEDUCTION_NAME], as_dict=True)
    for p in pending:
        p["label"] = _month_label(p["pay_month"], p["pay_year"])
        p["amount"] = _money(p["amount"])

    is_open = not adv.is_closed and remaining > ledger.EPS
    plan = {"installment": installment, "ahead": ahead, "employee_remaining": emp_remaining,
            "months_left": None, "finish_label": ""}
    if is_open and installment > 0:
        months = int(math.ceil((ahead + remaining) / installment - 1e-9))
        plan["months_left"] = months
        if last_period:
            m, y = last_period[0]["pay_month"], last_period[0]["pay_year"]
        else:
            m, y = _add_months(today.month, today.year, -1)
        plan["finish_label"] = _month_label(*_add_months(m, y, months))

    alerts = []
    ledger_sum = _money(sum(p["amount"] for p in payments))
    if abs(ledger_sum - paid) > ledger.EPS:
        alerts.append({"level": "danger", "text": "المسدد المسجل في السلفة %.2f لا يطابق مجموع سجل "
                       "السداد %.2f" % (paid, ledger_sum)})
    if is_open:
        if installment <= 0:
            alerts.append({"level": "warn", "text": "لا يوجد قسط «خصم سلفة» في هيكل راتب الموظف، فلن "
                           "تُخصم هذه السلفة من الراتب تلقائياً. أضف القسط من شاشة الرواتب أو سجّل سداداً مباشراً."})
        if ahead > 0:
            alerts.append({"level": "info", "text": "عليه سلف أقدم بمتبقٍّ %.2f تُخصم قبل هذه السلفة" % ahead})
        for p in pending:
            alerts.append({"level": "info", "text": "في مسير %s غير المعتمد خصم سلفة %.2f يُسجَّل عند اعتماده"
                           % (p["label"], p["amount"])})
    elif adv.is_closed and breakdown.get("settle"):
        alerts.append({"level": "info", "text": "أُقفلت بتسوية قدرها %.2f" % breakdown["settle"]})

    last_pay = next((p for p in reversed(payments) if p["amount"] > 0), None)
    return response.json(api.api_ok(data={
        "advance": {
            "id": adv.id, "employee": adv.employee, "advance_type": adv.advance_type,
            "advance_date": adv.advance_date, "amount": amount, "paid_amount": paid,
            "remaining": remaining, "is_closed": bool(adv.is_closed), "closed_date": adv.closed_date,
            "type_name": adv_type.name if adv_type else "",
            "progress": int(round(min(paid / amount, 1) * 100)) if amount > 0 else 0,
            "age_days": (today - adv.advance_date).days if adv.advance_date else None,
            "created_on": adv.created_on, "created_by": names.get(adv.created_by, ""),
            "modified_on": adv.modified_on, "modified_by": names.get(adv.modified_by, ""),
            "last_pay_date": last_pay["pay_date"] if last_pay else None,
        },
        "employee": {
            "id": emp.id if emp else adv.employee, "name": emp.emp_name if emp else "",
            "job": job.name if job else "", "mobile": emp.mobile if emp else "",
        },
        "payments": payments,
        "breakdown": {k: v for k, v in breakdown.items() if abs(v) > ledger.EPS},
        "plan": plan,
        "pending": pending,
        "others": [o for o in others if o["id"] != adv.id],
        "alerts": alerts,
    }))


@can_access(7004)
def new_advance():
    _post_only()
    try:
        errors, clean_data = _validate_advance_payload(request.vars)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        nid = db.emp_advances.insert(
            employee=clean_data["employee"],
            advance_type=clean_data["advance_type"],
            amount=clean_data["amount"],
            paid_amount=0,
            advance_date=clean_data["advance_date"],
            is_closed=False,
            closed_date=None,
        )
        db.commit()
        return response.json(api.api_ok(data=_advance_row(nid) or {"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7004)
def update_advance():
    """يعدّل الموظف والنوع والمبلغ والتاريخ فقط؛ المسدد والحالة من سجل السداد."""
    _post_only()
    try:
        data = request.vars
        advance_id = _int(data.id)
        ledger.lock_advances(db, ids=[advance_id])
        row = db.emp_advances(advance_id)
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        errors, clean_data = _validate_advance_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        paid = _money(row.paid_amount)
        if clean_data["amount"] < paid - ledger.EPS:
            return response.json(api.api_error(
                mess="المبلغ لا يمكن أن يقل عن المسدد منها (%.2f)" % paid))
        has_payments = not db(db.emp_advance_payment.advance == row.id).isempty()
        if clean_data["employee"] != row.employee and (has_payments or paid > ledger.EPS):
            return response.json(api.api_error(mess="لا يمكن نقل سلفة عليها سدادات إلى موظف آخر"))

        row.update_record(**clean_data)
        ledger.recompute(db, row.id, request.now.date())
        db.commit()
        return response.json(api.api_ok(data=_advance_row(row.id) or {"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7004)
def delete_advance():
    _post_only()
    try:
        advance_id = _int(request.args(0))
        ledger.lock_advances(db, ids=[advance_id])
        row = db.emp_advances(advance_id)
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        total = ledger.ledger_total(db, row.id)
        if abs(total) > ledger.EPS or _money(row.paid_amount) > ledger.EPS:
            return response.json(api.api_error(
                mess="على السلفة سدادات مسجلة بقيمة %.2f فلا تُحذف. احذف السداد المباشر من بطاقتها، "
                     "وخصم المسير يُعكس بإلغاء اعتماد فترته." % max(total, _money(row.paid_amount))))
        # سجل صافيه صفر (خصم ثم عكسه) يُحذف معها
        db(db.emp_advance_payment.advance == row.id).delete()
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7004)
def add_payment():
    """سداد سلفة: مباشر من الموظف (cash) دون خصم من الراتب، أو تسوية (settle) للمدير."""
    _post_only()
    data = request.vars
    source = data.source or "cash"
    if source == "settle" and not auth.has_membership("admin"):
        return response.json(api.api_error(mess="التسوية للمدير فقط"))
    try:
        pay_date = datetime.strptime(str(data.pay_date), "%Y-%m-%d").date() if data.pay_date else None
    except ValueError:
        return response.json(api.api_error(mess="تاريخ السداد غير صحيح"))
    try:
        amount = float(data.amount or 0)
        expected = float(data.expected_paid) if data.expected_paid not in (None, "") else None
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="المبلغ غير صحيح"))
    try:
        advance_id = _int(data.advance_id)
        ledger.add_manual(db, advance_id, amount, pay_date, source, data.note,
                          today=request.now.date(), expected_paid=expected)
        db.commit()
        row = _advance_row(advance_id)
        mess = "تم تسجيل السداد"
        if row and row["is_closed"] == "T":
            mess += " وأُقفلت السلفة"
        return response.json(api.api_ok(data=row, mess=mess))
    except ledger.LedgerError as e:
        db.rollback()
        return response.json(api.api_error(mess=e))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7004)
def delete_payment():
    """حذف سداد مباشر أو تسوية أُدخلت خطأً؛ تُسجَّل في auth_event."""
    _post_only()
    payment = db.emp_advance_payment(_int(request.args(0)))
    if not payment:
        return response.json(api.api_error(mess="الدفعة غير موجودة"))
    if payment.source == "settle" and not auth.has_membership("admin"):
        return response.json(api.api_error(mess="حذف التسوية للمدير فقط"))
    try:
        row = ledger.delete_manual(db, payment.id, request.now.date())
        auth.log_event("Advance payment deleted: %(info)s", dict(info=json.dumps({
            "payment": row.id, "advance": row.advance, "employee": row.employee,
            "amount": row.amount, "source": row.source, "pay_date": str(row.pay_date),
            "note": row.note or "", "created_by": row.created_by,
        }, ensure_ascii=False)), origin="advances")
        db.commit()
        return response.json(api.api_ok(data=_advance_row(row.advance), mess="حُذفت الدفعة"))
    except ledger.LedgerError as e:
        db.rollback()
        return response.json(api.api_error(mess=e))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
