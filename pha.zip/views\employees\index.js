var API_BASE = window.location.href + '/../../employees/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
            emp_status: '0'
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        job_titles: [],
        nationalities: [],
        statuses: [],
        loading: false,
    },
    created: function () {
        this.loading = true;
        // تحميل القوائم المرجعية
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.job_titles = data.job_titles;
                this.nationalities = data.nationalities;
                this.statuses = data.statuses;
            }.bind(this));
        // تحميل البيانات
        this.fetchData().then(function (data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                emp_status: this.getData.emp_status
            };
            var url = new URL(API_BASE + 'get_employees');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
        },
        edit_row: function () {
            this.new_row = false;
        },
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = {};
        },
        save_data: function () {
            if (!this.edit_row_data.emp_name) {
                Swal.fire('تنبيه', 'يجب إدخال اسم الموظف', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('emp_name', this.edit_row_data.emp_name);
            formData.append('job_title', this.edit_row_data.job_title || '');
            formData.append('id_number', this.edit_row_data.id_number || '');
            formData.append('start_date', this.edit_row_data.start_date || '');
            formData.append('nationality', this.edit_row_data.nationality || '');
            formData.append('emp_status', this.edit_row_data.emp_status || '');

            var endpoint = this.new_row ? 'new_employee' : 'update_employee';
            if (!this.new_row) {
                formData.append('id', this.edit_row_data.id);
            }

            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.id && data.id > 0) {
                        if (this.new_row) {
                            this.data.splice(0, 0, data);
                            this.data_row_count++;
                        } else {
                            this.$set(this.data, this.selectedRow, data);
                        }
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        this.new_row = true;
                        bootstrap.Modal.getInstance(document.getElementById("empModal")).hide();
                        Swal.fire('تم بنجاح', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                }.bind(this));
        },
        delete_emp: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف الموظف: ' + row.emp_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_employee/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                Swal.fire('تم', 'تم حذف الموظف بنجاح', 'success');
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ أثناء الحذف', 'error');
                            }
                        });
                }
            });
        },
        cancel_data: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        statusBadge: function (statusName) {
            if (statusName === 'على رأس العمل') return 'badge-active';
            if (statusName === 'في إجازة') return 'badge-leave';
            if (statusName === 'منقطع') return 'badge-absent';
            if (statusName === 'مفصول') return 'badge-fired';
            return 'bg-secondary';
        },
    }
});
