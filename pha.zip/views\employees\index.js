var API_BASE = window.location.href + '/../../employees/';

// عدد ومعدوده بقواعد العربية: [واحد، اثنان، 3-10، 11 فأكثر] (مثل _ar_count في الخادم)
function arCount(n, forms) {
    n = Number(n) || 0;
    if (n === 1) return forms[0];
    if (n === 2) return forms[1];
    return n + ' ' + (n >= 3 && n <= 10 ? forms[2] : forms[3]);
}

var app = new Vue({
    el: '#app',
    data: {
        months: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
        DAY_FORMS: ['يوم واحد', 'يومان', 'أيام', 'يوماً'],
        LEAVE_FORMS: ['إجازة واحدة', 'إجازتان', 'إجازات', 'إجازة'],
        INSTALLMENT_FORMS: ['قسط واحد', 'قسطين', 'أقساط', 'قسطاً'],
        // بطاقة الموظف: تُفتح عند اختياره، ويمنع profileSeq رداً متأخراً لموظف سابق من الكتابة فوقها
        profile: { emp: {}, data: null, loading: false, error: '' },
        profileSeq: 0,
        pendingAction: null,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
            emp_status: '0'
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        job_titles: [],
        nationalities: [],
        statuses: [],
        auth_users: [],
        loading: false,
    },
    created: function () {
        this.loading = true;
        // تحميل القوائم المرجعية
        fetch(API_BASE + 'get_lookups')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var d = Api.getData(data);
                this.job_titles = d.job_titles;
                this.nationalities = d.nationalities;
                this.statuses = d.statuses;
                this.auth_users = d.auth_users;
            }.bind(this));
        // تحميل البيانات
        this.fetchData().then(function (data) {
            this.data = Api.getData(data);
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    mounted: function () {
        // من البطاقة إلى التعديل أو الحذف: تُغلق البطاقة أولاً ثم يُنفَّذ الأمر عند تمام إغلاقها.
        // ضغطة أثناء ظهور البطاقة يتجاهل Bootstrap إغلاقها، فيُكمَل الإغلاق عند تمام الظهور.
        var el = document.getElementById('profileModal');
        el.addEventListener('shown.bs.modal', function () {
            if (this.pendingAction) bootstrap.Modal.getOrCreateInstance(el).hide();
        }.bind(this));
        el.addEventListener('hidden.bs.modal', function () {
            var action = this.pendingAction;
            this.pendingAction = null;
            if (action === 'edit' && this.selectedRow > -1) {
                this.edit_row();
                bootstrap.Modal.getOrCreateInstance(document.getElementById('empModal')).show();
            } else if (action === 'delete' && this.selectedRow > -1) {
                this.delete_emp();
            }
        }.bind(this));
    },
    computed: {
        salary: function () { return this.profile.data && this.profile.data.salary; },
        advances: function () { return this.profile.data && this.profile.data.advances; },
        leaves: function () { return (this.profile.data && this.profile.data.leaves) || {}; },
        attendance: function () { return (this.profile.data && this.profile.data.attendance) || {}; },
        leaveHeadline: function () {
            var l = this.leaves;
            if (l.current) return 'في إجازة';
            if (l.due) return l.due.text;
            if (l.last) return 'آخر إجازة ' + l.last.end_date;
            return 'لا توجد إجازات';
        },
        leaveSubline: function () {
            var l = this.leaves;
            if (l.current) return 'حتى ' + l.current.end_date + ' · متبقٍ ' + this.days(l.current.days_left);
            if (l.last) return 'آخر إجازة انتهت ' + l.last.end_date;
            if (l.due) return 'شهر الاستحقاق ' + l.due.name;
            return 'لم يُحدَّد شهر الاستحقاق';
        },
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                emp_status: this.getData.emp_status
            };
            var url = new URL(API_BASE + 'get_employees');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        // اختيار الموظف يفتح بطاقته مباشرة
        openProfile: function (index, row) {
            if (!row) return;
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row, { leave_month: row.leave_month || '' });
            this.pendingAction = null;
            this.profile = { emp: Object.assign({}, row), data: null, loading: true, error: '' };
            bootstrap.Modal.getOrCreateInstance(document.getElementById('profileModal')).show();
            var seq = ++this.profileSeq;
            fetch(API_BASE + 'get_profile?id=' + encodeURIComponent(row.id), {
                headers: { 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (seq !== this.profileSeq) return;
                    if (Api.isOk(data)) {
                        var d = Api.getData(data);
                        this.profile.data = d;
                        this.profile.emp = d.employee;
                    } else {
                        this.profile.error = Api.getError(data) || 'تعذّر تحميل بطاقة الموظف';
                    }
                }.bind(this))
                .catch(function () {
                    if (seq === this.profileSeq) this.profile.error = 'تعذّر الاتصال بالخادم';
                }.bind(this))
                .finally(function () {
                    if (seq === this.profileSeq) this.profile.loading = false;
                }.bind(this));
        },
        leaveProfileTo: function (action) {
            this.pendingAction = action;
            bootstrap.Modal.getOrCreateInstance(document.getElementById('profileModal')).hide();
        },
        edit_row: function () {
            this.new_row = false;
            var row = this.data[this.selectedRow];
            if (row) this.edit_row_data = Object.assign({}, row, { leave_month: row.leave_month || '' });
        },
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = { leave_month: '' };
        },
        // عند إدخال تاريخ المباشرة يُقترح شهره شهراً لاستحقاق الإجازة، ما لم يُحدَّد شهر
        suggestLeaveMonth: function () {
            if (this.edit_row_data.leave_month) return;
            var m = /^\d{4}-(\d{2})-\d{2}$/.exec(this.edit_row_data.start_date || '');
            if (m) this.$set(this.edit_row_data, 'leave_month', parseInt(m[1], 10));
        },
        monthName: function (n) {
            return this.months[(Number(n) || 0) - 1] || '';
        },
        initials: function (name) {
            var parts = String(name || '').trim().split(/\s+/).filter(Boolean);
            if (!parts.length) return '؟';
            return parts[0].charAt(0) + (parts[1] ? ' ' + parts[1].charAt(0) : '');
        },
        money: function (v) {
            return (Number(v) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        timeOf: function (v) {
            return v ? String(v).slice(11, 16) : '';
        },
        days: function (n) {
            return arCount(n, this.DAY_FORMS);
        },
        countText: function (n, forms) {
            return arCount(n, forms);
        },
        paidPct: function (a) {
            var amount = Number(a.amount) || 0;
            return amount > 0 ? Math.min(100, Math.round((Number(a.paid) || 0) / amount * 100)) : 0;
        },
        save_data: function () {
            if (!this.edit_row_data.emp_name) {
                Swal.fire('تنبيه', 'يجب إدخال اسم الموظف', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('emp_name', this.edit_row_data.emp_name);
            formData.append('job_title', this.edit_row_data.job_title || '');
            formData.append('id_number', this.edit_row_data.id_number || '');
            formData.append('start_date', this.edit_row_data.start_date || '');
            formData.append('nationality', this.edit_row_data.nationality || '');
            formData.append('emp_status', this.edit_row_data.emp_status || '');
            formData.append('mobile', this.edit_row_data.mobile || '');
            formData.append('user_id', this.edit_row_data.user_id || '');
            formData.append('leave_month', this.edit_row_data.leave_month || '');

            var endpoint = this.new_row ? 'new_employee' : 'update_employee';
            if (!this.new_row) {
                formData.append('id', this.edit_row_data.id);
            }

            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (Api.isOk(data)) {
                        var rec = Api.getData(data);
                        if (this.new_row) {
                            this.data.splice(0, 0, rec);
                            this.data_row_count++;
                        } else {
                            this.$set(this.data, this.selectedRow, rec);
                        }
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        this.new_row = true;
                        bootstrap.Modal.getInstance(document.getElementById("empModal")).hide();
                        Swal.fire('تم بنجاح', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Api.showError(data);
                    }
                }.bind(this));
        },
        delete_emp: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف الموظف: ' + row.emp_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_employee/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (Api.isOk(data)) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                Swal.fire('تم', 'تم حذف الموظف بنجاح', 'success');
                            } else {
                                Api.showError(data);
                            }
                        });
                }
            });
        },
        cancel_data: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        statusBadge: function (statusName) {
            if (statusName === 'على رأس العمل') return 'badge-active';
            if (statusName === 'في إجازة') return 'badge-leave';
            if (statusName === 'منقطع') return 'badge-absent';
            if (statusName === 'مفصول') return 'badge-fired';
            return 'bg-secondary';
        },
    }
});
