# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
#  مستودع التالف (damaged_store)
# ===========================================================================================
#  بضاعة منتهية أو تالفة كانت مدرجة في مرتجعات الموردين، نُقلت فعلياً إلى مستودع
#  بعيد. الترحيل إليه إجراء داخلي بحت (قرار المالك ٢٠٢٦-٠٩-١٧):
#    - يخصمها من مخزون الصيدلية بحركة «تالف» عبر الوحدة المركزية.
#    - لا يمس حساب المورد ولا يظهر في كشفه — لا سداد ولا إشعار دائن.
#    - المورد يُحفظ هنا معلومةً داخلية للتفاوض على تعويض غير ملزم فقط.
#
#  الجداول منفصلة عمداً: الروابط إلى المرتجع والمورد والصنف والدفعة أرقام عادية
#  لا reference، مع نسخة ثابتة من البيانات وقت الترحيل. حقول reference في web2py
#  تُنشأ بحذف تتابعي، فحذف مورد أو دفعة أو صنف كان سيمحو ما في المستودع معه.
#  الاستثناء item_main: يُنقل يدوياً عند دمج صنفين أو تحويل الباركود (items.py).
# ===========================================================================================

DAMAGED_EXIT_REASONS = {
    "compensation": "تعويض من المورد",
    "destroyed": "إتلاف",
    "correction": "تصحيح خطأ",
}

# عملية ترحيل واحدة (فاتورة مرتجع كاملة أو أسطر مختارة منها)
db.define_table(
    "damaged_store",
    Field("src_id", "integer", label="رقم المرتجع الأصلي"),
    Field("src_name", length=270, label="وصف المرتجع"),
    Field("src_date", "date", label="تاريخ المرتجع"),
    Field("src_created_by", "integer", label="مُدخل المرتجع"),
    Field("src_created_on", "datetime", label="وقت إدخال المرتجع"),
    Field("supplier", "integer", label="المورد"),
    Field("supplier_name", length=270, label="اسم المورد"),
    # يختاره المدير صراحةً في كل ترحيل (قرار المالك ٢٠٢٦-٠٩-١٧):
    #   خصم  = البضاعة ما زالت محسوبة في رصيد الصيدلية (تالف جديد من مورد لا يُرجع)
    #   بدون = الرصيد صحيح أصلاً (جُرد الصنف بدونها) — خصمها يُنقص مخزوناً موجوداً فعلاً
    Field("deduct_stock", "boolean", default=True, label="خُصم من مخزون الصيدلية"),
    Field("note", "text", label="ملاحظة"),
    auth.signature,
    on_define=id_label("م"),
)

# سطر في المستودع: المتبقي فيه = qty - qty_out
db.define_table(
    "damaged_store_line",
    Field("damaged_store", "reference damaged_store", label="الترحيل"),
    Field("src_line_id", "integer", label="سطر المرتجع الأصلي"),
    Field("item_main", "integer", label="الصنف"),
    Field("item_det", "integer", label="الدفعة"),
    Field("barcode", length=50, label="الباركود"),
    Field("item_name", length=460, label="اسم الصنف"),
    Field("expiration_date", "date", label="تاريخ الصلاحية"),
    Field("qty", "double", default=0, label="الكمية المرحّلة"),
    # أقل من qty حين لم يكفِ رصيد الدفعة: لا يُخصم أكثر من الموجود ولا يُنزل
    # رصيد تحت الصفر، والفرق غالباً تكرار إدراج أو صنف يحتاج جرداً
    Field("stock_deducted", "double", default=0, label="المخصوم من المخزون"),
    Field("qty_out", "double", default=0, label="المُخرَج"),
    Field("buy_price", "double", default=0, label="سعر الشراء"),
    Field("vat", "double", default=0, label="الضريبة"),
    auth.signature,
    on_define=id_label("م"),
)

# إخراج من المستودع (جزئي أو كلي). لا أثر له على المخزون — خُصم عند الترحيل
db.define_table(
    "damaged_store_exit",
    Field("line", "reference damaged_store_line", label="السطر"),
    Field("qty", "double", default=0, label="الكمية"),
    Field("reason", length=20, requires=IS_IN_SET(list(DAMAGED_EXIT_REASONS)),
          label="السبب"),
    Field("note", "text", label="ملاحظة"),
    auth.signature,
    on_define=id_label("م"),
)
