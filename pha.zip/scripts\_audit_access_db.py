# -*- coding: utf-8 -*-
"""
فحص تطابق الشاشات والصلاحيات مع قاعدة البيانات الفعلية.
تشغيل: uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/_audit_access_db.py
"""
import os, re

# 1) السجل المرجعي من controllers/setup.py
setup_path = os.path.join(request.folder, "controllers", "setup.py")
src = open(setup_path, encoding="utf-8").read()
m = re.search(r"screens_code\s*=\s*\[(.*?)\n\]", src, re.S)
registry = {}
for name, code in re.findall(
    r'\{[^{}]*?"name"\s*:\s*"([^"]+)"[^{}]*?"screen_code"\s*:\s*(\d+)[^{}]*?\}', m.group(1)
):
    registry[int(code)] = name

# 2) الشاشات في قاعدة البيانات
db_rows = db(db.screens.id > 0).select()
db_codes = {}
for r in db_rows:
    db_codes.setdefault(r.screen_code, []).append((r.id, r.name))

print("=" * 60)
print("عدد الشاشات في السجل المرجعي:", len(registry))
print("عدد الشاشات في قاعدة البيانات:", len(db_rows))

# 3) مسجلة في الكود ومفقودة من القاعدة
missing_in_db = sorted(set(registry) - set(db_codes))
print("\n--- شاشات في السجل ومفقودة من قاعدة البيانات:", len(missing_in_db))
for c in missing_in_db:
    print("  ", c, registry[c])

# 4) موجودة في القاعدة وليست في السجل (ستُحذف عند فتح صفحة الشاشات!)
extra_in_db = sorted(set(db_codes) - set(registry))
print("\n--- شاشات في قاعدة البيانات وليست في السجل المرجعي:", len(extra_in_db))
for c in extra_in_db:
    for rid, nm in db_codes[c]:
        print("  ", c, nm, "(id=%s)" % rid)

# 5) أكواد مكررة في قاعدة البيانات
dups = {c: v for c, v in db_codes.items() if len(v) > 1}
print("\n--- أكواد شاشات مكررة في قاعدة البيانات:", len(dups))
for c, v in dups.items():
    print("  ", c, v)

# 6) صلاحيات يتيمة: تشير لشاشة غير موجودة أو لمستخدم غير موجود
screen_ids = {r.id for r in db_rows}
user_ids = {r.id for r in db(db.auth_user.id > 0).select(db.auth_user.id)}
rules = db(db.screens_rules.id > 0).select()
orphan_screen = [r for r in rules if r.screens not in screen_ids]
orphan_user = [r for r in rules if r.to_user not in user_ids]
print("\n--- إجمالي سجلات الصلاحيات screens_rules:", len(rules))
print("صلاحيات تشير لشاشة غير موجودة:", len(orphan_screen))
for r in orphan_screen:
    print("   rule id=%s user=%s screen_id=%s" % (r.id, r.to_user, r.screens))
print("صلاحيات تشير لمستخدم غير موجود:", len(orphan_user))
for r in orphan_user:
    print("   rule id=%s user=%s screen_id=%s" % (r.id, r.to_user, r.screens))

# 7) شاشات لا توجد لها أي صلاحية مفعّلة (can_log_in) لأي مستخدم غير أدمن
active_screen_ids = {r.screens for r in rules if r.can_log_in}
no_perm = [r for r in db_rows if r.id not in active_screen_ids]
print("\n--- شاشات بلا أي صلاحية دخول ممنوحة لأي مستخدم:", len(no_perm))
for r in sorted(no_perm, key=lambda x: x.screen_code or 0):
    print("  ", r.screen_code, r.name)

print("=" * 60)
