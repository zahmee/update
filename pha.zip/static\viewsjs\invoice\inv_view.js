(function () {
    var urls = window.INV_VIEW_URLS || {};

    new Vue({
        el: '#app',
        data: {
            urls: urls,
            canDelete: urls.canDelete === true,
            selected_method: '1',
            inv_no: '',
            payload: {},
            master: {},
            detail: [],
            totals: {},
            loading: false
        },
        computed: {
            hasInvoice: function () {
                return this.master && Number(this.master.id || 0) > 0;
            }
        },
        methods: {
            buildUrl: function (base) {
                var params = new URLSearchParams();
                params.set('inv_type', this.selected_method);
                params.set('inv_id', this.inv_no);
                return base + '?' + params.toString();
            },
            getitem: function () {
                var self = this;
                if (!self.inv_no) {
                    Swal.fire('تنبيه', 'يجب إدخال رقم الفاتورة', 'warning');
                    return;
                }
                self.loading = true;
                self.clearResult();

                Api.get(self.buildUrl(self.urls.data)).then(function (response) {
                    if (Api.isOk(response)) {
                        self.payload = Api.getData(response) || {};
                        self.master = self.payload.master || {};
                        self.detail = self.payload.details || [];
                        self.totals = self.payload.totals || {};
                    } else {
                        Api.showError(response);
                    }
                    self.loading = false;
                });
            },
            clearResult: function () {
                this.payload = {};
                this.master = {};
                this.detail = [];
                this.totals = {};
            },
            printInvoice: function () {
                if (!this.master || !this.master.print_url) {
                    return;
                }
                window.open(this.master.print_url, '_blank');
            },
            delete_inv: function () {
                var self = this;
                if (!self.hasInvoice || !self.canDelete) {
                    return;
                }
                Swal.fire({
                    title: 'هل أنت متأكد؟',
                    text: 'سيتم حذف الفاتورة وتفاصيلها ولا يمكن التراجع من هذه الشاشة',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#b42318',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'نعم، احذف',
                    cancelButtonText: 'إلغاء'
                }).then(function (result) {
                    if (!result.value) {
                        return;
                    }
                    Api.get(self.buildUrl(self.urls.deleteUrl)).then(function (response) {
                        if (Api.isOk(response)) {
                            Api.showSuccess(response.mess || 'تم حذف الفاتورة');
                            self.clearResult();
                            self.inv_no = '';
                        } else {
                            Api.showError(response);
                        }
                    });
                });
            },
            formatNum: function (value) {
                return Number(value || 0).toLocaleString('en-US', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 2
                });
            }
        }
    });
})();
