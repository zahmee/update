var baseUrl = purl + '/../';

var app = new Vue({
    el: '#app',
    data: {
        items_reorder: items_reorder_id,
        data: [],
        data_all: [],
        show_spinner: true,
        // Column visibility
        show_best_price: false,
        show_supp_name: true,
        show_best_price_supp: false,
        show_type: false,
        show_count: true,
        show_avreg: true,
        show_id: true,
        show_important: true,
        item_id: true,
        text_ltr: false,
        new_need: 0.0,
        // Pagination
        pageSize: 200,
        currentPage: 1,
        // Sorting
        sortField: '',
        sortAsc: true,
        // Best suppliers lazy loading
        bestSuppLoaded: false,
        bestSuppLoading: false,
    },
    computed: {
        totalPages: function() {
            return Math.ceil(this.data.length / this.pageSize) || 1;
        },
        dataOffset: function() {
            return (this.currentPage - 1) * this.pageSize;
        },
        paginatedData: function() {
            var start = this.dataOffset;
            return this.data.slice(start, start + this.pageSize);
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) pages.push(i);
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
        dataCount: function() {
            return this.data.length;
        }
    },
    created: function() {
        var url = baseUrl + 'get_items_reorder_detail/' + this.items_reorder;
        fetch(url, {
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        })
        .then(function(r) { return r.json(); })
        .then(function(body) {
            if (body && body.length) {
                var ob = parseFloat(order_by) || 1;
                body.forEach(function(e) {
                    e.best_price_supp_n = '';
                    if (e.order_items === 0) {
                        e.important = 0;
                    } else if (e.quantity === 0 && e.order_items > 0) {
                        e.important = 9999;
                    } else {
                        e.important = Number((((e.order_items / e.quantity) * 100) / ob).toFixed(0));
                    }
                });
                this.data = body;
                this.data_all = body.map(function(e) {
                    return Object.assign({}, e, { order_items_back: e.order_items });
                });
            }
            this.show_spinner = false;
        }.bind(this))
        .catch(function() { this.show_spinner = false; }.bind(this));
    },
    methods: {
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.currentPage = page;
        },
        sortData: function(field) {
            if (this.sortField === field) {
                this.sortAsc = !this.sortAsc;
            } else {
                this.sortField = field;
                this.sortAsc = true;
            }
            var asc = this.sortAsc;
            this.data.sort(function(a, b) {
                var va = a[field];
                var vb = b[field];
                if (va == null) va = '';
                if (vb == null) vb = '';
                if (typeof va === 'number' && typeof vb === 'number') {
                    return asc ? va - vb : vb - va;
                }
                va = String(va).toLowerCase();
                vb = String(vb).toLowerCase();
                var cmp = va < vb ? -1 : va > vb ? 1 : 0;
                return asc ? cmp : -cmp;
            });
            this.currentPage = 1;
        },
        // ── Client-side filters ──
        restore_data: function() {
            this.data = this.data_all.map(function(row) {
                return Object.assign({}, row, { order_items: row.order_items_back });
            });
            this.currentPage = 1;
        },
        remove_z: function() {
            this.data = this.data.filter(function(e) { return e.order_items > 0; });
            this.currentPage = 1;
        },
        add_avreg_0: function() {
            this.data = this.data.filter(function(e) { return e.avrg_items === 0; });
            this.currentPage = 1;
        },
        remove_count: function() {
            this.data = this.data.filter(function(e) { return e.quantity < 1; });
            this.currentPage = 1;
        },
        remove_supplier: function(sup) {
            this.data = this.data.filter(function(e) { return e.supplier !== sup; });
            this.currentPage = 1;
        },
        remove_item: function(index) {
            this.data.splice(index, 1);
        },
        change_need: function() {
            var mult = parseFloat(this.new_need) || 0;
            this.data = this.data.map(function(row) {
                row.order_items = row.order_items * mult;
                return row;
            });
        },
        // ── Column toggles ──
        remove_best_price: function() { this.show_best_price = !this.show_best_price; },
        remove_supp_name: function() { this.show_supp_name = !this.show_supp_name; },
        remove_best_price_supp: function() {
            this.show_best_price_supp = !this.show_best_price_supp;
            if (this.show_best_price_supp && !this.bestSuppLoaded) {
                this.loadBestSuppliers();
            }
        },
        remove_type: function() { this.show_type = !this.show_type; },
        remove_count_coul: function() { this.show_count = !this.show_count; },
        remove_avg: function() { this.show_avreg = !this.show_avreg; },
        remove_important: function() { this.show_important = !this.show_important; },
        // ── Lazy load best suppliers ──
        loadBestSuppliers: function() {
            if (this.bestSuppLoaded || this.bestSuppLoading) return;
            this.bestSuppLoading = true;
            var url = baseUrl + 'get_best_suppliers/' + this.items_reorder;
            fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            })
            .then(function(r) { return r.json(); })
            .then(function(suppliers) {
                var map = {};
                suppliers.forEach(function(s) { map[s.items_main] = s.supp_name; });
                this.data.forEach(function(row) {
                    if (map[row.items_main]) row.best_price_supp_n = map[row.items_main];
                });
                this.data_all.forEach(function(row) {
                    if (map[row.items_main]) row.best_price_supp_n = map[row.items_main];
                });
                this.bestSuppLoaded = true;
                this.bestSuppLoading = false;
                this.data = [].concat(this.data);
            }.bind(this))
            .catch(function() { this.bestSuppLoading = false; }.bind(this));
        },
        // ── Navigation ──
        show_items_main: function(id) {
            window.open(purl + '/../../items/itm_rep_det/' + id);
        },
        delete_reorder: function(index) {
            Swal.fire({
                title: 'هل انت متأكد',
                text: 'انت على وشك حذف طلبية هذه العملية لا يمكن التراجع عنها',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا',
            }).then(function(result) {
                if (result.value) {
                    window.open(purl + '/../delete_order/' + index, '_self');
                }
            });
        },
    }
});
