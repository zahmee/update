# -*- coding: utf-8 -*-
"""اختبارات ترميز باركود الملصقات (بلا web2py ولا قاعدة بيانات).

Run: python -B scripts/test_label_barcodes.py
"""
import sys
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP / "modules"))
import label_barcodes as lb


class CheckDigit(unittest.TestCase):
    def test_known_gtins(self):
        self.assertTrue(lb.gs1_check_ok("6285147003426"))
        self.assertTrue(lb.gs1_check_ok("96385074"))
        self.assertTrue(lb.gs1_check_ok("036000291452"))
        self.assertFalse(lb.gs1_check_ok("6285147003427"))
        self.assertFalse(lb.gs1_check_ok("za0282"))
        self.assertFalse(lb.gs1_check_ok("249108"))
        self.assertFalse(lb.gs1_check_ok(""))


class ItemCode(unittest.TestCase):
    def assertBars(self, out, sym, text):
        self.assertEqual(out["sym"], sym)
        self.assertEqual(out["text"], text)
        self.assertEqual(out["modules"], len(out["bars"]))
        self.assertTrue(set(out["bars"]) <= {"0", "1"})
        left, right = lb.QUIET[sym]
        self.assertEqual(out["bars"][:left], "0" * left)
        self.assertEqual(out["bars"][-right:], "0" * right)
        self.assertEqual(out["bars"][left], "1")
        self.assertEqual(out["bars"][-right - 1], "1")

    def test_ean13_valid(self):
        out = lb.encode_item_code("6285147003426")
        self.assertBars(out, "EAN13", "6285147003426")
        self.assertEqual(out["modules"], 95 + 11 + 7)
        self.assertIsNone(out["note"])

    def test_ean13_wrong_check_digit_keeps_text(self):
        out = lb.encode_item_code("6285147003427")
        self.assertBars(out, "CODE128", "6285147003427")
        self.assertTrue(out["note"])

    def test_ean8_and_upca(self):
        self.assertBars(lb.encode_item_code("96385074"), "EAN8", "96385074")
        self.assertBars(lb.encode_item_code("036000291452"), "UPCA", "036000291452")

    def test_gtin14_and_alnum_are_code128(self):
        self.assertBars(lb.encode_item_code("16285147003423"), "CODE128", "16285147003423")
        self.assertBars(lb.encode_item_code("za0282"), "CODE128", "za0282")
        self.assertBars(lb.encode_item_code("6-130-83"), "CODE128", "6-130-83")
        self.assertBars(lb.encode_item_code(" 0012345 "), "CODE128", "0012345")

    def test_unencodable(self):
        self.assertIsNone(lb.encode_item_code(""))
        self.assertIsNone(lb.encode_item_code(None))
        self.assertIsNone(lb.encode_item_code("عربي"))
        self.assertIsNone(lb.encode_code128("  "))

    def test_batch_id_code128_subset_c(self):
        out = lb.encode_code128("249108")
        self.assertBars(out, "CODE128", "249108")
        # Start C + 3 أزواج + تحقق = 5 رموز × 11 + توقف 13 = 68 وحدة
        self.assertEqual(out["modules"], 68 + 20)

    def test_rects(self):
        self.assertEqual(lb.rects("0110100"), [(1, 2), (4, 1)])
        self.assertEqual(lb.rects("1"), [(0, 1)])
        self.assertEqual(lb.rects("000"), [])


if __name__ == "__main__":
    unittest.main()
