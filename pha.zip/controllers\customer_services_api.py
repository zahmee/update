# -*- coding: utf-8 -*-
import json
import logging

import api_helpers as api
import customer_maintenance as maintenance


def _allowed(code, permission="can_log_in"):
    if auth.has_membership("admin"):
        return True
    return bool(auth.user_id and db(
        (db.screens.screen_code == code)
        & (db.screens_rules.screens == db.screens.id)
        & (db.screens_rules.to_user == auth.user_id)
        & (db.screens_rules.can_log_in == True)
        & (db.screens_rules[permission] == True)
    ).count())


def _post():
    response.headers["Cache-Control"] = "private, no-store"
    if request.env.request_method != "POST":
        response.headers["Allow"] = "POST"
        raise maintenance.MaintenanceError("هذه العملية تتطلب طلبًا من شاشة خدمات العملاء.", 405)
    if not URL.verify(request, user_signature=True):
        raise maintenance.MaintenanceError("انتهت صلاحية الصفحة؛ حدّثها ثم حاول مجددًا.", 403)


def _error(error):
    if isinstance(error, maintenance.MaintenanceError):
        response.status = error.status
        return response.json(api.api_error(mess=str(error)))
    logging.getLogger("customer_maintenance").exception("Customer services failed")
    response.status = 500
    return response.json(api.api_error(mess="تعذّر إكمال العملية. حدّث الفحص ثم حاول مجددًا."))


@can_access(1001)
def overview():
    response.headers["Cache-Control"] = "private, no-store"
    try:
        if request.env.request_method not in ("GET", "HEAD"):
            response.headers["Allow"] = "GET, HEAD"
            raise maintenance.MaintenanceError("طريقة الطلب غير مسموحة.", 405)
        data = maintenance.overview(maintenance.load_rows(db), maintenance.account_snapshot(db), request.now.date())
        data["permissions"] = dict(edit=_allowed(1001, "can_edit"), purchases=_allowed(1002),
                                   payments=_allowed(1003), all_payments=_allowed(1004),
                                   status=_allowed(1006), admin=auth.has_membership("admin"))
        return response.json(api.api_ok(data=data))
    except Exception as error:
        return _error(error)


@can_access(1001)
def preview():
    try:
        _post()
        operation = request.post_vars.get("operation")
        maintenance.operation_for(operation)
        data, plan = maintenance.preview(maintenance.load_rows(db), operation, auth.user_id)
        session.customer_maintenance_plan = plan
        return response.json(api.api_ok(data=data))
    except Exception as error:
        return _error(error)


@can_access(1001)
def apply():
    try:
        _post()
        if not _allowed(1001, "can_edit"):
            raise maintenance.MaintenanceError("تحتاج إلى صلاحية تعديل العملاء لتطبيق الصيانة.", 403)
        try:
            ids = json.loads(request.post_vars.get("ids") or "null")
        except (ValueError, TypeError):
            raise maintenance.MaintenanceError("بيانات الاختيار غير صحيحة.")
        result = maintenance.apply(db, session.customer_maintenance_plan,
                                   request.post_vars.get("token"), ids, auth.user_id)
        auth.log_event("Customer maintenance: %(operation)s; customers=%(ids)s; fields=%(fields)s",
                       dict(operation=result["operation"], ids=sorted(ids), fields=result["fields"]),
                       origin="customer_maintenance")
        db.commit()
        session.customer_maintenance_plan = None
        return response.json(api.api_ok(data=result, mess="تم حفظ التغييرات للعملاء المحددين."))
    except Exception as error:
        db.rollback()
        if isinstance(error, maintenance.MaintenanceError) and error.status == 409:
            session.customer_maintenance_plan = None
        return _error(error)
