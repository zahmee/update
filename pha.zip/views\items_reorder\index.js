var app = new Vue({
    el: '#app',
    data: {
        URL: this.purl,
        data: [],
        loading: true,
    },
    computed: {
        totalItems() {
            return this.data.reduce((sum, item) => sum + (item.row_count || 0), 0);
        },
        processingCount() {
            return this.data.filter(item => item.jop_end_time).length;
        }
    },
    created() {
        this.loadData();
    },
    methods: {
        loadData() {
            this.loading = true;
            this.$http.get(this.URL + '/../get_items_reorder').then(response => {
                if (response.body && response.body !== "") {
                    this.data = response.body;
                }
                this.loading = false;
            }).catch(() => {
                this.loading = false;
            });
        },
        new_reorder() {
            window.open(purl + "/../new", '_self');
        },
        delete_reorder(id, index) {
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: "سيتم حذف الطلبية رقم " + id + " — لا يمكن التراجع",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc2626',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                reverseButtons: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    this.data.splice(index, 1);
                    window.open(purl + "/../delete_order/" + id, '_self');
                }
            });
        },
        preparation_reorder(id) {
            window.open(purl + "/../preparation_reorder/" + id, '_self');
        },
        show_reorder(id) {
            window.open(purl + "/../show_reorder/" + id, '_self');
        },
    },
});
