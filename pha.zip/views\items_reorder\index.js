Vue.component('v-select', VueSelect.VueSelect);

var app = new Vue({
    el: '#app',
    data: {
        URL: purl,
        data: [],
        loading: true,
        // New reorder form data
        new_row: {
            dis: '',
            supp_id: { id: -1, name: 'بدون اختيار' },
            type_id: '-1',
            avrg_by: 4,
            order_by: 1
        },
        suppliers: [],
        type_data: [],
        formLoading: false,
    },
    computed: {
        totalItems() {
            return this.data.reduce((sum, item) => sum + (item.row_count || 0), 0);
        },
        processingCount() {
            return this.data.filter(item => item.jop_end_time).length;
        },
        FormErr() {
            if (this.new_row.dis !== "" && this.new_row.avrg_by > 0 && this.new_row.order_by > 0) {
                if (this.new_row.supp_id.id === -1 && this.new_row.type_id === "-1") {
                    return false;
                }
                return true;
            } else {
                return false;
            }
        }
    },
    created() {
        this.loadData();
    },
    methods: {
        loadData() {
            this.loading = true;
            this.$http.get(get_items_reorder_url).then(response => {
                if (response.body && response.body !== "") {
                    this.data = response.body;
                }
                this.loading = false;
            }).catch(() => {
                this.loading = false;
            });
        },
        loadFormData() {
            if (this.type_data.length === 0) {
                this.$http.get(get_key_types_url).then(response => {
                    if (response.body && response.body !== "") {
                        this.type_data = response.body;
                    }
                });
            }
            if (this.suppliers.length === 0) {
                this.$http.get(get_suppliers_url).then(response => {
                    if (response.body && response.body !== "") {
                        this.suppliers = response.body;
                        this.suppliers.unshift({ name: "بدون اختيار", id: -1 });
                    }
                });
            }
        },
        resetForm() {
            this.new_row = {
                dis: '',
                supp_id: { id: -1, name: 'بدون اختيار' },
                type_id: '-1',
                avrg_by: 4,
                order_by: 1
            };
        },
        new_reorder() {
            this.loadFormData();
            this.resetForm();
            var modalEl = document.getElementById('newReorderModal');
            var modal = new bootstrap.Modal(modalEl);
            modal.show();
        },
        saveNewOrder() {
            this.formLoading = true;
            this.$http.post(
                addit_url,
                this.new_row
            ).then(response => {
                this.formLoading = false;
                if (response.body === '0') {
                    var modalEl = document.getElementById('newReorderModal');
                    var modal = bootstrap.Modal.getInstance(modalEl);
                    if (modal) modal.hide();
                    this.loadData();
                    Swal.fire({
                        icon: 'success',
                        title: 'تم إنشاء الطلبية',
                        timer: 1500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'خطأ',
                        text: 'لم يتم إنشاء الطلبية'
                    });
                }
            }).catch(err => {
                this.formLoading = false;
                console.error(err);
                Swal.fire({
                    icon: 'error',
                    title: 'خطأ',
                    text: 'حدث خطأ أثناء الحفظ'
                });
            });
        },
        delete_reorder(id, index) {
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: "سيتم حذف الطلبية رقم " + id + " — لا يمكن التراجع",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc2626',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                reverseButtons: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    this.data.splice(index, 1);
                    window.open(purl + "/../delete_order/" + id, '_self');
                }
            });
        },
        preparation_reorder(id) {
            window.open(purl + "/../preparation_reorder/" + id, '_self');
        },
        show_reorder(id) {
            window.open(purl + "/../show_reorder/" + id, '_self');
        },
    },
});
