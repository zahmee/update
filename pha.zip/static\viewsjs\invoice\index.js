var app = new Vue({
    el: '#app',
    data: {
        newTodo: '',
        NewItem: [],
        NewItemCount: 1,
        AllItems: [],
        todos: [],
        URL: this.purl,
        NowDate: new Date(),
        itemNotFound: false,
        key_payment_method: [{
            name : '' ,
            id : 0
        }],
        selected_method: 1,
        customer: {
            'id': 1,
            'name': 'عميل نقدي' ,
            'show': false ,
        },
        serchCustomar: {
            show: false,
            value: ''
        },
        serchCustomarList: [],
        serchItems: {
            show: false,
            vlaue: ''
        },
        serchItemsListDet: [],
        serchItemsListMaster: [],
        VAT: 0.0,
        discount: 0.0,
        invoce_no: 0,
        GivenByCustomer : 0.0 ,
        a:new AudioContext() ,

    },
    created: function () {
        this.$http.get(this.URL + '/../get_payment_method').then(response => {
            // get body data
            if (Api.isOk(response.body)) {
                this.key_payment_method = Api.getData(response.body);
            }
        }, response => {
            //
        });
    },
    methods: {
        getitem: function () {
            if (!this.NewItem) {
                this.itemNotFound = true;
                this.NewItemCount = 1;
                return;
            }
            this.$http.get(this.URL + '/../../invoice/getit/?itid=' + this.NewItem).then(response => {
                // get body data
                var items = Api.getData(response.body);
                if (Api.isOk(response.body) && items && items.length > 0) {
                    items[0]['count'] = this.NewItemCount;
                    items[0]['total'] = items[0]['public_price'] * this.NewItemCount;
                    this.AllItems.push(items[0]);
                    this.NewItem = '';
                    this.itemNotFound = false;
                    this.NewItemCount = 1;
                    this.$nextTick(() => {
                        var w = this.$refs.itemsWrapper;
                        if (w) w.scrollTop = w.scrollHeight;
                    });
                } else {
                    this.NewItem = '';
                    this.itemNotFound = true;
                    this.NewItemCount = 1;
                }
            }, response => {
                this.NewItem = '';
            });
        },
        getcustomer: function () {
            if (!this.customer.id) {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
                return;
            }
            this.$http.get(this.URL + '/../../invoice/getco/' + this.customer.id).then(response => {
                // get body data
                var customers = Api.getData(response.body);
                if (Api.isOk(response.body) && customers && customers.length > 0) {
                    this.customer = customers[0]
                    this.customer.show = true;
                } else {
                    this.customer.id = 1;
                    this.customer.name = 'عميل نقدي';
                    this.customer.show = false;
                }
            }, response => {
                this.customer.id = 1;
                this.customer.name = 'عميل نقدي';
                this.customer.show = false;
            });
        },
        removeItem: function (index) {
            this.AllItems.splice(index, 1);
        },
        printOne: function (index) {
            var item = this.AllItems[index];
            Swal.fire({
                title: item.name,
                html:
                    '<table style="width:100%;text-align:right;font-size:1rem;border-collapse:collapse;">' +
                    '<tr><td style="padding:6px 4px;color:#555;">رقم الصنف</td><td style="padding:6px 4px;font-weight:700;">' + item.id + '</td></tr>' +
                    '<tr style="background:#f8f9fa;"><td style="padding:6px 4px;color:#555;">السعر</td><td style="padding:6px 4px;font-weight:700;">' + item.public_price.toFixed(2) + ' ر.س</td></tr>' +
                    '<tr><td style="padding:6px 4px;color:#555;">الكمية</td><td style="padding:6px 4px;font-weight:700;">' + item.count + '</td></tr>' +
                    '<tr style="background:#f8f9fa;"><td style="padding:6px 4px;color:#555;">الضريبة</td><td style="padding:6px 4px;">' + item.vat + '</td></tr>' +
                    '<tr><td style="padding:6px 4px;color:#1565c0;font-weight:700;">الإجمالي</td><td style="padding:6px 4px;color:#1565c0;font-weight:700;font-size:1.15rem;">' + item.total.toFixed(2) + ' ر.س</td></tr>' +
                    '<tr style="background:#f8f9fa;"><td style="padding:6px 4px;color:#555;">الصلاحية</td><td style="padding:6px 4px;">' + (item.expiration_date || '—') + '</td></tr>' +
                    '</table>',
                icon: 'info',
                confirmButtonText: 'إغلاق',
                customClass: { popup: 'text-end' }
            });
        },
        getcount: function () {
            this.NewItemCount = this.NewItem;
            this.NewItem = '';
        },
        discountFun: function () {
            newval = this.total * 0.1;
            if (this.discount > newval) {
                this.discount = 0;
            }
        },
        findCustomer: function () {
            this.serchCustomar.show = !this.serchCustomar.show;
            //this.$refs.refsearchCustomer.focus();
            //this.$refs.searchCustomer.$el.focus()
        },
        SerchCustomer: function () {
            if (this.serchCustomar.value.length > 2) {
                this.$http.get(this.URL + '/../../invoice/search_c/?itid=' + this.serchCustomar.value).then(response => {
                    // get body data
                    var results = Api.getData(response.body);
                    if (Api.isOk(response.body) && results && results.length > 0) {
                        this.serchCustomarList = results;
                    } else {
                        this.serchCustomarList = [];
                        this.customer.id = 1;
                        this.customer.name = 'عميل نقدي';
                    }
                }, response => {
                    //this.customer.id = 1;
                    //this.customer.name = 'عميل نقدي';
                });
            } else {
                this.serchCustomarList = [];
            }
        },
        selectSerchCustomer: function (index) {
            this.customer.id = this.serchCustomarList[index].id;
            this.getcustomer() ;
            this.serchCustomar.show = !this.serchCustomar.show;
        },
        findItems: function () {
            this.serchItems.show = !this.serchItems.show;
        },
        SerchItems: function () {
            if (this.serchItems.value.length > 2) {
                this.$http.get(this.URL + '/../../items_qry/search_item/?itid=' + this.serchItems.value).then(response => {
                    if (response.body != "") {
                        this.serchItemsListMaster = response.body;
                    } else {
                        this.serchItemsListMaster = [];
                    }
                });
            } else {
                this.serchItemsListMaster = [];
            }
        },
        selectserchItems: function (index) {
            serch_item_det  = this.serchItemsListMaster[index];
            this.$http.get(this.URL + '/../../items_qry/search_item_det/?itid=' + serch_item_det.id ).then(response => {
                if (response.body != "") {
                    this.serchItemsListDet = response.body;
                } else {
                    this.serchItemsListMaster = [];
                }
            });
            /*
            newiteml = this.serchItemsList[index];
            newiteml['count'] = this.NewItemCount ;
            newiteml['total'] = newiteml['public_price'] * this.NewItemCount  ;
            this.AllItems.push(newiteml);
            console.log(newiteml);
            console.log(this.AllItems);
            */
        },
        selectserchItemsDet: function (index) {
            this.NewItem = this.serchItemsListDet[index]['id']
            this.getitem();
            this.serchItemsListMaster = [];
            this.serchItemsListDet = [];
            this.serchItems.value = '';
            this.NewItem = '';
            this.itemNotFound = false;
            this.NewItemCount = 1;
            this.serchItems.show = !this.serchItems.show;

        },
        SaveAll: function () {
            alldata = {};
            alldata['itm'] = this.AllItems;
            alldata['total'] = this.total.toFixed(2) ;
            alldata['discount'] = this.discount;
            alldata['totalAfterDiscount'] = this.totalAfterDiscount.toFixed(2) ;
            alldata['vat'] = this.vat.toFixed(2) ;
            alldata['totalAfterAll'] = this.totalAfterAll.toFixed(2) ;
            alldata['customer'] = this.customer.id;
            alldata['method'] = this.selected_method;
            
            this.$http.post(this.URL + '/../save/', JSON.stringify(alldata), { emulateJSON: true }).then(response => {
                if (Api.isOk(response.body) && response.body.invno > 0) {
                    this.invoce_no = response.body.invno;
                    return 'ok';
                } else {
                    console.log('err');
                    if (!Api.isOk(response.body)) Api.showError(response.body);
                    return;
                }
            }, response => {

                //this.customer.id = 1;
                //this.customer.name = 'عميل نقدي';
            }).then(res => {
                if (res == "ok") {
                    
                    var newpr = $('#pr').html();
                    $(newpr).printThis({
                        debug: false,
                        importCSS: false,
                        importStyle: true,
                        printContainer: true,
                        pageTitle: "الفاتورة",
                        removeInline: false,
                        header: "<h1>فاتورة</h1>",
                        footer: '<hr>'
                    });
                    
                    return 'ok';
                }
            }).then(res => {
                if (res == "ok") {
                    this.AllItems = [];
                    this.discount = 0;
                    this.customer.id = 1;
                    this.customer.name = "مبيعات نقدية";
                    this.selected_method = 1;
                    this.customer.show = false ;
                    this.GivenByCustomer = 0 ;
                }
            });
        },
        AddHalal : function(){
            var me = this ;
            this.AllItems.forEach(function (el, index) {
                if (el.id ===1){
                    me.AllItems.splice(index, 1);
                }
            }) ;
            var baqee = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            this.NewItem = 1 ;
            this.NewItemCount = Math.floor(baqee * 100).toFixed(0);
            this.getitem() ;
            // alert (baqee) ;
        } ,
        beep : function(vol, freq, duration){
            v=a.createOscillator()
            u=a.createGain()
            v.connect(u)
            v.frequency.value = freq
            v.type = "square"
            u.connect(a.destination)
            u.gain.value = vol * 0.01
            v.start(a.currentTime)
            v.stop(a.currentTime + duration * 0.001)
            } ,
    },
    computed: {
        // a computed getter
        total: function () {
            total = 0.0;
            this.AllItems.forEach(function (element) {
                element.total = (element.public_price * element.count) + (element.public_price * element.count * element.vat)
                total += (element.public_price * element.count);
            });
            return total;
        },
        now: function () {
            return Date.now()
        },
        vat: function () {
            vat = 0.0;
            this.AllItems.forEach(function (element) {
                el_vat = element.public_price * element.count * element.vat;
                vat += el_vat;
            });
            return vat;
        },
        totalAfterDiscount: function () {
            return this.total - this.discount;
        },
        totalAfterAll: function () {
            return this.totalAfterDiscount + this.vat;
        } ,
        BaqeeHalal: function () {
            var halal = (Math.floor(this.totalAfterAll + 1) - this.totalAfterAll.toFixed(2)).toFixed(2);
            if (halal < 1) 
                return halal
             else
                return 0.0
        } ,
        TheRest: function(){
            var rest = (this.GivenByCustomer  - this.totalAfterAll.toFixed(2)).toFixed(2)
            return rest
        }

    },
});
