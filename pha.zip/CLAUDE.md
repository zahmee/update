# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Application Overview

**asbab4** is a Pharmacy/Medical Supplies Management ERP system built on **Web2py** (Python). It provides invoice management, inventory tracking, customer/supplier accounting, and Saudi Arabia ZATCA tax compliance. The UI is fully Arabic (RTL) using Vue.js 2 + Bootstrap 5.3.2. Current version is tracked in `pha_ver.txt`.

## Running the Application

```bash
# From the web2py root directory (D:\web2py)
python web2py.py -a <admin_password>
# Access at http://localhost:8000/asbab4
```

**Database:** PostgreSQL — connection string and settings in `private/appconfig.ini`.

## Architecture

This is a standard **Web2py MVC** application:

- **`models/db.py`** (~1300 lines) — All database table definitions (50+ tables), utility functions (`can_access()`, `screens_rules()`), and DAL configuration. This is the single most important file.
- **`models/menu.py`** — Navigation menu structure.
- **`controllers/`** — One controller per business domain. Each function maps to a URL: `/asbab4/<controller>/<function>`.
- **`views/`** — Web2py HTML templates using `{{...}}` syntax, with Vue.js directives (`v-if`, `v-for`, `@click`) for interactivity.
- **`static/viewsjs/`** — Vue.js component JavaScript files that pair with views (e.g., `viewsjs/invoice/index.js` pairs with `views/invoice/index.html`).
- **`modules/`** — Reusable Python modules (SMS sending).
- **`private/appconfig.ini`** — App configuration (DB credentials, company info, VAT number, license expiry).

### Key Controllers (by complexity)

| Controller | Purpose |
|---|---|
| `invoice.py` (48KB) | Sales invoices, returns, printing, QR codes — the core module |
| `items.py` (24KB) | Product catalog and item details (SKU-level) |
| `setup.py` (24KB) | System configuration, users, roles, screen permissions |
| `suppliers.py` (12KB) | Supplier management and purchase invoices |
| `customers.py` | Customer management, payments, account reconciliation |
| `fund.py` | Cash fund movements and shift closing |
| `zatca.py` | Saudi ZATCA tax compliance and certificate management |
| `vat.py` | VAT calculation and reporting |
| `items_qry.py` / `items_rep.py` / `items_reorder.py` | Item queries, reports, reorder points |

### Database Schema (key relationships)

```
suppliers → suppliers_bills → items_det → invoice_details ← invoice_master ← customers
                                ↑
                            items_main (product catalog)
```

- **`items_main`** = product definition; **`items_det`** = SKU-level details (price, quantity, expiry, linked to supplier bill)
- **`invoice_master`** / **`invoice_details`** = sales invoices
- **`inv_return_master`** / **`inv_return_details`** = sales returns
- **`key_*` tables** = lookup/reference data (units, payment methods, customer types, invoice types)
- **`screens`** / **`screens_rules`** = screen-level access control per user

### Authentication & Authorization

- Web2py built-in auth with groups: `admin`, `user`, `account`, `report`.
- Custom `@can_access(screen_code)` decorator checks `screens_rules` table for per-user screen permissions.
- `@auth.requires_membership("group")` for role-based access.

### Frontend Pattern

Views use **web2py templates** for server-side rendering combined with **Vue.js 2** for client-side interactivity. Vue instances fetch data via `this.$http.get()` calls to controller endpoints that return JSON via `response.json()`. Bootstrap 5.3.2 handles layout with RTL support for Arabic.

## Development Conventions

- **Language:** Business logic variable names and UI labels are in Arabic. Database field names and technical identifiers are in English.
- **Database access:** Always use Web2py's DAL (`db(query).select()`) — never raw SQL.
- **Translation:** Use `T()` function for translatable strings. Arabic is forced via `T.force("ar")`.
- **No formal test suite** exists. Test through the web UI.
- **Cron jobs** are defined in `cron/` directory (e.g., reorder point checking).
- **datetime import:** `controllers/default.py` uses `from datetime import datetime` (الكلاس فقط). استخدم `datetime.now().date()` بدلاً من `datetime.date.today()` و`datetime.combine()` بدلاً من `datetime.datetime.combine()`.
- **SQLFORM.grid pattern:** الطريقة القياسية لإنشاء شاشة CRUD في `setup.py` هي استخدام `SQLFORM.grid()` مع `@auth.requires_membership("admin")`. الـ view تستخدم نفس نمط `unit_key.html` (تعديل أيقونات glyphicon عبر jQuery).

## Recent Changes (2026-03-01 / 2026-03-02)

### تحسينات الواجهة — layout.html
- **Navbar:** أصبح `sticky-top` ويبقى ظاهراً عند التمرير
- **Dark theme:** نُقل `data-bs-theme="dark"` للـ `<nav>` فقط (إزالة التكرار من `<header>`)
- **قائمة الإعداد:** أيقونة مختلفة لكل بند بدلاً من `fa-key` المتكررة
- **قائمة المستخدم:** أُضيف `dropdown-menu-dark` + أيقونات عربية لجميع البنود (الملف الشخصي، تغيير المرور، تسجيل الخروج)
- **بند "القطاعات":** أُضيف في آخر قائمة الإعداد بأيقونة `fad fa-map-marked-alt` مع فاصل

### تنظيف CSS — mystyle.css
- حُذف `* { margin: 0; padding: 0; }` (تعارض مع Bootstrap reset)
- حُذف `.container { width: 90%; }` (كان يلغي استجابية Bootstrap)
- حُذف `#page-wrap` (غير مستخدم)
- استُبدل `float: left/right` في footer بـ flexbox


### لوحة الإحصاءات (Dashboard) — default/index
**Controller `index()`** يحسب ويمرر `stats` dict:
- `total_today` — إجمالي مبيعات اليوم (ريال)
- `invoices_today_all` — فواتير اليوم من جميع المستخدمين
- `invoices_today_me` — فواتير اليوم للمستخدم الحالي
- `total_items` — عدد الأصناف الإجمالي (`items_main`)
- `total_customers` — عدد العملاء (`customers`)
- `active_suppliers` — عدد الموردين الفعليين (`suppliers.stoped != True`)
- `open_bills` — فواتير توريد غير مؤكدة (`suppliers_bills.bill_confirmation != True`)
- `pending_returns` — مرتجعات معلقة (`returned_supply.admin_accept == False`)

**Controller `dashboard_charts()`** — API endpoint يُرجع JSON:
- `sales_7days` — مبيعات آخر 7 أيام (مجموع يومي + عدد فواتير)
- `payment_breakdown` — توزيع طرق الدفع اليوم (اسم الطريقة + المجموع)

**View** تصميم Dashboard احترافي:
- بطاقات إحصاء gradient ملونة (7 بطاقات) مع أيقونات FontAwesome
- رسم بياني Area chart (مبيعات 7 أيام) باستخدام **ApexCharts 3.45.1**
- رسم بياني Donut chart (توزيع طرق الدفع)
- بطاقات مهام معلقة (مرتجعات + فواتير توريد)
- تنبيه انتهاء الاشتراك


## Important Note
After every major change, update this file (CLAUDE.md) to reflect the current project status.
Keep it concise, accurate, and up-to-date at all times.
