# -*- coding: utf-8 -*-
#  type: ignore
"""
واجهة الوكيل الخارجي — عمليات الكتابة فقط
External AI Agent API — write operations only.

مفصولة عن agent_api.py (قراءة فقط) عمداً لعزل أي تعديل على البيانات.
المصادقة: نفس مفتاح الوكيل (require_agent_key في models/db_7_agent.py).

نقاط النهاية (Endpoints):
  POST /asbab5/agent_api_write/request_item  — تسجيل طلب صنف غير متوفر
  POST /asbab5/agent_api_write/add_customer  — إضافة عميل (اسم + جوال) إن لم يوجد
  POST /asbab5/agent_api_write/update_customer_name — تصحيح اسم عميل موجود
"""

from datetime import datetime
import re
import api_helpers as api


# ===========================================================================
# تسجيل طلب صنف غير متوفر (دمج + زيادة العداد عند التكرار)
# ===========================================================================
@require_agent_key
def request_item():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        name = (data.name or "").strip()
        if not name:
            return api.api_error(mess="اسم الصنف مطلوب")

        item_id_val = (data.item_id or "").strip() or None
        customer_mobile = agent_normalize_mobile(data.customer_mobile) or None
        if customer_mobile and not agent_valid_mobile(customer_mobile):
            return api.api_error(mess="رقم جوال العميل غير صحيح")

        # دمج مع طلب موجود (بالباركود ثم بالاسم) غير الملغي
        existing = None
        if item_id_val:
            existing = db(
                (db.item_requests.item_id == item_id_val)
                & (db.item_requests.status != "rejected")
            ).select().first()
        if not existing:
            existing = db(
                (db.item_requests.name == name)
                & (db.item_requests.status != "rejected")
            ).select().first()

        if existing:
            existing.update_record(
                request_count=existing.request_count + 1,
                last_request_date=datetime.now(),
                customer_name=(data.customer_name or "").strip() or existing.customer_name or None,
                customer_mobile=customer_mobile or existing.customer_mobile or None,
                notes=(data.notes or "").strip() or existing.notes or None,
            )
            db.commit()
            return api.api_ok(
                data={"id": existing.id, "is_new": False, "request_count": existing.request_count},
                mess="تم تسجيل الطلب مرة أخرى (العدد: %d)" % existing.request_count,
            )

        rid = db.item_requests.insert(
            name=name,
            item_id=item_id_val,
            generic_name=(data.generic_name or "").strip() or None,
            supplier_name=(data.supplier_name or "").strip() or None,
            notes=(data.notes or "").strip() or None,
            customer_name=(data.customer_name or "").strip() or None,
            customer_mobile=customer_mobile,
            request_count=1,
            last_request_date=datetime.now(),
            status="new",
        )
        db.commit()
        return api.api_ok(data={"id": rid, "is_new": True}, mess="تم تسجيل الطلب بنجاح")

    return response.json(_do())


# ===========================================================================
# إضافة عميل جديد (اسم + جوال) إذا لم يكن موجوداً
# ===========================================================================
@require_agent_key
def add_customer():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        name = (data.name or "").strip()
        mobile = agent_normalize_mobile(data.mobile)

        if not name:
            return api.api_error(mess="اسم العميل مطلوب")
        if not re.match(r"^05\d{8}$", mobile):
            return api.api_error(mess="رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05")

        # موجود مسبقاً؟ أرجعه بدل التكرار (mobile فريد في الجدول)
        existing = db(db.customers.mobile == mobile).select().first()
        if existing:
            return api.api_ok(
                data={"id": existing.id, "name": existing.name,
                      "mobile": existing.mobile, "is_new": False},
                mess="العميل مسجّل مسبقاً",
            )

        nid = db.customers.validate_and_insert(
            name=name.lower(), mobile=mobile, cust_type=0
        )
        errs = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if errs:
            db.rollback()
            return api.api_error(mess=str(errs))
        new_id = nid["id"] if isinstance(nid, dict) else nid.id
        db.commit()
        return api.api_ok(
            data={"id": new_id, "name": name.lower(), "mobile": mobile, "is_new": True},
            mess="تم إضافة العميل بنجاح",
        )

    return response.json(_do())


# ===========================================================================
# تصحيح اسم عميل موجود بناءً على طلبه
# ===========================================================================
@require_agent_key
def update_customer_name():
    @api.api_safe(db_conn=db)
    def _do():
        data = request.vars
        name = (data.name or "").strip()
        mobile = agent_normalize_mobile(data.mobile)

        if not name:
            return api.api_error(mess="الاسم الصحيح مطلوب")
        if not re.match(r"^05\d{8}$", mobile):
            return api.api_error(mess="رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05")

        customer = db(db.customers.mobile == mobile).select().first()
        if not customer:
            return api.api_error(mess="لا يوجد عميل بهذا الرقم")

        previous_name = customer.name
        normalized_name = name.lower()
        customer.update_record(name=normalized_name)
        db.commit()
        return api.api_ok(
            data={
                "id": customer.id,
                "mobile": customer.mobile,
                "previous_name": previous_name,
                "name": normalized_name,
            },
            mess="تم تصحيح اسم العميل بنجاح",
        )

    return response.json(_do())
