# -*- coding: utf-8 -*-
"""Supplier maintenance regressions using an isolated in-memory DAL database.

Run from the app root: python -B scripts/test_supplier_maintenance.py
No application models, operational database, supplier records or credentials are loaded.
"""

import ast
import json
import sys
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP.parents[1]))
sys.path.insert(0, str(APP / "modules"))

from gluon import DAL, Field, HTTP, URL, current, redirect
from gluon.globals import Request, Response, Session
from gluon.storage import Storage, List
from gluon.tools import Auth
import api_helpers as api
import supplier_maintenance as maintenance

NOW = datetime(2026, 9, 22, 12)


def record(**changes):
    value = dict(id=1, name="  Alpha  Co  ", tel="001|002", address=" street  one ",
                 note=None, bank_account=" 001 | 002 ", stoped=True, modified_on=NOW)
    value.update(changes)
    return value


class FormattingTests(unittest.TestCase):
    def test_names_preserve_case_and_do_not_invent_missing_values(self):
        self.assertEqual(maintenance.proposed_changes(record(), "names")[0]["after"], "Alpha Co")
        for value in (None, "", "   "):
            self.assertEqual(maintenance.proposed_changes(record(name=value), "names"), [])

    def test_phone_boundaries_leading_zeroes_labels_and_distinct_formats_survive(self):
        value = "| 001 | +966 000 |001|مسؤول: 003 ext 04|+966000|"
        after = maintenance.proposed_changes(record(tel=value), "phones")[0]["after"]
        self.assertEqual(after, "001\n+966 000\nمسؤول: 003 ext 04\n+966000")
        self.assertNotIn("001+966", after)

    def test_bank_cleanup_never_joins_numbers_or_changes_internal_characters(self):
        before = " 001 002 | sa00 0000 00 | حساب ثان: ٠٠٣٤ "
        after = maintenance.proposed_changes(record(bank_account=before), "bank")[0]["after"]
        self.assertEqual(after, "001 002\nsa00 0000 00\nحساب ثان: ٠٠٣٤")

    def test_text_keeps_paragraphs_and_repeated_meaningful_lines(self):
        row = record(address=" A   B \r\n\r\n C | C ", note=None)
        changes = maintenance.proposed_changes(row, "texts")
        self.assertEqual(len(changes), 1)
        self.assertEqual(changes[0]["after"], "A B\n\nC\nC")

    def test_every_cleanup_is_idempotent_and_field_scoped(self):
        for operation in maintenance.OPERATIONS:
            row = record()
            with self.subTest(operation=operation["key"]):
                changes = maintenance.proposed_changes(row, operation["key"])
                self.assertTrue(all(change["field"] in operation["fields"] for change in changes))
                row.update({change["field"]: change["after"] for change in changes})
                self.assertEqual(maintenance.proposed_changes(row, operation["key"]), [])
                self.assertTrue(row["stoped"])

    def test_missing_values_and_status_are_reported_without_defaults(self):
        row = record(name=None, tel="| |", address=None, stoped=None)
        result, plan = maintenance.preview([row], "missing", 1)
        self.assertIsNone(plan)
        self.assertEqual(len(result["records"][0]["issues"]), 4)
        self.assertEqual(result["records"][0]["changes"], [])
        self.assertIsNone(row["stoped"])

    def test_duplicates_ignore_whitespace_and_case_but_do_not_merge(self):
        rows = [record(), record(id=2, name="alpha co"), record(id=3, name="Different")]
        result, plan = maintenance.preview(rows, "duplicates", 1)
        self.assertIsNone(plan)
        self.assertEqual([r["id"] for r in result["records"]], [1, 2])
        self.assertEqual(maintenance.summarize(rows)["duplicate_groups"], 1)
        self.assertEqual(maintenance.summarize(rows)["counts"]["duplicates"], 2)

    def test_cleanup_batch_is_explicitly_bounded_but_review_is_complete(self):
        rows = [record(id=i+1, tel=None) for i in range(maintenance.MAX_BATCH + 2)]
        result, plan = maintenance.preview(rows, "names", 1)
        self.assertEqual(len(result["records"]), maintenance.MAX_BATCH)
        self.assertEqual(result["total"], maintenance.MAX_BATCH + 2)
        self.assertTrue(result["truncated"])
        self.assertEqual(len(plan["fingerprints"]), maintenance.MAX_BATCH)
        review, plan = maintenance.preview(rows, "missing", 1)
        self.assertEqual(len(review["records"]), len(rows))


class DatabaseFixture(unittest.TestCase):
    def setUp(self):
        self.db = DAL("sqlite:memory")
        self.addCleanup(self.db.close)
        self.db.define_table("suppliers", Field("name"), Field("tel", "text"), Field("address", "text"),
                             Field("note", "text"), Field("bank_account", "text"), Field("stoped", "boolean"),
                             Field("modified_on", "datetime", default=NOW, update=lambda: datetime(2026, 9, 22, 13)),
                             Field("total_amount", "double"), Field("days_to_pay", "integer"))
        for values in (record(), record(id=2, name=" Beta  Ltd ", stoped=None)):
            values.pop("id")
            self.db.suppliers.insert(**values, total_amount=123.45, days_to_pay=30)
        self.db.commit()

    def rows(self):
        return maintenance.load_rows(self.db)

    def plan(self):
        return maintenance.preview(self.rows(), "names", 1)[1]


class DatabaseTests(DatabaseFixture):
    def test_only_selected_supplier_and_allowed_fields_change(self):
        before = self.db.suppliers[1].as_dict()
        plan = self.plan()
        result = maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db.commit()
        self.assertEqual(result["updated"], 1)
        self.assertEqual(self.db.suppliers[1].name, "Alpha Co")
        self.assertEqual(self.db.suppliers[2].name, " Beta  Ltd ")
        for field in ("total_amount", "days_to_pay", "tel", "bank_account", "stoped"):
            self.assertEqual(self.db.suppliers[1][field], before[field])
        self.assertIsNone(self.db.suppliers[2].stoped)
        self.assertNotEqual(self.db.suppliers[1].modified_on, before["modified_on"])

    def test_stale_second_supplier_blocks_the_entire_batch(self):
        plan = self.plan()
        self.db(self.db.suppliers.id == 2).update(tel="changed elsewhere")
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [1, 2], 1)
        self.db.rollback()
        self.assertEqual(self.db.suppliers[1].name, "  Alpha  Co  ")
        self.assertEqual(self.db.suppliers[2].tel, "changed elsewhere")

    def test_deleted_supplier_and_changed_proposal_are_rejected(self):
        plan = self.plan()
        with patch.object(maintenance, "_name", return_value="unexpected new rule"):
            with self.assertRaises(maintenance.MaintenanceError):
                maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db(self.db.suppliers.id == 1).delete()
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [1], 1)

    def test_expired_wrong_user_token_and_invalid_selections_never_write(self):
        plan = self.plan()
        cases = [(None, plan["token"], [1], 1, None), (plan, "wrong", [1], 1, None),
                 (plan, plan["token"], [1], 2, None),
                 (plan, plan["token"], [1], 1, plan["created_at"] + maintenance.PREVIEW_TTL + 1)]
        cases += [(plan, plan["token"], ids, 1, None) for ids in ([], [1, 1], [True], ["1"], [0], [999], "1", [1.0])]
        for candidate, token, ids, user, now in cases:
            with self.subTest(ids=ids, user=user), self.assertRaises(maintenance.MaintenanceError):
                maintenance.apply(self.db, candidate, token, ids, user, now=now)
        self.assertEqual(self.db.suppliers[1].name, "  Alpha  Co  ")

    def test_replay_cannot_repeat_a_write(self):
        plan = self.plan()
        maintenance.apply(self.db, plan, plan["token"], [1], 1)
        self.db.commit()
        with self.assertRaises(maintenance.MaintenanceError):
            maintenance.apply(self.db, plan, plan["token"], [1], 1)


class EndpointTests(DatabaseFixture):
    def setUp(self):
        super().setUp()
        self.request = Request({"request_method": "POST", "http_host": "localhost"})
        self.request.application = "asbab5"
        self.request.controller = "setup"
        self.request.function = "supplier_maintenance_preview"
        self.request.args = List()
        self.request.now = NOW
        self.response = Response()
        self.session = Session()
        self.session.auth = Storage(user=Storage(id=1, first_name="Fixture"), last_visit=NOW,
                                    expiration=3600, hmac_key="isolated-maintenance-signing-key")
        current.request, current.response, current.session = self.request, self.response, self.session
        current.T = lambda text: text
        self.auth = Auth(self.db)
        self.auth.define_tables(username=False, signature=False)
        self.db.auth_user.insert(first_name="Fixture", email="fixture@example.invalid")
        self.db.define_table("screens", Field("screen_code", "integer"))
        self.db.define_table("screens_rules", Field("screens", "integer"), Field("to_user", "integer"),
                             Field("can_log_in", "boolean"), Field("can_edit", "boolean"))
        self.db.screens.insert(screen_code=9301)
        self.db.screens_rules.insert(screens=1, to_user=1, can_log_in=True, can_edit=True)
        self.db.commit()
        self.role = "admin"
        self.auth.has_membership = lambda group_id=None, role=None: bool(self.auth.user and self.role == (role or group_id))
        self.env = dict(auth=self.auth, request=self.request, response=self.response, session=self.session,
                        db=self.db, api=api, supplier_maintenance=maintenance, URL=URL, HTTP=HTTP,
                        redirect=redirect, T=lambda text: text)
        model = ast.parse((APP / "models/db_4_access.py").read_text(encoding="utf-8-sig"))
        access = next(node for node in model.body if isinstance(node, ast.FunctionDef) and node.name == "can_access")
        exec(compile(ast.Module(body=[access], type_ignores=[]), "access", "exec"), self.env)
        controller = ast.parse((APP / "controllers/setup.py").read_text(encoding="utf-8-sig"))
        functions = [node for node in controller.body if isinstance(node, ast.FunctionDef)
                     and ("supplier_maintenance" in node.name or node.name in ("util", "util_2"))]
        exec(compile(ast.Module(body=functions, type_ignores=[]), "setup", "exec"), self.env)

    def call(self, name, body=None, method="POST", signed=True):
        self.request.function = name
        self.request.env.request_method = method
        self.response.status = 200
        self.request._post_vars = Storage(body or {})
        self.request._get_vars = Storage()
        if signed:
            url = URL("setup", name, user_signature=True)
            self.request._get_vars = Storage({key: values[0] for key, values in parse_qs(urlsplit(url).query).items()})
        self.request._vars = None
        return json.loads(self.env[name]())

    def preview_token(self):
        return self.call("supplier_maintenance_preview", dict(operation="names"))["data"]["token"]

    def test_summary_and_preview_are_read_only(self):
        before = self.rows()
        self.assertTrue(self.call("supplier_maintenance_summary", method="GET")["ok"])
        self.assertTrue(self.call("supplier_maintenance_preview", dict(operation="names"))["ok"])
        self.assertEqual(self.rows(), before)

    def test_legacy_get_redirects_without_writing(self):
        before = self.rows()
        with self.assertRaises(HTTP) as result:
            self.call("util_2", method="GET")
        self.assertEqual(result.exception.status, 303)
        self.assertEqual(self.rows(), before)

    def test_post_and_signature_are_required(self):
        for endpoint in ("supplier_maintenance_preview", "supplier_maintenance_apply"):
            for method, signed, status in (("GET", True, 405), ("POST", False, 403)):
                with self.subTest(endpoint=endpoint, method=method, signed=signed):
                    result = self.call(endpoint, method=method, signed=signed)
                    self.assertFalse(result["ok"])
                    self.assertEqual(self.response.status, status)
        self.assertEqual(self.db.suppliers[1].name, "  Alpha  Co  ")

    def test_anonymous_and_users_without_screen_access_are_blocked(self):
        self.role = "user"
        self.db(self.db.screens_rules.id > 0).update(can_log_in=False)
        self.db.commit()
        for endpoint in ("util", "supplier_maintenance_summary", "supplier_maintenance_preview", "supplier_maintenance_apply"):
            with self.subTest(endpoint=endpoint), self.assertRaises(HTTP):
                self.call(endpoint)
        self.auth.user = None
        with self.assertRaises(HTTP):
            self.call("supplier_maintenance_summary", method="GET", signed=False)

    def test_view_permission_is_not_write_permission(self):
        self.role = "user"
        self.db(self.db.screens_rules.id > 0).update(can_edit=False)
        self.db.commit()
        token = self.preview_token()
        result = self.call("supplier_maintenance_apply", dict(token=token, ids="[1]"))
        self.assertFalse(result["ok"])
        self.assertEqual(self.response.status, 403)
        self.assertEqual(self.db.suppliers[1].name, "  Alpha  Co  ")

    def test_success_logs_commits_only_server_proposals_and_consumes_plan(self):
        token = self.preview_token()
        body = dict(token=token, ids="[1]", after="CLIENT FORGERY", operation="bank")
        result = self.call("supplier_maintenance_apply", body)
        self.assertTrue(result["ok"])
        self.assertEqual(self.db.suppliers[1].name, "Alpha Co")
        self.assertEqual(self.db.suppliers[1].bank_account, " 001 | 002 ")
        self.assertIsNone(self.session.supplier_maintenance_plan)
        self.assertEqual(self.db(self.db.auth_event.origin == "supplier_maintenance").count(), 1)
        self.assertFalse(self.call("supplier_maintenance_apply", body)["ok"])
        self.assertEqual(self.response.status, 409)

    def test_mid_operation_failure_rolls_back_and_leaves_plan_retryable(self):
        token = self.preview_token()
        before = self.rows()
        with patch.object(self.auth, "log_event", side_effect=RuntimeError("fixture failure")):
            with self.assertLogs("supplier_maintenance", level="ERROR"):
                result = self.call("supplier_maintenance_apply", dict(token=token, ids="[1,2]"))
        self.assertFalse(result["ok"])
        self.assertEqual(self.response.status, 500)
        self.assertEqual(self.rows(), before)
        self.assertNotIn("fixture failure", result["mess"])

    def test_other_session_token_and_unknown_operation_are_rejected(self):
        self.assertFalse(self.call("supplier_maintenance_preview", dict(operation="activate_suppliers"))["ok"])
        token = self.preview_token()
        old_plan = self.session.supplier_maintenance_plan
        self.session.supplier_maintenance_plan = None
        self.assertFalse(self.call("supplier_maintenance_apply", dict(token=token, ids="[1]"))["ok"])
        self.session.supplier_maintenance_plan = old_plan
        self.request.function = "supplier_maintenance_apply"
        url = URL("setup", "supplier_maintenance_apply", user_signature=True)
        self.request._get_vars = Storage({key: values[0] for key, values in parse_qs(urlsplit(url).query).items()})
        self.request._post_vars = Storage(token=token, ids="[1]")
        self.request._vars = None
        self.session.auth.hmac_key = "different-session-key"
        self.assertFalse(json.loads(self.env["supplier_maintenance_apply"]())["ok"])
        self.assertEqual(self.response.status, 403)


if __name__ == "__main__":
    unittest.main(verbosity=2)
