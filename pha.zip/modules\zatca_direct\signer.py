# -*- coding: utf-8 -*-
# type: ignore
"""
Invoice signing: XSL transform, canonicalization, ECDSA signing, QR generation.
"""

import base64
import hashlib
import json
import os
import re
import tempfile
from datetime import datetime

import importlib
etree = importlib.import_module("lxml.etree")
x509 = importlib.import_module("cryptography.x509")
default_backend = importlib.import_module("cryptography.hazmat.backends").default_backend
hashes = importlib.import_module("cryptography.hazmat.primitives.hashes")
ec = importlib.import_module("cryptography.hazmat.primitives.asymmetric.ec")
load_pem_private_key = importlib.import_module("cryptography.hazmat.primitives.serialization").load_pem_private_key
crypto = importlib.import_module("OpenSSL.crypto")

RESOURCES_DIR = os.path.join(os.path.dirname(__file__), "resources")


def _res(filename):
    return os.path.join(RESOURCES_DIR, filename)


# ----- XML Processing -----

def _transform_xml(xml_tree):
    """Apply XSL transformation to remove UBLExtensions, QR, Signature."""
    xsl = etree.parse(_res("xslfile.xsl"))
    transform = etree.XSLT(xsl)
    result = transform(xml_tree)
    if result is None:
        raise Exception("XSL Transformation failed.")
    return result


def _canonicalize(xml_tree):
    """Canonicalize XML using C14N11."""
    return etree.tostring(xml_tree, method="c14n").decode("utf-8")


def _base64_hash(data_str):
    """SHA256 hash → base64."""
    h = hashlib.sha256(data_str.encode("utf-8")).digest()
    return base64.b64encode(h).decode()


def _extract_uuid(xml_tree):
    ns = {"cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"}
    nodes = xml_tree.xpath("//cbc:UUID", namespaces=ns)
    if not nodes:
        raise Exception("UUID not found in XML.")
    return nodes[0].text


def _is_simplified(xml_tree):
    ns = {"cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"}
    nodes = xml_tree.xpath("//cbc:InvoiceTypeCode", namespaces=ns)
    if nodes:
        name_attr = nodes[0].get("name")
        return name_attr and name_attr.startswith("02")
    return False


# ----- Cryptographic Operations -----

def _wrap_cert(cert_content):
    """Wrap raw base64 certificate with PEM headers."""
    lines = [cert_content[i:i + 64] for i in range(0, len(cert_content), 64)]
    return "-----BEGIN CERTIFICATE-----\n" + "\n".join(lines) + "\n-----END CERTIFICATE-----"


def _public_key_hash(cert_content):
    """SHA256 of certificate content → hex → base64."""
    h = hashlib.sha256(cert_content.encode("utf-8")).digest()
    return base64.b64encode(h.hex().encode("utf-8")).decode("utf-8")


def _get_issuer_name(certificate):
    issuer_parts = []
    issuer_dict = {}
    for attr in certificate.issuer:
        key = attr.oid._name
        if key in issuer_dict:
            if isinstance(issuer_dict[key], list):
                issuer_dict[key].append(attr.value)
            else:
                issuer_dict[key] = [issuer_dict[key], attr.value]
        else:
            issuer_dict[key] = attr.value

    if "commonName" in issuer_dict:
        issuer_parts.append(f"CN={issuer_dict['commonName']}")
    if "domainComponent" in issuer_dict:
        dc_list = issuer_dict["domainComponent"]
        if isinstance(dc_list, list):
            dc_list.reverse()
            for dc in dc_list:
                if dc:
                    issuer_parts.append(f"DC={dc}")
    return ", ".join(issuer_parts)


def _signed_properties_hash(signing_time, digest_value, issuer_name, serial_number):
    xml_string = (
        '<xades:SignedProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="xadesSignedProperties">\n'
        "                                    <xades:SignedSignatureProperties>\n"
        f"                                        <xades:SigningTime>{signing_time}</xades:SigningTime>\n"
        "                                        <xades:SigningCertificate>\n"
        "                                            <xades:Cert>\n"
        "                                                <xades:CertDigest>\n"
        '                                                    <ds:DigestMethod xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>\n'
        f'                                                    <ds:DigestValue xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{digest_value}</ds:DigestValue>\n'
        "                                                </xades:CertDigest>\n"
        "                                                <xades:IssuerSerial>\n"
        f'                                                    <ds:X509IssuerName xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{issuer_name}</ds:X509IssuerName>\n'
        f'                                                    <ds:X509SerialNumber xmlns:ds="http://www.w3.org/2000/09/xmldsig#">{serial_number}</ds:X509SerialNumber>\n'
        "                                                </xades:IssuerSerial>\n"
        "                                            </xades:Cert>\n"
        "                                        </xades:SigningCertificate>\n"
        "                                    </xades:SignedSignatureProperties>\n"
        "                                </xades:SignedProperties>"
    )
    xml_string = xml_string.replace("\r\n", "\n").strip()
    h = hashlib.sha256(xml_string.encode("utf-8")).digest()
    return base64.b64encode(h.hex().encode("utf-8")).decode("utf-8")


def _digital_signature(xml_hash_b64, private_key_content):
    """ECDSA sign the invoice hash."""
    hash_bytes = base64.b64decode(xml_hash_b64)
    pk_content = private_key_content.replace("\n", "").replace("\t", "")
    if "-----BEGIN EC PRIVATE KEY-----" not in pk_content:
        pk_content = f"-----BEGIN EC PRIVATE KEY-----\n{pk_content}\n-----END EC PRIVATE KEY-----"
    private_key = load_pem_private_key(pk_content.encode(), password=None, backend=default_backend())
    signature = private_key.sign(hash_bytes, ec.ECDSA(hashes.SHA256()))
    return base64.b64encode(signature).decode()


def _get_public_key_and_signature(cert_base64):
    """Extract public key and certificate signature for QR code."""
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".pem") as f:
            content = "-----BEGIN CERTIFICATE-----\n"
            content += "\n".join([cert_base64[i:i + 64] for i in range(0, len(cert_base64), 64)])
            content += "\n-----END CERTIFICATE-----\n"
            f.write(content)
            temp_path = f.name

        with open(temp_path, "r") as f:
            cert = crypto.load_certificate(crypto.FILETYPE_PEM, f.read())

        pub_key = crypto.dump_publickey(crypto.FILETYPE_ASN1, cert.get_pubkey())
        pub_key_details = (
            crypto.load_publickey(crypto.FILETYPE_ASN1, pub_key)
            .to_cryptography_key()
            .public_numbers()
        )

        x_bytes = pub_key_details.x.to_bytes(32, byteorder="big").rjust(32, b"\0")
        y_bytes = pub_key_details.y.to_bytes(32, byteorder="big").rjust(32, b"\0")

        public_key_der = (
            b"\x30\x56\x30\x10\x06\x07\x2a\x86\x48\xce\x3d\x02\x01"
            b"\x06\x05\x2b\x81\x04\x00\x0a\x03\x42\x00\x04"
            + x_bytes + y_bytes
        )

        with open(temp_path, "r") as f:
            cert_pem = f.read()
        matches = re.search(r"-----BEGIN CERTIFICATE-----(.+)-----END CERTIFICATE-----", cert_pem, re.DOTALL)
        if not matches:
            raise Exception("Error extracting DER data from certificate.")
        der_data = base64.b64decode(matches.group(1).replace("\n", ""))
        sequence_pos = der_data.rfind(b"\x30", -72)
        signature = der_data[sequence_pos:]

        return {"public_key": public_key_der, "signature": signature}
    finally:
        if temp_path and os.path.exists(temp_path):
            os.unlink(temp_path)


# ----- QR Code TLV Generation -----

def _write_tlv_tag(tag):
    result = bytes()
    flag = True
    for i in range(3, -1, -1):
        num = (tag >> (8 * i)) & 0xFF
        if num != 0 or not flag or i == 0:
            if flag and i != 0 and (num & 0x1F) != 0x1F:
                raise ValueError(f"Invalid tag value: {tag}")
            result += bytes([num])
            flag = False
    return result


def _write_tlv_length(length):
    if length <= 0x7F:
        return bytes([length])
    length_bytes = []
    while length > 0:
        length_bytes.insert(0, length & 0xFF)
        length >>= 8
    return bytes([0x80 | len(length_bytes)]) + bytes(length_bytes)


def _write_tlv(tag, value):
    if value is None:
        raise ValueError("TLV value is None!")
    tlv = _write_tlv_tag(tag)
    tlv += _write_tlv_length(len(value))
    tlv += value
    return tlv


def _generate_qr_code(canonical_xml, invoice_hash, signature_value, ecdsa_result):
    """Generate QR code TLV from invoice details."""
    import xml.etree.ElementTree as ET
    root = ET.fromstring(canonical_xml)

    ns_cbc = "{urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2}"
    ns_cac = "{urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2}"

    supplier_name = root.find(f".//{ns_cac}AccountingSupplierParty/{ns_cac}Party/{ns_cac}PartyLegalEntity/{ns_cbc}RegistrationName").text
    company_id = root.find(f".//{ns_cac}AccountingSupplierParty/{ns_cac}Party/{ns_cac}PartyTaxScheme/{ns_cbc}CompanyID").text
    issue_date = root.find(f".//{ns_cbc}IssueDate").text
    issue_time = root.find(f".//{ns_cbc}IssueTime").text
    payable_amount = root.find(f".//{ns_cac}LegalMonetaryTotal/{ns_cbc}PayableAmount").text
    tax_amount = root.find(f".//{ns_cac}TaxTotal/{ns_cbc}TaxAmount").text

    values = [
        None,  # index 0 unused
        supplier_name,
        company_id,
        f"{issue_date}T{issue_time}",
        payable_amount,
        tax_amount,
        invoice_hash,
        signature_value,
        ecdsa_result["public_key"],
        ecdsa_result["signature"],
    ]

    data = b""
    for key, value in enumerate(values[1:], start=1):
        if isinstance(value, str):
            value = value.encode("utf-8")
        data += _write_tlv(key, value)
    return base64.b64encode(data).decode()


# ----- Main Signing Function -----

def sign_invoice(xml_tree, x509_certificate_content, private_key_content):
    """
    Sign an invoice XML tree.

    Returns: JSON string with {invoiceHash, uuid, invoice}
    """
    # Pretty-print then re-parse for consistent formatting
    xml_bytes = etree.tostring(xml_tree, pretty_print=True, encoding="UTF-8")
    xml_tree = etree.fromstring(xml_bytes)

    uuid_val = _extract_uuid(xml_tree)
    is_simplified = _is_simplified(xml_tree)

    # XSL transform → canonicalize → hash
    transformed = _transform_xml(xml_tree)
    canonical = _canonicalize(transformed)
    invoice_hash = _base64_hash(canonical)

    xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>'
    base64_invoice = base64.b64encode(f"{xml_declaration}\n{canonical}".encode("utf-8")).decode("utf-8")

    # Standard invoices: just hash (signing done by ZATCA on clearance)
    if not is_simplified:
        return json.dumps({"invoiceHash": invoice_hash, "uuid": uuid_val, "invoice": base64_invoice})

    # Simplified invoices: full local signing
    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    pk_hash = _public_key_hash(x509_certificate_content)

    pem_cert = _wrap_cert(x509_certificate_content)
    certificate = x509.load_pem_x509_certificate(pem_cert.encode(), default_backend())

    issuer_name = _get_issuer_name(certificate)
    serial_number = certificate.serial_number
    sp_hash = _signed_properties_hash(timestamp, pk_hash, issuer_name, serial_number)
    sig_value = _digital_signature(invoice_hash, private_key_content)
    ecdsa_result = _get_public_key_and_signature(x509_certificate_content)

    # Populate UBL signature template
    with open(_res("zatca_ubl.xml"), "r") as f:
        ubl = f.read()
    ubl = ubl.replace("INVOICE_HASH", invoice_hash)
    ubl = ubl.replace("SIGNED_PROPERTIES", sp_hash)
    ubl = ubl.replace("SIGNATURE_VALUE", sig_value)
    ubl = ubl.replace("CERTIFICATE_CONTENT", x509_certificate_content)
    ubl = ubl.replace("SIGNATURE_TIMESTAMP", timestamp)
    ubl = ubl.replace("PUBLICKEY_HASHING", pk_hash)
    ubl = ubl.replace("ISSUER_NAME", issuer_name)
    ubl = ubl.replace("SERIAL_NUMBER", str(serial_number))

    # Insert UBL after root opening tag
    pos = canonical.find(">") + 1
    signed_xml = canonical[:pos] + ubl + canonical[pos:]

    # Generate QR code
    qr_code = _generate_qr_code(canonical, invoice_hash, sig_value, ecdsa_result)

    # Insert QR + Signature before <cac:AccountingSupplierParty>
    with open(_res("zatca_signature.xml"), "r") as f:
        sig_content = f.read().replace("BASE64_QRCODE", qr_code)

    insert_pos = signed_xml.find("<cac:AccountingSupplierParty>")
    if insert_pos == -1:
        raise Exception("<cac:AccountingSupplierParty> tag not found.")
    signed_xml = signed_xml[:insert_pos] + sig_content + signed_xml[insert_pos:]

    # Encode final invoice
    final_b64 = base64.b64encode(f'{xml_declaration}\n{signed_xml}'.encode("utf-8")).decode("utf-8")

    return json.dumps({"invoiceHash": invoice_hash, "uuid": uuid_val, "invoice": final_b64})


def extract_qr_from_xml(xml_input):
    """Extract QR code from ZATCA response XML (base64 or raw XML string)."""
    import xml.etree.ElementTree as ET

    if xml_input.strip().startswith("<"):
        xml_content = xml_input
    else:
        xml_content = base64.b64decode(xml_input).decode("utf-8", errors="ignore")

    root = ET.fromstring(xml_content)
    for adr in root.findall(".//{*}AdditionalDocumentReference"):
        id_el = adr.find(".//{*}ID")
        if id_el is not None and id_el.text and id_el.text.strip() == "QR":
            embedded = adr.find(".//{*}EmbeddedDocumentBinaryObject")
            if embedded is not None and embedded.text:
                return embedded.text.strip()
    return None
