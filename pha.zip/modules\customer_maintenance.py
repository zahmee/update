# -*- coding: utf-8 -*-
"""Customer services snapshots and conservative, reviewed data maintenance.

Balances use the existing customer ledger equation. Formatting never writes
financial fields, classifications, transactions, or inferred contact details.
"""
import hashlib
import json
import re
import secrets
import time
from collections import defaultdict
from datetime import date, datetime

from pydal.helpers.methods import bar_decode_string

PREVIEW_TTL = 900
MAX_BATCH = 500
FIELDS = ("id", "name", "administrator_name", "mobile", "tel", "address", "note", "cust_type", "modified_on")
LABELS = {"name": "اسم العميل", "administrator_name": "اسم المسؤول", "mobile": "رقم الجوال",
          "tel": "الهواتف الإضافية", "address": "العنوان", "note": "الملاحظات"}
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
OPERATIONS = (
    dict(key="names", title="تنسيق الأسماء", icon="text", kind="cleanup", fields=("name", "administrator_name"),
         description="ترتيب المسافات في اسم العميل والمسؤول مع الحفاظ على الأحرف."),
    dict(key="mobile", title="تنسيق الجوالات", icon="mobile-alt", kind="cleanup", fields=("mobile",),
         description="توحيد الأرقام وإزالة فواصل التنسيق للأرقام الصحيحة وغير المشتركة فقط."),
    dict(key="phones", title="تنظيم الهواتف الإضافية", icon="phone-alt", kind="cleanup", fields=("tel",),
         description="ترتيب قائمة الهواتف وإزالة القيم المتكررة تمامًا مع إبقاء الأصفار."),
    dict(key="texts", title="العناوين والملاحظات", icon="align-right", kind="cleanup", fields=("address", "note"),
         description="تنسيق المسافات والأسطر مع الحفاظ على الكلمات والفقرات."),
    dict(key="missing", title="البيانات الناقصة", icon="clipboard-list", kind="review", fields=(),
         description="الأسماء والجوالات والعناوين التي تحتاج إلى استكمال من مصدر موثوق."),
    dict(key="contacts", title="فحص الجوالات", icon="phone-slash", kind="review", fields=(),
         description="الأرقام المفقودة أو غير المطابقة للصيغة المحلية أو المشتركة بين العملاء."),
    dict(key="duplicates", title="الأسماء والجوالات المتكررة", icon="clone", kind="review", fields=(),
         description="تجميع التطابقات للمراجعة؛ لا تُدمج حسابات العملاء تلقائيًا."),
    dict(key="classification", title="فحص تصنيف العملاء", icon="user-tag", kind="review", fields=(),
         description="مراجعة التصنيف غير المسجل أو غير المعروف دون تغييره تلقائيًا."),
)
OPERATION_MAP = {operation["key"]: operation for operation in OPERATIONS}


class MaintenanceError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def operation_for(key):
    if not isinstance(key, str) or key not in OPERATION_MAP:
        raise MaintenanceError("اختر أداة فحص صحيحة.")
    return OPERATION_MAP[key]


def clean_name(value):
    if value is None:
        return None
    return re.sub(r"\s+", " ", value).strip() or value


def clean_lines(value):
    if value is None:
        return None
    result = []
    for line in value.replace("\r\n", "\n").replace("\r", "\n").replace("|", "\n").split("\n"):
        line = re.sub(r"[^\S\n]+", " ", line).strip()
        if line or (result and result[-1]):
            result.append(line)
    return "\n".join(result).strip()


def mobile_key(value):
    # Formatting only: do not guess missing digits or change country prefixes.
    return re.sub(r"[\s()\-]+", "", (value or "").translate(DIGITS))


def valid_mobile(value):
    return bool(re.fullmatch(r"05[0-9]{8}", value or ""))


def legacy_phones(raw):
    """customers.tel is list:string (stored as |a|b|), but legacy rows hold a plain
    number such as 0500550300. web2py decodes that by dropping the first and last
    characters (50055030), so it must never be read or compared through the DAL."""
    return isinstance(raw, str) and not (len(raw) >= 2 and raw[0] == raw[-1] == "|")


def decode_phones(raw):
    if raw is None or isinstance(raw, list):
        return raw
    if legacy_phones(raw):
        return [raw] if raw.strip() else []
    return bar_decode_string(raw)


def clean_phones(value):
    if value is None:
        return None
    result = []
    for entry in value:
        for line in re.split(r"[|\r\n]", entry):
            line = line.strip()
            if line and line not in result:
                result.append(line)
    return result


def indexes(rows):
    names, mobiles = defaultdict(list), defaultdict(list)
    for row in rows:
        name = (clean_name(row["name"]) or "").strip().casefold()
        mobile = mobile_key(row["mobile"])
        if name:
            names[name].append(row["id"])
        if mobile:
            mobiles[mobile].append(row["id"])
    return names, mobiles


def findings(row, groups):
    names, mobiles = groups
    missing = [LABELS[field] + " غير مسجل" for field in ("name", "mobile", "address")
               if not (row[field] or "").replace("|", "").strip()]
    contacts, duplicates, classification = [], [], []
    mobile = mobile_key(row["mobile"])
    if not mobile:
        contacts.append("رقم الجوال غير مسجل")
    elif not valid_mobile(mobile):
        contacts.append("رقم الجوال يحتاج إلى تحقق: الصيغة المعتمدة عشرة أرقام تبدأ بـ 05")
    elif row["mobile"] != mobile:
        contacts.append("رقم الجوال يحتاج إلى تنسيق قبل استخدامه")
    if mobile and len(mobiles[mobile]) > 1:
        message = "الجوال متطابق بعد التنسيق لدى العملاء: " + "، ".join(map(str, mobiles[mobile]))
        contacts.append(message)
        duplicates.append(message)
    name = (clean_name(row["name"]) or "").strip().casefold()
    if name and len(names[name]) > 1:
        duplicates.append("الاسم متطابق بعد التنسيق لدى العملاء: " + "، ".join(map(str, names[name])))
    if row["cust_type"] is None:
        classification.append("التصنيف غير مسجل؛ يُعرض حاليًا كعميل عام في سجل العملاء")
    elif row["cust_type"] not in (0, 10):
        classification.append("قيمة تصنيف غير معروفة: %s؛ راجع بيانات العميل" % row["cust_type"])
    return dict(missing=missing, contacts=contacts, duplicates=duplicates, classification=classification)


def proposed_changes(row, operation, groups):
    changes = []
    for field in operation_for(operation)["fields"]:
        before = row[field]
        if operation == "names":
            after = clean_name(before)
        elif operation == "mobile":
            candidate = mobile_key(before)
            after = candidate if valid_mobile(candidate) and len(groups[1][candidate]) == 1 else before
        elif operation == "phones":
            after = clean_phones(before)
            if legacy_phones(row.get("tel_raw")):
                # Show the stored text as-is; saving rewrites it in list format.
                before = row["tel_raw"]
        else:
            after = clean_lines(before)
        if after != before:
            changes.append(dict(field=field, label=LABELS[field], before=before, after=after))
    return changes


def load_rows(db, ids=None, lock=False):
    table = db.customers
    query = table.id > 0 if ids is None else table.id.belongs(ids)
    options = dict(orderby=table.id)
    if lock and db._adapter.dbengine == "postgres":
        options["for_update"] = True
    rows = [row.as_dict() for row in db(query).select(*[table[field] for field in FIELDS], **options)]
    # tel as stored: executesql skips the DAL list decoding (see legacy_phones).
    raw = dict(db.executesql(db(query)._select(table.id, table.tel)))
    for row in rows:
        row["tel_raw"] = raw.get(row["id"])
        row["tel"] = decode_phones(row["tel_raw"])
    return rows


def _fingerprint(row, changes):
    value = dict(row={field: row.get(field) for field in FIELDS + ("tel_raw",)}, changes=changes)
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def preview(rows, operation, user_id, now=None):
    config = operation_for(operation)
    groups = indexes(rows)
    records, fingerprints = [], {}
    total = 0
    for row in rows:
        changes = proposed_changes(row, operation, groups)
        issues = findings(row, groups).get(operation, [])
        if not changes and not issues:
            continue
        total += 1
        if config["kind"] == "cleanup" and len(records) >= MAX_BATCH:
            continue
        records.append(dict(id=row["id"], name=(row["name"] or "").strip() or "عميل بلا اسم",
                            mobile=row["mobile"], changes=changes, issues=issues))
        if changes:
            fingerprints[str(row["id"])] = _fingerprint(row, changes)
    plan = None
    if fingerprints:
        plan = dict(token=secrets.token_urlsafe(32), operation=operation, user_id=user_id,
                    created_at=time.time() if now is None else now, fingerprints=fingerprints)
    return dict(operation=operation, kind=config["kind"], records=records, total=total,
                truncated=total > len(records), token=plan["token"] if plan else None), plan


def apply(db, plan, token, selected_ids, user_id, now=None):
    """Caller owns commit/rollback, including the audit event."""
    now = time.time() if now is None else now
    if not isinstance(plan, dict) or plan.get("user_id") != user_id:
        raise MaintenanceError("أعد المعاينة قبل تطبيق التغييرات.", 409)
    if not isinstance(token, str) or not token.isascii() or not secrets.compare_digest(plan.get("token", ""), token):
        raise MaintenanceError("المعاينة غير صالحة؛ أعد الفحص.", 409)
    if not 0 <= now - plan["created_at"] <= PREVIEW_TTL:
        raise MaintenanceError("انتهت صلاحية المعاينة؛ أعد الفحص لعرض البيانات الحالية.", 409)
    operation = plan["operation"]
    if operation_for(operation)["kind"] != "cleanup":
        raise MaintenanceError("هذه الأداة مخصصة للفحص فقط.")
    if (not isinstance(selected_ids, list) or not selected_ids or len(selected_ids) > MAX_BATCH
            or any(type(value) is not int or value <= 0 for value in selected_ids)
            or len(set(selected_ids)) != len(selected_ids)):
        raise MaintenanceError("اختر عميلًا واحدًا على الأقل من المعاينة، دون تكرار.")
    if any(str(value) not in plan["fingerprints"] for value in selected_ids):
        raise MaintenanceError("يتضمن الاختيار عميلًا لم تتم معاينته؛ أعد الفحص.", 409)

    # A mobile-format collision can involve an unselected customer. Serialize this
    # short transaction with inserts/updates, then recheck every normalized number.
    if operation == "mobile" and db._adapter.dbengine == "postgres":
        db.executesql("LOCK TABLE customers IN SHARE ROW EXCLUSIVE MODE", placeholders=[])
    rows = load_rows(db, sorted(selected_ids), lock=True)
    groups = indexes(load_rows(db) if operation == "mobile" else rows)
    proposals = {row["id"]: proposed_changes(row, operation, groups) for row in rows}
    if len(rows) != len(selected_ids) or any(
            _fingerprint(row, proposals[row["id"]]) != plan["fingerprints"][str(row["id"])] for row in rows):
        raise MaintenanceError("تغيّرت البيانات أو ظهر تعارض منذ المعاينة. لم تُطبَّق العملية؛ أعد الفحص.", 409)
    fields = 0
    for row in rows:
        query = db.customers.id == row["id"]
        for field in FIELDS[1:]:
            # tel is not compared here: the DAL re-encodes it, so a legacy plain value
            # never matched and one such customer aborted the whole batch. Its raw value
            # is part of the fingerprint checked above, under the row lock.
            if field != "tel":
                query &= db.customers[field] == row[field]
        updates = {change["field"]: change["after"] for change in proposals[row["id"]]}
        if not updates or db(query).update(**updates) != 1:
            raise MaintenanceError("تغيّرت البيانات أثناء التنفيذ؛ أعد المعاينة.", 409)
        fields += len(updates)
    return dict(updated=len(rows), fields=fields, operation=operation)


def account_snapshot(db):
    """One statement: live ledger totals, with the existing balance equation.

The legacy cached customers.amount/total/payed/returns fields are intentionally
not read. Returns are separate activity figures, not deducted a second time.
"""
    return db.executesql("""
        SELECT c.id, COALESCE(i.credit_total, 0) AS credit_total,
               COALESCE(p.payment_total, 0) AS payment_total,
               ROUND(CAST(COALESCE(i.credit_total, 0) - COALESCE(p.payment_total, 0) AS NUMERIC), 2) AS balance,
               COALESCE(p.cash_total, 0) AS cash_total, COALESCE(p.charity_total, 0) AS charity_total,
               COALESCE(p.adjust_total, 0) AS adjust_total,
               COALESCE(i.invoice_count, 0) AS invoice_count, i.last_purchase,
               COALESCE(p.payment_count, 0) AS payment_count, p.last_payment,
               COALESCE(r.return_count, 0) AS return_count, COALESCE(r.return_total, 0) AS return_total
        FROM customers c
        LEFT JOIN (
            SELECT customer, COUNT(*) AS invoice_count, MAX(created_on) AS last_purchase,
                   SUM(CASE WHEN payment_method = %s THEN total_after_discount ELSE 0 END) AS credit_total
            FROM invoice_master GROUP BY customer
        ) i ON i.customer = c.id
        LEFT JOIN (
            SELECT customers_id, COUNT(*) AS payment_count, MAX(created_on) AS last_payment,
                   SUM(amount) AS payment_total,
                   SUM(CASE WHEN COALESCE(pay_type, 0) = %s THEN amount ELSE 0 END) AS cash_total,
                   SUM(CASE WHEN pay_type = %s THEN amount ELSE 0 END) AS charity_total,
                   SUM(CASE WHEN pay_type = %s THEN amount ELSE 0 END) AS adjust_total
            FROM customers_pay GROUP BY customers_id
        ) p ON p.customers_id = c.id
        LEFT JOIN (
            SELECT customer, COUNT(*) AS return_count, SUM(total_after_discount) AS return_total
            FROM inv_return_master GROUP BY customer
        ) r ON r.customer = c.id
        ORDER BY c.id
    """, placeholders=[3, 0, 10, 20], as_dict=True)


def _date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if value:
        try:
            return date.fromisoformat(str(value)[:10])
        except ValueError:
            pass
    return None


def overview(rows, accounts, today=None):
    today = today or date.today()
    groups = indexes(rows)
    account_map = {int(row["id"]): row for row in accounts}
    counts = {operation["key"]: 0 for operation in OPERATIONS}
    summary = dict(total=len(rows), attention=0, cleanup=0, debit=0, credit=0, zero=0,
                   recent=0, inactive=0, never=0, unknown=0, debit_amount=0, credit_amount=0)
    records = []
    for row in rows:
        issues = findings(row, groups)
        cleanup = False
        for operation in OPERATIONS:
            affected = (bool(proposed_changes(row, operation["key"], groups))
                        if operation["kind"] == "cleanup" else bool(issues[operation["key"]]))
            counts[operation["key"]] += affected
            cleanup = cleanup or (affected and operation["kind"] == "cleanup")
        all_issues = list(dict.fromkeys(issue for values in issues.values() for issue in values))
        summary["attention"] += bool(all_issues)
        summary["cleanup"] += cleanup
        account = dict(account_map.get(row["id"], {}))
        account.pop("id", None)
        for field in ("credit_total", "payment_total", "balance", "cash_total", "charity_total", "adjust_total", "return_total"):
            account[field] = float(account.get(field) or 0)
        balance = account["balance"]
        balance_state = "debit" if balance > 0 else "credit" if balance < 0 else "zero"
        summary[balance_state] += 1
        if balance > 0:
            summary["debit_amount"] += balance
        elif balance < 0:
            summary["credit_amount"] -= balance
        last_purchase = _date(account.get("last_purchase"))
        days = (today - last_purchase).days if last_purchase else None
        activity = ("never" if not account.get("invoice_count") else "unknown" if days is None or days < 0
                    else "recent" if days <= 90 else "inactive")
        summary[activity] += 1
        account["last_purchase"] = str(account["last_purchase"])[:10] if account.get("last_purchase") else None
        account["last_payment"] = str(account["last_payment"])[:10] if account.get("last_payment") else None
        records.append(dict(id=row["id"], name=row["name"] or "عميل بلا اسم", mobile=row["mobile"],
                            administrator_name=row["administrator_name"], tel=row["tel"], address=row["address"],
                            note=row["note"], cust_type=row["cust_type"],
                            type_label="دعم الجمعية" if row["cust_type"] == 10 else "عام" if row["cust_type"] == 0 else "غير محدد",
                            issues=all_issues, issue_keys=[key for key, values in issues.items() if values],
                            balance_state=balance_state, activity=activity, days_since_purchase=days, account=account))
    summary["debit_amount"] = round(summary["debit_amount"], 2)
    summary["credit_amount"] = round(summary["credit_amount"], 2)
    summary["counts"] = counts
    return dict(summary=summary, records=records, operations=OPERATIONS, as_of=today.isoformat())
