var app = new Vue({
  el: "#app",
  data: {
    URL: window.CP_URLS || window.location.href,
    data: [],
    selectedRow: -1,
    new_row: true,
    edit_row_data: {
      start_time: "",
      end_time: "",
      kashir_amount_cash: 0,
      kashir_amount_atm: 0,
      kashir_amount_delay: 0,
      kashir_note: "",
      cash: 0,
    },
    start_datetime: "",
    end_datetime: "",
    shift_duration: "",
  },
  computed: {
    pendingCount() {
      if (!this.data || this.data.length === 0) return 0;
      return this.data.filter(r => !r.accountant_aprove).length;
    },
    approvedCount() {
      if (!this.data || this.data.length === 0) return 0;
      return this.data.filter(r => r.accountant_aprove).length;
    },
    totalCash() {
      if (!this.data || this.data.length === 0) return '0.00';
      const total = this.data.reduce((sum, r) => sum + Number(r.kashir_amount_cash || 0), 0);
      return this.formatMoney(total);
    },
  },
  created() {
    this.loadData();
    this.initDates();
  },
  methods: {
    loadData() {
      const baseUrl = window.location.pathname.replace(/\/[^\/]+$/, '');
      fetch(baseUrl + "/close_periods_get", {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          this.data = data;
        })
        .catch((err) => {
          console.error("Failed to load close periods:", err);
          Swal.fire("خطأ", "فشل تحميل البيانات", "error");
        });
    },

    initDates() {
      const now = new Date();
      this.start_datetime = this.toLocalISO(now);
      this.end_datetime = this.toLocalISO(now);
      this.calcDuration();
    },

    toLocalISO(date) {
      const pad = (n) => String(n).padStart(2, '0');
      return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
    },

    formatDateTime(val) {
      if (!val) return '—';
      try {
        const d = new Date(val);
        const pad = (n) => String(n).padStart(2, '0');
        return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
      } catch {
        return val;
      }
    },

    formatMoney(val) {
      const num = Number(val || 0);
      return num.toFixed(2);
    },

    calcDuration() {
      if (!this.start_datetime || !this.end_datetime) {
        this.shift_duration = '';
        return;
      }
      const d1 = new Date(this.end_datetime);
      const d2 = new Date(this.start_datetime);
      const diff = d1 - d2;
      if (diff < 0) {
        this.shift_duration = 'فترات التاريخ غير صحيحة';
      } else {
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const mins = Math.floor(diff / (1000 * 60)) - hours * 60;
        this.shift_duration = `${hours} ساعة و ${mins} دقيقة`;
      }
    },

    rowSelect(index, row) {
      this.selectedRow = index;
      this.edit_row_data = { ...row };

      this.start_datetime = this.toLocalISO(new Date(row.start_time));
      this.end_datetime = this.toLocalISO(new Date(row.end_time));
      this.calcDuration();
    },

    edit_row() {
      this.new_row = false;
    },

    new_row_click() {
      this.new_row = true;
      this.edit_row_data = {
        kashir_amount_cash: 0,
        kashir_amount_atm: 0,
        kashir_amount_delay: 0,
        kashir_note: "",
        cash: 0,
      };
      this.initDates();
    },

    save_data() {
      if (!this.start_datetime || !this.end_datetime) {
        Swal.fire("تنبية", "يجب اختيار وقت البداية والنهاية", "error");
        return;
      }

      this.calcDuration();
      if (this.shift_duration.includes('غير صحيحة')) {
        Swal.fire("تنبية", "ادخال غير صحيح للوقت", "error");
        return;
      }

      const cash = Number(this.edit_row_data.kashir_amount_cash || 0);
      const atm = Number(this.edit_row_data.kashir_amount_atm || 0);
      const delay = Number(this.edit_row_data.kashir_amount_delay || 0);

      if (cash === 0 && atm === 0 && delay === 0) {
        Swal.fire("تنبية", "يجب ادخال مبلغ واحد على الأقل", "error");
        return;
      }

      // Convert datetime-local to SQL format
      const startSql = this.start_datetime.replace('T', ' ') + ':00';
      const endSql = this.end_datetime.replace('T', ' ') + ':00';

      this.edit_row_data.start_time = startSql;
      this.edit_row_data.end_time = endSql;
      this.edit_row_data.kashir_total = cash + atm + delay;

      const baseUrl = window.location.pathname.replace(/\/[^\/]+$/, '');

      if (this.new_row) {
        var url = new URL(baseUrl + "/close_periods_add", window.location.origin);
        var params = { ...this.edit_row_data };
        Object.keys(params).forEach((key) => url.searchParams.append(key, params[key]));

        fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.id > 0) {
              this.edit_row_data.id = data.id;
              this.data.push(this.edit_row_data);
              this.resetForm();
              Swal.fire("عمل رائع", "تم الحفظ بنجاح", "success");
            } else {
              Swal.fire("خطأ", "لم تتم عملية الاضافة", "error");
            }
          });
      } else {
        var url = new URL(baseUrl + "/close_periods_edit", window.location.origin);
        var params = { ...this.edit_row_data };
        Object.keys(params).forEach((key) => url.searchParams.append(key, params[key]));

        fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.id > 0) {
              this.data.splice(this.selectedRow, 1, data);
              this.resetForm();
              Swal.fire("عمل رائع", "تم التعديل بنجاح", "success");
            } else {
              Swal.fire("خطأ", data.mess || "حصل خطأ", "error");
            }
          });
      }

      // Close modal
      const elem = document.getElementById("cpModal");
      const modal = bootstrap.Modal.getInstance(elem);
      if (modal) modal.hide();
    },

    acc_save_data() {
      if (this.edit_row_data.accountant_aprove === true) {
        Swal.fire("تنبية", "لقد تم استلام هذا الشفت مسبقاً", "error");
        return;
      }

      const cash = Number(this.edit_row_data.cash || 0);
      const kashirCash = Number(this.edit_row_data.kashir_amount_cash || 0);
      const diff = Math.abs(cash - kashirCash);

      if (diff > 0.01) {
        Swal.fire({
          title: "تنبيه",
          html: "المبلغ المستلم لا يتطابق مع المبلغ المسلّم من الكاشير<br>الفرق: " + (cash - kashirCash).toFixed(2) + "<br>هل تريد المتابعة؟",
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: "نعم",
          cancelButtonText: "لا",
        }).then((result) => {
          if (result.isConfirmed) {
            this._confirmAccept();
          }
        });
        return;
      }

      this._confirmAccept();
    },

    _confirmAccept() {
      const baseUrl = window.location.pathname.replace(/\/[^\/]+$/, '');
      var url = new URL(baseUrl + "/close_periods_edit", window.location.origin);
      var params = { ...this.edit_row_data };
      Object.keys(params).forEach((key) => url.searchParams.append(key, params[key]));

      fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.id > 0) {
            this.data.splice(this.selectedRow, 1);
            this.selectedRow = -1;
            Swal.fire("عمل رائع", "تم استلام الشفت بنجاح", "success");
          } else {
            Swal.fire("خطأ", data.mess || "حصل خطأ", "error");
          }
        });

      const elem = document.getElementById("cpAccModal");
      const modal = bootstrap.Modal.getInstance(elem);
      if (modal) modal.hide();
    },

    cancel_data() {
      this.resetForm();
    },

    resetForm() {
      this.new_row = true;
      this.edit_row_data = {
        kashir_amount_cash: 0,
        kashir_amount_atm: 0,
        kashir_amount_delay: 0,
        kashir_note: "",
        cash: 0,
      };
      this.selectedRow = -1;
      this.initDates();
    },

    delete_row() {
      Swal.fire({
        title: "هل انت متأكد؟",
        text: "سيتم حذف هذا السجل نهائياً",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#dc2626",
        cancelButtonColor: "#64748b",
        confirmButtonText: "نعم، احذف",
        cancelButtonText: "إلغاء",
      }).then((result) => {
        if (result.value) {
          const baseUrl = window.location.pathname.replace(/\/[^\/]+$/, '');
          this.$http
            .get(baseUrl + "/close_periods_delete/" + this.edit_row_data.id)
            .then((response) => {
              if (response.body.mess === 1) {
                this.data.splice(this.selectedRow, 1);
                this.selectedRow = -1;
                Swal.fire("تم الحذف", "تم حذف السجل بنجاح", "success");
              } else {
                Swal.fire("لم تتم العملية", "لا يمكن حذف هذا السجل", "error");
              }
            });
        }
      });
    },

    link_1() {
      if (this.edit_row_data && this.edit_row_data.id) {
        const baseUrl = window.location.pathname.replace(/\/[^\/]+$/, '');
        window.open(baseUrl + "/print_close_period/" + this.edit_row_data.id);
      }
    },

    link_2() {
      if (this.edit_row_data && this.edit_row_data.id) {
        const baseUrl = window.location.pathname.replace(/\/[^\/]+$/, '');
        window.open(baseUrl + "/print_close_period_by_day/" + this.edit_row_data.id);
      }
    },
  },
  watch: {
    start_datetime() { this.calcDuration(); },
    end_datetime() { this.calcDuration(); },
  },
});
