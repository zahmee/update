# -*- coding: utf-8 -*-
"""إرسال الفواتير إلى الهيئة وسجل مشاكل الإرسال (zatca_issue).

كل صف في طابور الإرسال (invoice_sending) يُرسل عبر process_row، وكل نتيجة غير ناجحة — أو
ناجحة بملاحظات — تُسجَّل في zatca_issue: صف واحد لكل فاتورة يُحدَّث مع كل محاولة، ويحفظ آخر
رد من الهيئة وسجل المحاولات. التصنيف يحدد مصير الفاتورة في الطابور:

- مرفوضة (أخطاء تحقق في بياناتها)، وبيانات مفقودة، وحذف يدوي: تخرج من الطابور، ويُحفظ
  محتواها بلا بيانات الشهادة لإعادتها من شاشة السجل بعد المعالجة.
- تعذّر الاتصال، خطأ أو صيانة في خادم الهيئة، رفض بيانات الربط، رد غير متوقع، خطأ في
  التجهيز: تبقى في الطابور وتُعاد في دورة الإرسال التالية. قبل هذا كان أي رد غير ناجح يُعامل
  كرفض نهائي، فتُحذف الفاتورة من الطابور ولا تُرسل أبداً — ومنها ردود الصيانة.
- مقبولة بملاحظات: أُبلغ عنها فعلاً، وتُسجَّل للمراجعة فقط.

لا تخرج فاتورة من الطابور ما لم تُسجَّل أولاً. والسجل لا يُسقط الإرسال: يُكتب داخل نقطة حفظ،
فإن تعذّر بقي تحديث الفاتورة وصف الطابور كما هما.

الدوال لا تعتمد المعاملة (commit)؛ المستدعي يعتمد أو يتراجع — عدا run_queue، دورة الجدولة، التي
تعتمد بعد كل فاتورة. التحكم في الإرسال (إيقاف مؤقت أو مفتوح، واستئناف) في القسم الأخير من الملف.
"""

import json
import logging
import traceback
from datetime import datetime, timedelta

from zatca_direct.api_client import ZatcaApiError, ZatcaConnectionError

logger = logging.getLogger(__name__)

INV_TYPES = {1: "مبيعات", 2: "مرتجع مبيعات"}

# tone: لون الشارة في الشاشة
KINDS = {
    "rejected": {"label": "مرفوضة من الهيئة", "tone": "danger"},
    "warning": {"label": "مقبولة بملاحظات", "tone": "warn"},
    "connection": {"label": "تعذّر الاتصال بالهيئة", "tone": "retry"},
    "server": {"label": "خطأ أو صيانة في خادم الهيئة", "tone": "retry"},
    "auth": {"label": "رفض بيانات الربط", "tone": "retry"},
    "unexpected": {"label": "رد غير متوقع من الهيئة", "tone": "retry"},
    "internal": {"label": "خطأ في تجهيز الفاتورة", "tone": "retry"},
    "bad_data": {"label": "بيانات الفاتورة مفقودة", "tone": "danger"},
    "removed": {"label": "حُذفت من الطابور يدوياً", "tone": "muted"},
}
# تخرج من الطابور؛ ما سواها (عدا الملاحظات) يبقى ويُعاد تلقائياً
LEAVES_QUEUE = ("rejected", "bad_data", "removed")
RETRY_KINDS = ("connection", "server", "auth", "unexpected", "internal")

STATES = {
    "open": "مفتوحة",
    "sent_later": "أُرسلت لاحقاً",
    "resolved": "تمت المعالجة",
    "ignored": "متجاهلة",
}
MANUAL_STATES = ("open", "resolved", "ignored")

HISTORY_MAX = 30
RESPONSE_MAX = 30000
AUTO_ACTOR = "تلقائي"


# ------------------------------------------------------------------ قراءة رد الهيئة

def _clean(text):
    return " ".join(str(text if text is not None else "").split())


def _short(text, limit):
    text = _clean(text)
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _message_item(m):
    """(الرمز، النص) من عنصر رسالة الهيئة — قاموس أو نص."""
    if isinstance(m, dict):
        code = _clean(m.get("code"))
        body = _clean(m.get("message") or m.get("category"))
        if not (code or body):
            body = _clean(json.dumps(m, ensure_ascii=False))
        return code, body
    return "", _clean(m)


def _as_dict(body):
    if isinstance(body, dict):
        return body
    text = str(body or "")
    brace = text.find("{")
    if brace == -1:
        return None
    try:
        data = json.loads(text[brace:])
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def parse_body(body):
    """يفكك رد الهيئة (قاموس، أو نص JSON قد يسبقه نص) إلى حالته وأخطاء التحقق وملاحظاته.

    errors/warnings: نتائج التحقق وحدها (validationResults) — هي دليل الرفض.
    other: رسائل عامة خارجها (errors / message ...) تُستخدم لنص السبب فقط.
    """
    out = {"data": None, "status": "", "errors": [], "warnings": [], "other": []}
    data = _as_dict(body)
    if data is None:
        return out
    out["data"] = data
    vr = data.get("validationResults")
    vr = vr if isinstance(vr, dict) else {}
    for key, dest in (("errorMessages", "errors"), ("warningMessages", "warnings")):
        items = vr.get(key)
        if items is None:
            items = data.get(key)
        for m in items if isinstance(items, list) else []:
            code, text = _message_item(m)
            if code or text:
                out[dest].append({"code": code, "text": text})
    for key in ("errors", "Errors"):
        items = data.get(key)
        for m in items if isinstance(items, list) else []:
            code, text = _message_item(m)
            if code or text:
                out["other"].append({"code": code, "text": text})
    for key in ("message", "Message", "error", "errorMessage", "detail"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            out["other"].append({"code": "", "text": _clean(value)})
    out["status"] = _clean(data.get("reportingStatus") or data.get("clearanceStatus")
                           or vr.get("status"))
    return out


def _codes_text(items):
    seen = []
    for m in items:
        if m["code"] and m["code"] not in seen:
            seen.append(m["code"])
    return _short(", ".join(seen), 255) or None


def _response_text(parsed, raw):
    if parsed and parsed.get("data") is not None:
        text = json.dumps(parsed["data"], ensure_ascii=False)
    elif raw is None:
        return None
    else:
        text = str(raw)
    return text[:RESPONSE_MAX]


def _plain_snippet(raw):
    """أول سطر مفهوم من رد نصي؛ صفحات HTML لا يُقتبس منها شيء."""
    text = _clean(raw)
    if not text or text.startswith("<"):
        return ""
    return _short(text, 120)


def _reason(kind, http_status, parsed, raw):
    first = (parsed["errors"] or parsed["other"] or [None])[0]
    detail = ""
    if first:
        detail = (first["code"] + ": " if first["code"] else "") + first["text"]
    elif parsed.get("data") is None:
        detail = _plain_snippet(raw)
    code = " (%s)" % http_status if http_status else ""
    if kind == "rejected":
        return _short(detail or "رفضت الهيئة الفاتورة دون ذكر السبب", 500)
    head = {
        "auth": "الهيئة رفضت بيانات الربط (الشهادة أو كلمة السر)",
        "server": "خادم الهيئة لم يعالج الطلب (صيانة أو ضغط)",
        "unexpected": "رد غير متوقع من الهيئة",
    }.get(kind, "")
    return _short(head + code + (" — " + detail if detail else ""), 500)


def _info(kind, message, http_status=None, parsed=None, response=None):
    parsed = parsed or parse_body(None)
    return {
        "kind": kind,
        "leaves_queue": kind in LEAVES_QUEUE,
        "http_status": http_status,
        "zatca_status": parsed["status"][:40] or None,
        "codes": _codes_text(parsed["errors"] + parsed["warnings"] + parsed["other"]),
        "message": message,
        "response": response,
    }


def classify_http(status_code, body):
    """رد غير ناجح من الهيئة: رفض فقط إن كان فيه أخطاء تحقق أو حالة NOT_*، وإلا حسب الرمز."""
    parsed = parse_body(body)
    if parsed["errors"] or parsed["status"].upper().startswith("NOT_"):
        kind = "rejected"
    elif status_code in (401, 403):
        kind = "auth"
    elif status_code == 429 or (status_code or 0) >= 500:
        kind = "server"
    else:
        kind = "unexpected"
    return _info(kind, _reason(kind, status_code, parsed, body), status_code, parsed,
                 _response_text(parsed, body))


def classify_exception(exc, tb=None):
    if isinstance(exc, ZatcaApiError):
        return classify_http(exc.status_code, exc.detail)
    if isinstance(exc, ZatcaConnectionError):
        return _info("connection", _short("تعذّر الاتصال بالهيئة: %s" % exc, 500),
                     response=str(exc)[:RESPONSE_MAX])
    return _info("internal", _short("%s: %s" % (type(exc).__name__, exc), 500),
                 response=(tb or repr(exc))[:RESPONSE_MAX])


def classify_result(raw_response, status):
    """رد ناجح الرمز لكن بلا حالة قبول."""
    parsed = parse_body(raw_response)
    if parsed["errors"] or _clean(status).upper().startswith("NOT_"):
        kind = "rejected"
    else:
        kind = "unexpected"
    message = _reason(kind, None, parsed, raw_response)
    if kind == "unexpected" and status:
        message = _short("%s — الحالة: %s" % (message, status), 500)
    return _info(kind, message, None, parsed, _response_text(parsed, raw_response))


def warning_info(raw_response):
    """ملاحظات الهيئة على فاتورة قبلتها، أو None."""
    parsed = parse_body(raw_response)
    if not parsed["warnings"]:
        return None
    first = parsed["warnings"][0]
    message = (first["code"] + ": " if first["code"] else "") + first["text"]
    if len(parsed["warnings"]) > 1:
        message += " (+%d)" % (len(parsed["warnings"]) - 1)
    return _info("warning", _short(message, 500), None, parsed,
                 _response_text(parsed, raw_response))


def strip_payload(json_inv):
    """محتوى الفاتورة بلا بيانات الشهادة (المفتاح الخاص وكلمة السر) — هو ما يُحفظ في السجل."""
    if not isinstance(json_inv, dict):
        return None
    return json.dumps({k: v for k, v in json_inv.items() if k != "cert_info"}, ensure_ascii=False)


# ------------------------------------------------------------------ السجل

def _stamp(now):
    return now.strftime("%Y-%m-%d %H:%M:%S")


def _history_add(history, entry):
    try:
        items = json.loads(history or "[]")
    except ValueError:
        items = []
    if not isinstance(items, list):
        items = []
    items.append(entry)
    return json.dumps(items[-HISTORY_MAX:], ensure_ascii=False)


def find_issue(db, inv_type, inv_id):
    t = db.zatca_issue
    return db((t.inv_type == inv_type) & (t.inv_id == inv_id)).select(
        orderby=t.id, limitby=(0, 1)).first()


def _master(db, inv_type):
    return {1: db.invoice_master, 2: db.inv_return_master}.get(inv_type)


def _snapshot(db, inv_type, inv_id):
    table = _master(db, inv_type)
    if table is None or not inv_id:
        return {}
    row = db(table.id == inv_id).select(table.total, table.created_on).first()
    if not row:
        return {}
    snap = {"inv_total": row.total}
    if row.created_on:
        snap["inv_date"] = row.created_on.date()
        snap["inv_time"] = row.created_on.time().replace(microsecond=0)
    return snap


def _insert_issue(db, inv_type, inv_id, inv_date, inv_time, fields):
    snap = _snapshot(db, inv_type, inv_id)
    return db.zatca_issue.insert(
        inv_type=inv_type, inv_id=inv_id,
        inv_date=inv_date or snap.get("inv_date"),
        inv_time=inv_time or snap.get("inv_time"),
        inv_total=snap.get("inv_total"),
        **fields)


def record_problem(db, inv_type, inv_id, info, actor=None, payload=None,
                   inv_date=None, inv_time=None, now=None):
    """يسجّل مشكلة إرسال الفاتورة: صفها الوحيد يُنشأ أو يُحدَّث، وتُفتح من جديد ما لم تكن متجاهلة."""
    now = now or datetime.now()
    counts = info["kind"] != "removed"
    entry = {"at": _stamp(now), "kind": info["kind"], "http": info["http_status"],
             "msg": _short(info["message"], 200), "by": actor or AUTO_ACTOR}
    fields = dict(kind=info["kind"], http_status=info["http_status"],
                  zatca_status=info["zatca_status"], codes=info["codes"],
                  message=info["message"], response=info["response"], last_at=now)
    if payload:
        fields["payload"] = payload
    row = find_issue(db, inv_type, inv_id)
    if row:
        if row.state != "ignored":
            fields.update(state="open", resolved_by=None, resolved_at=None, resolve_note=None)
        fields["attempts"] = (row.attempts or 0) + (1 if counts else 0)
        fields["history"] = _history_add(row.history, entry)
        row.update_record(**fields)
        return row.id
    fields.update(state="open", attempts=1 if counts else 0, first_at=now,
                  history=_history_add(None, entry))
    return _insert_issue(db, inv_type, inv_id, inv_date, inv_time, fields)


def record_sent(db, inv_type, inv_id, warn=None, actor=None, inv_date=None, inv_time=None,
                now=None):
    """بعد قبول الهيئة: الملاحظات تُسجَّل للمراجعة، ومشكلة الفاتورة المفتوحة تُغلق تلقائياً."""
    now = now or datetime.now()
    row = find_issue(db, inv_type, inv_id)
    if warn is None and row is None:
        return None
    entry = {"at": _stamp(now), "kind": "warning" if warn else "sent", "http": None,
             "msg": _short(warn["message"], 200) if warn else "قبلتها الهيئة",
             "by": actor or AUTO_ACTOR}
    if warn:
        fields = dict(kind="warning", http_status=None, zatca_status=warn["zatca_status"],
                      codes=warn["codes"], message=warn["message"], response=warn["response"],
                      last_at=now, sent_at=now)
        if row:
            if row.state != "ignored":
                fields.update(state="open", resolved_by=None, resolved_at=None, resolve_note=None)
            fields["history"] = _history_add(row.history, entry)
            row.update_record(**fields)
            return row.id
        fields.update(state="open", attempts=0, first_at=now, history=_history_add(None, entry))
        return _insert_issue(db, inv_type, inv_id, inv_date, inv_time, fields)
    fields = dict(sent_at=now, last_at=now, history=_history_add(row.history, entry))
    if row.state == "open":
        fields.update(state="sent_later", resolved_by=None, resolved_at=now,
                      resolve_note="أُرسلت بنجاح في محاولة لاحقة")
    row.update_record(**fields)
    return row.id


def record_removed(db, queue_row, actor=None, now=None):
    """فاتورة غير مرسلة حُذفت من الطابور يدوياً: تُسجَّل بمحتواها لإعادتها إن لزم."""
    try:
        json_inv = json.loads(queue_row.inv_data) if queue_row.inv_data else None
    except (TypeError, ValueError):
        json_inv = None
    info = _info("removed", "حُذفت من طابور الإرسال يدوياً قبل وصولها للهيئة")
    return record_problem(db, queue_row.inv_type, queue_row.inv_id, info, actor=actor,
                          payload=strip_payload(json_inv), inv_date=queue_row.inv_date,
                          inv_time=queue_row.inv_time, now=now)


def _log_safely(db, fn, *args, **kwargs):
    """يكتب في السجل داخل نقطة حفظ: تعذّر السجل لا يلغي تحديث الفاتورة ولا صف الطابور.

    يعيد False إن تعذّرت الكتابة، وإلا True.
    """
    db.executesql("SAVEPOINT zatca_issue_log")
    try:
        fn(db, *args, **kwargs)
    except Exception:
        db.executesql("ROLLBACK TO SAVEPOINT zatca_issue_log")
        logger.exception("zatca_issue: تعذّر تسجيل الفاتورة %s/%s", args[0], args[1])
        return False
    db.executesql("RELEASE SAVEPOINT zatca_issue_log")
    return True


# ------------------------------------------------------------------ الإرسال

def _lock_queue_row(db, row_id):
    """يقفل صف الطابور حتى نهاية المعاملة، ويتخطاه إن كانت عملية أخرى ترسله الآن.

    يمنع دورتين متزامنتين — أو الدورة وزر الإرسال في الشاشة — من إرسال الفاتورة نفسها مرتين.
    """
    return bool(db.executesql(
        "SELECT id FROM invoice_sending WHERE id = %s AND COALESCE(send, 'F') = 'F'"
        " FOR UPDATE SKIP LOCKED", placeholders=[int(row_id)]))


def _mark_sent(db, queue_row, result, raw):
    table = _master(db, queue_row.inv_type)
    if table is None:
        return
    db(table.id == queue_row.inv_id).update(
        pih_txt=result.get("pih_base64"),
        qr_code=result.get("qr_value"),
        zatca_res=json.dumps(raw, ensure_ascii=False),
        send_to_zatca=True,
    )


def process_row(db, row_id, actor=None, process_fn=None, now=None):
    """يرسل صفاً واحداً من طابور الإرسال ويسجّل نتيجته. لا يعتمد المعاملة.

    يعيد dict: status، sent، وعند المشكلة kind و final (خرجت من الطابور) و detail.
    """
    now = now or datetime.now()
    if not _lock_queue_row(db, row_id):
        return {"row_id": row_id, "status": "BUSY", "sent": False,
                "detail": "الفاتورة قيد الإرسال من عملية أخرى، أو لم تعد في الطابور"}
    r = db.invoice_sending(row_id)
    base = {"row_id": r.id, "inv_id": r.inv_id, "inv_type": r.inv_type}
    ctx = dict(actor=actor, inv_date=r.inv_date, inv_time=r.inv_time, now=now)

    try:
        json_inv = json.loads(r.inv_data) if r.inv_data else None
    except (TypeError, ValueError):
        json_inv = None
    if not isinstance(json_inv, dict):
        message = ("بيانات الفاتورة المحفوظة في الطابور غير صالحة" if r.inv_data
                   else "لا توجد بيانات للفاتورة في الطابور")
        return _finish_problem(db, r, _info("bad_data", message), None, base, ctx)

    if process_fn is None:
        from zatca_direct.invoice_processor import process_invoice as process_fn
    try:
        result = process_fn(json_inv) or {}
    except Exception as exc:
        info = classify_exception(exc, traceback.format_exc())
        return _finish_problem(db, r, info, json_inv, base, ctx)

    raw = result.get("raw_response") or {}
    status = _clean(result.get("status")).upper()
    if status in ("REPORTED", "CLEARED"):
        _mark_sent(db, r, result, raw)
        r.update_record(send=True)
        warn = warning_info(raw)
        _log_safely(db, record_sent, r.inv_type, r.inv_id, warn, **ctx)
        out = dict(base, status=status, sent=True, warnings=bool(warn))
        if warn:
            out["detail"] = warn["message"]
        return out
    return _finish_problem(db, r, classify_result(raw, status), json_inv, base, ctx)


def _finish_problem(db, r, info, json_inv, base, ctx):
    payload = strip_payload(json_inv) if info["leaves_queue"] else None
    logged = _log_safely(db, record_problem, r.inv_type, r.inv_id, info, payload=payload, **ctx)
    final = bool(info["leaves_queue"] and logged)
    if final:
        r.delete_record()
    return dict(base, status=info["kind"].upper(), kind=info["kind"], sent=False,
                final=final, logged=logged, detail=info["message"])


# ------------------------------------------------------------------ إجراءات الشاشة

def invoice_sent(db, inv_type, inv_id):
    table = _master(db, inv_type)
    if table is None:
        return False
    row = db(table.id == inv_id).select(table.send_to_zatca).first()
    return bool(row and row.send_to_zatca)


def in_queue(db, inv_type, inv_id):
    q = db.invoice_sending
    return not db((q.inv_type == inv_type) & (q.inv_id == inv_id) & (q.send == False)).isempty()


def _lock_issue(db, issue_id):
    return bool(db.executesql("SELECT id FROM zatca_issue WHERE id = %s FOR UPDATE",
                              placeholders=[int(issue_id)]))


def set_state(db, issue_id, state, note, user_id=None, actor=None, now=None):
    """تغيير المتابعة يدوياً: تمت المعالجة / متجاهلة (بملاحظة إلزامية) / إعادة فتح."""
    now = now or datetime.now()
    if state not in MANUAL_STATES:
        return False, "حالة غير صالحة"
    note = _clean(note)
    if state != "open" and len(note) < 3:
        return False, "اكتب ملاحظة توضح ما تم (3 أحرف على الأقل)"
    if len(note) > 255:
        return False, "الملاحظة أطول من 255 حرفاً"
    if not _lock_issue(db, issue_id):
        return False, "السجل غير موجود"
    row = db.zatca_issue(issue_id)
    entry = {"at": _stamp(now), "kind": "state", "state": state, "msg": note,
             "by": actor or AUTO_ACTOR}
    fields = dict(state=state, history=_history_add(row.history, entry))
    if state == "open":
        fields.update(resolved_by=None, resolved_at=None, resolve_note=None)
    else:
        fields.update(resolved_by=user_id, resolved_at=now, resolve_note=note)
    row.update_record(**fields)
    return True, {"resolved": "سُجّلت المعالجة", "ignored": "سُجّل التجاهل",
                  "open": "أُعيد فتح السجل"}[state]


def requeue(db, issue_id, actor=None, now=None, cert_info_fn=None):
    """يعيد فاتورة خرجت من الطابور (مرفوضة أو محذوفة) إليه بمحتواها المحفوظ وبيانات الربط الحالية."""
    now = now or datetime.now()
    if not _lock_issue(db, issue_id):
        return False, "السجل غير موجود"
    row = db.zatca_issue(issue_id)
    if not row.payload:
        return False, "لا يوجد محتوى محفوظ لهذه الفاتورة يمكن إعادته"
    if invoice_sent(db, row.inv_type, row.inv_id):
        return False, "الفاتورة مُرسلة للهيئة بالفعل"
    if in_queue(db, row.inv_type, row.inv_id):
        return False, "الفاتورة موجودة في طابور الإرسال بالفعل"
    try:
        data = json.loads(row.payload)
    except ValueError:
        data = None
    if not isinstance(data, dict):
        return False, "المحتوى المحفوظ للفاتورة غير صالح"
    csr = db(db.csr_config.id > 0).select().first()
    if not (csr and csr.pcsid_binarysecuritytoken and csr.pcsid_secret):
        return False, "بيانات الربط بالهيئة غير مكتملة"
    if cert_info_fn is None:
        from invoice_zatca import cert_info_from_config as cert_info_fn
    data["cert_info"] = cert_info_fn(csr)
    db.invoice_sending.insert(
        inv_id=row.inv_id, inv_type=row.inv_type, inv_date=row.inv_date, inv_time=row.inv_time,
        inv_data=json.dumps(data, ensure_ascii=False), send=False)
    entry = {"at": _stamp(now), "kind": "requeued", "msg": "أُعيدت إلى طابور الإرسال",
             "by": actor or AUTO_ACTOR}
    row.update_record(state="open", resolved_by=None, resolved_at=None, resolve_note=None,
                      history=_history_add(row.history, entry))
    return True, "أُعيدت الفاتورة إلى طابور الإرسال وستُرسل في الدورة القادمة"


# ------------------------------------------------------------------ التحكم في الإرسال التلقائي
# قرار المالك 2026-09-24: الجدولة تزور رابط الإرسال دائماً، والمدير يتحكم في الإرسال من شاشة
# setup/invoice_sending. الإيقاف يجعل الزيارة تخرج دون إرسال؛ الفواتير تُضاف إلى الطابور كالمعتاد
# وتُرسل بترتيبها عند الاستئناف، لأن رقم التسلسل وبصمة الفاتورة السابقة يُثبَّتان عند الحفظ لا عند
# الإرسال. الإيقاف بمدة يُستأنف تلقائياً، وبلا مدة يبقى حتى الاستئناف يدوياً (بلا حد أقصى بقرار
# المالك). مهلة إبلاغ الهيئة عن الفاتورة المبسطة ٢٤ ساعة، والشاشة تنبّه عند اقتراب أقدم فاتورة منها.

REPORT_DEADLINE_HOURS = 24
DEADLINE_WARN_HOURS = 20
# أعطال عامة تصيب كل الفواتير: بعد ثلاثة متتالية تتوقف الزيارة ويُكمل الباقي في الزيارة التالية،
# بدل انتظار كل فاتورة حتى ٥٠ ثانية × ٣ محاولات. رفض بيانات الربط والرد غير المتوقع لا يوقفانها:
# قد يخصّان فاتورة بعينها، ولو كانت في رأس الطابور لتعطل الطابور كله.
OUTAGE_KINDS = ("connection", "server")
OUTAGE_STOP_AFTER = 3
PAUSE_PRESETS = ("1h", "3h", "morning", "until", "open")
MORNING_HOUR = 6
CONTROL_HISTORY_SHOWN = 8
_CONTROL_LOCK = "asbab5:zatca_send_control"
_RUNNING = dict(paused=False, paused_until=None, pause_reason=None, paused_by=None,
                paused_by_name=None, paused_at=None)
_AR_DAYS = ("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")
_AR_DIGITS = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")


def ar_when(dt, now):
    """وقت بصيغة الشاشة: «اليوم ٦:٠٠ م» / «غداً ٦:٠٠ ص» / «الخميس ٢٥/٩ ٦:٠٠ ص». يُحسب في الخادم
    فلا يتأثر بتقويم المتصفح أو منطقته الزمنية."""
    if not dt:
        return ""
    clock = "%d:%02d %s" % (dt.hour % 12 or 12, dt.minute, "ص" if dt.hour < 12 else "م")
    days = (dt.date() - now.date()).days
    day = {0: "اليوم", 1: "غداً", -1: "أمس"}.get(days) or "%s %d/%d" % (_AR_DAYS[dt.weekday()], dt.day, dt.month)
    return ("%s %s" % (day, clock)).translate(_AR_DIGITS)


def _history_list(history):
    try:
        items = json.loads(history or "[]")
    except ValueError:
        items = []
    return items if isinstance(items, list) else []


def _parse_stamp(text):
    try:
        return datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


def _control_row(db, lock=False):
    """صف التحكم (أو None قبل أول إيقاف). lock يسلسل التغييرات حتى نهاية المعاملة."""
    if lock and getattr(db._adapter, "dbengine", "") == "postgres":
        db.executesql("SELECT pg_advisory_xact_lock(hashtext(%s))", placeholders=[_CONTROL_LOCK])
    t = db.zatca_send_control
    return db(t.id > 0).select(orderby=t.id, limitby=(0, 1)).first()


def _effective(row, now):
    """موقوف الآن؟ الإيقاف الذي انتهت مدته لا يُعد موقوفاً ولو لم يُسجَّل استئنافه بعد."""
    return bool(row and row.paused and (row.paused_until is None or row.paused_until > now))


def _save_control(db, row, entry, fields):
    history = _history_add(row.history if row else None, entry)
    if row:
        row.update_record(history=history, **fields)
    else:
        db.zatca_send_control.insert(history=history, **dict(_RUNNING, **fields))


def control_state(db, now=None):
    """حالة الإرسال التلقائي للشاشة — قراءة فقط."""
    now = now or datetime.now()
    row = _control_row(db)
    paused = _effective(row, now)
    history = []
    for entry in reversed(_history_list(row.history if row else None)[-CONTROL_HISTORY_SHOWN:]):
        item = dict(entry)
        item["at_label"] = ar_when(_parse_stamp(entry.get("at")), now)
        item["until_label"] = ar_when(_parse_stamp(entry.get("until")), now)
        history.append(item)
    return {
        "paused": paused,
        "open_ended": bool(paused and row.paused_until is None),
        "until_label": ar_when(row.paused_until, now) if paused else "",
        "reason": row.pause_reason if paused else "",
        "by": (row.paused_by_name or "") if paused else "",
        "at_label": ar_when(row.paused_at, now) if paused else "",
        "history": history,
    }


def pause_until_for(preset, until_text, now):
    """(وقت الاستئناف أو None لإيقاف بلا مدة، رسالة خطأ أو None)."""
    if preset == "1h":
        return now + timedelta(hours=1), None
    if preset == "3h":
        return now + timedelta(hours=3), None
    if preset == "morning":
        morning = now.replace(hour=MORNING_HOUR, minute=0, second=0, microsecond=0)
        return (morning if morning > now else morning + timedelta(days=1)), None
    if preset == "open":
        return None, None
    if preset == "until":
        try:
            until = datetime.strptime(_clean(until_text)[:16], "%Y-%m-%dT%H:%M")
        except ValueError:
            return None, "حدد تاريخ ووقت الاستئناف"
        if until <= now + timedelta(minutes=1):
            return None, "وقت الاستئناف يجب أن يكون بعد الآن"
        return until, None
    return None, "اختر مدة الإيقاف"


def pause_sending(db, preset, reason, until_text=None, user_id=None, actor=None, now=None):
    """يوقف الإرسال التلقائي حتى وقت، أو حتى الاستئناف يدوياً. يعدّل الإيقاف القائم إن وُجد."""
    now = now or datetime.now()
    if preset not in PAUSE_PRESETS:
        return False, "اختر مدة الإيقاف"
    reason = _clean(reason)
    if len(reason) < 3:
        return False, "اكتب سبب الإيقاف (3 أحرف على الأقل)"
    if len(reason) > 255:
        return False, "السبب أطول من 255 حرفاً"
    until, error = pause_until_for(preset, until_text, now)
    if error:
        return False, error
    row = _control_row(db, lock=True)
    entry = {"at": _stamp(now), "action": "pause", "until": _stamp(until) if until else None,
             "msg": reason, "by": actor or AUTO_ACTOR}
    _save_control(db, row, entry, dict(paused=True, paused_until=until, pause_reason=reason,
                                       paused_by=user_id, paused_by_name=actor, paused_at=now))
    if until:
        return True, "أُوقف الإرسال التلقائي حتى %s" % ar_when(until, now)
    return True, "أُوقف الإرسال التلقائي حتى تستأنفه"


def resume_sending(db, actor=None, now=None):
    now = now or datetime.now()
    row = _control_row(db, lock=True)
    if not _effective(row, now):
        return False, "الإرسال التلقائي يعمل بالفعل"
    entry = {"at": _stamp(now), "action": "resume", "msg": "استُؤنف يدوياً", "by": actor or AUTO_ACTOR}
    _save_control(db, row, entry, _RUNNING)
    return True, "استُؤنف الإرسال التلقائي، وتُرسل الفواتير المنتظرة في زيارة الجدولة القادمة"


def sending_paused(db, now=None):
    """للدورة: هل الإرسال موقوف الآن؟ يسجّل الاستئناف التلقائي عند انتهاء المدة."""
    now = now or datetime.now()
    row = _control_row(db)
    if not (row and row.paused):
        return False
    if _effective(row, now):
        return True
    row = _control_row(db, lock=True)
    if row and row.paused and not _effective(row, now):
        entry = {"at": _stamp(now), "action": "auto_resume", "msg": "انتهت مدة الإيقاف", "by": AUTO_ACTOR}
        _save_control(db, row, entry, _RUNNING)
    return _effective(row, now)


def oldest_waiting(db, now=None):
    """أقدم فاتورة تنتظر في الطابور وعمرها بالساعات، لتنبيه مهلة الإبلاغ."""
    now = now or datetime.now()
    t = db.invoice_sending
    row = db((t.send == False) & (t.inv_date != None)).select(
        t.inv_id, t.inv_type, t.inv_date, t.inv_time, orderby=t.inv_date | t.inv_time,
        limitby=(0, 1)).first()
    if not row:
        return None
    issued = datetime.combine(row.inv_date, row.inv_time or datetime.min.time())
    hours = max((now - issued).total_seconds() / 3600.0, 0)
    tone = "danger" if hours >= REPORT_DEADLINE_HOURS else "warn" if hours >= DEADLINE_WARN_HOURS else "ok"
    return {"inv_id": row.inv_id, "inv_type": row.inv_type, "hours": round(hours, 1), "tone": tone,
            "issued_label": ar_when(issued, now)}


# ------------------------------------------------------------------ دورة الإرسال (الجدولة)

def _paused_safely(db, now, commit, rollback):
    """تعذّر قراءة التحكم لا يوقف الإرسال: يستمر كما كان قبل وجود التحكم."""
    try:
        paused = sending_paused(db, now)
        commit()
        return paused
    except Exception:
        rollback()
        logger.exception("zatca_send_control: تعذّرت قراءة حالة الإرسال، يستمر الإرسال")
        return False


def run_queue(db, process_fn=None, now_fn=None, commit=None, rollback=None):
    """الدورة التي تزورها الجدولة: تحترم الإيقاف (قبل الدورة وقبل كل فاتورة)، وتتوقف عند تعطل
    الهيئة. الدالة الوحيدة هنا التي تعتمد المعاملة: بعد كل فاتورة، فلا يضيع ما أُرسل إن انقطعت."""
    now_fn = now_fn or datetime.now
    commit = commit or db.commit
    rollback = rollback or db.rollback
    out = {"ok": True, "paused": False, "stopped": None, "processed": 0, "remaining": 0, "results": []}
    if _paused_safely(db, now_fn(), commit, rollback):
        out["paused"] = True
        return out

    db(db.invoice_sending.send == True).delete()
    commit()
    t = db.invoice_sending
    ids = [r.id for r in db(t.send == False).select(t.id, orderby=t.id)]
    results, streak = out["results"], 0
    for i, row_id in enumerate(ids):
        if i and _paused_safely(db, now_fn(), commit, rollback):
            out["stopped"] = "paused"
            break
        try:
            res = process_row(db, row_id, process_fn=process_fn, now=now_fn())
            commit()
        except Exception as e:
            rollback()
            logger.exception("ZATCA send failed for queue row %s", row_id)
            res = {"row_id": row_id, "status": "ERROR", "sent": False, "detail": str(e)}
        results.append(res)
        streak = streak + 1 if res.get("kind") in OUTAGE_KINDS else 0
        if streak >= OUTAGE_STOP_AFTER and i + 1 < len(ids):
            out["stopped"] = "outage"
            _note_outage_stop(db, res.get("kind"), len(ids) - i - 1, now_fn(), commit, rollback)
            break
    out["processed"] = len(results)
    out["remaining"] = len(ids) - len(results)
    return out


def _note_outage_stop(db, kind, remaining, now, commit, rollback):
    try:
        label = KINDS.get(kind, {}).get("label", kind)
        entry = {"at": _stamp(now), "action": "outage", "by": AUTO_ACTOR,
                 "msg": ("توقفت زيارة الإرسال بعد %d أعطال متتالية (%s)؛ الفواتير الباقية (%d) تُرسل في "
                         "الزيارة التالية" % (OUTAGE_STOP_AFTER, label, remaining)).translate(_AR_DIGITS)}
        _save_control(db, _control_row(db, lock=True), entry, {})
        commit()
    except Exception:
        rollback()
        logger.exception("zatca_send_control: تعذّر تسجيل توقف الزيارة")
