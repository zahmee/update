# -*- coding: utf-8 -*-
#  type: ignore
import api_helpers as api


def _valid_employee_id(value):
    try:
        employee_id = int(value)
    except (TypeError, ValueError):
        return None
    return employee_id if db.employees[employee_id] else None


def _post_only():
    """التعديل والحذف بطلب POST فقط، فلا يُنفَّذ برابط يُفتح في المتصفح."""
    if request.env.request_method != "POST":
        raise HTTP(405)


def _valid_allowance_deduction_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.key_allowance_deduction[row_id] else None


@can_access(7003)
def index():
    return dict()


@can_access(7003)
def get_lookups():
    employees = db(db.employees.id > 0).select(
        db.employees.id, db.employees.emp_name,
        orderby=db.employees.emp_name
    )
    ad_types = db(db.key_allowance_deduction.id > 0).select(
        db.key_allowance_deduction.id,
        db.key_allowance_deduction.name,
        db.key_allowance_deduction.ad_type,
        orderby=db.key_allowance_deduction.name
    )
    # من له راتب مسجل: الحفظ «إضافة» عليه يستبدل راتبه الأساسي، فتُعطَّل في نافذة الإضافة
    with_salary = [r[0] for r in db.executesql("SELECT employee FROM emp_salary")]
    return response.json(api.api_ok(data={
        "employees": employees,
        "ad_types": ad_types,
        "with_salary": with_salary,
    }))


@can_access(7003)
def get_salaries():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    # بحث نصي
    if ReqVar.SearchText and ReqVar.SearchText != '':
        srt = ReqVar.SearchText.split()
        for word in srt:
            pattern = '%' + word + '%'
            conditions.append("( emp.emp_name LIKE %s OR emp.id_number LIKE %s )")
            params.extend([pattern, pattern])

    # ترتيب
    allowed_sort_columns = {'id', 'emp_name', 'basic_salary', 'total_allowances', 'total_deductions', 'net_salary'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort_columns else 'emp_name'

    # تحويل أسماء الأعمدة المحسوبة للترتيب
    sort_map = {
        'id': 's.id',
        'emp_name': 'emp.emp_name',
        'basic_salary': 's.basic_salary',
        'total_allowances': 'total_allowances',
        'total_deductions': 'total_deductions',
        'net_salary': 'net_salary',
    }
    sort_col = sort_map.get(sc, 'emp.emp_name')
    sa = 'ASC' if ReqVar.sequence == 'true' else 'DESC'

    offset = int(pg * rc)

    where = ''
    if conditions:
        where = ' AND ' + ' AND '.join(conditions)

    sql = (
        f"SELECT s.id, s.employee, s.basic_salary, "
        f"emp.emp_name, jt.name AS job_title_name, "
        f"COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'بدل' "
        f"), 0) AS total_allowances, "
        f"COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'خصم' "
        f"), 0) AS total_deductions, "
        f"s.basic_salary + COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'بدل' "
        f"), 0) - COALESCE(( "
        f"  SELECT SUM(sd.amount) FROM emp_salary_detail sd "
        f"  JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        f"  WHERE sd.employee = s.employee AND ad.ad_type = 'خصم' "
        f"), 0) AS net_salary "
        f"FROM emp_salary s "
        f"JOIN employees emp ON emp.id = s.employee "
        f"LEFT JOIN key_job_titles jt ON jt.id = emp.job_title "
        f"WHERE 1=1 {where} "
        f"ORDER BY {sort_col} {sa} LIMIT %s OFFSET %s"
    )
    params_count = list(params)
    params.extend([rc, offset])

    sql2 = (
        f"SELECT count(*) FROM emp_salary s "
        f"JOIN employees emp ON emp.id = s.employee "
        f"WHERE 1=1 {where}"
    )

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)

    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(7003)
def get_salary_details():
    employee_id = request.args(0)
    if not employee_id:
        return response.json(api.api_ok(data=[]))

    sql = (
        "SELECT sd.id, sd.employee, sd.allowance_deduction, sd.amount, sd.notes, "
        "ad.name AS ad_name, ad.ad_type "
        "FROM emp_salary_detail sd "
        "JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        "WHERE sd.employee = %s "
        "ORDER BY ad.ad_type, ad.name"
    )
    qry = db.executesql(sql, placeholders=[employee_id], as_dict=True)
    return response.json(api.api_ok(data=qry))


@can_access(7003)
def get_salary_card():
    """بطاقة راتب الموظف: بياناته، الأساسي، البدلات والخصومات ومجاميعها، وتنبيهات قسط السلفة."""
    import advance_ledger

    employee_id = _valid_employee_id(request.args(0))
    if not employee_id:
        return response.json(api.api_error(mess="الموظف غير موجود"))
    emp = db.executesql(
        "SELECT e.id, e.emp_name, e.id_number, e.mobile, "
        "jt.name AS job_title_name, n.name AS nationality_name, st.name AS status_name, "
        "s.id AS salary_id, COALESCE(s.basic_salary, 0) AS basic_salary, s.modified_on "
        "FROM employees e "
        "LEFT JOIN emp_salary s ON s.employee = e.id "
        "LEFT JOIN key_job_titles jt ON jt.id = e.job_title "
        "LEFT JOIN key_nationalities n ON n.id = e.nationality "
        "LEFT JOIN key_emp_status st ON st.id = e.emp_status "
        "WHERE e.id = %s", placeholders=[employee_id], as_dict=True)[0]
    if not emp["salary_id"]:
        return response.json(api.api_error(mess="لا يوجد راتب مسجل لهذا الموظف"))

    items = db.executesql(
        "SELECT sd.id, sd.allowance_deduction, COALESCE(sd.amount, 0) AS amount, "
        "COALESCE(sd.notes, '') AS notes, sd.modified_on, ad.name AS ad_name, ad.ad_type "
        "FROM emp_salary_detail sd "
        "JOIN key_allowance_deduction ad ON ad.id = sd.allowance_deduction "
        "WHERE sd.employee = %s ORDER BY ad.name, sd.id",
        placeholders=[employee_id], as_dict=True)
    basic = round(float(emp["basic_salary"]), 2)
    allowances = round(sum(float(i["amount"]) for i in items if i["ad_type"] == "بدل"), 2)
    deductions = round(sum(float(i["amount"]) for i in items if i["ad_type"] == "خصم"), 2)
    net = round(basic + allowances - deductions, 2)
    updated = max([d for d in [emp["modified_on"]] + [i["modified_on"] for i in items] if d] or [None])

    # قسط «خصم سلفة» يُنسخ إلى المسير ويُخصم من السلف المفتوحة عند اعتماده (advance_ledger)
    deduction_id = advance_ledger.deduction_item_id(db)
    installment = round(sum(float(i["amount"]) for i in items
                            if deduction_id and i["allowance_deduction"] == deduction_id), 2)
    remaining = round(float(db.executesql(
        "SELECT COALESCE(SUM(COALESCE(amount, 0) - COALESCE(paid_amount, 0)), 0) FROM emp_advances "
        "WHERE employee = %s AND COALESCE(is_closed, 'F') <> 'T' "
        "AND COALESCE(amount, 0) - COALESCE(paid_amount, 0) > 0.005",
        placeholders=[employee_id])[0][0] or 0), 2)

    alerts = []
    if basic <= 0:
        alerts.append({"level": "warn", "text": "الراتب الأساسي صفر"})
    if net < 0:
        alerts.append({"level": "warn", "text": "الخصومات أكبر من الراتب، فالصافي سالب"})
    if remaining > 0 and installment <= 0:
        alerts.append({"level": "warn", "text": "عليه سلف متبقية %.2f ريال ولا يوجد بند «خصم سلفة»، "
                                                "فلن تُخصم من المسير تلقائياً" % remaining})
    elif remaining > 0:
        months = int(-(-remaining // installment))
        alerts.append({"level": "info", "text": "عليه سلف متبقية %.2f ريال، تُخصم بقسط %.2f شهرياً (%d %s)"
                       % (remaining, installment, months, "شهر" if months == 1 else "أشهر")})
        if installment > remaining + 0.005:
            alerts.append({"level": "warn", "text": "قسط «خصم سلفة» أكبر من المتبقي على السلف"})
    elif installment > 0:
        alerts.append({"level": "warn", "text": "يوجد بند «خصم سلفة» ولا توجد سلفة مفتوحة عليه"})

    for i in items:
        i.pop("modified_on", None)
        i["amount"] = round(float(i["amount"]), 2)
    return response.json(api.api_ok(data={
        "employee": {k: emp[k] for k in ("id", "emp_name", "id_number", "mobile", "job_title_name",
                                         "nationality_name", "status_name")},
        "salary_id": emp["salary_id"],
        "basic_salary": basic,
        "total_allowances": allowances,
        "total_deductions": deductions,
        "net_salary": net,
        "updated_on": updated.strftime("%Y-%m-%d") if updated else None,
        "items": items,
        "alerts": alerts,
    }))


@can_access(7003)
def save_salary():
    _post_only()
    try:
        data = request.vars
        employee_id = _valid_employee_id(data.employee)
        if not employee_id:
            return response.json(api.api_error(mess="الموظف مطلوب"))
        try:
            basic_salary = float(data.basic_salary or 0)
        except (TypeError, ValueError):
            basic_salary = -1
        if basic_salary < 0:
            return response.json(api.api_error(mess="الراتب الأساسي لا يمكن أن يكون سالباً"))

        # upsert
        existing = db(db.emp_salary.employee == employee_id).select().first()
        if existing:
            existing.update_record(basic_salary=basic_salary)
            sid = existing.id
        else:
            sid = db.emp_salary.insert(
                employee=employee_id,
                basic_salary=basic_salary,
            )
        db.commit()
        return response.json(api.api_ok(data={"id": sid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7003)
def add_detail():
    _post_only()
    try:
        data = request.vars
        employee_id = _valid_employee_id(data.employee)
        if not employee_id:
            return response.json(api.api_error(mess="الموظف مطلوب"))
        allowance_deduction = _valid_allowance_deduction_id(data.allowance_deduction)
        if not allowance_deduction:
            return response.json(api.api_error(mess="البدل/الخصم مطلوب"))
        try:
            amount = float(data.amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        nid = db.emp_salary_detail.insert(
            employee=employee_id,
            allowance_deduction=allowance_deduction,
            amount=amount,
            notes=data.notes or '',
        )
        db.commit()
        return response.json(api.api_ok(data={"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7003)
def update_detail():
    _post_only()
    try:
        data = request.vars
        row = db.emp_salary_detail[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        allowance_deduction = _valid_allowance_deduction_id(data.allowance_deduction)
        if not allowance_deduction:
            return response.json(api.api_error(mess="البدل/الخصم مطلوب"))
        try:
            amount = float(data.amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return response.json(api.api_error(mess="المبلغ يجب أن يكون أكبر من صفر"))
        row.update_record(
            allowance_deduction=allowance_deduction,
            amount=amount,
            notes=data.notes or '',
        )
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7003)
def delete_detail():
    _post_only()
    try:
        row = db.emp_salary_detail[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@can_access(7003)
def delete_salary():
    _post_only()
    try:
        row = db.emp_salary[request.args(0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        # حذف التفاصيل أولاً
        db(db.emp_salary_detail.employee == row.employee).delete()
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))
