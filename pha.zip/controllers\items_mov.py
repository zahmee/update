# -*- coding: utf-8 -*-
#  type: ignore

from datetime import datetime


@can_access(3007)
def index():
    return dict()


def search_item():
    """بحث عن صنف بالاسم أو الرقم"""
    search = request.vars.q or ""
    if not search:
        return response.json([])
    srh = search.strip().split()
    if len(srh) == 1:
        qry = (
            "select id, item_id, name from items_main"
            " where LOWER(name) like %s or item_id like %s"
            " order by name asc limit 10"
        )
        term = '%' + search.lower() + '%'
        data = db.executesql(qry, placeholders=[term, term], as_dict=True)
    elif len(srh) >= 2:
        qry = (
            "select id, item_id, name from items_main"
            " where LOWER(name) like %s and LOWER(name) like %s"
            " order by name asc limit 10"
        )
        data = db.executesql(qry, placeholders=[
            '%' + srh[0].lower() + '%',
            '%' + srh[1].lower() + '%',
        ], as_dict=True)
    else:
        data = []
    return response.json(data)


def summary():
    """API: ملخص حركة صنف (مجاميع فقط بدون تفاصيل)"""
    item_id = request.vars.item_id
    if not item_id:
        return response.json({"error": "يجب تحديد الصنف"})
    try:
        item_id = int(item_id)
    except (ValueError, TypeError):
        return response.json({"error": "رقم صنف غير صحيح"})

    item = db.items_main(item_id)
    if not item:
        return response.json({"error": "الصنف غير موجود"})

    # مجاميع من جدول الحركات
    row = db.executesql(
        "SELECT"
        " COALESCE(SUM(qty_in), 0)::double precision as total_in,"
        " COALESCE(SUM(qty_out), 0)::double precision as total_out,"
        " COALESCE(SUM(qty_in) - SUM(qty_out), 0)::double precision as balance,"
        " COUNT(*) as move_count"
        " FROM items_movement WHERE item_main = %s",
        placeholders=[item_id], as_dict=True
    )[0]

    # مجاميع حسب نوع الحركة
    by_type = db.executesql(
        "SELECT move_type,"
        " COALESCE(SUM(qty_in), 0)::double precision as total_in,"
        " COALESCE(SUM(qty_out), 0)::double precision as total_out,"
        " COUNT(*) as cnt"
        " FROM items_movement WHERE item_main = %s"
        " GROUP BY move_type ORDER BY move_type",
        placeholders=[item_id], as_dict=True
    )

    return response.json({
        "item_info": {
            "id": item.id,
            "item_id": item.item_id,
            "name": item.name,
            "public_price": float(item.public_price or 0),
        },
        "summary": {
            "total_in": float(row["total_in"]),
            "total_out": float(row["total_out"]),
            "balance": float(row["balance"]),
            "move_count": int(row["move_count"]),
        },
        "by_type": [
            {
                "move_type": r["move_type"],
                "total_in": float(r["total_in"]),
                "total_out": float(r["total_out"]),
                "count": int(r["cnt"]),
            }
            for r in by_type
        ],
    })


def movements():
    """API: تفاصيل الحركات مع ترقيم صفحات"""
    item_id = request.vars.item_id
    if not item_id:
        return response.json({"error": "يجب تحديد الصنف"})
    try:
        item_id = int(item_id)
    except (ValueError, TypeError):
        return response.json({"error": "رقم صنف غير صحيح"})

    page = int(request.vars.page or 1)
    page_size = int(request.vars.page_size or 50)
    move_type = request.vars.move_type or ""
    date_from = request.vars.date_from or None
    date_to = request.vars.date_to or None

    # بناء الاستعلام
    conditions = ["item_main = %s"]
    params = [item_id]

    if move_type:
        conditions.append("move_type = %s")
        params.append(move_type)
    if date_from:
        conditions.append("move_date >= %s::timestamp")
        params.append(str(date_from) + ' 00:00:00')
    if date_to:
        conditions.append("move_date <= %s::timestamp")
        params.append(str(date_to) + ' 23:59:59')

    where = " AND ".join(conditions)

    # عدد الحركات
    count_row = db.executesql(
        "SELECT COUNT(*) as cnt FROM items_movement WHERE " + where,
        placeholders=params, as_dict=True
    )[0]
    total = int(count_row["cnt"])

    # جلب الحركات مرتبة تصاعدياً لحساب الرصيد التراكمي
    all_rows = db.executesql(
        "SELECT id, move_type, move_date, qty_in, qty_out,"
        " unit_price, reference, ref_no"
        " FROM items_movement WHERE " + where +
        " ORDER BY move_date ASC, id ASC",
        placeholders=params, as_dict=True
    )

    # حساب الرصيد التراكمي
    balance = 0
    movements_list = []
    for row in all_rows:
        qi = float(row["qty_in"] or 0)
        qo = float(row["qty_out"] or 0)
        balance += qi - qo
        movements_list.append({
            "id": row["id"],
            "move_type": row["move_type"],
            "move_date": str(row["move_date"])[:16] if row["move_date"] else "",
            "qty_in": qi,
            "qty_out": qo,
            "unit_price": float(row["unit_price"] or 0),
            "reference": row["reference"] or "",
            "ref_no": row["ref_no"] or "",
            "balance": round(balance, 2),
        })

    # عكس للعرض (الأحدث أولاً) ثم ترقيم الصفحات
    movements_list.reverse()
    start = (page - 1) * page_size
    page_data = movements_list[start:start + page_size]

    return response.json({
        "movements": page_data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size if total > 0 else 1,
    })


@auth.requires_membership("admin")
def init_balance():
    """إضافة رصيد افتتاحي لجميع الأصناف من الكميات الحالية"""

    # التحقق من عدم وجود رصيد افتتاحي سابق
    existing = db(db.items_movement.move_type == "رصيد افتتاحي").count()
    if existing > 0:
        return response.json({
            "status": "error",
            "message": "تم إضافة الرصيد الافتتاحي مسبقاً ({} صنف)".format(existing),
        })

    # جلب الكمية الحالية لكل صنف
    rows = db.executesql(
        "SELECT item_idr, SUM(items_count) as total_qty"
        " FROM items_det"
        " GROUP BY item_idr"
        " HAVING SUM(items_count) != 0",
        as_dict=True
    )

    now = datetime.now()
    count = 0
    for row in rows:
        qty = float(row["total_qty"] or 0)
        if qty == 0:
            continue
        db.items_movement.insert(
            item_main=row["item_idr"],
            item_det=0,
            move_type="رصيد افتتاحي",
            move_date=now,
            qty_in=qty if qty > 0 else 0,
            qty_out=abs(qty) if qty < 0 else 0,
            unit_price=0,
            reference="رصيد افتتاحي",
            ref_no="",
        )
        count += 1

    db.commit()

    return response.json({
        "status": "success",
        "message": "تم إضافة الرصيد الافتتاحي لـ {} صنف".format(count),
        "count": count,
    })
