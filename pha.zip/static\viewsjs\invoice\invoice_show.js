(function () {
    var urls = window.INVOICE_SHOW_URLS || {};

    new Vue({
        el: '#app',
        data: {
            urls: {
                list: urls.list || '',
                newInvoice: urls.newInvoice || '#'
            },
            data: [],
            data_row_count: 0,
            loading: false,
            selectedRow: -1,
            edit_row_data: {},
            zatcaLoading: false,
            zatcaPayload: '',
            getData: {
                page: 0,
                RecordCount: 20,
                SearchText: '',
                ZatcaStatus: 'all',
                SortBy: 'id',
                sequence: false
            },
            totals: {
                pageNet: 0,
                pageVat: 0,
                pageSent: 0
            }
        },
        computed: {
            currentPage: function () {
                return Number(this.getData.page || 0);
            },
            totalPages: function () {
                var pages = Math.ceil(Number(this.data_row_count || 0) / Number(this.getData.RecordCount || 20));
                return pages > 0 ? pages : 1;
            },
            pageNet: function () {
                return this.totals.pageNet;
            },
            pageVat: function () {
                return this.totals.pageVat;
            },
            pageSent: function () {
                return this.totals.pageSent;
            },
            visiblePages: function () {
                var pages = [];
                var total = this.totalPages;
                var current = this.currentPage;
                var start = Math.max(0, current - 2);
                var end = Math.min(total - 1, current + 2);

                if (current < 2) {
                    end = Math.min(total - 1, 4);
                }
                if (current > total - 3) {
                    start = Math.max(0, total - 5);
                }

                for (var i = start; i <= end; i += 1) {
                    pages.push(i);
                }
                return pages;
            }
        },
        mounted: function () {
            this.loadList();
        },
        methods: {
            buildUrl: function () {
                var params = new URLSearchParams();
                params.set('page', this.getData.page);
                params.set('RecordCount', this.getData.RecordCount);
                params.set('SearchText', this.getData.SearchText || '');
                params.set('ZatcaStatus', this.getData.ZatcaStatus || 'all');
                params.set('SortBy', this.getData.SortBy || 'id');
                params.set('sequence', this.getData.sequence ? 'true' : 'false');
                return this.urls.list + '?' + params.toString();
            },
            loadList: function () {
                var self = this;
                self.loading = true;
                self.selectedRow = -1;
                self.edit_row_data = {};

                Api.get(self.buildUrl()).then(function (response) {
                    if (Api.isOk(response)) {
                        self.data = Api.getData(response) || [];
                        self.data_row_count = Number(response.count || 0);
                        self.totals.pageNet = Number(response.page_net || 0);
                        self.totals.pageVat = Number(response.page_vat || 0);
                        self.totals.pageSent = Number(response.page_sent || 0);
                    } else {
                        Api.showError(response);
                    }
                    self.loading = false;
                });
            },
            applyFilters: function () {
                this.getData.page = 0;
                this.loadList();
            },
            sortBy: function (field) {
                if (this.getData.SortBy === field) {
                    this.getData.sequence = !this.getData.sequence;
                } else {
                    this.getData.SortBy = field;
                    this.getData.sequence = true;
                }
                this.getData.page = 0;
                this.loadList();
            },
            sortIcon: function (field) {
                if (this.getData.SortBy !== field) {
                    return 'fal fa-sort text-muted';
                }
                return this.getData.sequence ? 'fal fa-sort-up' : 'fal fa-sort-down';
            },
            goToPage: function (page) {
                if (page < 0 || page >= this.totalPages || page === this.currentPage) {
                    return;
                }
                this.getData.page = page;
                this.loadList();
            },
            rowSelect: function (index, row) {
                this.selectedRow = index;
                this.edit_row_data = Object.assign({}, row);
            },
            cancel_data: function () {
                this.selectedRow = -1;
                this.edit_row_data = {};
            },
            printInvoice: function (row) {
                if (!row || !row.print_url) {
                    return;
                }
                window.open(row.print_url, '_blank');
            },
            showZatca: function (row) {
                var self = this;
                if (!row || !row.zatca_status_url) {
                    return;
                }
                self.zatcaPayload = '';
                self.zatcaLoading = true;
                self.openZatcaModal();

                Api.get(row.zatca_status_url).then(function (response) {
                    if (Api.isOk(response)) {
                        self.zatcaPayload = JSON.stringify(Api.getData(response), null, 2);
                    } else {
                        self.zatcaPayload = Api.getError(response);
                    }
                    self.zatcaLoading = false;
                });
            },
            openZatcaModal: function () {
                var modalEl = document.getElementById('zatcaStatusModal');
                if (!modalEl) {
                    return;
                }
                if (window.bootstrap && window.bootstrap.Modal) {
                    window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
                } else if (window.jQuery && jQuery.fn.modal) {
                    jQuery(modalEl).modal('show');
                }
            },
            formatNum: function (value) {
                return Number(value || 0).toLocaleString('en-US', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 2
                });
            },
            statusLabel: function (row) {
                return row && row.send_to_zatca ? 'مرسل' : 'غير مرسل';
            }
        }
    });
})();
