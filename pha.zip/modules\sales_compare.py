# -*- coding: utf-8 -*-
"""مقارنة المبيعات الشهرية بين السنوات (invoice_rep/rep13).

مصدر واحد للشاشة وتصدير إكسل: استعلامان مجمّعان (الفواتير والمرتجعات حسب السنة والشهر)
ثم build() دالة نقية تبني الجدول (الأشهر × السنوات) ونسب النمو.

قواعد المقارنة:
- نمو الشهر = قيمته ÷ قيمة الشهر نفسه في السنة السابقة − 1.
- الشهر الجاري ناقص، فيقارَن «حتى تاريخه» بالفترة نفسها من السنة السابقة (اليوم والساعة نفسها).
- نمو السنة يُحسب على الأشهر المشتركة فقط (التي فيها مبيعات في السنتين)، فالسنة الجارية تقارَن
  حتى تاريخه، وسنة بداية البيانات الناقصة لا تضخّم نمو السنة التي تليها.
- الضريبة: عمود vat في invoice_master لا يُسجَّل قبل أغسطس 2019، وفيه قيم تالفة (ضريبة أكبر من
  الفاتورة) تُستبعد. «قبل الضريبة» يطرحها من الإجمالي.
"""

import io
from datetime import datetime

MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
          "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]

MEASURES = {
    "sales": "المبيعات",
    "net": "صافي المبيعات بعد المرتجعات",
    "returns": "المرتجعات",
    "count": "عدد الفواتير",
    "avg": "متوسط الفاتورة",
}
MONEY_MEASURES = ("sales", "net", "returns", "avg")

_VAT = "CASE WHEN vat > 0 AND vat < total_after_discount THEN vat ELSE 0 END"
_TO_DATE = ("(EXTRACT(MONTH FROM created_on), EXTRACT(DAY FROM created_on), created_on::time)"
            " <= (%s, %s, %s)")
_SQL = """
    SELECT EXTRACT(YEAR FROM created_on)::int AS y,
           EXTRACT(MONTH FROM created_on)::int AS m,
           COUNT(*) AS cnt,
           COALESCE(SUM(total_after_discount), 0) AS amount,
           COALESCE(SUM({vat}), 0) AS vat,
           COUNT(*) FILTER (WHERE {td}) AS cnt_td,
           COALESCE(SUM(total_after_discount) FILTER (WHERE {td}), 0) AS amount_td,
           COALESCE(SUM({vat}) FILTER (WHERE {td}), 0) AS vat_td
    FROM {table}
    WHERE created_on >= %s AND created_on < %s
    GROUP BY 1, 2
"""


def year_bounds(db):
    """أول وآخر سنة فيها فواتير بيع، أو None عند خلو الجدول."""
    row = db.executesql("SELECT MIN(created_on), MAX(created_on) FROM invoice_master")[0]
    if not row[0]:
        return None
    return row[0], row[1]


def fetch(db, y_from, y_to, now):
    """المجاميع الخام لكل (سنة، شهر) من y_from-1 (أساس نمو أول سنة) إلى y_to."""
    start = datetime(y_from - 1, 1, 1)
    end = datetime(y_to + 1, 1, 1)
    td = [now.month, now.day, now.time()]
    out = {}
    for key, table in (("sales", "invoice_master"), ("ret", "inv_return_master")):
        sql = _SQL.format(vat=_VAT, td=_TO_DATE, table=table)
        # ثلاث مرات td في SELECT (cnt_td, amount_td, vat_td) ثم حدود الفترة
        rows = db.executesql(sql, placeholders=td * 3 + [start, end], as_dict=True)
        out[key] = rows
    return out


def _blank():
    return {"cnt": 0, "amount": 0.0, "vat": 0.0, "ret": 0.0, "ret_vat": 0.0}


def _components(raw):
    """{(y, m): {"full": {...}, "td": {...}}} من صفوف الاستعلامين."""
    comp = {}
    for r in raw.get("sales", []):
        c = comp.setdefault((int(r["y"]), int(r["m"])), {"full": _blank(), "td": _blank()})
        c["full"]["cnt"] = int(r["cnt"] or 0)
        c["full"]["amount"] = float(r["amount"] or 0)
        c["full"]["vat"] = float(r["vat"] or 0)
        c["td"]["cnt"] = int(r["cnt_td"] or 0)
        c["td"]["amount"] = float(r["amount_td"] or 0)
        c["td"]["vat"] = float(r["vat_td"] or 0)
    for r in raw.get("ret", []):
        c = comp.setdefault((int(r["y"]), int(r["m"])), {"full": _blank(), "td": _blank()})
        c["full"]["ret"] = float(r["amount"] or 0)
        c["full"]["ret_vat"] = float(r["vat"] or 0)
        c["td"]["ret"] = float(r["amount_td"] or 0)
        c["td"]["ret_vat"] = float(r["vat_td"] or 0)
    return comp


def _add(a, b):
    return {k: a[k] + b[k] for k in a}


def value(c, measure, ex_vat):
    """قيمة المقياس من المجاميع؛ None حين لا معنى لها (متوسط بلا فواتير)."""
    sales = c["amount"] - (c["vat"] if ex_vat else 0)
    ret = c["ret"] - (c["ret_vat"] if ex_vat else 0)
    if measure == "sales":
        return sales
    if measure == "returns":
        return ret
    if measure == "net":
        return sales - ret
    if measure == "count":
        return c["cnt"]
    if measure == "avg":
        return sales / c["cnt"] if c["cnt"] else None
    raise ValueError(measure)


def growth(cur, prev):
    """نسبة التغير %؛ None حين لا أساس للمقارنة."""
    if cur is None or prev is None or prev <= 0:
        return None
    return round((cur / prev - 1) * 100, 1)


def _r(v, measure):
    if v is None:
        return None
    return int(v) if measure == "count" else round(v, 2)


def build(raw, now, y_from, y_to, measure="sales", ex_vat=False):
    """الجدول: صف لكل شهر، عمود لكل سنة، وصف إجمالي ومتوسط شهري لكل سنة."""
    if measure not in MEASURES:
        measure = "sales"
    comp = _components(raw)
    years = list(range(y_from, y_to + 1))

    def has(y, m):
        c = comp.get((y, m))
        return bool(c and c["full"]["cnt"])

    def partial(y, m):
        return y == now.year and m == now.month

    rows = []
    for m in range(1, 13):
        cells = []
        for y in years:
            if not has(y, m):
                cells.append({"y": y, "v": None, "g": None, "partial": False})
                continue
            c = comp[(y, m)]
            v = value(c["full"], measure, ex_vat)
            g = None
            if has(y - 1, m):
                p = comp[(y - 1, m)]
                key = "td" if partial(y, m) else "full"
                g = growth(value(c[key], measure, ex_vat), value(p[key], measure, ex_vat))
            cells.append({"y": y, "v": _r(v, measure), "g": g, "partial": partial(y, m)})
        rows.append({"m": m, "name": MONTHS[m - 1], "cells": cells})

    totals = []
    for y in years:
        full = _blank()
        months = 0
        cur_cmp, prev_cmp = _blank(), _blank()
        shared = 0
        for m in range(1, 13):
            if not has(y, m):
                continue
            months += 1
            full = _add(full, comp[(y, m)]["full"])
            if has(y - 1, m):
                key = "td" if partial(y, m) else "full"
                cur_cmp = _add(cur_cmp, comp[(y, m)][key])
                prev_cmp = _add(prev_cmp, comp[(y - 1, m)][key])
                shared += 1
        total = value(full, measure, ex_vat) if months else None
        # متوسط الشهر لا معنى له لمقياس هو متوسط أصلاً
        avg_month = total / months if total is not None and measure != "avg" else None
        is_current = y == now.year
        totals.append({
            "y": y,
            "v": _r(total, measure),
            "g": growth(value(cur_cmp, measure, ex_vat), value(prev_cmp, measure, ex_vat)) if shared else None,
            "months": months,
            "shared": shared,
            # السنة لا تُعدّ كاملة إن كانت جارية أو ناقصة الأشهر (بداية البيانات)
            "complete": months == 12 and not is_current,
            "current": is_current,
            "avg_month": round(avg_month, 2) if avg_month is not None else None,
        })

    complete = [t for t in totals if t["complete"] and t["v"] is not None]
    best = max(complete, key=lambda t: t["v"]) if complete else None
    return {
        "measure": measure,
        "measure_name": MEASURES[measure],
        "money": measure in MONEY_MEASURES,
        "ex_vat": bool(ex_vat),
        "years": years,
        "rows": rows,
        "totals": totals,
        "best_year": best["y"] if best else None,
        "now": {"year": now.year, "month": now.month, "day": now.day,
                "text": now.strftime("%Y-%m-%d %H:%M")},
    }


def workbook(result):
    """ملف إكسل بالجدول نفسه: لكل سنة عمودا القيمة والنمو."""
    import xlsxwriter

    buf = io.BytesIO()
    wb = xlsxwriter.Workbook(buf, {"in_memory": True})
    ws = wb.add_worksheet("مقارنة شهرية")
    ws.right_to_left()

    num = "#,##0" if result["measure"] == "count" else "#,##0.00"
    base = {"font_name": "Arial", "font_size": 10, "border": 1, "valign": "vcenter"}
    f_title = wb.add_format({"bold": True, "font_size": 14, "font_name": "Arial"})
    f_sub = wb.add_format({"font_size": 9, "font_color": "#667085", "font_name": "Arial"})
    f_head = wb.add_format(dict(base, bold=True, bg_color="#134e4a", font_color="#ffffff", align="center"))
    f_month = wb.add_format(dict(base, bold=True, bg_color="#f3f7f8"))
    f_val = wb.add_format(dict(base, num_format=num))
    f_val_p = wb.add_format(dict(base, num_format=num, italic=True, bg_color="#fff8e6"))
    f_pct = wb.add_format(dict(base, num_format="+0.0%;-0.0%;0.0%", align="center"))
    f_pct_p = wb.add_format(dict(base, num_format="+0.0%;-0.0%;0.0%", align="center", italic=True,
                                 bg_color="#fff8e6"))
    f_tot = wb.add_format(dict(base, bold=True, num_format=num, bg_color="#fef3c7"))
    f_tot_pct = wb.add_format(dict(base, bold=True, num_format="+0.0%;-0.0%;0.0%", align="center",
                                   bg_color="#fef3c7"))
    f_tot_label = wb.add_format(dict(base, bold=True, bg_color="#fef3c7"))
    f_empty = wb.add_format(dict(base, font_color="#98a2b3", align="center"))

    years = result["years"]
    last_col = len(years) * 2
    ws.write(0, 0, "مقارنة %s الشهرية بين السنوات" % result["measure_name"], f_title)
    vat_txt = "قبل الضريبة" if result["ex_vat"] else "شاملة الضريبة"
    ws.write(1, 0, "%s — بيانات حتى %s" % (vat_txt if result["money"] else "عدد", result["now"]["text"]), f_sub)

    ws.merge_range(3, 0, 4, 0, "الشهر", f_head)
    for i, y in enumerate(years):
        ws.merge_range(3, 1 + i * 2, 3, 2 + i * 2, str(y), f_head)
        ws.write(4, 1 + i * 2, "القيمة", f_head)
        ws.write(4, 2 + i * 2, "النمو", f_head)

    def put(row, col, cell, fv, fp):
        if cell["v"] is None:
            ws.write(row, col, "—", f_empty)
        else:
            ws.write_number(row, col, cell["v"], fv)
        if cell["g"] is None:
            ws.write(row, col + 1, "—", f_empty)
        else:
            ws.write_number(row, col + 1, cell["g"] / 100.0, fp)

    for r, mrow in enumerate(result["rows"]):
        row = 5 + r
        ws.write_string(row, 0, mrow["name"], f_month)
        for i, cell in enumerate(mrow["cells"]):
            p = cell["partial"]
            put(row, 1 + i * 2, cell, f_val_p if p else f_val, f_pct_p if p else f_pct)

    tot_row = 5 + 12
    ws.write_string(tot_row, 0, "الإجمالي", f_tot_label)
    for i, t in enumerate(result["totals"]):
        put(tot_row, 1 + i * 2, t, f_tot, f_tot_pct)
    if result["measure"] != "avg":
        ws.write_string(tot_row + 1, 0, "متوسط الشهر", f_month)
        for i, t in enumerate(result["totals"]):
            if t["avg_month"] is None:
                ws.write(tot_row + 1, 1 + i * 2, "—", f_empty)
            else:
                ws.write_number(tot_row + 1, 1 + i * 2, t["avg_month"], f_val)
            ws.write(tot_row + 1, 2 + i * 2, "", f_empty)

    green = wb.add_format({"font_color": "#067647"})
    red = wb.add_format({"font_color": "#b42318"})
    for i in range(len(years)):
        col = 2 + i * 2
        ws.conditional_format(5, col, tot_row, col, {"type": "cell", "criteria": ">", "value": 0, "format": green})
        ws.conditional_format(5, col, tot_row, col, {"type": "cell", "criteria": "<", "value": 0, "format": red})

    note = tot_row + 3
    ws.write(note, 0, "النمو مقارنةً بالشهر نفسه من السنة السابقة. الخلايا المائلة: شهر جارٍ يقارَن حتى تاريخه "
                      "بالفترة نفسها من السنة السابقة.", f_sub)
    ws.write(note + 1, 0, "نمو الإجمالي محسوب على الأشهر المشتركة بين السنتين فقط، فالسنة الجارية تقارَن حتى تاريخه.",
             f_sub)
    if result["ex_vat"]:
        ws.write(note + 2, 0, "الضريبة غير مسجلة في الفواتير قبل أغسطس 2019، فأرقام ما قبلها شاملة.", f_sub)

    ws.set_column(0, 0, 14)
    for i in range(len(years)):
        ws.set_column(1 + i * 2, 1 + i * 2, 13)
        ws.set_column(2 + i * 2, 2 + i * 2, 8)
    ws.freeze_panes(5, 1)
    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 1)
    ws.print_area(0, 0, note + 2, last_col)
    wb.close()
    return buf.getvalue()
