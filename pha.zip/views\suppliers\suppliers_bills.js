Vue.component('v-select', VueSelect.VueSelect);

var APP_BASE = window.location.origin + window.location.pathname.replace(/\/suppliers\/suppliers_bills\/?$/, '');
var API_BASE = APP_BASE + '/suppliers_api/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        day_date: { day: 1, month: 1, year: 2019 },
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false
        },
        data_row_count: 0,
        coding: {
            supplier: [],
            Allsupplier: [],
            types: [],
            units: [],
            payment_method: []
        },
        select_obj_2: 0,
        select_conf: '',
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        loading: false,
    },
    created: function() {
        this.loading = true;
        this.fetchData().then(function(data) {
            this.data = Api.getData(data);
            this.data_row_count = data.count;
        }.bind(this)).finally(function() { this.loading = false; }.bind(this));

        fetch(APP_BASE + '/api_1/min_suppliers_1')
            .then(function(r) { return r.json(); })
            .then(function(resp) {
                var data = Api.getData(resp);
                this.coding.supplier = data;
                this.coding.Allsupplier = data;
                data.forEach(function(el) {
                    this.options.push({ value: el.id, label: '[' + el.id + '] - ' + el.name });
                }.bind(this));
            }.bind(this));

        fetch(API_BASE + 'get_invoce_type')
            .then(function(r) { return r.json(); })
            .then(function(data) { this.coding.types = Api.getData(data); }.bind(this));

        fetch(APP_BASE + '/suppliers_bills_api/get_payment_method')
            .then(function(r) { return r.json(); })
            .then(function(data) { this.coding.payment_method = Api.getData(data); }.bind(this));
    },
    computed: {
        total_no_vat: function() {
            if (parseFloat(this.edit_row_data.bill_total) > 0 && parseFloat(this.edit_row_data.bill_vat) > -1) {
                return (parseFloat(this.edit_row_data.bill_total) - parseFloat(this.edit_row_data.bill_vat)).toFixed(2);
            }
            return 0;
        },
        totalPages: function() {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function() {
            return this.getData.page + 1;
        },
        visiblePages: function() {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function() {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                types: this.select_obj_2,
                confirmation: this.select_conf,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc
            };
            if (this.value && this.value.value) {
                params.supplier = this.value.value;
            }
            var url = new URL(API_BASE + 'getSuppInvoce');
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); });
        },
        onChange: function() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        goToPage: function(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function(data) {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
            }.bind(this)).finally(function() { this.loading = false; }.bind(this));
        },
        sortBy: function(field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
            var sup = {};
            this.options.forEach(function(el) {
                if (el.value === row.supplier) sup = el;
            });
            this.edit_row_data.suppliers = sup;
        },
        on_change_select: function() {
            this.$forceUpdate();
        },
        edit_row: function() {
            this.new_row = false;
            var today = new Date(this.edit_row_data.bill_date);
            this.day_date.year = today.getFullYear();
            this.day_date.month = today.getMonth() + 1;
            this.day_date.day = today.getDate();
        },
        new_row_click: function() {
            this.new_row = true;
            var today = new Date();
            this.day_date.year = today.getFullYear();
            this.day_date.month = today.getMonth() + 1;
            this.day_date.day = today.getDate();
            this.edit_row_data = { suppliers: { value: '', label: '' } };
        },
        chk_date: function() {
            var today = new Date();
            if (this.day_date.day > 31 || this.day_date.day < 1) this.day_date.day = today.getDate();
            if (this.day_date.month > 12 || this.day_date.month < 1) this.day_date.month = today.getMonth() + 1;
            if (this.day_date.year > 2030 || this.day_date.year < 2020) this.day_date.year = today.getFullYear();
        },
        save_data: function() {
            var billTotal = parseFloat(this.edit_row_data.bill_total || 0);
            var billVat = parseFloat(this.edit_row_data.bill_vat || 0);
            var dateValue = new Date(this.day_date.year, this.day_date.month - 1, this.day_date.day);
            var now = new Date();
            now.setHours(0, 0, 0, 0);
            if (!this.edit_row_data.payment_method || !this.edit_row_data.invoce_type || !this.day_date.year || !this.day_date.month ||
                !this.edit_row_data.bill_no || !this.edit_row_data.suppliers.value || !this.day_date.day) {
                Swal.fire('تنبية', 'يجب إدخال كافة الحقول الأساسية.', 'error');
                return;
            }
            if (this.day_date.month < 1 || this.day_date.month > 12 || this.day_date.day < 1 || this.day_date.day > 31 || isNaN(dateValue.getTime()) || dateValue > now) {
                Swal.fire('تنبية', 'تاريخ الفاتورة غير صحيح أو مستقبلي.', 'error');
                return;
            }
            var typeName = '';
            this.coding.types.forEach(function(t) {
                if (Number(t.id) === Number(this.edit_row_data.invoce_type)) typeName = t.name;
            }.bind(this));
            var zeroTotalAllowed = (typeName === 'تعويض' || typeName === 'هدايا');
            if (isNaN(billTotal) || billTotal < 0 || (billTotal === 0 && !zeroTotalAllowed)) {
                Swal.fire('تنبية', 'إجمالي الفاتورة يجب أن يكون أكبر من صفر.', 'error');
                return;
            }
            if (isNaN(billVat) || billVat < 0 || billVat > billTotal) {
                Swal.fire('تنبية', 'ضريبة الفاتورة يجب ألا تكون سالبة أو أكبر من الإجمالي.', 'error');
                return;
            }
            // تثبيت القيم الرقمية (الحقل الفارغ يصبح صفراً فعلياً لا نصاً غير معرّف)
            this.edit_row_data.bill_total = billTotal;
            this.edit_row_data.bill_vat = billVat;
            var endpoint = this.new_row ? 'new_bill' : 'edit_bill';
            var url = new URL(API_BASE + endpoint);
            var params = this.edit_row_data;
            params.day = JSON.stringify(this.day_date);
            params.suppliers = JSON.stringify(this.edit_row_data.suppliers);
            Object.keys(params).forEach(function(k) { url.searchParams.append(k, params[k]); });
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function(r) { return r.json(); })
              .then(function(data) {
                if (Api.isOk(data)) {
                    var result = Api.getData(data);
                    this.edit_row_data.id = result.id;
                    this.coding.types.forEach(function(row) {
                        if (row.id === this.edit_row_data.invoce_type) this.edit_row_data.t_name = row.name;
                    }.bind(this));
                    this.coding.supplier.forEach(function(row) {
                        if (row.id === result.supplier) this.edit_row_data.s_name = row.name;
                    }.bind(this));
                    this.edit_row_data.bill_date = this.new_row ? result.bill_date : result.bill_date.substring(0, 10);
                    if (this.new_row) {
                        this.edit_row_data.itm_r_count = 0;
                        this.edit_row_data.itm_count = 0;
                        this.edit_row_data.f_count = 0;
                        this.edit_row_data.bill_confirmation = 'F';
                        this.data.splice(0, 0, this.edit_row_data);
                    } else {
                        this.$set(this.data, this.selectedRow, { ...this.edit_row_data });
                    }
                    this.edit_row_data = {};
                    this.selectedRow = -1;
                    this.new_row = true;
                    bootstrap.Modal.getInstance(document.getElementById("exampleModal")).hide();
                    Swal.fire('عمل رائع', 'تمت عملية الحفظ بشكل صحيح', 'success');
                } else {
                    Api.showError(data);
                }
            }.bind(this));
        },
        cancel_data: function() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
        },
        invoce_print_report: function() {
            window.open(window.location.href + '/../../items/it_rep1/' + this.edit_row_data.id, '_blank');
        },
        invoce_barcode_print: function() {
            window.open(window.location.href + '/../../items/it_prt.svc/' + this.edit_row_data.id);
        },
        invoce_print_return: function() {
            window.open(window.location.href + '/../../suppliers/return_suppliers_bills_print/' + this.edit_row_data.id, '_blank');
        },
        invoce_print_sales: function() {
            window.open(window.location.href + '/../../items/it_rep2/' + this.edit_row_data.id, '_blank');
        },
        invoce_insert_items: function() {
            window.open(window.location.href + '/../../items/it_inv/' + this.edit_row_data.id, '_blank');
        },
        invoce_print_files: function() {
            window.open(window.location.href + '/../../suppliers/suppliers_bills_files/' + this.edit_row_data.id, '_blank');
        },
    },
    watch: {
        value: function() { this.onChange(); }
    }
});
