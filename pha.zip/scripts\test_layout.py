# -*- coding: utf-8 -*-
import sys
sys.stdout = open('applications/asbab5/scripts/test_layout_out.txt', 'w', encoding='utf-8')
sys.stderr = sys.stdout
try:
    # محاولة render layout.html
    from gluon.template import render
    content = open('applications/asbab5/views/layout.html', 'r', encoding='utf-8').read()
    # web2py template rendering يحتاج environment
    result = response.render('layout.html', {})
    print("Layout rendered successfully")
    print(result[:500])
except Exception as e:
    print("Error:", type(e).__name__, str(e))
sys.stdout.close()
