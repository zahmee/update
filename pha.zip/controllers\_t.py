# -*- coding: utf-8 -*-
#  type: ignore

import os
import subprocess
import shutil

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"


@auth.requires_login()
def fix():
    qry = ('PGPASSWORD=\'5445za\' psql -h localhost -U admin -d pha -c " GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to admin ; " ')
    s = os.popen(qry)
    preprocessed = s.read()
    s.close()
    return preprocessed

@auth.requires_login()
def db_backup():
    _appPath = request.folder
    backupdir=_appPath + '/static/db.tar'
    configuration = AppConfig(reload=True)
    dbname = configuration.get('db.uri').split("/")
    script = ("PGPASSWORD='5445za' pg_dump -h localhost -U admin -F t "+dbname[-1]+" >  %s" % (backupdir))
    s = os.popen(script)
    preprocessed = s.read()
    s.close()
    return redirect(URL('static','db.tar'))


def _get_local_version():
    """قراءة رقم النسخة المحلية من pha_ver.txt"""
    ver_file = os.path.join(request.folder, "pha_ver.txt")
    try:
        with open(ver_file, "r") as f:
            return f.read().strip()
    except Exception:
        return "0"


def _get_remote_version():
    """قراءة رقم النسخة المتوفرة على الخادم باستخدام curl"""
    url = UPDATE_BASE_URL + "pha_ver.txt"
    result = subprocess.run(
        ["curl", "-sL", "--max-time", "30", url],
        capture_output=True, text=True, timeout=40,
    )
    if result.returncode != 0:
        raise Exception("curl failed: " + (result.stderr or "unknown error"))
    ver = result.stdout.strip()
    if not ver:
        raise Exception("لم يتم الحصول على رقم النسخة من الخادم")
    return ver


@auth.requires_login()
def up():
    """صفحة التحديث — تعرض النسخة الحالية مع إمكانية التحقق والتحديث"""
    local_ver = _get_local_version()
    return dict(local_ver=local_ver)


@auth.requires_login()
def check_update():
    """API: التحقق من وجود تحديث جديد"""
    local_ver = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))
    has_update = (local_ver != remote_ver)
    return response.json(dict(
        status="ok",
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        message="يتوفر تحديث جديد: " + remote_ver if has_update else "النسخة الحالية هي الأحدث",
    ))


def _clear_pycache(app_path):
    """حذف جميع مجلدات __pycache__ في التطبيق"""
    for root, dirs, _files in os.walk(app_path):
        for d in dirs:
            if d == "__pycache__":
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)


@auth.requires_login()
def apply_update():
    """API: تنزيل التحديث وتثبيته باستخدام curl + tar"""
    _appPath = request.folder
    saved_file = os.path.join(_appPath, "pha.zip")
    local_ver = _get_local_version()

    # 1) التحقق من النسخة
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))

    if local_ver == remote_ver:
        return response.json(dict(
            status="up_to_date",
            message="النسخة الحالية ({}) هي الأحدث — لا حاجة للتحديث".format(local_ver),
        ))

    # 2) تنزيل ملف التحديث باستخدام curl
    download_url = UPDATE_BASE_URL + "pha.zip"
    try:
        result = subprocess.run(
            ["curl", "-L", "--max-time", "120", "-o", saved_file, download_url],
            capture_output=True, text=True, timeout=150,
        )
        if result.returncode != 0:
            raise Exception(result.stderr or "curl download failed")
        if not os.path.exists(saved_file) or os.path.getsize(saved_file) < 100:
            raise Exception("الملف الذي تم تنزيله فارغ أو غير مكتمل")
    except subprocess.TimeoutExpired:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="انتهت مهلة تنزيل ملف التحديث",
        ))
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="فشل تنزيل ملف التحديث: " + str(e),
        ))

    # 3) فك الضغط مباشرة في مجلد التطبيق
    try:
        if os.name == "nt":
            # Windows: PowerShell Expand-Archive
            ps_cmd = (
                "Expand-Archive -Path '{}' -DestinationPath '{}' -Force"
                .format(saved_file.replace("'", "''"), _appPath.replace("'", "''"))
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode != 0:
                raise Exception(result.stderr or "Expand-Archive failed")
        else:
            # Linux: Python zipfile (يتعامل مع backslashes في المسارات)
            import zipfile
            with zipfile.ZipFile(saved_file, "r") as zf:
                for info in zf.infolist():
                    # تحويل backslashes إلى forward slashes
                    info.filename = info.filename.replace("\\", "/")
                    zf.extract(info, _appPath)
    except subprocess.TimeoutExpired:
        return response.json(dict(
            status="error",
            message="انتهت مهلة فك ضغط ملف التحديث",
        ))
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل فك الضغط: " + str(e),
        ))
    finally:
        # تنظيف: حذف ملف ZIP
        if os.path.exists(saved_file):
            os.remove(saved_file)

    # 4) تنظيف __pycache__
    _clear_pycache(_appPath)

    # تقرير النتيجة
    new_ver = _get_local_version()
    msg = "تم التحديث بنجاح من {} إلى {}".format(local_ver, new_ver)

    return response.json(dict(
        status="success",
        old_ver=local_ver,
        new_ver=new_ver,
        message=msg,
    ))
