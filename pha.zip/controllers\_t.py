# -*- coding: utf-8 -*-
#  type: ignore

import os
import subprocess
import shutil
from urllib.parse import urlparse, unquote

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"


def _db_conn_info():
    """تحليل db.uri من appconfig.ini إلى مكوّنات الاتصال — بدون تضمين كلمة المرور."""
    parsed = urlparse(AppConfig(reload=True).get("db.uri"))
    return {
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
        "host": parsed.hostname or "localhost",
        "port": str(parsed.port or 5432),
        "dbname": (parsed.path or "/").lstrip("/"),
    }


@auth.requires_login()
def fix():
    info = _db_conn_info()
    grant_sql = (
        "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to {u}; "
        "GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to {u}; "
        "GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to {u};"
    ).format(u=info["user"])
    env = {**os.environ, "PGPASSWORD": info["password"]}
    result = subprocess.run(
        ["psql", "-h", info["host"], "-p", info["port"],
         "-U", info["user"], "-d", info["dbname"], "-c", grant_sql],
        env=env, capture_output=True, text=True,
    )
    return result.stdout + result.stderr


@auth.requires_login()
def db_backup():
    backupdir = os.path.join(request.folder, "static", "db.tar")
    info = _db_conn_info()
    env = {**os.environ, "PGPASSWORD": info["password"]}
    with open(backupdir, "wb") as out:
        result = subprocess.run(
            ["pg_dump", "-h", info["host"], "-p", info["port"],
             "-U", info["user"], "-F", "t", info["dbname"]],
            env=env, stdout=out, stderr=subprocess.PIPE,
        )
    if result.returncode != 0:
        return "فشل النسخ الاحتياطي: " + result.stderr.decode("utf-8", "replace")
    return redirect(URL('static', 'db.tar'))


def _get_local_version():
    """قراءة رقم النسخة المحلية من pha_ver.txt"""
    ver_file = os.path.join(request.folder, "pha_ver.txt")
    try:
        with open(ver_file, "r") as f:
            return f.read().strip()
    except Exception:
        return "0"


def _get_remote_version():
    """قراءة رقم النسخة المتوفرة على الخادم باستخدام curl"""
    url = UPDATE_BASE_URL + "pha_ver.txt"
    result = subprocess.run(
        ["curl", "-sL", "--max-time", "30", url],
        capture_output=True, text=True, timeout=40,
    )
    if result.returncode != 0:
        raise Exception("curl failed: " + (result.stderr or "unknown error"))
    ver = result.stdout.strip()
    if not ver:
        raise Exception("لم يتم الحصول على رقم النسخة من الخادم")
    return ver


@auth.requires_login()
def up():
    """صفحة التحديث — تعرض النسخة الحالية مع إمكانية التحقق والتحديث"""
    local_ver = _get_local_version()
    return dict(local_ver=local_ver)


@auth.requires_login()
def check_update():
    """API: التحقق من وجود تحديث جديد"""
    local_ver = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))
    has_update = (local_ver != remote_ver)
    return response.json(dict(
        status="ok",
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        message="يتوفر تحديث جديد: " + remote_ver if has_update else "النسخة الحالية هي الأحدث",
    ))


def _clear_pycache(app_path):
    """حذف جميع مجلدات __pycache__ في التطبيق"""
    for root, dirs, _files in os.walk(app_path):
        for d in dirs:
            if d == "__pycache__":
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)


@auth.requires_login()
def apply_update():
    """API: تنزيل التحديث وتثبيته باستخدام curl + tar"""
    _appPath = request.folder
    saved_file = os.path.join(_appPath, "pha.zip")
    local_ver = _get_local_version()

    # 1) التحقق من النسخة
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))

    if local_ver == remote_ver:
        return response.json(dict(
            status="up_to_date",
            message="النسخة الحالية ({}) هي الأحدث — لا حاجة للتحديث".format(local_ver),
        ))

    # 2) تنزيل ملف التحديث باستخدام curl
    download_url = UPDATE_BASE_URL + "pha.zip"
    try:
        result = subprocess.run(
            ["curl", "-L", "--max-time", "120", "-o", saved_file, download_url],
            capture_output=True, text=True, timeout=150,
        )
        if result.returncode != 0:
            raise Exception(result.stderr or "curl download failed")
        if not os.path.exists(saved_file) or os.path.getsize(saved_file) < 100:
            raise Exception("الملف الذي تم تنزيله فارغ أو غير مكتمل")
    except subprocess.TimeoutExpired:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="انتهت مهلة تنزيل ملف التحديث",
        ))
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="فشل تنزيل ملف التحديث: " + str(e),
        ))

    # 3) فك الضغط مباشرة في مجلد التطبيق
    try:
        if os.name == "nt":
            # Windows: PowerShell Expand-Archive
            ps_cmd = (
                "Expand-Archive -Path '{}' -DestinationPath '{}' -Force"
                .format(saved_file.replace("'", "''"), _appPath.replace("'", "''"))
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode != 0:
                raise Exception(result.stderr or "Expand-Archive failed")
        else:
            # Linux: Python zipfile (يتعامل مع backslashes في المسارات)
            import zipfile
            with zipfile.ZipFile(saved_file, "r") as zf:
                for info in zf.infolist():
                    # تحويل backslashes إلى forward slashes
                    info.filename = info.filename.replace("\\", "/")
                    zf.extract(info, _appPath)
    except subprocess.TimeoutExpired:
        return response.json(dict(
            status="error",
            message="انتهت مهلة فك ضغط ملف التحديث",
        ))
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل فك الضغط: " + str(e),
        ))
    finally:
        # تنظيف: حذف ملف ZIP
        if os.path.exists(saved_file):
            os.remove(saved_file)

    # 4) تنظيف __pycache__
    _clear_pycache(_appPath)

    # تقرير النتيجة
    new_ver = _get_local_version()
    msg = "تم التحديث بنجاح من {} إلى {}".format(local_ver, new_ver)

    return response.json(dict(
        status="success",
        old_ver=local_ver,
        new_ver=new_ver,
        message=msg,
    ))
