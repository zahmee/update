# -*- coding: utf-8 -*-
#  type: ignore

import os
import threading
import sys

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"


def fix():
    qry = ('PGPASSWORD=\'5445za\' psql -h localhost -U admin -d pha -c " GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to admin ; " ')
    s = os.popen(qry)
    preprocessed = s.read()
    s.close()
    return preprocessed

def db():
    _appPath = request.folder
    backupdir=_appPath + '/static/db.tar'
    configuration = AppConfig(reload=True)
    dbname = configuration.get('db.uri').split("/")
    script = ("PGPASSWORD='5445za' pg_dump -h localhost -U admin -F t "+dbname[-1]+" >  %s" % (backupdir))
    s = os.popen(script)
    preprocessed = s.read()
    s.close()
    return redirect(URL('static','db.tar'))


def _get_local_version():
    """قراءة رقم النسخة المحلية من pha_ver.txt"""
    ver_file = os.path.join(request.folder, "pha_ver.txt")
    try:
        with open(ver_file, "r") as f:
            return f.read().strip()
    except Exception:
        return "0"


def _get_remote_version():
    """قراءة رقم النسخة المتوفرة على الخادم"""
    import urllib.request
    req = urllib.request.urlopen(UPDATE_BASE_URL + "pha_ver.txt", timeout=20)
    return req.read().decode("utf-8").strip()


def up():
    """صفحة التحديث — تعرض النسخة الحالية مع إمكانية التحقق والتحديث"""
    local_ver = _get_local_version()
    return dict(local_ver=local_ver)


def check_update():
    """API: التحقق من وجود تحديث جديد"""
    local_ver = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))
    has_update = (local_ver != remote_ver)
    return response.json(dict(
        status="ok",
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        message="يتوفر تحديث جديد: " + remote_ver if has_update else "النسخة الحالية هي الأحدث",
    ))


def apply_update():
    """API: تنزيل التحديث وتثبيته"""
    import urllib.request
    import zipfile

    _appPath = request.folder
    saved_file = os.path.join(_appPath, "pha.zip")
    local_ver = _get_local_version()

    # 1) التحقق من النسخة
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))

    if local_ver == remote_ver:
        return response.json(dict(
            status="up_to_date",
            message="النسخة الحالية ({}) هي الأحدث — لا حاجة للتحديث".format(local_ver),
        ))

    # 2) تنزيل ملف التحديث
    try:
        urllib.request.urlretrieve(UPDATE_BASE_URL + "pha.zip", saved_file)
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="فشل تنزيل ملف التحديث: " + str(e),
        ))

    # 3) التحقق من سلامة الملف المضغوط وفك ضغطه
    try:
        with zipfile.ZipFile(saved_file, "r") as zf:
            bad_file = zf.testzip()
            if bad_file:
                os.remove(saved_file)
                return response.json(dict(
                    status="error",
                    message="ملف التحديث تالف عند: " + bad_file,
                ))
            zf.extractall(_appPath)
    except zipfile.BadZipFile:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="الملف الذي تم تنزيله ليس ملف ZIP صالح",
        ))
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="فشل فك الضغط: " + str(e),
        ))

    # 4) حذف ملف التنزيل المؤقت
    if os.path.exists(saved_file):
        os.remove(saved_file)

    return response.json(dict(
        status="success",
        old_ver=local_ver,
        new_ver=remote_ver,
        message="تم التحديث بنجاح من النسخة {} إلى {}".format(local_ver, remote_ver),
    ))
