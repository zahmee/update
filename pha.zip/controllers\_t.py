# -*- coding: utf-8 -*-
#  type: ignore

import os
import threading
import sys

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"


def fix():
    qry = ('PGPASSWORD=\'5445za\' psql -h localhost -U admin -d pha -c " GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to admin; GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to admin ; " ')
    s = os.popen(qry)
    preprocessed = s.read()
    s.close()
    return preprocessed

def db():
    _appPath = request.folder
    backupdir=_appPath + '/static/db.tar'
    configuration = AppConfig(reload=True)
    dbname = configuration.get('db.uri').split("/")
    script = ("PGPASSWORD='5445za' pg_dump -h localhost -U admin -F t "+dbname[-1]+" >  %s" % (backupdir))
    s = os.popen(script)
    preprocessed = s.read()
    s.close()
    return redirect(URL('static','db.tar'))


def _get_local_version():
    """قراءة رقم النسخة المحلية من pha_ver.txt"""
    ver_file = os.path.join(request.folder, "pha_ver.txt")
    try:
        with open(ver_file, "r") as f:
            return f.read().strip()
    except Exception:
        return "0"


def _get_remote_version():
    """قراءة رقم النسخة المتوفرة على الخادم"""
    import urllib.request
    req = urllib.request.urlopen(UPDATE_BASE_URL + "pha_ver.txt", timeout=20)
    return req.read().decode("utf-8").strip()


def up():
    """صفحة التحديث — تعرض النسخة الحالية مع إمكانية التحقق والتحديث"""
    local_ver = _get_local_version()
    return dict(local_ver=local_ver)


def check_update():
    """API: التحقق من وجود تحديث جديد"""
    local_ver = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))
    has_update = (local_ver != remote_ver)
    return response.json(dict(
        status="ok",
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        message="يتوفر تحديث جديد: " + remote_ver if has_update else "النسخة الحالية هي الأحدث",
    ))


def _clear_pycache(app_path):
    """حذف جميع مجلدات __pycache__ في التطبيق"""
    import shutil
    for root, dirs, _files in os.walk(app_path):
        for d in dirs:
            if d == "__pycache__":
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)


def _fix_permissions(path, is_dir=False):
    """ضبط صلاحيات الملف/المجلد بعد الاستخراج"""
    import stat
    try:
        if is_dir:
            os.chmod(path, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)  # 0o755
        else:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)  # 0o644
    except Exception:
        pass


def apply_update():
    """API: تنزيل التحديث وتثبيته — فك الضغط في مجلد مؤقت ثم نسخ الملفات واحداً واحداً"""
    import urllib.request
    import zipfile
    import tempfile
    import shutil
    import stat

    _appPath = request.folder
    saved_file = os.path.join(_appPath, "pha.zip")
    local_ver = _get_local_version()

    # 1) التحقق من النسخة
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))

    if local_ver == remote_ver:
        return response.json(dict(
            status="up_to_date",
            message="النسخة الحالية ({}) هي الأحدث — لا حاجة للتحديث".format(local_ver),
        ))

    # 2) تنزيل ملف التحديث
    try:
        urllib.request.urlretrieve(UPDATE_BASE_URL + "pha.zip", saved_file)
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="فشل تنزيل ملف التحديث: " + str(e),
        ))

    # 3) فك الضغط في مجلد مؤقت ثم نسخ الملفات
    tmp_dir = tempfile.mkdtemp(prefix="pha_update_")
    failed_files = []
    updated_count = 0

    try:
        # فحص سلامة ZIP وفك الضغط في المجلد المؤقت
        with zipfile.ZipFile(saved_file, "r") as zf:
            bad_file = zf.testzip()
            if bad_file:
                return response.json(dict(
                    status="error",
                    message="ملف التحديث تالف عند: " + bad_file,
                ))
            zf.extractall(tmp_dir)

        # نسخ الملفات واحداً واحداً مع معالجة الأخطاء
        for root, dirs, files in os.walk(tmp_dir):
            rel_dir = os.path.relpath(root, tmp_dir)
            dest_dir = os.path.normpath(os.path.join(_appPath, rel_dir))

            # إنشاء المجلدات الجديدة مع الصلاحيات الصحيحة
            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir, exist_ok=True)
            _fix_permissions(dest_dir, is_dir=True)

            for fname in files:
                src = os.path.join(root, fname)
                dst = os.path.join(dest_dir, fname)
                rel_path = os.path.join(rel_dir, fname) if rel_dir != "." else fname
                try:
                    # إزالة read-only من الملف القديم إن وجد
                    if os.path.exists(dst):
                        os.chmod(dst, stat.S_IWRITE | stat.S_IREAD)
                    shutil.copy2(src, dst)
                    _fix_permissions(dst, is_dir=False)
                    updated_count += 1
                except Exception as e:
                    failed_files.append("{}: {}".format(rel_path, str(e)))

        # تنظيف __pycache__ لتجنب تحميل كود قديم مخزن
        _clear_pycache(_appPath)

    except zipfile.BadZipFile:
        return response.json(dict(
            status="error",
            message="الملف الذي تم تنزيله ليس ملف ZIP صالح",
        ))
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل فك الضغط: " + str(e),
        ))
    finally:
        # تنظيف: حذف المجلد المؤقت وملف ZIP
        shutil.rmtree(tmp_dir, ignore_errors=True)
        if os.path.exists(saved_file):
            os.remove(saved_file)

    # تقرير النتيجة
    msg = "تم التحديث بنجاح من {} إلى {} — تم تحديث {} ملف".format(
        local_ver, remote_ver, updated_count)
    if failed_files:
        msg += " ، {} ملف لم يتم تحديثه".format(len(failed_files))

    return response.json(dict(
        status="success",
        old_ver=local_ver,
        new_ver=remote_ver,
        message=msg,
        updated=updated_count,
        failed=failed_files,
    ))
