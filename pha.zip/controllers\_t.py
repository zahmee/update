# -*- coding: utf-8 -*-
#  type: ignore

import os
import subprocess
import shutil
from urllib.parse import urlparse, unquote

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"
UPDATE_FALLBACK_BASE_URL = "https://raw.githubusercontent.com/zahmee/update/main/"


def _db_conn_info():
    """تحليل db.uri من appconfig.ini إلى مكوّنات الاتصال — بدون تضمين كلمة المرور."""
    parsed = urlparse(AppConfig(reload=True).get("db.uri"))
    return {
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
        "host": parsed.hostname or "localhost",
        "port": str(parsed.port or 5432),
        "dbname": (parsed.path or "/").lstrip("/"),
    }


@auth.requires_login()
def fix():
    info = _db_conn_info()
    grant_sql = (
        "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public to {u}; "
        "GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public to {u}; "
        "GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public to {u};"
    ).format(u=info["user"])
    env = {**os.environ, "PGPASSWORD": info["password"]}
    result = subprocess.run(
        ["psql", "-h", info["host"], "-p", info["port"],
         "-U", info["user"], "-d", info["dbname"], "-c", grant_sql],
        env=env, capture_output=True, text=True,
    )
    return result.stdout + result.stderr


@auth.requires_login()
def db_backup():
    backupdir = os.path.join(request.folder, "static", "db.tar")
    info = _db_conn_info()
    env = {**os.environ, "PGPASSWORD": info["password"]}
    with open(backupdir, "wb") as out:
        result = subprocess.run(
            ["pg_dump", "-h", info["host"], "-p", info["port"],
             "-U", info["user"], "-F", "t", info["dbname"]],
            env=env, stdout=out, stderr=subprocess.PIPE,
        )
    if result.returncode != 0:
        return "فشل النسخ الاحتياطي: " + result.stderr.decode("utf-8", "replace")
    return redirect(URL('static', 'db.tar'))


def _get_remote_version():
    """قراءة رقم النسخة المتوفرة على الخادم باستخدام curl"""
    urls = [
        UPDATE_BASE_URL + "pha_ver.txt",
        UPDATE_FALLBACK_BASE_URL + "pha_ver.txt",
    ]
    last_error = ""
    for url in urls:
        result = subprocess.run(
            ["curl", "-fsSL", "--connect-timeout", "20", "--max-time", "90", url],
            capture_output=True, text=True, timeout=100,
        )
        if result.returncode == 0:
            ver = result.stdout.strip()
            if ver:
                return ver
            last_error = "لم يتم الحصول على رقم النسخة من الخادم"
        else:
            last_error = result.stderr or "unknown error"
    raise Exception("curl failed: " + last_error)


def _download_update_file(download_url, fallback_url, saved_file):
    """تنزيل ملف التحديث مع retries ومهلة كافية للسيرفرات البطيئة مع GitHub."""
    urls = [download_url]
    if fallback_url and fallback_url != download_url:
        urls.append(fallback_url)

    last_error = ""
    for url in urls:
        result = subprocess.run(
            [
                "curl",
                "-fL",
                "--http1.1",
                "--connect-timeout", "30",
                "--retry", "5",
                "--retry-delay", "3",
                "--retry-connrefused",
                "--speed-time", "90",
                "--speed-limit", "1024",
                "--max-time", "900",
                "-o", saved_file,
                url,
            ],
            capture_output=True, text=True, timeout=930,
        )
        if result.returncode == 0:
            return
        last_error = result.stderr or result.stdout or "curl download failed"
        if os.path.exists(saved_file):
            os.remove(saved_file)

    raise Exception(last_error)


def _validate_zip_file(saved_file):
    """التأكد من أن ملف التحديث ZIP صالح قبل فك الضغط."""
    import zipfile
    if not os.path.exists(saved_file) or os.path.getsize(saved_file) < 100:
        raise Exception("الملف الذي تم تنزيله فارغ أو غير مكتمل")
    if not zipfile.is_zipfile(saved_file):
        raise Exception("ملف التحديث الذي تم تنزيله ليس ملف ZIP صالح")
    with zipfile.ZipFile(saved_file, "r") as zf:
        bad_file = zf.testzip()
        if bad_file:
            raise Exception("ملف التحديث تالف عند: " + bad_file)


@auth.requires_login()
def up():
    """صفحة التحديث — تعرض النسخة الحالية مع إمكانية التحقق والتحديث"""
    local_ver = app_version()
    return dict(local_ver=local_ver)


@auth.requires_login()
def check_update():
    """API: التحقق من وجود تحديث جديد"""
    local_ver = app_version()
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))
    has_update = (local_ver != remote_ver)
    return response.json(dict(
        status="ok",
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        message="يتوفر تحديث جديد: " + remote_ver if has_update else "النسخة الحالية هي الأحدث",
    ))


def _clear_pycache(app_path):
    """حذف جميع مجلدات __pycache__ في التطبيق"""
    for root, dirs, _files in os.walk(app_path):
        for d in dirs:
            if d == "__pycache__":
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)


@auth.requires_login()
def apply_update():
    """API: تنزيل التحديث وتثبيته باستخدام curl + tar"""
    _appPath = request.folder
    saved_file = os.path.join(_appPath, "pha.zip")
    local_ver = app_version()

    # 1) التحقق من النسخة
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل الاتصال بخادم التحديث: " + str(e),
        ))

    if local_ver == remote_ver:
        return response.json(dict(
            status="up_to_date",
            message="النسخة الحالية ({}) هي الأحدث — لا حاجة للتحديث".format(local_ver),
        ))

    # 2) تنزيل ملف التحديث باستخدام curl
    download_url = UPDATE_BASE_URL + "pha.zip"
    fallback_url = UPDATE_FALLBACK_BASE_URL + "pha.zip"
    try:
        _download_update_file(download_url, fallback_url, saved_file)
        _validate_zip_file(saved_file)
    except subprocess.TimeoutExpired:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="انتهت مهلة تنزيل ملف التحديث من خادم التحديث",
        ))
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(
            status="error",
            message="فشل تنزيل ملف التحديث: " + str(e),
        ))

    # 3) فك الضغط مباشرة في مجلد التطبيق
    try:
        if os.name == "nt":
            # Windows: PowerShell Expand-Archive
            ps_cmd = (
                "Expand-Archive -Path '{}' -DestinationPath '{}' -Force"
                .format(saved_file.replace("'", "''"), _appPath.replace("'", "''"))
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode != 0:
                raise Exception(result.stderr or "Expand-Archive failed")
        else:
            # Linux: Python zipfile (يتعامل مع backslashes في المسارات)
            import zipfile
            with zipfile.ZipFile(saved_file, "r") as zf:
                for info in zf.infolist():
                    # تحويل backslashes إلى forward slashes
                    info.filename = info.filename.replace("\\", "/")
                    zf.extract(info, _appPath)
    except subprocess.TimeoutExpired:
        return response.json(dict(
            status="error",
            message="انتهت مهلة فك ضغط ملف التحديث",
        ))
    except Exception as e:
        return response.json(dict(
            status="error",
            message="فشل فك الضغط: " + str(e),
        ))
    finally:
        # تنظيف: حذف ملف ZIP
        if os.path.exists(saved_file):
            os.remove(saved_file)

    # 4) تنظيف __pycache__
    _clear_pycache(_appPath)

    # تقرير النتيجة
    new_ver = app_version()
    msg = "تم التحديث بنجاح من {} إلى {}".format(local_ver, new_ver)

    return response.json(dict(
        status="success",
        old_ver=local_ver,
        new_ver=new_ver,
        message=msg,
    ))
