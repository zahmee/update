var app = new Vue({
  el: "#app",
  data: {
    edit_row_data: {
      country_name: "SA",
      organization_unit_name: "1",
      environment: "nonproduction",
      api_site: "http://localhost:8011",
    },
    current_step: 0,
    phase: 0, // 0=empty, 1=data saved, 2=compliance CSID, 3=production CSID
    loading: false,
    onboarding_status: "",
    onboarding_progress: 0,
    status_data: {},
    steps: [
      { title: "بيانات المنشأة" },
      { title: "إنشاء المفاتيح" },
      { title: "اختبارات التوافق" },
      { title: "حالة الربط" },
    ],
  },
  computed: {
    envLabel: function () {
      var labels = {
        nonproduction: "تهيئة (Sandbox)",
        simulation: "تجريبية (Simulation)",
        production: "نهائية (Production)",
      };
      return labels[this.edit_row_data.environment] || this.edit_row_data.environment || "";
    },
  },
  created: function () {
    this.loadConfig();
    this.loadStatus();
  },
  methods: {
    // ---- URL helpers ----
    setupUrl: function (fn) {
      return new URL(window.location.href + "/../" + fn).href;
    },
    zatcaUrl: function (fn) {
      return new URL(window.location.href + "/../../zatca/" + fn).href;
    },

    // ---- Data loading ----
    loadConfig: function () {
      var self = this;
      fetch(this.setupUrl("git_csr_config"), {
        headers: { "Content-Type": "application/json", Accept: "application/json" },
      })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          self.edit_row_data = data;
          self.updatePhase();
          // Navigate to appropriate step
          if (self.phase >= 3) self.current_step = 3;
          else if (self.phase >= 2) self.current_step = 2;
          else if (self.phase >= 1) self.current_step = 0;
        });
    },
    loadStatus: function () {
      var self = this;
      fetch(this.zatcaUrl("zatca_status"), {
        headers: { "Content-Type": "application/json", Accept: "application/json" },
      })
        .then(function (r) { return r.json(); })
        .then(function (resp) {
          if (resp.ok || resp.status === 1) {
            self.status_data = resp.data;
          }
        })
        .catch(function () { /* ignore status errors */ });
    },
    updatePhase: function () {
      var d = this.edit_row_data;
      if (d.pcsid_requestid) {
        this.phase = 3;
      } else if (d.ccsid_requestid) {
        this.phase = 2;
      } else if (d.organization_name && d.organization_identifier) {
        this.phase = 1;
      } else {
        this.phase = 0;
      }
    },

    // ---- Stepper ----
    stepClass: function (idx) {
      if (this.phase > idx) return "done";
      if (this.current_step === idx) return "active";
      return "pending";
    },
    goToStep: function (idx) {
      if (idx <= this.phase || idx === this.phase) {
        this.current_step = idx;
      }
    },

    // ---- Validation ----
    validateCompanyData: function () {
      var d = this.edit_row_data;
      var checks = [
        [!d.organization_name, "يجب إدخال اسم المنشأة"],
        [!d.organization_identifier || String(d.organization_identifier).length !== 15, "الرقم الضريبي يجب أن يكون 15 خانة"],
        [!d.organization_unit_name, "يجب إدخال القسم / الفرع"],
        [!d.company_id || String(d.company_id).length !== 10, "السجل التجاري يجب أن يكون 10 خانات"],
        [!d.business_category, "يجب إدخال تصنيف النشاط"],
        [!d.address_city_name, "يجب إدخال المدينة"],
        [!d.address_street_name, "يجب إدخال الشارع"],
        [!d.address_neighborhood, "يجب إدخال الحي"],
        [!d.address_building_number || String(d.address_building_number).length !== 4, "رقم المبنى يجب أن يكون 4 أرقام"],
        [!d.address_postal_zone || String(d.address_postal_zone).length !== 5, "الرمز البريدي يجب أن يكون 5 أرقام"],
        [!d.location_address || String(d.location_address).length !== 8, "العنوان المختصر يجب أن يكون 8 خانات"],
      ];
      for (var i = 0; i < checks.length; i++) {
        if (checks[i][0]) {
          Swal.fire("تنبيه", checks[i][1], "error");
          return false;
        }
      }
      return true;
    },

    // ---- Save ----
    saveData: function () {
      var self = this;
      return fetch(this.setupUrl("update_csr_config"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(this.edit_row_data),
      })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data === "0") {
            self.updatePhase();
            return true;
          } else {
            Swal.fire("خطأ", (data && data.mess) || "حدث خطأ أثناء الحفظ", "error");
            return false;
          }
        });
    },
    saveAndNext: function () {
      if (!this.validateCompanyData()) return;
      var self = this;
      this.saveData().then(function (ok) {
        if (ok) {
          Swal.fire("تم", "تم حفظ بيانات المنشأة بنجاح", "success");
          self.phase = Math.max(self.phase, 1);
          self.current_step = 1;
        }
      });
    },

    // ---- Step 1: CSR + Compliance CSID ----
    doStep1: function () {
      var otp = this.edit_row_data.otp;
      if (!otp || String(otp).length !== 6) {
        Swal.fire("تنبيه", "يجب إدخال رمز OTP مكون من 6 أرقام", "error");
        return;
      }
      var self = this;
      // Save first, then generate
      this.saveData().then(function (ok) {
        if (!ok) return;
        self.loading = true;
        fetch(self.zatcaUrl("step1_csid"), {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ otp: otp }),
        })
          .then(function (r) { return r.json(); })
          .then(function (resp) {
            self.loading = false;
            if (resp.ok || resp.status === 1) {
              Swal.fire("تم", resp.mess || "تم إنشاء المفاتيح بنجاح", "success");
              self.phase = 2;
              self.loadConfig();
            } else {
              Swal.fire("خطأ", resp.mess || "فشل إنشاء المفاتيح", "error");
            }
          })
          .catch(function () {
            self.loading = false;
            Swal.fire("خطأ", "فشل الاتصال بالخادم", "error");
          });
      });
    },

    // ---- Step 2: Onboarding (6 test invoices + Production CSID) ----
    doStep2: function () {
      var self = this;
      this.loading = true;
      this.onboarding_status = "جاري إرسال الفواتير التجريبية إلى هيئة الزكاة...";
      this.onboarding_progress = 20;

      // Animate progress while waiting
      var progressTimer = setInterval(function () {
        if (self.onboarding_progress < 85) {
          self.onboarding_progress += 5;
          var messages = [
            "جاري إرسال الفواتير التجريبية...",
            "جاري التحقق من فاتورة ضريبية...",
            "جاري التحقق من إشعارات الائتمان...",
            "جاري التحقق من الفواتير المبسطة...",
            "جاري طلب المفتاح النهائي...",
          ];
          var idx = Math.min(Math.floor(self.onboarding_progress / 18), messages.length - 1);
          self.onboarding_status = messages[idx];
        }
      }, 3000);

      fetch(this.zatcaUrl("step2_onboarding"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
      })
        .then(function (r) { return r.json(); })
        .then(function (resp) {
          clearInterval(progressTimer);
          self.loading = false;
          if (resp.ok || resp.status === 1) {
            self.onboarding_progress = 100;
            self.onboarding_status = "اكتملت جميع الاختبارات بنجاح";
            Swal.fire("تم", resp.mess || "تم اجتياز اختبارات التوافق بنجاح", "success");
            self.phase = 3;
            self.loadConfig();
            self.loadStatus();
            setTimeout(function () { self.current_step = 3; }, 1500);
          } else {
            self.onboarding_progress = 0;
            self.onboarding_status = "";
            Swal.fire("خطأ", resp.mess || "فشل اختبارات التوافق", "error");
          }
        })
        .catch(function () {
          clearInterval(progressTimer);
          self.loading = false;
          self.onboarding_progress = 0;
          self.onboarding_status = "";
          Swal.fire("خطأ", "فشل الاتصال بالخادم", "error");
        });
    },

    // ---- Export / Import JSON ----
    export_json: function () {
      var dataStr = JSON.stringify(this.edit_row_data, null, 2);
      var dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);
      var link = document.createElement("a");
      link.setAttribute("href", dataUri);
      link.setAttribute("download", "zatca_config.json");
      link.click();
    },
    import_json: function () {
      this.$refs.fileInput.click();
    },
    handle_file_upload: function (event) {
      var self = this;
      var file = event.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function (e) {
        try {
          var json = JSON.parse(e.target.result);
          self.edit_row_data = json;
          self.updatePhase();
          Swal.fire("تم", "تم استيراد الملف بنجاح", "success");
        } catch (error) {
          Swal.fire("خطأ", "فشل قراءة الملف. تأكد من صحة تنسيق JSON", "error");
        }
      };
      reader.readAsText(file);
      event.target.value = "";
    },
  },
});
