# -*- coding: utf-8 -*-
# ===========================================================================================
# سكريبت التهيئة - البيانات الافتتاحية
# يتم تشغيله مرة واحدة عند تهيئة النظام لأول مرة:
#   python web2py.py -S asbab5 -M -R scripts/seed_data.py
# ===========================================================================================

print("بدء تهيئة البيانات الافتتاحية...")

# ===========================================================================================
# 1) جداول الترميزات الأساسية (من db_1_keys.py)
# ===========================================================================================

# الوحدات
if db(db.key_unit.id > 0).isempty():
    db.key_unit.insert(name="حبة")
    db.key_unit.insert(name="علبة")
    db.key_unit.insert(name="كرتون")
    db.key_unit.insert(name="ملل")
    db.key_unit.insert(name="شنطة")
    print("  + key_unit")

# طرق الدفع
if db(db.key_payment_method.id > 0).isempty():
    db.key_payment_method.insert(name="نقدي")
    db.key_payment_method.insert(name="شبكة الكترونية")
    db.key_payment_method.insert(name="آجل")
    db.key_payment_method.insert(name="تحويل في الحساب")
    db.key_payment_method.insert(name="شيك")
    db.key_payment_method.insert(name="خصم من الرصيد")
    print("  + key_payment_method")

# أنواع العملاء
if db(db.key_cust.id > 0).isempty():
    db.key_cust.insert(name="عميل عام")
    db.key_cust.insert(name="عميل جمعية البر")
    print("  + key_cust")

# مجموعات الصلاحيات
if db(db.auth_group.id > 0).isempty():
    db.auth_group.insert(role="admin")
    db.auth_group.insert(role="user")
    db.auth_group.insert(role="account")
    db.auth_group.insert(role="report")
    print("  + auth_group")

# المستخدم الافتراضي (admin)
if db(db.auth_user.id > 0).isempty():
    password = db.auth_user.password.validate("admin")[0]
    user_id = db.auth_user.insert(
        first_name="admin", last_name="user", password=password, email="admin@user.com"
    )
    print("  + auth_user (admin)")
    if db(db.auth_membership.id > 0).isempty():
        db.auth_membership.insert(
            user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
        )
        print("  + auth_membership")

# التصنيفات
if db(db.key_type.id > 0).isempty():
    db.key_type.insert(name="ادوات تجميل")
    db.key_type.insert(name="ادوات طبية")
    db.key_type.insert(name="ادوية")
    db.key_type.insert(name="اطفال")
    db.key_type.insert(name="اسنان")
    print("  + key_type")

# أنواع سداد المورد
if db(db.key_payment_type.id > 0).isempty():
    db.key_payment_type.insert(name="سداد مستحقات")
    db.key_payment_type.insert(name="خصم مكتسب")
    db.key_payment_type.insert(name="مرتجعات/فاتورة")
    db.key_payment_type.insert(name="مرتجعات/اصناف")
    print("  + key_payment_type")

# تصنيف الفواتير
if db(db.key_invoce_type.id > 0).isempty():
    db.key_invoce_type.insert(name="مشتريات")
    db.key_invoce_type.insert(name="تعويض")
    db.key_invoce_type.insert(name="هدايا")
    print("  + key_invoce_type")

# ===========================================================================================
# 2) البيانات الافتتاحية للأعمال (من db_2_business.py)
# ===========================================================================================

# المورد الافتراضي
if db(db.suppliers.id > 0).isempty():
    db.suppliers.insert(name="مورد عام - مورد نقدي")
    print("  + suppliers")

# الصنف الافتراضي (هلل)
if db(db.items_main.id > 0).isempty():
    db.items_main.insert(
        item_id="1", name="هلل", item_reg="1", flexible_price=True, public_price=0.01
    )
    print("  + items_main")

# العميل الافتراضي
if db(db.customers.id > 0).isempty():
    db.customers.insert(name="عميل عام - نفدي", mobile="0")
    print("  + customers")

# ===========================================================================================
# 3) بيانات التشغيل (من db_3_operations.py)
# ===========================================================================================

# النظام
if db(db.systems.id > 0).isempty():
    db.systems.insert(name="نظام الصيدلية")
    print("  + systems")

# إعدادات ZATCA
if db(db.csr_config.id > 0).isempty():
    db.csr_config.insert(otp="123456")
    print("  + csr_config")

# ===========================================================================================
# 4) بيانات المنشأة (من db_4_access.py)
# ===========================================================================================

if db(db.important_info.id > 0).isempty():
    db.important_info.insert(
        name="نظام ؟؟؟؟؟؟؟؟؟",
        vat="0",
        tel="0",
        mobile="05",
        address="العنوان",
        msg1="----",
        msg2="----",
    )
    print("  + important_info")

# ===========================================================================================
# 5) ترميزات الموارد البشرية (من db_5_hr.py)
# ===========================================================================================

# أنواع المستندات
if db(db.key_doc_types.id > 0).isempty():
    db.key_doc_types.insert(name="اوراق المؤسسة الرسمية")
    db.key_doc_types.insert(name="اقامة")
    db.key_doc_types.insert(name="جواز سفر")
    db.key_doc_types.insert(name="عقد عمل")
    db.key_doc_types.insert(name="ترخيص مزاولة مهنة")
    print("  + key_doc_types")

# المسميات الوظيفية
if db(db.key_job_titles.id > 0).isempty():
    db.key_job_titles.insert(name="صيدلي")
    db.key_job_titles.insert(name="فني صيدلة")
    db.key_job_titles.insert(name="محاسب")
    db.key_job_titles.insert(name="مدير")
    db.key_job_titles.insert(name="بائع")
    print("  + key_job_titles")

# الجنسيات
if db(db.key_nationalities.id > 0).isempty():
    db.key_nationalities.insert(name="سعودي")
    db.key_nationalities.insert(name="مصري")
    db.key_nationalities.insert(name="يمني")
    db.key_nationalities.insert(name="سوداني")
    db.key_nationalities.insert(name="هندي")
    db.key_nationalities.insert(name="باكستاني")
    db.key_nationalities.insert(name="بنغلاديشي")
    db.key_nationalities.insert(name="فلبيني")
    print("  + key_nationalities")

# أنواع السلف
if db(db.key_advance_types.id > 0).isempty():
    db.key_advance_types.insert(name="سلفة راتب")
    db.key_advance_types.insert(name="سلفة شخصية")
    db.key_advance_types.insert(name="سلفة طارئة")
    print("  + key_advance_types")

# البدلات والخصومات
if db(db.key_allowance_deduction.id > 0).isempty():
    db.key_allowance_deduction.insert(name="بدل سكن", ad_type="بدل")
    db.key_allowance_deduction.insert(name="بدل نقل", ad_type="بدل")
    db.key_allowance_deduction.insert(name="بدل إضافي", ad_type="بدل")
    db.key_allowance_deduction.insert(name="خصم غياب", ad_type="خصم")
    db.key_allowance_deduction.insert(name="خصم تأخير", ad_type="خصم")
    db.key_allowance_deduction.insert(name="خصم سلفة", ad_type="خصم")
    print("  + key_allowance_deduction")

# حالات الموظفين
if db(db.key_emp_status.id > 0).isempty():
    db.key_emp_status.insert(name="على رأس العمل")
    db.key_emp_status.insert(name="في إجازة")
    db.key_emp_status.insert(name="منقطع")
    db.key_emp_status.insert(name="مفصول")
    print("  + key_emp_status")

# ===========================================================================================
# 6) تصنيفات حركات الصندوق (من db_3_operations.py)
# ===========================================================================================
if db(db.key_fund_category.id > 0).isempty():
    _fund_cats = [
        # (code, name_ar, kind)
        ("RENT",     "إيجار",              "expense"),
        ("ELEC",     "كهرباء",             "expense"),
        ("WATER",    "ماء",                "expense"),
        ("TELE",     "اتصالات وإنترنت",    "expense"),
        ("SAL",      "رواتب",              "expense"),
        ("ADV",      "سلف موظفين",         "expense"),
        ("MAINT",    "صيانة",              "expense"),
        ("TRANS",    "مواصلات",            "expense"),
        ("MISC",     "نثرية",              "expense"),
        ("SUP",      "دفعات موردين",       "expense"),
        ("GOV",      "رسوم حكومية",        "expense"),
        ("OTHER_EX", "مصروفات أخرى",       "expense"),
        ("DEPOSIT",  "إيداع نقدي",         "deposit"),
        ("RETURN",   "استرداد من مورد/جهة","deposit"),
        ("OTHER_DP", "إيداعات أخرى",       "deposit"),
        ("LEGACY",   "مُرحَّل من النظام القديم", "expense"),
    ]
    for code, name_ar, kind in _fund_cats:
        db.key_fund_category.insert(code=code, name_ar=name_ar, kind=kind, is_active=True)
    print("  + key_fund_category")

# ===========================================================================================
db.commit()
print("تمت التهيئة بنجاح.")
