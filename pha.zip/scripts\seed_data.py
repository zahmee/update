# -*- coding: utf-8 -*-
# ===========================================================================================
# تهيئة النظام من سطر الأوامر: عند أول تثبيت، قبل وجود مستخدم يفتح شاشة setup/seed_data.
#
#   uv run web2py.py -S asbab5 -M -R scripts/seed_data.py             فحص فقط: يعرض النواقص
#   uv run web2py.py -S asbab5 -M -R scripts/seed_data.py -A apply    ينشئ الناقص بعد التحقق
#
# المنطق نفسه الذي تستخدمه الشاشة (modules/system_readiness.py): البيانات الافتتاحية للجداول
# الفارغة فقط وبأرقام ثابتة، ثم امتداد pg_trgm، ثم الفهارس الناقصة مع تحقق قبل كل خطوة وبعدها.
# من هنا وحده يُنشأ المدير الأول admin@user.com بكلمة المرور admin — غيّرها فور أول دخول.
# سجل الشاشات يُكمَل بعد الدخول من شاشة تهيئة النظام (قائمته في controllers/setup.py).
# ===========================================================================================
import sys

import system_readiness as readiness

APPLY = "apply" in [a.lower() for a in sys.argv[1:]]
MARK = {"done": "+", "skipped": "=", "failed": "!"}


def _show(res):
    print("  %s %s: %s" % (MARK.get(res["state"], "?"), res["label"], res["mess"]))
    for c in res.get("checks") or []:
        print("      %s %s" % ("ok " if c["ok"] else "no ", c["text"]))


print("تهيئة النظام — %s" % ("تنفيذ" if APPLY else "فحص فقط (أضف -A apply للتنفيذ)"))

print("\n[البيانات الافتتاحية]")
for s in readiness.seed_status(db):
    if s["state"] == "done":
        print("  = %s (السجلات: %s)" % (s["label"], s["count"]))
    elif s["state"] == "no_table":
        print("  ! %s: الجدول غير موجود" % s["label"])
    elif APPLY:
        _show(readiness.seed_apply(db, s["key"], allow_cli_only=True))
    else:
        print("  - %s: فارغ، سيُضاف: %s" % (s["label"], "، ".join(s["preview"])))
    for w in s["warnings"]:
        print("      تنبيه: %s" % w["text"])

print("\n[الامتدادات]")
for e in readiness.extension_status(db):
    if e["state"] == "ok":
        print("  = %s" % e["label"])
    elif APPLY and e["state"] == "missing":
        _show(readiness.extension_apply(db, e["name"]))
    else:
        print("  - %s: %s" % (e["label"], "غير مثبّت" if e["state"] == "missing" else "غير متوفر في الخادم"))

print("\n[فهارس السرعة]")
ok = 0
for x in readiness.index_status(db):
    if x["state"] == "ok":
        ok += 1
    elif APPLY and x["state"] in ("missing", "invalid"):
        _show(readiness.index_apply(db, x["name"]))
    else:
        print("  - %s (%s): %s" % (x["name"], x["purpose"], x["reason"] or "ناقص"))
print("  = قائم وصالح: %s" % ok)

extras = readiness.extra_indexes(db, db.tables)
if extras:
    print("\n[فهارس زائدة] تُحذف من شاشة تهيئة النظام بعد المراجعة:")
    for e in extras:
        print("  - %s على %s (%s ك.ب)%s" % (e["name"], e["table"], e["size"] // 1024,
                                          " مطابق لـ " + e["twin"] if e["twin"] else " معطوب"))

db.commit()
print("\nانتهى.")
