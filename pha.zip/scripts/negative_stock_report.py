# -*- coding: utf-8 -*-
"""تقرير الأصناف ذات الرصيد السالب — كشف جرد جاهز للطباعة والتعبئة.

يُخرج ملف إكسل بورقتين:
  1) كشف الجرد   — صف لكل صنف، مع خانة فارغة للكمية الفعلية وعمود فرق تلقائي
  2) الدفعات السالبة — تفصيل الدفعات التي تحمل الرصيد السالب داخل كل صنف

الأصناف المُدرجة هي التي إجمالي رصيدها سالب، أي التي لا يمكن إصلاحها برمجياً
(إصلاحها آلياً يعني اختراع كمية)، فتحتاج عدّاً فعلياً أو فاتورة شراء.

طريقة التشغيل من مجلد web2py:
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/negative_stock_report.py

يُحفظ الملف في جذر التطبيق باسم: جرد_الأصناف_السالبة_<التاريخ>.xlsx
"""
import os
from datetime import datetime

import xlsxwriter

OUT_DIR = os.path.join(request.folder)
STAMP = datetime.now().strftime("%Y-%m-%d")
OUT_PATH = os.path.join(OUT_DIR, "جرد_الأصناف_السالبة_%s.xlsx" % STAMP)

# ---------------------------------------------------------------- الاستعلام
ITEMS_SQL = """
WITH agg AS (
    SELECT item_idr,
           SUM(items_count)                             AS total,
           COUNT(*)                                     AS batches,
           COUNT(*) FILTER (WHERE items_count < 0)      AS neg_batches,
           COALESCE(SUM(items_count) FILTER (WHERE items_count > 0), 0) AS pos_qty
      FROM items_det
     WHERE item_idr IN (SELECT id FROM items_main
                         WHERE COALESCE(track_stock, 'T') = 'T')
     GROUP BY item_idr
    HAVING SUM(items_count) < 0
)
SELECT a.item_idr, a.total, a.batches, a.neg_batches, a.pos_qty,
       m.item_id, m.name,
       COALESCE(t.name, '') AS type_name,
       COALESCE(u.name, '') AS unit_name,
       COALESCE(m.public_price, 0) AS price,
       (SELECT MAX(move_date) FROM items_movement v
         WHERE v.item_main = a.item_idr AND v.move_type = 'بيع')   AS last_sale,
       (SELECT MAX(move_date) FROM items_movement v
         WHERE v.item_main = a.item_idr AND v.move_type = 'شراء')  AS last_buy
  FROM agg a
  JOIN items_main m ON m.id = a.item_idr
  LEFT JOIN key_type t ON t.id = m.item_type
  LEFT JOIN key_unit u ON u.id = m.item_unit
 ORDER BY a.total ASC
"""

BATCH_SQL = """
WITH agg AS (
    SELECT item_idr FROM items_det
     WHERE item_idr IN (SELECT id FROM items_main
                         WHERE COALESCE(track_stock, 'T') = 'T')
     GROUP BY item_idr HAVING SUM(items_count) < 0
)
SELECT d.item_idr, m.item_id, m.name, d.id AS det_id, d.supplier_inv,
       COALESCE(b.bill_no, '') AS bill_no, d.expiration_date, d.items_count,
       COALESCE(d.quantity, 0) AS quantity
  FROM items_det d
  JOIN agg      ON agg.item_idr = d.item_idr
  JOIN items_main m ON m.id = d.item_idr
  LEFT JOIN suppliers_bills b ON b.id = d.supplier_inv
 WHERE d.items_count < 0
 ORDER BY d.item_idr, d.id
"""

items = db.executesql(ITEMS_SQL, as_dict=True)
batches = db.executesql(BATCH_SQL, as_dict=True)

# ---------------------------------------------------------------- بناء الملف
wb = xlsxwriter.Workbook(OUT_PATH)
wb.set_properties({"title": "جرد الأصناف ذات الرصيد السالب"})

F = dict(font_name="Arial", font_size=10)
f_title = wb.add_format(dict(F, bold=True, font_size=14, align="center",
                             valign="vcenter", font_color="#0F5257"))
f_sub = wb.add_format(dict(F, align="center", font_color="#555555", italic=True))
f_head = wb.add_format(dict(F, bold=True, bg_color="#0F5257", font_color="white",
                            align="center", valign="vcenter", border=1,
                            text_wrap=True))
f_txt = wb.add_format(dict(F, border=1, align="right"))
f_ctr = wb.add_format(dict(F, border=1, align="center"))
f_num = wb.add_format(dict(F, border=1, align="center", num_format="0.##"))
f_neg = wb.add_format(dict(F, border=1, align="center", num_format="0.##",
                           bold=True, font_color="#B00020", bg_color="#FDECEE"))
f_fill = wb.add_format(dict(F, border=1, align="center", bg_color="#FFF8E1"))
f_diff = wb.add_format(dict(F, border=1, align="center", num_format="0.##",
                            bg_color="#F1F8E9"))
f_date = wb.add_format(dict(F, border=1, align="center", num_format="yyyy-mm-dd"))

# ================= الورقة 1: كشف الجرد =================
ws = wb.add_worksheet("كشف الجرد")
ws.right_to_left()
ws.set_default_row(18)

COLS = [
    ("م", 5), ("رقم الصنف", 14), ("اسم الصنف", 46), ("التصنيف", 14),
    ("الوحدة", 10), ("الرصيد الحالي", 12), ("الموجود في الدفعات", 13),
    ("عدد الدفعات", 9), ("دفعات سالبة", 9), ("آخر بيع", 12), ("آخر شراء", 12),
    ("سعر البيع", 10), ("الكمية الفعلية بعد العد", 14), ("الفرق", 11),
    ("ملاحظات", 24),
]
for c, (t, w) in enumerate(COLS):
    ws.set_column(c, c, w)

ws.merge_range(0, 0, 0, len(COLS) - 1,
               "كشف جرد الأصناف ذات الرصيد السالب", f_title)
ws.merge_range(1, 0, 1, len(COLS) - 1,
               "تاريخ الإصدار: %s   |   عدد الأصناف: %d   |   إجمالي العجز: %s وحدة"
               % (STAMP, len(items),
                  round(sum(float(r["total"] or 0) for r in items), 2)),
               f_sub)
ws.merge_range(2, 0, 2, len(COLS) - 1,
               "املأ عمود «الكمية الفعلية بعد العد» فقط — عمود «الفرق» يُحسب تلقائياً."
               "  البيع من هذه الأصناف محجوب حتى تُسوّى.", f_sub)

HDR = 4
for c, (t, _w) in enumerate(COLS):
    ws.write(HDR, c, t, f_head)
ws.set_row(HDR, 30)
ws.freeze_panes(HDR + 1, 3)
ws.autofilter(HDR, 0, HDR + len(items), len(COLS) - 1)

for i, r in enumerate(items):
    row = HDR + 1 + i
    ws.write_number(row, 0, i + 1, f_ctr)
    ws.write(row, 1, r["item_id"] or "", f_ctr)
    ws.write(row, 2, (r["name"] or "").upper(), f_txt)
    ws.write(row, 3, r["type_name"], f_ctr)
    ws.write(row, 4, r["unit_name"], f_ctr)
    ws.write_number(row, 5, float(r["total"] or 0), f_neg)
    ws.write_number(row, 6, float(r["pos_qty"] or 0), f_num)
    ws.write_number(row, 7, int(r["batches"] or 0), f_ctr)
    ws.write_number(row, 8, int(r["neg_batches"] or 0), f_ctr)
    ws.write(row, 9, r["last_sale"].date() if r["last_sale"] else "", f_date)
    ws.write(row, 10, r["last_buy"].date() if r["last_buy"] else "", f_date)
    ws.write_number(row, 11, float(r["price"] or 0), f_num)
    ws.write_blank(row, 12, None, f_fill)          # تُملأ يدوياً
    ws.write_formula(row, 13,
                     '=IF({c}="","",{c}-{b})'.format(
                         c=xlsxwriter.utility.xl_rowcol_to_cell(row, 12),
                         b=xlsxwriter.utility.xl_rowcol_to_cell(row, 5)),
                     f_diff)
    ws.write_blank(row, 14, None, f_fill)

ws.print_area(0, 0, HDR + len(items), len(COLS) - 1)
ws.repeat_rows(HDR)
ws.set_landscape()
ws.fit_to_pages(1, 0)

# ================= الورقة 2: الدفعات السالبة =================
ws2 = wb.add_worksheet("الدفعات السالبة")
ws2.right_to_left()
COLS2 = [("رقم الصنف", 14), ("اسم الصنف", 46), ("رقم الدفعة", 11),
         ("فاتورة التوريد", 12), ("رقم الفاتورة", 18),
         ("تاريخ الصلاحية", 13), ("الكمية المشتراة", 12), ("الرصيد السالب", 12)]
for c, (t, w) in enumerate(COLS2):
    ws2.set_column(c, c, w)
    ws2.write(0, c, t, f_head)
ws2.set_row(0, 30)
ws2.freeze_panes(1, 2)
ws2.autofilter(0, 0, len(batches), len(COLS2) - 1)

for i, r in enumerate(batches):
    row = i + 1
    ws2.write(row, 0, r["item_id"] or "", f_ctr)
    ws2.write(row, 1, (r["name"] or "").upper(), f_txt)
    ws2.write_number(row, 2, int(r["det_id"]), f_ctr)
    ws2.write(row, 3, int(r["supplier_inv"] or 0), f_ctr)
    ws2.write(row, 4, r["bill_no"], f_ctr)
    ws2.write(row, 5, r["expiration_date"] or "", f_date)
    ws2.write_number(row, 6, float(r["quantity"] or 0), f_num)
    ws2.write_number(row, 7, float(r["items_count"] or 0), f_neg)

wb.close()

print("عدد الأصناف ذات الرصيد السالب : %d" % len(items))
print("عدد الدفعات السالبة           : %d" % len(batches))
print("إجمالي العجز                  : %s وحدة"
      % round(sum(float(r["total"] or 0) for r in items), 2))
print("الملف                         : %s" % OUT_PATH)
