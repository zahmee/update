# -*- coding: utf-8 -*-

import sys
import psycopg2
import psycopg2.extras
import psycopg2.extensions
import os
import datetime 
import math
import xlsxwriter
import io

#-----------------------------------------------------------------
THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))
my_file = os.path.join(THIS_FOLDER, 'all_items_in_stock_run_result.txt')
text_file = open(my_file, "w")
text_file.write("===============================")
text_file.write("\n")
text_file.write(str(sys.argv[1]))
text_file.write("\n")
text_file.write("===============================")
text_file.write("\n")
text_file.write(datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
text_file.write("\n")
text_file.write('open script ')
text_file.write("\n")
psycopg2.extensions.register_type(psycopg2.extensions.UNICODE)
psycopg2.extensions.register_type(psycopg2.extensions.UNICODEARRAY)
if sys.argv[1] :
    conn = psycopg2.connect(f"dbname={sys.argv[1]} user=admin password=5445za host=localhost port=5432")
    conn.set_client_encoding('utf-8')
    ReOrderId = sys.argv[1]
    try:
        text_file.write('coonect to database ok ')
        text_file.write("\n")
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(
                "select item_idr, "
                " sum(items_count) as it_cou , "
                " ( select name from items_main where id= item_idr ) as name  "
                " from items_det  "
                " GROUP BY item_idr  "
                " having sum(items_count)<>0  "
                "  ORDER BY it_cou  "
                )
            qry = cur.fetchall()

            THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))
            my_file = os.path.join(THIS_FOLDER, "../static")
            my_file = os.path.join(my_file, 'all_items_in_stock.xlsx')
            workbook = xlsxwriter.Workbook(my_file)
            format_right_to_left = workbook.add_format({'reading_order': 2 , 'border': 1 })
            worksheet = workbook.add_worksheet()
            worksheet.right_to_left()
            worksheet.repeat_rows(0)    
            worksheet.set_landscape() 
            worksheet.set_header('&C&24 بيان بجميع الاصناف الموجودة   ')
            worksheet.set_footer('&Cصفحة &P من &N     &Rطبعة في  &D   &T')
            worksheet.set_margins(0.7 ,0.7,0.7,0.7)
            worksheet.set_paper(9)
            workbook.set_properties({
                'title':    'كشف بالاصناف',
                'subject':  'With document properties',
                'author':   'صدارة التطوير و البرمجة',
                'manager':  'Dr. Heinz Doofenshmirtz',
                'company':  'صدارة التطوير و البرمجة',
                'category': 'كشف',
                'keywords': 'Sample, Example, Properties',
                'comments': 'Created with Python and XlsxWriter',
                'status':   'Quo',
            })
            #worksheet.print_area('A1:J1')   
            worksheet.fit_to_pages(1, 0)  
            #worksheet.print_row_col_headers()
            # Start from the first cell. Rows and columns are zero indexed.
            row = 0
            col = 0
            worksheet.write(row, col    ,   'رقم الصنف')
            worksheet.write(row, col + 1,   'اسم الصنف')
            worksheet.write(row, col + 2,   'العدد')
            worksheet.write(row, col + 3,   'سعر الشراء')
            worksheet.write(row, col + 4,   'سعر البيع')
            worksheet.write(row, col + 5,   'الربح % ')
            worksheet.write(row, col + 6,   'الربح مبلغ ')
            worksheet.write(row, col + 7,   ' مج الشراء ')
            worksheet.write(row, col + 8,   ' مج البيع ')
            worksheet.write(row, col + 9,   ' مج الربح ')
            row += 1
            worksheet.set_column('A:A', 10)
            worksheet.set_column('B:B', 40)
            worksheet.set_column('C:C', 12)
            worksheet.set_column('D:D', 15)
            worksheet.set_column('E:E', 15)
            worksheet.set_column('F:F', 15)
            worksheet.set_column('G:G', 15)
            worksheet.set_column('H:H', 15)
            worksheet.set_column('I:I', 15)
            worksheet.set_column('J:J', 15)
            worksheet.set_column('K:K', 17)
            worksheet.set_column('L:L', 15)
            worksheet.set_column('M:M', 20)
            # Iterate over the data and write it out row by row.
            for r in qry :
                cur.execute(
                    f" select * from items_det where item_idr= {r['item_idr']} "
                    " order by id desc limit 1 "
                )
                items_det_row = cur.fetchone()
                cur.execute(
                    f" select item_id,item_group,(select name from key_type where id=item_type) as ty from items_main where id= {r['item_idr']} "
                    " order by id desc limit 1 "
                )
                itm_main = cur.fetchone()
                worksheet.write(row, col    ,   r['item_idr'])
                worksheet.write(row, col + 1,   r['name'])
                worksheet.write(row, col + 2,   round(float(r['it_cou']),2)  )
                worksheet.write(row, col + 3,   items_det_row['buy_price']  )
                worksheet.write(row, col + 4,   items_det_row['public_price']  )
                
                pr = (float(items_det_row['public_price']) - float(items_det_row['buy_price']))
                if float(items_det_row['buy_price']) == 0 :
                    per= ((float(items_det_row['public_price']) - float(items_det_row['buy_price']))/1)*100
                else :
                    per= ((float(items_det_row['public_price']) - float(items_det_row['buy_price']))/float(items_det_row['buy_price']))*100
                worksheet.write(row, col + 5,   round(per,2)  )
                worksheet.write(row, col + 6,   round(pr,2)  )
                worksheet.write(row, col + 7,   round((items_det_row['buy_price'] *r['it_cou'] ),2)  )
                worksheet.write(row, col + 8,   round((items_det_row['public_price'] *r['it_cou'] ),2)  )
                worksheet.write(row, col + 9,   round((pr*r['it_cou'] ),2)  )
                worksheet.write(row, col + 10,  itm_main['ty']   )
                worksheet.write(row, col + 11,  itm_main['item_group']   )
                worksheet.write(row, col + 12,  itm_main['item_id']   )
                row += 1
            bold = workbook.add_format()
            bold.set_font_size(12)
            bold.set_align('center')
            bold.set_bold()
            bold.set_font_name('Calibri')
            worksheet.add_table('A1:M'+str(row+1 ),  {'total_row': True ,
            'columns':[
                {'header': u'رقم الصنف' ,       'header_format' : bold , 'total_string': 'الاجمالي' },
                {'header': u'اسم الصنف' ,       'header_format' : bold , 'total_function': 'count' },
                {'header': u'العدد' ,           'header_format' : bold , 'total_function': 'sum'  },
                {'header': u'سعر الشراء' ,      'header_format' : bold , 'total_function': 'sum'  },
                {'header': u'سعر البيع' ,       'header_format' : bold , 'total_function': 'sum' },
                {'header': u'الربح %',          'header_format' : bold , 'total_function': 'average' },
                {'header': u' الربح مبلغ' ,     'header_format' : bold , 'total_function': 'sum' },
                {'header': u'مج الشراء' ,       'header_format' : bold , 'total_function': 'sum' },
                {'header': u'مج البيع' ,        'header_format' : bold , 'total_function': 'sum' },
                {'header': u'مج الربح' ,        'header_format' : bold , 'total_function': 'sum' },
                {'header': u'التصنيف' ,         'header_format' : bold , 'total_string': ' ' },
                {'header': u'المجموعة' ,        'header_format' : bold , 'total_string': ' ' },
                {'header': u'الرقم الدولي' ,    'header_format' : bold , 'total_string': ' ' },
                ] , 'autofilter': False , 'style': 'Table Style Light 8'    })
            workbook.close()
            text_file.write('write to excle file ok ')
            text_file.write("\n")
        conn.close()
    except :
        # print str(e) 
        print("Unexpected error:", sys.exc_info())
        my_file2 = os.path.join(THIS_FOLDER, 'all_items_in_stock_err.txt')
        text_file2 = open(my_file2, "w")
        text_file2.write(str(sys.exc_info()[0]))
        text_file2.write("\n")
        text_file2.write(str(sys.exc_info()))
        text_file2.close()
    finally:
        if conn is not None:
            conn.close()
text_file.close()