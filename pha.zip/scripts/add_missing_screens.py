# -*- coding: utf-8 -*-
"""
إضافة الشاشات غير المسجلة في جدول screens
تشغيل: uv run web2py.py -S asbab5 -M -R scripts/add_missing_screens.py
"""

new_screens = [
    # مراقبة المخزون
    {"systems": 1, "name": "حالات البيع بدون رصيد", "screen_code": 5300},
    {"systems": 1, "name": "اعتماد مراجعة حالات البيع بدون رصيد", "screen_code": 5301},
    # شؤون الموظفين
    {"systems": 1, "name": "الحضور والانصراف", "screen_code": 7001},
    {"systems": 1, "name": "استعراض الموظفين", "screen_code": 7002},
    {"systems": 1, "name": "المرتبات", "screen_code": 7003},
    {"systems": 1, "name": "السلف", "screen_code": 7004},
    {"systems": 1, "name": "الإجازات", "screen_code": 7005},
    {"systems": 1, "name": "كشف الرواتب", "screen_code": 7006},
    {"systems": 1, "name": "ملفاتي", "screen_code": 7007},
    # إقفال الفترات
    {"systems": 1, "name": "إقفال الفترات", "screen_code": 8001},
    # تقارير المبيعات
    {"systems": 1, "name": "تقارير المبيعات - التقرير 1", "screen_code": 8101},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 2", "screen_code": 8102},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 3", "screen_code": 8103},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 4", "screen_code": 8104},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 5", "screen_code": 8105},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 6", "screen_code": 8106},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 7", "screen_code": 8107},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 8", "screen_code": 8108},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 10", "screen_code": 8110},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 11", "screen_code": 8111},
    {"systems": 1, "name": "تقارير المبيعات - التقرير 12", "screen_code": 8112},
    # تقارير الأصناف
    {"systems": 1, "name": "تقارير الأصناف - التقرير 1", "screen_code": 8201},
    {"systems": 1, "name": "تقارير الأصناف - تقرير التجهيز", "screen_code": 8202},
    # الضريبة
    {"systems": 1, "name": "الضريبة - التقرير الرئيسي", "screen_code": 9001},
    {"systems": 1, "name": "الضريبة - تقرير 11", "screen_code": 9002},
    {"systems": 1, "name": "الضريبة - تقرير 12", "screen_code": 9003},
    {"systems": 1, "name": "الضريبة - تقرير 13", "screen_code": 9004},
    # زاتكا
    {"systems": 1, "name": "زاتكا - حالة الربط", "screen_code": 9101},
    {"systems": 1, "name": "زاتكا - توليد CSR وطلب CSID", "screen_code": 9102},
    {"systems": 1, "name": "زاتكا - التسجيل الإنتاجي", "screen_code": 9103},
]

added = 0
skipped = 0
for s in new_screens:
    exists = db(db.screens.screen_code == s["screen_code"]).select().first()
    if not exists:
        db.screens.insert(systems=s["systems"], name=s["name"], screen_code=s["screen_code"])
        added += 1
        print("Added:", s["screen_code"])
    else:
        skipped += 1
        print("Skipped (exists):", s["screen_code"])

db.commit()
print("\nDone. Added:", added, "Skipped:", skipped)
