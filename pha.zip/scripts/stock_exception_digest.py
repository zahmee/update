# -*- coding: utf-8 -*-
"""ملخص يومي بالرسائل النصية لحالات البيع بدون رصيد.

يُرسل رسالة واحدة للمدير آخر اليوم بعدد الحالات وتوزيعها على البائعين.
لا يُرسل شيئاً إذا لم تقع أي حالة — حتى لا تعتاد تجاهل الرسالة.

التشغيل يومياً (من مجلد web2py):
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/stock_exception_digest.py

ليوم محدد بدل اليوم الحالي:
    ... -R applications/asbab5/scripts/stock_exception_digest.py -A 2026-07-25
"""
import sys
from datetime import datetime, timedelta

import send_sms as sms

ADMIN_MOBILE = "+966500550300"   # نفس رقم تنبيهات زاتكا في send_invoice.py
MAX_NAMES = 4                     # أسماء البائعين المذكورة في الرسالة


def _target_day():
    arg = None
    for a in (sys.argv[1:] if len(sys.argv) > 1 else []):
        if a and a[0].isdigit():
            arg = a
            break
    if arg:
        try:
            return datetime.strptime(arg, "%Y-%m-%d").date()
        except ValueError:
            pass
    return datetime.now().date()


day = _target_day()
start = datetime.combine(day, datetime.min.time())
end = datetime.combine(day, datetime.max.time())

rows = db.executesql(
    "SELECT COALESCE(u.first_name || ' ' || u.last_name, 'غير معروف') AS name,"
    "       COUNT(*) AS cases,"
    "       ROUND(SUM(e.shortfall)::numeric, 1) AS units"
    "  FROM stock_exception e"
    "  LEFT JOIN auth_user u ON u.id = e.cashier"
    " WHERE e.happened_on BETWEEN %s AND %s"
    " GROUP BY 1 ORDER BY cases DESC",
    placeholders=[start, end], as_dict=True)

if not rows:
    print("لا توجد حالات في %s — لم تُرسل رسالة." % day)
else:
    total = sum(int(r["cases"]) for r in rows)
    units = round(sum(float(r["units"] or 0) for r in rows), 1)
    parts = ["%s %d" % (r["name"].strip(), int(r["cases"])) for r in rows[:MAX_NAMES]]
    if len(rows) > MAX_NAMES:
        parts.append("وآخرون %d" % sum(int(r["cases"]) for r in rows[MAX_NAMES:]))

    msg = "بيع بدون رصيد %s\nالحالات %d - وحدات %s\n%s" % (
        day.strftime("%m-%d"), total, units, " | ".join(parts))

    dry = any("dry" in str(a).lower() for a in sys.argv[1:])
    if dry:
        print("[تجربة بدون إرسال]")
    else:
        try:
            p = sms.SMS(sms_authorization, sms_sender)
            res = p.send(ADMIN_MOBILE, msg)
            print("أُرسلت الرسالة:", res)
        except Exception as e:
            print("تعذّر إرسال الرسالة:", e)
    print("---\n" + msg)

db.commit()
