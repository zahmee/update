# -*- coding: utf-8 -*-
import sys
import psycopg2
import psycopg2.extras
import psycopg2.extensions
import os
import datetime
import math

THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))
my_file = os.path.join(THIS_FOLDER, "reorder_run_result.txt")
text_file = open(my_file, "w")
text_file.write("===============================")
text_file.write("\n")
text_file.write(str(sys.argv[1]))
text_file.write("\n")
text_file.write("===============================")
text_file.write("\n")
text_file.write(datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
text_file.write("\n")
text_file.write("open script ")
text_file.write("\n")
psycopg2.extensions.register_type(psycopg2.extensions.UNICODE)
psycopg2.extensions.register_type(psycopg2.extensions.UNICODEARRAY)
if sys.argv[1]:
    conn = psycopg2.connect(
        f"dbname={sys.argv[2]} user=admin password=5445za host=localhost port=5432"
    )
    conn.set_client_encoding("utf-8")
    ReOrderId = sys.argv[1]
    try:
        text_file.write("connect to database ok ")
        text_file.write("\n")
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute("SELECT * FROM items_reorder where id=%s", (ReOrderId,))
            Order = cur.fetchone()
            start_time = datetime.datetime.now().strftime("%H:%M:%S")
            if (Order["supplier"]) and (Order["key_type"]):
                # print "all"
                cur.execute(
                    "SELECT * FROM items_main  where suppliers=%s and item_type=%s order by id ",
                    (
                        Order["supplier"],
                        Order["key_type"],
                    ),
                )
                qry = cur.fetchall()
            elif Order["key_type"] != None:
                # print "type only"
                cur.execute(
                    "SELECT * FROM items_main  where item_type=%s order by id ",
                    (Order["key_type"],),
                )
                qry = cur.fetchall()
            elif Order["supplier"] != "":
                # print "suppliers only"
                cur.execute(
                    "SELECT * FROM items_main  where suppliers=%s order by id ",
                    (Order["supplier"],),
                )
                qry = cur.fetchall()
            row_count = cur.rowcount
            # =================================================================================================
            cur.execute(
                "delete FROM items_reorder_detail  where items_reorder=%s ",
                (Order["id"],),
            )
            conn.commit()
            # print(sys.getsizeof(qry))
            # print(len(qry))
            text_file.write("get all  items to work :"+datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S") )
            text_file.write("\n")
            for r in qry:
                cur.execute(
                    "SELECT sum(items_count) FROM items_det where item_idr=%s ",
                    (r["id"],),
                )
                sum_row = cur.fetchone()[0]
                if sum_row:
                    sum_row = round(float(sum_row), 2)
                else:
                    sum_row = 0
                avrg_itms_qry = (
                    "select sum(item_count) from  invoice_details "
                    " where item_number in (select id from items_det where item_idr =  "
                    + str(r["id"])
                    + " )"
                    " and created_on> date_trunc('month', CURRENT_DATE) - INTERVAL '"
                    + str(Order["avrg_by"])
                    + " month'  "
                )
                cur.execute(avrg_itms_qry)
                #---------------------
                #          ok
                #---------------------
                avrg_itms = cur.fetchone()[0]
                avrg_item = ((avrg_itms or 0) / Order["avrg_by"]) or 0
                best_price_qry = (
                    " select min(buy_price)  from  items_det  "
                    "     where item_idr =  " + str(r["id"]) + "  "
                    "     and buy_price > 0  "
                    "     and created_on> date_trunc('month', CURRENT_DATE) - INTERVAL '"
                    + str(Order["avrg_by"])
                    + " month' "
                )
                cur.execute(best_price_qry)
                best_price_row = cur.fetchone()[0]
                # مشكلة سعر الشراء اذا كان الصنف لم يشترى خلال الفترة المحددة
                best_price = best_price_row or 0
                order_items = (avrg_item * Order["order_by"]) - (sum_row or 0)
                if (order_items) < (avrg_item / 2):
                    order_items = 0
                if order_items < 0:
                    order_items = 0
                cur.execute("select * from items_main where id=%s", (r["id"],))
                items_main = cur.fetchone()
                # -------------------------- insert into table
                nr1 = (
                    f"insert into items_reorder_detail "
                    f"( items_reorder , items_main  ,supplier , key_type , quantity ,avrg_items ,order_items ,best_price )"
                    f" VALUES "
                    f" ( {Order['id']} , {r['id']} , {items_main['suppliers'] or 'NULL' } , {items_main['item_type'] or 'NULL' } , {round( ( sum_row or 0 ) , 2) } , "
                    f" {round(avrg_item  ,2)} , { math.ceil(order_items) } , {round(best_price,2)} )"
                )
                # print (nr1)
                cur.execute(nr1)
                conn.commit()
                #text_file.write(f"get one items to work {r['id']} :"+datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S") )
                #text_file.write("\n")
            end_time = datetime.datetime.now().strftime("%H:%M:%S")
            # print(end_time)
            cur.execute(
                f"update items_reorder set jop_end_time='{end_time}' , jop_start_time='{start_time}' ,row_count={row_count} where id={ReOrderId} "
            )
            conn.commit()
            text_file.write("write to database ok ")
            text_file.write("\n")
            text_file.write("finsh all the work .")
            text_file.write("\n")
            text_file.write(datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
            text_file.write("\n")

        conn.close()
    except:
        # print str(e)
        print("Unexpected error:", sys.exc_info())
        my_file2 = os.path.join(THIS_FOLDER, "reorder_err.txt")
        text_file2 = open(my_file2, "w")
        text_file2.write(str(sys.exc_info()[0]))
        text_file2.write("\n")
        text_file2.write(str(sys.exc_info()))
        text_file2.close()
    finally:
        if conn is not None:
            conn.close()
    text_file.close()
    # stats = pstats.Stats(pr)
    # stats.sort_stats(pstats.SortKey.TIME)
    # stats.print_stats()
