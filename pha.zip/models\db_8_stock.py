# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
#  وحدة المخزون المركزية (Stock Core)
# ===========================================================================================
#  المصدر الوحيد لتعديل كميات المخزون في النظام.
#
#  القاعدة: أي تعديل على items_det.items_count يجب أن يمر من هنا، حتى يبقى
#  جدول الحركات items_movement مطابقاً للمخزون الفعلي في كل لحظة.
#
#  لا تعدّل items_count مباشرة في أي وحدة تحكم.
# ===========================================================================================

STOCK_EPS = 1e-9

# ===========================================================================================
#  جدول حالات البيع بدون رصيد (stock_exception)
# ===========================================================================================
#  البيع لا يُمنع أبداً عند نقص الرصيد: المنع يدفع العملية خارج الدفاتر (يأخذ
#  البائع المبلغ نقداً بلا أثر) فيتحول خلل محاسبي إلى باب سرقة.
#  البديل: البيع يمر، ويُسجَّل هنا منسوباً لاسم البائع للمراجعة.
#  الدلالة الحقيقية في النمط لا في الحادثة: بائع بعشرات الحالات وزملاؤه بصفر.
db.define_table(
    "stock_exception",
    Field("invoice_uuid", length=50, label="رقم العملية"),
    Field("invoice_no", "integer", default=0, label="رقم الفاتورة"),
    Field("item_main", "reference items_main", label="الصنف"),
    Field("item_det", "integer", default=0, label="الدفعة"),
    Field("item_name", length=460, label="اسم الصنف"),
    Field("item_code", length=20, label="رقم الصنف"),
    Field("qty_requested", "double", default=0, label="الكمية المباعة"),
    Field("qty_available", "double", default=0, label="الرصيد وقتها"),
    Field("shortfall", "double", default=0, label="العجز"),
    Field("unit_price", "double", default=0, label="سعر البيع"),
    Field("cashier", "reference auth_user", label="البائع"),
    Field("happened_on", "datetime", default=request.now, label="الوقت"),
    Field("status", length=20, default="open",
          requires=IS_IN_SET(["open", "reviewed"]), label="الحالة"),
    Field("review_note", "text", label="ملاحظة المراجعة"),
    Field("reviewed_by", "reference auth_user", label="راجعها"),
    Field("reviewed_on", "datetime", label="وقت المراجعة"),
)
db.stock_exception.id.label = "م"


def stock_log_exception(invoice_uuid, invoice_no, item_main, item_det,
                        qty_requested, qty_available, unit_price=0):
    """يسجّل حالة بيع بدون رصيد منسوبة للمستخدم الحالي."""
    m = db.items_main(item_main)
    return db.stock_exception.insert(
        invoice_uuid=str(invoice_uuid or "")[:50],
        invoice_no=int(invoice_no or 0),
        item_main=item_main,
        item_det=int(item_det or 0),
        item_name=(m.name if m else "")[:460],
        item_code=(m.item_id if m else "")[:20],
        qty_requested=float(qty_requested or 0),
        qty_available=float(qty_available or 0),
        shortfall=round(float(qty_requested or 0) - float(qty_available or 0), 6),
        unit_price=float(unit_price or 0),
        cashier=auth.user_id,
        happened_on=request.now,
        status="open",
    )


def _stock_row(det):
    """يقبل رقم الدفعة أو صف الدفعة ويعيد الصف."""
    if det is None:
        return None
    if isinstance(det, (int, float)):
        return db.items_det(int(det))
    if isinstance(det, str):
        return db.items_det(int(det)) if det.strip().isdigit() else None
    return det


def _stock_row_locked(det):
    """يعيد صف الدفعة بقراءة محدّثة مقفولة (SELECT ... FOR UPDATE).

    تعديل الكمية هو قراءة ثم كتابة: لو قرأ مساران متزامنان القيمة نفسها
    (بيع ومرتجع على الدفعة ذاتها مثلاً) لكتب كل منهما فوق الآخر، فيضيع
    أحد التعديلين ويختلف المخزون عن الدفتر بصمت حتى الجرد القادم.
    القفل هنا يجعل كل مسارات التعديل آمنة من مكان واحد، ولا يضر المسارات
    التي تقفل مسبقاً (البيع عبر stock_lock_items) لأن القفل داخل المعاملة
    الواحدة لا يتعارض مع نفسه.
    """
    row = _stock_row(det)
    if row is None:
        return None
    return db(db.items_det.id == int(row.id)).select(
        for_update=True, limitby=(0, 1)
    ).first()


def _stock_apply(row, delta, move_type, reference="", ref_no="", unit_price=None, when=None):
    """التنفيذ الفعلي للحركة. يفترض أن الصف مقروء مقفولاً بالفعل."""
    delta = float(delta or 0)
    if abs(delta) < STOCK_EPS:
        return float(row.items_count or 0)

    new_val = round(float(row.items_count or 0) + delta, 6)
    row.update_record(items_count=new_val)

    if unit_price is None:
        unit_price = float(row.public_price or 0)
    db.items_movement.insert(
        item_main=row.item_idr,
        item_det=int(row.id),
        move_type=move_type,
        move_date=when or request.now,
        qty_in=delta if delta > 0 else 0,
        qty_out=(-delta) if delta < 0 else 0,
        unit_price=float(unit_price or 0),
        reference=(reference or "")[:270],
        ref_no=str(ref_no or "")[:50],
    )
    return new_val


def stock_move(det, delta, move_type, reference="", ref_no="", unit_price=None, when=None):
    """يعدّل كمية الدفعة ويسجّل الحركة في نفس اللحظة.

    delta موجب = وارد للمخزون، سالب = صادر منه.
    يعيد الكمية الجديدة للدفعة.
    """
    row = _stock_row_locked(det)
    if row is None:
        raise ValueError("سطر المخزون غير موجود")
    return _stock_apply(row, delta, move_type, reference, ref_no, unit_price, when)


def stock_set(det, new_qty, move_type, reference="", ref_no="", unit_price=None):
    """يضبط كمية الدفعة على قيمة مطلقة ويسجّل الفارق كحركة."""
    row = _stock_row_locked(det)
    if row is None:
        raise ValueError("سطر المخزون غير موجود")
    delta = float(new_qty or 0) - float(row.items_count or 0)
    if abs(delta) < STOCK_EPS:
        return float(row.items_count or 0)
    return _stock_apply(row, delta, move_type, reference, ref_no, unit_price)


def stock_lock_items(item_ids):
    """يقفل كل دفعات الأصناف المطلوبة (SELECT ... FOR UPDATE) بترتيب ثابت
    لمنع التعارض التزامني والـ deadlock. يعيد قاموساً {رقم_الصنف: [الدفعات]}."""
    ids = sorted({int(i) for i in item_ids if i})
    out = {}
    if not ids:
        return out
    rows = db(db.items_det.item_idr.belongs(ids)).select(
        orderby=db.items_det.id, for_update=True
    )
    for r in rows:
        out.setdefault(int(r.item_idr), []).append(r)
    return out


def stock_lock_dets(det_ids):
    """يقفل دفعات بعينها بترتيب تصاعدي ثابت لأرقامها.

    الترتيب هو ما يمنع الـ deadlock: أي مسار يعدّل أكثر من دفعة في نفس
    العملية يجب أن يقفلها بنفس الترتيب الذي يستخدمه البيع (stock_lock_items
    يقفل بترتيب id أيضاً)، وإلا أمكن أن ينتظر كل مسار قفلاً بيد الآخر.
    """
    ids = sorted({int(i) for i in det_ids if i})
    if not ids:
        return []
    return db(db.items_det.id.belongs(ids)).select(
        orderby=db.items_det.id, for_update=True
    )


def stock_item_available(item_idr, batches=None):
    """الرصيد الصافي للصنف عبر كل دفعاته (الموجبة والسالبة معاً).

    يجب أن يكون الصافي لا مجموع الموجب وحده: صنف دفعاته (-50, +10) رصيده
    الحقيقي -40، فلو حسبنا الموجب وحده (10) لسمحنا ببيع يزيد السالب سوءاً.
    """
    if batches is not None:
        return sum(float(r.items_count or 0) for r in batches)
    s = db.items_det.items_count.sum()
    r = db(db.items_det.item_idr == item_idr).select(s).first()
    return float((r[s] if r else 0) or 0)


def _info_num(field_name, fallback):
    """قراءة رقم من إعدادات النظام مع قيمة احتياطية."""
    try:
        info = db(db.important_info.id > 0).select(
            db.important_info[field_name], limitby=(0, 1)
        ).first()
        v = float(info[field_name] or 0) if info else 0.0
        return v if v > 0 else float(fallback)
    except Exception:
        return float(fallback)


def stock_max_line_qty():
    """أقصى كمية مسموحة في سطر فاتورة واحد — فوقها يُرفض السطر.

    الغرض: منع الخطأ الشائع بإدخال رقم الصنف (الباركود، 8-19 خانة) في خانة
    الكمية، فينتج سطر بكمية فلكية يفسد الفاتورة والمخزون والتقارير.
    """
    return _info_num("max_line_qty", 1000)


def stock_confirm_line_qty():
    """الكمية التي يبدأ عندها طلب تأكيد الكاشير (دون رفض)."""
    return _info_num("confirm_line_qty", 100)


def stock_invoice_warn_amount():
    """إجمالي الفاتورة الذي يستدعي تنبيهاً — تأكيد فقط، لا يمنع الحفظ."""
    return _info_num("invoice_warn_amount", 3000)


def stock_qty_looks_like_barcode(qty, item_main_row):
    """هل الكمية المُدخلة هي رقم الصنف نفسه؟ (تشخيص دقيق للخطأ الشائع)"""
    code = str((item_main_row.item_id if item_main_row else "") or "").strip()
    if not code or not code.isdigit():
        return False
    try:
        q = float(qty)
    except (TypeError, ValueError):
        return False
    if q != int(q):
        return False
    return str(int(q)) == code


def stock_tracked(item_idr):
    """هل يُتابَع مخزون هذا الصنف؟

    الأصناف الخدمية/الوهمية (مثل صنف "هللة" المستخدم لتقريب الفواتير) تُباع
    باستمرار ولا تُشترى أبداً، فرصيدها سالب دائماً بطبيعتها. منع البيع منها
    يوقف الفوترة بلا سبب. القيمة الفارغة (الأصناف القديمة) تعني: تُتابَع.
    """
    m = db.items_main(item_idr)
    if not m:
        return True
    return True if m.track_stock is None else bool(m.track_stock)


# ملاحظة مقصودة: لا توجد هنا دالة "هل يُسمح بالبيع بالسالب؟" ولا يجوز إعادتها.
# البيع لا يُمنع أبداً عند نقص الرصيد (قرار المالك ٢٠٢٦-٠٧-٢٦، انظر أعلى الملف)،
# فأي إعداد يشترط الرصيد سيعيد المنع الذي رُفض صراحةً. الحقل
# important_info.allow_negative_stock باقٍ في الجدول لأسباب تاريخية فقط،
# وهو غير معروض في أي شاشة ولا يقرأه أي كود.


def stock_plan_sale(batches, qty, preferred_det_id=None):
    """يوزّع كمية البيع على دفعات الصنف: الدفعة المختارة أولاً، ثم الأقرب
    انتهاءً فالأقدم. لا يسمح لأي دفعة بالنزول تحت الصفر.

    يعيد (التوزيع، النقص) حيث التوزيع قائمة (صف_الدفعة، الكمية).
    """
    remaining = float(qty or 0)
    plan = []
    if remaining <= STOCK_EPS:
        return plan, 0.0

    def _take(row):
        nonlocal remaining
        avail = float(row.items_count or 0)
        if avail <= STOCK_EPS or remaining <= STOCK_EPS:
            return
        take = avail if avail < remaining else remaining
        plan.append((row, round(take, 6)))
        remaining = round(remaining - take, 6)

    # 1) الدفعة التي اختارها الكاشير أولاً
    if preferred_det_id:
        for r in batches:
            if int(r.id) == int(preferred_det_id):
                _take(r)
                break

    # 2) باقي الدفعات: الأقرب انتهاءً أولاً (FEFO) ثم الأقدم إدخالاً
    def _key(r):
        return (r.expiration_date is None, r.expiration_date, r.id)

    for r in sorted(batches, key=_key):
        if preferred_det_id and int(r.id) == int(preferred_det_id):
            continue
        _take(r)

    return plan, max(remaining, 0.0)


def stock_repair_item(item_idr):
    """يصلح الأرصدة السالبة لصنف بتوزيعها على دفعاته الموجبة.

    العملية محايدة تماماً: إجمالي الصنف قبل الإصلاح = إجماليه بعده،
    لذلك لا تُسجَّل حركة (لا وارد ولا صادر — مجرد إعادة توزيع داخلية).

    يعيد (نجح، الكمية_المعالجة).
    لا ينجح إذا كان إجمالي الصنف نفسه سالباً — عندها الحل شراء أو جرد.
    """
    rows = db(db.items_det.item_idr == item_idr).select(orderby=db.items_det.id)
    negatives = [r for r in rows if float(r.items_count or 0) < 0]
    if not negatives:
        return True, 0.0

    positives = [r for r in rows if float(r.items_count or 0) > 0]
    deficit = -sum(float(r.items_count or 0) for r in negatives)
    available = sum(float(r.items_count or 0) for r in positives)

    # لا يجوز الإصلاح إذا لم تكفِ الموجبات — وإلا اخترعنا كمية من العدم
    if available + STOCK_EPS < deficit:
        return False, 0.0

    for r in negatives:
        r.update_record(items_count=0)

    remaining = deficit
    for r in positives:
        if remaining <= STOCK_EPS:
            break
        c = float(r.items_count or 0)
        take = c if c < remaining else remaining
        r.update_record(items_count=round(c - take, 6))
        remaining = round(remaining - take, 6)

    return True, deficit


def stock_repair_bill_items(supplier_inv):
    """يصلح الأرصدة السالبة لكل أصناف فاتورة توريد. يعيد عدد الأصناف المصلحة."""
    rows = db(db.items_det.supplier_inv == supplier_inv).select(
        db.items_det.item_idr, distinct=True
    )
    fixed = 0
    for r in rows:
        ok, amount = stock_repair_item(r.item_idr)
        if ok and amount > 0:
            fixed += 1
    return fixed


def stock_purchase_logged(det_id):
    """هل سُجّلت حركة شراء لهذه الدفعة من قبل؟ (لمنع التسجيل المزدوج)."""
    return db(
        (db.items_movement.item_det == int(det_id))
        & (db.items_movement.move_type == "شراء")
    ).count() > 0
