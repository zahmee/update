# -*- coding: utf-8 -*-
"""Read-only activity for supplier/customer cards, using the transaction tables.

Supplier returns are account entries of types 3/4; do not also sum their return
documents, which would count approved returns twice. Discounts (type 2) are not
payments. Customer adjustments (type 20) are not payments either.
"""
import logging
import re
from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

import api_helpers as api


class ActivityError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _party_id(value):
    if not re.fullmatch(r"[1-9][0-9]{0,9}", str(value or "")):
        raise ActivityError("رقم السجل غير صالح.")
    number = int(value)
    if number > 2147483647:
        raise ActivityError("رقم السجل غير صالح.")
    return number


def _require_party(db, table, value):
    number = _party_id(value)
    if not db(table.id == number).select(table.id, limitby=(0, 1)).first():
        raise ActivityError("لم يتم العثور على السجل.", 404)
    return number


def _money(value):
    if value is None:
        return None
    try:
        number = Decimal(str(value))
        if number.is_finite():
            return float(number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError, TypeError):
        pass
    return None


def _period(now):
    today = now.date() if isinstance(now, datetime) else now
    start = datetime.combine(today - timedelta(days=89), time.min)
    end = datetime.combine(today + timedelta(days=1), time.min)
    return today, start, end


def _latest(db, table, query, date_field, amount_field, extra, today):
    # PostgreSQL permits dates beyond Python's year range (legacy data contains
    # one). Read the date as text so one malformed date cannot break the card.
    date_text = date_field.cast("text")
    fields = [table.id, date_text, amount_field] + list(extra)
    # Explicitly exclude null dates before sorting: PostgreSQL DESC puts NULL first.
    row = db(query & (date_field != None)).select(
        *fields, orderby=~date_field | ~table.id, limitby=(0, 1)
    ).first()
    if row is None:
        row = db(query).select(*fields, orderby=~table.id, limitby=(0, 1)).first()
    if row is None:
        return None, None
    occurred, invalid_date, day = row[date_text], False, None
    if occurred:
        try:
            day = datetime.fromisoformat(occurred).date()
        except (ValueError, TypeError):
            invalid_date = True
    record = row[table._tablename]
    return record, dict(
        id=int(record.id), date=occurred, invalid_date=invalid_date,
        future=bool(day and day > today), amount=_money(record[amount_field]),
        reference=str(record.id), reference_label="رقم الفاتورة", detail="", badges=[],
    )


def _totals(db, table, query, date_field, amount_field, start, end):
    if date_field.type == "date":
        start, end = start.date(), end.date()
    count, amounts, total = table.id.count(), amount_field.count(), amount_field.sum()
    row = db(query & (date_field >= start) & (date_field < end)).select(count, amounts, total).first()
    size = int(row[count] or 0)
    return dict(count=size, amount=_money(row[total]) if size else 0.0,
                missing_amounts=size - int(row[amounts] or 0))


def _event(db, key, title, empty, table, query, date_field, amount_field,
           extra, period_query, period_label, today, start, end):
    row, latest = _latest(db, table, query, date_field, amount_field, extra, today)
    event = dict(key=key, title=title, empty=empty, latest=latest,
                 period_label=period_label,
                 period=_totals(db, table, period_query, date_field, amount_field, start, end))
    return row, event


def _lookup(db, table):
    return {int(row.id): row.name for row in db(table.id > 0).select(table.id, table.name)}


def customer_activity(db, value, now):
    customer_id = _require_party(db, db.customers, value)
    today, start, end = _period(now)
    methods = _lookup(db, db.key_payment_method)
    events = []
    for table, key, title, empty in (
        (db.invoice_master, "invoice", "آخر فاتورة بيع", "لا توجد فواتير بيع مسجلة."),
        (db.inv_return_master, "return", "آخر مرتجع مبيعات", "لا توجد مرتجعات مبيعات مسجلة."),
    ):
        query = table.customer == customer_id
        row, event = _event(
            db, key, title, empty, table, query, table.created_on, table.total_after_discount,
            [table.payment_method], query, "فواتير البيع" if key == "invoice" else "مرتجعات المبيعات",
            today, start, end,
        )
        if row:
            event["latest"]["detail"] = methods.get(row.payment_method, "طريقة الدفع غير محددة")
        events.append(event)

    table = db.customers_pay
    query = (table.customers_id == customer_id) & ((table.pay_type == None) | (table.pay_type != 20))
    row, event = _event(
        db, "payment", "آخر سداد", "لا توجد سدادات مسجلة.", table, query,
        table.created_on, table.amount, [table.pay_type], query, "السدادات دون التسويات", today, start, end,
    )
    if row:
        event["latest"]["reference_label"] = "رقم السند"
        event["latest"]["detail"] = "دعم الجمعية" if row.pay_type == 10 else "سداد نقدي"
    events.append(event)
    return dict(party_id=customer_id, events=events, pending=[],
                period_from=start.date().isoformat(), period_to=today.isoformat(),
                note="تشمل فواتير البيع جميع طرق الدفع. التسويات لا تُحتسب ضمن آخر سداد أو إحصاء السدادات.")


def supplier_activity(db, value, now):
    supplier_id = _require_party(db, db.suppliers, value)
    today, start, end = _period(now)
    methods = _lookup(db, db.key_payment_method)
    bills = db.suppliers_bills
    # Type 1 is purchases, matching the seed data and purchase workflow. Other
    # document types include gifts/compensation/quotations; they are not purchases.
    purchases = (bills.supplier == supplier_id) & (bills.invoce_type == 1)
    row, invoice = _event(
        db, "invoice", "آخر فاتورة شراء", "لا توجد فواتير شراء مسجلة.", bills, purchases,
        bills.bill_date, bills.bill_total, [bills.bill_no, bills.bill_confirmation, bills.payment_method],
        purchases & (bills.bill_confirmation == True), "فواتير الشراء المعتمدة", today, start, end,
    )
    if row:
        invoice["latest"]["reference"] = row.bill_no or str(row.id)
        invoice["latest"]["reference_label"] = "رقم فاتورة المورد" if row.bill_no else "الرقم الداخلي"
        invoice["latest"]["detail"] = methods.get(row.payment_method, "طريقة الدفع غير محددة")
        invoice["latest"]["badges"] = [dict(
            text="معتمدة" if row.bill_confirmation else "قيد الاعتماد",
            tone="success" if row.bill_confirmation else "warning",
        )]

    pay = db.suppliers_bills_pay
    entries = pay.supplier == supplier_id
    returns = entries & pay.payment_type.belongs((3, 4))
    row, returned = _event(
        db, "return", "آخر مرتجع مسجل", "لا توجد قيود مرتجعات مسجلة.", pay, returns,
        pay.pay_date, pay.pay_total, [pay.payment_type], returns, "قيود المرتجعات", today, start, end,
    )
    if row:
        returned["latest"]["reference_label"] = "رقم القيد"
        returned["latest"]["detail"] = "مرتجع فاتورة" if row.payment_type == 3 else "مرتجع أصناف"

    payments = entries & (pay.payment_type == 1)
    row, payment = _event(
        db, "payment", "آخر سداد للمورد", "لا توجد سدادات مستحقات مسجلة.", pay, payments,
        pay.pay_date, pay.pay_total, [pay.payment_method], payments, "سدادات المستحقات", today, start, end,
    )
    if row:
        payment["latest"]["reference_label"] = "رقم السند"
        payment["latest"]["detail"] = methods.get(row.payment_method, "طريقة الدفع غير محددة")

    pending_bills = db(purchases & ((bills.bill_confirmation == False) | (bills.bill_confirmation == None))).count()
    ret = db.returned_supply
    pending_returns = db((ret.supplier == supplier_id) & ((ret.admin_accept == False) | (ret.admin_accept == None))).count()
    return dict(party_id=supplier_id, events=[invoice, returned, payment],
                pending=[dict(label="فواتير شراء قيد الاعتماد", count=pending_bills),
                         dict(label="مرتجعات قيد الاعتماد", count=pending_returns)],
                period_from=start.date().isoformat(), period_to=today.isoformat(),
                note="المرتجعات حسب قيود حساب المورد، دون تكرار مستندات المرتجع. الخصم المكتسب ليس سدادًا، وإحصاء الشراء للمعتمد فقط.")


def respond(db, request, response, loader):
    response.headers["Cache-Control"] = "private, no-store"
    try:
        if request.env.request_method not in ("GET", "HEAD"):
            response.headers["Allow"] = "GET, HEAD"
            raise ActivityError("طريقة الطلب غير مسموحة.", 405)
        return response.json(api.api_ok(data=loader(db, request.args(0), request.now)))
    except ActivityError as error:
        response.status = error.status
        return response.json(api.api_error(mess=str(error)))
    except Exception:
        db.rollback()
        logging.getLogger("party_activity").exception("Could not load party activity")
        response.status = 500
        return response.json(api.api_error(mess="تعذّر تحميل إحصاءات النشاط. حاول مرة أخرى."))
