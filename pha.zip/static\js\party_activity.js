/* Shared read-only supplier/customer activity inside their existing cards. */
(function () {
    'use strict';
    var moneyFormat = new Intl.NumberFormat('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    Vue.component('party-activity', {
        props: {
            url: {type: String, required: true},
            partyId: {type: [Number, String], required: true},
            // compact = one-table summary that fits the card without scrolling (customers card).
            compact: {type: Boolean, default: false}
        },
        data: function () {
            return {activity: null, loading: false, error: '', sequence: 0};
        },
        watch: {partyId: {immediate: true, handler: function () { this.load(); }}},
        beforeDestroy: function () {
            this.sequence += 1;
            if (this.controller) this.controller.abort();
        },
        methods: {
            load: function () {
                var self = this;
                var sequence = ++this.sequence;
                if (this.controller) this.controller.abort();
                this.controller = new AbortController();
                this.activity = null;
                this.error = '';
                this.loading = true;
                fetch(this.url.replace(/\/$/, '') + '/' + encodeURIComponent(this.partyId), {
                    headers: {'Accept': 'application/json'}, signal: this.controller.signal,
                    credentials: 'same-origin', cache: 'no-store'
                }).then(function (response) { return response.json(); })
                  .then(function (payload) {
                      if (sequence !== self.sequence) return;
                      if (!Api.isOk(payload)) { self.error = Api.getError(payload); return; }
                      var activity = Api.getData(payload);
                      if (!activity || String(activity.party_id) !== String(self.partyId)) {
                          self.error = 'تعذّر عرض نشاط هذا السجل. حاول التحديث.';
                          return;
                      }
                      self.activity = activity;
                  }).catch(function (error) {
                      if (sequence === self.sequence && error.name !== 'AbortError') {
                          self.error = 'تعذّر تحميل إحصاءات النشاط. تحقق من الاتصال ثم اضغط تحديث.';
                      }
                  }).finally(function () {
                      if (sequence === self.sequence) self.loading = false;
                  });
            },
            money: function (value) {
                return value === null || value === undefined || !Number.isFinite(Number(value))
                    ? 'غير مسجل' : moneyFormat.format(Number(value));
            },
            date: function (value) {
                // These are local business dates; do not shift them through a UTC conversion.
                return value ? String(value).replace('T', ' ').slice(0, 16) : 'تاريخ غير مسجل';
            },
            icon: function (key) {
                return {invoice: 'fa-file-invoice', return: 'fa-undo-alt', payment: 'fa-hand-holding-usd'}[key];
            }
        },
        template: `
          <section class="party-activity" :class="{'party-activity-compact': compact}" aria-label="إحصاءات النشاط" :aria-busy="loading ? 'true' : 'false'">
            <div class="party-activity-heading">
              <div>
                <h6>آخر العمليات</h6>
                <p v-if="!compact">ملخص الفواتير والمرتجعات والسداد</p>
                <p v-else-if="activity">إحصاء ٩٠ يومًا: <bdi>{{ activity.period_from }}</bdi> إلى <bdi>{{ activity.period_to }}</bdi></p>
              </div>
              <button type="button" class="party-activity-refresh" @click="load" :disabled="loading" aria-label="تحديث إحصاءات النشاط">
                <i class="fas fa-sync-alt" :class="{'fa-spin': loading}" aria-hidden="true"></i> تحديث
              </button>
            </div>
            <div v-if="loading" class="party-activity-loading" role="status">
              <span class="spinner-border spinner-border-sm" aria-hidden="true"></span> جاري تحميل إحصاءات النشاط...
            </div>
            <div v-else-if="error" class="party-activity-error" role="alert">{{ error }}</div>
            <template v-else-if="activity && compact">
              <div class="party-activity-table-wrap">
                <table class="party-activity-table">
                  <thead>
                    <tr>
                      <th scope="col">العملية</th>
                      <th scope="col">المبلغ</th>
                      <th scope="col">التاريخ</th>
                      <th scope="col">الرقم</th>
                      <th scope="col" class="party-col-period">عدد ٩٠ يومًا</th>
                      <th scope="col" class="party-col-period">مجموع ٩٠ يومًا</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="event in activity.events" :key="event.key" :class="'party-row-' + event.key">
                      <th scope="row"><i class="fad fa-fw" :class="icon(event.key)" aria-hidden="true"></i> {{ event.title }}</th>
                      <template v-if="event.latest">
                        <td class="party-num" data-label="المبلغ"><bdi>{{ money(event.latest.amount) }}</bdi></td>
                        <td class="party-date" data-label="التاريخ">
                          <bdi>{{ date(event.latest.date) }}</bdi>
                          <span v-if="event.latest.future" class="party-tag party-badge-warning">تاريخ مستقبلي</span>
                          <span v-if="event.latest.invalid_date" class="party-tag party-badge-warning">تاريخ غير صالح</span>
                        </td>
                        <td class="party-ref" data-label="الرقم" :title="event.latest.reference_label">
                          <strong><bdi>{{ event.latest.reference }}</bdi></strong>
                          <span v-if="event.latest.detail" class="party-tag">{{ event.latest.detail }}</span>
                          <span v-for="(badge, index) in event.latest.badges" :key="index" class="party-tag" :class="'party-badge-' + badge.tone">{{ badge.text }}</span>
                        </td>
                      </template>
                      <td v-else colspan="3" class="party-row-empty">{{ event.empty }}</td>
                      <td class="party-num party-col-period" data-label="عدد ٩٠ يومًا" :title="event.period_label"><strong>{{ event.period.count }}</strong></td>
                      <td class="party-num party-col-period" data-label="مجموع ٩٠ يومًا" :title="event.period_label">
                        <bdi>{{ money(event.period.amount) }}</bdi>
                        <span v-if="event.period.missing_amounts" class="party-tag party-badge-warning" title="توجد مبالغ غير مسجلة">غير مكتمل</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="party-activity-pending" v-if="activity.pending.length">
                <span v-for="item in activity.pending" :key="item.label"><strong>{{ item.count }}</strong> {{ item.label }}</span>
              </div>
              <p class="party-activity-note">المبالغ بالريال. {{ activity.note }}</p>
            </template>
            <template v-else-if="activity">
              <div class="party-activity-grid">
                <article v-for="event in activity.events" :key="event.key" class="party-event" :class="'party-event-' + event.key">
                  <h6><i class="fad" :class="icon(event.key)" aria-hidden="true"></i> {{ event.title }}</h6>
                  <div v-if="event.latest" class="party-event-detail">
                    <div class="party-event-amount"><bdi>{{ money(event.latest.amount) }}</bdi><small v-if="event.latest.amount !== null">ريال</small></div>
                    <div class="party-event-date"><bdi>{{ date(event.latest.date) }}</bdi></div>
                    <div class="party-event-reference">{{ event.latest.reference_label }} <strong><bdi>{{ event.latest.reference }}</bdi></strong></div>
                    <div class="party-event-badges">
                      <span v-if="event.latest.detail">{{ event.latest.detail }}</span>
                      <span v-for="(badge, index) in event.latest.badges" :key="index" :class="'party-badge-' + badge.tone">{{ badge.text }}</span>
                      <span v-if="event.latest.future" class="party-badge-warning">تاريخ مستقبلي</span>
                      <span v-if="event.latest.invalid_date" class="party-badge-warning">تاريخ غير صالح</span>
                    </div>
                  </div>
                  <p v-else class="party-event-empty">{{ event.empty }}</p>
                  <div class="party-event-period">
                    <span class="party-period-label">{{ event.period_label }} · آخر ٩٠ يومًا</span>
                    <div><span><strong>{{ event.period.count }}</strong> عملية</span><span><bdi>{{ money(event.period.amount) }}</bdi> <small v-if="event.period.amount !== null">ريال</small></span></div>
                    <small v-if="event.period.missing_amounts" class="party-period-incomplete">المجموع غير مكتمل: توجد مبالغ غير مسجلة.</small>
                  </div>
                </article>
              </div>
              <div class="party-activity-pending" v-if="activity.pending.length">
                <span v-for="item in activity.pending" :key="item.label"><strong>{{ item.count }}</strong> {{ item.label }}</span>
              </div>
              <p class="party-activity-note">{{ activity.note }}</p>
              <p class="party-activity-range">فترة الإحصاء: <bdi>{{ activity.period_from }}</bdi> إلى <bdi>{{ activity.period_to }}</bdi></p>
            </template>
          </section>`
    });
}());
