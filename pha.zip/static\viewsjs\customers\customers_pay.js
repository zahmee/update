var API_BASE = window.location.href.replace(/\/customers\/customers_pay\/.*$/, '/customers_api/');
var PAY_CHARITY = 10;
var PAY_ADJUST = 20;  // تسوية رصيد: لا تُعدَّل ولا تُطبع سنداً، ويحذفها المدير فقط

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: { page: 0, RecordCount: 15, kind: '' },
        data_row_count: 0,
        stats: {
            credit_total: 0, total_amount: 0, adjust_amount: 0, balance: 0,
            counts: { all: 0, cash: 0, charity: 0, adjust: 0 },
        },
        selectedRow: -1,
        isNew: true,
        form: { amount: '', pay_type: '0', pay_note: '', note: '', send_sms: true },
        loading: false,
        saving: false,
        isAdmin: typeof IS_ADMIN !== 'undefined' && IS_ADMIN,
        hasMobile: typeof HAS_MOBILE !== 'undefined' && HAS_MOBILE,
    },
    created: function () {
        this.fetchData();
    },
    computed: {
        selected: function () {
            return this.data[this.selectedRow] || null;
        },
        selectedIsAdjust: function () {
            return !!this.selected && Number(this.selected.pay_type) === PAY_ADJUST;
        },
        // أزرار الفلتر: «الكل» دائماً، والباقي عند وجود سندات من نوعه
        kinds: function () {
            var c = this.stats.counts || {};
            var kind = this.getData.kind;
            return [
                { key: '', label: 'الكل', count: c.all || 0 },
                { key: 'cash', label: 'نقدي', count: c.cash || 0 },
                { key: 'charity', label: 'دعم الجمعية', count: c.charity || 0 },
                { key: 'adjust', label: 'تسويات', count: c.adjust || 0 },
            ].filter(function (k) { return k.key === '' || k.count > 0 || k.key === kind; });
        },
        formAmount: function () {
            var v = parseFloat(this.form.amount);
            return isFinite(v) && v > 0 ? v : 0;
        },
        balanceAfter: function () {
            return Math.round(((parseFloat(this.stats.balance) || 0) - this.formAmount) * 100) / 100;
        },
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        money: function (v) {
            return (parseFloat(v) || 0).toFixed(2);
        },
        balClass: function (v) {
            v = parseFloat(v) || 0;
            if (v > 0.005) return 'money-positive';   // عليه
            if (v < -0.005) return 'money-credit';    // له
            return 'money-clear';
        },
        balLabel: function (v) {
            v = parseFloat(v) || 0;
            if (v > 0.005) return 'عليه مديونية';
            if (v < -0.005) return 'له رصيد عندكم';
            return 'لا يوجد رصيد';
        },
        typeOf: function (row) {
            var t = Number(row && row.pay_type);
            if (t === PAY_ADJUST) return { label: 'تسوية رصيد', cls: 'cp-type-adjust' };
            if (t === PAY_CHARITY) return { label: 'دعم الجمعية', cls: 'cp-type-charity' };
            return { label: 'سداد نقدي', cls: 'cp-type-cash' };
        },
        // «0» تُكتب أحياناً في الملاحظات بلا معنى
        noteText: function (v) {
            v = (v === null || v === undefined) ? '' : String(v).trim();
            return v === '0' ? '' : v;
        },
        fmtDate: function (v) {
            return v ? String(v).replace('T', ' ').slice(0, 16) : '';
        },
        rowClass: function (row, index) {
            if (this.selectedRow === index) return 'customer-row-selected';
            return Number(row.pay_type) === PAY_ADJUST ? 'cp-row-adjust' : '';
        },
        fetchData: function () {
            var self = this;
            self.loading = true;
            var url = new URL(API_BASE + 'get_customers_pay');
            url.searchParams.append('customer_id', CUSTOMER_ID);
            url.searchParams.append('page', self.getData.page);
            url.searchParams.append('RecordCount', self.getData.RecordCount);
            url.searchParams.append('kind', self.getData.kind);
            fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); })
              .then(function (data) {
                  if (Api.isOk(data)) {
                      self.data = Api.getData(data);
                      self.data_row_count = data.count;
                      self.stats = {
                          credit_total: data.credit_total || 0,
                          total_amount: data.total_amount || 0,
                          adjust_amount: data.adjust_amount || 0,
                          balance: data.balance || 0,
                          counts: data.counts || { all: 0, cash: 0, charity: 0, adjust: 0 },
                      };
                  } else {
                      Api.showError(data);
                  }
              })
              .catch(function () { Swal.fire('خطأ', 'تعذّر تحميل السدادات.', 'error'); })
              .finally(function () { self.loading = false; });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.fetchData();
        },
        setKind: function (kind) {
            if (this.getData.kind === kind) return;
            this.getData.kind = kind;
            this.onChange();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.fetchData();
        },
        rowSelect: function (index) {
            this.selectedRow = index;
        },
        cancelSelect: function () {
            this.selectedRow = -1;
        },
        newPayClick: function () {
            this.isNew = true;
            // الرسالة مفعّلة في البداية، ويستطيع المستخدم إلغاءها لهذا السداد
            this.form = { amount: '', pay_type: '0', pay_note: '', note: '', send_sms: this.hasMobile };
        },
        editClick: function () {
            var row = this.selected;
            if (!row) return;
            this.isNew = false;
            this.form = {
                id: row.id,
                amount: row.amount,
                pay_type: String(row.pay_type || 0),
                pay_note: row.pay_note || '',
                send_sms: false,
            };
        },
        savePay: function () {
            var self = this;
            // الزر يُعطَّل أثناء الحفظ: النقر المتكرر كان يسجّل السداد نفسه عدة مرات
            if (self.saving) return;
            if (!self.form.amount || parseFloat(self.form.amount) <= 0) {
                Swal.fire('تنبيه', 'يجب إدخال مبلغ صحيح أكبر من صفر.', 'error');
                return;
            }
            var url;
            if (self.isNew) {
                url = new URL(API_BASE + 'save_coust_pay');
                url.searchParams.append('coust', CUSTOMER_ID);
                url.searchParams.append('mount', self.form.amount);
                url.searchParams.append('type', self.form.pay_type);
                url.searchParams.append('pay_note', self.form.pay_note || '');
                url.searchParams.append('note', self.form.note || '');
                url.searchParams.append('send_sms', self.form.send_sms && self.hasMobile ? '1' : '0');
            } else {
                url = new URL(API_BASE + 'edit_customers_pay');
                url.searchParams.append('id', self.form.id);
                url.searchParams.append('amount', self.form.amount);
                url.searchParams.append('pay_type', self.form.pay_type);
                url.searchParams.append('pay_note', self.form.pay_note || '');
            }
            self.saving = true;
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); })
              .then(function (data) {
                  if (Api.isOk(data)) {
                      bootstrap.Modal.getInstance(document.getElementById('payModal')).hide();
                      Swal.fire('تم', data.mess || (self.isNew ? 'تمت عملية الحفظ بنجاح' : 'تم التعديل بنجاح'), 'success');
                      self.selectedRow = -1;
                      self.fetchData();
                  } else {
                      Api.showError(data);
                  }
              })
              .catch(function () {
                  Swal.fire('خطأ', 'تعذّر الاتصال بالخادم. تحقق من السجل قبل إعادة المحاولة.', 'error');
              })
              .finally(function () { self.saving = false; });
        },
        deletePay: function () {
            var self = this;
            var row = self.selected;
            if (!row) return;
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: 'سيتم حذف السند رقم ' + row.id + ' بمبلغ ' + self.money(row.amount),
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                confirmButtonText: 'نعم، حذف',
                cancelButtonText: 'تراجع',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                var url = new URL(API_BASE + 'delete_customers_pay');
                url.searchParams.append('id', row.id);
                fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
                }).then(function (r) { return r.json(); })
                  .then(function (data) {
                      if (Api.isOk(data)) {
                          Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                          self.selectedRow = -1;
                          self.fetchData();
                      } else {
                          Api.showError(data);
                      }
                  })
                  .catch(function () { Swal.fire('خطأ', 'تعذّر الاتصال بالخادم.', 'error'); });
            });
        },
        printPay: function () {
            var row = this.selected;
            if (!row) return;
            window.open(window.location.href.replace(/\/customers_pay\/.*$/, '/pay_print/' + row.id), '_blank');
        },
    },
});
