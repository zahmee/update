var API_BASE = window.location.href.replace(/\/customers\/customers_pay\/.*$/, '/customers_api/');

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: { page: 0, RecordCount: 15 },
        data_row_count: 0,
        total_amount: 0,
        selectedRow: -1,
        isNew: true,
        form: { amount: '', pay_type: '0', pay_note: '', note: '' },
        loading: false,
    },
    created: function () {
        this.fetchData();
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function () {
            var self = this;
            self.loading = true;
            var url = new URL(API_BASE + 'get_customers_pay');
            url.searchParams.append('customer_id', CUSTOMER_ID);
            url.searchParams.append('page', self.getData.page);
            url.searchParams.append('RecordCount', self.getData.RecordCount);
            fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); })
              .then(function (data) {
                  if (Api.isOk(data)) {
                      self.data = Api.getData(data);
                      self.data_row_count = data.count;
                      self.total_amount = data.total_amount || 0;
                  } else {
                      Api.showError(data);
                  }
              }).finally(function () { self.loading = false; });
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.fetchData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
        },
        cancelSelect: function () {
            this.selectedRow = -1;
        },
        newPayClick: function () {
            this.isNew = true;
            this.form = { amount: '', pay_type: '0', pay_note: '', note: '' };
        },
        editClick: function () {
            this.isNew = false;
            var row = this.data[this.selectedRow];
            this.form = {
                id: row.id,
                amount: row.amount,
                pay_type: String(row.pay_type || 0),
                pay_note: row.pay_note || '',
            };
        },
        savePay: function () {
            var self = this;
            if (!self.form.amount || parseFloat(self.form.amount) <= 0) {
                Swal.fire('تنبيه', 'يجب إدخال مبلغ صحيح أكبر من صفر.', 'error');
                return;
            }
            if (self.isNew) {
                var url = new URL(API_BASE + 'save_coust_pay');
                url.searchParams.append('coust', CUSTOMER_ID);
                url.searchParams.append('mount', self.form.amount);
                url.searchParams.append('type', self.form.pay_type);
                url.searchParams.append('pay_note', self.form.pay_note);
                url.searchParams.append('note', self.form.note || '');
                fetch(url, { method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
                }).then(function (r) { return r.json(); })
                  .then(function (data) {
                      if (Api.isOk(data)) {
                          bootstrap.Modal.getInstance(document.getElementById('payModal')).hide();
                          Swal.fire('تم', 'تمت عملية الحفظ بنجاح', 'success');
                          self.selectedRow = -1;
                          self.fetchData();
                      } else {
                          Api.showError(data);
                      }
                  });
            } else {
                var url = new URL(API_BASE + 'edit_customers_pay');
                url.searchParams.append('id', self.form.id);
                url.searchParams.append('amount', self.form.amount);
                url.searchParams.append('pay_type', self.form.pay_type);
                url.searchParams.append('pay_note', self.form.pay_note);
                fetch(url, { method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
                }).then(function (r) { return r.json(); })
                  .then(function (data) {
                      if (Api.isOk(data)) {
                          bootstrap.Modal.getInstance(document.getElementById('payModal')).hide();
                          Swal.fire('تم', 'تم التعديل بنجاح', 'success');
                          self.selectedRow = -1;
                          self.fetchData();
                      } else {
                          Api.showError(data);
                      }
                  });
            }
        },
        deletePay: function () {
            var self = this;
            var row = self.data[self.selectedRow];
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: 'سيتم حذف السند رقم ' + row.id,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                confirmButtonText: 'نعم، حذف',
                cancelButtonText: 'تراجع',
            }).then(function (result) {
                if (result.isConfirmed) {
                    var url = new URL(API_BASE + 'delete_customers_pay');
                    url.searchParams.append('id', row.id);
                    fetch(url, { method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
                    }).then(function (r) { return r.json(); })
                      .then(function (data) {
                          if (Api.isOk(data)) {
                              Swal.fire('تم', 'تم الحذف بنجاح', 'success');
                              self.selectedRow = -1;
                              self.fetchData();
                          } else {
                              Api.showError(data);
                          }
                      });
                }
            });
        },
        printPay: function () {
            var row = this.data[this.selectedRow];
            window.open(window.location.href.replace(/\/customers_pay\/.*$/, '/pay_print/' + row.id), '_blank');
        },
    },
});
