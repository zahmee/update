# -*- coding: utf-8 -*-
"""ملفات إكسل لشاشة «تقارير عامة» (items_rep/items_report_crate).

تُبنى عند الطلب وتُنزَّل مباشرة من دالة محمية بـ can_access(8201). كانت تُكتب في static بعملية
خلفية، فتُنزَّل لأي أحد بلا تسجيل دخول، وينتظر المستخدم دقائق ثم يحدّث الصفحة.

قواعد الأرقام هي نفسها في بقية النظام:
- الرصيد = مجموع items_count لكل دفعات الصنف (stock_item_available).
- آخر سعر شراء = أحدث دفعة سعر شرائها > 0، وسعر البيع = item_rules.sale_price على أحدث دفعة
  مسعّرة، ونسبة الربح = (البيع قبل الضريبة − آخر شراء) ÷ آخر شراء، كبطاقة الصنف.
- تكلفة المخزون = مجموع (كمية الدفعة × سعر شرائها)، فالبضاعة المجانية تكلفتها صفر.
- سطر الفاتورة: amount سعر الوحدة قبل الضريبة، total شامل الضريبة، vat_total مبلغها. amount و total
  مخزّنان نصاً في القاعدة (رغم تعريفهما رقماً في النموذج)، فيُحوَّلان بـ _num.
- المرتجع بإشارة سالبة في كل الأعمدة، فمجموع أي عمود هو الصافي. تكلفة السطر = الكمية × سعر شراء
  الدفعة المباعة نفسها.
- صنف «هلله» (id 1) وأصناف الخدمة (track_stock='F') ليست مخزوناً.
"""
import io
from datetime import datetime, timedelta

import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell

import item_rules

XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MAX_SALES_DAYS = 366          # أطول فترة لتقرير المبيعات
STALE_DAYS_CHOICES = (90, 180, 365)
COVER_DAYS = 90               # نافذة المبيعات لحساب «يكفي لمدة»

# صفوف الورقة الجدولية: عنوان، وصف، إجمالي (أعلى الجدول ليبقى ظاهراً مع التجميد)، رؤوس، ثم البيانات
TITLE_ROW, NOTE_ROW, TOTAL_ROW, HEAD_ROW = 0, 1, 2, 3


def _num(col):
    """تحويل آمن لعمود نصي إلى رقم؛ القيمة غير الرقمية تُعد صفراً ولا تُسقط التقرير."""
    return (r"(CASE WHEN {0} ~ '^\s*-?[0-9]+(\.[0-9]+)?([eE][-+]?[0-9]+)?\s*$' "
            r"THEN {0}::float8 ELSE 0 END)").format(col)


# ────────────────────────────── التنسيق والكتابة ──────────────────────────────

def _formats(wb):
    base = {"font_name": "Segoe UI", "font_size": 10, "valign": "vcenter"}
    money = "#,##0.00;[Red]-#,##0.00"
    qty = "#,##0.##;[Red]-#,##0.##"
    tot = {"bold": True, "bg_color": "#E6F4F1", "top": 1, "bottom": 1, "border_color": "#9AD7CC"}

    def f(**kw):
        d = dict(base)
        d.update(kw)
        return wb.add_format(d)

    return {
        "title": f(bold=True, font_size=15, font_color="#134E4A"),
        "note": f(font_color="#667085"),
        "head": f(bold=True, font_color="#FFFFFF", bg_color="#0F766E", align="center",
                  text_wrap=True, border=1, border_color="#0B5F58"),
        "text": f(),
        "int": f(num_format="0"),
        "qty": f(num_format=qty),
        "money": f(num_format=money),
        "pct": f(num_format="0.0%;[Red]-0.0%"),
        "date": f(num_format="yyyy-mm-dd", align="center"),
        "dt": f(num_format="yyyy-mm-dd hh:mm", align="center"),
        "tot_label": f(**tot),
        "tot_blank": f(**tot),
        "tot_int": f(num_format="0", **tot),
        "tot_qty": f(num_format=qty, **tot),
        "tot_money": f(num_format=money, **tot),
        "tot_pct": f(num_format="0.0%;[Red]-0.0%", **tot),
        "section": f(bold=True, font_size=12, font_color="#134E4A", bottom=2, border_color="#0F766E"),
        "kpi_label": f(bold=True, font_color="#344054", bg_color="#F3F7F8", border=1, border_color="#D9E2EA"),
        "kpi_money": f(bold=True, font_size=11, num_format=money, border=1, border_color="#D9E2EA"),
        "kpi_int": f(bold=True, font_size=11, num_format="#,##0", border=1, border_color="#D9E2EA"),
        "kpi_qty": f(bold=True, font_size=11, num_format=qty, border=1, border_color="#D9E2EA"),
        "kpi_pct": f(bold=True, font_size=11, num_format="0.0%;[Red]-0.0%", border=1, border_color="#D9E2EA"),
        "kpi_text": f(bold=True, font_size=11, border=1, border_color="#D9E2EA"),
        "hint": f(font_color="#667085", italic=True),
    }


def _cell(ws, r, c, v, kind, fmt):
    if v is None or v == "":
        ws.write_blank(r, c, None, fmt[kind])
    elif kind == "text":
        # نص صريح: رقم دولي بأصفار في أوله يبقى كما هو، واسم يبدأ بـ = لا يُقرأ معادلة
        ws.write_string(r, c, str(v), fmt["text"])
    elif kind in ("date", "dt"):
        if getattr(v, "year", 0) < 1900:  # إكسل لا يعرض ما قبل 1900
            ws.write_string(r, c, str(v), fmt["text"])
        else:
            ws.write_datetime(r, c, v, fmt[kind])
    else:
        ws.write_number(r, c, float(v), fmt[kind])


def _sheet_setup(ws, cols=None):
    ws.right_to_left()
    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 0)
    ws.set_margins(0.4, 0.4, 0.6, 0.6)
    ws.set_footer("&Cصفحة &P من &N")
    for c, col in enumerate(cols or []):
        ws.set_column(c, c, col[1])


def _table(wb, fmt, name, title, note, cols, rows, count=None, sums=None):
    """ورقة جدول: عنوان، وصف، سطر إجمالي أعلى الجدول، رؤوس مثبتة، وتصفية.

    cols: [(العنوان، العرض، النوع، الإجمالي)]؛ النوع text/int/qty/money/pct/date/dt، والإجمالي None أو
    "sum" أو ("ratio", أ, ب) = إجمالي العمود أ ÷ إجمالي العمود ب.
    rows: قائمة، أو مُكرِّر مع count. sums: {رقم العمود: القيمة} تُحفظ نتيجةً للمعادلة فتظهر حتى في
    برامج لا تعيد الحساب؛ تُحسب من القائمة إن غابت.
    الإجمالي SUBTOTAL فيتبع التصفية، ويُكتب قبل البيانات لأن constant_memory يكتب الصفوف بالترتيب.
    """
    ws = wb.add_worksheet(name)
    _sheet_setup(ws, cols)
    ws.repeat_rows(HEAD_ROW)
    if isinstance(rows, list):
        count = len(rows)
        if sums is None:
            sums = {c: sum(float(r[c] or 0) for r in rows)
                    for c, col in enumerate(cols) if col[3] == "sum"}
    sums = sums or {}
    first, last = HEAD_ROW + 1, HEAD_ROW + max(count or 0, 1)

    ws.set_row(TITLE_ROW, 26)
    ws.merge_range(TITLE_ROW, 0, TITLE_ROW, max(len(cols) - 1, 1), title, fmt["title"])
    ws.write_string(NOTE_ROW, 0, note, fmt["note"])

    for c, col in enumerate(cols):
        spec, kind = col[3], col[2]
        if c == 0:
            ws.write_string(TOTAL_ROW, 0, "الإجمالي", fmt["tot_label"])
        elif spec == "sum":
            rng = "%s:%s" % (xl_rowcol_to_cell(first, c), xl_rowcol_to_cell(last, c))
            ws.write_formula(TOTAL_ROW, c, "=SUBTOTAL(109,%s)" % rng,
                             fmt["tot_" + ("money" if kind == "money" else "int" if kind == "int" else "qty")],
                             round(sums.get(c, 0), 2))
        elif isinstance(spec, tuple) and spec[0] == "ratio":
            a, b = spec[1], spec[2]
            value = sums.get(a, 0) / sums[b] if sums.get(b) else 0
            ws.write_formula(TOTAL_ROW, c, "=IFERROR(%s/%s,0)" % (
                xl_rowcol_to_cell(TOTAL_ROW, a), xl_rowcol_to_cell(TOTAL_ROW, b)), fmt["tot_pct"], value)
        else:
            ws.write_blank(TOTAL_ROW, c, None, fmt["tot_blank"])

    ws.set_row(HEAD_ROW, 34)
    for c, col in enumerate(cols):
        ws.write_string(HEAD_ROW, c, col[0], fmt["head"])
    r = first
    for row in rows:
        for c, col in enumerate(cols):
            _cell(ws, r, c, row[c], col[2], fmt)
        r += 1
    ws.freeze_panes(first, 0)
    if count:
        ws.autofilter(HEAD_ROW, 0, HEAD_ROW + count, len(cols) - 1)
    return ws


def _summary(wb, fmt, title, note, kpis, tables, notes=()):
    """ورقة الملخص: مؤشرات (عنوان/قيمة) ثم جداول صغيرة متتالية، كلها بالترتيب من الأعلى."""
    ws = wb.add_worksheet("الملخص")
    widths = max([len(t[1]) for t in tables] + [2])
    _sheet_setup(ws)
    ws.set_portrait()
    ws.set_column(0, 0, 34)
    ws.set_column(1, widths, 16)
    ws.set_row(0, 26)
    ws.merge_range(0, 0, 0, max(widths - 1, 1), title, fmt["title"])
    ws.write_string(1, 0, note, fmt["note"])
    r = 3
    for label, value, kind in kpis:
        ws.write_string(r, 0, label, fmt["kpi_label"])
        if value is None:
            ws.write_string(r, 1, "—", fmt["kpi_text"])
        elif kind == "text":
            ws.write_string(r, 1, str(value), fmt["kpi_text"])
        else:
            ws.write_number(r, 1, float(value), fmt["kpi_" + kind])
        r += 1
    for heading, cols, rows in tables:
        r += 1
        ws.write_string(r, 0, heading, fmt["section"])
        r += 1
        for c, col in enumerate(cols):
            ws.write_string(r, c, col[0], fmt["head"])
        r += 1
        for row in rows:
            for c, col in enumerate(cols):
                _cell(ws, r, c, row[c], col[2], fmt)
            r += 1
        if not rows:
            ws.write_string(r, 0, "لا توجد بيانات", fmt["hint"])
            r += 1
    if notes:
        r += 1
        ws.write_string(r, 0, "ملاحظات", fmt["section"])
        for text in notes:
            r += 1
            ws.write_string(r, 0, "• " + text, fmt["hint"])
    ws.activate()
    return ws


def _workbook():
    """ملف في الذاكرة؛ constant_memory يكتب الصفوف فوراً فلا تتضخم الذاكرة مع سنة من الأسطر."""
    buf = io.BytesIO()
    wb = xlsxwriter.Workbook(buf, {"constant_memory": True})
    wb.set_properties({"title": "تقارير عامة", "company": "نظام الصدارة"})
    return buf, wb, _formats(wb)


def _day(v):
    return v.date() if isinstance(v, datetime) else v


def _ratio(a, b):
    return (a / b) if b else None


# ────────────────────────────── جرد وتقييم المخزون ──────────────────────────────

_STOCK_SQL = """
    WITH b AS (
        SELECT d.item_idr,
               SUM(d.items_count) AS stock,
               SUM(d.items_count * COALESCE(d.buy_price, 0)) AS cost_value,
               COUNT(*) FILTER (WHERE d.items_count > 0) AS batches,
               MIN(d.expiration_date) FILTER (WHERE d.items_count > 0) AS nearest_expiry,
               MAX(d.created_on) AS last_purchase
        FROM items_det d
        GROUP BY d.item_idr
        HAVING ABS(SUM(d.items_count)) > 0.0001
    ),
    lb AS (
        SELECT DISTINCT ON (item_idr) item_idr, buy_price
        FROM items_det WHERE buy_price > 0 ORDER BY item_idr, id DESC
    ),
    lp AS (
        SELECT DISTINCT ON (item_idr) item_idr, public_price, vat, vat_in_public_price
        FROM items_det WHERE public_price > 0 ORDER BY item_idr, id DESC
    ),
    sa AS (
        SELECT d.item_idr, MAX(x.created_on) AS last_sale,
               SUM(x.item_count) FILTER (WHERE x.created_on >= %s) AS sold_window
        FROM invoice_details x JOIN items_det d ON d.id = x.item_number
        GROUP BY d.item_idr
    )
    SELECT i.id, i.item_id AS barcode, i.name, kt.name AS category, s.name AS supplier,
           COALESCE(i.halt, 'F') = 'T' AS halted,
           b.stock, b.cost_value, b.batches, b.nearest_expiry, b.last_purchase,
           lb.buy_price AS last_buy,
           lp.public_price AS det_price, lp.vat AS det_vat, lp.vat_in_public_price AS det_vat_incl,
           i.public_price AS card_price,
           sa.last_sale, COALESCE(sa.sold_window, 0) AS sold_window
    FROM b
    JOIN items_main i ON i.id = b.item_idr
    LEFT JOIN key_type kt ON kt.id = i.item_type
    LEFT JOIN suppliers s ON s.id = i.suppliers
    LEFT JOIN lb ON lb.item_idr = b.item_idr
    LEFT JOIN lp ON lp.item_idr = b.item_idr
    LEFT JOIN sa ON sa.item_idr = b.item_idr
    WHERE i.id <> 1 AND COALESCE(i.track_stock, 'T') = 'T'
    ORDER BY kt.name NULLS LAST, i.name
"""


def _stock_items(db, now, stale_days):
    stale_cut = now - timedelta(days=stale_days)
    rows = db.executesql(_STOCK_SQL, placeholders=[now - timedelta(days=COVER_DAYS)], as_dict=True)
    items = []
    for r in rows:
        stock = round(float(r["stock"] or 0), 3)
        sale_incl, sale_ex, _vat, _src = item_rules.sale_price(
            r["det_price"], r["det_vat"], r["det_vat_incl"], r["card_price"])
        last_buy = float(r["last_buy"]) if r["last_buy"] else None
        cost = float(r["cost_value"] or 0)
        sold = float(r["sold_window"] or 0)
        sale_ex_value = stock * sale_ex if sale_ex else None
        last_sale, last_purchase = r["last_sale"], r["last_purchase"]
        items.append(dict(
            id=r["id"], barcode=r["barcode"], name=r["name"],
            category=r["category"] or "بدون تصنيف", supplier=r["supplier"] or "بدون مورد",
            halted=bool(r["halted"]), stock=stock, batches=r["batches"] or 0,
            nearest_expiry=r["nearest_expiry"], last_buy=last_buy,
            sale_ex=sale_ex, sale_incl=sale_incl, cost=cost,
            sale_ex_value=sale_ex_value,
            sale_incl_value=stock * sale_incl if sale_incl else None,
            profit=(sale_ex_value - cost) if sale_ex_value is not None else None,
            margin=(sale_ex - last_buy) / last_buy if (sale_ex and last_buy) else None,
            sold=sold,
            cover_days=round(stock / (sold / COVER_DAYS)) if (sold > 0 and stock > 0) else None,
            last_sale=last_sale, last_purchase=last_purchase,
            idle_days=(now - last_sale).days if last_sale else None,
            stale=stock > 0 and (not last_sale or last_sale < stale_cut)
            and (not last_purchase or last_purchase < stale_cut),
        ))
    return items


def _group(items, key):
    """تجميع الأصناف المتوفرة حسب حقل (تصنيف/مورد) مرتبة بالتكلفة تنازلياً."""
    groups = {}
    for it in items:
        g = groups.setdefault(it[key], {"n": 0, "stock": 0.0, "cost": 0.0, "sale": 0.0, "profit": 0.0})
        g["n"] += 1
        g["stock"] += it["stock"]
        g["cost"] += it["cost"]
        g["sale"] += it["sale_ex_value"] or 0
        g["profit"] += it["profit"] or 0
    total_cost = sum(g["cost"] for g in groups.values())
    rows = [(name, g["n"], g["stock"], g["cost"], g["sale"], g["profit"],
             _ratio(g["profit"], g["cost"]), _ratio(g["cost"], total_cost))
            for name, g in groups.items()]
    return sorted(rows, key=lambda x: -x[3])


def stock_workbook(db, stale_days=180, now=None):
    """جرد وتقييم المخزون الحالي. يعيد (محتوى الملف، ملخص الأرقام)."""
    now = now or datetime.now()
    items = _stock_items(db, now, stale_days)
    pos = [it for it in items if it["stock"] > 0]
    neg = sorted([it for it in items if it["stock"] < 0], key=lambda it: it["stock"])
    stale = sorted([it for it in pos if it["stale"]], key=lambda it: -it["cost"])
    today = now.date()
    soon = today + timedelta(days=90)

    total_cost = sum(it["cost"] for it in pos)
    total_sale = sum(it["sale_ex_value"] or 0 for it in pos)
    total_profit = sum(it["profit"] or 0 for it in pos)
    stale_cost = sum(it["cost"] for it in stale)
    stamp = "أُنشئ في %s" % now.strftime("%Y-%m-%d %H:%M")

    buf, wb, fmt = _workbook()
    _summary(wb, fmt, "جرد وتقييم المخزون", stamp, [
        ("عدد الأصناف المتوفرة", len(pos), "int"),
        ("إجمالي الكميات", sum(it["stock"] for it in pos), "qty"),
        ("تكلفة المخزون", total_cost, "money"),
        ("قيمة البيع قبل الضريبة", total_sale, "money"),
        ("قيمة البيع شامل الضريبة", sum(it["sale_incl_value"] or 0 for it in pos), "money"),
        ("الربح المتوقع", total_profit, "money"),
        ("نسبة الربح على التكلفة", _ratio(total_profit, total_cost), "pct"),
        ("أصناف راكدة (بلا بيع %d يوماً)" % stale_days, len(stale), "int"),
        ("تكلفة الأصناف الراكدة", stale_cost, "money"),
        ("نسبتها من تكلفة المخزون", _ratio(stale_cost, total_cost), "pct"),
        ("أصناف لديها دفعة منتهية الصلاحية", sum(1 for it in pos if it["nearest_expiry"]
                                                   and it["nearest_expiry"] < today), "int"),
        ("أصناف تنتهي دفعة منها خلال 90 يوماً", sum(1 for it in pos if it["nearest_expiry"]
                                                      and today <= it["nearest_expiry"] <= soon), "int"),
        ("أصناف رصيدها سالب", len(neg), "int"),
        ("أصناف متوفرة بلا سعر شراء", sum(1 for it in pos if not it["last_buy"]), "int"),
        ("أصناف متوفرة بلا سعر بيع", sum(1 for it in pos if not it["sale_ex"]), "int"),
    ], [
        ("أعلى 15 تصنيفاً بتكلفة المخزون", _group_cols("التصنيف"), _group(pos, "category")[:15]),
    ], notes=(
        "التكلفة = كمية كل دفعة × سعر شرائها؛ البضاعة المجانية تكلفتها صفر.",
        "سعر البيع من أحدث دفعة مسعّرة كما في نقطة البيع، والربح يُحسب على السعر قبل الضريبة.",
        "الراكد: رصيده موجب ولم يُبع ولم يُشترَ منذ %d يوماً." % stale_days,
        "«يكفي لمدة» = الرصيد ÷ متوسط البيع اليومي في آخر %d يوماً." % COVER_DAYS,
    ))

    item_cols = [
        ("م", 8, "int", None), ("الرقم الدولي", 16, "text", None), ("اسم الصنف", 40, "text", None),
        ("التصنيف", 18, "text", None), ("المورد", 22, "text", None), ("الرصيد", 10, "qty", "sum"),
        ("الدفعات", 8, "int", None), ("أقرب صلاحية", 12, "date", None),
        ("آخر سعر شراء", 11, "money", None), ("سعر البيع قبل الضريبة", 12, "money", None),
        ("سعر البيع شامل الضريبة", 12, "money", None), ("نسبة الربح على التكلفة", 11, "pct", ("ratio", 14, 12)),
        ("تكلفة المخزون", 14, "money", "sum"), ("قيمة البيع قبل الضريبة", 14, "money", "sum"),
        ("الربح المتوقع", 13, "money", "sum"), ("مبيعات %d يوماً" % COVER_DAYS, 11, "qty", "sum"),
        ("يكفي لمدة (يوم)", 10, "int", None), ("آخر بيع", 12, "date", None),
        ("آخر شراء", 12, "date", None), ("موقوف", 8, "text", None),
    ]
    _table(wb, fmt, "المخزون", "الأصناف المتوفرة", stamp + " — مرتبة حسب التصنيف ثم الاسم", item_cols, [
        (it["id"], it["barcode"], it["name"], it["category"], it["supplier"], it["stock"], it["batches"],
         it["nearest_expiry"], it["last_buy"], it["sale_ex"], it["sale_incl"], it["margin"], it["cost"],
         it["sale_ex_value"], it["profit"], it["sold"], it["cover_days"], _day(it["last_sale"]),
         _day(it["last_purchase"]), "نعم" if it["halted"] else "")
        for it in pos])

    _table(wb, fmt, "حسب التصنيف", "المخزون حسب التصنيف", stamp, _group_cols("التصنيف"),
           _group(pos, "category"))
    _table(wb, fmt, "حسب المورد", "المخزون حسب المورد", stamp + " — مورد بطاقة الصنف",
           _group_cols("المورد"), _group(pos, "supplier"))

    _table(wb, fmt, "الراكدة", "أصناف راكدة: بلا بيع ولا شراء منذ %d يوماً" % stale_days,
           stamp + " — مرتبة بالتكلفة من الأعلى", [
               ("م", 8, "int", None), ("الرقم الدولي", 16, "text", None), ("اسم الصنف", 40, "text", None),
               ("التصنيف", 18, "text", None), ("المورد", 22, "text", None), ("الرصيد", 10, "qty", "sum"),
               ("تكلفة المخزون", 14, "money", "sum"), ("آخر بيع", 12, "date", None),
               ("أيام بلا بيع", 10, "int", None), ("آخر شراء", 12, "date", None),
               ("أقرب صلاحية", 12, "date", None)], [
               (it["id"], it["barcode"], it["name"], it["category"], it["supplier"], it["stock"],
                it["cost"], _day(it["last_sale"]), it["idle_days"], _day(it["last_purchase"]),
                it["nearest_expiry"]) for it in stale])

    _table(wb, fmt, "الرصيد السالب", "أصناف رصيدها سالب — تحتاج جرداً أو فاتورة شراء",
           stamp + " — مرتبة من الأكثر سالبية", [
               ("م", 8, "int", None), ("الرقم الدولي", 16, "text", None), ("اسم الصنف", 40, "text", None),
               ("التصنيف", 18, "text", None), ("الرصيد", 10, "qty", "sum"), ("آخر بيع", 12, "date", None),
               ("آخر شراء", 12, "date", None), ("موقوف", 8, "text", None)], [
               (it["id"], it["barcode"], it["name"], it["category"], it["stock"], _day(it["last_sale"]),
                _day(it["last_purchase"]), "نعم" if it["halted"] else "") for it in neg])
    wb.close()
    return buf.getvalue(), {"items": len(pos), "cost": round(total_cost, 2), "stale": len(stale),
                            "negative": len(neg)}


def _group_cols(label):
    return [
        (label, 28, "text", None), ("عدد الأصناف", 10, "int", "sum"), ("الرصيد", 12, "qty", "sum"),
        ("تكلفة المخزون", 15, "money", "sum"), ("قيمة البيع قبل الضريبة", 15, "money", "sum"),
        ("الربح المتوقع", 14, "money", "sum"), ("نسبة الربح على التكلفة", 12, "pct", ("ratio", 5, 3)),
        ("من إجمالي التكلفة", 12, "pct", None),
    ]


# ────────────────────────────── المبيعات والمرتجعات لفترة ──────────────────────────────

# كل أسطر الفترة مرة واحدة في جدول مؤقت يُحذف مع نهاية الطلب، ثم تُقرأ منه الملخصات والتفاصيل.
# الربط بالفاتورة LEFT: السطر هو مصدر مبيعات الصنف حتى لو غابت فاتورته الرئيسية.
_SALES_LINES_SQL = """
    CREATE TEMP TABLE rep_sales_lines ON COMMIT DROP AS
    SELECT l.kind, l.sgn, l.inv_no, l.line_id, l.created_on,
           l.sgn * l.qty AS qty, l.unit_price, l.vat_rate,
           l.sgn * (l.total - l.vat_amount) AS net_ex,
           l.sgn * l.vat_amount AS vat_amount,
           l.sgn * l.total AS total,
           l.sgn * l.qty * COALESCE(b.buy_price, 0) AS cost,
           COALESCE(b.buy_price, 0) <= 0 AS no_cost,
           l.batch_id, b.item_idr, i.item_id AS barcode,
           COALESCE(i.name, 'صنف محذوف') AS item_name,
           COALESCE(kt.name, 'بدون تصنيف') AS category,
           COALESCE(kpm.name, '—') AS pay_name,
           COALESCE(c.name, '—') AS customer,
           COALESCE(NULLIF(TRIM(COALESCE(au.first_name, '') || ' ' || COALESCE(au.last_name, '')), ''),
                    '—') AS user_name
    FROM (
        SELECT 'بيع'::text AS kind, 1 AS sgn, m.id AS inv_no, d.id AS line_id, d.created_on,
               m.payment_method, m.customer, COALESCE(m.created_by, d.created_by) AS created_by,
               d.item_number AS batch_id, COALESCE(d.item_count, 0) AS qty,
               {amount} AS unit_price, COALESCE(d.vat, 0) AS vat_rate,
               COALESCE(d.vat_total, 0) AS vat_amount, {total} AS total
        FROM invoice_details d
        LEFT JOIN invoice_master m ON m.uuid = d.uuid
        WHERE d.created_on >= %s AND d.created_on < %s
        UNION ALL
        SELECT 'مرتجع'::text, -1, r.id, d.id, d.created_on,
               r.payment_method, r.customer, COALESCE(r.created_by, d.created_by),
               d.item_number, COALESCE(d.item_count, 0),
               {amount}, COALESCE(d.vat, 0), COALESCE(d.vat_total, 0), {total}
        FROM inv_return_details d
        LEFT JOIN inv_return_master r ON r.uuid = d.uuid
        WHERE d.created_on >= %s AND d.created_on < %s
    ) l
    LEFT JOIN items_det b ON b.id = l.batch_id
    LEFT JOIN items_main i ON i.id = b.item_idr
    LEFT JOIN key_type kt ON kt.id = i.item_type
    LEFT JOIN key_payment_method kpm ON kpm.id = l.payment_method
    LEFT JOIN customers c ON c.id = l.customer
    LEFT JOIN auth_user au ON au.id = l.created_by
""".format(amount=_num("d.amount"), total=_num("d.total"))

_SALES_KPI_SQL = """
    SELECT COUNT(DISTINCT inv_no) FILTER (WHERE sgn = 1),
           COUNT(DISTINCT inv_no) FILTER (WHERE sgn = -1),
           COUNT(*),
           COALESCE(SUM(net_ex) FILTER (WHERE sgn = 1), 0),
           COALESCE(SUM(vat_amount) FILTER (WHERE sgn = 1), 0),
           COALESCE(SUM(total) FILTER (WHERE sgn = 1), 0),
           COALESCE(-SUM(net_ex) FILTER (WHERE sgn = -1), 0),
           COALESCE(-SUM(vat_amount) FILTER (WHERE sgn = -1), 0),
           COALESCE(-SUM(total) FILTER (WHERE sgn = -1), 0),
           COALESCE(SUM(cost), 0),
           COALESCE(SUM(qty), 0),
           COALESCE(SUM(net_ex) FILTER (WHERE sgn = 1 AND no_cost), 0),
           COUNT(*) FILTER (WHERE inv_no IS NULL)
    FROM rep_sales_lines
"""


def _iter_rows(db, sql, size=5000):
    """قراءة على دفعات بمؤشر في الخادم، فلا تُحمَّل أسطر سنة كاملة في الذاكرة دفعة واحدة."""
    conn = getattr(db._adapter, "connection", None)
    if conn is None or not hasattr(conn, "cursor"):
        for row in db.executesql(sql):
            yield row
        return
    cur = conn.cursor(name="rep_sales_cursor")
    cur.itersize = size
    try:
        cur.execute(sql)
        for row in cur:
            yield row
    finally:
        cur.close()


def sales_workbook(db, start, end, now=None):
    """المبيعات والمرتجعات من start (شاملاً) إلى end (غير شامل). يعيد (محتوى الملف، ملخص الأرقام)."""
    now = now or datetime.now()
    db.executesql(_SALES_LINES_SQL, placeholders=[start, end, start, end])
    (n_inv, n_ret, n_lines, s_ex, s_vat, s_tot, r_ex, r_vat, r_tot, cost, qty, no_cost_sales,
     orphans) = db.executesql(_SALES_KPI_SQL)[0]
    net_ex, net_vat, net_tot = s_ex - r_ex, s_vat - r_vat, s_tot - r_tot
    profit = net_ex - cost
    by_month = (end - start).days > 92
    period = "من %s إلى %s" % (start.strftime("%Y-%m-%d %H:%M"),
                               (end - timedelta(minutes=1)).strftime("%Y-%m-%d %H:%M"))
    stamp = "%s — أُنشئ في %s" % (period, now.strftime("%Y-%m-%d %H:%M"))

    pay_rows = db.executesql("""
        SELECT pay_name, COUNT(DISTINCT inv_no) FILTER (WHERE sgn = 1),
               COALESCE(SUM(total) FILTER (WHERE sgn = 1), 0), COALESCE(-SUM(total) FILTER (WHERE sgn = -1), 0),
               SUM(total)
        FROM rep_sales_lines GROUP BY pay_name ORDER BY SUM(total) DESC""")
    period_rows = [
        (r[0].strftime("%Y-%m") if by_month else r[0].date(),) + tuple(r[1:])
        for r in db.executesql("""
            SELECT date_trunc(%s, created_on), COUNT(DISTINCT inv_no) FILTER (WHERE sgn = 1),
                   COALESCE(SUM(net_ex) FILTER (WHERE sgn = 1), 0),
                   COALESCE(-SUM(net_ex) FILTER (WHERE sgn = -1), 0),
                   SUM(net_ex), SUM(cost), SUM(net_ex) - SUM(cost)
            FROM rep_sales_lines GROUP BY 1 ORDER BY 1""",
            placeholders=["month" if by_month else "day"])]
    user_rows = db.executesql("""
        SELECT user_name, COUNT(DISTINCT inv_no) FILTER (WHERE sgn = 1),
               COALESCE(SUM(total) FILTER (WHERE sgn = 1), 0), COALESCE(-SUM(total) FILTER (WHERE sgn = -1), 0),
               SUM(total)
        FROM rep_sales_lines GROUP BY user_name ORDER BY SUM(total) DESC""")

    notes = [
        "المرتجعات بإشارة سالبة في ورقتي «حسب الصنف» و«التفاصيل»، فمجموع أي عمود هو الصافي.",
        "التكلفة = الكمية × سعر شراء الدفعة المباعة نفسها؛ الدفعة بلا سعر شراء تكلفتها صفر.",
        "الإجماليات أعلى كل جدول تتبع التصفية.",
    ]
    if no_cost_sales:
        notes.append("مبيعات بقيمة %.2f قبل الضريبة من دفعات بلا سعر شراء، فربحها مبالغ فيه." % no_cost_sales)
    if orphans:
        notes.append("%d سطراً بلا فاتورة رئيسية، فرقم الفاتورة وطريقة الدفع فيها فارغة." % orphans)

    buf, wb, fmt = _workbook()
    money_cols = lambda head: [(head, 14, "money", None)]
    _summary(wb, fmt, "المبيعات والمرتجعات", stamp, [
        ("الفترة", period, "text"),
        ("فواتير البيع", n_inv, "int"),
        ("فواتير المرتجع", n_ret, "int"),
        ("المبيعات قبل الضريبة", s_ex, "money"),
        ("ضريبة المبيعات", s_vat, "money"),
        ("المبيعات شامل الضريبة", s_tot, "money"),
        ("المرتجعات قبل الضريبة", r_ex, "money"),
        ("ضريبة المرتجعات", r_vat, "money"),
        ("المرتجعات شامل الضريبة", r_tot, "money"),
        ("الصافي قبل الضريبة", net_ex, "money"),
        ("صافي الضريبة", net_vat, "money"),
        ("الصافي شامل الضريبة", net_tot, "money"),
        ("تكلفة البضاعة المباعة", cost, "money"),
        ("إجمالي الربح", profit, "money"),
        ("هامش الربح من المبيعات", _ratio(profit, net_ex), "pct"),
        ("متوسط فاتورة البيع شامل الضريبة", _ratio(s_tot, n_inv), "money"),
    ], [
        ("حسب طريقة الدفع", [("طريقة الدفع", 0, "text", None), ("فواتير البيع", 0, "int", None)]
         + money_cols("المبيعات شامل الضريبة") + money_cols("المرتجعات شامل الضريبة")
         + money_cols("الصافي شامل الضريبة"), pay_rows),
        ("حسب الشهر" if by_month else "حسب اليوم",
         [("الشهر" if by_month else "اليوم", 0, "text" if by_month else "date", None),
          ("فواتير البيع", 0, "int", None)] + money_cols("المبيعات قبل الضريبة")
         + money_cols("المرتجعات قبل الضريبة") + money_cols("الصافي قبل الضريبة")
         + money_cols("التكلفة") + money_cols("الربح"), period_rows),
        ("حسب البائع", [("البائع", 0, "text", None), ("فواتير البيع", 0, "int", None)]
         + money_cols("المبيعات شامل الضريبة") + money_cols("المرتجعات شامل الضريبة")
         + money_cols("الصافي شامل الضريبة"), user_rows),
    ], notes)

    item_rows = [
        tuple(r[:12]) + (_ratio(r[11], r[7]), r[12])
        for r in db.executesql("""
            SELECT item_idr, MAX(barcode), MAX(item_name), MAX(category),
                   COALESCE(SUM(qty) FILTER (WHERE sgn = 1), 0), COALESCE(-SUM(qty) FILTER (WHERE sgn = -1), 0),
                   SUM(qty), SUM(net_ex), SUM(vat_amount), SUM(total), SUM(cost), SUM(net_ex) - SUM(cost),
                   COUNT(DISTINCT inv_no) FILTER (WHERE sgn = 1)
            FROM rep_sales_lines GROUP BY item_idr ORDER BY SUM(net_ex) DESC NULLS LAST""")]
    _table(wb, fmt, "حسب الصنف", "المبيعات حسب الصنف", stamp + " — الأعلى مبيعاً أولاً", [
        ("م", 8, "int", None), ("الرقم الدولي", 16, "text", None), ("اسم الصنف", 40, "text", None),
        ("التصنيف", 18, "text", None), ("الكمية المباعة", 11, "qty", "sum"),
        ("الكمية المرتجعة", 11, "qty", "sum"), ("صافي الكمية", 11, "qty", "sum"),
        ("صافي المبيعات قبل الضريبة", 15, "money", "sum"), ("الضريبة", 12, "money", "sum"),
        ("الصافي شامل الضريبة", 15, "money", "sum"), ("التكلفة", 13, "money", "sum"),
        ("الربح", 13, "money", "sum"), ("هامش الربح", 10, "pct", ("ratio", 11, 7)),
        ("فواتير البيع", 10, "int", None)], item_rows)

    cat_raw = db.executesql("""
        SELECT category, COUNT(DISTINCT item_idr), SUM(qty), SUM(net_ex), SUM(vat_amount), SUM(total),
               SUM(cost), SUM(net_ex) - SUM(cost)
        FROM rep_sales_lines GROUP BY category ORDER BY SUM(net_ex) DESC""")
    _table(wb, fmt, "حسب التصنيف", "المبيعات حسب التصنيف", stamp, [
        ("التصنيف", 28, "text", None), ("عدد الأصناف", 10, "int", "sum"), ("صافي الكمية", 12, "qty", "sum"),
        ("صافي المبيعات قبل الضريبة", 16, "money", "sum"), ("الضريبة", 13, "money", "sum"),
        ("الصافي شامل الضريبة", 16, "money", "sum"), ("التكلفة", 14, "money", "sum"),
        ("الربح", 14, "money", "sum"), ("هامش الربح", 11, "pct", ("ratio", 7, 3)),
        ("من صافي المبيعات", 12, "pct", None)],
        [tuple(r) + (_ratio(r[7], r[3]), _ratio(r[3], net_ex)) for r in cat_raw])

    _table(wb, fmt, "التفاصيل", "أسطر المبيعات والمرتجعات", stamp, [
        ("النوع", 9, "text", None), ("رقم الفاتورة", 11, "int", None), ("التاريخ والوقت", 16, "dt", None),
        ("طريقة الدفع", 13, "text", None), ("العميل", 22, "text", None), ("البائع", 16, "text", None),
        ("الرقم الدولي", 16, "text", None), ("اسم الصنف", 40, "text", None), ("التصنيف", 18, "text", None),
        ("رقم الدفعة", 10, "int", None), ("الكمية", 9, "qty", "sum"),
        ("سعر الوحدة قبل الضريبة", 12, "money", None), ("نسبة الضريبة", 9, "pct", None),
        ("مبلغ الضريبة", 11, "money", "sum"), ("الإجمالي شامل الضريبة", 13, "money", "sum"),
        ("التكلفة", 12, "money", "sum"), ("الربح", 12, "money", "sum")],
        _iter_rows(db, """
            SELECT kind, inv_no, created_on, pay_name, customer, user_name, barcode, item_name, category,
                   batch_id, qty, unit_price, vat_rate, vat_amount, total, cost, net_ex - cost
            FROM rep_sales_lines ORDER BY created_on, inv_no, line_id"""),
        count=n_lines, sums={10: qty, 13: net_vat, 14: net_tot, 15: cost, 16: profit})
    wb.close()
    return buf.getvalue(), {"invoices": n_inv, "returns": n_ret, "lines": n_lines,
                            "net_total": round(net_tot, 2), "profit": round(profit, 2)}
