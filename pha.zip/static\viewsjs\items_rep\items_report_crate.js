// تقارير عامة: الملف يُجهَّز عند الطلب ويُنزَّل مباشرة (items_rep/stock_report و sales_report)
var API_BASE = window.location.origin
    + window.location.pathname.replace(/\/items_rep\/items_report_crate.*$/, '/items_rep/');
var XLSX_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

function pad2(n) { return (n < 10 ? '0' : '') + n; }

// قيمة لحقل datetime-local بالتوقيت المحلي
function toLocalInput(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
        + 'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
}

function parseLocalInput(v) {
    var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(v || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]) : null;
}

function readableSize(bytes) {
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' م.ب';
    return Math.max(1, Math.round(bytes / 1024)) + ' ك.ب';
}

// اسم الملف كما سمّاه الخادم (filename* بالعربية)، وإلا الاسم البديل
function fileNameFrom(disposition, fallback) {
    var m = /filename\*=UTF-8''([^;]+)/i.exec(disposition || '');
    if (m) {
        try { return decodeURIComponent(m[1]); } catch (e) { /* يُستخدم البديل */ }
    }
    m = /filename="([^"]+)"/i.exec(disposition || '');
    return m ? m[1] : fallback;
}

var app = new Vue({
    el: '#app',
    data: {
        staleChoices: (typeof STALE_CHOICES !== 'undefined' && STALE_CHOICES) || [90, 180, 365],
        maxDays: (typeof MAX_DAYS !== 'undefined' && MAX_DAYS) || 366,
        stockSheets: ['الملخص', 'المخزون', 'حسب التصنيف', 'حسب المورد', 'الراكدة', 'الرصيد السالب'],
        salesSheets: ['الملخص', 'حسب الصنف', 'حسب التصنيف', 'التفاصيل'],
        presets: [
            { key: 'today', label: 'اليوم' },
            { key: 'yesterday', label: 'أمس' },
            { key: 'month', label: 'هذا الشهر' },
            { key: 'last_month', label: 'الشهر الماضي' },
            { key: 'last30', label: 'آخر 30 يوماً' },
            { key: 'year', label: 'هذه السنة' },
        ],
        stock: { stale: 180, busy: false, elapsed: 0, done: null },
        sales: { start: '', end: '', preset: '', busy: false, elapsed: 0, done: null },
    },
    created: function () {
        this.applyPreset('month');
    },
    computed: {
        salesDays: function () {
            var a = parseLocalInput(this.sales.start), b = parseLocalInput(this.sales.end);
            if (!a || !b || b < a) return 0;
            return Math.ceil((b - a + 60000) / 86400000);  // النهاية شاملة دقيقتها
        },
        salesError: function () {
            var a = parseLocalInput(this.sales.start), b = parseLocalInput(this.sales.end);
            if (!a || !b) return 'حدّد تاريخ البداية والنهاية';
            if (a > b) return 'تاريخ البداية بعد تاريخ النهاية';
            if (this.salesDays > this.maxDays) {
                return 'الفترة أطول من ' + this.maxDays + ' يوماً؛ قسّمها على أكثر من ملف';
            }
            return '';
        },
    },
    methods: {
        applyPreset: function (key) {
            var now = new Date(), y = now.getFullYear(), m = now.getMonth(), d = now.getDate();
            var endToday = new Date(y, m, d, 23, 59);
            var range = {
                today: [new Date(y, m, d), endToday],
                yesterday: [new Date(y, m, d - 1), new Date(y, m, d - 1, 23, 59)],
                month: [new Date(y, m, 1), endToday],
                last_month: [new Date(y, m - 1, 1), new Date(y, m, 0, 23, 59)],
                last30: [new Date(y, m, d - 29), endToday],
                year: [new Date(y, 0, 1), endToday],
            }[key];
            if (!range) return;
            this.sales.start = toLocalInput(range[0]);
            this.sales.end = toLocalInput(range[1]);
            this.sales.preset = key;
        },
        download: function (kind) {
            var st = this[kind];
            if (st.busy) return;
            if (kind === 'sales' && this.salesError) {
                Swal.fire('تنبيه', this.salesError, 'warning');
                return;
            }
            var url = new URL(API_BASE + (kind === 'stock' ? 'stock_report' : 'sales_report'));
            if (kind === 'stock') {
                url.searchParams.append('stale_days', st.stale);
            } else {
                url.searchParams.append('start', st.start);
                url.searchParams.append('end', st.end);
            }
            var began = Date.now();
            var disposition = '';
            st.busy = true;
            st.elapsed = 0;
            st.done = null;
            var timer = setInterval(function () { st.elapsed = Math.floor((Date.now() - began) / 1000); }, 500);
            fetch(url, { headers: { 'Accept': XLSX_TYPE + ', application/json' } })
                .then(function (r) {
                    var type = r.headers.get('Content-Type') || '';
                    if (type.indexOf('application/json') >= 0) {
                        return r.json().then(function (data) {
                            throw new Error(Api.getError(data) || 'تعذّر تجهيز التقرير');
                        });
                    }
                    if (type.indexOf('text/html') >= 0) {
                        // تحويل إلى صفحة الدخول أو «لا يوجد لديك صلاحية»
                        throw new Error('انتهت الجلسة أو لا توجد صلاحية. أعد تحميل الصفحة ثم حاول.');
                    }
                    if (!r.ok || type.indexOf('spreadsheetml') < 0) {
                        throw new Error('تعذّر تجهيز التقرير (' + r.status + ')');
                    }
                    disposition = r.headers.get('Content-Disposition') || '';
                    return r.blob();
                })
                .then(function (blob) {
                    var name = fileNameFrom(disposition, kind + '.xlsx');
                    var link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = name;
                    document.body.appendChild(link);
                    link.click();
                    link.remove();
                    setTimeout(function () { URL.revokeObjectURL(link.href); }, 10000);
                    st.done = {
                        name: name,
                        size: readableSize(blob.size),
                        secs: ((Date.now() - began) / 1000).toFixed(1),
                    };
                })
                .catch(function (e) {
                    Swal.fire('تعذّر التنزيل', (e && e.message) || 'تعذّر الاتصال بالخادم', 'error');
                })
                .finally(function () {
                    clearInterval(timer);
                    st.busy = false;
                });
        },
    },
});
