# -*- coding: utf-8 -*-
"""
مولّد وسوم الأصناف (item_tags) عبر نموذج Claude.

يُستدعى من:
- controllers/item_tags.py  (توليد فردي + تعبئة مجمّعة + حفظ يدوي)
- controllers/api_1.py      (توليد متزامن عند إنشاء صنف جديد)

لا يعتمد على متغيرات web2py العامة — كل ما يحتاجه يُمرَّر كوسائط (db, api_key, ...).
الاتصال بالواجهة عبر urllib فقط (بلا اعتماديات خارجية)، تماشياً مع نمط المشروع.
"""
import json
import urllib.request
import urllib.error

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_MODEL = "claude-haiku-4-5-20251001"

# الموجّه مبني ليُخرج كلمات بحث منظّمة، عربية وإنجليزية، تخدم بحث الوكيل.
_SYSTEM_PROMPT = (
    "أنت مساعد متخصص في الأدوية والمستلزمات الطبية في صيدلية سعودية. "
    "مهمتك توليد كلمات بحث (وسوم) لصنف واحد، تُستخدم لتحسين بحث وكيل ذكاء يخدم العملاء. "
    "أعِد سطراً واحداً فقط من كلمات مفصولة بمسافات، تجمع بين العربية والإنجليزية، ويشمل: "
    "الاسم التجاري ونطقه بالعربي، الاسم العلمي (المادة الفعّالة) بالعربي والإنجليزي، "
    "التصنيف الدوائي، الحالات أو الأعراض التي يُستخدم لها، الشكل والجرعة، "
    "ومرادفات وأخطاء إملائية شائعة قد يكتبها العميل. "
    "لا تضع شروحات، ولا أسطراً متعددة، ولا ترقيماً، ولا علامات اقتباس — الكلمات فقط. "
    "إن لم تكن متأكداً من معلومة دوائية فلا تخمّن؛ اكتفِ بالاسم ومشتقاته."
)


def build_user_prompt(name, generic_name=None, item_type=None):
    """يبني نص الطلب من بيانات الصنف المتاحة."""
    parts = ["الاسم التجاري: %s" % (name or "")]
    if generic_name:
        parts.append("الاسم العلمي: %s" % generic_name)
    if item_type:
        parts.append("التصنيف: %s" % item_type)
    parts.append("أعِد سطر الوسوم فقط.")
    return "\n".join(parts)


def generate_tags(name, generic_name=None, item_type=None, api_key=None,
                  model=None, timeout=30):
    """
    يستدعي النموذج ويُعيد سطر الوسوم (str).
    يرفع ValueError عند نقص المدخلات و RuntimeError عند فشل الاتصال/الاستجابة.
    """
    if not api_key:
        raise ValueError("مفتاح واجهة الذكاء الاصطناعي غير مُعدّ (ai.anthropic_api_key)")
    if not (name or "").strip():
        raise ValueError("اسم الصنف فارغ")

    body = {
        "model": model or DEFAULT_MODEL,
        "max_tokens": 300,
        "temperature": 0.2,
        "system": _SYSTEM_PROMPT,
        "messages": [
            {"role": "user",
             "content": build_user_prompt(name, generic_name, item_type)},
        ],
    }
    req = urllib.request.Request(
        ANTHROPIC_URL,
        data=json.dumps(body).encode("utf-8"),
        method="POST",
        headers={
            "x-api-key": api_key,
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        raise RuntimeError("فشل الاتصال بالنموذج (%s): %s" % (e.code, detail[:300]))
    except urllib.error.URLError as e:
        raise RuntimeError("تعذّر الوصول إلى خدمة الذكاء الاصطناعي: %s" % e.reason)

    blocks = payload.get("content") or []
    text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
    text = " ".join(text.split())  # تطبيع المسافات والأسطر إلى سطر واحد
    if not text:
        raise RuntimeError("النموذج أعاد نتيجة فارغة")
    return text


def store_tags(db, item_id, tags, source="ai"):
    """upsert: صف واحد لكل صنف. لا يعمل commit — المتصل مسؤول عنه."""
    row = db(db.item_tags.item_idr == item_id).select().first()
    if row:
        row.update_record(tags=tags, source=source)
    else:
        db.item_tags.insert(item_idr=item_id, tags=tags, source=source)


def _resolve_type_name(db, item):
    if item.item_type:
        kt = db.key_type(item.item_type)
        return kt.name if kt else None
    return None


def tag_and_store(db, item, api_key, model=None, source="ai"):
    """
    يولّد الوسوم لصنف (Row من items_main) ويحفظها. يُعيد نص الوسوم.
    لا يعمل commit — المتصل مسؤول عنه ليتحكم بحدود المعاملة.
    """
    tags = generate_tags(
        item.name, item.generic_name, _resolve_type_name(db, item),
        api_key=api_key, model=model,
    )
    store_tags(db, item.id, tags, source=source)
    return tags
