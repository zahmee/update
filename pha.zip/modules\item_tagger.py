# -*- coding: utf-8 -*-
"""
مولّد وسوم الأصناف (item_tags).

يدعم مزوّدَين عبر إعداد واحد (provider):
- anthropic : واجهة Claude الأصلية.
- openai    : أي واجهة متوافقة مع OpenAI — ومنها DeepSeek (deepseek-chat)
              عبر base_url = https://api.deepseek.com (أرخص وأسرع).

للسرعة والتكلفة:
- generate_tags_batch : يوسّم عدة أصناف في نداء واحد (يقلّل الاستدعاءات عشرات المرّات).
- المعالجة المتوازية تُدار في الكنترولر (ThreadPoolExecutor) فوق هذه الدالة.

لا يعتمد على متغيرات web2py — كل ما يحتاجه يُمرَّر عبر cfg (dict).
الاتصال بـ urllib فقط (بلا اعتماديات خارجية).
"""
import json
import urllib.request
import urllib.error

DEFAULT_ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_OPENAI_BASE = "https://api.deepseek.com"

_RULES = (
    "تشمل الوسوم: الاسم التجاري ونطقه بالعربي، الاسم العلمي (المادة الفعّالة) "
    "بالعربي والإنجليزي، التصنيف الدوائي، الحالات أو الأعراض التي يُستخدم لها، "
    "الشكل والجرعة، ومرادفات وأخطاء إملائية شائعة قد يكتبها العميل. "
    "كلمات مفصولة بمسافات فقط، بلا شروحات ولا ترقيم ولا علامات اقتباس. "
    "إن لم تكن متأكداً من معلومة دوائية فلا تخمّن؛ اكتفِ بالاسم ومشتقاته."
)

_SYSTEM_PROMPT = (
    "أنت مساعد متخصص في الأدوية والمستلزمات الطبية في صيدلية سعودية. "
    "مهمتك توليد كلمات بحث (وسوم) لصنف واحد لتحسين بحث وكيل ذكاء يخدم العملاء. "
    "أعِد سطراً واحداً فقط من الكلمات. " + _RULES
)

_SYSTEM_PROMPT_BATCH = (
    "أنت مساعد متخصص في الأدوية والمستلزمات الطبية في صيدلية سعودية. "
    "ستصلك قائمة أصناف، لكل صنف رقم بين قوسين. ولّد كلمات بحث (وسوم) لكل صنف "
    "لتحسين بحث وكيل ذكاء يخدم العملاء. " + _RULES + " "
    "أعِد JSON صالحاً فقط: كائن مفاتيحه أرقام الأصناف (كنصوص) وقيمته سطر وسوم الصنف. "
    "لا تكتب أي شيء خارج JSON."
)


# ===========================================================================
# طبقة الاتصال — توجيه حسب المزوّد
# ===========================================================================
def _chat(cfg, system, user, max_tokens=1024, timeout=60):
    if not cfg or not cfg.get("api_key"):
        raise ValueError("مفتاح واجهة الذكاء الاصطناعي غير مُعدّ")
    if (cfg.get("provider") or "anthropic").lower() == "anthropic":
        return _chat_anthropic(cfg, system, user, max_tokens, timeout)
    return _chat_openai(cfg, system, user, max_tokens, timeout)


def _post_json(url, headers, body, timeout):
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        method="POST", headers=headers,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        raise RuntimeError("فشل الاتصال بالنموذج (%s): %s" % (e.code, detail[:300]))
    except urllib.error.URLError as e:
        raise RuntimeError("تعذّر الوصول إلى خدمة الذكاء الاصطناعي: %s" % e.reason)


def _chat_anthropic(cfg, system, user, max_tokens, timeout):
    payload = _post_json(
        ANTHROPIC_URL,
        {
            "x-api-key": cfg["api_key"],
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        },
        {
            "model": cfg.get("model") or DEFAULT_ANTHROPIC_MODEL,
            "max_tokens": max_tokens,
            "temperature": 0.2,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        },
        timeout,
    )
    blocks = payload.get("content") or []
    return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")


def _chat_openai(cfg, system, user, max_tokens, timeout):
    base = (cfg.get("base_url") or DEFAULT_OPENAI_BASE).rstrip("/")
    payload = _post_json(
        base + "/chat/completions",
        {
            "Authorization": "Bearer %s" % cfg["api_key"],
            "content-type": "application/json",
        },
        {
            "model": cfg.get("model"),
            "max_tokens": max_tokens,
            "temperature": 0.2,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        },
        timeout,
    )
    choices = payload.get("choices") or []
    if not choices:
        return ""
    return (choices[0].get("message") or {}).get("content", "") or ""


# ===========================================================================
# بناء cfg
# ===========================================================================
def build_cfg(provider, model, anthropic_key=None, openai_key=None, openai_base_url=None):
    provider = (provider or "anthropic").lower()
    if provider == "anthropic":
        return {"provider": "anthropic", "api_key": anthropic_key,
                "model": model or DEFAULT_ANTHROPIC_MODEL}
    return {"provider": "openai", "api_key": openai_key,
            "base_url": openai_base_url or DEFAULT_OPENAI_BASE, "model": model}


def cfg_for(role, provider, anthropic_model=None, anthropic_key=None,
            openai_model=None, openai_key=None, openai_base_url=None):
    """
    يبني cfg حسب اختيار المستخدم (provider) ونوع العملية (role: 'single' | 'bulk').
    - auto      : single → Claude، bulk → DeepSeek (الافتراضي)
    - anthropic : كل العمليات عبر Claude
    - openai    : كل العمليات عبر DeepSeek
    """
    provider = (provider or "auto").lower()
    if provider == "anthropic":
        use = "anthropic"
    elif provider == "openai":
        use = "openai"
    else:  # auto
        use = "anthropic" if role == "single" else "openai"
    if use == "anthropic":
        return build_cfg("anthropic", anthropic_model, anthropic_key=anthropic_key)
    return build_cfg("openai", openai_model, openai_key=openai_key,
                     openai_base_url=openai_base_url)


# ===========================================================================
# توليد فردي
# ===========================================================================
def _item_line(name, generic_name=None, item_type=None):
    seg = "الاسم التجاري: %s" % (name or "")
    if generic_name:
        seg += " | الاسم العلمي: %s" % generic_name
    if item_type:
        seg += " | التصنيف: %s" % item_type
    return seg


def generate_tags(name, generic_name=None, item_type=None, cfg=None, timeout=30):
    """يولّد سطر وسوم لصنف واحد. يرفع ValueError/RuntimeError عند الفشل."""
    if not (name or "").strip():
        raise ValueError("اسم الصنف فارغ")
    user = _item_line(name, generic_name, item_type) + "\nأعِد سطر الوسوم فقط."
    # 1500 بدل 300: نماذج DeepSeek الاستدلالية تحتاج متّسعاً للتفكير قبل الإخراج
    # (لا يضرّ Claude — مجرّد سقف). يهمّ حين provider=openai للسجل الواحد أيضاً.
    text = _chat(cfg, _SYSTEM_PROMPT, user, max_tokens=1500, timeout=timeout)
    text = " ".join(text.split())
    if not text:
        raise RuntimeError("النموذج أعاد نتيجة فارغة")
    return text


# ===========================================================================
# توليد مجمّع (عدة أصناف في نداء واحد)
# ===========================================================================
def _parse_json_object(text):
    t = (text or "").strip()
    if t.startswith("```"):
        t = t.strip("`")
        if t[:4].lower() == "json":
            t = t[4:]
    i, j = t.find("{"), t.rfind("}")
    if i != -1 and j != -1 and j > i:
        t = t[i:j + 1]
    return json.loads(t)


def generate_tags_batch(items, cfg, timeout=90):
    """
    items: قائمة dict بها id, name, generic_name, item_type.
    يُعيد dict: {item_id: tags}. الأصناف التي لم يُرجعها النموذج تُحذف ببساطة
    (تلتقطها الدفعة التالية). يرفع استثناءً فقط عند فشل النداء كله.
    """
    if not items:
        return {}
    lines = [
        "[%s] %s" % (it["id"], _item_line(it.get("name"), it.get("generic_name"),
                                          it.get("item_type")))
        for it in items
    ]
    user = (
        "وسِّم الأصناف التالية، رقم كل صنف بين قوسين:\n"
        + "\n".join(lines)
        + "\n\nأعِد JSON فقط: مفاتيحه أرقام الأصناف وقيمته سطر وسوم كل صنف."
    )
    # ملاحظة: نماذج DeepSeek استدلالية (reasoning) تستهلك جزءاً من max_tokens في
    # التفكير قبل الإخراج، فنترك متّسعاً كافياً وإلا عاد المحتوى فارغاً.
    max_tokens = min(8192, 120 * len(items) + 3000)
    text = _chat(cfg, _SYSTEM_PROMPT_BATCH, user, max_tokens=max_tokens, timeout=timeout)
    data = _parse_json_object(text)

    out = {}
    for it in items:
        v = data.get(str(it["id"]))
        if v is None:
            v = data.get(it["id"])
        if v:
            cleaned = " ".join(str(v).split())
            if cleaned:
                out[it["id"]] = cleaned
    return out


# ===========================================================================
# حفظ
# ===========================================================================
def store_tags(db, item_id, tags, source="ai"):
    """upsert: صف واحد لكل صنف. لا يعمل commit — المتصل مسؤول عنه."""
    row = db(db.item_tags.item_idr == item_id).select().first()
    if row:
        row.update_record(tags=tags, source=source)
    else:
        db.item_tags.insert(item_idr=item_id, tags=tags, source=source)


def _resolve_type_name(db, item):
    if item.item_type:
        kt = db.key_type(item.item_type)
        return kt.name if kt else None
    return None


def tag_and_store(db, item, cfg, source="ai"):
    """يولّد ويحفظ وسوم صنف واحد (Row من items_main). يُعيد نص الوسوم. بلا commit."""
    tags = generate_tags(
        item.name, item.generic_name, _resolve_type_name(db, item), cfg=cfg,
    )
    store_tags(db, item.id, tags, source=source)
    return tags
