# -*- coding: utf-8 -*-
#  type: ignore
import api_helpers as api

# import gluon.contrib.simplejson as json
# print (json.dumps({"c": 0, "b": 0, "a": 0}, sort_keys=True))
# sup = db().select(db.suppliers.ALL ).as_list()


def _to_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _validate_main_item_payload(data):
    errors = []
    name = (data.name or "").strip()
    if not name:
        errors.append("اسم الصنف مطلوب")
    public_price = _to_float(data.public_price, -1)
    if public_price is None or public_price < 0:
        errors.append("سعر البيع لا يمكن أن يكون سالباً")

    def valid_ref(table_name, value, message, required=True):
        if not value:
            if required:
                errors.append(message)
            return None
        try:
            row_id = int(value)
        except (TypeError, ValueError):
            errors.append(message)
            return None
        if not db[table_name][row_id]:
            errors.append(message)
            return None
        return row_id

    return errors, {
        "name": name.upper(),
        "item_id": (data.item_id or "").strip(),
        "item_unit": valid_ref("key_unit", data.item_unit, "الوحدة مطلوبة"),
        "item_type": valid_ref("key_type", data.item_type, "التصنيف مطلوب"),
        "public_price": public_price,
        "suppliers": valid_ref("suppliers", data.suppliers, "المورد مطلوب"),
        "flexible_price": data.flexible_price,
        "item_group": data.item_group,
    }


@can_access(3001)
def min_suppliers_1():
    sql = "select id , name from suppliers where stoped='F' order by id  "
    sup = db.executesql(sql, as_dict=True)
    return response.json(api.api_ok(data=sup))


@can_access(3001)
def types():
    sql = "select id , name from key_type order by id"
    sup = db.executesql(sql, as_dict=True)
    return response.json(api.api_ok(data=sup))


@can_access(3001)
def units():
    sql = "select id , name from key_unit order by id"
    sup = db.executesql(sql, as_dict=True)
    return response.json(api.api_ok(data=sup))


@can_access(3001)
def getMainItems2():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)

    # whitelist للحقول المسموح بالترتيب عليها (يمنع SQL injection في ORDER BY)
    allowed_sort = {'id', 'item_id', 'name', 'item_type', 'suppliers', 'item_group'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    conditions = []
    params      = []

    # بحث نصي — parameterized queries (لا SQL injection)
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append(
                "(upper(im.name) LIKE upper(%s)"
                " OR im.item_id  LIKE %s"
                " OR im.item_reg LIKE %s"
                " OR CAST(im.id AS text) LIKE %s)"
            )
            params.extend([pattern, pattern, pattern, pattern])

    # فلتر المورد
    if ReqVar.supplier and ReqVar.supplier not in ('', '0', 'None'):
        try:
            conditions.append("im.suppliers = %s")
            params.append(int(ReqVar.supplier))
        except (ValueError, TypeError):
            pass

    # فلتر التصنيف
    if ReqVar.types and ReqVar.types not in ('', '0', 'None'):
        try:
            conditions.append("im.item_type = %s")
            params.append(int(ReqVar.types))
        except (ValueError, TypeError):
            pass

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف
    data_sql = f"""
        SELECT
            im.id,
            UPPER(im.name)  AS name,
            im.item_id,
            im.public_price,
            im.suppliers,
            im.item_type,
            im.item_unit,
            im.flexible_price,
            im.item_group,
            s.name          AS s_name,
            kt.name         AS t_name
        FROM  items_main im
        LEFT JOIN suppliers s  ON s.id  = im.suppliers
        LEFT JOIN key_type  kt ON kt.id = im.item_type
        {where}
        ORDER BY im.{sc} {sa}
        LIMIT {rc} OFFSET {offset}
    """
    count_sql = f"SELECT COUNT(*) FROM items_main im {where}"

    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(3001)
def newMainItem():
    try:
        data = request.vars
        errors, clean_data = _validate_main_item_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.items_main.validate_and_insert(
            **clean_data
        )
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        db.commit()

        # توليد وسوم البحث للصنف الجديد (متزامن، حسب مزوّد السجل الواحد، ولا يُفشل الحفظ إن تعذّر)
        try:
            new_id = nid.get("id") if isinstance(nid, dict) else nid.id
            if new_id:
                import item_tagger
                cfg = item_tagger.cfg_for(
                    "single", ai_provider,
                    anthropic_model=ai_anthropic_model, anthropic_key=ai_anthropic_key,
                    openai_model=ai_openai_model, openai_key=ai_openai_key,
                    openai_base_url=ai_openai_base_url)
                if cfg.get("api_key"):
                    item = db.items_main(new_id)
                    if item:
                        item_tagger.tag_and_store(db, item, cfg, source="ai")
                        db.commit()
        except Exception:
            db.rollback()  # الوسوم اختيارية — دالة التعبئة المجمّعة ستلتقطه لاحقاً

        return response.json(api.api_ok(data=nid))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(3001)
def editMainItem():
    try:
        data = request.vars
        row = db.items_main[data.id]
        if not row:
            return response.json(api.api_error(mess="الصنف غير موجود"))
        errors, clean_data = _validate_main_item_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.update_record(**clean_data)
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


# ============================>  items_det
@can_access(3006)
def getItemsDet():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)

    allowed_sort = {'id', 'item_id', 'item_idr', 'supplier_inv',
                    'expiration_date', 'items_count', 'buy_price', 'public_price'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    conditions = []
    params      = []

    # بحث نصي — parameterized + يشمل اسم الصنف الآن
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append(
                "(d.item_id LIKE %s"
                " OR CAST(d.supplier_inv AS text) LIKE %s"
                " OR CAST(d.id AS text) LIKE %s"
                " OR upper(im.name) LIKE upper(%s))"
            )
            params.extend([pattern, pattern, pattern, pattern])

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف
    data_sql = f"""
        SELECT
            d.id,
            d.item_idr,
            d.item_id,
            d.public_price,
            d.supplier_inv,
            d.quantity,
            d.buy_price,
            d.expiration_date,
            d.items_count,
            d.vat,
            d.vat_in_public_price,
            d.return_count,
            UPPER(im.name) AS it_name
        FROM  items_det d
        LEFT JOIN items_main im ON im.id = d.item_idr
        {where}
        ORDER BY d.{sc} {sa}
        LIMIT {rc} OFFSET {offset}
    """
    count_sql = f"""
        SELECT COUNT(*)
        FROM  items_det d
        LEFT JOIN items_main im ON im.id = d.item_idr
        {where}
    """
    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(3006)
def editItemsDet():
    try:
        data = request.vars
        row = db.items_det[data.id]
        if not row:
            return response.json(api.api_error(mess="تفاصيل الصنف غير موجودة"))
        public_price = _to_float(data.public_price, -1)
        items_count = _to_float(data.items_count, -1)
        vat = _to_float(data.vat, -1)
        return_count = _to_float(data.return_count or 0, -1)
        errors = []
        if public_price < 0:
            errors.append("سعر البيع لا يمكن أن يكون سالباً")
        if items_count < 0:
            errors.append("الكمية لا يمكن أن تكون سالبة")
        if vat < 0:
            errors.append("الضريبة لا يمكن أن تكون سالبة")
        if return_count < 0:
            errors.append("كمية المرتجع لا يمكن أن تكون سالبة")
        if return_count > items_count:
            errors.append("كمية المرتجع لا يمكن أن تكون أكبر من الكمية")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.update_record(
            public_price=public_price,
            items_count=items_count,
            vat=vat,
            vat_in_public_price=data.vat_in_public_price,
            return_count=return_count,
        )
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


@can_access(3001, 3007)
def getCountItems():
    id = request.args(0)
    sql = "select ROUND(sum( items_count )::numeric,2) as count from items_det id where item_idr = %s "
    qry = db.executesql(sql, placeholders=[id], as_dict=True)
    re = qry[0]["count"]
    return response.json(api.api_ok(data=re))


@can_access(3007)
def editcountItem():
    data = request.vars
    item = db.items_main[data.item_id]
    if not item:
        return response.json(api.api_error(mess="الصنف غير موجود"))
    total_count = _to_float(data.total_count, -1)
    if total_count < 0:
        return response.json(api.api_error(mess="الكمية لا يمكن أن تكون سالبة"))
    if not db(db.items_det.item_idr == data.item_id).select(db.items_det.id, limitby=(0, 1)).first():
        return response.json(api.api_error(mess="لا توجد دفعات لهذا الصنف"))
    update_qry = "update items_det set items_count =0 where item_idr = %s"
    db.executesql(update_qry, placeholders=[data.item_id])
    new_count = (
        db(db.items_det.item_idr == data.item_id).select(orderby=db.items_det.id).last()
    )
    new_count.items_count = total_count
    new_count.update_record()
    db.commit()
    return response.json(api.api_ok())
