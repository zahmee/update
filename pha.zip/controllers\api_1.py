# -*- coding: utf-8 -*-
#  type: ignore
import api_helpers as api
import item_rules

# import gluon.contrib.simplejson as json
# print (json.dumps({"c": 0, "b": 0, "a": 0}, sort_keys=True))
# sup = db().select(db.suppliers.ALL ).as_list()


def _to_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _validate_main_item_payload(data):
    errors = []
    name = item_rules.normalize_name(data.name)
    if not name:
        errors.append("اسم الصنف مطلوب")
    public_price = _to_float(data.public_price, -1)
    if public_price is None or public_price < 0:
        errors.append("سعر البيع لا يمكن أن يكون سالباً")

    def valid_ref(table_name, value, message, required=True):
        if not value:
            if required:
                errors.append(message)
            return None
        try:
            row_id = int(value)
        except (TypeError, ValueError):
            errors.append(message)
            return None
        if not db[table_name][row_id]:
            errors.append(message)
            return None
        return row_id

    return errors, {
        "name": name,
        "item_id": item_rules.normalize_barcode(data.item_id),
        "item_unit": valid_ref("key_unit", data.item_unit, "الوحدة مطلوبة"),
        "item_type": valid_ref("key_type", data.item_type, "التصنيف مطلوب"),
        "public_price": public_price,
        # اختياري (قرار المالك 2026-09-17): الفارغ يُعبأ من أول فاتورة توريد للصنف
        "suppliers": valid_ref("suppliers", data.suppliers, "المورد غير صحيح", required=False),
        "flexible_price": data.flexible_price,
        "item_group": data.item_group,
    }


# ============================>  رصيد الصنف وأسعاره (شاشة المواد الأساسية)
# عتبة "قريب الانتهاء" = الافتراضي نفسه في تقرير قرب الانتهاء (items/rep_bydate)
_NEAR_EXPIRY_DAYS = 90


def _is_true(value):
    return str(value) in ("T", "True", "true", "t", "1")


# سعر البيع من مصدر واحد (modules/item_rules.py) تستخدمه أيضاً شاشة جودة البيانات
_sale_price = item_rules.sale_price


def _items_stock_prices(item_ids):
    """الرصيد الصافي وآخر سعر شراء وسعر أحدث دفعة لمجموعة أصناف باستعلام واحد.

    الرصيد صافٍ عبر كل الدفعات (الموجبة والسالبة) كما في stock_item_available،
    ولا يُحسب إلا لأصناف الصفحة المعروضة لا للجدول كله.
    """
    ids = sorted({int(i) for i in item_ids if i})
    if not ids:
        return {}
    rows = db.executesql(
        """
        SELECT i.id,
               st.stock,
               lb.buy_price            AS last_buy_price,
               lp.public_price         AS det_price,
               lp.vat                  AS det_vat,
               lp.vat_in_public_price  AS det_vat_incl
        FROM unnest(%s::int[]) AS i(id)
        LEFT JOIN LATERAL (SELECT SUM(d.items_count) AS stock
                           FROM items_det d WHERE d.item_idr = i.id) st ON TRUE
        LEFT JOIN LATERAL (SELECT d.buy_price
                           FROM items_det d
                           WHERE d.item_idr = i.id AND d.buy_price > 0
                           ORDER BY d.id DESC LIMIT 1) lb ON TRUE
        LEFT JOIN LATERAL (SELECT d.public_price, d.vat, d.vat_in_public_price
                           FROM items_det d
                           WHERE d.item_idr = i.id AND d.public_price > 0
                           ORDER BY d.id DESC LIMIT 1) lp ON TRUE
        """,
        placeholders=[ids],
        as_dict=True,
    )
    return {r["id"]: r for r in rows}


def _attach_stock_prices(row, stats):
    """يضيف إلى صف الصنف: الرصيد وآخر سعر شراء وسعر البيع الحالي."""
    stats = stats or {}
    sale, sale_ex, vat, source = _sale_price(
        stats.get("det_price"), stats.get("det_vat"),
        stats.get("det_vat_incl"), row.get("public_price"),
    )
    row["stock"] = round(_to_float(stats.get("stock"), 0.0), 2)
    row["last_buy_price"] = round(_to_float(stats.get("last_buy_price"), 0.0), 2) or None
    row["sale_price"] = sale
    row["sale_price_ex"] = sale_ex
    row["sale_vat"] = vat
    row["sale_price_source"] = source
    return row


@can_access(3001)
def min_suppliers_1():
    sql = "select id , name from suppliers where stoped='F' order by id  "
    sup = db.executesql(sql, as_dict=True)
    return response.json(api.api_ok(data=sup))


@can_access(3001)
def types():
    sql = "select id , name from key_type order by id"
    sup = db.executesql(sql, as_dict=True)
    return response.json(api.api_ok(data=sup))


@can_access(3001)
def units():
    sql = "select id , name from key_unit order by id"
    sup = db.executesql(sql, as_dict=True)
    return response.json(api.api_ok(data=sup))


@can_access(3001)
def getMainItems2():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)

    # whitelist للحقول المسموح بالترتيب عليها (يمنع SQL injection في ORDER BY)
    allowed_sort = {'id', 'item_id', 'name', 'item_type', 'suppliers', 'item_group'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    conditions = []
    params      = []

    # بحث نصي — parameterized queries (لا SQL injection)
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append(
                "(upper(im.name) LIKE upper(%s)"
                " OR im.item_id  LIKE %s"
                " OR im.item_reg LIKE %s"
                " OR CAST(im.id AS text) LIKE %s)"
            )
            params.extend([pattern, pattern, pattern, pattern])

    # فلتر المورد
    if ReqVar.supplier and ReqVar.supplier not in ('', '0', 'None'):
        try:
            conditions.append("im.suppliers = %s")
            params.append(int(ReqVar.supplier))
        except (ValueError, TypeError):
            pass

    # فلتر التصنيف
    if ReqVar.types and ReqVar.types not in ('', '0', 'None'):
        try:
            conditions.append("im.item_type = %s")
            params.append(int(ReqVar.types))
        except (ValueError, TypeError):
            pass

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف
    data_sql = f"""
        SELECT
            im.id,
            UPPER(im.name)  AS name,
            im.item_id,
            im.public_price,
            im.suppliers,
            im.item_type,
            im.item_unit,
            im.flexible_price,
            im.item_group,
            im.halt,
            im.track_stock,
            s.name          AS s_name,
            kt.name         AS t_name
        FROM  items_main im
        LEFT JOIN suppliers s  ON s.id  = im.suppliers
        LEFT JOIN key_type  kt ON kt.id = im.item_type
        {where}
        ORDER BY im.{sc} {sa}{'' if sc == 'id' else ', im.id ' + sa}
        LIMIT {rc} OFFSET {offset}
    """
    count_sql = f"SELECT COUNT(*) FROM items_main im {where}"

    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    # الرصيد والأسعار لأصناف الصفحة فقط (استعلام واحد إضافي)
    stats = _items_stock_prices([r["id"] for r in qry])
    for r in qry:
        _attach_stock_prices(r, stats.get(r["id"]))
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(3001)
def getMainItemCard():
    """بطاقة الصنف للنافذة المنبثقة في شاشة المواد (قراءة فقط): البيانات الأساسية،
    الرصيد والدفعات المتوفرة، آخر شراء، سعر البيع الحالي، وآخر عملية بيع فعلية."""
    try:
        item_idr = int(request.args(0) or request.vars.id or 0)
    except (TypeError, ValueError):
        item_idr = 0
    rows = db.executesql(
        """
        SELECT im.id, UPPER(im.name) AS name, im.item_id, im.item_reg, im.item_group,
               im.public_price, im.flexible_price, im.halt, im.seasonal_drug,
               im.track_stock, im.note,
               ku.name AS unit_name, kt.name AS type_name, s.name AS supplier_name
        FROM items_main im
        LEFT JOIN key_unit  ku ON ku.id = im.item_unit
        LEFT JOIN key_type  kt ON kt.id = im.item_type
        LEFT JOIN suppliers s  ON s.id  = im.suppliers
        WHERE im.id = %s
        """,
        placeholders=[item_idr],
        as_dict=True,
    )
    if not rows:
        return response.json(api.api_error(mess="الصنف غير موجود"))
    im = rows[0]
    today = request.now.date()

    def days_since(value):
        if not value:
            return None
        d = value.date() if hasattr(value, "date") else value
        return (today - d).days

    item = dict(
        id=im["id"],
        name=im["name"],
        item_id=im["item_id"],
        item_reg=im["item_reg"] or "",
        item_group=im["item_group"],
        unit_name=im["unit_name"] or "",
        type_name=im["type_name"] or "",
        supplier_name=im["supplier_name"] or "",
        card_price=round(_to_float(im["public_price"], 0.0), 2),
        flexible_price=_is_true(im["flexible_price"]),
        halt=_is_true(im["halt"]),
        seasonal=_is_true(im["seasonal_drug"]),
        # الفارغ = يُتابَع (انظر stock_tracked)
        track_stock=im["track_stock"] is None or _is_true(im["track_stock"]),
        note=im["note"] or "",
    )
    _attach_stock_prices(item, _items_stock_prices([item_idr]).get(item_idr))
    sale_ex = item["sale_price_ex"]

    # الدفعات التي بها رصيد (موجب أو سالب) — الأقرب انتهاءً أولاً كما في البيع
    counts = db.executesql(
        "SELECT COUNT(*) AS total_count,"
        " COUNT(*) FILTER (WHERE ABS(COALESCE(items_count, 0)) > 0.000001) AS open_count"
        " FROM items_det WHERE item_idr = %s",
        placeholders=[item_idr],
        as_dict=True,
    )[0]
    batch_rows = db.executesql(
        """
        SELECT id, supplier_inv, expiration_date, items_count, buy_price,
               public_price, vat, vat_in_public_price
        FROM items_det
        WHERE item_idr = %s AND ABS(COALESCE(items_count, 0)) > 0.000001
        ORDER BY expiration_date NULLS LAST, id
        LIMIT 50
        """,
        placeholders=[item_idr],
        as_dict=True,
    )
    batches = []
    for b in batch_rows:
        exp = b["expiration_date"]
        if not exp:
            state = ""
        elif exp < today:
            state = "expired"
        elif (exp - today).days <= _NEAR_EXPIRY_DAYS:
            state = "near"
        else:
            state = "ok"
        batches.append(dict(
            id=b["id"],
            supplier_inv=b["supplier_inv"],
            expiration_date=str(exp) if exp else "",
            expiry_state=state,
            items_count=round(_to_float(b["items_count"], 0.0), 2),
            buy_price=round(_to_float(b["buy_price"], 0.0), 2),
            sale_price=_sale_price(b["public_price"], b["vat"], b["vat_in_public_price"], 0)[0],
        ))

    # آخر شراء: أحدث دفعة لها سعر شراء، مع فاتورة التوريد ومورّدها
    last_buy = None
    lb = db.executesql(
        """
        SELECT d.buy_price, d.quantity, d.created_on, d.supplier_inv,
               sb.bill_no, sb.bill_date, sb.bill_confirmation, s.name AS supplier_name
        FROM items_det d
        LEFT JOIN suppliers_bills sb ON sb.id = d.supplier_inv
        LEFT JOIN suppliers       s  ON s.id  = sb.supplier
        WHERE d.item_idr = %s AND d.buy_price > 0
        ORDER BY d.id DESC
        LIMIT 1
        """,
        placeholders=[item_idr],
        as_dict=True,
    )
    if lb:
        lb = lb[0]
        when = lb["bill_date"] or lb["created_on"]
        last_buy = dict(
            price=round(_to_float(lb["buy_price"], 0.0), 2),
            quantity=round(_to_float(lb["quantity"], 0.0), 2),
            date=str(when)[:10] if when else "",
            days_ago=days_since(when),
            supplier_inv=lb["supplier_inv"],
            bill_no=lb["bill_no"] or "",
            supplier_name=lb["supplier_name"] or "",
            confirmed=_is_true(lb["bill_confirmation"]),
        )

    # نسبة الربح بنفس معادلة تقرير فاتورة التوريد (it_rep1): على السعر قبل الضريبة
    margin_pct = None
    if last_buy and sale_ex:
        margin_pct = round((sale_ex - last_buy["price"]) / last_buy["price"] * 100, 1)

    # آخر عملية بيع فعلية: أحدث سطر فاتورة لكل دفعة ثم الأحدث بينها.
    # (invoice_details.item_idr غير معبأ، فالربط عبر الدفعة item_number)
    last_sale = None
    ls = db.executesql(
        """
        SELECT s.amount, s.item_count, s.vat, s.created_on, s.uuid
        FROM items_det d
        CROSS JOIN LATERAL (
            SELECT x.id, x.amount, x.item_count, x.vat, x.created_on, x.uuid
            FROM invoice_details x
            WHERE x.item_number = d.id AND x.created_on IS NOT NULL
            ORDER BY x.created_on DESC, x.id DESC
            LIMIT 1
        ) s
        WHERE d.item_idr = %s
        ORDER BY s.created_on DESC, s.id DESC
        LIMIT 1
        """,
        placeholders=[item_idr],
        as_dict=True,
    )
    if ls:
        ls = ls[0]
        unit = _to_float(ls["amount"], 0.0)  # سعر الوحدة قبل الضريبة
        inv = db.executesql(
            "SELECT id FROM invoice_master WHERE uuid = %s LIMIT 1",
            placeholders=[ls["uuid"]],
        )
        last_sale = dict(
            price=round(unit * (1 + _to_float(ls["vat"], 0.0)), 2),
            price_ex=round(unit, 2),
            quantity=round(_to_float(ls["item_count"], 0.0), 2),
            date=ls["created_on"].strftime("%Y-%m-%d %H:%M"),
            days_ago=days_since(ls["created_on"]),
            invoice_no=inv[0][0] if inv else None,
        )

    return response.json(api.api_ok(data=dict(
        item=item,
        batches=batches,
        batches_total=counts["total_count"],
        batches_open=counts["open_count"],
        last_buy=last_buy,
        margin_pct=margin_pct,
        last_sale=last_sale,
    )))


@can_access(3001)
def getItemRequestDraft():
    """بيانات طلب عميل لتعبئة نافذة "صنف جديد" في شاشة المواد (زر "تحويل" في شاشة
    الطلبات). بيانات الصنف فقط — لا اسم العميل ولا جواله."""
    try:
        rid = int(request.args(0) or request.vars.id or 0)
    except (TypeError, ValueError):
        rid = 0
    req = db.item_requests(rid) if rid else None
    if not req:
        return response.json(api.api_error(mess="طلب العميل غير موجود"))
    linked = db.items_main(req.converted_to_item) if req.converted_to_item else None
    return response.json(api.api_ok(data=dict(
        id=req.id,
        name=item_rules.normalize_name(req.name),
        item_id=item_rules.normalize_barcode(req.item_id),
        generic_name=req.generic_name or "",
        supplier_name=req.supplier_name or "",
        notes=req.notes or "",
        converted_to_item=req.converted_to_item,
        converted_item_name=((linked.name or "").upper() if linked else ""),
    )))


def _same_name_warnings(name, exclude_id=0):
    same = item_rules.same_name_items(db, name, exclude_id)
    if not same:
        return []
    return ["يوجد صنف بالاسم نفسه: " + "، ".join(
        "%s (م %s، الباركود %s)" % (r["name"], r["id"], r["item_id"]) for r in same)]


def _confirm_first(data, warnings):
    """ملاحظات لا تمنع الحفظ: تُعاد للمتصفح ليؤكدها المستخدم، ثم يعيد الإرسال
    بـ confirm_warnings=1. يعيد الاستجابة أو None إن لا حاجة للتأكيد."""
    if warnings and str(data.confirm_warnings or "") != "1":
        return response.json(api.api_error(
            mess=" | ".join(warnings), need_confirm=True, warnings=warnings))
    return None


@can_access(3001)
def newInternalBarcode():
    """باركود داخلي غير مستخدم لمنتج ليس له باركود (زر «توليد» في نافذة الصنف
    الجديد): 13 خانة تبدأ بـ 2990 بخانة تحقق صحيحة. لا يحجز الرقم — التكرار يُرفض عند الحفظ."""
    return response.json(api.api_ok(data=item_rules.next_internal_barcode(db)))


@can_access(3001)
def newMainItem():
    try:
        data = request.vars
        # صنف جديد من طلب عميل: يُفحص الطلب أولاً (أوضح رفض)، ويُربط في نفس المعاملة.
        # القفل يمنع نافذتين مفتوحتين على الطلب نفسه من إنشاء صنفين مكررين له،
        # وكل رجوع قبل الإدراج يفك القفل بـ rollback.
        req = None
        if data.request_id:
            try:
                rid = int(data.request_id)
            except (TypeError, ValueError):
                rid = 0
            req = db(db.item_requests.id == rid).select(for_update=True).first()
            if not req:
                return response.json(api.api_error(mess="طلب العميل غير موجود"))
            if req.converted_to_item:
                db.rollback()
                return response.json(api.api_error(
                    mess="هذا الطلب مربوط بصنف من قبل، فلم يُنشأ صنف مكرر"))
        errors, clean_data = _validate_main_item_payload(data)
        # قواعد الباركود والاسم المشتركة (modules/item_rules.py): الخطأ يمنع الحفظ،
        # والملاحظة (طول غير قياسي، خانة تحقق خاطئة، اسم مكرر) تحتاج تأكيد المستخدم
        errors += item_rules.barcode_errors(clean_data["item_id"])
        if clean_data["name"]:
            errors += item_rules.name_errors(clean_data["name"])
        if not errors:
            owner = item_rules.barcode_owner(db, clean_data["item_id"])
            if owner:
                errors.append(item_rules.owner_message(owner))
        if errors:
            db.rollback()
            return response.json(api.api_error(mess=" | ".join(errors)))
        need = _confirm_first(data, item_rules.barcode_warnings(clean_data["item_id"])
                              + _same_name_warnings(clean_data["name"]))
        if need:
            db.rollback()
            return need
        if clean_data["suppliers"] is None:
            # المورد اختياري: حذف المفتاح بدل None لأن مدقق الحقل المرجعي يرفض القيمة الفارغة
            clean_data.pop("suppliers")
        nid = db.items_main.validate_and_insert(
            **clean_data
        )
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        new_id = nid.get("id") if isinstance(nid, dict) else nid.id
        if req:
            # الحالة لا تتغير عمداً: "متاح" تعني وصول البضاعة وتُرسل رسالة للعميل،
            # وإنشاء بطاقة الصنف ليس ذلك — يغيّرها الموظف عند التوفر فعلاً.
            req.update_record(converted_to_item=new_id)
        db.commit()

        # توليد وسوم البحث للصنف الجديد (متزامن، حسب مزوّد السجل الواحد، ولا يُفشل الحفظ إن تعذّر)
        try:
            if new_id:
                import item_tagger
                cfg = item_tagger.cfg_for(
                    "single", ai_provider,
                    anthropic_model=ai_anthropic_model, anthropic_key=ai_anthropic_key,
                    openai_model=ai_openai_model, openai_key=ai_openai_key,
                    openai_base_url=ai_openai_base_url)
                if cfg.get("api_key"):
                    item = db.items_main(new_id)
                    if item:
                        item_tagger.tag_and_store(db, item, cfg, source="ai")
                        db.commit()
        except Exception:
            db.rollback()  # الوسوم اختيارية — دالة التعبئة المجمّعة ستلتقطه لاحقاً

        return response.json(api.api_ok(data=nid, request_linked=bool(req)))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(3001)
def editMainItem():
    try:
        data = request.vars
        row = db.items_main[data.id]
        if not row:
            return response.json(api.api_error(mess="الصنف غير موجود"))
        errors, clean_data = _validate_main_item_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        # الباركود لا يُغيَّر من هنا: كل دفعة تحمل نسخة نصية منه تربطها بها نقطة البيع،
        # فتغييره في الصنف وحده يفصل الدفعات عنه (54 صنفاً انفصلت هكذا). التغيير من
        # شاشة تغيير الباركود 3014 التي تنقل الدفعات وتحفظ القديم كباركود سابق.
        if clean_data.pop("item_id") != item_rules.normalize_barcode(row.item_id):
            return response.json(api.api_error(
                mess="لا يُغيَّر الباركود من نافذة التعديل. استخدم شاشة تغيير الباركود حتى تنتقل الدفعات معه."))
        # قواعد الاسم عند تغييره فقط: الأسماء القديمة المخالفة لا تمنع تعديل باقي الخانات،
        # والحفظ يوحّد مسافاتها تلقائياً
        if clean_data["name"] != item_rules.normalize_name(row.name):
            errors = item_rules.name_errors(clean_data["name"])
            if errors:
                return response.json(api.api_error(mess=" | ".join(errors)))
            need = _confirm_first(data, _same_name_warnings(clean_data["name"], row.id))
            if need:
                return need
        row.update_record(**clean_data)
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


# ============================>  items_det
@can_access(3006)
def getItemsDet():
    ReqVar = request.vars
    pg = int(ReqVar.page        or 0)
    rc = int(ReqVar.RecordCount or 20)

    allowed_sort = {'id', 'item_id', 'item_idr', 'supplier_inv',
                    'expiration_date', 'items_count', 'buy_price', 'public_price'}
    sc = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    conditions = []
    params      = []

    # بحث نصي — parameterized + يشمل اسم الصنف الآن
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = f'%{word}%'
            conditions.append(
                "(d.item_id LIKE %s"
                " OR CAST(d.supplier_inv AS text) LIKE %s"
                " OR CAST(d.id AS text) LIKE %s"
                " OR upper(im.name) LIKE upper(%s))"
            )
            params.extend([pattern, pattern, pattern, pattern])

    where  = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc
    ph     = params if params else None

    # JOIN بدلاً من correlated subquery لكل صف
    data_sql = f"""
        SELECT
            d.id,
            d.item_idr,
            d.item_id,
            d.public_price,
            d.supplier_inv,
            d.quantity,
            d.buy_price,
            d.expiration_date,
            d.items_count,
            d.vat,
            d.vat_in_public_price,
            d.return_count,
            UPPER(im.name) AS it_name
        FROM  items_det d
        LEFT JOIN items_main im ON im.id = d.item_idr
        {where}
        ORDER BY d.{sc} {sa}
        LIMIT {rc} OFFSET {offset}
    """
    count_sql = f"""
        SELECT COUNT(*)
        FROM  items_det d
        LEFT JOIN items_main im ON im.id = d.item_idr
        {where}
    """
    qry  = db.executesql(data_sql,  placeholders=ph, as_dict=True)
    qry2 = db.executesql(count_sql, placeholders=ph, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@can_access(3006)
def editItemsDet():
    try:
        data = request.vars
        row = db.items_det[data.id]
        if not row:
            return response.json(api.api_error(mess="تفاصيل الصنف غير موجودة"))
        public_price = _to_float(data.public_price, -1)
        items_count = _to_float(data.items_count, -1)
        vat = _to_float(data.vat, -1)
        return_count = _to_float(data.return_count or 0, -1)
        errors = []
        if public_price < 0:
            errors.append("سعر البيع لا يمكن أن يكون سالباً")
        if items_count < 0:
            errors.append("الكمية لا يمكن أن تكون سالبة")
        if vat < 0:
            errors.append("الضريبة لا يمكن أن تكون سالبة")
        if return_count < 0:
            errors.append("كمية المرتجع لا يمكن أن تكون سالبة")
        if return_count > items_count:
            errors.append("كمية المرتجع لا يمكن أن تكون أكبر من الكمية")
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.update_record(
            public_price=public_price,
            vat=vat,
            vat_in_public_price=data.vat_in_public_price,
            return_count=return_count,
        )
        # تغيير الكمية يمر من الوحدة المركزية ليُسجَّل في دفتر الحركات
        stock_set(row, items_count, "تعديل يدوي", "تعديل تفاصيل الصنف", str(row.id))
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e, err=3, invno=0))


@can_access(3001, 3007)
def getCountItems():
    id = request.args(0)
    sql = "select ROUND(sum( items_count )::numeric,2) as count from items_det id where item_idr = %s "
    qry = db.executesql(sql, placeholders=[id], as_dict=True)
    re = qry[0]["count"]
    return response.json(api.api_ok(data=re))


@can_access(3007)
def editcountItem():
    data = request.vars
    item = db.items_main[data.item_id]
    if not item:
        return response.json(api.api_error(mess="الصنف غير موجود"))
    total_count = _to_float(data.total_count, -1)
    if total_count < 0:
        return response.json(api.api_error(mess="الكمية لا يمكن أن تكون سالبة"))
    if not db(db.items_det.item_idr == data.item_id).select(db.items_det.id, limitby=(0, 1)).first():
        return response.json(api.api_error(mess="لا توجد دفعات لهذا الصنف"))
    # تصفير كل الدفعات ثم وضع الإجمالي في آخر دفعة — كل خطوة تُسجَّل في الدفتر
    rows = db(db.items_det.item_idr == data.item_id).select(orderby=db.items_det.id)
    for r in rows:
        stock_set(r, 0, "تعديل يدوي", "ضبط إجمالي كمية الصنف", str(data.item_id))
    stock_set(rows.last(), total_count, "تعديل يدوي",
              "ضبط إجمالي كمية الصنف", str(data.item_id))
    db.commit()
    return response.json(api.api_ok())
