// سجل مشاكل إرسال الفواتير للهيئة — views/zatca_issues/index.html
var ziApp = new Vue({
    el: '#zi',
    data: {
        rows: [],
        stats: { open: 0, rejected: 0, warning: 0, retry: 0, removed: 0, sent_later_7d: 0, queue: 0, queue_oldest_age: '' },
        f: { state: 'open', kind: '', inv_type: '', date_from: '', date_to: '', q: '' },
        loading: false,
        page: 1,
        perPage: 50,
        total: 0,
        listSeq: 0,
        searchTimer: null,
        cur: null,
        detailLoading: false,
        detailSeq: 0,
        note: '',
        busy: false,
        modal: null
    },
    computed: {
        totalPages: function () {
            return Math.max(Math.ceil(this.total / this.perPage), 1);
        },
        emptyText: function () {
            var f = this.f;
            if (f.q || f.kind || f.inv_type || f.date_from || f.date_to) return 'لا توجد نتائج مطابقة';
            return f.state === 'open' ? 'لا توجد مشاكل مفتوحة' : 'لا توجد سجلات';
        }
    },
    mounted: function () {
        var self = this;
        var el = document.getElementById('ziModal');
        self.modal = bootstrap.Modal.getOrCreateInstance(el);
        el.addEventListener('hidden.bs.modal', function () {
            self.detailSeq++;
            self.cur = null;
            self.note = '';
        });
        self.reload();
    },
    methods: {
        money: function (v) {
            if (v === null || v === undefined || v === '') return '—';
            var n = Number(v) || 0;
            return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },
        query: function () {
            var p = new URLSearchParams();
            p.set('page', this.page);
            Object.keys(this.f).forEach(function (k) {
                if (this.f[k]) p.set(k, this.f[k]);
            }, this);
            return p.toString();
        },
        reload: function () {
            this.loadStats();
            this.loadRows();
        },
        loadStats: function () {
            var self = this;
            Api.get(window.ZI_URLS.summary).then(function (res) {
                if (Api.isOk(res)) self.stats = Api.getData(res);
            });
        },
        loadRows: function () {
            var self = this;
            var seq = ++self.listSeq;
            self.loading = true;
            Api.get(window.ZI_URLS.rows + '?' + self.query()).then(function (res) {
                if (seq !== self.listSeq) return;
                if (Api.isOk(res)) {
                    self.rows = Api.getData(res) || [];
                    self.total = res.count || 0;
                    self.perPage = res.per_page || self.perPage;
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                if (seq === self.listSeq) self.loading = false;
            });
        },
        search: function (now) {
            var self = this;
            clearTimeout(self.searchTimer);
            self.searchTimer = setTimeout(function () {
                self.page = 1;
                self.loadRows();
            }, now ? 0 : 300);
        },
        setState: function (s) {
            if (this.f.state === s) return;
            this.f.state = s;
            this.search(true);
        },
        isFilter: function (state, kind) {
            return this.f.state === state && this.f.kind === kind;
        },
        quick: function (state, kind) {
            this.f.state = state;
            this.f.kind = kind;
            this.search(true);
        },
        goPage: function (p) {
            if (p < 1 || p > this.totalPages || p === this.page) return;
            this.page = p;
            this.loadRows();
        },
        open: function (row) {
            var self = this;
            var seq = ++self.detailSeq;
            self.cur = null;
            self.note = '';
            self.detailLoading = true;
            self.modal.show();
            Api.get(window.ZI_URLS.detail + '/' + row.id).then(function (res) {
                if (seq !== self.detailSeq) return;
                if (Api.isOk(res)) {
                    self.cur = Api.getData(res);
                } else {
                    self.modal.hide();
                    Api.showError(res);
                }
            }).finally(function () {
                if (seq === self.detailSeq) self.detailLoading = false;
            });
        },
        afterAction: function (res) {
            if (Api.isOk(res)) {
                this.modal.hide();
                Api.showSuccess(res.mess);
                this.reload();
            } else {
                Api.showError(res);
            }
        },
        setIssueState: function (state) {
            var self = this;
            if (!self.cur || self.busy) return;
            if (state !== 'open' && self.note.trim().length < 3) {
                Swal.fire('تنبيه', 'اكتب ملاحظة توضح ما تم (3 أحرف على الأقل)', 'warning');
                return;
            }
            var body = new FormData();
            body.append('id', self.cur.id);
            body.append('state', state);
            body.append('note', self.note.trim());
            self.busy = true;
            Api.post(window.ZI_URLS.setState, body).then(function (res) {
                self.afterAction(res);
            }).finally(function () {
                self.busy = false;
            });
        },
        requeue: function () {
            var self = this;
            if (!self.cur || self.busy) return;
            var cur = self.cur;
            Swal.fire({
                icon: 'question',
                title: 'إعادة الفاتورة للطابور؟',
                text: 'ستُرسل في دورة الإرسال القادمة بمحتواها المحفوظ. إن لم يُعالَج سبب الرفض سترفضها الهيئة مرة أخرى.',
                showCancelButton: true,
                confirmButtonText: 'إعادة',
                cancelButtonText: 'إلغاء'
            }).then(function (r) {
                if (!r.isConfirmed || self.cur !== cur) return;
                var body = new FormData();
                body.append('id', cur.id);
                self.busy = true;
                Api.post(window.ZI_URLS.requeue, body).then(function (res) {
                    self.afterAction(res);
                }).finally(function () {
                    self.busy = false;
                });
            });
        }
    }
});
