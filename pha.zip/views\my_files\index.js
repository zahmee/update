var API_BASE = window.location.href + '/../../my_files/';
var DOWNLOAD_BASE = window.location.href + '/../../default/download/';

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: false,
            doc_type: '0'
        },
        data_row_count: 0,
        showBtn: 0,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        doc_types: [],
        selectedFile: null,
        loading: false,
    },
    created: function () {
        this.loading = true;
        // تحميل أنواع المستندات
        fetch(API_BASE + 'get_doc_types')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                this.doc_types = data;
            }.bind(this));
        // تحميل البيانات
        this.fetchData().then(function (data) {
            this.data = data.data;
            this.data_row_count = data.count;
        }.bind(this)).finally(function () { this.loading = false; }.bind(this));
    },
    computed: {
        totalPages: function () {
            return Math.ceil(this.data_row_count / this.getData.RecordCount) || 1;
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var total = this.totalPages;
            var current = this.currentPage;
            var pages = [];
            var start = Math.max(1, current - 2);
            var end = Math.min(total, current + 2);
            if (start > 1) {
                pages.push(1);
                if (start > 2) pages.push('...');
            }
            for (var i = start; i <= end; i++) {
                pages.push(i);
            }
            if (end < total) {
                if (end < total - 1) pages.push('...');
                pages.push(total);
            }
            return pages;
        },
    },
    methods: {
        fetchData: function () {
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc,
                doc_type: this.getData.doc_type
            };
            var url = new URL(API_BASE + 'get_docs');
            Object.keys(params).forEach(function (k) { url.searchParams.append(k, params[k]); });
            return fetch(url, {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
            }).then(function (r) { return r.json(); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.loading = true;
            this.fetchData().then(function (data) {
                this.data = data.data;
                this.data_row_count = data.count;
            }.bind(this)).finally(function () { this.loading = false; }.bind(this));
        },
        sortBy: function (field) {
            if (this.getData.SortBy !== field) {
                this.getData.SortBy = field;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = Object.assign({}, row);
        },
        edit_row: function () {
            this.new_row = false;
        },
        new_row_click: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedFile = null;
            if (this.$refs.fileInput) {
                this.$refs.fileInput.value = '';
            }
        },
        onFileChange: function (e) {
            this.selectedFile = e.target.files[0] || null;
        },
        save_data: function () {
            if (!this.edit_row_data.doc_type) {
                Swal.fire('تنبيه', 'يجب اختيار نوع المستند', 'error');
                return;
            }
            if (!this.edit_row_data.doc_name) {
                Swal.fire('تنبيه', 'يجب إدخال اسم المستند', 'error');
                return;
            }

            var formData = new FormData();
            formData.append('doc_type', this.edit_row_data.doc_type);
            formData.append('doc_name', this.edit_row_data.doc_name);
            formData.append('description', this.edit_row_data.description || '');
            formData.append('expiry_date', this.edit_row_data.expiry_date || '');

            if (this.selectedFile) {
                formData.append('doc_file', this.selectedFile);
            }

            var endpoint = this.new_row ? 'new_doc' : 'update_doc';
            if (!this.new_row) {
                formData.append('id', this.edit_row_data.id);
            }

            fetch(API_BASE + endpoint, {
                method: 'POST',
                body: formData
            }).then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.id && data.id > 0) {
                        if (this.new_row) {
                            this.data.splice(0, 0, data);
                            this.data_row_count++;
                        } else {
                            this.$set(this.data, this.selectedRow, data);
                        }
                        this.edit_row_data = {};
                        this.selectedRow = -1;
                        this.new_row = true;
                        this.selectedFile = null;
                        if (this.$refs.fileInput) {
                            this.$refs.fileInput.value = '';
                        }
                        bootstrap.Modal.getInstance(document.getElementById("docModal")).hide();
                        Swal.fire('تم بنجاح', 'تمت عملية الحفظ بشكل صحيح', 'success');
                    } else {
                        Swal.fire('تنبيه', data.mess || 'حصل خطأ', 'error');
                    }
                }.bind(this));
        },
        delete_doc: function () {
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف المستند: ' + row.doc_name + '؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع'
            }).then(function (result) {
                if (result.isConfirmed) {
                    fetch(API_BASE + 'delete_doc/' + row.id, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    }).then(function (r) { return r.json(); })
                        .then(function (data) {
                            if (data.status === 1) {
                                self.data.splice(self.selectedRow, 1);
                                self.data_row_count--;
                                self.selectedRow = -1;
                                self.edit_row_data = {};
                                Swal.fire('تم', 'تم حذف المستند بنجاح', 'success');
                            } else {
                                Swal.fire('خطأ', data.mess || 'حصل خطأ أثناء الحذف', 'error');
                            }
                        });
                }
            });
        },
        download_file: function () {
            var row = this.data[this.selectedRow];
            if (row && row.doc_file) {
                window.open(DOWNLOAD_BASE + row.doc_file, '_blank');
            }
        },
        cancel_data: function () {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;
            this.selectedFile = null;
            if (this.$refs.fileInput) {
                this.$refs.fileInput.value = '';
            }
        },
        isExpired: function (row) {
            if (!row.expiry_date) return false;
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            var expiry = new Date(row.expiry_date);
            return expiry < today;
        },
    }
});
