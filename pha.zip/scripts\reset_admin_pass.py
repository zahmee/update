# -*- coding: utf-8 -*-
# run: uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/reset_admin_pass.py

def reset():
    user = db(db.auth_user.email == 'zahmee@gmail.com').select().first()
    if user:
        new_hash = db.auth_user.password.validate('admin')[0]
        user.update_record(password=new_hash)
        db.commit()
        print('Password reset for', user.email)
    else:
        print('User not found')

reset()
