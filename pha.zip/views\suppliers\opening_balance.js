Vue.component('v-select', VueSelect.VueSelect);
var app = new Vue({
    el: '#app',
    data: {
        counter: 0,
        data: [],
        getData: {
            page: 0,
            RecordCount: 20,
            SearchText: '',
            SortBy: 'id',
            sortAsc: true
        },
        data_row_count: 0,
        select_obj_1: {
            serch_text: '',
            show_select: false,
            select_value: '',
            select_id: '',
        },
        select_obj_2: 0,
        showBtn: 0,
        show_model: false,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        value: '',
        options: [],
        supplier:[] ,
        Allsupplier:[] ,

    },
    created() {
        this.getData.SortBy = 'id';
        this.getData.sortAsc = false;

        fetch(window.location.href + '/../../suppliers_api/get_opening_balance', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(response => response.json())
            .then(data => {
                this.data = Api.getData(data);
                this.data_row_count = data.count;
                fetch(window.location.href + '/../../api_1/min_suppliers_1')
                    .then(response => response.json())
                    .then(resp => {
                        var data = Api.getData(resp);
                        this.supplier = data;
                        this.Allsupplier = data;
                        op = this.options;
                        data.forEach(function (el) {
                            new_el = {
                                value: el.id,
                                label: '[' + el.id + '] - ' + el.name
                            }
                            //
                            op.push(new_el);
                        });
                    })
            });
    },
    methods: {
        onChange() {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }

            var url = new URL(window.location.href + '/../../suppliers_api/get_opening_balance'),
                params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key])),
                fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        this.data = Api.getData(data);
                        this.data_row_count = data.count;

                    });
        },
        showmoor() {
            this.getData.page++;
            if (typeof this.value.value == 'undefined') {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/get_opening_balance'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    Api.getData(data).forEach(el => {
                        this.data.push(el);
                    })

                });
        },
        goToPage(page) {
            if (page === '...' || page < 1 || page > this.totalPages || page === this.currentPage) {
                return;
            }
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.edit_row_data = {};
            if (this.value) {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    supplier: this.value.value,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            } else {
                params = {
                    page: this.getData.page,
                    RecordCount: this.getData.RecordCount,
                    SearchText: this.getData.SearchText,
                    types: this.select_obj_2,
                    SortBy: this.getData.SortBy,
                    sequence: this.getData.sortAsc
                }
            }
            var url = new URL(window.location.href + '/../../suppliers_api/get_opening_balance'),
                params = params
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
            fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }).then((response) => response.json())
                .then((data) => {
                    this.data = Api.getData(data);
                    this.data_row_count = data.count;
                });
        },
        sortBy(filed) {
            if (this.getData.SortBy != filed) {
                this.getData.SortBy = filed;
                this.getData.sortAsc = true;
            } else {
                this.getData.sortAsc = !this.getData.sortAsc;
            }
            this.onChange();
        },
        rowSelect(index, row) {
            this.selectedRow = index;
            this.edit_row_data = { ...row };
        },
        on_change_select() {
            this.$forceUpdate();
        },

        edit_row() {
            this.new_row = false;
            this.edit_row_data.supplier = { value: this.edit_row_data.supplier, label: this.edit_row_data.supplier_n }
        },
        new_row_click() {
            this.new_row = true;
            this.edit_row_data = {
            };
        },
        save_data() {
            if (!this.edit_row_data.supplier || !this.edit_row_data.year_balance 
                || !this.edit_row_data.account   ) {
                Swal.fire(
                    'تنبية',
                    'يجب ادخال [ المورد - السنة - المبلغ ] .',
                    'error'
                );
                return;
            }
            if (this.new_row) {
                // اضافة جديد
                var url = new URL(window.location.href + '/../../suppliers_api/new_o_b');
                params = this.edit_row_data;
                params.supplier = JSON.stringify(this.edit_row_data.supplier);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (Api.isOk(data)) {
                            var result = Api.getData(data);
                            this.edit_row_data.id = result.id;
                            this.data.splice(0, 0, result);
                            this.data_row_count = parseInt(this.data_row_count || 0) + 1;
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            //row_modal.hide();
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Api.showError(data);
                        }
                    });
            } else {
                // تعديل 
                //
                var url = new URL(window.location.href + '/../../suppliers_api/edit_o_b');
                params = this.edit_row_data;
                params.supplier = JSON.stringify(this.edit_row_data.supplier);
                Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                }).then((response) => response.json())
                    .then((data) => {
                        if (Api.isOk(data)) {
                            this.$set(this.data, this.selectedRow, Api.getData(data));
                            this.edit_row_data = {};
                            this.selectedRow = -1;
                            const elem = document.getElementById("exampleModal");
                            const modal = bootstrap.Modal.getInstance(elem);
                            modal.hide();
                            Swal.fire(
                                'عمل رائع',
                                'شكرا لك لقد تمت عملية الحفظ بشكل صحيح',
                                'success'
                            );
                        } else {
                            Api.showError(data);
                        }
                    });
            }
        },
        cancel_data() {
            this.new_row = true;
            this.edit_row_data = {};
            this.selectedRow = -1;

        },
        account_movement() {
            url = window.location.href + '/../../suppliers_report/account_movement/' + this.edit_row_data.id;
            window.open(url, "_self"); //items_qry/items_sales
        },
        formatNum(val) {
            if (val === undefined || val === null || val === '') return '0.00';
            var num = parseFloat(val);
            if (isNaN(num)) return '0.00';
            return num.toFixed(2);
        },
    },
    watch: {
        value: function (val) {
            this.onChange();
        }
    },
    computed: {
        currentPage() {
            return this.getData.page + 1;
        },
        totalPages() {
            var recordCount = parseInt(this.getData.RecordCount || 20);
            var rowCount = parseInt(this.data_row_count || 0);
            return Math.max(1, Math.ceil(rowCount / recordCount));
        },
        visiblePages() {
            var pages = [];
            var total = this.totalPages;
            var current = this.currentPage;
            if (total <= 7) {
                for (var i = 1; i <= total; i++) {
                    pages.push(i);
                }
                return pages;
            }
            pages.push(1);
            if (current > 4) {
                pages.push('...');
            }
            var start = Math.max(2, current - 1);
            var end = Math.min(total - 1, current + 1);
            for (var p = start; p <= end; p++) {
                pages.push(p);
            }
            if (current < total - 3) {
                pages.push('...');
            }
            pages.push(total);
            return pages;
        },
    },

});
