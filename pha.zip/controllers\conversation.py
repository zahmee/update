# -*- coding: utf-8 -*-
# type: ignore
"""
شاشة المحادثات (ربط واتساب/تيليجرام) — conversation_log كواجهة محادثة.

- index()         : الصفحة (admin) + إحصائيات مختصرة.
- conversations() : قائمة المحادثات مجمّعة (صف واحد لكل مُحادِث، الأحدث أعلى) + بحث + تصفّح.
- thread()        : رسائل محادثة واحدة مرتّبة زمنياً (الأقدم أعلى) كفقاعات.

التجميع بمفتاح المحادثة = COALESCE(sender_id, phone).
DISTINCT ON خاص بـ PostgreSQL → SQL خام بـ placeholders (آمن). خيط الرسائل بـ DAL.
"""
import api_helpers as api


@auth.requires_membership("admin")
def index():
    t = db.conversation_log
    today = request.now.replace(hour=0, minute=0, second=0, microsecond=0)
    return dict(
        stat_total=db(t.id > 0).count(),
        stat_today=db(t.created_on >= today).count(),
        stat_convs=db.executesql(
            "SELECT COUNT(DISTINCT COALESCE(sender_id, phone)) FROM conversation_log")[0][0],
    )


@auth.requires_membership("admin")
def conversations():
    """صف واحد لكل محادثة: آخر رسالة + العدد، مرتّبة بالأحدث."""
    v = request.vars
    try:
        page = max(0, int(v.page or 0))
    except (TypeError, ValueError):
        page = 0
    try:
        rc = min(max(int(v.RecordCount or 40), 1), 100)
    except (TypeError, ValueError):
        rc = 40
    offset = page * rc

    inner_where = ""
    iparams = []
    s = (v.search or "").strip()
    if s:
        pat = "%" + s + "%"
        inner_where = " WHERE (sender_id ILIKE %s OR phone ILIKE %s OR content ILIKE %s)"
        iparams = [pat, pat, pat]

    sql = (
        "SELECT t.conv_key, t.sender_id, t.channel, t.phone, t.customer_id,"
        " t.content, t.msg_type, t.direction, t.created_on, c.cnt"
        " FROM (SELECT DISTINCT ON (COALESCE(sender_id, phone))"
        "         COALESCE(sender_id, phone) AS conv_key, sender_id, channel, phone,"
        "         customer_id, content, msg_type, direction, created_on"
        "       FROM conversation_log" + inner_where +
        "       ORDER BY COALESCE(sender_id, phone), created_on DESC) t"
        " JOIN (SELECT COALESCE(sender_id, phone) AS k, COUNT(*) cnt"
        "       FROM conversation_log GROUP BY COALESCE(sender_id, phone)) c"
        "   ON c.k = t.conv_key"
        " ORDER BY t.created_on DESC LIMIT %s OFFSET %s"
    )
    rows = db.executesql(sql, placeholders=iparams + [rc, offset], as_dict=True)

    count = db.executesql(
        "SELECT COUNT(DISTINCT COALESCE(sender_id, phone)) FROM conversation_log" + inner_where,
        placeholders=iparams,
    )[0][0]

    # أسماء العملاء دفعة واحدة
    cust_ids = {r["customer_id"] for r in rows if r["customer_id"]}
    names = {}
    if cust_ids:
        for cst in db(db.customers.id.belongs(cust_ids)).select(
            db.customers.id, db.customers.name
        ):
            names[cst.id] = cst.name

    data = [{
        "conv_key": r["conv_key"],
        "sender_id": r["sender_id"],
        "channel": r["channel"],
        "phone": r["phone"],
        "customer_id": r["customer_id"],
        "customer_name": names.get(r["customer_id"]),
        "last_content": r["content"],
        "last_type": r["msg_type"],
        "last_direction": r["direction"],
        "last_at": str(r["created_on"]) if r["created_on"] else "",
        "count": r["cnt"],
    } for r in rows]

    return response.json(api.api_list(rows=data, count=count))


@auth.requires_membership("admin")
def thread():
    """رسائل محادثة واحدة مرتّبة زمنياً تصاعدياً (الأقدم أعلى)."""
    key = (request.vars.key or "").strip()
    if not key:
        return response.json(api.api_error(mess="مفتاح المحادثة مطلوب"))
    try:
        limit = min(max(int(request.vars.limit or 500), 1), 2000)
    except (TypeError, ValueError):
        limit = 500

    t = db.conversation_log
    q = (t.sender_id == key) | (t.phone == key)
    # نأخذ الأحدث limit ثم نعرضها تصاعدياً
    rows = db(q).select(orderby=~t.created_on, limitby=(0, limit))
    rows = list(reversed(rows))

    name = None
    cid = next((r.customer_id for r in rows if r.customer_id), None)
    if cid:
        c = db.customers(cid)
        name = c.name if c else None

    data = [{
        "id": r.id,
        "created_on": str(r.created_on) if r.created_on else "",
        "channel": r.channel,
        "sender_id": r.sender_id,
        "phone": r.phone,
        "customer_id": r.customer_id,
        "direction": r.direction,
        "msg_type": r.msg_type,
        "content": r.content,
        "message_id": r.message_id,
        "meta": r.meta,
    } for r in rows]

    header = {
        "key": key,
        "channel": rows[-1].channel if rows else None,
        "phone": next((r.phone for r in rows if r.phone), None),
        "customer_name": name,
        "count": len(data),
    }
    return response.json(api.api_ok(data={"header": header, "messages": data}))


@auth.requires_membership("admin")
def delete_message():
    """حذف رسالة واحدة بالـ id."""
    mid = request.vars.id
    if not mid or not str(mid).isdigit():
        return response.json(api.api_error(mess="رقم الرسالة مطلوب"))
    n = db(db.conversation_log.id == int(mid)).delete()
    db.commit()
    if not n:
        return response.json(api.api_error(mess="الرسالة غير موجودة"))
    return response.json(api.api_ok(data={"deleted": n, "id": int(mid)}))


@auth.requires_membership("admin")
def delete_conversation():
    """حذف محادثة كاملة (كل رسائل المُحادِث) بمفتاح المحادثة."""
    key = (request.vars.key or "").strip()
    if not key:
        return response.json(api.api_error(mess="مفتاح المحادثة مطلوب"))
    t = db.conversation_log
    n = db((t.sender_id == key) | (t.phone == key)).delete()
    db.commit()
    return response.json(api.api_ok(data={"deleted": n, "key": key}))


@auth.requires_membership("admin")
def delete_all_conversations():
    """حذف جميع المحادثات (كل سجلات conversation_log) — يتطلب confirm=yes."""
    if (request.vars.confirm or "") != "yes":
        return response.json(api.api_error(mess="تأكيد الحذف مطلوب"))
    n = db(db.conversation_log.id > 0).delete()
    db.commit()
    return response.json(api.api_ok(data={"deleted": n}))
