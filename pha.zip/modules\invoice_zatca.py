# -*- coding: utf-8 -*-
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP


def round_up(x):
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def round_json_values(data):
    """
    دالة تقوم بالمرور على كائن JSON (سواء كان قاموس أو قائمة)
    وتقرب أي قيمة عشرية (float) إلى خانتين بدقة مالية.
    """
    if isinstance(data, dict):
        return {k: round_json_values(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [round_json_values(i) for i in data]
    elif isinstance(data, float):
        d = Decimal(str(data))
        rounded = d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return float(rounded)
    return data


ZATCA_TEMPLATE = {
    "cert_info": {
        "privateKey": "",
        "csr": "",
        "pcsid_binarySecurityToken": "",
        "pcsid_secret": "",
        "environment": "Simulation",
        "reportingUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/reporting/single",
        "clearanceUrl": "https://gw-fatoora.zatca.gov.sa/e-invoicing/simulation/invoices/clearance/single"
    },
    "input_xml": {
        "xml_template_path": "xxx.xml"
    },
    "document_type": "SIMSI",
    "invoice_number": "DOC-0001",
    "icv_start": 1,
    "pih_base64": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
    "invoice": {
        "ProfileID": "reporting:1.0",
        "ID": "SME00011",
        "UUID": "8e6000cf-1a98-4500-b3e7-b5d5954bc10d",
        "IssueDate": "2025-11-25",
        "IssueTime": "02:30:08",
        "InvoiceTypeCode": "388",
        "InvoiceTypeCodeName": "0200000",
        "Note": "",
        "DocumentCurrencyCode": "SAR",
        "TaxCurrencyCode": "SAR",
        "BillingReference": "",
        "AdditionalDocumentReferences": [
            {
                "ID": "ICV",
                "UUID": "10"
            },
            {
                "ID": "PIH",
                "Attachment": "NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==",
                "FileName": "pih.txt"
            }
        ],
        "SupplierStreetName": "1234 Street",
        "SupplierBuildingNumber": "2322",
        "SupplierCityName": "Riyadh",
        "SupplierDistrict": "Al-Murabba",
        "SupplierPostalZone": "23333",
        "SupplierCountryCode": "SA",
        "SupplierVAT": "",
        "SupplierName": "",
        "SupplierSchemeID": "CRN",
        "SupplierCRN": "",
        "CustomerStreetName": "*",
        "CustomerBuildingNumber": "1111",
        "CustomerCityName": "*",
        "CustomerDistrict": "*",
        "CustomerPostalZone": "12345",
        "CustomerCountryCode": "SA",
        "CustomerVAT": "",
        "CustomerName": "****",
        "CustomerCRN": "",
        "DeliveryDate": "2025-01-01",
        "PaymentMeansCode": "10",
        "AllowanceCharge": {
            "ChargeIndicator": "False",
            "Reason": "discount",
            "Amount": 0.00,
            "TaxCategories": [
                {"ID": "S", "Percent": 15, "SchemeID": "VAT"}
            ]
        },
        "InvoiceLines": [],
        "TaxAmount": 30.15,
        "TaxableAmount": 201.00,
        "TaxPercent": 15.00,
        "LineExtensionAmount": 201.00,
        "TaxExclusiveAmount": 201.00,
        "TaxInclusiveAmount": 231.15,
        "AllowanceTotalAmount": 0.00,
        "PrepaidAmount": 0.00,
        "PayableAmount": 231.15
    }
}


def generate_invoice_json(db, invo, invtype):
    try:
        csr_config = db(db.csr_config.id > 0).select().first()
        now = datetime.now()
        environment_type = csr_config.environment
        if environment_type.lower() == "nonproduction":
            api_path = "developer-portal"
        elif environment_type.lower() == "simulation":
            api_path = "simulation"
        elif environment_type.lower() == "production":
            api_path = "core"

        invoce = invo
        import copy
        re_data = copy.deepcopy(ZATCA_TEMPLATE)
        re_data["cert_info"]["privateKey"] = csr_config.privatekey
        re_data["cert_info"]["csr"] = csr_config.csr
        re_data["cert_info"]["pcsid_binarySecurityToken"] = csr_config.pcsid_binarysecuritytoken
        re_data["cert_info"]["pcsid_secret"] = csr_config.pcsid_secret
        re_data["cert_info"]["environment"] = csr_config.environment
        re_data["cert_info"]["reportingUrl"] = (
            f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/reporting/single"
        )
        re_data["cert_info"]["clearanceUrl"] = (
            f"https://gw-fatoora.zatca.gov.sa/e-invoicing/{api_path}/invoices/clearance/single"
        )
        re_data["document_type"] = invtype
        re_data["invoice_number"] = "INV-" + invoce["invoice_number"].zfill(12)
        re_data["invoice"]["ID"] = "INV-" + invoce["invoice_number"].zfill(12)
        re_data["invoice"]["UUID"] = invoce.uuid
        re_data["invoice"]["IssueDate"] = now.strftime("%Y-%m-%d")
        re_data["invoice"]["IssueTime"] = now.strftime("%H:%M:%S")
        re_data["invoice"]["AdditionalDocumentReferences"][0]["UUID"] = str(csr_config.icv)
        re_data["invoice"]["AdditionalDocumentReferences"][1]["Attachment"] = csr_config.pih
        # معلومات المورد
        re_data["invoice"]["SupplierStreetName"] = csr_config.address_street_name
        re_data["invoice"]["SupplierBuildingNumber"] = csr_config.address_building_number
        re_data["invoice"]["SupplierCityName"] = csr_config.address_city_name
        re_data["invoice"]["SupplierDistrict"] = csr_config.address_neighborhood
        re_data["invoice"]["SupplierPostalZone"] = csr_config.address_postal_zone
        re_data["invoice"]["SupplierVAT"] = csr_config.organization_identifier
        re_data["invoice"]["SupplierName"] = csr_config.organization_name
        re_data["invoice"]["SupplierCRN"] = csr_config.company_id
        # معلومات العميل
        if invtype.startswith("STD"):
            if invoce.customer > 1:
                customer = db.customers[invoce.customer]
                re_data["invoice"]["CustomerStreetName"] = "main"
                re_data["invoice"]["CustomerBuildingNumber"] = "1111"
                re_data["invoice"]["CustomerCityName"] = "my city"
                re_data["invoice"]["CustomerDistrict"] = "my dist"
                re_data["invoice"]["CustomerPostalZone"] = "12345"
                re_data["invoice"]["CustomerCountryCode"] = "SA"
                re_data["invoice"]["CustomerVAT"] = customer.vat
                re_data["invoice"]["CustomerName"] = customer.name
                re_data["invoice"]["CustomerCRN"] = customer.crn
        re_data["invoice"]["PaymentMeansCode"] = "1"
        # تفاصيل الاصناف
        inv_lines = []
        line_id = 1
        for item in invoce.itm:
            if item["vat"] > 0:
                line = {
                    "ID": str(item["id"]),
                    "UnitCode": "PCE",
                    "Quantity": float(item["count"]),
                    "LineExtensionAmount": float(item["LineExtensionAmount"]),
                    "TaxAmount": float(item["vat_mount"]),
                    "RoundingAmount": float(item["total"]),
                    "Name": item["name"],
                    "TaxCategoryID": "S",
                    "TaxPercent": 15.00,
                    "PriceAmount": float(item["public_price"]),
                    "AllowanceCharge": {
                        "ChargeIndicator": "False",
                        "Reason": "discount",
                        "Amount": 0.00,
                    },
                }
            else:
                line = {
                    "ID": str(item["id"]),
                    "UnitCode": "PCE",
                    "Quantity": float(item["count"]),
                    "LineExtensionAmount": float(item["LineExtensionAmount"]),
                    "TaxAmount": 0.00,
                    "RoundingAmount": float(item["total"]),
                    "Name": item["name"],
                    "TaxCategoryID": "Z",
                    "TaxPercent": 0.00,
                    "PriceAmount": float(item["public_price"]),
                    "AllowanceCharge": {
                        "ChargeIndicator": "False",
                        "Reason": "discount",
                        "Amount": 0.00,
                    },
                }
            inv_lines.append(line)
            line_id += 1

        re_data["invoice"]["InvoiceLines"] = inv_lines
        # القيم المالية
        if invoce.vat < 0:
            invoce.vat = 0
        re_data["invoice"]["TaxAmount"] = round(float(invoce.vat), 2)
        re_data["invoice"]["TaxableAmount"] = round(float(invoce.TaxableAmount), 2)
        re_data["invoice"]["TaxPercent"] = 15.00
        re_data["invoice"]["LineExtensionAmount"] = round(float(invoce.LineExtensionAmount), 2)
        re_data["invoice"]["TaxExclusiveAmount"] = round(float(invoce.LineExtensionAmount), 2)
        re_data["invoice"]["TaxInclusiveAmount"] = round(float(invoce.totalAfterAll), 2)
        re_data["invoice"]["AllowanceTotalAmount"] = 0.00
        re_data["invoice"]["PayableAmount"] = round(float(invoce.totalAfterAll), 2)
        return re_data
    except Exception as e:
        print(f"error : {e}")
        return str(e)
