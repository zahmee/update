# -*- coding: utf-8 -*-
#  type: ignore
import random
from datetime import datetime, timedelta

import send_sms as sms
import api_helpers as api


@auth.requires_login()
def index():
    return dict()


@auth.requires_login()
def get_my_status():
    try:
        emp = db(db.employees.user_id == auth.user_id).select().first()
        if not emp:
            return response.json(api.api_error(mess="not_linked"))

        # البحث عن سجل مفتوح (حضور بدون انصراف) — قد يكون من يوم سابق (دوام ليلي)
        open_att = db(
            (db.attendance.employee == emp.id) &
            (db.attendance.check_in != None) &
            (db.attendance.check_out == None)
        ).select(orderby=~db.attendance.id, limitby=(0, 1)).first()

        # سجلات اليوم المكتملة
        today = request.now.date()
        today_records = db(
            (db.attendance.employee == emp.id) &
            (db.attendance.att_date == today) &
            (db.attendance.check_out != None)
        ).select(orderby=~db.attendance.id)

        att = open_att

        att_data = None
        if att:
            att_data = {
                "id": att.id,
                "att_date": str(att.att_date),
                "check_in": str(att.check_in) if att.check_in else None,
                "check_out": str(att.check_out) if att.check_out else None,
                "shift_start": str(att.shift_start) if att.shift_start else None,
                "shift_end": str(att.shift_end) if att.shift_end else None,
                "shift_hours": att.shift_hours or 0,
            }

        # سجلات اليوم المكتملة
        today_list = []
        for r in today_records:
            today_list.append({
                "id": r.id,
                "check_in": str(r.check_in) if r.check_in else None,
                "check_out": str(r.check_out) if r.check_out else None,
                "shift_start": str(r.shift_start) if r.shift_start else None,
                "shift_end": str(r.shift_end) if r.shift_end else None,
                "shift_hours": r.shift_hours or 0,
            })

        return response.json(api.api_ok(data={
            "employee": {
                "id": emp.id,
                "emp_name": emp.emp_name,
                "mobile": emp.mobile or '',
            },
            "today": att_data,
            "today_records": today_list,
        }))
    except Exception as e:
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def request_otp():
    try:
        data = request.vars
        emp = db(db.employees.user_id == auth.user_id).select().first()
        if not emp:
            return response.json(api.api_error(mess="لم يتم ربط حسابك بسجل موظف"))

        if not emp.mobile:
            return response.json(api.api_error(mess="لا يوجد رقم جوال مسجل لك"))

        otp_type = data.otp_type  # "in" or "out"
        shift_time = data.shift_time or None

        # البحث عن سجل مفتوح (حضور بدون انصراف)
        open_att = db(
            (db.attendance.employee == emp.id) &
            (db.attendance.check_in != None) &
            (db.attendance.check_out == None)
        ).select(orderby=~db.attendance.id, limitby=(0, 1)).first()

        if otp_type == "in":
            if open_att:
                return response.json(api.api_error(mess="لديك سجل حضور مفتوح لم يتم تسجيل انصرافه بعد"))

        if otp_type == "out":
            if not open_att:
                return response.json(api.api_error(mess="لا يوجد سجل حضور مفتوح لتسجيل الانصراف"))

        # إبطال OTPs السابقة غير المستخدمة
        db(
            (db.attendance_otp.employee == emp.id) &
            (db.attendance_otp.is_used == False)
        ).update(is_used=True)

        # توليد OTP جديد
        otp_code = str(random.randint(100000, 999999))

        db.attendance_otp.insert(
            employee=emp.id,
            otp_code=otp_code,
            otp_type=otp_type,
            shift_time=shift_time,
            created_on=request.now,
            is_used=False,
        )
        db.commit()

        # إرسال SMS
        try:
            msg = "رمز التحقق للحضور والانصراف: " + otp_code
            p = sms.SMS(sms_authorization, sms_sender)
            mobile = emp.mobile
            if mobile.startswith("0"):
                mobile = "966" + mobile[1:]
            elif not mobile.startswith("966") and not mobile.startswith("+966"):
                mobile = "966" + mobile
            p.send(mobile, msg)
        except Exception:
            pass  # SMS failure should not block OTP creation

        return response.json(api.api_ok(mess="تم إرسال رمز التحقق إلى جوالك"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def verify_otp():
    try:
        data = request.vars
        emp = db(db.employees.user_id == auth.user_id).select().first()
        if not emp:
            return response.json(api.api_error(mess="لم يتم ربط حسابك بسجل موظف"))

        otp_type = data.otp_type
        otp_code = data.otp_code

        # البحث عن OTP صالح (غير مستخدم، آخر 5 دقائق)
        five_min_ago = request.now - timedelta(minutes=5)
        otp = db(
            (db.attendance_otp.employee == emp.id) &
            (db.attendance_otp.otp_code == otp_code) &
            (db.attendance_otp.otp_type == otp_type) &
            (db.attendance_otp.is_used == False) &
            (db.attendance_otp.created_on >= five_min_ago)
        ).select(orderby=~db.attendance_otp.id, limitby=(0, 1)).first()

        if not otp:
            return response.json(api.api_error(mess="رمز التحقق غير صحيح أو منتهي الصلاحية"))

        # تعليم OTP كمستخدم
        otp.update_record(is_used=True)

        today = request.now.date()
        now = request.now

        if otp_type == "in":
            # تسجيل حضور — يسمح بأكثر من دورية في اليوم
            db.attendance.insert(
                employee=emp.id,
                att_date=today,
                check_in=now,
                shift_start=otp.shift_time,
            )
            db.commit()
            return response.json(api.api_ok(mess="تم تسجيل حضورك بنجاح", data={"type": "in"}))
        else:
            # تسجيل انصراف — البحث عن آخر سجل مفتوح (قد يكون من يوم سابق)
            att = db(
                (db.attendance.employee == emp.id) &
                (db.attendance.check_in != None) &
                (db.attendance.check_out == None)
            ).select(orderby=~db.attendance.id, limitby=(0, 1)).first()

            if not att:
                return response.json(api.api_error(mess="لا يوجد سجل حضور مفتوح"))

            # حساب ساعات العمل الفعلية
            check_in = att.check_in
            shift_hours = 0
            if check_in:
                diff = now - check_in
                shift_hours = round(diff.total_seconds() / 3600, 2)

            att.update_record(
                check_out=now,
                shift_end=otp.shift_time,
                shift_hours=shift_hours,
            )
            db.commit()
            return response.json(api.api_ok(
                mess="تم تسجيل انصرافك بنجاح",
                data={"type": "out", "hours": shift_hours},
            ))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def my_attendance():
    try:
        emp = db(db.employees.user_id == auth.user_id).select().first()
        if not emp:
            return response.json(api.api_list(rows=[], count=0))

        pg = int(request.vars.page or 0)
        rc = int(request.vars.RecordCount or 20)
        offset = pg * rc

        qry = db.executesql(
            "SELECT id, att_date, check_in, check_out, shift_start, shift_end, "
            "shift_hours FROM attendance "
            "WHERE employee = %s ORDER BY check_in DESC LIMIT %s OFFSET %s",
            placeholders=[emp.id, rc, offset], as_dict=True
        )
        cnt = db.executesql(
            "SELECT count(*) FROM attendance WHERE employee = %s",
            placeholders=[emp.id], as_dict=True
        )
        return response.json(api.api_list(rows=qry, count=cnt[0]["count"] if cnt else 0))
    except Exception as e:
        return response.json(api.api_error(mess=e))


@auth.requires_membership("admin")
def report():
    return dict()


@auth.requires_membership("admin")
def get_report_data():
    try:
        ReqVar = request.vars
        pg = int(ReqVar.page or 0)
        rc = int(ReqVar.RecordCount or 50)

        conditions = ["1=1"]
        params = []

        if ReqVar.employee_id and ReqVar.employee_id != '' and ReqVar.employee_id != '0':
            conditions.append("a.employee = %s")
            params.append(int(ReqVar.employee_id))

        if ReqVar.date_from and ReqVar.date_from != '':
            conditions.append("a.att_date >= %s")
            params.append(ReqVar.date_from)

        if ReqVar.date_to and ReqVar.date_to != '':
            conditions.append("a.att_date <= %s")
            params.append(ReqVar.date_to)

        where = " WHERE " + " AND ".join(conditions)
        offset = pg * rc

        sql = (
            "SELECT a.id, a.att_date, a.check_in, a.check_out, "
            "a.shift_start, a.shift_end, a.shift_hours, "
            "e.emp_name "
            "FROM attendance a "
            "LEFT JOIN employees e ON e.id = a.employee "
            + where +
            " ORDER BY a.check_in DESC, e.emp_name "
            "LIMIT %s OFFSET %s"
        )
        params_data = list(params)
        params_data.extend([rc, offset])

        sql_count = (
            "SELECT count(*) FROM attendance a "
            "LEFT JOIN employees e ON e.id = a.employee "
            + where
        )

        sql_summary = (
            "SELECT COUNT(*) AS total_shifts, "
            "COALESCE(SUM(a.shift_hours), 0) AS total_hours "
            "FROM attendance a "
            "LEFT JOIN employees e ON e.id = a.employee "
            + where
        )

        qry = db.executesql(sql, placeholders=params_data, as_dict=True)
        cnt = db.executesql(sql_count, placeholders=params if params else None, as_dict=True)
        summary = db.executesql(sql_summary, placeholders=params if params else None, as_dict=True)

        return response.json(api.api_list(
            rows=qry,
            count=cnt[0]["count"] if cnt else 0,
            summary=summary[0] if summary else {"total_shifts": 0, "total_hours": 0},
        ))
    except Exception as e:
        return response.json(api.api_error(mess=e))
