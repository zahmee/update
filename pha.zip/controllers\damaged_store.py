# -*- coding: utf-8 -*-
#  type: ignore
"""مستودع التالف — ترحيل البضاعة المنتهية من مرتجعات الموردين ومتابعة ما فيه.

الترحيل (2017، للمدير): ينقل أسطر فاتورة مرتجع غير معتمدة إلى المستودع، ويخصمها
من مخزون الصيدلية بحركة «تالف»، ويحذفها من المرتجع. لا شيء على حساب المورد.
الاستعراض (2017 أو 2018): القائمة والملخص والتصدير.
الإخراج من المستودع (2017): يسجّل خروج البضاعة (تعويض/إتلاف/تصحيح) ولا يمس
المخزون، لأن الخصم تم عند الترحيل.
"""

import io
import json

import api_helpers as api

_EPS = 1e-6
_FROM = (
    " FROM damaged_store_line l"
    " JOIN damaged_store s ON s.id = l.damaged_store"
    " LEFT JOIN items_main im ON im.id = l.item_main"
)
_SORTS = {
    "date": "s.created_on DESC, l.id",
    "name": "l.item_name, l.id",
    "expiry": "l.expiration_date NULLS LAST, l.id",
    "value": "(l.qty - l.qty_out) * l.buy_price DESC, l.id",
    "supplier": "s.supplier_name, l.item_name, l.id",
}


def _f(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _ids(raw):
    """«1,2,3» أو قائمة → أرقام صحيحة فريدة مرتبة."""
    if raw is None:
        return []
    parts = raw if isinstance(raw, (list, tuple)) else str(raw).split(",")
    return sorted({int(p) for p in (str(x).strip() for x in parts) if p.isdigit()})


def _det_id(raw):
    s = str(raw or "").strip()
    return int(s) if s.isdigit() else None


def _is_post():
    return request.env.request_method == "POST"


def _refresh_return_totals(ret_id):
    """إعادة احتساب رأس المرتجع بعد نقل بعض أسطره — نفس حساب suppliers_api."""
    db.executesql(
        "UPDATE returned_supply SET"
        " item_count = (SELECT COUNT(*) FROM returned_supply_det WHERE returned_supply = %s),"
        " item_sum = (SELECT SUM(item_count) FROM returned_supply_det WHERE returned_supply = %s),"
        " real_total = (SELECT SUM(total) FROM returned_supply_det WHERE returned_supply = %s),"
        " real_total2 = (SELECT SUM(total_2) FROM returned_supply_det WHERE returned_supply = %s)"
        " WHERE id = %s",
        placeholders=[ret_id] * 5,
    )


# ==============================================================================
#  الترحيل
# ==============================================================================
def _transfer_state(ret_id, line_ids=None, lock=False, allow_empty=False, deduct=True):
    """الوضع الكامل لترحيل فاتورة مرتجع — مشترك بين المعاينة والتنفيذ.

    lock=True (التنفيذ): يقفل رأس الفاتورة ثم أسطرها ثم الدفعات بترتيب تصاعدي،
    فتُقرأ الأرصدة بعد انتهاء أي بيع جارٍ ولا تتغير حتى نهاية العملية.

    deduct=True: خصم كل سطر = الأقل من كميته ومن رصيد دفعته المتبقي بعد الأسطر
    المختارة السابقة لنفس الدفعة: لا يُخصم أكثر من الموجود ولا ينزل رصيد تحت
    الصفر. ما لم يُخصم يبقى ظاهراً في السطر (short) — غالباً تكرار إدراج أو صنف
    يحتاج جرداً، ولا يُخصم من دفعات أخرى للصنف لأن ذلك قد يُنقص مخزوناً موجوداً.
    deduct=False: لا خصم أصلاً — رصيد الصيدلية صحيح والبضاعة في المستودع فقط.

    يعيد (الوضع، رسالة_الخطأ).
    """
    inv_q = db.returned_supply.id == ret_id
    if lock:
        inv = db(inv_q).select(for_update=True, limitby=(0, 1)).first()
    else:
        inv = db(inv_q).select(limitby=(0, 1)).first()
    if not inv:
        return None, "فاتورة المرتجع غير موجودة — ربما رُحّلت أو حُذفت"
    if inv.admin_accept:
        return None, "الفاتورة معتمدة: خُصمت وسُجّلت على المورد، فلا تُرحَّل"

    det_q = db.returned_supply_det.returned_supply == ret_id
    order = db.returned_supply_det.id
    if lock:
        src_rows = db(det_q).select(orderby=order, for_update=True)
    else:
        src_rows = db(det_q).select(orderby=order)
    if not src_rows:
        return None, "الفاتورة بلا أصناف"

    all_ids = {int(r.id) for r in src_rows}
    if line_ids is None:
        selected = set(all_ids)
    else:
        selected = set(line_ids)
        if not selected and not allow_empty:
            return None, "لم يُحدَّد أي سطر للترحيل"
        if not selected <= all_ids:
            return None, "بعض الأسطر لم تعد في الفاتورة — حدّث المعاينة"

    det_ids = sorted({d for d in (_det_id(r.item_id) for r in src_rows) if d})
    if lock:
        batch_rows = stock_lock_dets(det_ids)
    else:
        batch_rows = db(db.items_det.id.belongs(det_ids)).select() if det_ids else []
    batches = {int(b.id): b for b in batch_rows}

    item_ids = sorted({int(b.item_idr) for b in batches.values() if b.item_idr})
    items = {}
    if item_ids:
        for m in db(db.items_main.id.belongs(item_ids)).select(
            db.items_main.id, db.items_main.item_id, db.items_main.name,
            db.items_main.track_stock,
        ):
            items[int(m.id)] = m

    # نفس الدفعة في فواتير مرتجع معلقة أخرى، أو ما زالت في المستودع: غالباً تكرار
    other_pending, in_store = {}, {}
    if det_ids:
        for r in db.executesql(
            "SELECT d.item_id AS det,"
            "       ARRAY_AGG(DISTINCT d.returned_supply ORDER BY d.returned_supply) AS invs"
            "  FROM returned_supply_det d"
            "  JOIN returned_supply r ON r.id = d.returned_supply"
            " WHERE d.returned_supply <> %s"
            "   AND COALESCE(r.admin_accept, 'F') <> 'T'"
            "   AND d.item_id = ANY(%s)"
            " GROUP BY d.item_id",
            placeholders=[ret_id, [str(d) for d in det_ids]], as_dict=True,
        ):
            other_pending[int(r["det"])] = list(r["invs"] or [])
        for r in db.executesql(
            "SELECT item_det, SUM(qty - qty_out) AS rem FROM damaged_store_line"
            " WHERE item_det = ANY(%s) AND qty - qty_out > %s GROUP BY item_det",
            placeholders=[det_ids, _EPS], as_dict=True,
        ):
            in_store[int(r["item_det"])] = round(_f(r["rem"]), 6)

    today = request.now.date()
    left = {d: max(_f(b.items_count), 0.0) for d, b in batches.items()}
    lines = []
    for r in src_rows:
        det = _det_id(r.item_id)
        b = batches.get(det)
        m = items.get(int(b.item_idr)) if (b and b.item_idr) else None
        qty = _f(r.item_count)
        tracked = True if (m is None or m.track_stock is None) else bool(m.track_stock)
        sel = int(r.id) in selected
        take = 0.0
        if deduct and sel and b is not None and tracked:
            take = round(min(qty, left[det]), 6)
            left[det] = round(left[det] - take, 6)
        price = _f(r.inv_price) or (_f(b.buy_price) if b else 0.0)
        exp = b.expiration_date if b else None
        lines.append({
            "id": int(r.id),
            "det_id": det,
            "item_main": int(b.item_idr) if (b and b.item_idr) else None,
            "barcode": (m.item_id if m else "") or (b.item_id if b else "") or "",
            "name": (m.name if m else "") or r.item_name or "",
            "expiration_date": str(exp) if exp else "",
            "expired": bool(exp and exp < today),
            "qty": round(qty, 6),
            "balance": round(_f(b.items_count), 6) if b else None,
            "deduct": take,
            "buy_price": round(price, 4),
            "vat": _f(r.vat),
            "value": round(qty * price, 2),
            "selected": sel,
            "missing_batch": b is None,
            "untracked": b is not None and not tracked,
            "short": bool(deduct and sel and b is not None and tracked and take < qty - _EPS),
            "other_pending": other_pending.get(det, []) if det else [],
            "in_store": in_store.get(det, 0.0) if det else 0.0,
        })

    chosen = [x for x in lines if x["selected"]]
    totals = {
        "all_lines": len(lines),
        "lines": len(chosen),
        "qty": round(sum(x["qty"] for x in chosen), 2),
        "deduct": round(sum(x["deduct"] for x in chosen), 2),
        "value": round(sum(x["value"] for x in chosen), 2),
        "value_vat": round(sum(x["value"] * (1 + x["vat"]) for x in chosen), 2),
        "short": sum(1 for x in chosen if x["short"]),
        "expired": sum(1 for x in chosen if x["expired"]),
        "duplicates": sum(1 for x in chosen if x["other_pending"] or x["in_store"] > 0),
    }
    sup = db.suppliers(inv.supplier) if inv.supplier else None
    invoice = {
        "id": int(inv.id),
        "name": inv.name or "",
        "ret_date": str(inv.ret_date) if inv.ret_date else "",
        "supplier": int(inv.supplier) if inv.supplier else None,
        "supplier_name": sup.name if sup else "",
    }
    return {"invoice": invoice, "lines": lines, "totals": totals, "deduct": bool(deduct),
            "_inv": inv}, None


def _deduct_choice(raw):
    """«1» خصم، «0» بدون خصم، وغير ذلك None (لم يُختر)."""
    return {"1": True, "0": False}.get(str(raw if raw is not None else "").strip())


@can_access(2017)
def transfer_preview():
    """معاينة الترحيل — لا تكتب شيئاً. بلا line_ids تُختار كل الأسطر.
    بلا deduct تُحسب كميات الخصم المحتملة، لتساعد المدير على الاختيار."""
    try:
        ret_id = int(request.args(0) or request.vars.ret_id)
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="رقم الفاتورة غير صحيح"))
    raw = request.vars.line_ids
    line_ids = None if raw is None else _ids(raw)
    deduct = _deduct_choice(request.vars.deduct)
    state, err = _transfer_state(ret_id, line_ids, allow_empty=True,
                                 deduct=True if deduct is None else deduct)
    if err:
        return response.json(api.api_error(mess=err))
    state.pop("_inv", None)
    return response.json(api.api_ok(data=state))


@can_access(2017)
def transfer():
    """تنفيذ الترحيل. يعيد حساب الوضع تحت القفل ولا يثق بمعاينة المتصفح:
    إن اختلف الخصم المحسوب عمّا رآه المدير يُرفض ويُطلب تحديث المعاينة."""
    if not _is_post():
        return response.json(api.api_error(mess="طلب غير صالح"))
    try:
        ret_id = int(request.vars.ret_id)
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="رقم الفاتورة غير صحيح"))
    line_ids = _ids(request.vars.line_ids)
    # لا قيمة افتراضية: الخطأ في أي اتجاه يُفسد الرصيد (خصم ما جُرد سابقاً، أو إبقاء ما خرج من الرف)
    deduct = _deduct_choice(request.vars.deduct)
    if deduct is None:
        return response.json(api.api_error(mess="اختر أولاً: هل يُخصم من رصيد الصيدلية؟"))
    try:
        expected = {
            int(k): float(v)
            for k, v in json.loads(request.vars.expected or "{}").items()
        }
    except (TypeError, ValueError, AttributeError):
        return response.json(api.api_error(mess="بيانات المعاينة غير صالحة — حدّث المعاينة"))
    note = (request.vars.note or "").strip()[:2000]

    try:
        state, err = _transfer_state(ret_id, line_ids, lock=True, deduct=deduct)
        if err:
            db.rollback()
            return response.json(api.api_error(mess=err))
        chosen = [x for x in state["lines"] if x["selected"]]
        drift = set(expected) != {x["id"] for x in chosen} or any(
            abs(expected[x["id"]] - x["deduct"]) > _EPS for x in chosen
        )
        if drift:
            db.rollback()
            return response.json(api.api_error(
                mess="تغيّرت الأرصدة أو الأسطر منذ المعاينة — حدّث المعاينة ثم أعد المحاولة."
            ))

        inv, info = state["_inv"], state["invoice"]
        store_id = db.damaged_store.insert(
            src_id=inv.id,
            src_name=inv.name,
            src_date=inv.ret_date,
            src_created_by=inv.created_by,
            src_created_on=inv.created_on,
            supplier=inv.supplier,
            supplier_name=info["supplier_name"],
            deduct_stock=deduct,
            note=note,
        )
        ref = "مستودع التالف - مرتجع توريد %s" % inv.id
        for x in chosen:
            db.damaged_store_line.insert(
                damaged_store=store_id,
                src_line_id=x["id"],
                item_main=x["item_main"],
                item_det=x["det_id"],
                barcode=x["barcode"][:50],
                item_name=x["name"][:460],
                expiration_date=x["expiration_date"] or None,
                qty=x["qty"],
                stock_deducted=x["deduct"],
                qty_out=0,
                buy_price=x["buy_price"],
                vat=x["vat"],
            )
            if x["deduct"] > STOCK_EPS:
                # الدفعة مقفولة في _transfer_state، وإعادة قفلها داخل نفس المعاملة بلا أثر
                stock_move(x["det_id"], -x["deduct"], "تالف", ref, str(store_id),
                           x["buy_price"])

        db(db.returned_supply_det.id.belongs([x["id"] for x in chosen])).delete()
        remaining = db(db.returned_supply_det.returned_supply == inv.id).count()
        if remaining:
            _refresh_return_totals(inv.id)
        else:
            db(db.returned_supply.id == inv.id).delete()
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))

    t = state["totals"]
    mess = "رُحّل %d صنف إلى مستودع التالف" % t["lines"]
    mess += (" وخُصم من رصيد الصيدلية %s" % t["deduct"]) if deduct else " دون خصم من رصيد الصيدلية"
    mess += (" — بقي %d سطر في المرتجع" % remaining) if remaining else " وأُغلقت فاتورة المرتجع"
    return response.json(api.api_ok(
        data={
            "store_id": store_id,
            "deduct_stock": deduct,
            "lines": t["lines"],
            "qty": t["qty"],
            "deduct": t["deduct"],
            "value": t["value"],
            "short": t["short"],
            "remaining_lines": remaining,
            "invoice_removed": not remaining,
        },
        mess=mess,
    ))


# ==============================================================================
#  المستودع: الاستعراض
# ==============================================================================
def _store_filters(state=None, short=None, by_supplier=True):
    """شروط القائمة — مشتركة بين العرض والتصدير والملخص."""
    v = request.vars
    conds, params = ["TRUE"], []
    for word in (v.q or "").split():
        term = "%" + word + "%"
        conds.append(
            "(UPPER(l.item_name) LIKE UPPER(%s) OR l.barcode LIKE %s"
            " OR im.item_id LIKE %s OR CAST(s.src_id AS text) = %s)"
        )
        params += [term, term, term, word]
    sup = str(v.supplier or "").strip()
    if by_supplier and sup.isdigit():
        conds.append("s.supplier = %s")
        params.append(int(sup))
    state = state or v.state or "in"
    if state == "in":
        conds.append("l.qty - l.qty_out > %s")
        params.append(_EPS)
    elif state == "out":
        conds.append("l.qty - l.qty_out <= %s")
        params.append(_EPS)
    if short is None:
        short = v.short in ("1", "true", "T")
    if short:
        # «خصم أقل» يعني شيئاً في الترحيل بالخصم فقط؛ بدون خصم الصفر مقصود
        conds.append("s.deduct_stock = 'T' AND l.stock_deducted < l.qty - %s")
        params.append(_EPS)
    return " AND ".join(conds), params


def _store_rows(where, params, sort="date", limit=None, offset=0):
    sql = (
        "SELECT l.id, l.damaged_store, s.src_id, s.src_name, s.supplier, s.supplier_name,"
        "       s.created_on AS moved_on, s.deduct_stock,"
        "       l.item_main, l.item_det, l.barcode, l.item_name,"
        "       l.expiration_date, l.qty, l.qty_out, l.stock_deducted, l.buy_price, l.vat"
        + _FROM + " WHERE " + where + " ORDER BY " + _SORTS.get(sort, _SORTS["date"])
    )
    ph = list(params)
    if limit:
        sql += " LIMIT %s OFFSET %s"
        ph += [limit, offset]
    rows = db.executesql(sql, placeholders=ph, as_dict=True)
    today = request.now.date()
    for r in rows:
        qty, out, price = _f(r["qty"]), _f(r["qty_out"]), _f(r["buy_price"])
        rem = max(round(qty - out, 6), 0.0)
        exp = r["expiration_date"]
        r["remaining"] = rem
        r["value"] = round(rem * price, 2)
        r["value_vat"] = round(rem * price * (1 + _f(r["vat"])), 2)
        r["deduct_stock"] = r["deduct_stock"] in ("T", True)
        r["short"] = r["deduct_stock"] and _f(r["stock_deducted"]) < qty - _EPS
        r["expired"] = bool(exp and exp < today)
        r["expiration_date"] = str(exp) if exp else ""
        r["moved_on"] = str(r["moved_on"])[:16] if r["moved_on"] else ""
        for k in ("qty", "qty_out", "stock_deducted", "buy_price", "vat"):
            r[k] = round(_f(r[k]), 4)
    return rows


@can_access(2017, 2018)
def index():
    sc = screens_rules(2017)
    return dict(can_manage=bool(sc and sc.can_log_in))


@can_access(2017, 2018)
def lines():
    where, params = _store_filters()
    try:
        page = max(int(request.vars.page or 0), 0)
        per = min(max(int(request.vars.per or 50), 1), 200)
    except (TypeError, ValueError):
        page, per = 0, 50
    total = db.executesql("SELECT COUNT(*)" + _FROM + " WHERE " + where,
                          placeholders=params)[0][0]
    rows = _store_rows(where, params, request.vars.sort, per, page * per)
    return response.json(api.api_list(rows=rows, count=int(total)))


@can_access(2017, 2018)
def summary():
    """ما في المستودع الآن لكل مورد، وما خرج منه حسب السبب.

    يتبع البحث فقط: جدول الموردين يبقى كاملاً ليُختار منه، والصفحة تحسب
    المؤشرات للمورد المختار من هذه الصفوف نفسها.
    """
    where, params = _store_filters(state="in", short=False, by_supplier=False)
    rows = db.executesql(
        "SELECT s.supplier, MAX(s.supplier_name) AS supplier_name,"
        "       COUNT(*) AS lines,"
        "       ROUND(SUM(l.qty - l.qty_out)::numeric, 2) AS qty,"
        "       ROUND(SUM((l.qty - l.qty_out) * l.buy_price)::numeric, 2) AS value,"
        "       ROUND(SUM((l.qty - l.qty_out) * l.buy_price"
        "                 * (1 + COALESCE(l.vat, 0)))::numeric, 2) AS value_vat,"
        "       COUNT(*) FILTER (WHERE s.deduct_stock = 'T'"
        "                          AND l.stock_deducted < l.qty - %s) AS short"
        + _FROM + " WHERE " + where +
        " GROUP BY s.supplier ORDER BY value DESC NULLS LAST",
        placeholders=[_EPS] + params, as_dict=True,
    )
    for r in rows:
        for k in ("qty", "value", "value_vat"):
            r[k] = _f(r[k])
    totals = {
        "lines": sum(int(r["lines"]) for r in rows),
        "qty": round(sum(r["qty"] for r in rows), 2),
        "value": round(sum(r["value"] for r in rows), 2),
        "value_vat": round(sum(r["value_vat"] for r in rows), 2),
        "short": sum(int(r["short"]) for r in rows),
        "suppliers": len(rows),
    }
    where_all, params_all = _store_filters(state="all", short=False, by_supplier=False)
    exits = db.executesql(
        "SELECT s.supplier, e.reason, COUNT(*) AS n, ROUND(SUM(e.qty)::numeric, 2) AS qty,"
        "       ROUND(SUM(e.qty * l.buy_price)::numeric, 2) AS value"
        "  FROM damaged_store_exit e"
        "  JOIN damaged_store_line l ON l.id = e.line"
        "  JOIN damaged_store s ON s.id = l.damaged_store"
        "  LEFT JOIN items_main im ON im.id = l.item_main"
        " WHERE " + where_all + " GROUP BY s.supplier, e.reason",
        placeholders=params_all, as_dict=True,
    )
    for r in exits:
        r["label"] = DAMAGED_EXIT_REASONS.get(r["reason"], r["reason"])
        r["qty"], r["value"] = _f(r["qty"]), _f(r["value"])
    return response.json(api.api_ok(data={"rows": rows, "totals": totals, "exits": exits}))


@can_access(2017, 2018)
def suppliers():
    rows = db.executesql(
        "SELECT supplier AS id, MAX(supplier_name) AS name FROM damaged_store"
        " GROUP BY supplier ORDER BY 2",
        as_dict=True,
    )
    return response.json(api.api_list(rows=rows, count=len(rows)))


@can_access(2017, 2018)
def line_detail():
    try:
        line_id = int(request.args(0))
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="رقم السطر غير صحيح"))
    where, params = "l.id = %s", [line_id]
    rows = _store_rows(where, params)
    if not rows:
        return response.json(api.api_error(mess="السطر غير موجود"))
    line = rows[0]
    head = db.executesql(
        "SELECT s.src_date, s.note,"
        "       COALESCE(mu.first_name || ' ' || mu.last_name, '') AS moved_by,"
        "       COALESCE(cu.first_name || ' ' || cu.last_name, '') AS src_by,"
        "       s.src_created_on"
        "  FROM damaged_store s"
        "  LEFT JOIN auth_user mu ON mu.id = s.created_by"
        "  LEFT JOIN auth_user cu ON cu.id = s.src_created_by"
        " WHERE s.id = %s",
        placeholders=[line["damaged_store"]], as_dict=True,
    )[0]
    line["src_date"] = str(head["src_date"]) if head["src_date"] else ""
    line["store_note"] = head["note"] or ""
    line["moved_by"] = head["moved_by"]
    line["src_by"] = head["src_by"]
    line["src_created_on"] = str(head["src_created_on"])[:16] if head["src_created_on"] else ""
    exits = db.executesql(
        "SELECT e.id, e.qty, e.reason, e.note, e.created_on,"
        "       COALESCE(u.first_name || ' ' || u.last_name, '') AS by_name"
        "  FROM damaged_store_exit e LEFT JOIN auth_user u ON u.id = e.created_by"
        " WHERE e.line = %s ORDER BY e.id",
        placeholders=[line_id], as_dict=True,
    )
    for e in exits:
        e["qty"] = _f(e["qty"])
        e["label"] = DAMAGED_EXIT_REASONS.get(e["reason"], e["reason"])
        e["created_on"] = str(e["created_on"])[:16] if e["created_on"] else ""
    line["exits"] = exits
    return response.json(api.api_ok(data=line))


# ==============================================================================
#  المستودع: الإخراج
# ==============================================================================
@can_access(2017)
def exit_line():
    """إخراج كمية من سطر (تعويض/إتلاف/تصحيح). لا يمس المخزون."""
    if not _is_post():
        return response.json(api.api_error(mess="طلب غير صالح"))
    v = request.vars
    try:
        line_id = int(v.line_id)
        qty = round(float(v.qty), 6)
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="بيانات غير صحيحة"))
    reason = v.reason
    note = (v.note or "").strip()[:2000]
    if reason not in DAMAGED_EXIT_REASONS:
        return response.json(api.api_error(mess="اختر سبب الإخراج"))
    if qty <= 0:
        return response.json(api.api_error(mess="الكمية يجب أن تكون أكبر من صفر"))
    if reason == "correction" and not note:
        return response.json(api.api_error(mess="التصحيح يحتاج ملاحظة توضّح سببه"))
    try:
        line = db(db.damaged_store_line.id == line_id).select(
            for_update=True, limitby=(0, 1)
        ).first()
        if not line:
            db.rollback()
            return response.json(api.api_error(mess="السطر غير موجود"))
        rem = round(_f(line.qty) - _f(line.qty_out), 6)
        if qty > rem + _EPS:
            db.rollback()
            return response.json(api.api_error(
                mess="الكمية أكبر من المتبقي في المستودع (%s)" % round(rem, 2)
            ))
        db.damaged_store_exit.insert(line=line.id, qty=qty, reason=reason, note=note)
        line.update_record(qty_out=round(_f(line.qty_out) + qty, 6))
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(
        data={"remaining": round(rem - qty, 6)}, mess="تم تسجيل الإخراج"
    ))


# ==============================================================================
#  المستودع: التصدير
# ==============================================================================
@can_access(2017, 2018)
def excel():
    """قائمة المستودع حسب الفلاتر الحالية، مع عمودَي ملاحظات للتفاوض يدوياً."""
    import xlsxwriter

    where, params = _store_filters()
    rows = _store_rows(where, params, request.vars.sort or "supplier")

    sup_name = ""
    sup = str(request.vars.supplier or "").strip()
    if sup.isdigit() and rows:
        sup_name = rows[0]["supplier_name"] or ""
    state_label = {"in": "الموجود في المستودع", "out": "ما خرج بالكامل",
                   "all": "كل الأسطر"}.get(request.vars.state or "in", "")

    buf = io.BytesIO()
    wb = xlsxwriter.Workbook(buf, {"in_memory": True})
    ws = wb.add_worksheet("مستودع التالف")
    ws.right_to_left()

    title = wb.add_format({"bold": True, "font_size": 13, "align": "center"})
    sub = wb.add_format({"align": "center", "font_color": "#555555"})
    head = wb.add_format({"bold": True, "bg_color": "#D9E1F2", "align": "center",
                          "border": 1, "text_wrap": True, "valign": "vcenter"})
    note_head = wb.add_format({"bold": True, "bg_color": "#FFF2CC", "align": "center",
                               "border": 1, "valign": "vcenter"})
    cell = wb.add_format({"border": 1})
    cell_c = wb.add_format({"border": 1, "align": "center"})
    num = wb.add_format({"border": 1, "align": "center", "num_format": "#,##0.00"})
    note_cell = wb.add_format({"border": 1, "bg_color": "#FFFDF5"})
    tot = wb.add_format({"bold": True, "bg_color": "#EDEDED", "border": 1,
                         "align": "center", "num_format": "#,##0.00"})
    tot_lbl = wb.add_format({"bold": True, "bg_color": "#EDEDED", "border": 1,
                             "align": "center"})

    # «في المستودع» يُصدَّر بالمتبقي، وما عداه بالكمية المرحّلة أصلاً
    remaining_mode = (request.vars.state or "in") == "in"
    headers = ["م", "الباركود", "اسم الصنف", "رقم الدفعة", "تاريخ الصلاحية",
               "الكمية المتبقية" if remaining_mode else "الكمية المرحّلة",
               "سعر الشراء", "القيمة", "المورد", "رقم المرتجع",
               "تاريخ الترحيل", "ملاحظة ١", "ملاحظة ٢"]
    last_col = len(headers) - 1
    ws.merge_range(0, 0, 0, last_col,
                   "مستودع التالف" + ((" — " + sup_name) if sup_name else ""), title)
    ws.merge_range(1, 0, 1, last_col,
                   "%s   |   تاريخ التصدير: %s   |   عدد الأسطر: %d" % (
                       state_label, request.now.strftime("%Y-%m-%d"), len(rows)), sub)
    hr = 3
    for i, h in enumerate(headers):
        ws.write(hr, i, h, note_head if h.startswith("ملاحظة") else head)
    ws.set_row(hr, 28)

    qty_sum = value_sum = 0.0
    for i, r in enumerate(rows):
        rw = hr + 1 + i
        qty = r["remaining"] if remaining_mode else r["qty"]
        value = round(qty * r["buy_price"], 2)
        qty_sum += qty
        value_sum += value
        ws.write(rw, 0, i + 1, cell_c)
        ws.write(rw, 1, r["barcode"] or "", cell_c)
        ws.write(rw, 2, r["item_name"] or "", cell)
        ws.write(rw, 3, r["item_det"] or "", cell_c)
        ws.write(rw, 4, r["expiration_date"], cell_c)
        ws.write(rw, 5, qty, num)
        ws.write(rw, 6, r["buy_price"], num)
        ws.write(rw, 7, value, num)
        ws.write(rw, 8, r["supplier_name"] or "", cell)
        ws.write(rw, 9, r["src_id"] or "", cell_c)
        ws.write(rw, 10, r["moved_on"][:10], cell_c)
        ws.write_blank(rw, 11, None, note_cell)
        ws.write_blank(rw, 12, None, note_cell)

    tr = hr + 1 + len(rows)
    ws.merge_range(tr, 0, tr, 4, "الإجمالي", tot_lbl)
    ws.write(tr, 5, round(qty_sum, 2), tot)
    ws.write_blank(tr, 6, None, tot)
    ws.write(tr, 7, round(value_sum, 2), tot)
    for c in range(8, 11):
        ws.write_blank(tr, c, None, tot)
    ws.write_blank(tr, 11, None, note_cell)
    ws.write_blank(tr, 12, None, note_cell)

    for c, w in enumerate([5, 15, 40, 11, 14, 10, 12, 12, 28, 11, 13, 24, 24]):
        ws.set_column(c, c, w)
    ws.freeze_panes(hr + 1, 0)
    ws.autofilter(hr, 0, max(tr - 1, hr), last_col)
    ws.set_landscape()
    ws.fit_to_pages(1, 0)
    ws.repeat_rows(hr)
    wb.close()
    buf.seek(0)

    response.headers["Content-Type"] = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response.headers["Content-Disposition"] = (
        "attachment; filename=damaged_store_%s.xlsx" % request.now.strftime("%Y%m%d_%H%M%S")
    )
    return buf.read()
