# -*- coding: utf-8 -*-
#  type: ignore
"""
مراقبة حركات الصندوق — مصروفات وإيداعات
Screen code: 5001 (عرض/تسجيل)، 5002 (اعتماد/رفض)
"""
from datetime import datetime, date, timedelta
import api_helpers as api


# ===========================================================================================
# صفحة الواجهة
# ===========================================================================================
@can_access(5001)
def index():
    sc = screens_rules(5001)
    can_add = bool(sc and sc.can_add)
    can_edit = bool(sc and sc.can_edit)
    can_delete = bool(sc and sc.can_delete)
    can_approve = bool(auth.has_membership("admin"))
    return dict(
        can_add=can_add, can_edit=can_edit,
        can_delete=can_delete, can_approve=can_approve,
    )


# ===========================================================================================
# قوائم مرجعية
# ===========================================================================================
@can_access(5001)
def lookups():
    cats = db(db.key_fund_category.is_active == True).select(
        db.key_fund_category.id,
        db.key_fund_category.code,
        db.key_fund_category.name_ar,
        db.key_fund_category.kind,
        orderby=db.key_fund_category.name_ar,
    )
    pays = db(db.key_payment_method.id > 0).select(
        db.key_payment_method.id, db.key_payment_method.name,
        orderby=db.key_payment_method.id,
    )
    users = db(db.auth_user.id > 0).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name,
        orderby=db.auth_user.first_name,
    )
    data = {
        "categories": [
            {"id": r.id, "code": r.code, "name_ar": r.name_ar, "kind": r.kind}
            for r in cats
        ],
        "payment_methods": [{"id": r.id, "name": r.name} for r in pays],
        "users": [
            {"id": u.id, "name": (u.first_name or "") + " " + (u.last_name or "")}
            for u in users
        ],
    }
    return response.json(api.api_ok(data=data))


# ===========================================================================================
# إحصاءات لوحة القيادة
# ===========================================================================================
@can_access(5001)
def get_dashboard():
    try:
        today = request.now.date()
        since_30 = today - timedelta(days=30)

        # الرصيد الحالي + مجاميع المُقدَّم للاعتماد + المسودات
        bal_sql = (
            "SELECT "
            " COALESCE(SUM(CASE WHEN kind='deposit'  AND status='approved'  THEN amount ELSE 0 END),0) AS dep_tot, "
            " COALESCE(SUM(CASE WHEN kind='expense'  AND status='approved'  THEN amount ELSE 0 END),0) AS exp_tot, "
            " COALESCE(SUM(CASE WHEN kind='deposit'  AND status='submitted' THEN amount ELSE 0 END),0) AS dep_submitted, "
            " COALESCE(SUM(CASE WHEN kind='expense'  AND status='submitted' THEN amount ELSE 0 END),0) AS exp_submitted, "
            " COALESCE(SUM(CASE WHEN kind='deposit'  AND status IN ('draft','returned') THEN amount ELSE 0 END),0) AS dep_draft, "
            " COALESCE(SUM(CASE WHEN kind='expense'  AND status IN ('draft','returned') THEN amount ELSE 0 END),0) AS exp_draft "
            "FROM fund_entry"
        )
        r = db.executesql(bal_sql, as_dict=True)[0]
        current_balance = float(r["dep_tot"]) - float(r["exp_tot"])

        # اليوم
        today_sql = (
            "SELECT "
            " COALESCE(SUM(CASE WHEN kind='deposit' AND status='approved' THEN amount ELSE 0 END),0) AS dep_today, "
            " COALESCE(SUM(CASE WHEN kind='expense' AND status='approved' THEN amount ELSE 0 END),0) AS exp_today "
            "FROM fund_entry WHERE entry_date = %s"
        )
        rt = db.executesql(today_sql, placeholders=[today], as_dict=True)[0]

        # أعلى 5 تصنيفات مصروفات خلال 30 يومًا
        top_sql = (
            "SELECT c.id AS category_id, c.name_ar AS name, "
            "       COALESCE(SUM(fe.amount),0) AS total "
            "FROM fund_entry fe "
            "JOIN key_fund_category c ON c.id = fe.category_id "
            "WHERE fe.kind='expense' AND fe.status='approved' "
            "  AND fe.entry_date >= %s "
            "GROUP BY c.id, c.name_ar "
            "ORDER BY total DESC LIMIT 5"
        )
        top_cats = db.executesql(top_sql, placeholders=[since_30], as_dict=True)

        # اتجاه آخر 30 يومًا
        trend_sql = (
            "SELECT entry_date, "
            " COALESCE(SUM(CASE WHEN kind='deposit' AND status='approved' THEN amount ELSE 0 END),0) AS dep, "
            " COALESCE(SUM(CASE WHEN kind='expense' AND status='approved' THEN amount ELSE 0 END),0) AS exp "
            "FROM fund_entry WHERE entry_date >= %s "
            "GROUP BY entry_date ORDER BY entry_date"
        )
        trend = db.executesql(trend_sql, placeholders=[since_30], as_dict=True)

        # معلقات الاعتماد
        pending = db(db.fund_entry.status == "submitted").count()
        # سندات أُرجعت لأمين الصندوق وما زالت تنتظر تصحيحه
        returned = db(db.fund_entry.status == "returned").count()

        data = {
            "current_balance": round(current_balance, 2),
            "today_deposits": round(float(rt["dep_today"]), 2),
            "today_expenses": round(float(rt["exp_today"]), 2),
            "pending_approval": pending,
            "returned_pending": returned,
            "submitted_deposits": round(float(r["dep_submitted"]), 2),
            "submitted_expenses": round(float(r["exp_submitted"]), 2),
            "draft_deposits": round(float(r["dep_draft"]), 2),
            "draft_expenses": round(float(r["exp_draft"]), 2),
            "top_categories": [
                {"name": r["name"], "total": float(r["total"])} for r in top_cats
            ],
            "trend_30d": [
                {"date": str(r["entry_date"]),
                 "deposits": float(r["dep"]),
                 "expenses": float(r["exp"])}
                for r in trend
            ],
        }
        return response.json(api.api_ok(data=data))
    except Exception as e:
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# قائمة الحركات مع فلاتر ورصيد متراكم
# ===========================================================================================
@can_access(5001)
def get_entries():
    try:
        ReqVar = request.vars
        pg = int(ReqVar.page or 0)
        rc = int(ReqVar.RecordCount or 20)

        conditions = []
        params = []

        if ReqVar.date_from:
            conditions.append("fe.entry_date >= %s")
            params.append(ReqVar.date_from)
        if ReqVar.date_to:
            conditions.append("fe.entry_date <= %s")
            params.append(ReqVar.date_to)
        if ReqVar.kind in ("expense", "deposit"):
            conditions.append("fe.kind = %s")
            params.append(ReqVar.kind)
        if ReqVar.category_id and ReqVar.category_id != "0":
            conditions.append("fe.category_id = %s")
            params.append(int(ReqVar.category_id))
        if ReqVar.payment_method and ReqVar.payment_method != "0":
            conditions.append("fe.payment_method = %s")
            params.append(int(ReqVar.payment_method))
        if ReqVar.status and ReqVar.status != "all":
            conditions.append("fe.status = %s")
            params.append(ReqVar.status)
        if ReqVar.created_by and ReqVar.created_by != "0":
            conditions.append("fe.submitted_by = %s")
            params.append(int(ReqVar.created_by))
        if ReqVar.min_amount:
            try:
                conditions.append("fe.amount >= %s")
                params.append(float(ReqVar.min_amount))
            except ValueError:
                pass
        if ReqVar.max_amount:
            try:
                conditions.append("fe.amount <= %s")
                params.append(float(ReqVar.max_amount))
            except ValueError:
                pass
        if ReqVar.SearchText and ReqVar.SearchText.strip():
            for word in ReqVar.SearchText.strip().split():
                p = "%" + word + "%"
                conditions.append(
                    "(fe.beneficiary LIKE %s OR fe.description LIKE %s "
                    "OR fe.document_no LIKE %s OR CAST(fe.amount AS text) LIKE %s)"
                )
                params.extend([p, p, p, p])

        allowed_sort = {
            "id", "entry_date", "kind", "amount", "status",
            "category_id", "payment_method",
        }
        sort_col = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else "entry_date"
        sa = "ASC" if (ReqVar.sequence or "false") == "true" else "DESC"
        offset = pg * rc

        where_sql = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        # الرصيد المتراكم يُحسَب على نفس الفلتر بترتيب (entry_date, id)
        sql = (
            "SELECT fe.id, fe.entry_date, fe.kind, fe.category_id, fe.payment_method, "
            "       fe.amount, fe.beneficiary, fe.ref_type, fe.ref_id, fe.document_no, "
            "       fe.attachment, fe.description, fe.status, fe.submitted_by, fe.submitted_at, "
            "       fe.approved_by, fe.approved_at, fe.rejected_reason, "
            "       fe.returned_at, fe.returned_reason, fe.returned_count, "
            "       c.name_ar AS category_name, c.code AS category_code, c.kind AS category_kind, "
            "       pm.name AS payment_method_name, "
            "       (COALESCE(ua.first_name,'') || ' ' || COALESCE(ua.last_name,'')) AS approver_name, "
            "       (COALESCE(us.first_name,'') || ' ' || COALESCE(us.last_name,'')) AS submitter_name, "
            "       ROUND( "
            "         SUM(CASE WHEN fe.status='approved' AND fe.kind='deposit' THEN fe.amount "
            "                  WHEN fe.status='approved' AND fe.kind='expense' THEN -fe.amount "
            "                  ELSE 0 END) "
            "         OVER (ORDER BY fe.entry_date ASC, fe.id ASC "
            "               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) "
            "       ::numeric, 2) AS running_balance "
            "FROM fund_entry fe "
            "LEFT JOIN key_fund_category c ON c.id = fe.category_id "
            "LEFT JOIN key_payment_method pm ON pm.id = fe.payment_method "
            "LEFT JOIN auth_user ua ON ua.id = fe.approved_by "
            "LEFT JOIN auth_user us ON us.id = fe.submitted_by "
            f"{where_sql} "
            f"ORDER BY fe.{sort_col} {sa}, fe.id {sa} "
            "LIMIT %s OFFSET %s"
        )
        params_count = list(params)
        params.extend([rc, offset])

        sql2 = f"SELECT count(*) FROM fund_entry fe {where_sql}"
        sql3 = (
            "SELECT "
            " COALESCE(SUM(CASE WHEN fe.kind='deposit' THEN fe.amount ELSE 0 END),0) AS tot_dep, "
            " COALESCE(SUM(CASE WHEN fe.kind='expense' THEN fe.amount ELSE 0 END),0) AS tot_exp "
            f"FROM fund_entry fe {where_sql}"
        )

        rows = db.executesql(sql, placeholders=params, as_dict=True)
        count = db.executesql(
            sql2, placeholders=params_count if params_count else None, as_dict=True
        )[0]["count"]
        totals = db.executesql(
            sql3, placeholders=params_count if params_count else None, as_dict=True
        )[0]

        return response.json(api.api_list(
            rows=rows, count=count,
            totals={"deposits": float(totals["tot_dep"]),
                    "expenses": float(totals["tot_exp"])},
        ))
    except Exception as e:
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# سجل واحد (مع كل التفاصيل للعرض)
# ===========================================================================================
@can_access(5001)
def get_entry():
    try:
        eid = request.args(0)
        if not eid:
            return response.json(api.api_error(mess="معرّف السجل مفقود"))
        sql = (
            "SELECT fe.*, c.name_ar AS category_name, c.code AS category_code, "
            "       pm.name AS payment_method_name, "
            "       (COALESCE(ua.first_name,'') || ' ' || COALESCE(ua.last_name,'')) AS approver_name, "
            "       (COALESCE(us.first_name,'') || ' ' || COALESCE(us.last_name,'')) AS submitter_name, "
            "       (COALESCE(ur.first_name,'') || ' ' || COALESCE(ur.last_name,'')) AS returner_name "
            "FROM fund_entry fe "
            "LEFT JOIN key_fund_category c ON c.id = fe.category_id "
            "LEFT JOIN key_payment_method pm ON pm.id = fe.payment_method "
            "LEFT JOIN auth_user ua ON ua.id = fe.approved_by "
            "LEFT JOIN auth_user us ON us.id = fe.submitted_by "
            "LEFT JOIN auth_user ur ON ur.id = fe.returned_by "
            "WHERE fe.id = %s"
        )
        rows = db.executesql(sql, placeholders=[int(eid)], as_dict=True)
        if not rows:
            return response.json(api.api_error(mess="السجل غير موجود"))
        return response.json(api.api_ok(data=rows[0]))
    except Exception as e:
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# مساعدات داخلية
# ===========================================================================================
def _validate_entry(data):
    """يعيد قائمة أخطاء أو [] عند نجاح التحقق."""
    errs = []
    if not data.entry_date:
        errs.append("التاريخ مطلوب")
    else:
        try:
            d = datetime.strptime(str(data.entry_date), "%Y-%m-%d").date()
            if d > request.now.date():
                errs.append("لا يمكن تسجيل تاريخ مستقبلي")
        except Exception:
            errs.append("تنسيق التاريخ غير صحيح")
    if data.kind not in ("expense", "deposit"):
        errs.append("نوع الحركة غير صحيح")
    try:
        amt = float(data.amount or 0)
        if amt <= 0:
            errs.append("المبلغ يجب أن يكون أكبر من صفر")
    except Exception:
        errs.append("المبلغ غير صحيح")
    if not data.category_id:
        errs.append("التصنيف مطلوب")
    if not data.payment_method:
        errs.append("طريقة الدفع مطلوبة")
    return errs


# ===========================================================================================
# إنشاء حركة جديدة (draft)
# ===========================================================================================
@can_access(5001)
def new_entry():
    try:
        data = request.vars
        errs = _validate_entry(data)
        if errs:
            return response.json(api.api_error(mess=" | ".join(errs)))

        attachment = data.attachment if (
            data.attachment is not None and hasattr(data.attachment, "file")
        ) else None

        nid = db.fund_entry.insert(
            entry_date=data.entry_date,
            kind=data.kind,
            category_id=int(data.category_id),
            payment_method=int(data.payment_method),
            amount=float(data.amount),
            beneficiary=(data.beneficiary or "").strip(),
            ref_type=(data.ref_type or "manual").strip(),
            ref_id=(int(data.ref_id) if data.ref_id else None),
            document_no=(data.document_no or "").strip(),
            attachment=attachment,
            description=(data.description or "").strip(),
            status="draft",
            submitted_by=auth.user.id,
            submitted_at=request.now,
        )
        db.commit()
        return response.json(api.api_ok(data={"id": nid}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# تعديل (مسودة أو مُرجَع للتعديل، ومن صاحب السجل)
# ===========================================================================================
@can_access(5001)
def edit_entry():
    try:
        data = request.vars
        row = db.fund_entry[int(data.id or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.status not in ("draft", "returned"):
            return response.json(api.api_error(
                mess="لا يمكن التعديل — السجل ليس مسودة ولا مُرجَعاً للتعديل"
            ))
        if row.submitted_by and row.submitted_by != auth.user.id \
                and not auth.has_membership("admin"):
            return response.json(api.api_error(mess="التعديل مقيد بصاحب السجل"))
        errs = _validate_entry(data)
        if errs:
            return response.json(api.api_error(mess=" | ".join(errs)))

        updates = dict(
            entry_date=data.entry_date,
            kind=data.kind,
            category_id=int(data.category_id),
            payment_method=int(data.payment_method),
            amount=float(data.amount),
            beneficiary=(data.beneficiary or "").strip(),
            ref_type=(data.ref_type or "manual").strip(),
            ref_id=(int(data.ref_id) if data.ref_id else None),
            document_no=(data.document_no or "").strip(),
            description=(data.description or "").strip(),
        )
        if data.attachment is not None and hasattr(data.attachment, "file"):
            updates["attachment"] = data.attachment
        row.update_record(**updates)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# تقديم للاعتماد: draft | returned ➜ submitted
# ===========================================================================================
@can_access(5001)
def submit_entry():
    try:
        row = db.fund_entry[int(request.args(0) or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.status not in ("draft", "returned"):
            return response.json(api.api_error(
                mess="لا يمكن التقديم — السجل ليس مسودة ولا مُرجَعاً للتعديل"
            ))
        # سبب الإرجاع يبقى كما هو ليرى المعتمِد ما طلبه عند مراجعة التصحيح
        row.update_record(status="submitted", submitted_at=request.now)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "status": "submitted"}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# اعتماد: submitted ➜ approved
# ===========================================================================================
def _can_approve():
    return bool(auth.has_membership("admin"))


@can_access(5002)
def approve_entry():
    try:
        if not _can_approve():
            return response.json(api.api_error(mess="صلاحية الاعتماد للمدير فقط"))
        row = db.fund_entry[int(request.args(0) or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.status != "submitted":
            return response.json(api.api_error(mess="لا يمكن الاعتماد — السجل غير مُقدَّم"))
        row.update_record(
            status="approved",
            approved_by=auth.user.id,
            approved_at=request.now,
            rejected_reason=None,
        )
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "status": "approved"}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# رفض: submitted ➜ rejected
# ===========================================================================================
@can_access(5002)
def reject_entry():
    try:
        if not _can_approve():
            return response.json(api.api_error(mess="صلاحية الرفض للمدير فقط"))
        data = request.vars
        row = db.fund_entry[int(data.id or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.status != "submitted":
            return response.json(api.api_error(mess="لا يمكن الرفض — السجل غير مُقدَّم"))
        reason = (data.reason or "").strip()
        if not reason:
            return response.json(api.api_error(mess="سبب الرفض مطلوب"))
        row.update_record(
            status="rejected",
            approved_by=auth.user.id,
            approved_at=request.now,
            rejected_reason=reason,
        )
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "status": "rejected"}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# إرجاع للتعديل: submitted | rejected ➜ returned
#
# ليس رفضاً. المعتمِد يرى خطأً في السند فيُعيده إلى أمين الصندوق ليصححه ويُعيد تقديمه.
# السبب إلزامي — هو الرسالة التي يقرأها أمين الصندوق ليعرف ما الذي يُصحّحه.
# أثر الإرجاع (من/متى/لماذا/كم مرة) يبقى محفوظاً بعد إعادة التقديم والاعتماد.
# ===========================================================================================
@can_access(5002)
def return_entry():
    try:
        if not _can_approve():
            return response.json(api.api_error(mess="صلاحية الإرجاع للمدير فقط"))
        data = request.vars
        row = db.fund_entry[int(data.id or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.status not in ("submitted", "rejected"):
            return response.json(api.api_error(
                mess="الإرجاع متاح للسندات المُقدَّمة أو المرفوضة فقط"
            ))
        reason = (data.reason or "").strip()
        if not reason:
            return response.json(api.api_error(mess="سبب الإرجاع مطلوب"))
        row.update_record(
            status="returned",
            returned_by=auth.user.id,
            returned_at=request.now,
            returned_reason=reason,
            returned_count=(row.returned_count or 0) + 1,
            # الإرجاع يلغي أثر الرفض السابق — السند عاد إلى يد أمين الصندوق
            rejected_reason=None,
        )
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "status": "returned"}))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# حذف: مسودة أو مُرجَع للتعديل
# ===========================================================================================
@can_access(5001)
def del_entry():
    try:
        row = db.fund_entry[int(request.args(0) or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.status not in ("draft", "returned"):
            return response.json(api.api_error(
                mess="الحذف متاح للمسودات والسندات المُرجَعة للتعديل فقط"
            ))
        if row.submitted_by and row.submitted_by != auth.user.id \
                and not auth.has_membership("admin"):
            return response.json(api.api_error(mess="الحذف مقيد بصاحب السجل"))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok(mess="تم الحذف"))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# مطابقة مع تسليم فترة
# ===========================================================================================
@can_access(5001)
def reconcile_shift():
    try:
        sid = int(request.args(0) or 0)
        shift = db.closing_shift[sid]
        if not shift:
            return response.json(api.api_error(mess="الفترة غير موجودة"))
        sql = (
            "SELECT "
            " COALESCE(SUM(CASE WHEN kind='expense' AND status='approved' THEN amount ELSE 0 END),0) AS exp, "
            " COALESCE(SUM(CASE WHEN kind='deposit' AND status='approved' THEN amount ELSE 0 END),0) AS dep "
            "FROM fund_entry "
            "WHERE entry_date BETWEEN %s AND %s"
        )
        d_from = shift.start_time.date() if shift.start_time else None
        d_to = shift.end_time.date() if shift.end_time else d_from
        r = db.executesql(sql, placeholders=[d_from, d_to], as_dict=True)[0]
        data = {
            "shift_id": shift.id,
            "start_time": str(shift.start_time or ""),
            "end_time": str(shift.end_time or ""),
            "kashir_amount_cash": float(shift.kashir_amount_cash or 0),
            "kashir_total": float(shift.kashir_total or 0),
            "app_total": float(shift.app_total or 0),
            "fund_expenses": float(r["exp"]),
            "fund_deposits": float(r["dep"]),
            "net_fund_delta": float(r["dep"]) - float(r["exp"]),
        }
        return response.json(api.api_ok(data=data))
    except Exception as e:
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# تصدير Excel — يستخدم نفس فلاتر get_entries
# ===========================================================================================
@can_access(5001)
def export_excel():
    try:
        import xlsxwriter
        import io

        ReqVar = request.vars
        conditions, params = [], []

        if ReqVar.date_from:
            conditions.append("fe.entry_date >= %s"); params.append(ReqVar.date_from)
        if ReqVar.date_to:
            conditions.append("fe.entry_date <= %s"); params.append(ReqVar.date_to)
        if ReqVar.kind in ("expense", "deposit"):
            conditions.append("fe.kind = %s"); params.append(ReqVar.kind)
        if ReqVar.category_id and ReqVar.category_id != "0":
            conditions.append("fe.category_id = %s"); params.append(int(ReqVar.category_id))
        if ReqVar.status and ReqVar.status != "all":
            conditions.append("fe.status = %s"); params.append(ReqVar.status)

        where_sql = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        sql = (
            "SELECT fe.entry_date, fe.kind, c.name_ar AS category, fe.beneficiary, "
            "       pm.name AS payment_method, fe.amount, fe.document_no, fe.status, "
            "       (COALESCE(us.first_name,'') || ' ' || COALESCE(us.last_name,'')) AS submitter, "
            "       (COALESCE(ua.first_name,'') || ' ' || COALESCE(ua.last_name,'')) AS approver, "
            "       fe.description "
            "FROM fund_entry fe "
            "LEFT JOIN key_fund_category c ON c.id = fe.category_id "
            "LEFT JOIN key_payment_method pm ON pm.id = fe.payment_method "
            "LEFT JOIN auth_user us ON us.id = fe.submitted_by "
            "LEFT JOIN auth_user ua ON ua.id = fe.approved_by "
            f"{where_sql} "
            "ORDER BY fe.entry_date ASC, fe.id ASC"
        )
        rows = db.executesql(sql, placeholders=params if params else None, as_dict=True)

        buf = io.BytesIO()
        wb = xlsxwriter.Workbook(buf, {"in_memory": True})
        ws = wb.add_worksheet("Fund")
        ws.right_to_left()
        head = wb.add_format({"bold": True, "bg_color": "#D9E1F2", "align": "center"})
        money = wb.add_format({"num_format": "#,##0.00"})

        headers = [
            "التاريخ", "النوع", "التصنيف", "المستفيد", "طريقة الدفع",
            "المبلغ", "رقم السند", "الحالة", "المُنشِئ", "المعتمد", "الوصف",
        ]
        for i, h in enumerate(headers):
            ws.write(0, i, h, head)
        for r_idx, r in enumerate(rows, start=1):
            ws.write(r_idx, 0, str(r.get("entry_date") or ""))
            ws.write(r_idx, 1, "مصروف" if r.get("kind") == "expense" else "إيداع")
            ws.write(r_idx, 2, r.get("category") or "")
            ws.write(r_idx, 3, r.get("beneficiary") or "")
            ws.write(r_idx, 4, r.get("payment_method") or "")
            ws.write(r_idx, 5, float(r.get("amount") or 0), money)
            ws.write(r_idx, 6, r.get("document_no") or "")
            ws.write(r_idx, 7, r.get("status") or "")
            ws.write(r_idx, 8, (r.get("submitter") or "").strip())
            ws.write(r_idx, 9, (r.get("approver") or "").strip())
            ws.write(r_idx, 10, r.get("description") or "")
        ws.set_column(0, 10, 18)
        wb.close()
        buf.seek(0)
        response.headers["Content-Type"] = (
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        fname = "fund_entries_" + request.now.strftime("%Y%m%d_%H%M%S") + ".xlsx"
        response.headers["Content-Disposition"] = f"attachment; filename={fname}"
        return buf.read()
    except Exception as e:
        print(e)
        return response.json(api.api_error(mess=e))


# ===========================================================================================
# طباعة سند صرف/استلام
# ===========================================================================================
@can_access(5001)
def print_voucher():
    eid = int(request.args(0) or 0)
    row = db.fund_entry[eid]
    if not row:
        redirect(URL("index"))
    cat = db.key_fund_category[row.category_id] if row.category_id else None
    pm = db.key_payment_method[row.payment_method] if row.payment_method else None
    submitter = db.auth_user[row.submitted_by] if row.submitted_by else None
    approver = db.auth_user[row.approved_by] if row.approved_by else None
    return dict(
        row=row, cat=cat, pm=pm,
        submitter=submitter, approver=approver,
    )
