# -*- coding: utf-8 -*-
#  type: ignore
import api_helpers as api


@auth.requires_login()
def index():
    return dict()


@auth.requires_login()
def get_movment():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    conditions = []
    params = []

    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            pattern = '%' + word + '%'
            conditions.append(
                "( detill LIKE %s OR CAST(amount AS text) LIKE %s"
                " OR CAST(process_date AS text) LIKE %s )"
            )
            params.extend([pattern, pattern, pattern])

    allowed_sort = {'id', 'process_date', 'process_type', 'detill', 'amount', 'aprove'}
    sort_col = ReqVar.SortBy if ReqVar.SortBy in allowed_sort else 'id'
    sa = 'ASC' if (ReqVar.sequence or 'true') == 'true' else 'DESC'

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    offset = pg * rc

    sql = (
        "SELECT *, ROUND("
        " SUM(CASE WHEN process_type = 1 THEN amount ELSE -amount END)"
        " OVER (ORDER BY id ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)"
        f"::numeric, 2) AS sum_total"
        f" FROM fund_movement {where}"
        f" ORDER BY {sort_col} {sa}"
        " LIMIT %s OFFSET %s"
    )
    sql2 = f"SELECT count(*) FROM fund_movement {where}"

    params_count = list(params)
    params.extend([rc, offset])

    qry = db.executesql(sql, placeholders=params, as_dict=True)
    qry2 = db.executesql(sql2, placeholders=params_count if params_count else None, as_dict=True)
    return response.json(api.api_list(rows=qry, count=qry2[0]["count"]))


@auth.requires_login()
def new_movment():
    try:
        data = request.vars
        nid = db.fund_movement.validate_and_insert(
            process_date=data.process_date,
            process_type=data.process_type,
            detill=data.detill,
            amount=data.amount,
            aprove=False,
        )
        db.commit()
        return response.json(api.api_ok(data=nid))
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def edit_movment():
    try:
        data = request.vars
        q = db.fund_movement[data.id]
        if q and q.aprove == False:
            q.process_date = data.process_date
            q.process_type = data.process_type
            q.detill = data.detill
            q.amount = data.amount
            q.update_record()
            db.commit()
            return response.json(api.api_ok(data=q))
        else:
            return response.json(api.api_error(mess="لايمكن الحفظ"))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def del_movment():
    try:
        del_row = db.fund_movement[request.args(0)]
        if del_row and del_row.aprove == False:
            del_row.delete_record()
            db.commit()
            return response.json(api.api_ok(mess="تم الحذف بنجاح", mess_code=1))
        else:
            return response.json(api.api_error(mess="حصل خطأ"))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@auth.requires_membership("admin")
def aprove_movment():
    try:
        edi_row = db.fund_movement[request.args(0)]
        if edi_row:
            edi_row.aprove = not edi_row.aprove
            edi_row.update_record()
            db.commit()
            return response.json(api.api_ok(data=edi_row))
        else:
            return response.json(api.api_error(mess="حصل خطأ"))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json(api.api_error(mess=e))


@auth.requires_login()
def print():
    return dict()

# edit_row.delete_record()
"""
@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict()


"""
