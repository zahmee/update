# -*- coding: utf-8 -*-
#  type: ignore
"""جودة بيانات الأصناف (البند الخامس، قرارات المالك 2026-09-17).

شاشة للمدير فقط (بطاقة في الإعدادات) تفحص كل الأصناف: عدد كل مشكلة وقائمة
أصنافها مع أزرار الانتقال لإصلاحها في شاشاتها الأصلية بقواعدها (بطاقة الصنف،
تغيير الباركود، دمج الأصناف). قراءة فقط — لا تكتب في القاعدة شيئاً.

قواعد الباركود والاسم وسعر البيع من modules/item_rules.py نفسها التي تحكم الحفظ،
فما تعدّه الشاشة خطأً هو ما يرفضه الإدخال. النتيجة تُحفظ مؤقتاً دقيقتين (فحص كل
الأصناف ثقيل نسبياً)، وزر "تحديث" يعيد الحساب فوراً.
"""
import os
import re

import api_helpers as api
import item_cleanup
import item_rules

HALALA_ID = 1  # صنف "هلله" الوهمي: باركوده "1" مقصود ولا سعر له
CACHE_SECONDS = 120
CATEGORY_MIN_ITEMS = 20  # لا يُحكم على ضريبة تصنيف بأقل من هذا العدد
CATEGORY_MAJORITY = 0.8  # نسبة الأغلبية التي تجعل المخالف مشبوهاً

GROUPS = [
    ("barcode", "الباركود", "fa-barcode"),
    ("basic", "البيانات الأساسية", "fa-id-card"),
    ("vat", "الضريبة", "fa-percent"),
    ("price", "السعر والربح", "fa-coins"),
]

# level: danger يفسد البيع أو الضريبة | warn يحتاج مراجعة | info للمتابعة
CHECKS = [
    dict(key="bc_invalid", group="barcode", level="danger", actions=["barcode", "card"],
         title="باركود غير صالح",
         hint="قصير أو وهمي أو ليس أرقاماً فقط (ومنه رقم التسجيل المكتوب مكان الباركود). "
              "يُصحَّح من شاشة تغيير الباركود بمسح باركود العلبة."),
    dict(key="bc_zero_dup", group="barcode", level="danger", actions=["merge", "card"],
         title="باركود مكرر بالأصفار البادئة",
         hint="الرقم نفسه لصنفين مع اختلاف الأصفار في أوله، وغالباً المنتج نفسه مسجلاً مرتين. "
              "إن كانا نفس المنتج فادمجهما."),
    dict(key="bc_nonstandard", group="barcode", level="warn", actions=["barcode", "card"],
         title="باركود غير قياسي",
         hint="خانة التحقق لا تطابق الرقم (غالباً خطأ كتابة)، أو الطول غير المعتاد 8 أو 12 أو 13 أو 14. "
              "امسح العلبة للتأكد."),
    dict(key="bc_internal", group="barcode", level="info", actions=["barcode", "card"],
         title="باركود داخلي بانتظار الحقيقي",
         hint="رقم داخلي (2990) وُلّد لمنتج بلا باركود أو بدل رقم قصير. إن كان على العلبة باركود "
              "فامسحه من شاشة تغيير الباركود وأعد طباعة الملصق."),
    dict(key="bc_detached", group="barcode", level="danger", actions=["card"],
         title="دفعات منفصلة عن صنفها",
         hint="نص باركود دفعات الصنف يختلف عن باركوده فتظهر في نقطة البيع بلا اسم أو باسم صنف آخر. "
              "تُصلح بسكربت التنظيف (item_data_cleanup ← realign)."),
    dict(key="bs_no_type", group="basic", level="danger", actions=["card"],
         title="بلا تصنيف", hint="اختر التصنيف من نافذة تعديل الصنف."),
    dict(key="bs_no_unit", group="basic", level="warn", actions=["card"],
         title="بلا وحدة", hint="اختر الوحدة من نافذة تعديل الصنف."),
    dict(key="bs_no_supplier", group="basic", level="info", actions=["card"],
         title="بلا مورد نشط",
         hint="خانة المورد فارغة أو المورد موقوف. يُعبأ تلقائياً من أول فاتورة توريد، أو يُختار من نافذة التعديل."),
    dict(key="bs_bad_name", group="basic", level="warn", actions=["card"],
         title="اسم قصير أو بلا حروف", hint="الاسم أقل من 10 أحرف أو بلا حروف. يُصحَّح من نافذة التعديل."),
    dict(key="bs_dup_name", group="basic", level="warn", actions=["merge", "card"],
         title="اسم مكرر",
         hint="أكثر من صنف بالاسم نفسه. إن كانا نفس المنتج فادمجهما، وإلا ميّز الاسم باللون أو المقاس."),
    dict(key="vt_mixed", group="vat", level="danger", actions=["card"],
         title="يُباع بضريبتين",
         hint="دفعات فيها رصيد بنسب ضريبة مختلفة، فتختلف ضريبة البيع حسب الدفعة التي يُباع منها."),
    dict(key="vt_null", group="vat", level="danger", actions=["card"],
         title="دفعات برصيد بلا نسبة ضريبة",
         hint="نقطة البيع تأخذ لها النسبة القديمة المخزنة في بطاقة الصنف (غالباً 5%)."),
    dict(key="vt_category", group="vat", level="warn", actions=["card"],
         title="نسبة عكس أغلب تصنيفه",
         hint="ضريبة أحدث دفعة تخالف أغلب أصناف التصنيف نفسه (80% فأكثر): إما التصنيف خطأ أو الضريبة."),
    dict(key="pr_no_price", group="price", level="warn", actions=["card"],
         title="بلا سعر بيع", hint="لا دفعة مسعّرة ولا سعر في بطاقة الصنف."),
    dict(key="pr_below_cost", group="price", level="danger", actions=["card"],
         title="البيع أقل من الشراء",
         hint="سعر البيع قبل الضريبة في أحدث دفعة أقل من آخر سعر شراء للصنف."),
]
CHECK_KEYS = {c["key"] for c in CHECKS}

BASE_SQL = """
SELECT im.id, im.item_id, UPPER(im.name) AS name,
       im.item_type, kt.name AS type_name, ku.name AS unit_name,
       s.name AS sup_name, COALESCE(s.stoped, 'F') AS sup_stoped,
       COALESCE(im.halt, 'F') AS halt, COALESCE(im.track_stock, 'T') AS track,
       im.public_price AS card_price,
       COALESCE(st.stock, 0) AS stock,
       lp.public_price AS det_price, lp.vat AS det_vat, lp.vat_in_public_price AS det_incl,
       lb.buy_price AS last_buy
FROM items_main im
LEFT JOIN key_type  kt ON kt.id = im.item_type
LEFT JOIN key_unit  ku ON ku.id = im.item_unit
LEFT JOIN suppliers s  ON s.id  = im.suppliers
LEFT JOIN (SELECT item_idr, SUM(items_count) AS stock FROM items_det GROUP BY item_idr) st
       ON st.item_idr = im.id
LEFT JOIN (SELECT DISTINCT ON (item_idr) item_idr, public_price, vat, vat_in_public_price
           FROM items_det WHERE public_price > 0 ORDER BY item_idr, id DESC) lp
       ON lp.item_idr = im.id
LEFT JOIN (SELECT DISTINCT ON (item_idr) item_idr, buy_price
           FROM items_det WHERE buy_price > 0 ORDER BY item_idr, id DESC) lb
       ON lb.item_idr = im.id
"""


def _pct(v):
    return "%g%%" % round(float(v or 0) * 100, 2)


def _compute():
    rows = db.executesql(BASE_SQL, as_dict=True)
    items = {}
    hits = {k: [] for k in CHECK_KEYS}
    by_key, by_name, cat = {}, {}, {}

    for r in rows:
        iid = r["id"]
        raw = r["item_id"] or ""
        code = raw.strip()
        stock = float(r["stock"] or 0)
        items[iid] = dict(id=iid, barcode=raw, name=r["name"] or "", type_name=r["type_name"] or "",
                          supplier=r["sup_name"] or "", stock=round(stock, 2), halt=r["halt"] == "T")
        service = iid == HALALA_ID or r["track"] == "F"

        # ---------------- الباركود
        if not service:
            errs = item_rules.barcode_errors(raw)
            if not errs and raw != code:
                errs = ["فيه مسافة في أوله أو آخره."]
            if errs:
                hits["bc_invalid"].append((iid, errs[0], None))
            else:
                warns = item_rules.barcode_warnings(code)
                if warns:
                    hits["bc_nonstandard"].append((iid, warns[0], None))
            if re.fullmatch(item_rules.INTERNAL_PREFIX + r"[0-9]{9}", code):
                hits["bc_internal"].append((iid, "باركود داخلي %s" % code, None))
        if re.fullmatch(r"[0-9]+", code) and item_rules.barcode_key(code):
            by_key.setdefault(item_rules.barcode_key(code), []).append(iid)

        # ---------------- البيانات الأساسية
        if not r["type_name"]:
            hits["bs_no_type"].append((iid, "", None))
        if not r["unit_name"]:
            hits["bs_no_unit"].append((iid, "", None))
        if not r["sup_name"]:
            hits["bs_no_supplier"].append((iid, "خانة المورد فارغة", None))
        elif r["sup_stoped"] == "T":
            hits["bs_no_supplier"].append((iid, "المورد موقوف: %s" % r["sup_name"], None))
        if not service:
            name_errs = item_rules.name_errors(r["name"])
            if name_errs:
                hits["bs_bad_name"].append((iid, name_errs[0], None))
        norm = item_rules.normalize_name(r["name"])
        if norm:
            by_name.setdefault(norm, []).append(iid)

        # ---------------- السعر والربح
        sale, sale_ex, vat, source = item_rules.sale_price(
            r["det_price"], r["det_vat"], r["det_incl"], r["card_price"])
        if not service and not sale:
            hits["pr_no_price"].append((iid, "", None))
        buy = float(r["last_buy"] or 0)
        if source == "batch" and buy > 0 and sale_ex + 0.005 < buy:
            hits["pr_below_cost"].append(
                (iid, "بيع %.2f قبل الضريبة، وآخر شراء %.2f" % (sale_ex, buy), None))

        # ---------------- بيانات ضريبة التصنيف
        if source == "batch" and r["det_vat"] is not None and r["item_type"] and not service:
            c = cat.setdefault(r["item_type"], {"name": r["type_name"] or "", "zero": [], "pos": []})
            (c["pos"] if float(r["det_vat"]) > 0 else c["zero"]).append(iid)

    # ---------------- التكرار
    for key, ids in by_key.items():
        if len(ids) > 1:
            for iid in ids:
                others = [o for o in ids if o != iid]
                hits["bc_zero_dup"].append((iid, "يتكرر مع: " + "، ".join(
                    "م %s (%s)" % (o, items[o]["barcode"].strip()) for o in others[:3]), others[0]))
    for name, ids in by_name.items():
        if len(ids) > 1:
            for iid in ids:
                others = [o for o in ids if o != iid]
                hits["bs_dup_name"].append((iid, "بالاسم نفسه: " + "، ".join(
                    "م %s" % o for o in others[:3]), others[0]))

    # ---------------- الضريبة على مستوى الدفعات
    for iid, rates in db.executesql(
        "SELECT item_idr, STRING_AGG(DISTINCT ROUND(vat::numeric, 4)::text, ',') FROM items_det"
        " WHERE items_count > 0 AND vat IS NOT NULL GROUP BY item_idr"
        " HAVING COUNT(DISTINCT ROUND(vat::numeric, 4)) > 1"
    ):
        if iid in items:
            hits["vt_mixed"].append((iid, "نسب الدفعات التي فيها رصيد: " + " / ".join(
                _pct(x) for x in sorted(rates.split(","), key=float)), None))
    for iid, n in db.executesql(
        "SELECT item_idr, COUNT(*) FROM items_det WHERE items_count > 0 AND vat IS NULL GROUP BY item_idr"
    ):
        if iid in items:
            hits["vt_null"].append((iid, "%d دفعة" % n, None))
    for tid, c in cat.items():
        total = len(c["zero"]) + len(c["pos"])
        if total < CATEGORY_MIN_ITEMS:
            continue
        if len(c["pos"]) >= CATEGORY_MAJORITY * total:
            for iid in c["zero"]:
                hits["vt_category"].append((iid, "%d%% من «%s» بضريبة، وهذا بدون ضريبة"
                                            % (round(100.0 * len(c["pos"]) / total), c["name"]), None))
        elif len(c["zero"]) >= CATEGORY_MAJORITY * total:
            for iid in c["pos"]:
                hits["vt_category"].append((iid, "%d%% من «%s» بدون ضريبة، وهذا بضريبة"
                                            % (round(100.0 * len(c["zero"]) / total), c["name"]), None))

    # ---------------- الدفعات المنفصلة
    for iid, n in db.executesql(
        "SELECT d.item_idr, COUNT(*) FROM items_det d JOIN items_main im ON im.id = d.item_idr"
        " WHERE COALESCE(d.item_id, '') <> COALESCE(im.item_id, '') GROUP BY d.item_idr"
    ):
        hits["bc_detached"].append((iid, "%d دفعة" % n, None))

    # الأهم أولاً: ما فيه رصيد، ثم الأحدث
    for key in hits:
        hits[key].sort(key=lambda h: (-abs(items[h[0]]["stock"]), -h[0]))
    return dict(generated=request.now.strftime("%Y-%m-%d %H:%M"), total=len(items), items=items, hits=hits)


def _data(refresh=False):
    key = "item_quality_%s" % request.application
    if refresh:
        cache.ram(key, None)
    return cache.ram(key, _compute, time_expire=CACHE_SECONDS)


@auth.requires_membership("admin")
def index():
    return dict()


@auth.requires_membership("admin")
def summary():
    data = _data(refresh=str(request.vars.refresh or "") == "1")
    groups = []
    for gkey, gtitle, icon in GROUPS:
        checks = [dict(key=c["key"], title=c["title"], hint=c["hint"], level=c["level"],
                       actions=c["actions"], count=len(data["hits"][c["key"]]))
                  for c in CHECKS if c["group"] == gkey]
        groups.append(dict(key=gkey, title=gtitle, icon=icon, checks=checks,
                           issues=sum(ch["count"] for ch in checks)))
    return response.json(api.api_ok(data=dict(generated=data["generated"], total_items=data["total"],
                                              groups=groups)))


@auth.requires_membership("admin")
def cleanup_plan():
    """تقرير التسوية: كم سيتغير في كل إصلاح. لا يكتب في القاعدة شيئاً."""
    plans = item_cleanup.plan(db)
    return response.json(api.api_ok(data=[
        dict(key=a["key"], title=a["title"], detail=a["detail"],
             count=plans[a["key"]]["count"], note=plans[a["key"]]["note"])
        for a in item_cleanup.ACTIONS
    ]))


@auth.requires_membership("admin")
def cleanup_apply():
    """تنفيذ الإصلاحات المختارة — نفس منطق سكربتات التسوية (modules/item_cleanup.py).

    لا يغيّر بنية القاعدة ولا يحذف صفاً، ويحفظ نسخة تراجع قبل الكتابة، ويتراجع
    كاملاً إن تغيّر إجمالي الأرصدة أو عدد الحركات.
    """
    if request.env.request_method != "POST" or str(request.vars.confirm or "") != "1":
        return response.json(api.api_error(mess="طلب غير صالح"))
    actions = [a for a in str(request.vars.actions or "").split(",") if a]
    try:
        res = item_cleanup.apply(db, request.folder, request.now, actions)
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذر التنفيذ ولم يُكتب شيء: %s" % e))
    if res["problems"]:
        return response.json(api.api_error(mess=" | ".join(res["problems"])))
    cache.ram("item_quality_%s" % request.application, None)  # الفحوص تُحسب من جديد
    titles = {a["key"]: a["title"] for a in item_cleanup.ACTIONS}
    return response.json(api.api_ok(data=dict(
        applied=[dict(key=k, title=titles[k], count=n) for k, n in res["applied"].items()],
        aliases=res.get("aliases", 0), backup=res["backup"], excel=res["excel"])))


@auth.requires_membership("admin")
def cleanup_file():
    """تنزيل ملف الباركود المستبدل الناتج عن التسوية. الاسم مولَّد ولا يُقبل غيره."""
    name = str(request.args(0) or "")
    if not re.fullmatch(r"item_barcode_review_\d{8}_\d{6}\.xlsx", name):
        raise HTTP(404)
    path = os.path.join(request.folder, "private", name)
    if not os.path.exists(path):
        raise HTTP(404)
    response.headers["Content-Type"] = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response.headers["Content-Disposition"] = 'attachment; filename="%s"' % name
    return response.stream(path)


@auth.requires_membership("admin")
def rows():
    key = request.vars.key
    if key not in CHECK_KEYS:
        return response.json(api.api_error(mess="فحص غير معروف"))
    try:
        page = max(0, int(request.vars.page or 0))
        rc = min(max(int(request.vars.RecordCount or 25), 1), 100)
    except (TypeError, ValueError):
        page, rc = 0, 25
    q = item_rules.normalize_name(request.vars.q)
    data = _data()
    out = []
    for iid, detail, other in data["hits"][key]:
        it = data["items"][iid]
        if q and q not in it["name"] and q not in it["barcode"].upper() and q != str(iid):
            continue
        out.append(dict(it, detail=detail, other=other))
    return response.json(api.api_list(rows=out[page * rc:(page + 1) * rc], count=len(out),
                                      generated=data["generated"]))
