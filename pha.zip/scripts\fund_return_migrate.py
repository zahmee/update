# -*- coding: utf-8 -*-
"""أعمدة إرجاع سند الصندوق للتعديل — تسوية فرع.

شاشة الصندوق تحتاج أربعة أعمدة على جدول fund_entry لحفظ أثر الإرجاع:

    returned_by  returned_at  returned_reason  returned_count

المفروض أن يضيفها web2py وحده لأن migrate مفعّلة. لكن في postgres تعليمات
تعديل الجداول تجري داخل معاملة: إذا انهار الطلب لأي سبب بعد إصدار التعديل
وقبل تثبيته، تتراجع المعاملة فتختفي الأعمدة من القاعدة — بينما web2py يكون
قد كتب ملف الوصف في مجلد databases على القرص، والقرص لا يتراجع.

النتيجة عطل صامت وخبيث: web2py يقرأ ملفه فيظن الأعمدة موجودة فلا يعيد
المحاولة أبداً، والشاشة تنهار عند كل فتح برسالة:

    column fe.returned_at does not exist

ولا يشفيه إلا إضافة الأعمدة يدوياً. وهذا ما يفعله هذا السكربت.

  الوضع الافتراضي: تقرير فقط، لا يكتب حرفاً في القاعدة.
  للتنفيذ الفعلي أضف الوسيط: apply

التشغيل من مجلد web2py:
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/fund_return_migrate.py
    uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/fund_return_migrate.py -A apply

آمن للإعادة: تشغيله مرتين لا يغيّر شيئاً في المرة الثانية، ولا يمس أي صف
قائم — الإضافة أعمدة فارغة فقط، ولا يُحذف ولا يُعدَّل أي سند.
"""
import sys

APPLY = any(str(a).strip().lower() == "apply" for a in sys.argv[1:])

# العمود -> تعريفه كما يولّده web2py لنفس النوع في هذا الجدول
COLUMNS = [
    ("returned_by", "INTEGER"),
    ("returned_at", "TIMESTAMP WITHOUT TIME ZONE"),
    ("returned_reason", "TEXT"),
    ("returned_count", "INTEGER DEFAULT 0"),
]
FK_NAME = "fund_entry_returned_by_fkey"


def hr(t=""):
    print("\n" + "=" * 62)
    if t:
        print(t)
        print("=" * 62)


def present():
    rows = db.executesql(
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_name='fund_entry' AND column_name LIKE 'returned%'"
    )
    return {r[0] for r in rows}


def fk_present():
    return bool(db.executesql(
        "SELECT 1 FROM pg_constraint WHERE conname=%s", placeholders=[FK_NAME]))


hr("تسوية فرع — أعمدة إرجاع سند الصندوق")
print("الوضع:", "تنفيذ فعلي (apply)" if APPLY else "تقرير فقط — لن يُكتب شيء")

have = present()
missing = [(c, t) for c, t in COLUMNS if c not in have]

hr("الحالة قبل")
for c, _t in COLUMNS:
    print("   %-16s %s" % (c, "موجود" if c in have else "مفقود"))
print("   %-16s %s" % (FK_NAME, "موجود" if fk_present() else "مفقود"))

total = db(db.fund_entry.id > 0).count()
print("\n   عدد سندات الصندوق:", total)

if not missing and fk_present():
    hr("النتيجة")
    print("الفرع سليم — كل الأعمدة والمفتاح الأجنبي موجودة. لا حاجة لأي إجراء.")
else:
    hr("المطلوب")
    for c, t in missing:
        print("   إضافة العمود:", c, "->", t)
    if not fk_present():
        print("   إضافة المفتاح الأجنبي:", FK_NAME)

    if not APPLY:
        hr("لم يُنفَّذ شيء")
        print("أعد التشغيل مع الوسيط  apply  للتنفيذ الفعلي.")
    else:
        hr("التنفيذ")
        for c, t in missing:
            db.executesql(
                "ALTER TABLE fund_entry ADD COLUMN IF NOT EXISTS %s %s" % (c, t))
            print("   تمت إضافة:", c)
        if not fk_present():
            db.executesql(
                "ALTER TABLE fund_entry ADD CONSTRAINT " + FK_NAME +
                " FOREIGN KEY (returned_by) REFERENCES auth_user(id) ON DELETE CASCADE")
            print("   تم إنشاء المفتاح الأجنبي:", FK_NAME)
        db.executesql(
            "UPDATE fund_entry SET returned_count = 0 WHERE returned_count IS NULL")
        db.commit()

        # إعادة السؤال بعد التثبيت — لا نصدّق أن العمود أُضيف لمجرد أن الأمر مرّ.
        # هذا بالضبط ما فات في المرة الأولى: التعليمة نجحت ثم تراجعت بلا إشعار.
        hr("التحقق بعد التثبيت")
        have2 = present()
        ok = True
        for c, _t in COLUMNS:
            good = c in have2
            ok = ok and good
            print("   %-16s %s" % (c, "مؤكَّد" if good else "ما زال مفقوداً"))
        fk_ok = fk_present()
        ok = ok and fk_ok
        print("   %-16s %s" % (FK_NAME, "مؤكَّد" if fk_ok else "ما زال مفقوداً"))

        # الاستعلام الحقيقي الذي كانت الشاشة تنهار عليه
        db.executesql(
            "SELECT fe.id, fe.returned_at, fe.returned_reason, fe.returned_count "
            "FROM fund_entry fe LIMIT 1")
        print("\n   استعلام الشاشة: نجح")

        after = db(db.fund_entry.id > 0).count()
        print("   عدد السندات بعد التسوية:", after, "(كان", str(total) + ")")
        assert after == total, "عدد السندات تغيّر — أوقف وراجع"

        hr("النتيجة")
        print("تمت التسوية بنجاح." if ok else "التسوية لم تكتمل — راجع أعلاه.")

hr()
