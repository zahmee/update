# -*- coding: utf-8 -*-
"""تهيئة النظام وجاهزيته — البيانات الافتتاحية وفهارس الأداء (المنطق المشترك).

يستورده:
  - controllers/setup.py        شاشة setup/seed_data: تفحص أولاً وتعرض النواقص، ثم تنشئ ما
                                  يختاره المدير خطوة خطوة، مع تحقق قبل كل خطوة وبعدها.
  - models/db_z_schema_sync.py  مرة لكل عملية خادم: auto_apply ينشئ الفهارس الناقصة على
                                  الجداول الصغيرة فقط؛ الجداول الكبيرة تُترك للشاشة.
  - scripts/seed_data.py        سطر الأوامر عند أول تثبيت (ومنه وحده يُنشأ المدير الأول).

فلا يوجد تنفيذان قد يفترقان مع الوقت.

قواعد لا تُكسر:
  - البيانات الافتتاحية تُضاف إلى الجدول الفارغ فقط؛ الجدول الذي فيه بيانات لا يُمس أبداً.
  - تُضاف بأرقام صريحة ١..ن ثم يُضبط التسلسل، لأن الكود يعتمد على أرقام بعينها (طريقة الدفع
    ٣ = آجل، نوع سداد المورد ٣/٤ = مرتجعات، الصنف ١ = الهللة، النظام ١ للشاشات). لو أُدرجت
    بالتسلسل وكان متقدماً (محاولة سابقة فاشلة) لأخذت أرقاماً أخرى وتعطلت تلك الحسابات بصمت.
  - الفهرس لا يُنشأ إن وُجد فهرس مطابق أو مغطٍّ له بأي اسم، ولا يُنشأ فريد على بيانات مكررة.
  - من الشاشة يُبنى الفهرس بـ CONCURRENTLY فلا يتوقف البيع أثناء بنائه، ثم يُتحقق أنه صالح؛
    المحاولة المعطوبة تُحذف فوراً (الفهرس المعطوب يُحدَّث مع كل كتابة ولا يُستخدم في أي بحث).

أسماء الجداول والأعمدة والفهارس ثوابت هنا ولا تأتي من المستخدم: الواجهة ترسل مفتاحاً يُبحث
عنه في القوائم أدناه، وكل قيمة أخرى تمر بـ placeholders. لا شيء يكتب إلا *_apply و auto_apply
و drop_extra.
"""

import re
from collections import defaultdict

# الجداول التي يتجاوز عدد صفوفها هذا الحد لا يُبنى فهرسها تلقائياً عند تشغيل الخادم: البناء
# العادي يوقف الكتابة في الجدول طوال مدته (ثوانٍ على جدول فواتير بمليون صف)، فيُترك للشاشة
# التي تبنيه بـ CONCURRENTLY. تحت الحد يستغرق البناء أقل من ثانية.
AUTO_MAX_ROWS = 500000

# أقفال تمنع تشغيلين متزامنين لنفس الخطوة (مديران يضغطان معاً)
_LOCK_KEY = "asbab5:system_readiness"

# مهلة انتظار الأقفال أثناء بناء فهرس من الشاشة، ومهلة البناء كله (أقل من مهلة gunicorn ٣٠٠ث)
_LOCK_TIMEOUT = "20s"
_STATEMENT_TIMEOUT = "280s"


class ReadinessError(Exception):
    def __init__(self, message, status=400):
        Exception.__init__(self, message)
        self.status = status


# ===========================================================================================
# البيانات الافتتاحية
# ===========================================================================================

SEED_GROUPS = [
    {"key": "keys", "title": "الترميزات الأساسية", "icon": "tags"},
    {"key": "access", "title": "الدخول والصلاحيات", "icon": "user-shield"},
    {"key": "records", "title": "السجلات الافتراضية", "icon": "id-card"},
    {"key": "company", "title": "المنشأة والفوترة الإلكترونية", "icon": "building"},
    {"key": "hr", "title": "الموارد البشرية", "icon": "users"},
    {"key": "fund", "title": "الصندوق", "icon": "cash-register"},
]


def _named(values, field="name", **extra):
    return [dict({field: v}, **extra) for v in values]


SEEDS = [
    # ── الترميزات الأساسية ──
    {"key": "key_unit", "group": "keys", "table": "key_unit", "label": "وحدات الأصناف",
     "rows": _named(["حبة", "علبة", "كرتون", "ملل", "شنطة"])},
    {"key": "key_payment_method", "group": "keys", "table": "key_payment_method", "label": "طرق الدفع",
     "rows": _named(["نقدي", "شبكة الكترونية", "آجل", "تحويل في الحساب", "شيك", "خصم من الرصيد"]),
     "note": "أرقامها ثابتة في الكود: ١ نقدي، ٢ شبكة، ٣ آجل، ٤ تحويل."},
    {"key": "key_cust", "group": "keys", "table": "key_cust", "label": "أنواع العملاء",
     "rows": _named(["عميل عام", "عميل جمعية البر"])},
    {"key": "key_type", "group": "keys", "table": "key_type", "label": "تصنيفات الأصناف",
     "rows": _named(["ادوات تجميل", "ادوات طبية", "ادوية", "اطفال", "اسنان"])},
    {"key": "key_payment_type", "group": "keys", "table": "key_payment_type", "label": "أنواع سداد المورد",
     "rows": _named(["سداد مستحقات", "خصم مكتسب", "مرتجعات/فاتورة", "مرتجعات/اصناف"]),
     "note": "أرقامها ثابتة في الكود: ٣ و٤ مرتجعات المورد."},
    {"key": "key_invoce_type", "group": "keys", "table": "key_invoce_type", "label": "تصنيف فواتير الموردين",
     "rows": _named(["مشتريات", "تعويض", "هدايا"])},

    # ── الدخول والصلاحيات ──
    {"key": "auth_group", "group": "access", "table": "auth_group", "label": "مجموعات الصلاحيات",
     "rows": _named(["admin", "user", "account", "report"], field="role")},
    # لا يُنشأ من الشاشة: فتحها يتطلب مستخدماً مسجلاً، فجدول المستخدمين ليس فارغاً أبداً هناك
    {"key": "auth_user", "group": "access", "table": "auth_user", "label": "المدير الأول للنظام",
     "rows": [{"first_name": "admin", "last_name": "user", "email": "admin@user.com"}],
     "preview": ["admin@user.com، كلمة المرور admin"], "cli_only": True,
     "note": "يُنشأ من سطر الأوامر عند أول تثبيت ويُضم إلى مجموعة admin."},
    {"key": "systems", "group": "access", "table": "systems", "label": "النظام",
     "rows": _named(["نظام الصيدلية"]),
     "note": "كل شاشة في سجل الصلاحيات مربوطة بالنظام رقم ١."},

    # ── السجلات الافتراضية ──
    {"key": "suppliers", "group": "records", "table": "suppliers", "label": "المورد النقدي العام",
     "rows": _named(["مورد عام - مورد نقدي"])},
    {"key": "customers", "group": "records", "table": "customers", "label": "العميل النقدي العام",
     "rows": [{"name": "عميل عام - نقدي", "mobile": "0"}]},
    # صنف التبرع بباقي الهلل: يُباع ولا يُشترى، فرصيده سالب بطبيعته. لذلك لا يُتابع مخزونه
    # (وإلا عُدّ عجزاً) ويبقى موقوفاً فلا يدخل تقرير إعادة الطلب. الكود يستثنيه بالرقم ١.
    {"key": "items_main", "group": "records", "table": "items_main", "label": "صنف الهللة (باقي الهلل)",
     "rows": [{"item_id": "1", "name": "هلله", "item_reg": "1", "flexible_price": True,
               "public_price": 0.01, "track_stock": False, "halt": True}],
     "preview": ["هلله: الرقم ١، سعر متغير، بلا متابعة مخزون"],
     "note": "صنف وهمي للتبرع بكسور الريال؛ الكود يستثنيه بالرقم ١."},

    # ── المنشأة والفوترة الإلكترونية ──
    {"key": "important_info", "group": "company", "table": "important_info", "label": "المعلومات الرسمية للمنشأة",
     "rows": [{"name": "نظام ؟؟؟؟؟؟؟؟؟", "vat": "0", "tel": "0", "mobile": "05",
               "address": "العنوان", "msg1": "----", "msg2": "----"}],
     "preview": ["سجل مؤقت يُستكمل من شاشة المعلومات الرسمية"]},
    {"key": "csr_config", "group": "company", "table": "csr_config", "label": "إعدادات الربط بالهيئة",
     "rows": [{"otp": "123456"}],
     "preview": ["سجل الربط الأولي (يُستكمل من شاشة الربط بالهيئة)"]},

    # ── الموارد البشرية ──
    {"key": "key_doc_types", "group": "hr", "table": "key_doc_types", "label": "أنواع المستندات",
     "rows": _named(["اوراق المؤسسة الرسمية", "اقامة", "جواز سفر", "عقد عمل", "ترخيص مزاولة مهنة"])},
    {"key": "key_job_titles", "group": "hr", "table": "key_job_titles", "label": "المسميات الوظيفية",
     "rows": _named(["صيدلي", "فني صيدلة", "محاسب", "مدير", "بائع"])},
    {"key": "key_nationalities", "group": "hr", "table": "key_nationalities", "label": "الجنسيات",
     "rows": _named(["سعودي", "مصري", "يمني", "سوداني", "هندي", "باكستاني", "بنغلاديشي", "فلبيني"])},
    {"key": "key_advance_types", "group": "hr", "table": "key_advance_types", "label": "أنواع السلف",
     "rows": _named(["سلفة راتب", "سلفة شخصية", "سلفة طارئة"])},
    {"key": "key_allowance_deduction", "group": "hr", "table": "key_allowance_deduction",
     "label": "البدلات والخصومات",
     "rows": [{"name": n, "ad_type": t} for n, t in [
         ("بدل سكن", "بدل"), ("بدل نقل", "بدل"), ("بدل إضافي", "بدل"),
         ("خصم غياب", "خصم"), ("خصم تأخير", "خصم"), ("خصم سلفة", "خصم")]],
     "note": "مسير الرواتب يخصم أقساط السلف عبر بند «خصم سلفة» باسمه."},
    {"key": "key_emp_status", "group": "hr", "table": "key_emp_status", "label": "حالات الموظفين",
     "rows": _named(["على رأس العمل", "في إجازة", "منقطع", "مفصول"])},

    # ── الصندوق ──
    {"key": "key_fund_category", "group": "fund", "table": "key_fund_category",
     "label": "تصنيفات حركات الصندوق",
     "rows": [{"code": c, "name_ar": n, "kind": k, "is_active": True} for c, n, k in [
         ("RENT", "إيجار", "expense"), ("ELEC", "كهرباء", "expense"), ("WATER", "ماء", "expense"),
         ("TELE", "اتصالات وإنترنت", "expense"), ("SAL", "رواتب", "expense"),
         ("ADV", "سلف موظفين", "expense"), ("MAINT", "صيانة", "expense"),
         ("TRANS", "مواصلات", "expense"), ("MISC", "نثرية", "expense"),
         ("SUP", "دفعات موردين", "expense"), ("GOV", "رسوم حكومية", "expense"),
         ("OTHER_EX", "مصروفات أخرى", "expense"), ("DEPOSIT", "إيداع نقدي", "deposit"),
         ("RETURN", "استرداد من مورد/جهة", "deposit"), ("OTHER_DP", "إيداعات أخرى", "deposit"),
         ("LEGACY", "مُرحَّل من النظام القديم", "expense")]],
     "preview_field": "name_ar"},
]

_SEEDS_BY_KEY = {s["key"]: s for s in SEEDS}


def _q(db, sql, ph=None):
    return db.executesql(sql, placeholders=ph or [], as_dict=True)


def _scalar(db, sql, ph=None):
    rows = db.executesql(sql, placeholders=ph or [])
    return rows[0][0] if rows else None


def _existing_tables(db, names):
    return {r["table_name"] for r in _q(
        db,
        "SELECT table_name FROM information_schema.tables"
        " WHERE table_schema = current_schema() AND table_name = ANY(%s)",
        [list(names)],
    )}


def _count(db, table):
    return int(_scalar(db, "SELECT COUNT(*) FROM " + table) or 0)


def _preview(spec):
    if spec.get("preview"):
        return list(spec["preview"])
    field = spec.get("preview_field") or ("role" if spec["table"] == "auth_group" else "name")
    return [str(r.get(field, "")) for r in spec["rows"]]


def _link(c, f, label):
    return {"c": c, "f": f, "label": label}


_AR_DIGITS = str.maketrans("0123456789,", "٠١٢٣٤٥٦٧٨٩٬")


def ar_num(n):
    """رقم بالأرقام العربية كما تعرضها الواجهة (Intl ar-SA)."""
    return "{:,}".format(n).translate(_AR_DIGITS) if isinstance(n, int) else str(n).translate(_AR_DIGITS)


def _seed_warnings(db, key):
    """صفوف يعتمد عليها الكود في جدول غير فارغ: تنبيه للقراءة فقط، والإصلاح من شاشته."""
    out = []
    if key == "key_payment_method":
        have = {r[0] for r in db.executesql("SELECT id FROM key_payment_method WHERE id IN (1,2,3,4)")}
        miss = [i for i in (1, 2, 3, 4) if i not in have]
        if miss:
            out.append({"text": "لا توجد طريقة دفع بالرقم %s. فواتير الآجل ورصيد العملاء وإقفال الوردية"
                                " تعتمد على هذه الأرقام." % "، ".join(ar_num(i) for i in miss),
                        "link": _link("setup", "payment_method_key", "طرق الدفع")})
    elif key == "key_payment_type":
        have = {r[0] for r in db.executesql("SELECT id FROM key_payment_type WHERE id IN (3,4)")}
        if len(have) < 2:
            out.append({"text": "نوعا السداد ٣ و٤ (مرتجعات المورد) غير موجودين معاً، وكشف حساب المورد"
                                " يعتمد عليهما.", "link": None})
    elif key == "auth_group":
        if not _scalar(db, "SELECT COUNT(*) FROM auth_group WHERE role = 'admin'"):
            out.append({"text": "لا توجد مجموعة admin، فلن يعمل أي مستخدم كمدير للنظام.",
                        "link": _link("setup", "users_management", "إدارة المستخدمين")})
    elif key == "auth_user":
        row = _q(db, "SELECT id, password FROM auth_user WHERE lower(email) = 'admin@user.com' LIMIT 1")
        if row and _default_password(db, row[0]["password"]):
            out.append({"text": "المستخدم admin@user.com ما زال بكلمة المرور الافتراضية admin. غيّرها فوراً.",
                        "link": _link("setup", "users_management", "إدارة المستخدمين")})
    elif key == "systems":
        if not _scalar(db, "SELECT COUNT(*) FROM systems WHERE id = 1"):
            out.append({"text": "لا يوجد نظام بالرقم ١، فلا يمكن تسجيل الشاشات في سجل الصلاحيات.",
                        "link": None})
    elif key == "items_main":
        row = _q(db, "SELECT item_id, name, COALESCE(track_stock, 'T') AS tracked FROM items_main WHERE id = 1")
        if not row:
            out.append({"text": "لا يوجد صنف بالرقم ١، والكود يستثني صنف الهللة بهذا الرقم.", "link": None})
        elif row[0]["tracked"] == "T" and "هلل" in (row[0]["name"] or ""):
            out.append({"text": "صنف الهللة (رقم ١) ما زال يُتابع مخزونه، فيظهر رصيده السالب عجزاً"
                                " في تنبيهات البيع بدون رصيد. شغّل ترحيل الفرع أو أوقف متابعة مخزونه.",
                        "link": None})
    elif key == "important_info":
        row = _q(db, "SELECT name, vat FROM important_info ORDER BY id LIMIT 1")
        if row and ("؟؟؟" in (row[0]["name"] or "") or (row[0]["vat"] or "0").strip() in ("", "0")):
            out.append({"text": "بيانات المنشأة ما زالت افتراضية (الاسم أو الرقم الضريبي) وتظهر هكذا"
                                " في الفواتير.", "link": _link("setup", "important_info", "المعلومات الرسمية")})
    elif key == "key_allowance_deduction":
        if not _scalar(db, "SELECT COUNT(*) FROM key_allowance_deduction WHERE name = %s", ["خصم سلفة"]):
            out.append({"text": "لا يوجد بند «خصم سلفة»، فلن يخصم مسير الرواتب أقساط السلف.",
                        "link": _link("setup", "allowance_deduction", "البدلات والخصومات")})
    return out


def _default_password(db, stored):
    try:
        return db.auth_user.password.validate("admin")[0] == stored
    except Exception:
        return False


def seed_status(db):
    """حالة كل بند افتتاحي — قراءة فقط."""
    tables = _existing_tables(db, [s["table"] for s in SEEDS])
    out = []
    for spec in SEEDS:
        item = {
            "key": spec["key"], "group": spec["group"], "label": spec["label"],
            "table": spec["table"], "note": spec.get("note", ""),
            "preview": _preview(spec), "rows": len(spec["rows"]),
            "count": 0, "state": "no_table", "warnings": [],
        }
        if spec["table"] in tables:
            item["count"] = _count(db, spec["table"])
            if item["count"]:
                item["state"] = "done"
                item["warnings"] = _seed_warnings(db, spec["key"])
            else:
                item["state"] = "cli" if spec.get("cli_only") else "missing"
        out.append(item)
    return out


def _serial_sequence(db, table):
    seq = _scalar(db, "SELECT pg_get_serial_sequence(%s, 'id')", [table])
    if seq:
        return seq
    # جداول أُعيدت تسميتها: التسلسل غير مملوك للعمود لكنه في قيمته الافتراضية
    default = _scalar(
        db,
        "SELECT column_default FROM information_schema.columns"
        " WHERE table_schema = current_schema() AND table_name = %s AND column_name = 'id'",
        [table],
    ) or ""
    m = re.search(r"nextval\('([^']+)'", default)
    return m.group(1) if m else None


def _xact_lock(db, key):
    return bool(_scalar(db, "SELECT pg_try_advisory_xact_lock(hashtext(%s))", [key]))


def _check(checks, ok, text):
    checks.append({"ok": bool(ok), "text": text})
    return ok


def seed_apply(db, key, allow_cli_only=False):
    """يضيف البيانات الافتتاحية لجدول واحد بعد التحقق، ثم يتحقق مما أضاف.

    لا يلتزم (commit) إلا بعد ثبوت التحقق؛ أي فشل يتراجع عن الخطوة كلها.
    """
    spec = _SEEDS_BY_KEY.get(key)
    if not spec:
        raise ReadinessError("بند غير معروف.")
    table, rows = spec["table"], spec["rows"]
    checks = []
    res = {"kind": "seed", "key": key, "label": spec["label"], "state": "failed",
           "checks": checks, "mess": ""}
    try:
        if not _check(checks, _xact_lock(db, _LOCK_KEY + ":seed"),
                      "لا توجد عملية تهيئة أخرى قيد التنفيذ"):
            res["mess"] = "عملية تهيئة أخرى تعمل الآن. أعد المحاولة بعد قليل."
            return res
        if spec.get("cli_only") and not allow_cli_only:
            res["mess"] = "هذا البند يُنشأ من سطر الأوامر عند أول تثبيت فقط."
            return res
        if not _check(checks, table in _existing_tables(db, [table]), "الجدول موجود في القاعدة"):
            res["mess"] = "الجدول غير موجود بعد. شغّل النظام مرة ليُنشئه ثم أعد الفحص."
            return res
        n = _count(db, table)
        if n:
            _check(checks, False, "الجدول فارغ")
            res["state"] = "skipped"
            res["mess"] = "لم يُضف شيء: الجدول لم يعد فارغاً (عدد سجلاته %s)." % ar_num(n)
            return res
        _check(checks, True, "الجدول فارغ")

        admin_group = None
        if key == "auth_user":
            admin_group = _scalar(db, "SELECT id FROM auth_group WHERE role = 'admin' ORDER BY id LIMIT 1")
            if not _check(checks, admin_group, "مجموعة admin موجودة"):
                res["mess"] = "أنشئ مجموعات الصلاحيات أولاً."
                return res

        seq = _serial_sequence(db, table)
        if not _check(checks, seq, "تسلسل الترقيم معروف"):
            res["mess"] = "تعذّر تحديد تسلسل ترقيم الجدول، ولم يُضف شيء."
            return res

        dal = db[table]
        for i, row in enumerate(rows, 1):
            values = dict(row)
            if key == "auth_user":
                values["password"] = dal.password.validate("admin")[0]
            dal.insert(id=i, **values)
        db.executesql("SELECT setval(%s, (SELECT MAX(id) FROM " + table + "))", placeholders=[seq])
        if key == "auth_user":
            db.auth_membership.insert(user_id=1, group_id=admin_group)

        # التحقق بعد الإضافة: العدد والأرقام كما خُطط لها
        got = [r[0] for r in db.executesql("SELECT id FROM " + table + " ORDER BY id")]
        ok = got == list(range(1, len(rows) + 1))
        _check(checks, ok, "أُضيفت بالأرقام من ١ إلى %s" % ar_num(len(rows)))
        if ok and key == "auth_user":
            ok = _check(checks, _scalar(db, "SELECT COUNT(*) FROM auth_membership"
                                            " WHERE user_id = 1 AND group_id = %s", [admin_group]),
                        "المدير عضو في مجموعة admin")
        if not ok:
            db.rollback()
            res["mess"] = "لم يطابق الناتج المتوقع، فأُلغيت الخطوة ولم يُحفظ شيء."
            return res
        db.commit()
        res["state"] = "done"
        res["mess"] = "أُضيفت البيانات وتم التحقق منها (السجلات: %s)." % ar_num(len(rows))
        return res
    except Exception as e:
        db.rollback()
        res["state"] = "failed"
        res["mess"] = "فشلت الإضافة ولم يُحفظ شيء: %s" % _pg_message(e)
        return res


# ===========================================================================================
# فهارس الأداء
# ===========================================================================================

INDEX_GROUPS = [
    {"key": "items", "title": "الأصناف والمخزون", "icon": "boxes"},
    {"key": "sales", "title": "المبيعات والمرتجعات والوردية", "icon": "receipt"},
    {"key": "suppliers", "title": "الموردون والمشتريات", "icon": "truck"},
    {"key": "customers", "title": "العملاء", "icon": "user-friends"},
    {"key": "access", "title": "الصلاحيات", "icon": "shield-check"},
    {"key": "hr", "title": "الموارد البشرية", "icon": "users"},
    {"key": "fund", "title": "الصندوق", "icon": "cash-register"},
    {"key": "agent", "title": "البحث الذكي والمحادثات", "icon": "comments"},
]


def _ix(group, name, table, columns, purpose, unique=False, method="btree", where=None,
        match=None, where_match=None, requires=None):
    """تعريف فهرس.

    columns: كما تُكتب في CREATE INDEX ("item_idr" أو "move_date DESC" أو "tags gin_trgm_ops").
    match:   صيغة PostgreSQL المفككة لأعمدة التعبير (مثل "upper((name)::text)")، لكشف فهرس
             مطابق باسم آخر. الأعمدة العادية لا تحتاجه.
    """
    return {"group": group, "name": name, "table": table, "columns": list(columns),
            "purpose": purpose, "unique": unique, "method": method, "where": where,
            "match": match, "where_match": where_match, "requires": requires}


INDEXES = [
    # ── الأصناف والمخزون ──
    # مسح الباركود في نقطة البيع والمرتجع (invoice.getit): "where item_id=%s order by id desc
    # limit 1". بلا فهرس يمشي على الدفعات من الأحدث حتى يجد الباركود: ٢٤ ألف صف لصنف قديم،
    # والجدول كله (٢٠٤ آلاف) لباركود غير موجود أو سابق — مع كل مسح. id ضمن الفهرس ليخدم
    # الترتيب مباشرة. item_id لا يتغير إلا عند دمج أو تغيير باركود، فلا يمنع التحديث في مكانه.
    _ix("items", "idx_items_det_item_id", "items_det", ["item_id", "id DESC"],
        "مسح الباركود في نقطة البيع والمرتجع (أحدث دفعة للباركود)"),
    _ix("items", "idx_items_det_item_idr", "items_det", ["item_idr"],
        "ربط الدفعات بصنفها في كل استعلامات الأصناف والفواتير والجرد"),
    _ix("items", "idx_items_det_supplier_inv", "items_det", ["supplier_inv"],
        "دفعات فاتورة التوريد"),
    _ix("items", "idx_items_main_suppliers", "items_main", ["suppliers"],
        "تصفية الأصناف حسب المورد"),
    _ix("items", "idx_items_main_item_type", "items_main", ["item_type"],
        "تصفية الأصناف حسب التصنيف"),
    _ix("items", "idx_items_main_name_upper", "items_main", ["upper(name)"],
        "البحث باسم الصنف", match=["upper((name)::text)"]),
    _ix("items", "idx_item_halt_log_item", "item_halt_log", ["item_idr", "id"],
        "آخر حدث إيقاف للصنف في بطاقته وفي تسوية البيانات"),
    _ix("items", "idx_items_movement_composite", "items_movement",
        ["item_main", "move_type", "move_date DESC"],
        "حركة الصنف حسب النوع والتاريخ (كرت الصنف وشاشة الحركة)"),
    _ix("items", "idx_items_movement_item_det", "items_movement", ["item_det"],
        "حركات الدفعة الواحدة"),
    _ix("items", "idx_inv_count_item_session", "inv_count_item", ["session_id"],
        "أصناف جلسة الجرد"),
    _ix("items", "idx_inv_count_item_item_main", "inv_count_item", ["item_main"],
        "البحث عن صنف داخل الجرد"),
    _ix("items", "idx_items_reorder_detail_reorder", "items_reorder_detail", ["items_reorder"],
        "أسطر تقرير إعادة الطلب (عرضه وحذفه)"),
    # كل استعلامات شاشة البيع بدون رصيد تبدأ بنطاق happened_on وترتّب به
    _ix("items", "idx_stock_exception_happened_on", "stock_exception", ["happened_on DESC"],
        "حالات البيع بدون رصيد بالتاريخ"),

    # ── المبيعات والمرتجعات والوردية ──
    # الفريد حارس التكرار الحقيقي: فحص التطبيق "ابحث ثم أدرج" فيه فجوة يمر منها طلبان متزامنان
    # بنفس الرقم فتُحفظ الفاتورة مرتين ويُخصم المخزون مرتين. لا يُنشأ على بيانات مكررة — تُعالج
    # من شاشة حماية تكرار الفواتير (setup/uuid_guard) التي تحذف الزائد بعد نسخة احتياطية.
    _ix("sales", "idx_invoice_master_uuid_uniq", "invoice_master", ["uuid"],
        "منع حفظ فاتورة البيع مرتين (حارس التكرار)", unique=True),
    _ix("sales", "idx_invoice_master_customer", "invoice_master", ["customer"],
        "فواتير العميل ورصيده"),
    _ix("sales", "idx_invoice_master_created_on", "invoice_master", ["created_on DESC"],
        "تقارير المبيعات بالتاريخ ولوحة التحكم"),
    _ix("sales", "idx_invoice_master_created_by_date", "invoice_master", ["created_by", "created_on DESC"],
        "مبيعات البائع اليومية وإقفال الوردية"),
    # رصيد العميل = فواتير الآجل فقط (payment_method=3) — نحو ٠٫٣٪ من الفواتير. فهرس جزئي صغير
    # يخدم رصيد العميل في نقطة البيع وقائمة العملاء، ولا يُحدَّث مع فواتير النقد والشبكة.
    _ix("sales", "idx_invoice_master_credit_customer", "invoice_master", ["customer"],
        "رصيد العميل من فواتير الآجل (نقطة البيع وقائمة العملاء)",
        where="payment_method = 3", where_match="(payment_method = 3)"),
    # فلتر «غير المرسلة للهيئة» في قائمة الفواتير. كان معرّفاً سابقاً بـ "= false" على عمود
    # CHAR(1) فرفضته القاعدة في كل تشغيل بصمت ولم يُنشأ قط في أي فرع.
    _ix("sales", "idx_invoice_master_zatca_pending", "invoice_master", ["id DESC"],
        "الفواتير غير المرسلة للهيئة في قائمة الفواتير",
        where="send_to_zatca = 'F'", where_match="(send_to_zatca = 'F'::bpchar)"),
    _ix("sales", "idx_invoice_details_uuid", "invoice_details", ["uuid"],
        "أسطر الفاتورة"),
    _ix("sales", "idx_invoice_details_item_number", "invoice_details", ["item_number"],
        "مبيعات الدفعة وآخر بيع للصنف"),
    _ix("sales", "idx_invoice_details_created_on", "invoice_details", ["created_on DESC"],
        "تقارير المبيعات التفصيلية بالتاريخ"),
    _ix("sales", "idx_inv_return_master_uuid_uniq", "inv_return_master", ["uuid"],
        "منع حفظ المرتجع مرتين (حارس التكرار)", unique=True),
    _ix("sales", "idx_inv_return_master_customer", "inv_return_master", ["customer"],
        "مرتجعات العميل"),
    _ix("sales", "idx_inv_return_master_created_on", "inv_return_master", ["created_on DESC"],
        "تقارير المرتجعات بالتاريخ"),
    _ix("sales", "idx_inv_return_details_uuid", "inv_return_details", ["uuid"],
        "أسطر المرتجع"),
    _ix("sales", "idx_inv_return_details_item_number", "inv_return_details", ["item_number"],
        "مرتجعات الدفعة"),
    _ix("sales", "idx_inv_return_details_created_on", "inv_return_details", ["created_on DESC"],
        "تقارير المرتجعات التفصيلية"),
    _ix("sales", "idx_closing_shift_pha_user", "closing_shift", ["pha_user"],
        "فترات إقفال المستخدم"),
    # صف واحد لكل فاتورة في سجل مشاكل الإرسال؛ يُبحث عنه مع كل إرسال ناجح لإغلاق مشكلتها السابقة
    _ix("sales", "idx_zatca_issue_invoice", "zatca_issue", ["inv_type", "inv_id"],
        "سجل مشاكل إرسال الفاتورة للهيئة (صف واحد لكل فاتورة)", unique=True),
    _ix("sales", "idx_zatca_issue_state_last", "zatca_issue", ["state", "last_at DESC"],
        "شاشة مشاكل الإرسال: المفتوحة بالأحدث"),

    # ── الموردون والمشتريات ──
    _ix("suppliers", "idx_suppliers_bills_supplier", "suppliers_bills", ["supplier"],
        "فواتير المورد"),
    _ix("suppliers", "idx_suppliers_bills_confirmation", "suppliers_bills", ["bill_confirmation"],
        "الفواتير المعتمدة وغير المعتمدة"),
    _ix("suppliers", "idx_suppliers_bills_pay_supplier", "suppliers_bills_pay", ["supplier"],
        "سدادات المورد وكشف حسابه"),
    # قائمة مرتجعات الموردين تحسب لكل سطر استعلامين فرعيين على هذا الربط، ومستودع التالف يقرأ به
    _ix("suppliers", "idx_returned_supply_det_returned_supply", "returned_supply_det", ["returned_supply"],
        "أصناف فاتورة مرتجع المورد (القائمة ومستودع التالف)"),

    # ── العملاء ──
    _ix("customers", "idx_customers_pay_customers_id", "customers_pay", ["customers_id"],
        "سدادات العميل ورصيده"),

    # ── الصلاحيات ──
    _ix("access", "idx_screens_rules_user_screen", "screens_rules", ["to_user", "screens"],
        "فحص صلاحية المستخدم على الشاشة (مع كل طلب)"),
    # invoice_sending بلا فهرس عمداً: يُفرَّغ مع كل دورة إرسال فيبقى صغيراً. تعريفه السابق
    # (WHERE send = false على عمود CHAR(1)) رفضته القاعدة في كل تشغيل ولم يُنشأ قط.

    # ── الموارد البشرية ──
    _ix("hr", "idx_attendance_employee_date", "attendance", ["employee", "att_date DESC"],
        "حضور الموظف في يوم محدد"),
    _ix("hr", "idx_attendance_otp_employee", "attendance_otp", ["employee"],
        "رمز التحقق للموظف"),
    _ix("hr", "idx_emp_leaves_employee", "emp_leaves", ["employee"],
        "إجازات الموظف"),
    _ix("hr", "idx_emp_salary_detail_employee", "emp_salary_detail", ["employee"],
        "بدلات الموظف وخصوماته"),
    _ix("hr", "idx_emp_advances_employee", "emp_advances", ["employee", "is_closed"],
        "السلف المفتوحة للموظف"),
    _ix("hr", "idx_emp_advance_payment_advance", "emp_advance_payment", ["advance", "pay_date"],
        "سجل سداد السلفة"),
    _ix("hr", "idx_emp_advance_payment_period", "emp_advance_payment",
        ["employee", "pay_year", "pay_month"],
        "خصم السلفة المسجل لموظف في شهر مسير (يمنع الخصم المكرر)"),
    _ix("hr", "idx_payroll_employee_period", "payroll", ["employee", "pay_year", "pay_month"],
        "مسير الموظف لشهر محدد"),
    _ix("hr", "idx_payroll_detail_payroll_id", "payroll_detail", ["payroll_id"],
        "تفاصيل المسير"),
    _ix("hr", "idx_my_files_expiry_date", "my_files", ["expiry_date"],
        "تنبيه المستندات المنتهية"),
    _ix("hr", "idx_my_files_created_by", "my_files", ["created_by"],
        "مستندات المستخدم"),

    # ── الصندوق ──
    _ix("fund", "idx_fund_entry_entry_date", "fund_entry", ["entry_date DESC"],
        "حركات الصندوق بالتاريخ"),
    _ix("fund", "idx_fund_entry_status", "fund_entry", ["status"],
        "تصفية الحركات بالحالة"),
    _ix("fund", "idx_fund_entry_category", "fund_entry", ["category_id"],
        "تجميع الحركات حسب التصنيف"),
    _ix("fund", "idx_fund_entry_kind", "fund_entry", ["kind"],
        "فصل المصروفات عن الإيداعات"),
    _ix("fund", "idx_fund_entry_ref", "fund_entry", ["ref_type", "ref_id"],
        "ربط الحركة بمستندها المرجعي"),

    # ── البحث الذكي والمحادثات ──
    _ix("agent", "idx_item_tags_trgm", "item_tags", ["tags gin_trgm_ops"],
        "بحث الوكيل الذكي في وسوم الأصناف (بحث تقريبي)", method="gin", requires="pg_trgm"),
    _ix("agent", "conversation_log_sender_idx", "conversation_log", ["sender_id", "created_on"],
        "محادثة المرسل الواحد بترتيبها"),
    _ix("agent", "conversation_log_created_idx", "conversation_log", ["created_on"],
        "أحدث المحادثات"),
    _ix("agent", "conversation_log_customer_idx", "conversation_log", ["customer_id"],
        "محادثات العميل"),
]

_INDEXES_BY_NAME = {s["name"]: s for s in INDEXES}

EXTENSIONS = [
    {"name": "pg_trgm", "label": "البحث التقريبي في النصوص (pg_trgm)",
     "purpose": "يحتاجه فهرس وسوم الأصناف الذي يسرّع بحث الوكيل الذكي."},
]
_EXTENSIONS_BY_NAME = {e["name"]: e for e in EXTENSIONS}


def create_sql(spec, concurrently=False):
    return "CREATE %sINDEX %sIF NOT EXISTS %s ON %s%s (%s)%s" % (
        "UNIQUE " if spec["unique"] else "",
        "CONCURRENTLY " if concurrently else "",
        spec["name"], spec["table"],
        "" if spec["method"] == "btree" else " USING " + spec["method"],
        ", ".join(spec["columns"]),
        " WHERE " + spec["where"] if spec.get("where") else "",
    )


def _spec_keys(spec):
    """أعمدة التعريف بالصيغة التي يعيدها pg_get_indexdef لكل عمود، مع اتجاه الترتيب."""
    cols, desc = [], []
    for i, col in enumerate(spec["columns"]):
        if spec.get("match"):
            cols.append(spec["match"][i])
        else:
            cols.append(col.split()[0])
        desc.append(" DESC" in col.upper())
    return cols, desc


def _plain_columns(spec):
    return [] if spec.get("match") else [c.split()[0] for c in spec["columns"]]


_INDEX_SQL = r"""
SELECT t.relname AS tbl, i.relname AS name, x.indisunique AS uniq, x.indisprimary AS pkey,
       x.indisvalid AS valid, x.indisready AS ready, am.amname AS method,
       pg_get_expr(x.indpred, x.indrelid) AS pred, x.indoption::text AS opts,
       ARRAY(SELECT pg_get_indexdef(x.indexrelid, k, false)
               FROM generate_series(1, x.indnkeyatts) AS k ORDER BY k) AS cols,
       EXISTS (SELECT 1 FROM pg_constraint c WHERE c.conindid = x.indexrelid) AS backed,
       pg_relation_size(x.indexrelid) AS size,
       regexp_replace(pg_get_indexdef(x.indexrelid), '^(CREATE (UNIQUE )?INDEX )\S+ ON ', '\1ON ') AS def,
       x.indexrelid::bigint AS oid
  FROM pg_index x
  JOIN pg_class i ON i.oid = x.indexrelid
  JOIN pg_class t ON t.oid = x.indrelid
  JOIN pg_namespace n ON n.oid = t.relnamespace
  JOIN pg_am am ON am.oid = i.relam
 WHERE n.nspname = current_schema() AND t.relname = ANY(%s)
"""


def _load_indexes(db, tables):
    by_table = defaultdict(list)
    for r in _q(db, _INDEX_SQL, [list(tables)]):
        flags = [int(v) for v in (r["opts"] or "").split()]
        r["desc"] = [bool(f & 1) for f in flags]
        r["cols"] = list(r["cols"] or [])
        by_table[r["tbl"]].append(r)
    return by_table


def _load_tables(db, tables):
    """عدد الصفوف التقريبي وحجم كل جدول، والأعمدة الموجودة فيه."""
    info = {}
    for r in _q(db,
                "SELECT c.relname AS tbl, c.reltuples::bigint AS rows, pg_total_relation_size(c.oid) AS size"
                "  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace"
                " WHERE n.nspname = current_schema() AND c.relkind IN ('r', 'p') AND c.relname = ANY(%s)",
                [list(tables)]):
        rows = int(r["rows"])
        if rows < 0:
            # جدول لم تُجمع إحصاؤه بعد: عدّ محدود التكلفة بدل تقدير مجهول
            rows = int(_scalar(db, "SELECT COUNT(*) FROM (SELECT 1 FROM " + r["tbl"] +
                                   " LIMIT %s) s", [AUTO_MAX_ROWS + 1]) or 0)
        info[r["tbl"]] = {"rows": rows, "size": int(r["size"] or 0), "columns": set()}
    for r in _q(db,
                "SELECT table_name, column_name FROM information_schema.columns"
                " WHERE table_schema = current_schema() AND table_name = ANY(%s)",
                [list(tables)]):
        if r["table_name"] in info:
            info[r["table_name"]]["columns"].add(r["column_name"])
    return info


def _duplicate_values(db, spec):
    """عدد القيم المكررة التي تمنع الفهرس الفريد (الفارغ '' قيمة مكررة أيضاً)."""
    col = _plain_columns(spec)[0]
    return int(_scalar(
        db,
        "SELECT COUNT(*) FROM (SELECT 1 FROM " + spec["table"] + " WHERE " + col +
        " IS NOT NULL GROUP BY " + col + " HAVING COUNT(*) > 1) d",
    ) or 0)


def _index_state(db, spec, idx_by_table, tables, installed_ext, dup_check_max_rows=None):
    """حالة فهرس واحد مع خطوات التحقق التي بُنيت عليها — قراءة فقط."""
    table = spec["table"]
    checks = []
    st = {"name": spec["name"], "state": "missing", "via": "", "how": "", "reason": "",
          "checks": checks, "rows": 0, "size": 0, "big": False}
    t = tables.get(table)
    if not _check(checks, t, "الجدول موجود"):
        st["state"], st["reason"] = "no_table", "الجدول غير موجود في القاعدة بعد."
        return st
    st["rows"], st["size"] = t["rows"], t["size"]
    st["big"] = t["rows"] > AUTO_MAX_ROWS
    missing_cols = [c for c in _plain_columns(spec) if c not in t["columns"]]
    if not _check(checks, not missing_cols, "الأعمدة موجودة"):
        st["state"] = "no_column"
        st["reason"] = "أعمدة غير موجودة: %s" % "، ".join(missing_cols)
        return st

    existing = idx_by_table.get(table, [])
    own = [ix for ix in existing if ix["name"] == spec["name"]]
    if own:
        ix = own[0]
        if ix["valid"] and ix["ready"]:
            st["state"], st["size"] = "ok", int(ix["size"] or 0)
            _check(checks, True, "الفهرس موجود وصالح")
            return st
        _check(checks, False, "الفهرس موجود لكنه معطوب من محاولة سابقة")
        st["state"] = "invalid"
    else:
        cols, desc = _spec_keys(spec)
        for ix in existing:
            if not (ix["valid"] and ix["ready"]) or ix["method"] != spec["method"]:
                continue
            same_pred = (ix["pred"] or None) == (spec.get("where_match") or None)
            if (ix["cols"] == cols and ix["desc"][:len(desc)] == desc and same_pred
                    and bool(ix["uniq"]) == bool(spec["unique"])):
                st.update(state="ok", via=ix["name"], how="equivalent", size=int(ix["size"] or 0))
                _check(checks, True, "يوجد فهرس مطابق باسم آخر")
                return st
        if not spec["unique"] and not spec.get("where"):
            for ix in existing:
                if (ix["valid"] and ix["ready"] and ix["method"] == spec["method"] and not ix["pred"]
                        and ix["cols"][:len(cols)] == cols):
                    st.update(state="ok", via=ix["name"], how="covered", size=int(ix["size"] or 0))
                    _check(checks, True, "يغطيه فهرس أوسع قائم")
                    return st
        _check(checks, True, "لا يوجد فهرس مطابق بأي اسم")

    def block(reason):
        # النسخة المعطوبة تبقى "معطوب" فيمكن حذفها (تُحدَّث مع كل كتابة بلا فائدة) حتى لو تعذّر
        # إعادة بنائها الآن؛ index_apply يحذفها ثم يتوقف عند السبب.
        st["reason"] = reason
        if st["state"] == "invalid":
            st["blocked"] = True
        else:
            st["state"] = "blocked"
        return st

    if spec.get("requires") and spec["requires"] not in installed_ext:
        _check(checks, False, "امتداد %s مثبّت" % spec["requires"])
        return block("يتطلب امتداد %s أولاً." % spec["requires"])

    if spec["unique"]:
        if dup_check_max_rows is not None and t["rows"] > dup_check_max_rows:
            return block("لم يُفحص التكرار في هذا الوضع.")
        dups = _duplicate_values(db, spec)
        if not _check(checks, not dups, "لا توجد قيم مكررة تمنع القيد الفريد"):
            st["link"] = _link("setup", "uuid_guard", "حماية تكرار الفواتير")
            return block("توجد قيم مكررة (%s). عالجها أولاً من شاشة حماية تكرار الفواتير." % ar_num(dups))
    return st


def _installed_extensions(db):
    return {r[0] for r in db.executesql("SELECT extname FROM pg_extension")}


def index_status(db):
    """حالة كل فهرس في القائمة — قراءة فقط."""
    names = sorted({s["table"] for s in INDEXES})
    idx_by_table = _load_indexes(db, names)
    tables = _load_tables(db, names)
    installed = _installed_extensions(db)
    out = []
    for spec in INDEXES:
        st = _index_state(db, spec, idx_by_table, tables, installed)
        st.update({"group": spec["group"], "table": spec["table"], "purpose": spec["purpose"],
                   "unique": spec["unique"], "method": spec["method"],
                   "definition": "%s%s (%s)%s" % (
                       spec["table"],
                       "" if spec["method"] == "btree" else " USING " + spec["method"],
                       ", ".join(spec["columns"]),
                       " WHERE " + spec["where"] if spec.get("where") else ""),
                   "requires": spec.get("requires") or ""})
        out.append(st)
    return out


def extension_status(db):
    installed = _installed_extensions(db)
    available = {r[0] for r in db.executesql("SELECT name FROM pg_available_extensions")}
    out = []
    for e in EXTENSIONS:
        state = "ok" if e["name"] in installed else ("missing" if e["name"] in available else "unavailable")
        out.append({"name": e["name"], "label": e["label"], "purpose": e["purpose"], "state": state})
    return out


def extra_indexes(db, tables):
    """فهارس زائدة: مكررة حرفياً لفهرس آخر، أو معطوبة من محاولة بناء سابقة.

    كلاهما يُحدَّث مع كل كتابة في الجدول (أي على مسار الكاشير) دون أن يخدم أي بحث.
    لا يُدرج أبداً فهرس مسنود بقيد (مفتاح أساسي/قيد فريد). من كل مجموعة مكررة يبقى:
    المسنود بقيد، ثم المسجل في قائمة الفهارس أعلاه (فيبقى الكود مصدر الحقيقة)، ثم الأقدم.
    """
    registry = set(_INDEXES_BY_NAME)
    out = []
    groups = defaultdict(list)
    for tbl, rows in _load_indexes(db, tables).items():
        for ix in rows:
            if ix["backed"] or ix["pkey"]:
                if ix["valid"]:
                    groups[(tbl, ix["def"])].append(ix)
                continue
            if not (ix["valid"] and ix["ready"]):
                if ix["name"] not in registry:  # فهارس القائمة المعطوبة تظهر في قائمتها وتُعاد
                    out.append({"name": ix["name"], "table": tbl, "size": int(ix["size"] or 0),
                                "kind": "invalid", "twin": "", "definition": ix["def"]})
                continue
            groups[(tbl, ix["def"])].append(ix)
    for (tbl, _def), rows in groups.items():
        if len(rows) < 2:
            continue
        rows.sort(key=lambda ix: (not (ix["backed"] or ix["pkey"]), ix["name"] not in registry, ix["oid"]))
        keeper = rows[0]
        for ix in rows[1:]:
            if ix["backed"] or ix["pkey"]:
                continue
            out.append({"name": ix["name"], "table": tbl, "size": int(ix["size"] or 0),
                        "kind": "duplicate", "twin": keeper["name"], "definition": ix["def"]})
    out.sort(key=lambda e: -e["size"])
    return out


# ===========================================================================================
# التنفيذ خارج المعاملة (CONCURRENTLY لا يعمل داخل معاملة)
# ===========================================================================================

def _run_autocommit(db, statements):
    """ينفّذ أوامر بلا معاملة مع مهل انتظار، ثم يعيد الاتصال لحاله قبل رجوعه لمجمع الاتصالات."""
    db.commit()
    conn = db._adapter.connection
    previous = conn.autocommit
    conn.autocommit = True
    try:
        db.executesql("SELECT set_config('lock_timeout', %s, false),"
                      " set_config('statement_timeout', %s, false)",
                      placeholders=[_LOCK_TIMEOUT, _STATEMENT_TIMEOUT])
        for sql in statements:
            db.executesql(sql)
    finally:
        try:
            db.executesql("RESET lock_timeout")
            db.executesql("RESET statement_timeout")
        finally:
            conn.autocommit = previous


def _session_lock(db, key):
    return bool(_scalar(db, "SELECT pg_try_advisory_lock(hashtext(%s))", [key]))


def _session_unlock(db, key):
    try:
        db.executesql("SELECT pg_advisory_unlock(hashtext(%s))", placeholders=[key])
        db.commit()
    except Exception:
        db.rollback()


def _pg_message(error):
    text = str(error).strip().split("\n")[0]
    if "lock timeout" in text or "canceling statement due to lock timeout" in text:
        return "الجدول مشغول بعمليات أخرى طويلة. أعد المحاولة في وقت أهدأ."
    if "statement timeout" in text:
        return "تجاوز البناء المهلة المسموحة. أعد المحاولة في وقت أهدأ."
    if "permission denied" in text or "must be owner" in text:
        return "مستخدم قاعدة البيانات لا يملك الصلاحية لهذه العملية (%s)." % text
    return text


def _quote_ident(name):
    return '"%s"' % name.replace('"', '""')


def _index_row(db, table, name):
    rows = _load_indexes(db, [table]).get(table, [])
    return next((ix for ix in rows if ix["name"] == name), None)


def index_apply(db, name):
    """ينشئ فهرساً واحداً من القائمة: تحقق ← بناء دون إيقاف الكتابة ← تحقق من صلاحيته."""
    spec = _INDEXES_BY_NAME.get(name)
    if not spec:
        raise ReadinessError("فهرس غير معروف.")
    table = spec["table"]
    res = {"kind": "index", "key": name, "label": spec["purpose"], "state": "failed",
           "checks": [], "mess": ""}
    lock = _LOCK_KEY + ":index:" + name
    if not _session_lock(db, lock):
        res["mess"] = "هذا الفهرس قيد الإنشاء من جلسة أخرى الآن."
        return res
    try:
        tables = _load_tables(db, [table])
        st = _index_state(db, spec, _load_indexes(db, [table]), tables, _installed_extensions(db))
        res["checks"] = checks = st["checks"]
        if st["state"] == "ok":
            res["state"] = "skipped"
            res["mess"] = ("موجود مسبقاً باسم %s، فلم يُنشأ مكرر." % st["via"]) if st["via"] \
                else "موجود مسبقاً، لا شيء لعمله."
            return res
        if st["state"] in ("no_table", "no_column", "blocked"):
            res["mess"] = st["reason"]
            return res
        if st.get("blocked"):
            # نسخة معطوبة وإعادة البناء متعذرة الآن: تُحذف وحدها (لا تخدم بحثاً وتُحدَّث مع كل
            # كتابة) ثم يُذكر السبب
            try:
                _run_autocommit(db, ["DROP INDEX CONCURRENTLY IF EXISTS " + _quote_ident(name)])
            except Exception as e:
                res["mess"] = "تعذّر حذف النسخة المعطوبة: %s" % _pg_message(e)
                return res
            _check(checks, _index_row(db, table, name) is None, "حُذفت النسخة المعطوبة")
            res["mess"] = "لم يُعد البناء: %s" % st["reason"]
            return res

        statements = []
        if st["state"] == "invalid":
            statements.append("DROP INDEX CONCURRENTLY IF EXISTS " + _quote_ident(name))
        statements.append(create_sql(spec, concurrently=True))
        try:
            _run_autocommit(db, statements)
        except Exception as e:
            _check(checks, False, "بناء الفهرس")
            res["mess"] = "فشل البناء: %s" % _pg_message(e)
        ix = _index_row(db, table, name)
        if ix and ix["valid"] and ix["ready"]:
            _check(checks, True, "الفهرس موجود وصالح بعد البناء")
            res["state"] = "done"
            res["mess"] = "أُنشئ الفهرس وتم التحقق من صلاحيته."
            return res
        if ix:
            # البناء المتزامن الفاشل يترك فهرساً معطوباً يُحدَّث مع كل كتابة — يُحذف فوراً
            try:
                _run_autocommit(db, ["DROP INDEX CONCURRENTLY IF EXISTS " + _quote_ident(name)])
                _check(checks, True, "حُذفت النسخة المعطوبة")
            except Exception:
                _check(checks, False, "حذف النسخة المعطوبة (تبقى معطوبة في قائمة الفهارس)")
        if not res["mess"]:
            res["mess"] = "الفهرس غير موجود بعد المحاولة. راجع سجل قاعدة البيانات."
        return res
    finally:
        _session_unlock(db, lock)


def drop_extra(db, name, tables):
    """يحذف فهرساً زائداً بعد التأكد من أنه ما زال زائداً (وتوأمه قائم إن كان مكرراً)."""
    current = {e["name"]: e for e in extra_indexes(db, tables)}
    res = {"kind": "extra", "key": name, "label": name, "state": "failed", "checks": [], "mess": ""}
    checks = res["checks"]
    entry = current.get(name)
    if not _check(checks, entry, "الفهرس ما زال زائداً"):
        res["state"] = "skipped"
        res["mess"] = "لم يعد زائداً، لا شيء لحذفه."
        return res
    if entry["kind"] == "duplicate":
        _check(checks, True, "الفهرس المطابق %s قائم وصالح" % entry["twin"])
    _check(checks, True, "غير مسنود بقيد")
    lock = _LOCK_KEY + ":index:" + name
    if not _session_lock(db, lock):
        res["mess"] = "هذا الفهرس قيد المعالجة من جلسة أخرى الآن."
        return res
    try:
        try:
            _run_autocommit(db, ["DROP INDEX CONCURRENTLY IF EXISTS " + _quote_ident(name)])
        except Exception as e:
            res["mess"] = "فشل الحذف: %s" % _pg_message(e)
            return res
        gone = _index_row(db, entry["table"], name) is None
        _check(checks, gone, "الفهرس لم يعد موجوداً")
        if gone:
            res["state"] = "done"
            res["mess"] = "حُذف الفهرس الزائد وتم التحقق."
        else:
            res["mess"] = "ما زال الفهرس موجوداً بعد المحاولة."
        return res
    finally:
        _session_unlock(db, lock)


def extension_apply(db, name):
    ext = _EXTENSIONS_BY_NAME.get(name)
    if not ext:
        raise ReadinessError("امتداد غير معروف.")
    res = {"kind": "extension", "key": name, "label": ext["label"], "state": "failed",
           "checks": [], "mess": ""}
    checks = res["checks"]
    if name in _installed_extensions(db):
        _check(checks, True, "الامتداد مثبّت")
        res["state"], res["mess"] = "skipped", "مثبّت مسبقاً."
        return res
    available = _scalar(db, "SELECT COUNT(*) FROM pg_available_extensions WHERE name = %s", [name])
    if not _check(checks, available, "الامتداد متوفر في خادم قاعدة البيانات"):
        res["mess"] = "الامتداد غير متوفر في خادم PostgreSQL، ويلزم تثبيت حزمة contrib."
        return res
    try:
        db.executesql("CREATE EXTENSION IF NOT EXISTS " + name)
        db.commit()
    except Exception as e:
        db.rollback()
        res["mess"] = "تعذّر التثبيت: %s" % _pg_message(e)
        return res
    ok = name in _installed_extensions(db)
    _check(checks, ok, "الامتداد مثبّت بعد التنفيذ")
    res["state"] = "done" if ok else "failed"
    res["mess"] = "ثُبّت الامتداد وتم التحقق." if ok else "لم يظهر الامتداد بعد التنفيذ."
    return res


# ===========================================================================================
# الإنشاء التلقائي عند تشغيل الخادم (models/db_z_schema_sync.py)
# ===========================================================================================

def auto_apply(db, max_rows=AUTO_MAX_ROWS):
    """ينشئ الفهارس الناقصة على الجداول الصغيرة فقط، بنفس فحوص الشاشة.

    يُستدعى مرة لكل عملية خادم (وعند تعديل النماذج). لا ينشئ مكرراً لفهرس قائم باسم آخر،
    ولا فريداً على بيانات مكررة، ولا يبني شيئاً على جدول كبير — تلك تظهر ناقصة في شاشة
    تهيئة النظام وتُبنى منها دون إيقاف البيع. لا يرفع استثناءً أبداً.
    """
    created = []
    try:
        names = sorted({s["table"] for s in INDEXES})
        idx_by_table = _load_indexes(db, names)
        tables = _load_tables(db, names)
        installed = _installed_extensions(db)
        db.commit()
    except Exception:
        db.rollback()
        return created
    for spec in INDEXES:
        try:
            st = _index_state(db, spec, idx_by_table, tables, installed, dup_check_max_rows=max_rows)
            if st["state"] not in ("missing", "invalid") or st.get("blocked") or st["rows"] > max_rows:
                db.commit()
                continue
            # عمليات خادم متعددة (gunicorn) تبدأ معاً: واحدة فقط تبني، والبقية تتخطى
            if not _xact_lock(db, _LOCK_KEY + ":index:" + spec["name"]):
                db.rollback()
                continue
            ix = _index_row(db, spec["table"], spec["name"])
            if ix and ix["valid"] and ix["ready"]:
                db.commit()
                continue
            if ix:
                db.executesql("DROP INDEX IF EXISTS " + _quote_ident(spec["name"]))
            db.executesql(create_sql(spec))
            db.commit()
            created.append(spec["name"])
        except Exception:
            db.rollback()
    return created


def summary(seeds, indexes, extras, extensions):
    return {
        "seeds_total": len(seeds),
        "seeds_done": sum(1 for s in seeds if s["state"] == "done"),
        "seeds_missing": sum(1 for s in seeds if s["state"] == "missing"),
        "warnings": sum(len(s["warnings"]) for s in seeds),
        "indexes_total": len(indexes),
        "indexes_ok": sum(1 for s in indexes if s["state"] == "ok"),
        "indexes_missing": sum(1 for s in indexes if s["state"] in ("missing", "invalid")),
        "indexes_blocked": sum(1 for s in indexes if s["state"] in ("blocked", "no_table", "no_column")),
        "extras": len(extras),
        "extras_size": sum(e["size"] for e in extras),
        "extensions_missing": sum(1 for e in extensions if e["state"] != "ok"),
    }
