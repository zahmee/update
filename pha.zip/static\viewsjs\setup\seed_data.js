(function () {
  'use strict';
  var cfg = window.SYSTEM_READINESS;
  if (!cfg || !document.getElementById('system-readiness')) return;

  // ترتيب التنفيذ: الامتداد قبل الفهرس الذي يحتاجه، والبيانات قبل الفهارس، والحذف آخراً
  var KIND_ORDER = { extension: 0, seed: 1, index: 2, extra: 3 };
  var KIND_LABEL = { extension: 'امتداد', seed: 'بيانات افتتاحية', index: 'فهرس', extra: 'حذف فهرس زائد' };
  var numberFormat = new Intl.NumberFormat('ar-SA');
  var seq = 0;

  function byKey(list, key) {
    var out = {};
    (list || []).forEach(function (item) { out[item[key]] = item; });
    return out;
  }

  new Vue({
    el: '#system-readiness',
    data: {
      report: null, loading: false, error: '', tab: 'seeds',
      filter: { seeds: 'issues', indexes: 'issues' },
      selected: [], pending: {}, results: {}, log: [], run: null,
      canApply: cfg.canApply
    },
    computed: {
      busy: function () { return this.loading || !!(this.run && !this.run.finished); },
      seedIssues: function () {
        return this.report ? this.report.seeds.filter(this.seedNeedsAttention) : [];
      },
      indexIssues: function () {
        return this.report ? this.report.indexes.filter(function (x) { return x.state !== 'ok'; }) : [];
      },
      seedGroupsView: function () {
        return this.groupView(this.report && this.report.seed_groups,
          this.filter.seeds === 'issues' ? this.seedIssues : (this.report ? this.report.seeds : []), 'group');
      },
      indexGroupsView: function () {
        return this.groupView(this.report && this.report.index_groups,
          this.filter.indexes === 'issues' ? this.indexIssues : (this.report ? this.report.indexes : []), 'group');
      },
      extensionsView: function () {
        var all = this.filter.indexes === 'all';
        return this.report ? this.report.extensions.filter(function (e) { return all || e.state !== 'ok'; }) : [];
      },
      tabs: function () {
        var s = (this.report && this.report.summary) || {};
        var n = this.number;
        var seedHint = s.seeds_missing ? 'جداول فارغة: ' + n(s.seeds_missing) : 'لا جداول فارغة';
        if (s.warnings) seedHint += '، تنبيهات: ' + n(s.warnings);
        var ixHint = s.indexes_missing ? 'ناقص: ' + n(s.indexes_missing) : 'لا فهارس ناقصة';
        if (s.indexes_blocked) ixHint += '، متعذر: ' + n(s.indexes_blocked);
        if (s.extensions_missing) ixHint += '، امتداد ناقص';
        return [
          { key: 'seeds', icon: 'table', title: 'البيانات الافتتاحية', value: n(s.seeds_done),
            of: 'من ' + n(s.seeds_total), hint: seedHint, attention: !!(s.seeds_missing || s.warnings) },
          { key: 'indexes', icon: 'tachometer-alt', title: 'فهارس السرعة', value: n(s.indexes_ok),
            of: 'من ' + n(s.indexes_total), hint: ixHint,
            attention: !!(s.indexes_missing || s.indexes_blocked || s.extensions_missing) },
          { key: 'extras', icon: 'layer-group', title: 'فهارس زائدة', value: n(s.extras), of: '',
            hint: s.extras ? this.size(s.extras_size) + ' تُحدَّث مع كل حفظ بلا فائدة' : 'لا يوجد زائد',
            attention: !!s.extras },
          { key: 'log', icon: 'history', title: 'سجل التنفيذ', value: n(this.log.length), of: '',
            hint: this.log.length ? 'خطوات هذه الجلسة' : 'لم يُنفَّذ شيء بعد', attention: false }
        ];
      },
      steps: function () {
        // كل الخطوات الممكنة بترتيب التنفيذ، ليُستخرج منها المحدد
        if (!this.report) return [];
        var out = [];
        function add(kind, key, label, big) {
          out.push({ id: kind + ':' + key, kind: kind, key: key, label: label, big: !!big, pos: out.length });
        }
        this.report.extensions.forEach(function (e) { add('extension', e.name, e.label); });
        this.report.seeds.forEach(function (s) { add('seed', s.key, s.label); });
        this.report.indexes.forEach(function (x) { add('index', x.name, x.purpose, x.big); });
        this.report.extras.forEach(function (e) { add('extra', e.name, 'حذف ' + e.name); });
        return out.sort(function (a, b) { return KIND_ORDER[a.kind] - KIND_ORDER[b.kind] || a.pos - b.pos; });
      },
      selectedSteps: function () {
        var chosen = new Set(this.selected);
        return this.steps.filter(function (st) { return chosen.has(st.id); });
      },
      selectionSummary: function () {
        // صيغة «البند (العدد)» تتجنب اختلاف المعدود العربي بين المفرد والمثنى والجمع
        var counts = { extension: 0, seed: 0, index: 0, extra: 0 };
        this.selectedSteps.forEach(function (st) { counts[st.kind] += 1; });
        var n = this.number;
        var parts = [];
        if (counts.seed) parts.push('بيانات افتتاحية (' + n(counts.seed) + ')');
        if (counts.extension) parts.push('امتدادات (' + n(counts.extension) + ')');
        if (counts.index) parts.push('فهارس (' + n(counts.index) + ')');
        if (counts.extra) parts.push('حذف فهارس زائدة (' + n(counts.extra) + ')');
        return parts.join('، ');
      }
    },
    created: function () { this.load(); },
    methods: {
      number: function (value) { return numberFormat.format(value || 0); },
      digits: function (text) {
        return String(text || '').replace(/[0-9]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.charAt(+d); });
      },
      size: function (bytes) {
        var mb = (bytes || 0) / 1048576;
        if (mb >= 1024) return numberFormat.format(Math.round(mb / 102.4) / 10) + ' غ.ب';
        if (mb >= 1) return numberFormat.format(mb >= 10 ? Math.round(mb) : Math.round(mb * 10) / 10) + ' م.ب';
        return numberFormat.format(Math.max(1, Math.round((bytes || 0) / 1024))) + ' ك.ب';
      },
      seconds: function (ms) { return numberFormat.format(Math.round((ms || 0) / 100) / 10) + ' ث'; },
      stepId: function (kind, key) { return kind + ':' + key; },
      groupView: function (groups, items, field) {
        return (groups || []).map(function (g) {
          return { key: g.key, title: g.title, icon: g.icon,
                   items: items.filter(function (it) { return it[field] === g.key; }) };
        }).filter(function (g) { return g.items.length; });
      },
      seedNeedsAttention: function (s) {
        return s.state !== 'done' || (s.warnings && s.warnings.length);
      },
      isSelectable: function (kind, item) {
        if (!this.canApply) return false;
        if (kind === 'seed') return item.state === 'missing';
        if (kind === 'index') return item.state === 'missing' || item.state === 'invalid';
        if (kind === 'extension') return item.state === 'missing';
        return kind === 'extra';
      },
      selectable: function (kind) {
        if (!this.report) return [];
        var list = { seed: this.report.seeds, index: this.report.indexes,
                     extension: this.report.extensions, extra: this.report.extras }[kind] || [];
        var self = this;
        return list.filter(function (item) { return self.isSelectable(kind, item); });
      },
      selectAll: function (kind) {
        var ids = new Set(this.selected);
        var self = this;
        var kinds = kind === 'index' ? ['extension', 'index'] : [kind];
        kinds.forEach(function (k) {
          self.selectable(k).forEach(function (item) {
            ids.add(self.stepId(k, item.key || item.name));
          });
        });
        this.selected = Array.from(ids);
      },
      rowClass: function (kind, key) {
        var id = this.stepId(kind, key);
        return { 'is-selected': this.selected.indexOf(id) !== -1, 'is-working': !!this.pending[id] };
      },
      seedTone: function (s) {
        if (s.state === 'done') return s.warnings.length ? 'warn' : 'ok';
        if (s.state === 'missing') return 'warn';
        if (s.state === 'no_table') return 'danger';
        return 'muted';
      },
      seedLabel: function (s) {
        if (s.state === 'done') return s.warnings.length ? 'مكتمل مع تنبيه' : 'مكتمل';
        if (s.state === 'missing') return s.count ? 'ناقص ' + this.number(s.rows) : 'فارغ';
        if (s.state === 'no_table') return 'الجدول غير موجود';
        return 'من سطر الأوامر';
      },
      indexTone: function (x) {
        return { ok: 'ok', missing: 'warn', invalid: 'danger', blocked: 'danger',
                 no_column: 'danger', no_table: 'muted' }[x.state] || 'muted';
      },
      indexLabel: function (x) {
        if (x.state === 'ok') return x.via ? (x.how === 'covered' ? 'مغطى' : 'موجود باسم آخر') : 'موجود';
        return { missing: 'ناقص', invalid: 'معطوب', blocked: 'متعذر', no_column: 'عمود غير موجود',
                 no_table: 'الجدول غير موجود' }[x.state] || x.state;
      },
      extensionTone: function (e) { return { ok: 'ok', missing: 'warn' }[e.state] || 'danger'; },
      extensionLabel: function (e) { return { ok: 'مثبّت', missing: 'غير مثبّت' }[e.state] || 'غير متوفر في الخادم'; },
      stateIcon: function (state) {
        return { done: 'check-circle', skipped: 'minus-circle', failed: 'times-circle' }[state] || 'circle';
      },
      kindLabel: function (kind) { return KIND_LABEL[kind] || kind; },

      load: async function (keepResults) {
        if (this.loading) return;
        this.loading = true;
        this.error = '';
        try {
          var res = await Api.get(cfg.status);
          if (!Api.isOk(res)) { this.error = Api.getError(res); return; }
          var first = !this.report;
          this.report = Api.getData(res);
          this.canApply = this.report.can_apply;
          if (!keepResults) this.results = {};
          this.dropStaleSelection();
          if (first) this.openFirstIssue();
        } finally { this.loading = false; }
      },
      openFirstIssue: function () {
        var s = this.report.summary;
        if (!(s.seeds_missing || s.warnings)) {
          if (s.indexes_missing || s.indexes_blocked || s.extensions_missing) this.tab = 'indexes';
          else if (s.extras) this.tab = 'extras';
        }
        if (!this.seedIssues.length) this.filter.seeds = 'all';
        if (!this.indexIssues.length) this.filter.indexes = 'all';
      },
      dropStaleSelection: function () {
        // بعد إعادة الفحص يبقى من التحديد ما لا يزال قابلاً للتنفيذ فقط
        var valid = new Set();
        var self = this;
        ['seed', 'index', 'extension', 'extra'].forEach(function (k) {
          self.selectable(k).forEach(function (item) { valid.add(self.stepId(k, item.key || item.name)); });
        });
        this.selected = this.selected.filter(function (id) { return valid.has(id); });
      },

      confirmRun: function (steps) {
        var counts = { extension: 0, seed: 0, index: 0, extra: 0 };
        var big = 0;
        steps.forEach(function (st) { counts[st.kind] += 1; if (st.kind === 'index' && st.big) big += 1; });
        var n = this.number;
        var lines = [];
        if (counts.extension) lines.push('تثبيت امتدادات قاعدة البيانات: ' + n(counts.extension));
        if (counts.seed) lines.push('إضافة البيانات الافتتاحية للجداول الفارغة: ' + n(counts.seed));
        if (counts.index) {
          lines.push('بناء الفهارس: ' + n(counts.index) + (big
            ? '، منها على جداول كبيرة: ' + n(big) + ' (تُبنى دون إيقاف البيع وقد تستغرق دقائق)' : ''));
        }
        if (counts.extra) lines.push('حذف الفهارس الزائدة: ' + n(counts.extra));
        var list = document.createElement('ul');
        list.className = 'sr-confirm-list';
        lines.forEach(function (text) {
          var li = document.createElement('li');
          li.textContent = text;
          list.appendChild(li);
        });
        var note = document.createElement('p');
        note.className = 'sr-confirm-note';
        note.textContent = 'يُعاد التحقق من كل خطوة قبل تنفيذها، وتُتخطى إن تغيّرت حالتها منذ الفحص.';
        var box = document.createElement('div');
        box.appendChild(list);
        box.appendChild(note);
        return Swal.fire({
          title: 'تنفيذ الخطوات المحددة؟',
          html: box, icon: 'question', showCancelButton: true,
          confirmButtonText: 'نعم، نفّذ', cancelButtonText: 'رجوع',
          confirmButtonColor: '#12514c', focusCancel: true
        });
      },
      runSelected: async function () {
        if (this.busy || !this.canApply) return;
        var steps = this.selectedSteps.slice();
        if (!steps.length) return;
        var answer = await this.confirmRun(steps);
        if (!answer.isConfirmed) return;

        this.run = { total: steps.length, index: 0, current: '', stop: false, stopped: false,
                     finished: false, counts: { done: 0, skipped: 0, failed: 0 } };
        for (var i = 0; i < steps.length; i++) {
          if (this.run.stop) { this.run.stopped = true; break; }
          var st = steps[i];
          this.run.index = i + 1;
          this.run.current = st.label;
          this.$set(this.pending, st.id, true);
          var started = Date.now();
          var body = new FormData();
          body.append('kind', st.kind);
          body.append('key', st.key);
          var res = await Api.post(cfg.apply, body);
          var outcome = Api.isOk(res) ? Api.getData(res)
            : { state: 'failed', mess: Api.getError(res), checks: [], fatal: true };
          outcome.kind = st.kind;
          outcome.label = st.label;
          outcome.ms = Date.now() - started;
          outcome.time = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
          outcome.seq = ++seq;
          this.$delete(this.pending, st.id);
          this.$set(this.results, st.id, outcome);
          this.log.unshift(outcome);
          this.run.counts[outcome.state] = (this.run.counts[outcome.state] || 0) + 1;
          if (outcome.state !== 'failed') {
            this.selected = this.selected.filter(function (id) { return id !== st.id; });
          }
          // خطأ في الطلب نفسه (صلاحية، انتهاء الجلسة، اتصال) يصيب كل ما بعده: توقف
          if (outcome.fatal) { this.run.stopped = true; this.error = outcome.mess; break; }
        }
        this.run.finished = true;
        this.run.index = this.run.total;
        await this.load(true);
      }
    }
  });
})();
