# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_trial_api — ميزان المراجعة (Trial Balance) فقط.

استُخرج من reports_api.py في Phase 2.2 (2026-05-25).
يحتوي:
- trial_balance — يبني الميزان كاملاً مع rollup للحسابات الرئيسية
- _trial_balance_xlsx — تصدير xlsx
- _empty_tb_totals — قالب الإجماليات الصفرية
"""

from datetime import datetime

import acc_export


@auth.requires(can_view)
def trial_balance():
    """ميزان المراجعة — تقرير محاسبي يعرض الرصيد الافتتاحي وحركة الفترة
    والرصيد الختامي لكل حساب.

    عقد جديد (يحلّ محل القديم):
      branch     — id الفرع (مطلوب)
      period     — id الدورة (مطلوب)
      date_from  — YYYY-MM-DD (مطلوب)
      date_to    — YYYY-MM-DD (مطلوب)
      max_level  — أقصى مستوى عرض (0 = الكل، n = أرقام حسابات بطول ≤ n)
      hide_zero  — '1' لإخفاء الحسابات الصفرية

    الردّ:
      {err, period: {...}, branch: {...}, accounts: [...], totals: {...}, health: {...}}

    أداء: 3 استعلامات تجميعية + شجرة Python (بدل 260+ استعلام).
    صحة: يفلتر القيود المحذوفة (is_active=True) — إصلاح bug.
    """
    try:
        v = request.vars
        try:
            branch_id = int(v.get("branch") or v.get("branch_select") or 0)
            period_id = int(v.get("period") or 0)
        except Exception:
            return response.json({"err": 1, "mess": "قيمة فرع/دورة غير صحيحة"})
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})

        if period_id <= 0:
            sd_str = v.get("date_from")
            if sd_str:
                try:
                    sd = datetime.strptime(str(sd_str)[:10], "%Y-%m-%d").date()
                    per = db(
                        (db.account_periods.start_date <= sd)
                        & (db.account_periods.end_date >= sd)
                    ).select().first()
                    if per:
                        period_id = per.id
                except Exception:
                    pass
        if period_id <= 0:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة مالية"})
            period_id = per.id

        period = db.account_periods[period_id]
        if not period:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        branch = db.branches[branch_id]
        if not branch:
            return response.json({"err": 1, "mess": "الفرع غير موجود"})

        date_from = None
        date_to = None
        if v.get("date_from"):
            try:
                date_from = datetime.strptime(str(v.get("date_from"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if v.get("date_to"):
            try:
                date_to = datetime.strptime(str(v.get("date_to"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if not date_from:
            date_from = period.start_date
        if not date_to:
            date_to = period.end_date

        max_level = int(v.get("max_level") or 0)
        hide_zero = str(v.get("hide_zero") or "").lower() in ("1", "true", "yes")

        accs = db(
            (db.accounting_tree.branches == branch_id)
            & (db.accounting_tree.account_periods == period_id)
        ).select(orderby=db.accounting_tree.account_no)
        if not accs:
            return response.json({
                "err": 0,
                "period": {"id": period.id, "disc": period.disc,
                           "open_period": int(period.open_period or 0)},
                "branch": {"id": branch.id, "name": branch.name},
                "date_from": str(date_from), "date_to": str(date_to),
                "accounts": [], "totals": _empty_tb_totals(),
                "health": {"balanced_open": True, "balanced_movement": True, "balanced_close": True},
            })

        open_rows = db.executesql(
            "SELECT account_no, COALESCE(SUM(debit),0)::float as d, "
            "       COALESCE(SUM(credit),0)::float as c "
            "FROM account_periods_opening "
            "WHERE branches = %s AND account_periods = %s "
            "GROUP BY account_no",
            placeholders=[branch_id, period_id],
            as_dict=True,
        )
        open_map = {r["account_no"]: (r["d"] or 0, r["c"] or 0) for r in open_rows}

        pre_rows = db.executesql(
            "SELECT jed.account_no, COALESCE(SUM(jed.debit),0)::float as d, "
            "       COALESCE(SUM(jed.credit),0)::float as c "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            "WHERE jem.is_active = 'T'"
            "  AND jed.branches = %s "
            "  AND jed.account_periods = %s "
            "  AND jed.journal_date < %s "
            "GROUP BY jed.account_no",
            placeholders=[branch_id, period_id, str(date_from)],
            as_dict=True,
        )
        pre_map = {r["account_no"]: (r["d"] or 0, r["c"] or 0) for r in pre_rows}

        mov_rows = db.executesql(
            "SELECT jed.account_no, COALESCE(SUM(jed.debit),0)::float as d, "
            "       COALESCE(SUM(jed.credit),0)::float as c "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            "WHERE jem.is_active = 'T'"
            "  AND jed.branches = %s "
            "  AND jed.account_periods = %s "
            "  AND jed.journal_date >= %s "
            "  AND jed.journal_date <= %s "
            "GROUP BY jed.account_no",
            placeholders=[branch_id, period_id, str(date_from), str(date_to)],
            as_dict=True,
        )
        mov_map = {r["account_no"]: (r["d"] or 0, r["c"] or 0) for r in mov_rows}

        children_count = {}
        for a in accs:
            mp = a.main_account or "0"
            if mp != "0":
                children_count[mp] = children_count.get(mp, 0) + 1

        nodes = {}
        for a in accs:
            no = a.account_no
            od, oc = open_map.get(no, (0.0, 0.0))
            pd_, pc = pre_map.get(no, (0.0, 0.0))
            md, mc = mov_map.get(no, (0.0, 0.0))
            nodes[no] = {
                "id": int(a.id),
                "account_no": no,
                "account_name": a.account_name_ar or "",
                "main_account": a.main_account or "0",
                "account_type": int(a.account_type or 0),
                "final_account": int(a.final_account or 0),
                "_own_open_debit": float(od or 0),
                "_own_open_credit": float(oc or 0),
                "_own_pre_debit": float(pd_ or 0),
                "_own_pre_credit": float(pc or 0),
                "_own_mov_debit": float(md or 0),
                "_own_mov_credit": float(mc or 0),
                "is_leaf": children_count.get(no, 0) == 0,
                "level": len(no),
            }

        def _rollup():
            for n in nodes.values():
                n["open_debit"] = n["_own_open_debit"] + n["_own_pre_debit"]
                n["open_credit"] = n["_own_open_credit"] + n["_own_pre_credit"]
                n["mov_debit"] = n["_own_mov_debit"]
                n["mov_credit"] = n["_own_mov_credit"]
            for no in sorted(nodes.keys(), key=lambda x: -len(x)):
                node = nodes[no]
                if node["is_leaf"]:
                    continue
                for child_no, child in nodes.items():
                    if child["main_account"] == no:
                        node["open_debit"] += child["open_debit"]
                        node["open_credit"] += child["open_credit"]
                        node["mov_debit"] += child["mov_debit"]
                        node["mov_credit"] += child["mov_credit"]
        _rollup()

        for n in nodes.values():
            od, oc = n["open_debit"], n["open_credit"]
            if od > oc:
                n["open_debit_net"] = round(od - oc, 2)
                n["open_credit_net"] = 0.0
            else:
                n["open_debit_net"] = 0.0
                n["open_credit_net"] = round(oc - od, 2)
            md, mc = n["mov_debit"], n["mov_credit"]
            n["mov_debit"] = round(md, 2)
            n["mov_credit"] = round(mc, 2)
            net = (n["open_debit_net"] - n["open_credit_net"]) + (md - mc)
            if net > 0:
                n["close_debit_net"] = round(net, 2)
                n["close_credit_net"] = 0.0
            else:
                n["close_debit_net"] = 0.0
                n["close_credit_net"] = round(-net, 2)
            n.pop("_own_open_debit", None); n.pop("_own_open_credit", None)
            n.pop("_own_pre_debit", None); n.pop("_own_pre_credit", None)
            n.pop("_own_mov_debit", None); n.pop("_own_mov_credit", None)
            n.pop("open_debit", None); n.pop("open_credit", None)

        out = sorted(nodes.values(), key=lambda x: x["account_no"])
        if max_level > 0:
            out = [n for n in out if n["level"] <= max_level]
        if hide_zero:
            out = [n for n in out if not (
                n["open_debit_net"] == 0 and n["open_credit_net"] == 0
                and n["mov_debit"] == 0 and n["mov_credit"] == 0
                and n["close_debit_net"] == 0 and n["close_credit_net"] == 0
            )]

        totals = _empty_tb_totals()
        for n in out:
            if n["is_leaf"]:
                totals["open_debit"] += n["open_debit_net"]
                totals["open_credit"] += n["open_credit_net"]
                totals["mov_debit"] += n["mov_debit"]
                totals["mov_credit"] += n["mov_credit"]
                totals["close_debit"] += n["close_debit_net"]
                totals["close_credit"] += n["close_credit_net"]
        for k in totals:
            totals[k] = round(totals[k], 2)
        totals["open_diff"] = round(totals["open_debit"] - totals["open_credit"], 2)
        totals["mov_diff"] = round(totals["mov_debit"] - totals["mov_credit"], 2)
        totals["close_diff"] = round(totals["close_debit"] - totals["close_credit"], 2)
        totals["account_count"] = len(out)

        result = {
            "err": 0,
            "period": {
                "id": period.id, "disc": period.disc,
                "open_period": int(period.open_period or 0),
                "start_date": str(period.start_date), "end_date": str(period.end_date),
            },
            "branch": {"id": branch.id, "name": branch.name},
            "date_from": str(date_from), "date_to": str(date_to),
            "accounts": out,
            "totals": totals,
            "health": {
                "balanced_open": abs(totals["open_diff"]) < 0.005,
                "balanced_movement": abs(totals["mov_diff"]) < 0.005,
                "balanced_close": abs(totals["close_diff"]) < 0.005,
            },
        }

        if str(v.get("format") or "").lower() == "xlsx":
            return _trial_balance_xlsx(result)

        return response.json(result)
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


def _trial_balance_xlsx(data):
    """يحوّل ردّ trial_balance إلى ملف xlsx جاهز للتنزيل."""
    columns = [
        {"key": "account_no", "title": "رقم الحساب", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 32},
        {"key": "open_debit_net", "title": "افتتاحي مدين", "format": "currency"},
        {"key": "open_credit_net", "title": "افتتاحي دائن", "format": "currency"},
        {"key": "mov_debit", "title": "حركة مدين", "format": "currency"},
        {"key": "mov_credit", "title": "حركة دائن", "format": "currency"},
        {"key": "close_debit_net", "title": "ختامي مدين", "format": "currency"},
        {"key": "close_credit_net", "title": "ختامي دائن", "format": "currency"},
    ]
    totals = data["totals"]
    totals_row = {
        "account_no": "—",
        "account_name": "الإجمالي (من الحسابات النهائية)",
        "open_debit_net": totals.get("open_debit"),
        "open_credit_net": totals.get("open_credit"),
        "mov_debit": totals.get("mov_debit"),
        "mov_credit": totals.get("mov_credit"),
        "close_debit_net": totals.get("close_debit"),
        "close_credit_net": totals.get("close_credit"),
    }
    meta = [
        ("الفرع", data["branch"]["name"]),
        ("الدورة", data["period"]["disc"]),
        ("من تاريخ", data["date_from"]),
        ("إلى تاريخ", data["date_to"]),
        ("عدد الحسابات", totals.get("account_count", 0)),
    ]
    fname = "trial_balance_%s_%s.xlsx" % (data["branch"]["name"], data["date_to"])
    return acc_export.xlsx_response(
        response, fname,
        title="ميزان المراجعة",
        meta=meta,
        columns=columns,
        rows=data["accounts"],
        totals=totals_row,
        sheet_name="ميزان المراجعة",
    )


def _empty_tb_totals():
    return {
        "open_debit": 0.0, "open_credit": 0.0,
        "mov_debit": 0.0, "mov_credit": 0.0,
        "close_debit": 0.0, "close_credit": 0.0,
    }
