# -*- coding: utf-8 -*-
"""Pure helpers for SMS password reset OTPs."""

import hashlib
import hmac
import secrets


def generate_otp(length=6):
    if length < 6:
        raise ValueError("OTP length must be at least 6")
    upper = 10 ** length
    return ("%0" + str(length) + "d") % secrets.randbelow(upper)


def hash_otp(code, salt):
    payload = ("%s:%s" % (salt, code)).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def verify_otp(code, salt, expected_hash):
    if not code or not salt or not expected_hash:
        return False
    return hmac.compare_digest(hash_otp(code, salt), expected_hash)


def valid_password(password, minimum=4):
    pw = password or ""
    if len(pw) < minimum:
        return False, "كلمة المرور يجب أن تكون %d أحرف على الأقل" % minimum
    if pw.strip() != pw:
        return False, "كلمة المرور لا يجب أن تبدأ أو تنتهي بفراغ"
    return True, ""
