// ======================  رصيد حساب موزَّع على الفروع — منطق Vue 3  ======================
// حساب واحد مختار → بطاقة لكل فرع تُظهر افتتاحي + حركة + ختامي.

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_branches_api/',
            settingApi: window.purl + '/../../setting_api/',
            opsApi: window.purl + '/../../operations_api/',

            branches: [],
            periods: [],
            accounts: [],
            selectedAccount: null,
            sourceBranch: 0,
            hideInactive: false,

            filters: {
                period: 0,
                date_from: '',
                date_to: '',
            },

            data: null,
            loading: false,
            _loadSeq: 0,
            _accountT: null,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        canQuery() {
            return this.sourceBranch > 0
                && this.filters.period > 0
                && this.selectedAccount
                && this.selectedAccount.id > 0;
        },
        visibleBranches() {
            if (!this.data) return [];
            if (!this.hideInactive) return this.data.branches;
            return this.data.branches.filter(b => b.has_activity);
        },
        activeBranchesCount() {
            if (!this.data) return 0;
            return this.data.branches.filter(b => b.has_activity).length;
        },
    },

    watch: {
        selectedAccount(newVal) {
            var self = this;
            if (this._accountT) clearTimeout(this._accountT);
            this._accountT = setTimeout(() => {
                if (newVal && newVal.id > 0 && self.filters.period > 0) {
                    self.reload();
                } else {
                    self.data = null;
                }
            }, 200);
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.sourceBranch = main.id;
                else if (self.branches.length === 1) self.sourceBranch = self.branches[0].id;
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                if (self.sourceBranch > 0 && self.filters.period > 0) {
                    self.loadAccounts();
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        loadAccounts() {
            var self = this;
            this.accounts = [];
            this.selectedAccount = null;
            axios.get(this.opsApi + 'get_accounts_for_journal/' + this.sourceBranch + '/' + this.filters.period)
                .then(res => {
                    var rows = (res.data && res.data.accounts) || res.data || [];
                    self.accounts = (Array.isArray(rows) ? rows : []).map(a => ({
                        id: a.id,
                        account_no: a.account_no,
                        name: a.account_name_ar || a.account_name || '',
                        parent_name: a.parent_name || '',
                        label: a.account_no + ' — ' + (a.account_name_ar || a.account_name || ''),
                    }));
                }).catch(() => {
                    Swal.fire({ icon: 'warning', title: 'تعذّر تحميل قائمة الحسابات' });
                });
        },

        onSourceBranchChange() {
            this.data = null;
            if (this.sourceBranch > 0 && this.filters.period > 0) this.loadAccounts();
        },

        onPeriodChange() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                if (p.start_date) this.filters.date_from = p.start_date;
                if (p.end_date) this.filters.date_to = p.end_date;
            }
            this.data = null;
            if (this.sourceBranch > 0 && this.filters.period > 0) this.loadAccounts();
        },

        onFilterChange() { if (this.canQuery) this.reload(); },

        resetToFullPeriod() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                this.filters.date_from = p.start_date || '';
                this.filters.date_to = p.end_date || '';
                this.reload();
            }
        },

        reload() {
            if (!this.canQuery) return;
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            var body = {
                period: this.filters.period,
                account_id: this.selectedAccount.id,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || '',
            };
            axios.post(this.api + 'single_account_branches/', body).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: d.mess || 'تعذّر تحميل التقرير' });
                    self.data = null;
                } else {
                    self.data = d;
                }
            }).catch(err => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'خطأ في الاتصال', text: (err && err.message) || '' });
                self.data = null;
            }).finally(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        fmtCell(n) {
            var v = Number(n) || 0;
            if (v === 0) return '—';
            return fmtNumber(v);
        },

        valClass(n, hint) {
            var v = Number(n) || 0;
            if (v === 0) return 'is-zero';
            if (hint === 'debit') return 'is-debit';
            if (hint === 'credit') return 'is-credit';
            return '';
        },

        fmtNet(n) {
            var v = Number(n) || 0;
            if (v === 0) return '0.00';
            if (v > 0) return fmtNumber(v) + ' (مدين)';
            return fmtNumber(-v) + ' (دائن)';
        },

        netClass(n) {
            var v = Number(n) || 0;
            if (v > 0) return 'is-debit';
            if (v < 0) return 'is-credit';
            return 'is-zero';
        },

        printReport() { window.print(); },

        exportCSV() {
            if (!this.data) return;
            var rows = [[
                'الفرع', 'هل رئيسي', 'افتتاحي مدين', 'افتتاحي دائن',
                'حركة مدين', 'حركة دائن', 'ختامي مدين', 'ختامي دائن', 'صافي ختامي'
            ]];
            this.data.branches.forEach(b => {
                rows.push([
                    b.branch_name, b.is_main ? 'نعم' : 'لا',
                    fmtNumber(b.open_debit), fmtNumber(b.open_credit),
                    fmtNumber(b.mov_debit), fmtNumber(b.mov_credit),
                    fmtNumber(b.close_debit), fmtNumber(b.close_credit),
                    fmtNumber(b.closing_net),
                ]);
            });
            var g = this.data.grand;
            rows.push([
                'الإجمالي عبر الفروع', '',
                fmtNumber(g.open_debit), fmtNumber(g.open_credit),
                fmtNumber(g.mov_debit), fmtNumber(g.mov_credit),
                fmtNumber(g.close_debit), fmtNumber(g.close_credit),
                fmtNumber(g.closing_net),
            ]);

            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            var slug = this.data.account.account_no.replace(/\W+/g, '_');
            a.download = 'account_' + slug + '_by_branches_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
