# -*- coding: utf-8 -*-
#  type: ignore

from datetime import date, datetime

# طبقة الخدمة المشتركة في modules/ — استُخرِجت في Phase 2 (2026-05-24)
import acc_dates
import acc_periods
import acc_validation

# المرجع التاريخي: هذه الـ aliases تحافظ على توافق call sites القديمة
_validate_journal = lambda row_detail, account_periods, branch_id=None: \
    acc_validation.validate_journal(db, row_detail, account_periods, branch_id)
_period_is_open = lambda period_id: acc_periods.is_open(db, period_id)


@auth.requires(can_enter)
def save_journal():
    try:
        row = request.vars
        row_detail = row["detail"]
        row_master = row["master"]
        account_periods = get_account_periods(row_master["journal_date"])
        chk = _validate_journal(row_detail, account_periods)
        if chk:
            return response.json({"err": 2, "id": 0, "mess": chk})
        total_debit = round(sum(float(r.get("debit") or 0) for r in row_detail), 2)
        total_credit = round(sum(float(r.get("credit") or 0) for r in row_detail), 2)
        master_id = db.journal_entry_master.insert(
            account_periods=account_periods,
            journal_date=row_master["journal_date"],
            branches=row_master["branches"],
            debit_total=total_debit,
            credit_total=total_credit,
            journal_detail=row_master["journal_detail"],
            journal_operations=len(row_detail),
            journal_save=row_master["journal_save"],
        )
        for rows in row_detail:
            detail_id = db.journal_entry_detail.insert(
                journal_entry_master=master_id,
                account_periods=account_periods,
                journal_date=row_master["journal_date"],
                branches=row_master["branches"],
                debit=rows["debit"],
                credit=rows["credit"],
                detail=rows["detail"],
                accounting_tree=rows["accounting_tree"],
                account_no=rows["account"],
                cost_center=rows["cost_center"],
            )
        db.commit()
        ret = {"err": 0, "id": master_id, "mess": "0"}
        return response.json(ret)
    except Exception as e:
        db.rollback()
        print(e)
        ret = {"err": 3, "id": 0, "mess": str(e)}
        return response.json(ret)


# ================= edit journal ================================
def _user_name(uid):
    """يُرجع اسم المستخدم (للأودِت) — أو فارغ."""
    if not uid:
        return ""
    try:
        u = db.auth_user[int(uid)]
        if u:
            return ((u.first_name or "") + " " + (u.last_name or "")).strip() or u.email
    except Exception:
        pass
    return ""


# استُخرج إلى modules/acc_dates.py
_normalize_journal_date = acc_dates.normalize_journal_date


@auth.requires(can_account)
def get_journal_entry_edit():
    """يُرجع payload نظيف لشاشة تعديل القيد:
      - master: id, branches, branch_name, period, period_disc, period_open,
                journal_date, journal_save, journal_detail, is_active,
                audit: {created_by, created_on, modified_by, modified_on}
      - details: [{id, accounting_tree, account: {id, account_no, name,
                   parent_name, account_type, final_account, label},
                   debit, credit, detail, cost_center}]
    """
    try:
        jid = request.args(0)
        if not jid:
            return response.json({"err": 1, "mess": "رقم القيد مطلوب"})
        master = db.journal_entry_master[jid]
        if not master:
            return response.json({"err": 1, "mess": "القيد غير موجود"})
        if not master.is_active:
            return response.json({"err": 1, "mess": "القيد محذوف — لا يمكن تعديله"})

        # معلومات الفرع والدورة
        branch = db.branches[master.branches] if master.branches else None
        period = db.account_periods[master.account_periods] if master.account_periods else None

        # السطور
        details = db(
            db.journal_entry_detail.journal_entry_master == master.id
        ).select(orderby=db.journal_entry_detail.id)
        out_details = []
        for r in details:
            acc = db.accounting_tree[r.accounting_tree] if r.accounting_tree else None
            if acc:
                parent_name = ""
                if acc.main_account and acc.main_account != "0":
                    pr = db(
                        (db.accounting_tree.account_no == acc.main_account)
                        & (db.accounting_tree.branches == acc.branches)
                        & (db.accounting_tree.account_periods == acc.account_periods)
                    ).select().first()
                    if pr:
                        parent_name = pr.account_name_ar or ""
                label = (acc.account_no or "") + " — " + (acc.account_name_ar or "")
                if parent_name:
                    label += "  ‹ " + parent_name
                account = {
                    "id": int(acc.id),
                    "account_no": acc.account_no,
                    "name": acc.account_name_ar or "",
                    "parent_name": parent_name,
                    "account_type": int(acc.account_type or 0),
                    "final_account": int(acc.final_account or 0),
                    "label": label,
                }
            else:
                # حساب محذوف — نُبقي السطر لكن نشير لذلك (يحدث لو حُذف حساب
                # من الشجرة بعد إنشاء القيد — وهو ممنوع، لكن للسلامة)
                account = None
            out_details.append({
                "id": int(r.id),
                "accounting_tree": int(r.accounting_tree or 0),
                "account": account,
                "account_no": r.account_no,
                "debit": float(r.debit or 0),
                "credit": float(r.credit or 0),
                "detail": r.detail or "",
                "cost_center": int(r.cost_center or 0),
            })

        return response.json({
            "err": 0,
            "master": {
                "id": int(master.id),
                "branches": int(master.branches or 0),
                "branch_name": branch.name if branch else "—",
                "account_periods": int(master.account_periods or 0),
                "period_disc": period.disc if period else "—",
                "period_open": int(period.open_period or 0) if period else 0,
                "period_start": str(period.start_date) if period and period.start_date else None,
                "period_end": str(period.end_date) if period and period.end_date else None,
                "journal_date": str(master.journal_date) if master.journal_date else None,
                "journal_save": master.journal_save or "",
                "journal_detail": master.journal_detail or "",
                "journal_operations": int(master.journal_operations or 0),
                "debit_total": float(master.debit_total or 0),
                "credit_total": float(master.credit_total or 0),
                "is_active": bool(master.is_active),
                "audit": {
                    "created_by": _user_name(master.created_by) if hasattr(master, "created_by") else "",
                    "created_on": str(master.created_on) if hasattr(master, "created_on") and master.created_on else "",
                    "modified_by": _user_name(master.modified_by) if hasattr(master, "modified_by") else "",
                    "modified_on": str(master.modified_on) if hasattr(master, "modified_on") and master.modified_on else "",
                },
            },
            "details": out_details,
        })
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_account)
def update_journal():
    """تعديل قيد قائم — admin/account فقط (لا user). يقبل journal_date كنص YYYY-MM-DD أو dict.
    يفحص: القيد موجود، الدورة الحالية مفتوحة، الدورة الجديدة مفتوحة، التوازن،
    صحة كل سطر (الحسابات من نفس الفرع، إلخ)."""
    try:
        row = request.vars
        row_detail = row.get("detail") or []
        row_master = row.get("master") or {}
        if not row_master.get("id"):
            return response.json({"err": 1, "id": 0, "mess": "رقم القيد مطلوب"})
        master = db.journal_entry_master[row_master["id"]]
        if not master:
            return response.json({"err": 1, "id": 0, "mess": "القيد غير موجود"})
        if not master.is_active:
            return response.json({"err": 1, "id": 0, "mess": "القيد محذوف"})
        # حماية: لا يمكن تعديل قيد في دورة مقفلة (نفحص الدورة الحالية أولاً)
        if not _period_is_open(master.account_periods):
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن تعديل قيد في دورة مالية مقفلة"
            })
        # حماية: الفرع لا يقابل التغيير (يتطلب إعادة التحقق من كل الحسابات)
        new_branch = int(row_master.get("branches") or 0)
        if new_branch and new_branch != int(master.branches):
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يُسمح بتغيير فرع القيد بعد إنشائه"
            })
        # تاريخ القيد
        journal_date = _normalize_journal_date(row_master.get("journal_date"))
        if not journal_date:
            return response.json({"err": 1, "id": 0, "mess": "صيغة التاريخ غير صحيحة"})
        account_periods = get_account_periods(journal_date)
        if not account_periods:
            return response.json({
                "err": 2, "id": 0,
                "mess": "التاريخ %s خارج الدورات المفتوحة" % journal_date
            })
        # التحقق الكامل عبر _validate_journal (يفحص الحسابات والمبالغ ومركز التكلفة)
        chk = _validate_journal(row_detail, account_periods, branch_id=master.branches)
        if chk:
            return response.json({"err": 2, "id": 0, "mess": chk})
        total_debit = round(sum(float(r.get("debit") or 0) for r in row_detail), 2)
        total_credit = round(sum(float(r.get("credit") or 0) for r in row_detail), 2)
        # حفظ
        db(db.journal_entry_detail.journal_entry_master == master.id).delete()
        for rd in row_detail:
            db.journal_entry_detail.insert(
                journal_entry_master=master.id,
                account_periods=account_periods,
                journal_date=journal_date,
                branches=master.branches,
                debit=rd.get("debit") or 0,
                credit=rd.get("credit") or 0,
                detail=(rd.get("detail") or "").strip(),
                accounting_tree=rd.get("accounting_tree"),
                account_no=rd.get("account"),
                cost_center=int(rd.get("cost_center") or 0) or None,
            )
        master.update_record(
            account_periods=account_periods,
            journal_date=journal_date,
            debit_total=total_debit,
            credit_total=total_credit,
            journal_detail=(row_master.get("journal_detail") or "").strip(),
            journal_operations=len(row_detail),
            journal_save=(row_master.get("journal_save") or "").strip(),
        )
        db.commit()
        return response.json({"err": 0, "id": int(master.id), "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


# =====================================
# ==================================>   functions
@auth.requires(can_enter)
def get_account_periods(str_date):
    qry_date = datetime.strptime(str_date, "%Y-%m-%d").date()
    qry = db(db.account_periods.open_period == 1).select(db.account_periods.ALL)
    ret_id = 0
    for row in qry:
        start_date = row.start_date
        end_date = row.end_date
        if start_date <= qry_date <= end_date:
            ret_id = row.id
            break
        else:
            ret_id = 0
    return ret_id


# جديد: يحمّل كل ما تحتاجه شاشة القيد دفعةً واحدة لتقليل round-trips:
#   - الفروع المتاحة
#   - مراكز التكلفة المتاحة
#   - الدورة المالية المفتوحة الافتراضية + تاريخ اليوم إن وقع فيها
#   - تواريخ بداية/نهاية الدورة (للحقل date min/max)
@auth.requires(can_enter)
def get_journal_bootstrap():
    try:
        from datetime import date as _date
        # فروع
        branches = []
        for b in db(db.branches.show_row == 1).select(orderby=db.branches.id):
            branches.append({
                "id": b.id,
                "name": b.name,
                "code": b.code,
                "is_main": int(b.is_main or 2),
            })
        # مراكز التكلفة
        cost_centers = []
        for c in db(db.key_cost_center.show_cost == 1).select(
            orderby=db.key_cost_center.name
        ):
            cost_centers.append({"id": c.id, "name": c.name})
        # كل الدورات المفتوحة + اليوم
        today = _date.today()
        open_periods = []
        today_period = None
        for p in db(db.account_periods.open_period == 1).select(
            orderby=db.account_periods.id
        ):
            d = {
                "id": p.id, "disc": p.disc,
                "start_date": str(p.start_date) if p.start_date else None,
                "end_date": str(p.end_date) if p.end_date else None,
            }
            open_periods.append(d)
            if p.start_date <= today <= p.end_date and not today_period:
                today_period = d
        return response.json({
            "err": 0,
            "branches": branches,
            "cost_centers": cost_centers,
            "open_periods": open_periods,
            "today_period": today_period,
            "today": str(today),
        })
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})


# ============================================================================
# =====================  قائمة قيود اليومية (Journals List)  =================
# ============================================================================
# تُستخدم في شاشة operations/index2 لعرض القيود المسجَّلة مع فلترة شاملة.

# استُبدلت بـ acc_dates.parse_iso (modules/) — alias للتوافق
_parse_iso_date_safe = acc_dates.parse_iso


@auth.requires(can_enter)
def list_journals():
    """إرجاع قائمة قيود مرشّحة مع pagination.
    Query params:
      branch     — id الفرع (0 = الكل)
      period     — id الدورة (0 = الكل)
      date_from  — YYYY-MM-DD
      date_to    — YYYY-MM-DD
      q          — نص بحث (في البيان أو رقم القيد أو رقم الحفظ)
      include_deleted — 1 لعرض الناعمة المحذوفة (admin فقط)
      page       — رقم الصفحة (1-based)
      per_page   — حجم الصفحة (افتراضي 25، حد أقصى 200)
    """
    try:
        v = request.vars
        branch = int(v.get("branch") or 0)
        period = int(v.get("period") or 0)
        date_from = _parse_iso_date_safe(v.get("date_from"))
        date_to = _parse_iso_date_safe(v.get("date_to"))
        q_text = (v.get("q") or "").strip()
        include_deleted = str(v.get("include_deleted") or "").lower() in ("1", "true", "yes")
        if include_deleted and not auth.has_membership("admin"):
            include_deleted = False
        page = max(1, int(v.get("page") or 1))
        per_page = max(1, min(200, int(v.get("per_page") or 25)))

        m = db.journal_entry_master
        cond = m.id > 0
        if not include_deleted:
            cond &= (m.is_active == True)
        if branch > 0:
            cond &= (m.branches == branch)
        if period > 0:
            cond &= (m.account_periods == period)
        if date_from:
            cond &= (m.journal_date >= date_from)
        if date_to:
            cond &= (m.journal_date <= date_to)
        if q_text:
            # بحث متعدد: رقم القيد رقمياً، أو نص في البيان/رقم الحفظ
            try:
                qid = int(q_text)
                cond &= ((m.id == qid)
                         | m.journal_detail.contains(q_text)
                         | m.journal_save.contains(q_text))
            except Exception:
                cond &= (m.journal_detail.contains(q_text)
                         | m.journal_save.contains(q_text))

        total = db(cond).count()
        rows = db(cond).select(
            m.ALL, orderby=~m.journal_date | ~m.id,
            limitby=((page - 1) * per_page, page * per_page),
        )
        # إثراء: اسم الفرع، اسم الدورة
        bids = list({r.branches for r in rows if r.branches})
        pids = list({r.account_periods for r in rows if r.account_periods})
        bmap = {}
        pmap = {}
        if bids:
            for b in db(db.branches.id.belongs(bids)).select(db.branches.id, db.branches.name):
                bmap[b.id] = b.name
        if pids:
            for p in db(db.account_periods.id.belongs(pids)).select(
                db.account_periods.id, db.account_periods.disc, db.account_periods.open_period
            ):
                pmap[p.id] = {"disc": p.disc, "open_period": int(p.open_period or 0)}
        items = []
        for r in rows:
            items.append({
                "id": r.id,
                "journal_date": str(r.journal_date) if r.journal_date else None,
                "branch_id": r.branches,
                "branch_name": bmap.get(r.branches, "—"),
                "period_id": r.account_periods,
                "period_disc": (pmap.get(r.account_periods) or {}).get("disc", "—"),
                "period_open": (pmap.get(r.account_periods) or {}).get("open_period", 0),
                "journal_detail": r.journal_detail or "",
                "journal_save": r.journal_save or "",
                "journal_operations": int(r.journal_operations or 0),
                "debit_total": float(r.debit_total or 0),
                "credit_total": float(r.credit_total or 0),
                "is_active": bool(r.is_active),
                "balanced": abs(float(r.debit_total or 0) - float(r.credit_total or 0)) < 0.005,
            })
        return response.json({
            "err": 0,
            "items": items,
            "total": int(total),
            "page": page,
            "per_page": per_page,
            "pages": (int(total) + per_page - 1) // per_page if total else 1,
        })
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_enter)
def list_journals_stats():
    """إحصائيات لنفس الفلتر — مدين/دائن إجمالي + عدد القيود.
    تستخدم نفس البارامترات (بدون pagination)."""
    try:
        v = request.vars
        branch = int(v.get("branch") or 0)
        period = int(v.get("period") or 0)
        date_from = _parse_iso_date_safe(v.get("date_from"))
        date_to = _parse_iso_date_safe(v.get("date_to"))
        q_text = (v.get("q") or "").strip()
        include_deleted = str(v.get("include_deleted") or "").lower() in ("1", "true", "yes")
        if include_deleted and not auth.has_membership("admin"):
            include_deleted = False

        m = db.journal_entry_master
        cond = m.id > 0
        if not include_deleted:
            cond &= (m.is_active == True)
        if branch > 0:
            cond &= (m.branches == branch)
        if period > 0:
            cond &= (m.account_periods == period)
        if date_from:
            cond &= (m.journal_date >= date_from)
        if date_to:
            cond &= (m.journal_date <= date_to)
        if q_text:
            try:
                qid = int(q_text)
                cond &= ((m.id == qid)
                         | m.journal_detail.contains(q_text)
                         | m.journal_save.contains(q_text))
            except Exception:
                cond &= (m.journal_detail.contains(q_text)
                         | m.journal_save.contains(q_text))

        agg = db(cond).select(
            m.id.count(), m.debit_total.sum(), m.credit_total.sum()
        ).first()
        n = int(agg[m.id.count()] or 0)
        d = float(agg[m.debit_total.sum()] or 0)
        c = float(agg[m.credit_total.sum()] or 0)
        return response.json({
            "err": 0,
            "count": n,
            "debit": round(d, 2),
            "credit": round(c, 2),
            "diff": round(d - c, 2),
            "balanced": abs(d - c) < 0.005,
        })
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_account)
def soft_delete_journal():
    """حذف ناعم لقيد — admin/account فقط. يبقى الرأس كسجل تدقيق وتُحذف سطوره.
    ممنوع للدورات المقفلة."""
    try:
        jid = request.vars.get("id")
        mas = db.journal_entry_master[jid] if jid else None
        if not mas:
            return response.json({"err": 1, "mess": "القيد غير موجود"})
        per = db.account_periods[mas.account_periods] if mas.account_periods else None
        if not per or int(per.open_period or 0) != 1:
            return response.json({"err": 2, "mess": "لا يمكن حذف قيد في دورة مالية مقفلة"})
        if not mas.is_active:
            return response.json({"err": 1, "mess": "القيد محذوف مسبقاً"})
        db(db.journal_entry_detail.journal_entry_master == mas.id).delete()
        mas.update_record(is_active=False)
        db.commit()
        return response.json({"err": 0, "id": int(mas.id), "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# جديد: شجرة حسابات الفرع للورقية فقط (يحدّد الدورة بالتاريخ)
#   - يعيد كل حساب مع رقم الأب واسم الأب وطبيعة الحساب
@auth.requires(can_enter)
def get_accounts_for_journal():
    """/get_accounts_for_journal/<branch>/[<period>]
    إن لم تُمرّر الدورة تُختار أول دورة مفتوحة."""
    try:
        branch_id = int(request.args(0) or 0)
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})
        per_id = request.args(1)
        if per_id:
            per_id = int(per_id)
        else:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة مفتوحة"})
            per_id = per.id
        rows = db.executesql(
            "SELECT at.id, at.account_no, at.account_name_ar, "
            "       at.main_account, at.account_type, at.final_account, "
            "       (SELECT account_name_ar FROM accounting_tree p "
            "          WHERE p.branches = at.branches "
            "            AND p.account_periods = at.account_periods "
            "            AND p.account_no = at.main_account LIMIT 1) AS parent_name "
            "FROM accounting_tree at "
            "WHERE at.branches = %s AND at.account_periods = %s "
            "  AND at.show_account = 1 "
            "  AND at.account_no NOT IN ( "
            "    SELECT main_account FROM accounting_tree "
            "    WHERE branches = %s AND account_periods = %s "
            "      AND main_account IS NOT NULL ) "
            "ORDER BY at.account_no",
            placeholders=[branch_id, per_id, branch_id, per_id],
            as_dict=True,
        )
        out = []
        for r in rows:
            label = r["account_no"] + " — " + (r["account_name_ar"] or "")
            if r.get("parent_name"):
                label += "  ‹ " + r["parent_name"]
            out.append({
                "id": int(r["id"]),
                "account_no": r["account_no"],
                "name": r["account_name_ar"] or "",
                "parent_name": r.get("parent_name") or "",
                "account_type": int(r["account_type"] or 0),
                "final_account": int(r["final_account"] or 0),
                "label": label,
            })
        return response.json({"err": 0, "accounts": out, "period_id": per_id})
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})
