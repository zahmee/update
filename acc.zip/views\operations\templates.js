// ======================  قوالب القيود — منطق Vue 3  ======================
// شاشة إدارة قوالب القيود المتكرّرة (Phase 3.6 — 2026-05-25).

function blankLine() {
    return {
        accounting_tree: null,
        debit: 0,
        credit: 0,
        detail: '',
        cost_center: null,
    };
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            tplApi: window.purl + '/../../templates_api/',
            settingApi: window.purl + '/../../setting_api/',
            opsApi: window.purl + '/../../operations_api/',

            templates: [],
            loading: false,
            saving: false,

            // قائمة الحسابات + سياقها (الفرع/الفترة المختارَين)
            branches: [],
            periods: [],
            ctxBranch: 0,
            ctxPeriod: 0,
            accounts: [],
            loadingAccounts: false,

            showModal: false,
            editing: { id: null, name: '', description: '', lines: [] },
        };
    },
    computed: {
        totalD() {
            return Math.round(this.editing.lines.reduce(
                (s, l) => s + (Number(l.debit) || 0), 0) * 100) / 100;
        },
        totalC() {
            return Math.round(this.editing.lines.reduce(
                (s, l) => s + (Number(l.credit) || 0), 0) * 100) / 100;
        },
        linesBalanced() {
            return Math.abs(this.totalD - this.totalC) < 0.01;
        },
    },
    created() {
        this.loadTemplates();
    },
    methods: {
        loadTemplates() {
            var self = this;
            self.loading = true;
            axios.get(this.tplApi + 'list_templates').then(res => {
                if (res.data && res.data.err === 0) {
                    self.templates = res.data.items || [];
                }
            }).catch(() => {
                AccUI.toastError('تعذّر تحميل القوالب');
            }).then(() => { self.loading = false; });
        },
        /**
         * تحميل قائمة الفروع والدورات + تعيين السياق الافتراضي (أول دورة مفتوحة).
         * المستخدم يستطيع تغييره من dropdown الـ modal.
         */
        loadContextOnce() {
            if (this.branches.length && this.periods.length) return Promise.resolve();
            var self = this;
            return Promise.all([
                axios.get(this.settingApi + 'get_all_branches').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periods').then(r => r.data || []),
            ]).then(arr => {
                self.branches = arr[0] || [];
                self.periods = arr[1] || [];
                if (!self.branches.length) {
                    AccUI.toastError('لا توجد فروع');
                    return;
                }
                var openP = self.periods.find(p => p.open_period === 1)
                          || self.periods[self.periods.length - 1];
                if (!openP) {
                    AccUI.toastError('لا توجد دورات مالية');
                    return;
                }
                // الافتراضي: أول فرع + الدورة المفتوحة
                if (!self.ctxBranch) self.ctxBranch = self.branches[0].id;
                if (!self.ctxPeriod) self.ctxPeriod = openP.id;
            });
        },

        loadAccountsForCtx() {
            if (!this.ctxBranch || !this.ctxPeriod) {
                this.accounts = [];
                return Promise.resolve();
            }
            var self = this;
            this.loadingAccounts = true;
            return axios.get(this.opsApi + 'get_accounts_for_journal/'
                             + this.ctxBranch + '/' + this.ctxPeriod
            ).then(res => {
                self.accounts = (res.data && res.data.accounts) || [];
            }).catch(() => {
                self.accounts = [];
                AccUI.toastError('تعذّر تحميل الحسابات');
            }).then(() => { self.loadingAccounts = false; });
        },

        onCtxChange() {
            // أعد تحميل الحسابات عند تغيير الفرع/الفترة
            this.loadAccountsForCtx();
        },
        openNewModal() {
            var self = this;
            this.editing = {
                id: null, name: '', description: '',
                lines: [blankLine(), blankLine()],
            };
            this.showModal = true;
            this.loadContextOnce().then(() => self.loadAccountsForCtx());
        },
        openEditModal(t) {
            var self = this;
            this.loadContextOnce().then(() => self.loadAccountsForCtx()).then(() => {
                axios.get(self.tplApi + 'get_template/' + t.id).then(res => {
                    if (res.data && res.data.err === 0) {
                        var lines = (res.data.lines || []).map(l => ({
                            accounting_tree: l.accounting_tree,
                            debit: Number(l.debit) || 0,
                            credit: Number(l.credit) || 0,
                            detail: l.detail || '',
                            cost_center: l.cost_center || null,
                        }));
                        if (!lines.length) lines = [blankLine(), blankLine()];
                        self.editing = {
                            id: res.data.id,
                            name: res.data.name,
                            description: res.data.description,
                            lines: lines,
                        };
                        self.showModal = true;
                    } else {
                        AccUI.toastError('تعذّر تحميل القالب', (res.data && res.data.mess) || '');
                    }
                });
            });
        },
        addLine() {
            this.editing.lines.push(blankLine());
        },
        removeLine(idx) {
            if (this.editing.lines.length > 2) {
                this.editing.lines.splice(idx, 1);
            } else {
                AccUI.toastError('سطرين على الأقل', 'القالب يحتاج سطرين على الأقل');
            }
        },
        onAmountInput(line, side) {
            // مدين ودائن غير معاً
            if (side === 'debit' && Number(line.debit) > 0) line.credit = 0;
            if (side === 'credit' && Number(line.credit) > 0) line.debit = 0;
        },
        fmt(n) { return AccUI.formatNumber(n); },
        saveTemplate() {
            var self = this;
            // validation client-side
            if (!this.editing.name.trim()) {
                AccUI.toastError('الاسم مطلوب'); return;
            }
            for (var i = 0; i < this.editing.lines.length; i++) {
                var l = this.editing.lines[i];
                if (!l.accounting_tree) {
                    AccUI.toastError('السطر ' + (i+1) + ' بلا حساب'); return;
                }
                var d = Number(l.debit) || 0;
                var c = Number(l.credit) || 0;
                if (d === 0 && c === 0) {
                    AccUI.toastError('السطر ' + (i+1) + ' بلا مبلغ'); return;
                }
                if (d > 0 && c > 0) {
                    AccUI.toastError('السطر ' + (i+1) + ' مدين ودائن معاً'); return;
                }
            }
            var payload = {
                id: this.editing.id || undefined,
                name: this.editing.name.trim(),
                description: this.editing.description || '',
                lines: this.editing.lines.map(l => ({
                    accounting_tree: l.accounting_tree,
                    debit: Number(l.debit) || 0,
                    credit: Number(l.credit) || 0,
                    detail: l.detail || '',
                    cost_center: l.cost_center || null,
                })),
            };
            self.saving = true;
            var endpoint = this.editing.id ? 'update_template' : 'save_template';
            axios.post(this.tplApi + endpoint, payload).then(res => {
                if (res.data && res.data.err === 0) {
                    AccUI.toastSaved(self.editing.id ? 'تم التعديل' : 'تمت الإضافة');
                    self.showModal = false;
                    self.loadTemplates();
                } else {
                    AccUI.toastError('تعذّر الحفظ', (res.data && res.data.mess) || '');
                }
            }).catch(err => {
                AccUI.toastError('خطأ في الاتصال', (err && err.message) || '');
            }).then(() => { self.saving = false; });
        },
        deleteTemplate(t) {
            var self = this;
            AccUI.confirmDelete('حذف القالب', 'سيُحذف القالب "' + t.name + '" نهائياً.')
                .then(r => {
                    if (!r.isConfirmed) return;
                    return axios.post(self.tplApi + 'delete_template', { id: t.id });
                })
                .then(res => {
                    if (!res) return;
                    if (res.data && res.data.err === 0) {
                        AccUI.toastDeleted();
                        self.loadTemplates();
                    } else {
                        AccUI.toastError('تعذّر الحذف', (res.data && res.data.mess) || '');
                    }
                });
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
