# -*- coding: utf-8 -*-
# type: ignore
"""setting_closing_api — إقفال نتيجة الدورة قبل ترحيل الافتتاحيات."""


def _closing_save_no(period_id, branch_id):
    return ("CL-%s-%s" % (int(period_id), int(branch_id)))[:20]


def _previous_period_for_target(per):
    if not per:
        return None
    if per.start_date:
        prev = db(db.account_periods.end_date < per.start_date).select(
            db.account_periods.ALL,
            orderby=~db.account_periods.end_date,
            limitby=(0, 1),
        ).first()
        if prev:
            return prev
    return db(db.account_periods.id < per.id).select(
        db.account_periods.ALL,
        orderby=~db.account_periods.id,
        limitby=(0, 1),
    ).first()


def _closing_result_summary(period_id, branch_id):
    """يرجع حسابات الأرباح والخسائر غير المقفلة وحسابات حقوق الملكية المتاحة."""
    rows = db.executesql(
        """
        SELECT at.id AS account_id, at.account_no, at.account_name_ar,
               at.final_account,
               COALESCE((SELECT SUM(debit) FROM account_periods_opening
                          WHERE account_periods = %s AND branches = %s
                            AND account_no = at.account_no), 0) AS od,
               COALESCE((SELECT SUM(credit) FROM account_periods_opening
                          WHERE account_periods = %s AND branches = %s
                            AND account_no = at.account_no), 0) AS oc,
               COALESCE((SELECT SUM(jed.debit)
                          FROM journal_entry_detail jed
                          JOIN journal_entry_master jem
                            ON jem.id = jed.journal_entry_master
                         WHERE jem.is_active = 'T'
                           AND jed.account_periods = %s
                           AND jed.branches = %s
                           AND jed.account_no = at.account_no), 0) AS jd,
               COALESCE((SELECT SUM(jed.credit)
                          FROM journal_entry_detail jed
                          JOIN journal_entry_master jem
                            ON jem.id = jed.journal_entry_master
                         WHERE jem.is_active = 'T'
                           AND jed.account_periods = %s
                           AND jed.branches = %s
                           AND jed.account_no = at.account_no), 0) AS jc
        FROM accounting_tree at
        WHERE at.account_periods = %s
          AND at.branches = %s
          AND at.final_account <> 1
          AND at.account_no NOT IN (
            SELECT main_account FROM accounting_tree
             WHERE account_periods = %s
               AND branches = %s
               AND main_account IS NOT NULL
          )
        ORDER BY at.account_no
        """,
        placeholders=[
            int(period_id), int(branch_id),
            int(period_id), int(branch_id),
            int(period_id), int(branch_id),
            int(period_id), int(branch_id),
            int(period_id), int(branch_id),
            int(period_id), int(branch_id),
        ],
        as_dict=True,
    )
    detail = []
    total_debit = total_credit = 0.0
    for row in rows:
        net = round(
            float(row.get("od") or 0) + float(row.get("jd") or 0)
            - float(row.get("oc") or 0) - float(row.get("jc") or 0),
            2,
        )
        if abs(net) < 0.005:
            continue
        debit = net if net > 0 else 0.0
        credit = -net if net < 0 else 0.0
        total_debit += debit
        total_credit += credit
        detail.append({
            "account_id": int(row["account_id"]),
            "account_no": row["account_no"],
            "account_name": row["account_name_ar"] or row["account_no"],
            "final_account": int(row["final_account"] or 0),
            "debit": round(debit, 2),
            "credit": round(credit, 2),
            "net": net,
        })

    equity_accounts = db.executesql(
        """
        SELECT at.id, at.account_no, at.account_name_ar, at.account_type
          FROM accounting_tree at
         WHERE at.account_periods = %s
           AND at.branches = %s
           AND at.final_account = 1
           AND at.account_type = 1
           AND at.account_no LIKE %s
           AND at.account_no NOT IN (
             SELECT main_account FROM accounting_tree
              WHERE account_periods = %s
                AND branches = %s
                AND main_account IS NOT NULL
           )
         ORDER BY at.account_no
        """,
        placeholders=[
            int(period_id), int(branch_id), "3%",
            int(period_id), int(branch_id),
        ],
        as_dict=True,
    )
    net = round(total_debit - total_credit, 2)
    return {
        "needs_closing": bool(detail),
        "debit": round(total_debit, 2),
        "credit": round(total_credit, 2),
        "net": net,
        "result_type": "loss" if net > 0 else ("profit" if net < 0 else "zero"),
        "rows": detail,
        "equity_accounts": [{
            "id": int(a["id"]),
            "account_no": a["account_no"],
            "account_name": a["account_name_ar"] or a["account_no"],
            "account_type": int(a["account_type"] or 0),
        } for a in equity_accounts],
        "save_no": _closing_save_no(period_id, branch_id),
    }


@auth.requires(can_view)
def closing_result_status():
    """حالة إقفال نتيجة الدورة السابقة بالنسبة للدورة المختارة."""
    try:
        branch_id = int(request.vars.get("branch") or request.args(0) or 0)
        period_id = int(request.vars.get("period") or request.args(1) or 0)
        per = db.account_periods[period_id] if period_id else None
        if not (branch_id and per):
            return response.json({"err": 1, "mess": "الفرع والدورة مطلوبان"})
        prev = _previous_period_for_target(per)
        if not prev:
            return response.json({"err": 1, "mess": "لا توجد دورة سابقة"})
        summary = _closing_result_summary(prev.id, branch_id)
        summary.update({
            "source_period_id": int(prev.id),
            "source_period_name": prev.disc,
            "source_period_open": int(prev.open_period or 0),
        })
        return response.json({"err": 0, "closing": summary})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_admin)
def close_previous_period_result():
    """ينشئ قيد إقفال الأرباح والخسائر في الدورة السابقة."""
    try:
        branch_id = int(request.vars.get("branch") or 0)
        period_id = int(request.vars.get("period") or 0)
        equity_id = int(request.vars.get("equity_account") or 0)
        allow_closed = str(request.vars.get("allow_closed") or "").lower() in (
            "1", "true", "yes"
        )
        per = db.account_periods[period_id] if period_id else None
        if not (branch_id and per and equity_id):
            return response.json({"err": 1, "mess": "الفرع والدورة وحساب حقوق الملكية مطلوبة"})
        prev = _previous_period_for_target(per)
        if not prev:
            return response.json({"err": 1, "mess": "لا توجد دورة سابقة"})
        if int(prev.open_period or 0) != 1 and not allow_closed:
            return response.json({"err": 2, "mess": "الدورة السابقة مقفلة. يتطلب الإجراء تأكيد مدير."})

        equity = db.accounting_tree[equity_id]
        if (not equity or int(equity.account_periods or 0) != int(prev.id)
                or int(equity.branches or 0) != branch_id
                or int(equity.final_account or 0) != 1
                or int(equity.account_type or 0) != 1
                or not str(equity.account_no or "").startswith("3")):
            return response.json({"err": 1, "mess": "حساب الإقفال يجب أن يكون من حسابات حقوق الملكية للدورة السابقة"})

        summary = _closing_result_summary(prev.id, branch_id)
        if not summary["needs_closing"]:
            return response.json({"err": 0, "mess": "0", "already_closed": True})
        save_no = summary["save_no"]
        exists = db(
            (db.journal_entry_master.account_periods == prev.id)
            & (db.journal_entry_master.branches == branch_id)
            & (db.journal_entry_master.journal_save == save_no)
            & (db.journal_entry_master.is_active == True)
        ).count()
        if exists:
            return response.json({"err": 2, "mess": "يوجد قيد إقفال نتيجة مسجل مسبقاً لهذه الدورة والفرع"})

        lines = []
        for row in summary["rows"]:
            if row["debit"] > 0:
                lines.append((row["account_id"], row["account_no"], 0.0, row["debit"]))
            if row["credit"] > 0:
                lines.append((row["account_id"], row["account_no"], row["credit"], 0.0))
        if summary["net"] > 0:
            lines.append((int(equity.id), equity.account_no, summary["net"], 0.0))
        elif summary["net"] < 0:
            lines.append((int(equity.id), equity.account_no, 0.0, -summary["net"]))

        total_debit = round(sum(line[2] for line in lines), 2)
        total_credit = round(sum(line[3] for line in lines), 2)
        if abs(total_debit - total_credit) >= 0.005:
            return response.json({"err": 3, "mess": "قيد الإقفال غير متوازن — أوقف التنفيذ"})

        master_id = db.journal_entry_master.insert(
            account_periods=prev.id,
            journal_date=prev.end_date or request.now.date(),
            branches=branch_id,
            debit_total=total_debit,
            credit_total=total_credit,
            journal_detail="قيد إقفال نتيجة الدورة %s" % prev.disc,
            journal_operations=len(lines),
            journal_save=save_no,
        )
        for account_id, account_no, debit, credit in lines:
            db.journal_entry_detail.insert(
                journal_entry_master=master_id,
                account_periods=prev.id,
                journal_date=prev.end_date or request.now.date(),
                branches=branch_id,
                debit=debit,
                credit=credit,
                detail="إقفال نتيجة الدورة",
                accounting_tree=account_id,
                account_no=account_no,
                cost_center=None,
            )
        db.commit()
        return response.json({
            "err": 0, "mess": "0", "journal_id": int(master_id),
            "journal_save": save_no, "debit": total_debit, "credit": total_credit,
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
