# -*- coding: utf-8 -*-
"""
acc_schema — أدوات فحص وجود الجداول في قاعدة البيانات.

`migrate=false` يعني web2py لا ينشئ الجداول من تعريف Field()،
لذلك بعض الجداول الجديدة (journal_attachments, journal_templates)
قد لا تكون مطبَّقة على القاعدة الفعلية. هذه الـ helpers تكتشف ذلك
بأمان وتُرجع رسالة ودودة بدلاً من Exception غامض.

استعمال نموذجي:
    from applications.acc.modules import acc_schema
    if not acc_schema.table_exists(db, 'journal_attachments'):
        return response.json(acc_schema.missing_table_response(
            'journal_attachments', migration='001'))
"""


def table_exists(db, table_name):
    """يتحقّق فعلياً من وجود الجدول في PostgreSQL (information_schema).

    Returns: bool — True إن كان الجدول موجوداً في DB.
    آمن: يلتقط أي خطأ ويُرجع False.
    """
    try:
        rows = db.executesql(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = %s LIMIT 1",
            placeholders=[table_name],
        )
        return bool(rows)
    except Exception:
        # SQLite أو خطأ في الاتصال → fallback لمحاولة استعلام بسيط
        try:
            db.executesql("SELECT 1 FROM " + table_name + " LIMIT 1")
            return True
        except Exception:
            return False


def missing_table_response(table_name, migration=None):
    """رد JSON قياسي عند غياب جدول.

    Returns: dict {err: 2, mess: "..."} يُمرَّر إلى response.json().
    """
    msg = "ميزة غير مفعَّلة: الجدول `%s` غير موجود في القاعدة." % table_name
    if migration:
        msg += " طبّق `migrations_manual/%s_*.sql` ثم أعد المحاولة." % migration
    return {"err": 2, "mess": msg, "missing_table": table_name}


def required_tables(db, names, migrations=None):
    """يفحص قائمة جداول دفعةً واحدة.

    Args:
        names: list[str]
        migrations: dict {table_name: migration_number} (اختياري للرسالة)

    Returns:
        (ok, missing) — ok bool، missing قائمة الأسماء الناقصة
    """
    missing = []
    for n in names:
        if not table_exists(db, n):
            missing.append(n)
    return (not missing, missing)


def health_check(db, required=None):
    """فحص صحة شامل للقاعدة. يُستخدم في endpoint /health.

    Args:
        required: list of dicts [{"name": "x", "migration": "001"}]

    Returns: dict {ok, db_connected, tables: {...}, errors: [...]}
    """
    result = {"ok": True, "db_connected": False, "tables": {}, "errors": []}
    # فحص الاتصال
    try:
        db.executesql("SELECT 1")
        result["db_connected"] = True
    except Exception as e:
        result["ok"] = False
        result["db_connected"] = False
        result["errors"].append("DB غير متاحة: " + str(e))
        return result

    # فحص الجداول الأساسية
    base = ["accounting_tree", "journal_entry_master", "journal_entry_detail",
            "account_periods", "branches", "auth_user"]
    for t in base:
        exists = table_exists(db, t)
        result["tables"][t] = exists
        if not exists:
            result["ok"] = False
            result["errors"].append("جدول أساسي ناقص: " + t)

    # فحص الجداول الاختيارية (مع رقم migration)
    if required:
        for r in required:
            name = r.get("name") if isinstance(r, dict) else r
            mig = r.get("migration") if isinstance(r, dict) else None
            exists = table_exists(db, name)
            result["tables"][name] = exists
            if not exists and mig:
                result["errors"].append(
                    "ميزة معطّلة: %s (طبّق migration %s)" % (name, mig)
                )

    return result
