/**
 * acc_ui.js — مساعدات واجهة موحَّدة (Toasts، تأكيدات، تنسيق أرقام).
 *
 * يُحمَّل من layout.html — متاح في كل الشاشات.
 * يستخدم SweetAlert2 الموجود مسبقاً.
 *
 * استعمال:
 *   AccUI.toastSaved();                        // تم الحفظ بنجاح
 *   AccUI.toastSaved('تم حفظ القيد');          // مخصَّص
 *   AccUI.toastAdded();                        // تمت الإضافة
 *   AccUI.toastDeleted();                      // تم الحذف
 *   AccUI.toastError('تعذّر التحميل', msg);     // إشعار خطأ
 *   AccUI.toastInfo('عملية جارية');             // معلومات
 *   AccUI.confirmDelete('حذف الفرع').then(...);// نعم/إلغاء
 *   AccUI.formatNumber(1234.5)                 // "1,234.50"
 */
(function (window) {
    'use strict';

    function _toast(opts) {
        if (typeof Swal === 'undefined') {
            console.log('[AccUI]', opts.title, opts.text || '');
            return;
        }
        return Swal.fire(Object.assign({
            timer: 1700,
            showConfirmButton: false,
            toast: false,
        }, opts));
    }

    const AccUI = {
        toastSaved(title) {
            return _toast({ icon: 'success', title: title || 'تم الحفظ' });
        },
        toastAdded(title) {
            return _toast({ icon: 'success', title: title || 'تمت الإضافة' });
        },
        toastDeleted(title) {
            return _toast({ icon: 'success', title: title || 'تم الحذف' });
        },
        toastError(title, text) {
            return _toast({
                icon: 'error',
                title: title || 'خطأ',
                text: text || '',
                timer: 3000,
                showConfirmButton: true,
            });
        },
        toastInfo(title, text) {
            return _toast({
                icon: 'info',
                title: title,
                text: text || '',
            });
        },
        confirmDelete(title, text) {
            if (typeof Swal === 'undefined') {
                return Promise.resolve({ isConfirmed: confirm(title) });
            }
            return Swal.fire({
                icon: 'warning',
                title: title || 'تأكيد الحذف',
                text: text || 'لا يمكن التراجع عن هذا الإجراء.',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#dc3545',
            });
        },
        formatNumber(n, digits) {
            const v = Number(n) || 0;
            const d = (typeof digits === 'number') ? digits : 2;
            return v.toLocaleString('en-US', {
                minimumFractionDigits: d,
                maximumFractionDigits: d,
            });
        },
        /**
         * تنبيه قبل الطباعة كـ PDF — يخبر المستخدم بكيفية الحفظ كـ PDF.
         * يُحفّز window.print() بعد التأكيد.
         */
        printAsPdf(opts) {
            opts = opts || {};
            if (typeof Swal === 'undefined') {
                window.print();
                return Promise.resolve(true);
            }
            return Swal.fire({
                icon: 'info',
                title: opts.title || 'حفظ كـ PDF',
                html: opts.html ||
                    'سيظهر مربّع الطباعة. اختر <b>"حفظ كـ PDF"</b> ' +
                    'كوجهة الطباعة، ثم اضغط حفظ.',
                showCancelButton: true,
                confirmButtonText: 'متابعة',
                cancelButtonText: 'إلغاء',
            }).then(function (r) {
                if (r.isConfirmed) {
                    setTimeout(function () { window.print(); }, 100);
                    return true;
                }
                return false;
            });
        },
        /**
         * يُعالج رد API بشكل موحَّد. يتوقع شكل acc_responses:
         *   {err: 0, ...data} → onOk(data)
         *   {err: 1|2|3, mess: "..."} → toastError(mess)
         */
        handleResponse(d, onOk, errTitle) {
            if (d && Number(d.err) === 0) {
                if (typeof onOk === 'function') onOk(d);
                return true;
            }
            this.toastError(errTitle || 'خطأ', (d && d.mess) || '');
            return false;
        },
    };

    window.AccUI = AccUI;
})(window);
