# -*- coding: utf-8 -*-
"""Helpers for importing accounting-tree JSON files."""


TEMPLATE_FILES = {
    "1": "account_tree_ex2.json",
    "2": "account_tree_ex.json",
    "3": "account_tree_ex3.json",
    "4": "account_tree_ex4.json",
    "5": "account_tree_sme_sa.json",
}


def template_filename(template_id):
    return TEMPLATE_FILES.get(str(template_id or "").strip())


def _clean_text(value, default=""):
    value = default if value is None else value
    return str(value).strip()


def _clean_int(value, default):
    try:
        return int(value)
    except Exception:
        return default


def normalize_chart_rows(rows):
    """Return import-safe accounting-tree rows."""
    if not isinstance(rows, list):
        return []
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        out.append({
            "account_no": _clean_text(row.get("account_no")),
            "account_name_ar": _clean_text(row.get("account_name_ar")),
            "account_name_en": _clean_text(row.get("account_name_en")),
            "main_account": _clean_text(row.get("main_account"), "0") or "0",
            "account_type": _clean_int(row.get("account_type"), 1),
            "final_account": _clean_int(row.get("final_account"), 1),
            "show_account": 2 if _clean_int(row.get("show_account"), 1) == 2 else 1,
        })
    return out


def sort_chart_rows(rows):
    """Parents first, then numeric-like account numbers in lexical order."""
    return sorted(
        rows or [],
        key=lambda r: (len(str(r.get("account_no") or "")), str(r.get("account_no") or "")),
    )


def validate_chart_rows(rows):
    """Return Arabic error text for invalid import data, otherwise None."""
    if not isinstance(rows, list) or not rows:
        return "ملف الدليل لا يحتوي على حسابات."

    numbers = set()
    duplicates = set()
    for i, row in enumerate(rows, 1):
        acc = _clean_text(row.get("account_no"))
        name = _clean_text(row.get("account_name_ar"))
        main = _clean_text(row.get("main_account"), "0") or "0"
        if not acc:
            return "السطر %d بلا رقم حساب." % i
        if not name:
            return "السطر %d بلا اسم حساب عربي." % i
        if acc in numbers:
            duplicates.add(acc)
        numbers.add(acc)
        if main != "0" and not acc.startswith(main):
            return "الحساب %s يجب أن يبدأ برقم الحساب الرئيسي %s." % (acc, main)

    if duplicates:
        sample = ", ".join(sorted(duplicates)[:5])
        return "ملف الدليل يحتوي على أرقام حسابات مكررة: %s" % sample

    for row in rows:
        main = _clean_text(row.get("main_account"), "0") or "0"
        if main != "0" and main not in numbers:
            return "الحساب الرئيسي %s غير موجود داخل ملف الدليل." % main

    return None
