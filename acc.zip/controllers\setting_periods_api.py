# -*- coding: utf-8 -*-
# type: ignore
"""
setting_periods_api — إدارة الدورات المالية + الإقفال/الفتح + ترحيل الأرصدة
+ مساعدات استكشاف الدورة من تاريخ.

استُخرج من setting_api.py في Phase 2.3 (2026-05-25).
"""

from datetime import datetime

from applications.acc.modules import acc_dates, acc_carry_forward


_parse_iso_date = acc_dates.parse_iso


def _enrich_periods(rows):
    """إثراء الصفوف باسم المستخدم الذي أقفل الدورة."""
    uids = list({r.closed_by for r in rows if r.closed_by})
    names = {}
    if uids:
        for u in db(db.auth_user.id.belongs(uids)).select(
            db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
        ):
            names[u.id] = ((u.first_name or "") + " " + (u.last_name or "")).strip()
    out = []
    for r in rows:
        d = r.as_dict()
        d["closed_by_name"] = names.get(r.closed_by, "")
        out.append(d)
    return out


@auth.requires(can_view)
def get_all_account_periods():
    rows = db(db.account_periods.show_row == 1).select(
        db.account_periods.ALL, orderby=db.account_periods.id
    )
    return response.json(_enrich_periods(rows))


@auth.requires(can_view)
def get_all_account_periodsA():
    rows = db(db.account_periods.id > 0).select(
        db.account_periods.ALL, orderby=db.account_periods.id
    )
    return response.json(_enrich_periods(rows))


@auth.requires(can_view)
def period_stats():
    """إحصائيات الدورة — تُستدعى عند فتح نافذة التعديل."""
    try:
        pid = request.vars.get("id") or request.args(0)
        if not pid:
            return response.json({"err": 1, "mess": "id مطلوب"})
        pid = int(pid)
        count = db(db.journal_entry_master.account_periods == pid).count()
        sums = db.executesql(
            "SELECT COALESCE(SUM(debit),0), COALESCE(SUM(credit),0) "
            "FROM journal_entry_detail WHERE account_periods=%s",
            placeholders=[pid],
        )
        debit = float(sums[0][0] or 0)
        credit = float(sums[0][1] or 0)
        unbal_r = db.executesql(
            "SELECT COUNT(*) FROM ("
            "  SELECT journal_entry_master FROM journal_entry_detail "
            "  WHERE account_periods=%s "
            "  GROUP BY journal_entry_master "
            "  HAVING round(CAST(COALESCE(sum(debit),0) AS numeric),2) "
            "       <> round(CAST(COALESCE(sum(credit),0) AS numeric),2)"
            ") t",
            placeholders=[pid],
        )
        unbal = int(unbal_r[0][0] or 0)
        return response.json({
            "err": 0, "count": count, "debit": debit,
            "credit": credit, "unbalanced": unbal,
        })
    except Exception as e:
        print(e)
        return response.json({"err": 3, "mess": str(e)})


def _validate_period(row, period_id=None):
    disc = (row.get("disc") or "").strip()
    if not disc:
        return "وصف الدورة مطلوب"
    if len(disc) < 3:
        return "وصف الدورة يجب ألا يقل عن 3 أحرف"
    pt = (row.get("period_type") or "year").strip().lower()
    if pt not in _VALID_PERIOD_TYPES:
        return "نوع الدورة غير صحيح"
    sd = _parse_iso_date(row.get("start_date"))
    ed = _parse_iso_date(row.get("end_date"))
    if not sd:
        return "تاريخ بداية الدورة مطلوب وبصيغة صحيحة"
    if not ed:
        return "تاريخ نهاية الدورة مطلوب وبصيغة صحيحة"
    if sd > ed:
        return "تاريخ البداية يجب أن يسبق تاريخ النهاية"
    dup = db.account_periods.disc == disc
    if period_id:
        dup &= db.account_periods.id != period_id
    if db(dup).count() > 0:
        return "وصف الدورة مستخدم مسبقاً لدورة أخرى"
    ov = (db.account_periods.start_date <= ed) & (db.account_periods.end_date >= sd)
    if period_id:
        ov &= db.account_periods.id != period_id
    other = db(ov).select(db.account_periods.disc, limitby=(0, 1)).first()
    if other:
        return "تتداخل تواريخ الدورة مع دورة قائمة: %s" % other.disc
    return None


_VALID_PERIOD_TYPES = ("year", "half", "quarter", "month", "custom")


def _period_fields(row, default_open=1):
    pt = (row.get("period_type") or "year").strip().lower()
    if pt not in _VALID_PERIOD_TYPES:
        pt = "year"
    return dict(
        disc=(row.get("disc") or "").strip(),
        start_date=_parse_iso_date(row.get("start_date")),
        end_date=_parse_iso_date(row.get("end_date")),
        open_period=int(row.get("open_period") or default_open),
        show_row=int(row.get("show_row") or 1),
        period_type=pt,
        notes=(row.get("notes") or "").strip(),
    )


@auth.requires(can_account)
def add_account_periods():
    """إضافة دورة مالية جديدة.

    سلوك مهم (Fix 2026-05-26): إذا الدورة الجديدة open_period=1 وتوجد دورات
    مفتوحة سابقة، يرفض الـ API مع err=4 وقائمة الدورات المُتأثرة. الـ frontend
    يطلب تأكيد المستخدم ثم يعيد الإرسال مع confirm_close_others=1.
    """
    try:
        row = request.vars
        err = _validate_period(row)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        fields = _period_fields(row, default_open=1)
        # تحقق: لو الدورة الجديدة مفتوحة وتوجد دورات أخرى مفتوحة، نطلب تأكيد
        if fields["open_period"] == 1:
            already_open = db(db.account_periods.open_period == 1).select(
                db.account_periods.id, db.account_periods.disc
            )
            confirm = str(row.get("confirm_close_others") or "").lower() in (
                "1", "true", "yes", "on")
            if already_open and not confirm:
                return response.json({
                    "err": 4,
                    "mess": "ستُقفل %d دورة مفتوحة حالياً عند فتح هذه الدورة. أكّد الإجراء." % len(already_open),
                    "will_close": [{"id": p.id, "disc": p.disc} for p in already_open],
                })
        nid = db.account_periods.insert(**fields)
        if fields["open_period"] == 1:
            db(
                (db.account_periods.id != nid)
                & (db.account_periods.open_period == 1)
            ).update(open_period=2)
        db.commit()
        return response.json({"err": 0, "id": nid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def update_account_periods():
    try:
        row = request.vars
        pid = row.get("id")
        rec = db.account_periods[pid] if pid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "الدورة المالية غير موجودة"})
        err = _validate_period(row, period_id=pid)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        fields = _period_fields(row, default_open=int(rec.open_period or 1))
        fields["open_period"] = int(rec.open_period or 1)
        rec.update_record(**fields)
        db.commit()
        return response.json({"err": 0, "id": pid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def delete_account_periods():
    try:
        pid = request.vars.get("id")
        rec = db.account_periods[pid] if pid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "الدورة المالية غير موجودة"})
        used = (
            db(db.journal_entry_master.account_periods == pid).count()
            + db(db.journal_entry_detail.account_periods == pid).count()
            + db(db.accounting_tree.account_periods == pid).count()
            + db(db.account_periods_opening.account_periods == pid).count()
        )
        if used > 0:
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن حذف الدورة لارتباطها بـ %d سجل في النظام. أوقف عرضها بدلاً من حذفها." % used,
            })
        rec.delete_record()
        db.commit()
        return response.json({"err": 0, "id": pid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


# ===================  إقفال / إعادة فتح الدورة المالية  ===================
def _unclosed_result_accounts(period_id):
    """حسابات نتيجة غير مقفلة؛ يجب تصفيرها قبل إقفال الدورة."""
    return db.executesql(
        """
        SELECT x.branches, br.name, COUNT(*) AS n
          FROM (
            SELECT at.branches, at.account_no,
                   COALESCE((SELECT SUM(debit) FROM account_periods_opening
                              WHERE account_periods = %s
                                AND branches = at.branches
                                AND account_no = at.account_no), 0)
                 + COALESCE((SELECT SUM(jed.debit)
                                FROM journal_entry_detail jed
                                JOIN journal_entry_master jem
                                  ON jem.id = jed.journal_entry_master
                               WHERE jem.is_active = 'T'
                                 AND jed.account_periods = %s
                                 AND jed.branches = at.branches
                                 AND jed.account_no = at.account_no), 0)
                 - COALESCE((SELECT SUM(credit) FROM account_periods_opening
                              WHERE account_periods = %s
                                AND branches = at.branches
                                AND account_no = at.account_no), 0)
                 - COALESCE((SELECT SUM(jed.credit)
                                FROM journal_entry_detail jed
                                JOIN journal_entry_master jem
                                  ON jem.id = jed.journal_entry_master
                               WHERE jem.is_active = 'T'
                                 AND jed.account_periods = %s
                                 AND jed.branches = at.branches
                                 AND jed.account_no = at.account_no), 0) AS bal
              FROM accounting_tree at
             WHERE at.account_periods = %s
               AND at.final_account <> 1
               AND at.account_no NOT IN (
                 SELECT main_account FROM accounting_tree
                  WHERE account_periods = %s
                    AND branches = at.branches
                    AND main_account IS NOT NULL
               )
          ) x
          LEFT JOIN branches br ON br.id = x.branches
         WHERE ABS(x.bal) >= 0.005
         GROUP BY x.branches, br.name
         ORDER BY x.branches
        """,
        placeholders=[
            int(period_id), int(period_id), int(period_id),
            int(period_id), int(period_id), int(period_id),
        ],
        as_dict=True,
    )


@auth.requires(can_admin)
def close_period():
    """إقفال دورة مالية — لا يُسمح بالإقفال إن وُجد قيد غير متوازن."""
    try:
        period_id = request.vars.get("id") or request.args(0)
        per = db.account_periods[period_id]
        if not per:
            return response.json({"err": 1, "id": 0, "mess": "الدورة المالية غير موجودة"})
        if per.open_period != 1:
            return response.json({"err": 2, "id": 0, "mess": "الدورة مقفلة بالفعل"})
        unclosed = _unclosed_result_accounts(period_id)
        if unclosed:
            branch_names = "، ".join([
                "%s (%s حساب)" % (r.get("name") or r.get("branches"), int(r.get("n") or 0))
                for r in unclosed
            ])
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن إقفال الدورة — توجد حسابات إيرادات/مصروفات غير مقفلة في: %s. "
                "أنشئ قيد إقفال نتيجة الدورة أولاً." % branch_names,
            })
        qry_unbal = (
            "select count(*) as n from ( "
            "  select jed.journal_entry_master from journal_entry_detail jed "
            "  join journal_entry_master jem on jem.id = jed.journal_entry_master "
            "  where jem.is_active = 'T' and jed.account_periods = %s "
            "  group by jed.journal_entry_master "
            "  having round(CAST(COALESCE(sum(debit),0) as numeric),2) "
            "       <> round(CAST(COALESCE(sum(credit),0) as numeric),2) "
            ") t"
        )
        n = db.executesql(qry_unbal, placeholders=[int(period_id)], as_dict=True)[0]["n"]
        if n and int(n) > 0:
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن إقفال الدورة — يوجد %s قيد غير متوازن. "
                "راجع تقرير «القيود غير المتوازنة» أولاً." % n,
            })
        per.update_record(
            open_period=2,
            closed_on=request.now,
            closed_by=auth.user_id,
        )
        db.commit()
        return response.json({"err": 0, "id": per.id, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_admin)
def reopen_period():
    """إعادة فتح دورة مالية مقفلة — يُقفل بقية الدورات المفتوحة."""
    try:
        period_id = request.vars.get("id") or request.args(0)
        per = db.account_periods[period_id]
        if not per:
            return response.json({"err": 1, "id": 0, "mess": "الدورة المالية غير موجودة"})
        per.update_record(open_period=1, closed_on=None, closed_by=None)
        db(
            (db.account_periods.id != per.id)
            & (db.account_periods.open_period == 1)
        ).update(open_period=2)
        db.commit()
        return response.json({"err": 0, "id": per.id, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


# =================  ترحيل الأرصدة إلى الدورة التالية  =================
# يُرحَّل الرصيد الختامي لحسابات الميزانية فقط — كأرصدة افتتاحية للدورة التالية.
# منطق الحساب في modules/acc_carry_forward.py — هذا الـ controller للـ SQL فقط.


def _next_period(per):
    return (
        db(db.account_periods.start_date > per.end_date)
        .select(orderby=db.account_periods.start_date, limitby=(0, 1))
        .first()
    )


def _carry_forward_rows(period_id):
    """حساب صافي رصيد كل (فرع، رقم حساب) لحسابات الميزانية في الدورة.
    SQL هنا، منطق التحويل في modules/acc_carry_forward.py."""
    rows = db.executesql(
        """
        SELECT
            at.branches, br.name,
            at.account_no, at.account_name_ar, at.main_account,
            COALESCE((SELECT SUM(debit) FROM journal_entry_detail
                       WHERE account_periods=at.account_periods
                         AND branches=at.branches
                         AND account_no=at.account_no), 0)::float as jd,
            COALESCE((SELECT SUM(credit) FROM journal_entry_detail
                       WHERE account_periods=at.account_periods
                         AND branches=at.branches
                         AND account_no=at.account_no), 0)::float as jc,
            COALESCE((SELECT SUM(debit) FROM account_periods_opening
                       WHERE account_periods=at.account_periods
                         AND branches=at.branches
                         AND account_no=at.account_no), 0)::float as od,
            COALESCE((SELECT SUM(credit) FROM account_periods_opening
                       WHERE account_periods=at.account_periods
                         AND branches=at.branches
                         AND account_no=at.account_no), 0)::float as oc
        FROM accounting_tree at
        LEFT JOIN branches br ON br.id = at.branches
        WHERE at.account_periods = %s AND at.final_account = %s
        ORDER BY at.branches, at.account_no
        """,
        placeholders=[int(period_id), acc_carry_forward.FINAL_BALANCE_SHEET],
        as_dict=True,
    )
    out = []
    for r in rows:
        formatted = acc_carry_forward.format_carry_row(r)
        if formatted:
            out.append(formatted)
    return out


@auth.requires(can_admin)
def preview_carry_forward():
    """معاينة بيانات الترحيل قبل التنفيذ."""
    try:
        pid = request.vars.get("id") or request.args(0)
        per = db.account_periods[pid] if pid else None
        if not per:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        nxt = _next_period(per)
        if not nxt:
            return response.json({"err": 1, "mess": "لا توجد دورة لاحقة. أنشئ الدورة التالية أولاً."})
        preview = _carry_forward_rows(pid)
        total_debit = round(sum(p["debit"] for p in preview), 2)
        total_credit = round(sum(p["credit"] for p in preview), 2)
        return response.json({
            "err": 0, "preview": preview, "count": len(preview),
            "total_debit": total_debit, "total_credit": total_credit,
            "balanced": abs(total_debit - total_credit) < 0.01,
            "next_period_id": nxt.id, "next_period_name": nxt.disc,
            "already_exported": bool(per.export),
        })
    except Exception as e:
        print(e)
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_admin)
def execute_carry_forward():
    """تنفيذ ترحيل أرصدة حسابات الميزانية إلى الدورة التالية."""
    try:
        pid = request.vars.get("id")
        per = db.account_periods[pid] if pid else None
        if not per:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        if per.open_period == 1:
            return response.json({"err": 2, "mess": "أَقفل الدورة أولاً قبل ترحيل أرصدتها."})
        if per.export:
            return response.json({"err": 2, "mess": "تم ترحيل أرصدة هذه الدورة مسبقاً."})
        nxt = _next_period(per)
        if not nxt:
            return response.json({"err": 1, "mess": "لا توجد دورة لاحقة. أنشئ الدورة التالية أولاً."})
        preview = _carry_forward_rows(pid)
        if not preview:
            return response.json({"err": 1, "mess": "لا توجد أرصدة قابلة للترحيل."})
        for p in preview:
            db.account_periods_opening.insert(
                account_periods=nxt.id,
                branches=p["branch_id"],
                account_no=p["account_no"],
                main_account=p["main_account"],
                debit=p["debit"],
                credit=p["credit"],
                export=False,
                carried_from_period=int(pid),
            )
        per.update_record(export=True)
        db.commit()
        return response.json({
            "err": 0, "count": len(preview),
            "next_period_name": nxt.disc, "mess": "0",
        })
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_admin)
def revert_carry_forward():
    """التراجع عن الترحيل — حذف الأرصدة المرحَّلة فقط."""
    try:
        pid = request.vars.get("id")
        per = db.account_periods[pid] if pid else None
        if not per:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        if not per.export:
            return response.json({"err": 1, "mess": "لم يتم ترحيل أرصدة هذه الدورة"})
        nxt = _next_period(per)
        if not nxt:
            return response.json({"err": 1, "mess": "لا توجد دورة لاحقة"})
        je_count = db(db.journal_entry_master.account_periods == nxt.id).count()
        if je_count > 0:
            return response.json({
                "err": 2,
                "mess": "الدورة التالية «%s» تحتوي على %d قيد — لا يمكن إلغاء الترحيل بأمان."
                % (nxt.disc, je_count),
            })
        deleted = db(
            (db.account_periods_opening.account_periods == nxt.id)
            & (db.account_periods_opening.carried_from_period == int(pid))
        ).delete()
        per.update_record(export=False)
        db.commit()
        return response.json({"err": 0, "deleted": int(deleted or 0), "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "mess": str(e)})


# ==================  استكشاف الدورة من تاريخ  ==================
@auth.requires(can_view)
def date_chek():
    """فحص ما إذا كان التاريخ يقع داخل دورة مفتوحة (DD-MM-YYYY)."""
    qry_date = datetime.strptime(request.args(0), "%d-%m-%Y").date()
    qry = db(db.account_periods.open_period == 1).select(db.account_periods.ALL)
    in_between = False
    for row in qry:
        start_date = row.start_date
        end_date = row.end_date
        if start_date <= qry_date <= end_date:
            in_between = True
            break
        else:
            in_between = False
    return in_between


@auth.requires(can_view)
def get_period_for_date():
    """يُرجع الدورة المالية التي يقع فيها تاريخ معيّن."""
    try:
        s = (request.vars.get("d") or request.args(0) or "").strip()
        if not s:
            return response.json({"err": 1, "mess": "التاريخ مطلوب"})
        try:
            qd = datetime.strptime(s, "%Y-%m-%d").date()
        except Exception:
            return response.json({"err": 1, "mess": "صيغة التاريخ غير صحيحة"})
        per = db(
            (db.account_periods.start_date <= qd)
            & (db.account_periods.end_date >= qd)
        ).select(orderby=db.account_periods.id).first()
        if not per:
            return response.json({
                "err": 1,
                "mess": "التاريخ %s خارج كل الدورات المالية المعرّفة" % s,
            })
        return response.json({
            "err": 0,
            "id": per.id,
            "disc": per.disc,
            "open_period": int(per.open_period or 0),
            "start_date": str(per.start_date),
            "end_date": str(per.end_date),
        })
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})
