# -*- coding: utf-8 -*-
# type: ignore
"""
setting_api — façade بعد التقسيم (Phase 2.3 — 2026-05-25).

الإعدادات قُسّمت لـ 5 controllers مخصّصة تحت الحد (600 سطر):
- `setting_periods_api`   — الدورات + الإقفال/الفتح + ترحيل + date_chek
- `setting_branches_api`  — الفروع
- `setting_tree_api`      — شجرة الحسابات + استيراد + استنساخ
- `setting_lookups_api`   — الحسابات الختامية + مراكز التكلفة + المستخدمون
- `setting_opening_api`   — الأرصدة الافتتاحية

هذا الملف يبقي **العقد القديم** سارياً: كل views/setting/*.js تنادي
`/setting_api/<func>` وستجد الدالة هنا.

ملاحظة مهمة: web2py يكتشف الدوال المُتاحة عبر regex على نص الملف
(`REGEX_EXPOSED` في `gluon/compileapp.py`)، فالدوال المُحمَّلة عبر `exec`
**غير مرئية** لـ URL dispatcher. لذلك نُعرّف stubs أولاً (تكتشفها web2py)،
ثم الـ exec يستبدلها بالتنفيذات الحقيقية. هذا يُبقي الـ URLs القديمة سارية
بدون تعديل الـ JS لكل شاشة.
"""

import os


# ===== stubs (الترتيب مهم: قبل exec حتى تُستبدل بالتنفيذات الفعلية) =====
# setting_periods_api
def get_all_account_periods(): pass
def get_all_account_periodsA(): pass
def period_stats(): pass
def add_account_periods(): pass
def update_account_periods(): pass
def delete_account_periods(): pass
def close_period(): pass
def reopen_period(): pass
def preview_carry_forward(): pass
def execute_carry_forward(): pass
def revert_carry_forward(): pass
def date_chek(): pass
def get_period_for_date(): pass

# setting_branches_api
def get_all_branches(): pass
def get_all_branchesA(): pass
def add_branches(): pass
def update_branches(): pass
def delete_branches(): pass

# setting_tree_api
def get_accounting_tree(): pass
def get_accounting_tree2(): pass
def upload_data(): pass
def add_accounting_tree(): pass
def clear_all_account_data(): pass
def list_source_periods_for_clone(): pass
def clone_tree_to_period(): pass
def add_account_file(): pass
def update_accounting_tree(): pass
def delete_accounting_tree(): pass
def get_accounting_tree_last(): pass

# setting_lookups_api
def get_key_final_account(): pass
def get_all_final_accounts(): pass
def add_final_account(): pass
def update_final_account(): pass
def delete_final_account(): pass
def key_cost_center(): pass
def get_all_cost_centers(): pass
def add_cost_center(): pass
def update_cost_center(): pass
def delete_cost_center(): pass
def toggle_cost_center_visibility(): pass
def get_all_users(): pass
def get_screen_data(): pass

# setting_opening_api
def get_opening_periods_balance(): pass
def preview_previous_opening_balances(): pass
def carry_previous_opening_balances(): pass
def update_opening_periods_balance(): pass
def bulk_update_opening_balances(): pass
def clear_opening_balances(): pass

# setting_closing_api
def closing_result_status(): pass
def close_previous_period_result(): pass


# ===== تحميل التنفيذات الفعلية (تُستبدل الـ stubs أعلاه) =====
_dir = os.path.join(request.folder, 'controllers')
for _f in [
    'setting_periods_api.py',
    'setting_branches_api.py',
    'setting_tree_api.py',
    'setting_lookups_api.py',
    'setting_closing_api.py',
    'setting_opening_api.py',
]:
    with open(os.path.join(_dir, _f), encoding='utf-8') as _fh:
        exec(_fh.read(), globals())


def chktree():
    """فحص يدوي — يطبع الحسابات المكرّرة أو اليتيمة في الشجرة المحاسبية."""
    qry = db(db.accounting_tree.id > 0).select()
    print("-------------------------------------")
    for row in qry:
        count_acc = db(db.accounting_tree.account_no == row["account_no"]).count()
        if count_acc > 1:
            print(row["account_no"])
        if db(db.accounting_tree.account_no == row["main_account"]).select():
            pass
        else:
            print(row["account_no"])
