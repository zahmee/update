/* app_users.js — إدارة المستخدمين والأدوار (Vue 3) */

const ROLE_CLASSES = {
  'admin': 'is-admin',
  'user': 'is-user',
  'account': 'is-account',
  'report': 'is-report',
};

const vueApp = Vue.createApp({
  data() {
    return {
      apiBase: window.apiBase,
      isAdmin: !!window.isAdmin,

      users: [],
      groups: [],
      hasMustChange: false,
      loading: true,
      saving: false,

      filter_text: '',

      // User modal
      user_modal_open: false,
      user_form: { id: 0, first_name: '', last_name: '', email: '', mobile: '', password: '' },

      // Roles modal
      roles_modal_open: false,
      roles_form: { user_id: 0, full_name: '', role_ids: [] },

      // Reset password modal
      reset_modal_open: false,
      reset_form: { user_id: 0, full_name: '', password: '' },

      // Group modal
      group_modal_open: false,
      group_form: { id: 0, role: '', description: '', system: false },
    };
  },

  computed: {
    filtered() {
      const q = (this.filter_text || '').trim().toLowerCase();
      if (!q) return this.users;
      return this.users.filter(u =>
        (u.full_name || '').toLowerCase().includes(q) ||
        (u.email || '').toLowerCase().includes(q) ||
        (u.mobile || '').toLowerCase().includes(q) ||
        (u.first_name || '').toLowerCase().includes(q) ||
        (u.last_name || '').toLowerCase().includes(q));
    },

    adminCount() {
      const adminGroup = this.groups.find(g => g.role === 'admin');
      if (!adminGroup) return 0;
      return this.users.filter(u => u.role_ids.includes(adminGroup.id)).length;
    },

    mustChangeCount() {
      return this.users.filter(u => u.must_change_password).length;
    },
  },

  created() {
    this.refresh();
    window.addEventListener('keydown', this.on_key);
  },

  unmounted() {
    window.removeEventListener('keydown', this.on_key);
  },

  methods: {
    on_key(e) {
      if (e.key === 'Escape') {
        if (this.user_modal_open) this.close_user_modal();
        else if (this.roles_modal_open) this.close_roles_modal();
        else if (this.reset_modal_open) this.close_reset_modal();
        else if (this.group_modal_open) this.close_group_modal();
      }
    },

    refresh() {
      this.loading = true;
      const p1 = axios.get(this.apiBase + 'list_app_users');
      const p2 = axios.get(this.apiBase + 'list_auth_groups');
      Promise.all([p1, p2]).then(([rUsers, rGroups]) => {
        const du = rUsers.data || {};
        const dg = rGroups.data || {};
        this.users = du.rows || [];
        // الأدوار من list_auth_groups (تحوي description + members_count)
        this.groups = dg.rows || [];
        this.hasMustChange = !!du.has_must_change_field;
        this.loading = false;
      }).catch(err => {
        this.loading = false;
        AccUI && AccUI.toastError ?
          AccUI.toastError('تعذّر التحميل', (err.response && err.response.data && err.response.data.mess) || 'تأكد من الاتصال') :
          Swal.fire({ icon: 'error', title: 'تعذّر التحميل' });
      });
    },

    roleLabel(gid) {
      const g = this.groups.find(x => x.id === gid);
      return g ? g.role : '?';
    },

    roleChipClass(gid) {
      const g = this.groups.find(x => x.id === gid);
      if (!g) return 'is-custom';
      return ROLE_CLASSES[g.role] || 'is-custom';
    },

    // ===== User CRUD =====
    open_new_user() {
      this.user_form = { id: 0, first_name: '', last_name: '', email: '', mobile: '', password: '' };
      this.user_modal_open = true;
      this.$nextTick(() => { if (this.$refs.firstNameInput) this.$refs.firstNameInput.focus(); });
    },

    open_edit_user(u) {
      this.user_form = {
        id: u.id, first_name: u.first_name || '', last_name: u.last_name || '',
        email: u.email || '', mobile: u.mobile || '', password: '',
      };
      this.user_modal_open = true;
      this.$nextTick(() => { if (this.$refs.firstNameInput) this.$refs.firstNameInput.focus(); });
    },

    close_user_modal() { this.user_modal_open = false; },

    save_user() {
      const f = this.user_form;
      if (!f.first_name || !f.first_name.trim()) {
        Swal.fire({ icon: 'warning', title: 'الاسم الأول مطلوب' }); return;
      }
      if (!f.email || !f.email.trim()) {
        Swal.fire({ icon: 'warning', title: 'البريد الإلكتروني مطلوب' }); return;
      }
      this.saving = true;
      const payload = new FormData();
      if (f.id) payload.append('id', f.id);
      payload.append('first_name', f.first_name.trim());
      payload.append('last_name', f.last_name.trim());
      payload.append('email', f.email.trim().toLowerCase());
      payload.append('mobile', (f.mobile || '').trim());
      if (f.password) payload.append('password', f.password);
      axios.post(this.apiBase + 'save_app_user', payload)
        .then(r => {
          this.saving = false;
          const d = r.data || {};
          if (d.err === 0) {
            this.close_user_modal();
            this.refresh();
            this._toast(f.id ? 'تم التحديث' : 'تمت الإضافة');
          } else {
            Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || '' });
          }
        })
        .catch(() => {
          this.saving = false;
          Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
        });
    },

    // ===== Roles assignment =====
    open_roles(u) {
      this.roles_form = {
        user_id: u.id, full_name: u.full_name,
        role_ids: u.role_ids.slice(),
      };
      this.roles_modal_open = true;
    },

    close_roles_modal() { this.roles_modal_open = false; },

    save_roles() {
      this.saving = true;
      const payload = new FormData();
      payload.append('user_id', this.roles_form.user_id);
      payload.append('role_ids', this.roles_form.role_ids.join(','));
      axios.post(this.apiBase + 'set_user_roles', payload)
        .then(r => {
          this.saving = false;
          const d = r.data || {};
          if (d.err === 0) {
            this.close_roles_modal();
            this.refresh();
            this._toast('تم تحديث الأدوار');
          } else {
            Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || '' });
          }
        })
        .catch(() => {
          this.saving = false;
          Swal.fire({ icon: 'error', title: 'تعذّر الاتصال' });
        });
    },

    // ===== Reset password =====
    open_reset_pw(u) {
      this.reset_form = {
        user_id: u.id, full_name: u.full_name,
        password: this._suggestPassword(),
      };
      this.reset_modal_open = true;
      this.$nextTick(() => {
        if (this.$refs.resetInput) {
          this.$refs.resetInput.focus();
          this.$refs.resetInput.select();
        }
      });
    },

    close_reset_modal() { this.reset_modal_open = false; },

    confirm_reset() {
      if (!this.reset_form.password || this.reset_form.password.length < 4) {
        Swal.fire({ icon: 'warning', title: 'كلمة المرور قصيرة', text: '٤ أحرف على الأقل' });
        return;
      }
      this.saving = true;
      const payload = new FormData();
      payload.append('id', this.reset_form.user_id);
      payload.append('password', this.reset_form.password);
      axios.post(this.apiBase + 'reset_user_password', payload)
        .then(r => {
          this.saving = false;
          const d = r.data || {};
          if (d.err === 0) {
            const pwd = this.reset_form.password;
            this.close_reset_modal();
            this.refresh();
            Swal.fire({
              icon: 'success',
              title: 'تمت إعادة التعيين',
              html: 'كلمة المرور الجديدة: <code style="font-size:1.2rem;">' + pwd + '</code><br><small>سيُجبَر المستخدم على تغييرها عند الدخول التالي.</small>',
            });
          } else {
            Swal.fire({ icon: 'error', title: 'تعذّر', text: d.mess || '' });
          }
        })
        .catch(() => {
          this.saving = false;
          Swal.fire({ icon: 'error', title: 'تعذّر الاتصال' });
        });
    },

    toggle_must(u) {
      const payload = new FormData();
      payload.append('id', u.id);
      axios.post(this.apiBase + 'toggle_must_change', payload)
        .then(r => {
          const d = r.data || {};
          if (d.err === 0) {
            u.must_change_password = !!d.must;
            this._toast(d.must ? 'تم إجبار التغيير' : 'أُلغيَ إجبار التغيير');
          } else {
            Swal.fire({ icon: 'error', title: 'تعذّر', text: d.mess || '' });
          }
        }).catch(() => Swal.fire({ icon: 'error', title: 'تعذّر الاتصال' }));
    },

    // ===== Groups CRUD =====
    open_new_group() {
      this.group_form = { id: 0, role: '', description: '', system: false };
      this.group_modal_open = true;
      this.$nextTick(() => { if (this.$refs.groupInput) this.$refs.groupInput.focus(); });
    },

    open_edit_group(g) {
      this.group_form = {
        id: g.id, role: g.role || '', description: g.description || '',
        system: !!g.system,
      };
      this.group_modal_open = true;
    },

    close_group_modal() { this.group_modal_open = false; },

    save_group() {
      const f = this.group_form;
      if (!f.role || !f.role.trim()) {
        Swal.fire({ icon: 'warning', title: 'اسم الدور مطلوب' }); return;
      }
      this.saving = true;
      const payload = new FormData();
      if (f.id) payload.append('id', f.id);
      payload.append('role', f.role.trim());
      payload.append('description', f.description || '');
      axios.post(this.apiBase + 'save_auth_group', payload)
        .then(r => {
          this.saving = false;
          const d = r.data || {};
          if (d.err === 0) {
            this.close_group_modal();
            this.refresh();
            this._toast(f.id ? 'تم التحديث' : 'تمت الإضافة');
          } else {
            Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || '' });
          }
        })
        .catch(() => {
          this.saving = false;
          Swal.fire({ icon: 'error', title: 'تعذّر الاتصال' });
        });
    },

    delete_group(g) {
      if (g.system || g.members_count > 0) return;
      Swal.fire({
        icon: 'warning',
        title: 'حذف الدور: ' + g.role + '؟',
        text: 'لا يمكن التراجع.',
        showCancelButton: true,
        confirmButtonText: 'نعم احذف',
        cancelButtonText: 'إلغاء',
        confirmButtonColor: '#dc3545',
      }).then(res => {
        if (!res.isConfirmed) return;
        const payload = new FormData();
        payload.append('id', g.id);
        axios.post(this.apiBase + 'delete_auth_group', payload).then(r => {
          const d = r.data || {};
          if (d.err === 0) { this.refresh(); this._toast('تم الحذف'); }
          else Swal.fire({ icon: 'error', title: 'تعذّر', text: d.mess || '' });
        }).catch(() => Swal.fire({ icon: 'error', title: 'تعذّر الاتصال' }));
      });
    },

    // ===== Helpers =====
    _toast(msg) {
      if (window.AccUI && AccUI.toastInfo) {
        AccUI.toastInfo(msg);
      } else {
        Swal.fire({
          icon: 'success', title: msg, toast: true,
          position: 'top-end', showConfirmButton: false, timer: 1800,
        });
      }
    },

    _suggestPassword() {
      const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
      let s = '';
      for (let i = 0; i < 10; i++) s += chars[Math.floor(Math.random() * chars.length)];
      return s;
    },
  },
});

const app = vueApp.mount('#app');
