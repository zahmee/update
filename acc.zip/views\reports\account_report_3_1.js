// ======================  إجماليات الحسابات حسب الفرع — منطق Vue 3  ======================
// مصفوفة [حسابات × فروع] تُظهر مدين/دائن/صافي لكل تقاطع.

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_branches_api/',
            settingApi: window.purl + '/../../setting_api/',
            opsApi: window.purl + '/../../operations_api/',

            branches: [],
            periods: [],
            accounts: [],
            selectedAccounts: [],
            sourceBranch: 0,
            includeOpening: false,
            hideZeroRows: false,

            filters: {
                period: 0,
                date_from: '',
                date_to: '',
            },

            data: null,
            loading: false,
            _loadSeq: 0,
            _accountsT: null,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        canQuery() {
            return this.sourceBranch > 0
                && this.filters.period > 0
                && this.selectedAccounts.length > 0;
        },
        visibleAccounts() {
            if (!this.data) return [];
            if (!this.hideZeroRows) return this.data.accounts;
            return this.data.accounts.filter(a => (a.total.debit !== 0 || a.total.credit !== 0));
        },
    },

    watch: {
        selectedAccounts: {
            handler(newVal) {
                var self = this;
                if (this._accountsT) clearTimeout(this._accountsT);
                this._accountsT = setTimeout(() => {
                    if (newVal && newVal.length > 0 && self.canQuery) {
                        self.reload();
                    } else if (!newVal || !newVal.length) {
                        self.data = null;
                    }
                }, 300);
            },
            deep: true,
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.sourceBranch = main.id;
                else if (self.branches.length === 1) self.sourceBranch = self.branches[0].id;
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                if (self.sourceBranch > 0 && self.filters.period > 0) {
                    self.loadAccounts();
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        loadAccounts() {
            var self = this;
            this.accounts = [];
            this.selectedAccounts = [];
            axios.get(this.opsApi + 'get_accounts_for_journal/' + this.sourceBranch + '/' + this.filters.period)
                .then(res => {
                    var rows = (res.data && res.data.accounts) || res.data || [];
                    self.accounts = (Array.isArray(rows) ? rows : []).map(a => ({
                        id: a.id,
                        account_no: a.account_no,
                        name: a.account_name_ar || a.account_name || '',
                        parent_name: a.parent_name || '',
                        label: a.account_no + ' — ' + (a.account_name_ar || a.account_name || ''),
                    }));
                }).catch(() => {
                    Swal.fire({ icon: 'warning', title: 'تعذّر تحميل قائمة الحسابات' });
                });
        },

        onSourceBranchChange() {
            this.data = null;
            if (this.sourceBranch > 0 && this.filters.period > 0) this.loadAccounts();
        },

        onPeriodChange() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                if (p.start_date) this.filters.date_from = p.start_date;
                if (p.end_date) this.filters.date_to = p.end_date;
            }
            this.data = null;
            if (this.sourceBranch > 0 && this.filters.period > 0) this.loadAccounts();
        },

        onFilterChange() { if (this.canQuery) this.reload(); },

        resetToFullPeriod() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                this.filters.date_from = p.start_date || '';
                this.filters.date_to = p.end_date || '';
                this.reload();
            }
        },

        clearAccounts() { this.selectedAccounts = []; this.data = null; },

        reload() {
            if (!this.canQuery) return;
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            var body = {
                period: this.filters.period,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || '',
                account_ids: this.selectedAccounts.map(a => a.id),
                include_opening: this.includeOpening,
            };
            axios.post(this.api + 'account_branches_matrix/', body).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: d.mess || 'تعذّر تحميل التقرير' });
                    self.data = null;
                } else {
                    self.data = d;
                }
            }).catch(err => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'خطأ في الاتصال', text: (err && err.message) || '' });
                self.data = null;
            }).finally(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        fmtCell(cell, side) {
            if (!cell) return '—';
            var v = Number(cell[side] || 0);
            if (v === 0) return '—';
            return fmtNumber(v);
        },

        cellClass(cell, side) {
            if (!cell) return 'is-zero';
            var v = Number(cell[side] || 0);
            if (v === 0) return 'is-zero';
            return side === 'debit' ? 'is-debit' : 'is-credit';
        },

        fmtNet(n) {
            var v = Number(n) || 0;
            if (v === 0) return '0.00';
            if (v > 0) return fmtNumber(v) + ' (مدين)';
            return fmtNumber(-v) + ' (دائن)';
        },

        netClass(n) {
            var v = Number(n) || 0;
            if (v > 0) return 'is-debit';
            if (v < 0) return 'is-credit';
            return 'is-zero';
        },

        fmt(n) { return fmtNumber(n); },

        printReport() { window.print(); },

        exportCSV() {
            if (!this.data) return;
            var brs = this.data.branches;
            var head = ['الحساب رقم', 'الحساب اسم', 'مرجع'];
            brs.forEach(b => {
                head.push(b.name + ' - مدين');
                head.push(b.name + ' - دائن');
            });
            head.push('إجمالي - مدين');
            head.push('إجمالي - دائن');
            head.push('صافي');
            var rows = [head];
            this.visibleAccounts.forEach(a => {
                var row = [a.account_no, a.account_name, a.is_parent ? 'مجمَّع' : ''];
                brs.forEach(b => {
                    var c = a.by_branch[b.id] || { debit: 0, credit: 0 };
                    row.push(fmtNumber(c.debit));
                    row.push(fmtNumber(c.credit));
                });
                row.push(fmtNumber(a.total.debit));
                row.push(fmtNumber(a.total.credit));
                row.push(fmtNumber(a.total.net));
                rows.push(row);
            });
            var foot = ['', 'إجمالي عمود', ''];
            brs.forEach(b => {
                var g = this.data.grand_by_branch[b.id];
                foot.push(fmtNumber(g.debit));
                foot.push(fmtNumber(g.credit));
            });
            foot.push(fmtNumber(this.data.grand.debit));
            foot.push(fmtNumber(this.data.grand.credit));
            foot.push(fmtNumber(this.data.grand.net));
            rows.push(foot);

            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'account_branches_matrix_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
