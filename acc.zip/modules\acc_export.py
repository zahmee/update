# -*- coding: utf-8 -*-
"""
acc_export — تصدير التقارير إلى Excel (xlsx).

يستخدم openpyxl (مثبَّت في بيئة web2py؛ إن لم يكن: `pip install openpyxl`).

العقد الموحَّد لتمرير البيانات:
- title    : عنوان التقرير (يظهر في الصف الأول)
- meta     : list من (label, value) — معلومات السياق (الفرع، الدورة، التاريخ، إلخ)
- columns  : list من dicts {key, title, format?, width?, align?}
             format: "number" | "currency" | "date" | "text" (افتراضي text)
             align:  "start" | "center" | "end" (افتراضي start)
- rows     : list من dicts (مفاتيحها = column keys)
- totals   : dict اختياري بنفس مفاتيح الأعمدة → صف إجمالي
- footer   : list من tuples (label, value) إضافية أسفل الجدول
- sheet_name: اسم الورقة (افتراضي: "تقرير")

الدالة `xlsx_response(filename, **kwargs)` تُهيّئ ردّ web2py مباشرة.

التنسيقات:
- الترويسة: خلفية رمادية + خط أبيض + توسيط
- الأرقام والعملات: tabular numerals + 2 خانة عشرية
- الإجمالي: خط عريض + خلفية رمادية فاتحة
- RTL تلقائي (الأعمدة من اليمين لليسار)
"""

from io import BytesIO

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    Workbook = None


# ============================ ثوابت تنسيق ============================
_HEAD_FILL = "374151"
_HEAD_FONT_COLOR = "FFFFFF"
_TOTAL_FILL = "E5E7EB"
_META_FILL = "F3F4F6"
_BORDER = Side(border_style="thin", color="9CA3AF") if Workbook else None
_FMT_CURRENCY = "#,##0.00;[Red]-#,##0.00;\"—\""
_FMT_NUMBER = "#,##0;[Red]-#,##0;\"—\""
_FMT_DATE = "YYYY-MM-DD"


def to_xlsx_bytes(title, columns, rows, meta=None, totals=None,
                  footer=None, sheet_name="تقرير"):
    """يبني ملف xlsx ويُرجع bytes جاهزة للإرسال."""
    if Workbook is None:
        raise RuntimeError("openpyxl غير مثبَّت — `pip install openpyxl`")

    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31] or "تقرير"
    ws.sheet_view.rightToLeft = True

    n_cols = len(columns)
    cur_row = 1

    # ----- عنوان التقرير -----
    if title:
        ws.cell(row=cur_row, column=1, value=str(title))
        ws.merge_cells(start_row=cur_row, end_row=cur_row,
                      start_column=1, end_column=n_cols)
        c = ws.cell(row=cur_row, column=1)
        c.font = Font(bold=True, size=14, color="111827")
        c.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[cur_row].height = 24
        cur_row += 1

    # ----- ميتاداتا (الفرع، الدورة، إلخ) -----
    if meta:
        for label, value in meta:
            ws.cell(row=cur_row, column=1, value=str(label))
            c1 = ws.cell(row=cur_row, column=1)
            c1.font = Font(bold=True, color="374151")
            c1.fill = PatternFill("solid", fgColor=_META_FILL)
            c1.alignment = Alignment(horizontal="left")  # left فعلياً = "end" في RTL
            ws.cell(row=cur_row, column=2, value=value if value is not None else "—")
            if n_cols > 2:
                ws.merge_cells(start_row=cur_row, end_row=cur_row,
                              start_column=2, end_column=n_cols)
            cur_row += 1
        cur_row += 1  # صف فارغ

    # ----- ترويسة الأعمدة -----
    head_row = cur_row
    for ci, col in enumerate(columns, 1):
        c = ws.cell(row=head_row, column=ci, value=str(col.get("title", "")))
        c.font = Font(bold=True, color=_HEAD_FONT_COLOR, size=11)
        c.fill = PatternFill("solid", fgColor=_HEAD_FILL)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = Border(top=_BORDER, bottom=_BORDER, left=_BORDER, right=_BORDER)
    ws.row_dimensions[head_row].height = 22
    cur_row += 1

    # ----- صفوف البيانات -----
    for r in rows:
        for ci, col in enumerate(columns, 1):
            key = col["key"]
            value = r.get(key) if isinstance(r, dict) else None
            c = ws.cell(row=cur_row, column=ci, value=_normalize_value(value, col))
            _apply_cell_format(c, col, is_total=False)
        cur_row += 1

    # ----- صف الإجمالي -----
    if totals:
        for ci, col in enumerate(columns, 1):
            key = col["key"]
            value = totals.get(key, "")
            c = ws.cell(row=cur_row, column=ci, value=_normalize_value(value, col))
            _apply_cell_format(c, col, is_total=True)
            c.font = Font(bold=True, color="111827")
            c.fill = PatternFill("solid", fgColor=_TOTAL_FILL)
        cur_row += 1

    # ----- footer إضافي -----
    if footer:
        cur_row += 1
        for label, value in footer:
            ws.cell(row=cur_row, column=1, value=str(label))
            ws.cell(row=cur_row, column=1).font = Font(italic=True, color="6B7280")
            ws.cell(row=cur_row, column=2, value=value if value is not None else "")
            cur_row += 1

    # ----- عرض الأعمدة -----
    for ci, col in enumerate(columns, 1):
        width = col.get("width") or _auto_width(col, rows)
        ws.column_dimensions[get_column_letter(ci)].width = width

    # ----- تجميد ترويسة الجدول -----
    ws.freeze_panes = ws.cell(row=head_row + 1, column=1)

    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()


def xlsx_response(response, filename, **kwargs):
    """يبني ردّ web2py مع headers مناسبة لتنزيل Excel.

    الاستخدام داخل controller:
        return acc_export.xlsx_response(response, "trial_balance.xlsx",
                                        title="ميزان المراجعة", columns=[...], rows=[...])
    """
    data = to_xlsx_bytes(**kwargs)
    response.headers["Content-Type"] = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response.headers["Content-Disposition"] = (
        'attachment; filename="%s"' % (filename or "report.xlsx")
    )
    return data


# ============================ helpers داخلية ============================

def _normalize_value(value, col):
    """يحوّل القيمة لنوع openpyxl يفهمه (number/string/date)."""
    fmt = (col.get("format") or "text").lower()
    if value is None or value == "":
        return None
    if fmt in ("number", "currency"):
        try:
            return float(value)
        except Exception:
            return value
    return value


def _apply_cell_format(cell, col, is_total=False):
    """يطبّق التنسيق على خلية حسب نوع العمود."""
    fmt = (col.get("format") or "text").lower()
    align = (col.get("align") or _default_align(fmt)).lower()
    horizontal = {"start": "right", "center": "center", "end": "left"}.get(align, "right")
    cell.alignment = Alignment(horizontal=horizontal, vertical="center")
    cell.border = Border(top=_BORDER, bottom=_BORDER, left=_BORDER, right=_BORDER)
    if fmt == "currency":
        cell.number_format = _FMT_CURRENCY
    elif fmt == "number":
        cell.number_format = _FMT_NUMBER
    elif fmt == "date":
        cell.number_format = _FMT_DATE


def _default_align(fmt):
    if fmt in ("number", "currency"):
        return "end"
    if fmt == "date":
        return "center"
    return "start"


def _auto_width(col, rows):
    """تخمين عرض عمود تقريبي بناءً على العنوان وأطول قيمة في الصفوف."""
    title_len = len(str(col.get("title", "")))
    key = col.get("key")
    sample_lens = [
        len(str(r.get(key))) for r in (rows or [])[:200]
        if isinstance(r, dict) and r.get(key) is not None
    ]
    max_data = max(sample_lens) if sample_lens else 0
    fmt = (col.get("format") or "text").lower()
    base = max(title_len, max_data) + 2
    if fmt in ("number", "currency"):
        base = max(base, 12)
    return min(max(base, 8), 40)
