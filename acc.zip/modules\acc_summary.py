# -*- coding: utf-8 -*-
"""
acc_summary — ملخّص الحسابات الرئيسية (لكشف الحساب المخصص account_report_2).

دالتان (DI بـ `db`):
- compute_account_totals   — إجماليات حساب فقط (افتتاحي/حركة/ختامي) بلا جلب الحركات.
- build_children_summary   — عند اختيار حساب رئيسي: صف إجماليات لكل حساب فرعي مباشر.

فُصلت عن acc_balance في وحدة مستقلة (2026-07-25) لتُحمَّل طازجة على الخوادم
العاملة دون إعادة تشغيل — web2py يُخزّن وحدات modules/ ولا يعيد تحميل المعدَّلة
منها في وضع الإنتاج، لكنه يُحمّل الوحدات الجديدة عند أول استيراد.

المنطق يطابق acc_balance.build_account_statement (نفس LIKE rollup وقواعد الافتتاحي).
"""


def compute_account_totals(db, branch_id, period_id, account_no, date_from, date_to):
    """يحسب إجماليات حساب فقط (بدون جلب الحركات) عبر LIKE rollup — أخفّ من
    build_account_statement. يُستخدم لبناء ملخّص الحسابات الفرعية لحساب رئيسي.

    account_no : str — رقم الحساب (يُطبَّق LIKE 'account_no%' لضمّ كل الفروع)
    Returns dict {opening:{debit,credit,net}, totals:{debit,credit,net_movement},
                  ending:{debit,credit,net}}
    """
    like_pat = str(account_no) + "%"

    # افتتاحي الدورة من account_periods_opening
    opening_rows = db.executesql(
        "SELECT COALESCE(SUM(debit),0)::float, COALESCE(SUM(credit),0)::float "
        "FROM account_periods_opening "
        "WHERE branches = %s AND account_periods = %s AND account_no LIKE %s",
        placeholders=[branch_id, period_id, like_pat],
    )
    od = float(opening_rows[0][0] or 0) if opening_rows else 0.0
    oc = float(opening_rows[0][1] or 0) if opening_rows else 0.0

    # حركة ما قبل date_from → تُضاف للافتتاحي
    pre_rows = db.executesql(
        "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
        "FROM journal_entry_detail jed "
        "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
        "WHERE jem.is_active = 'T' "
        "  AND jed.branches = %s AND jed.account_periods = %s "
        "  AND jed.account_no LIKE %s AND jed.journal_date < %s",
        placeholders=[branch_id, period_id, like_pat, str(date_from)],
    )
    pd_ = float(pre_rows[0][0] or 0) if pre_rows else 0.0
    pc = float(pre_rows[0][1] or 0) if pre_rows else 0.0
    opening_net = round((od + pd_) - (oc + pc), 2)

    # حركة الفترة (date_from..date_to)
    per_rows = db.executesql(
        "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
        "FROM journal_entry_detail jed "
        "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
        "WHERE jem.is_active = 'T' "
        "  AND jed.branches = %s AND jed.account_periods = %s "
        "  AND jed.account_no LIKE %s "
        "  AND jed.journal_date >= %s AND jed.journal_date <= %s",
        placeholders=[branch_id, period_id, like_pat, str(date_from), str(date_to)],
    )
    td = round(float(per_rows[0][0] or 0) if per_rows else 0.0, 2)
    tc = round(float(per_rows[0][1] or 0) if per_rows else 0.0, 2)
    final_net = round(opening_net + td - tc, 2)

    return {
        "opening": {
            "debit": round(opening_net, 2) if opening_net >= 0 else 0.0,
            "credit": round(-opening_net, 2) if opening_net < 0 else 0.0,
            "net": round(opening_net, 2),
        },
        "totals": {
            "debit": td,
            "credit": tc,
            "net_movement": round(td - tc, 2),
        },
        "ending": {
            "debit": round(final_net, 2) if final_net >= 0 else 0.0,
            "credit": round(-final_net, 2) if final_net < 0 else 0.0,
            "net": final_net,
        },
    }


def build_children_summary(db, branch_id, period_id, account_id, date_from, date_to):
    """ملخّص حساب رئيسي: صف إجماليات لكل حساب فرعي مباشر + إجمالي الأب.

    يُرجع None إذا: الحساب غير موجود / لا ينتمي للفرع / **ليس حساباً رئيسياً**
    (ليس له أبناء) — عندها يستخدم المتصل build_account_statement بدلاً منه.

    عند وجود أبناء يُرجع dict بمفاتيح كشف الحساب (account/opening/totals/ending)
    مضافاً إليها: is_summary=True, children=[{account, opening, totals, ending}, ...].

    إجمالي الأب = مجموع أعمدة فروعه المباشرة (يساوي دائماً مجموع الصفوف المعروضة).
    """
    acc = db.accounting_tree[account_id]
    if not acc:
        return None
    if int(acc.branches) != int(branch_id):
        return None

    # الأبناء المباشرون (main_account == رقم هذا الحساب)
    children = db(
        (db.accounting_tree.main_account == acc.account_no)
        & (db.accounting_tree.branches == branch_id)
        & (db.accounting_tree.account_periods == period_id)
    ).select(orderby=db.accounting_tree.account_no)
    if not children:
        return None  # حساب فرعي (ورقي) — ليس ملخّصاً

    # اسم الأب (سياق العرض)
    parent_name = ""
    if acc.main_account and acc.main_account != "0":
        pr = db(
            (db.accounting_tree.account_no == acc.main_account)
            & (db.accounting_tree.branches == branch_id)
            & (db.accounting_tree.account_periods == period_id)
        ).select(db.accounting_tree.account_name_ar).first()
        if pr:
            parent_name = pr.account_name_ar or ""

    # أرقام الحسابات التي هي آباء — لتمييز الابن الذي هو بدوره حساب رئيسي
    parent_nos = set()
    for row in db.executesql(
        "SELECT DISTINCT main_account FROM accounting_tree "
        "WHERE branches = %s AND account_periods = %s "
        "  AND main_account IS NOT NULL AND main_account <> '0'",
        placeholders=[branch_id, period_id],
    ):
        if row and row[0]:
            parent_nos.add(row[0])

    # إجمالي الأب = مجموع أعمدة فروعه المباشرة → التذييل يساوي دائماً مجموع الصفوف
    # المعروضة (بخلاف LIKE rollup الذي قد يضمّ حسابات تبدأ بنفس البادئة دون أن
    # تكون أبناءً مباشرين — مثل "10" تحت البادئة "1").
    child_items = []
    od = oc = md = mc = ed = ec = 0.0
    for ch in children:
        t = compute_account_totals(db, branch_id, period_id, ch.account_no,
                                   date_from, date_to)
        child_items.append({
            "account": {
                "id": int(ch.id),
                "account_no": ch.account_no,
                "account_name": ch.account_name_ar or "",
                "account_type": int(ch.account_type or 0),
                "final_account": int(ch.final_account or 0),
                "is_parent": ch.account_no in parent_nos,
            },
            "opening": t["opening"],
            "totals": t["totals"],
            "ending": t["ending"],
        })
        od += t["opening"]["debit"]
        oc += t["opening"]["credit"]
        md += t["totals"]["debit"]
        mc += t["totals"]["credit"]
        ed += t["ending"]["debit"]
        ec += t["ending"]["credit"]

    od, oc, md, mc, ed, ec = (round(od, 2), round(oc, 2), round(md, 2),
                              round(mc, 2), round(ed, 2), round(ec, 2))

    return {
        "is_summary": True,
        "account": {
            "id": int(acc.id),
            "account_no": acc.account_no,
            "account_name": acc.account_name_ar or "",
            "parent_name": parent_name,
            "main_account": acc.main_account or "0",
            "account_type": int(acc.account_type or 0),
            "final_account": int(acc.final_account or 0),
            "children_count": len(children),
            "is_parent": True,
            "is_rolled": True,
        },
        "children": child_items,
        "opening": {"debit": od, "credit": oc, "net": round(od - oc, 2)},
        "totals": {"debit": md, "credit": mc,
                   "net_movement": round(md - mc, 2), "count": 0},
        "ending": {"debit": ed, "credit": ec, "net": round(ed - ec, 2)},
    }
