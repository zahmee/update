// ======================  كشف حساب — منطق Vue 3  ======================
// تقرير حركة حساب واحد + رصيد متحرّك. عقد API الجديد يُرجع payload نظيف:
//   {account, branch, period, opening, movements, totals, ending}
// قائمة الحسابات تُحمَّل عند تغيير الفرع/الدورة.

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_account_api/',
            settingApi: window.purl + '/../../setting_api/',
            opsApi: window.purl + '/../../operations_api/',
            printJournalURL: window.printJournalURL,

            branches: [],
            periods: [],
            accounts: [],
            selectedAccount: null,

            filters: {
                branch: 0,
                period: 0,
                account_id: 0,
                date_from: '',
                date_to: '',
            },

            data: null,
            loading: false,
            _loadSeq: 0,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        canQuery() {
            return this.filters.branch > 0 && this.filters.period > 0 && this.filters.account_id > 0;
        },
    },

    watch: {
        // v-model على vue-select يحدّث selectedAccount لكن @update:modelValue
        // غير موثوق في v4 — نستخدم watcher بدلاً
        selectedAccount(newVal) {
            if (newVal && newVal.id) {
                this.filters.account_id = Number(newVal.id);
                this.reload();
            } else {
                this.filters.account_id = 0;
                this.data = null;
            }
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                // افتراضيات
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.filters.branch = main.id;
                else if (self.branches.length === 1) self.filters.branch = self.branches[0].id;
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                if (self.filters.branch > 0 && self.filters.period > 0) {
                    self.loadAccounts();
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        loadAccounts() {
            if (!(this.filters.branch > 0 && this.filters.period > 0)) {
                this.accounts = [];
                return;
            }
            var self = this;
            axios.get(this.opsApi + 'get_accounts_for_journal/'
                      + this.filters.branch + '/' + this.filters.period).then(r => {
                var d = r.data || {};
                if (d.err) {
                    self.accounts = [];
                } else {
                    self.accounts = d.accounts || [];
                }
            }).catch(() => { self.accounts = []; });
        },

        onBranchChange() {
            this.selectedAccount = null;
            this.filters.account_id = 0;
            this.data = null;
            this.loadAccounts();
        },

        onPeriodChange() {
            // اختيار دورة → ملء التواريخ
            if (this.filters.period > 0) {
                var p = this.periods.find(p => Number(p.id) === Number(this.filters.period));
                if (p) {
                    if (p.start_date) this.filters.date_from = p.start_date;
                    if (p.end_date) this.filters.date_to = p.end_date;
                }
            }
            this.selectedAccount = null;
            this.filters.account_id = 0;
            this.data = null;
            this.loadAccounts();
        },

        // (احتفاظ بـ method للتوافق العكسي — الـ watcher على selectedAccount هو المعتمد)
        onAccountChange(acc) {
            // الـ watcher يهتم بالتحديث؛ هذا hook للاستدعاء البرمجي الصريح
            this.selectedAccount = acc;
        },

        onFilterChange() {
            if (this.canQuery) this.reload();
        },

        reload() {
            if (!this.canQuery) return;
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            axios.post(this.api + 'acount_balanc/', this.filters).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess });
                    self.data = null;
                } else {
                    self.data = d;
                }
            }).catch(() => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                self.data = null;
            }).then(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        resetToFullPeriod() {
            if (!this.data) return;
            this.filters.date_from = this.data.period.start_date || '';
            this.filters.date_to = this.data.period.end_date || '';
            this.reload();
        },

        printReport() {
            this.now_str = new Date().toLocaleString('en-GB');
            this.$nextTick(() => window.print());
        },

        exportExcel() {
            if (!this.data) return;
            var params = new URLSearchParams();
            Object.keys(this.filters).forEach(k => {
                var v = this.filters[k];
                if (v !== '' && v !== null && v !== undefined) params.append(k, v);
            });
            params.append('format', 'xlsx');
            window.open(this.api + 'acount_balanc?' + params.toString(), '_blank');
        },

        exportCSV() {
            if (!this.data) return;
            var rows = [
                ['#', 'رقم القيد', 'التاريخ', 'رقم الحساب', 'اسم الحساب',
                 'بيان القيد', 'بيان السطر', 'مركز التكلفة', 'مدين', 'دائن', 'الرصيد'],
            ];
            // افتتاحي
            rows.push(['', '', this.filters.date_from, '', '',
                       'رصيد افتتاحي', '', '',
                       this.data.opening.debit, this.data.opening.credit,
                       this.data.opening.net]);
            // حركة
            this.data.movements.forEach((r, i) => {
                rows.push([
                    i + 1, r.journal_id, r.journal_date,
                    r.account_no, r.account_name,
                    r.master_detail, r.detail || '', r.cost_center_name || '',
                    r.debit, r.credit, r.running_balance,
                ]);
            });
            // إجمالي
            rows.push(['', '', '', '', '', 'إجمالي حركة الفترة', '', '',
                       this.data.totals.debit, this.data.totals.credit,
                       this.data.totals.net_movement]);
            // ختامي
            rows.push(['', '', this.filters.date_to, '', '',
                       'الرصيد الختامي', '', '',
                       this.data.ending.debit, this.data.ending.credit,
                       this.data.ending.net]);
            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'account_' + this.data.account.account_no + '_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        faLabel(v) {
            v = Number(v);
            return v === 1 ? 'ميزانية' : v === 2 ? 'أرباح وخسائر' : v === 3 ? 'متاجرة' : '';
        },

        fmt(n) { return fmtNumber(n); },
        fmtCell(n) {
            var v = Number(n) || 0;
            return v === 0 ? '—' : fmtNumber(v);
        },

        // وضع dropdown vue-select خارج overflow (نفس النمط من شاشة القيد)
        withPopper(dropdownList, component, { width }) {
            var toggle = component.$refs.toggle;
            if (!toggle) return function () {};
            var update = function () {
                var rect = toggle.getBoundingClientRect();
                var minWidth = Math.max(parseFloat(width) || 0, 380);
                dropdownList.style.position = 'absolute';
                dropdownList.style.top = (rect.bottom + window.scrollY + 2) + 'px';
                dropdownList.style.left = (rect.left + window.scrollX) + 'px';
                dropdownList.style.width = minWidth + 'px';
                dropdownList.style.maxHeight = '320px';
                dropdownList.style.overflowY = 'auto';
                dropdownList.style.zIndex = 9999;
                dropdownList.style.background = '#fff';
                dropdownList.style.border = '1px solid var(--line-2, #d6d6d6)';
                dropdownList.style.borderRadius = '8px';
                dropdownList.style.boxShadow = '0 8px 24px rgba(0,0,0,0.12)';
            };
            update();
            window.addEventListener('scroll', update, true);
            window.addEventListener('resize', update);
            return function () {
                window.removeEventListener('scroll', update, true);
                window.removeEventListener('resize', update);
            };
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
