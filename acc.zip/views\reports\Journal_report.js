// ======================  دفتر اليومية — منطق Vue 3  ======================
// تقرير قانوني — قائمة بكل قيود اليومية مع سطورها التفصيلية وإجماليات التوازن.
// عقد API الجديد: POST /reports_journal_api/Journal_report يقبل (branch, period, date_from, date_to, q)
// ويُرجع {entries: [{master, details, balance_ok, diff, sum_debit, sum_credit}], stats}

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_journal_api/',
            settingApi: window.purl + '/../../setting_api/',

            branches: [],
            periods: [],

            filters: {
                branch: 0,
                period: 0,
                date_from: '',
                date_to: '',
                q: '',
            },

            entries: [],
            stats: null,
            loading: true,

            _searchT: null,
            _loadSeq: 0,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        hasActiveFilters() {
            return this.filters.branch > 0
                || this.filters.period > 0
                || !!this.filters.date_from
                || !!this.filters.date_to
                || !!this.filters.q;
        },
        filterBranchName() {
            if (!this.filters.branch) return 'كل الفروع';
            var b = this.branches.find(b => Number(b.id) === Number(this.filters.branch));
            return b ? b.name : '—';
        },
        filterPeriodName() {
            if (!this.filters.period) return 'كل الدورات';
            var p = this.periods.find(p => Number(p.id) === Number(this.filters.period));
            return p ? p.disc : '—';
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                // افتراضياً: أول دورة مفتوحة
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                self.reload();
            }).catch(() => {
                self.loading = false;
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        reload() {
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            axios.post(this.api + 'Journal_report/', this.filters).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess });
                    self.entries = []; self.stats = null;
                } else {
                    self.entries = d.entries || [];
                    self.stats = d.stats || null;
                }
            }).catch(() => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                self.entries = []; self.stats = null;
            }).then(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        onFilterChange() { this.reload(); },

        onPeriodChange() {
            // عند اختيار دورة، نملأ تلقائياً مدى تاريخها (إن كانت الحقول فارغة)
            if (this.filters.period > 0) {
                var p = this.periods.find(p => Number(p.id) === Number(this.filters.period));
                if (p) {
                    if (p.start_date) this.filters.date_from = p.start_date;
                    if (p.end_date) this.filters.date_to = p.end_date;
                }
            }
            this.reload();
        },

        onSearchInput() {
            var self = this;
            if (this._searchT) clearTimeout(this._searchT);
            this._searchT = setTimeout(() => { self.reload(); }, 350);
        },

        clearFilters() {
            this.filters.branch = 0;
            this.filters.period = 0;
            this.filters.date_from = '';
            this.filters.date_to = '';
            this.filters.q = '';
            this.reload();
        },

        printReport() {
            this.now_str = new Date().toLocaleString('en-GB');
            this.$nextTick(() => window.print());
        },

        exportExcel() {
            if (!this.entries.length) return;
            var params = new URLSearchParams();
            Object.keys(this.filters).forEach(k => {
                var v = this.filters[k];
                if (v !== '' && v !== null && v !== undefined) params.append(k, v);
            });
            params.append('format', 'xlsx');
            window.open(this.api + 'Journal_report?' + params.toString(), '_blank');
        },

        exportCSV() {
            if (!this.entries.length) return;
            var rows = [
                ['رقم القيد', 'التاريخ', 'الفرع', 'الدورة', 'البيان الإجمالي',
                 'رقم الحساب', 'اسم الحساب', 'بيان السطر', 'مركز التكلفة', 'مدين', 'دائن'],
            ];
            this.entries.forEach(e => {
                e.details.forEach(d => {
                    rows.push([
                        e.master.id, e.master.journal_date, e.master.branch_name,
                        e.master.period_disc, e.master.journal_detail,
                        d.account_no, d.account_name, d.detail || '',
                        d.cost_center_name || '', d.debit, d.credit,
                    ]);
                });
                // سطر إجمالي القيد
                rows.push(['', '', '', '', 'إجمالي القيد ' + e.master.id, '', '', '', '',
                           e.sum_debit, e.sum_credit]);
            });
            // إجمالي الدفتر
            if (this.stats) {
                rows.push(['', '', '', '', '', '', '', '', 'الإجمالي العام',
                           this.stats.debit, this.stats.credit]);
            }
            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'journal_report_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        fmt(n) { return fmtNumber(n); },
    },
});

var app = vueApp.mount('#app');
