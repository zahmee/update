# -*- coding: utf-8 -*-
# type: ignore
"""
setting_users_api — إدارة المستخدمين والأدوار.

Endpoints:
- list_app_users        — قائمة المستخدمين + أدوار كل واحد + حالة must_change_password
- save_app_user         — إضافة/تعديل مستخدم (admin فقط للإضافة)
- reset_user_password   — إعادة تعيين كلمة المرور (admin فقط)
- toggle_must_change    — تفعيل/إلغاء إجبار تغيير كلمة المرور (admin فقط)
- set_user_roles        — حفظ مجموعة أدوار مستخدم (transaction، admin فقط)
- list_auth_groups      — قائمة الأدوار مع عدد المستخدمين
- save_auth_group       — إضافة/تعديل دور (admin فقط)
- delete_auth_group     — حذف دور غير نظامي (admin فقط)

ملاحظة: الـ stubs في setting_api.py لا تشمل هذه الدوال — تُستدعى مباشرة عبر
`setting_users_api/<func>` من شاشة app_users.
"""

import re

_SYSTEM_ROLES = ("admin", "user", "account", "report")
_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def _is_admin():
    return auth.has_membership("admin")


def _forbidden():
    return response.json({"err": 2, "mess": "صلاحية غير كافية — يلزم admin"})


def _user_role_ids(user_id):
    rows = db(db.auth_membership.user_id == user_id).select(
        db.auth_membership.group_id)
    return [r.group_id for r in rows]


# ============================================================================
# =====================  المستخدمون  =========================================
# ============================================================================


@auth.requires(auth.has_membership("admin"))
def list_app_users():
    """قائمة كل المستخدمين مع أدوار كل واحد."""
    users = db(db.auth_user.id > 0).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name,
        db.auth_user.email, db.auth_user.mobile, db.auth_user.registration_key,
        orderby=db.auth_user.id,
    )

    memberships = db(db.auth_membership.id > 0).select(
        db.auth_membership.user_id, db.auth_membership.group_id)
    by_user = {}
    for m in memberships:
        by_user.setdefault(m.user_id, []).append(m.group_id)

    groups = db(db.auth_group.id > 0).select(
        db.auth_group.id, db.auth_group.role)
    role_name = {g.id: g.role for g in groups}

    has_must_change = "must_change_password" in db.auth_user.fields
    rows = []
    for u in users:
        if has_must_change:
            full = db.auth_user[u.id]
            must = (full.must_change_password or "F") == "T"
        else:
            must = False
        role_ids = by_user.get(u.id, [])
        rows.append({
            "id": u.id,
            "first_name": (u.first_name or "").strip(),
            "last_name": (u.last_name or "").strip(),
            "full_name": (" ".join(filter(None, [u.first_name, u.last_name]))
                          or u.email or "").strip(),
            "email": u.email or "",
            "mobile": getattr(u, "mobile", "") or "",
            "blocked": bool(u.registration_key) and u.registration_key not in
                       ("", "pending"),
            "must_change_password": must,
            "role_ids": role_ids,
            "role_names": [role_name.get(r, "?") for r in role_ids],
        })

    return response.json({"err": 0, "rows": rows,
                          "groups": [{"id": g.id, "role": g.role,
                                      "system": g.role in _SYSTEM_ROLES}
                                     for g in groups],
                          "has_must_change_field": has_must_change})


def _validate_user(row, user_id=None):
    first = (row.get("first_name") or "").strip()
    last = (row.get("last_name") or "").strip()
    email = (row.get("email") or "").strip().lower()
    mobile = (row.get("mobile") or "").strip()
    if not first:
        return "الاسم الأول مطلوب"
    if not email:
        return "البريد الإلكتروني مطلوب"
    if not _EMAIL_RE.match(email):
        return "صيغة البريد الإلكتروني غير صحيحة"
    if len(first) > 128 or len(last) > 128:
        return "الاسم طويل جداً"
    if len(mobile) > 20:
        return "رقم الجوال طويل جداً"
    dup_q = db.auth_user.email == email
    if user_id:
        dup_q &= db.auth_user.id != user_id
    if db(dup_q).count() > 0:
        return "البريد الإلكتروني مستخدم لمستخدم آخر"
    return None


@auth.requires(auth.has_membership("admin"))
def save_app_user():
    """إضافة أو تعديل مستخدم. password اختياري عند التعديل."""
    try:
        row = request.vars
        uid = row.get("id")
        err = _validate_user(row, user_id=uid if uid else None)
        if err:
            return response.json({"err": 1, "mess": err})

        fields = dict(
            first_name=(row.get("first_name") or "").strip(),
            last_name=(row.get("last_name") or "").strip(),
            email=(row.get("email") or "").strip().lower(),
            mobile=(row.get("mobile") or "").strip(),
        )
        pw = (row.get("password") or "").strip()
        if uid:
            rec = db.auth_user[uid]
            if not rec:
                return response.json({"err": 1, "mess": "المستخدم غير موجود"})
            if pw:
                if len(pw) < 4:
                    return response.json({
                        "err": 1, "mess": "كلمة المرور قصيرة (٤ أحرف على الأقل)"})
                fields["password"] = db.auth_user.password.validate(pw)[0]
            rec.update_record(**fields)
            new_id = rec.id
        else:
            if not pw or len(pw) < 4:
                return response.json({
                    "err": 1, "mess": "كلمة المرور مطلوبة (٤ أحرف على الأقل)"})
            fields["password"] = db.auth_user.password.validate(pw)[0]
            if "must_change_password" in db.auth_user.fields:
                fields["must_change_password"] = "T"
            new_id = db.auth_user.insert(**fields)

        db.commit()
        return response.json({"err": 0, "id": new_id, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def reset_user_password():
    """إعادة تعيين كلمة مرور مستخدم. يضع must_change_password='T' لو متاحاً."""
    try:
        uid = request.vars.get("id")
        new_pw = (request.vars.get("password") or "").strip()
        if not uid:
            return response.json({"err": 1, "mess": "id مطلوب"})
        if len(new_pw) < 4:
            return response.json({"err": 1, "mess": "كلمة المرور قصيرة"})
        rec = db.auth_user[uid]
        if not rec:
            return response.json({"err": 1, "mess": "المستخدم غير موجود"})
        fields = {"password": db.auth_user.password.validate(new_pw)[0]}
        if "must_change_password" in db.auth_user.fields:
            fields["must_change_password"] = "T"
        rec.update_record(**fields)
        db.commit()
        return response.json({"err": 0, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def toggle_must_change():
    """تبديل must_change_password — مفيد لإجبار مستخدم على تغيير كلمته."""
    try:
        if "must_change_password" not in db.auth_user.fields:
            return response.json({
                "err": 1, "mess": "الحقل غير متاح في قاعدة البيانات الحالية"})
        uid = request.vars.get("id")
        rec = db.auth_user[uid] if uid else None
        if not rec:
            return response.json({"err": 1, "mess": "المستخدم غير موجود"})
        cur = (rec.must_change_password or "F") == "T"
        rec.update_record(must_change_password="F" if cur else "T")
        db.commit()
        return response.json({"err": 0, "must": (not cur)})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ============================================================================
# =====================  ربط المستخدم بالأدوار  ==============================
# ============================================================================


@auth.requires(auth.has_membership("admin"))
def set_user_roles():
    """يُعيد بناء عضوية مستخدم في الأدوار بشكل ذرّي.

    payload: {user_id, role_ids: [csv أو list]}
    حماية: لا يسمح بإزالة آخر admin (يبقى admin في النظام).
    """
    try:
        uid = request.vars.get("user_id")
        rec = db.auth_user[uid] if uid else None
        if not rec:
            return response.json({"err": 1, "mess": "المستخدم غير موجود"})

        raw = request.vars.get("role_ids", "")
        if isinstance(raw, list):
            ids_str = raw
        else:
            ids_str = [s for s in str(raw).split(",") if s.strip()]
        try:
            new_ids = set(int(x) for x in ids_str)
        except Exception:
            return response.json({"err": 1, "mess": "قائمة الأدوار غير صحيحة"})

        if new_ids:
            valid = db(db.auth_group.id.belongs(new_ids)).select(db.auth_group.id)
            valid_ids = set(g.id for g in valid)
            if valid_ids != new_ids:
                return response.json({"err": 1, "mess": "دور غير موجود"})

        admin_g = db(db.auth_group.role == "admin").select().first()
        if admin_g:
            cur_admins = db(
                (db.auth_membership.group_id == admin_g.id)
            ).count()
            user_was_admin = admin_g.id in _user_role_ids(uid)
            user_will_admin = admin_g.id in new_ids
            if user_was_admin and not user_will_admin and cur_admins <= 1:
                return response.json({
                    "err": 1,
                    "mess": "لا يمكن إزالة آخر admin من النظام"})

        db(db.auth_membership.user_id == uid).delete()
        for gid in new_ids:
            db.auth_membership.insert(user_id=uid, group_id=gid)
        db.commit()
        return response.json({"err": 0, "mess": "0",
                              "role_ids": sorted(new_ids)})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ============================================================================
# =====================  الأدوار (auth_group)  ===============================
# ============================================================================


@auth.requires(auth.has_membership("admin"))
def list_auth_groups():
    """قائمة الأدوار مع عدد المستخدمين لكل دور."""
    groups = db(db.auth_group.id > 0).select(
        db.auth_group.id, db.auth_group.role, db.auth_group.description,
        orderby=db.auth_group.id)

    members = db(db.auth_membership.id > 0).select(
        db.auth_membership.group_id)
    counts = {}
    for m in members:
        counts[m.group_id] = counts.get(m.group_id, 0) + 1

    rows = []
    for g in groups:
        rows.append({
            "id": g.id,
            "role": g.role or "",
            "description": g.description or "",
            "system": (g.role or "") in _SYSTEM_ROLES,
            "members_count": counts.get(g.id, 0),
        })
    return response.json({"err": 0, "rows": rows})


@auth.requires(auth.has_membership("admin"))
def save_auth_group():
    """إضافة أو تعديل دور. الأدوار النظامية يمكن تعديل وصفها فقط لا اسمها."""
    try:
        row = request.vars
        gid = row.get("id")
        role = (row.get("role") or "").strip()
        desc = (row.get("description") or "").strip()
        if not role:
            return response.json({"err": 1, "mess": "اسم الدور مطلوب"})
        if len(role) > 80:
            return response.json({"err": 1, "mess": "اسم الدور طويل جداً"})

        dup_q = db.auth_group.role == role
        if gid:
            dup_q &= db.auth_group.id != gid
        if db(dup_q).count() > 0:
            return response.json({"err": 1, "mess": "اسم دور مستخدم مسبقاً"})

        if gid:
            rec = db.auth_group[gid]
            if not rec:
                return response.json({"err": 1, "mess": "الدور غير موجود"})
            if rec.role in _SYSTEM_ROLES and role != rec.role:
                return response.json({
                    "err": 1,
                    "mess": "لا يمكن تغيير اسم دور نظامي (%s)" % rec.role})
            rec.update_record(role=role, description=desc)
            new_id = rec.id
        else:
            new_id = db.auth_group.insert(role=role, description=desc)
        db.commit()
        return response.json({"err": 0, "id": new_id, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(auth.has_membership("admin"))
def delete_auth_group():
    """حذف دور — يرفض النظامية والمرتبطة بمستخدمين."""
    try:
        gid = request.vars.get("id")
        rec = db.auth_group[gid] if gid else None
        if not rec:
            return response.json({"err": 1, "mess": "الدور غير موجود"})
        if (rec.role or "") in _SYSTEM_ROLES:
            return response.json({
                "err": 1,
                "mess": "هذا دور نظامي محمي (%s)" % rec.role})
        used = db(db.auth_membership.group_id == gid).count()
        if used > 0:
            return response.json({
                "err": 2,
                "mess": "لا يمكن حذف الدور لارتباطه بـ %d مستخدم" % used})
        rec.delete_record()
        db.commit()
        return response.json({"err": 0, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
