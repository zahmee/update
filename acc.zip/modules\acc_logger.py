# -*- coding: utf-8 -*-
"""
acc_logger — تسجيل الأخطاء مركزياً في err_report.

كل الـ APIs الجديدة يجب أن تستخدم `log_error(db, exc, screen)` بدلاً من print(e).
الجدول `err_report` يحوي:
  - er_dis: وصف الخطأ (str(exc))
  - screen_dis: اسم الشاشة/الـ endpoint
  - error_date: تلقائي

استعمال نموذجي:
    try:
        ...
    except Exception as e:
        acc_logger.log_error(db, e, screen='operations_api.save_journal')
        return response.json(acc_responses.error(e))
"""

import sys
import traceback
from datetime import datetime


def log_error(db, exc, screen="unknown", extra=None, user_id=None):
    """يسجّل خطأ في err_report. آمن — لا يرفع.

    Args:
        db: web2py DAL
        exc: Exception instance (أو string)
        screen: اسم الـ endpoint/الشاشة
        extra: dict إضافي للسياق (يُحوَّل لـ string ويُلحَق)
        user_id: id المستخدم إن أمكن

    Returns: int|None — id السجل أو None لو فشل التسجيل
    """
    try:
        msg = _format_error(exc, extra)
        # محاولة الكتابة في err_report
        rec_id = db.err_report.insert(
            er_dis=msg[:2000],         # حد أعلى للحماية
            screen_dis=str(screen)[:200],
            error_date=datetime.now(),
        )
        db.commit()
        return int(rec_id) if rec_id else None
    except Exception as inner:
        # لا نريد أن يفشل التسجيل نفسه ويُخفي الخطأ الأصلي
        try:
            db.rollback()
        except Exception:
            pass
        # fallback إلى stderr
        sys.stderr.write("[acc_logger] فشل التسجيل: %s\n" % inner)
        sys.stderr.write("[acc_logger] الخطأ الأصلي [%s]: %s\n" % (screen, exc))
        return None


def _format_error(exc, extra=None):
    """يبني نص الخطأ مع stack trace مختصر."""
    if isinstance(exc, Exception):
        # نلتقط الـ traceback إن كان متاحاً
        try:
            tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
            tb_str = "".join(tb[-8:])  # آخر 8 أسطر (يكفي للتشخيص)
        except Exception:
            tb_str = ""
        msg = "%s: %s" % (type(exc).__name__, str(exc))
        if tb_str:
            msg += "\n" + tb_str
    else:
        msg = str(exc)
    if extra:
        try:
            msg += "\nسياق: " + str(extra)
        except Exception:
            pass
    return msg


def recent_errors(db, limit=50, screen=None):
    """يستعلم آخر الأخطاء — لشاشة الإدارة.

    Returns: list[dict]
    """
    q = db.err_report.id > 0
    if screen:
        q &= db.err_report.screen_dis.contains(screen)
    rows = db(q).select(
        orderby=~db.err_report.id,
        limitby=(0, max(1, min(limit, 500))),
    )
    return [{
        "id": int(r.id),
        "er_dis": r.er_dis or "",
        "screen_dis": r.screen_dis or "",
        "error_date": str(r.error_date) if r.error_date else None,
    } for r in rows]


def cleanup_old(db, keep_days=30):
    """يحذف الأخطاء الأقدم من keep_days يوم — يُستدعى دورياً.

    Returns: int — عدد المحذوف
    """
    try:
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=keep_days)
        n = db(db.err_report.error_date < cutoff).delete()
        db.commit()
        return int(n or 0)
    except Exception as e:
        db.rollback()
        sys.stderr.write("[acc_logger] cleanup failed: %s\n" % e)
        return 0
