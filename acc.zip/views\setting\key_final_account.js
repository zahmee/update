// ======================  الحسابات الختامية — منطق Vue 3  ======================
// النموذج: enum نظامي. IDs 1،2،3 محجوزة وكود التقارير يعتمد عليها.
// السماح بإعادة التسمية، منع الحذف للنظامية ولأي تصنيف عليه حسابات مرتبطة.

// شرح كل تصنيف نظامي + التقارير المرتبطة (للعرض فقط — مصدر الحقيقة هو الـ ID)
var SYSTEM_META = {
    1: {
        role: 'حسابات المركز المالي (الأصول، الخصوم، حقوق الملكية)',
        brief: 'الحسابات التي تظهر في الميزانية العمومية وتُرحَّل أرصدتها للدورة التالية.',
        reports: ['الميزانية', 'الميزان', 'ترحيل الأرصدة'],
    },
    2: {
        role: 'الإيرادات والمصاريف التشغيلية',
        brief: 'الحسابات التي تظهر في قائمة الدخل وتُقفل في نهاية الدورة (لا تُرحَّل).',
        reports: ['قائمة الدخل', 'الميزان', 'الأرباح والخسائر'],
    },
    3: {
        role: 'حسابات المتاجرة (المشتريات، المبيعات، المخزون)',
        brief: 'حسابات يُحدَّد فيها مجمل الربح قبل تحويلها إلى الأرباح والخسائر.',
        reports: ['قائمة المتاجرة', 'الميزان'],
    },
};

function normalize(c) {
    return {
        id: Number(c.id),
        name: c.name == null ? '' : String(c.name),
        show_account: Number(c.show_account) === 2 ? 2 : 1,
        usage_count: Number(c.usage_count) || 0,
        is_system: !!c.is_system,
    };
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../setting_api/',
            isAdmin: !!window.isAdmin,
            data: [],
            loading: true,
            saving: false,
            modal_open: false,
            select_row: { id: -1, name: '', show_account: 1, usage_count: 0, is_system: false },
        };
    },

    computed: {
        is_edit() { return Number(this.select_row.id) > 0; },
        modal_title() {
            if (!this.is_edit) return 'إضافة تصنيف ختامي مخصص';
            if (this.select_row.is_system) return 'تعديل اسم التصنيف النظامي';
            return 'تعديل التصنيف المخصص';
        },
        namePlaceholder() {
            if (this.is_edit && this.select_row.is_system) {
                var sys = { 1: 'الميزانية أو قائمة المركز المالي',
                            2: 'الأرباح والخسائر أو قائمة الدخل',
                            3: 'المتاجرة أو مجمل الربح' };
                return sys[this.select_row.id] || 'اسم التصنيف';
            }
            return 'مثلاً: ميزانية تحليلية / تصنيف داخلي';
        },
        missing() {
            var m = [];
            if (!(this.select_row.name || '').trim()) m.push('اسم التصنيف');
            return m;
        },
        is_valid() { return this.missing.length === 0; },
        stats() {
            var s = { total: 0, system: 0, custom: 0, hidden: 0, total_usage: 0 };
            this.data.forEach(row => {
                s.total++;
                if (row.is_system) s.system++;
                else s.custom++;
                if (Number(row.show_account) !== 1) s.hidden++;
                s.total_usage += Number(row.usage_count) || 0;
            });
            return s;
        },
    },

    watch: {
        modal_open(open) { document.body.style.overflow = open ? 'hidden' : ''; },
    },

    created() { this.load(); },

    mounted() { window.addEventListener('keydown', this.on_key); },

    unmounted() {
        window.removeEventListener('keydown', this.on_key);
        document.body.style.overflow = '';
    },

    methods: {
        load() {
            var self = this;
            this.loading = true;
            return axios.get(this.api + 'get_all_final_accounts').then(res => {
                self.data = Array.isArray(res.data) ? res.data.map(normalize) : [];
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: 'تأكد من الاتصال.' });
            }).then(() => { self.loading = false; });
        },

        open_new() {
            if (!this.isAdmin) return;
            this.select_row = { id: -1, name: '', show_account: 1, usage_count: 0, is_system: false };
            this.modal_open = true;
            this.focus_first();
        },

        open_edit(row) {
            this.select_row = Object.assign({}, normalize(row));
            this.modal_open = true;
            this.focus_first();
        },

        close_modal() {
            if (this.saving) return;
            this.modal_open = false;
        },

        focus_first() {
            var self = this;
            this.$nextTick(() => {
                if (self.$refs.firstInput) self.$refs.firstInput.focus();
            });
        },

        on_key(e) {
            if (e.key === 'Escape' && this.modal_open) this.close_modal();
        },

        systemMeta(id) {
            return SYSTEM_META[id] || { role: '', brief: '', reports: [] };
        },

        cardColorClass(row) {
            if (row.is_system) {
                if (row.id === 1) return 'is-fa-1';
                if (row.id === 2) return 'is-fa-2';
                if (row.id === 3) return 'is-fa-3';
            }
            return 'is-custom';
        },

        cardIcon(row) {
            if (row.is_system) {
                if (row.id === 1) return 'fa-balance-scale';
                if (row.id === 2) return 'fa-chart-line';
                if (row.id === 3) return 'fa-store';
            }
            return 'fa-tag';
        },

        deleteHint(row) {
            if (row.is_system) return 'تصنيف نظامي محمي — لا يمكن حذفه';
            if (row.usage_count > 0) return 'مرتبط بحسابات — لا يمكن الحذف';
            return 'حذف';
        },

        payload() {
            return {
                id: this.select_row.id,
                name: (this.select_row.name || '').trim(),
                show_account: Number(this.select_row.show_account) === 2 ? 2 : 1,
            };
        },

        add_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'add_final_account/', this.payload()).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تمت الإضافة',
                                timer: 1500, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.saving = false; });
        },

        update_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'update_final_account/', this.payload()).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تم الحفظ',
                                timer: 1500, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.saving = false; });
        },

        delete_row() { this._do_delete(this.select_row); },
        quick_delete(row) { this._do_delete(row); },

        _do_delete(row) {
            if (this.saving) return;
            if (row.is_system) {
                Swal.fire({
                    icon: 'warning',
                    title: 'تصنيف نظامي محمي',
                    html: 'لا يمكن حذف <b>' + row.name + '</b> لأن تقارير الميزانية والأرباح والخسائر ' +
                          'والمتاجرة تعتمد عليه. يمكنك تعديل اسمه فقط.',
                });
                return;
            }
            if (row.usage_count > 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'تصنيف مرتبط بحسابات',
                    html: 'لا يمكن حذف <b>' + row.name + '</b> لأنه مرتبط بـ ' +
                          '<b>' + row.usage_count + '</b> حساب في الشجرة المحاسبية. ' +
                          'أعد تصنيف تلك الحسابات أولاً.',
                });
                return;
            }
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'حذف تصنيف ختامي',
                html: 'سيتم حذف <b>' + row.name + '</b> نهائياً. هل أنت متأكد؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(result => {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'delete_final_account/', { id: row.id }).then(res => {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.modal_open = false;
                        Swal.fire({ icon: 'success', title: 'تم الحذف',
                                    timer: 1500, showConfirmButton: false });
                        self.load();
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الحذف', text: d.mess || 'حدث خطأ' });
                    }
                }).catch(() => {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                }).then(() => { self.saving = false; });
            });
        },
    },
});

var app = vueApp.mount('#app');
