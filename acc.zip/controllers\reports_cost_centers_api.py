# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_cost_centers_api — تقارير مراكز التكلفة.

Endpoints:
- cost_centers_summary — ملخّص لكل مركز: عدد العمليات، إجمالي مدين/دائن، صافي
- cost_center_details  — كشف تفصيلي لمركز واحد (كل السطور التي استخدمته)

ملف منفصل احتراماً لقاعدة 600 سطر.
"""

import json

import acc_dates
import acc_export
import acc_periods


def _payload():
    """قراءة POST body JSON أو request.vars بشكل متسامح."""
    try:
        if request.body and request.body.read(1):
            request.body.seek(0)
            payload = json.loads(request.body.read().decode("utf-8") or "{}")
        else:
            payload = {}
    except Exception:
        payload = {}
    v = dict(request.vars or {})
    v.update(payload)
    return v


def _int_or_zero(x):
    try:
        return int(x)
    except Exception:
        return 0


@auth.requires(can_view)
def cost_centers_summary():
    """ملخّص حركة كل مركز تكلفة في فترة.

    Body / vars:
      branch     — id الفرع (0 = كل الفروع)
      period     — id الدورة (0 = كل الدورات)
      date_from  — YYYY-MM-DD (اختياري)
      date_to    — YYYY-MM-DD (اختياري)
      include_hidden — bool — يضمّن المراكز المخفية (show_cost=0)

    Return:
      { err, items: [{id, name, lines, debit, credit, net}], grand, count }

    output: صفّ لكل مركز فاعل في الفترة. المراكز المستخدَمة فقط (لا الصفرية).
    """
    try:
        v = _payload()
        branch_id = _int_or_zero(v.get("branch"))
        period_id = _int_or_zero(v.get("period"))
        date_from = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_from")))
        date_to = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_to")))
        include_hidden = str(v.get("include_hidden") or "").lower() in ("1", "true", "yes")

        where = ["jem.is_active = 'T'", "jed.cost_center IS NOT NULL", "jed.cost_center > 0"]
        params = []
        if branch_id > 0:
            where.append("jed.branches = %s")
            params.append(branch_id)
        if period_id > 0:
            where.append("jed.account_periods = %s")
            params.append(period_id)
        if date_from:
            where.append("jed.journal_date >= %s")
            params.append(date_from)
        if date_to:
            where.append("jed.journal_date <= %s")
            params.append(date_to)
        where_sql = " AND ".join(where)

        sql = (
            "SELECT jed.cost_center AS cc_id, "
            "       COUNT(*) AS lines_count, "
            "       COALESCE(SUM(jed.debit),0)::float AS debit, "
            "       COALESCE(SUM(jed.credit),0)::float AS credit "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            f"WHERE {where_sql} "
            "GROUP BY jed.cost_center "
            "ORDER BY (COALESCE(SUM(jed.debit),0) + COALESCE(SUM(jed.credit),0)) DESC"
        )
        rows = db.executesql(sql, placeholders=params, as_dict=True)

        # جلب أسماء مراكز التكلفة (مع/بدون المخفية)
        cc_filter = db.key_cost_center
        if not include_hidden:
            cc_filter = db(cc_filter.show_cost == 1)
        else:
            cc_filter = db(cc_filter)
        cc_map = {int(c.id): {
            "name": c.name,
            "show_cost": int(c.show_cost or 0),
        } for c in cc_filter.select()}

        # حالة خاصة: قد توجد سطور بمركز تكلفة لم يَعُد موجوداً (orphan) — نضمّنها
        items = []
        grand = {"lines": 0, "debit": 0.0, "credit": 0.0}
        for r in rows:
            cc_id = int(r["cc_id"])
            meta = cc_map.get(cc_id)
            if meta is None and not include_hidden:
                # مركز مخفي/محذوف — تجاهله إن لم تطلب include_hidden
                # نتحقّق إن كان موجوداً بأي حال
                full = db.key_cost_center[cc_id]
                if not full:
                    continue
                meta = {"name": full.name + " (محذوف)", "show_cost": 0}
            elif meta is None:
                full = db.key_cost_center[cc_id]
                if not full:
                    meta = {"name": "مركز #%d (غير معروف)" % cc_id, "show_cost": 0}
                else:
                    meta = {"name": full.name + " (محذوف)", "show_cost": 0}
            debit = float(r["debit"] or 0)
            credit = float(r["credit"] or 0)
            items.append({
                "id": cc_id,
                "name": meta["name"],
                "is_visible": meta["show_cost"] == 1,
                "lines": int(r["lines_count"] or 0),
                "debit": round(debit, 2),
                "credit": round(credit, 2),
                "net": round(debit - credit, 2),
            })
            grand["lines"] += int(r["lines_count"] or 0)
            grand["debit"] += debit
            grand["credit"] += credit
        grand["debit"] = round(grand["debit"], 2)
        grand["credit"] = round(grand["credit"], 2)
        grand["net"] = round(grand["debit"] - grand["credit"], 2)

        result = {
            "err": 0,
            "branch_id": branch_id,
            "period_id": period_id,
            "date_from": date_from or "",
            "date_to": date_to or "",
            "items": items,
            "grand": grand,
            "count": len(items),
        }

        if str(v.get("format") or "").lower() == "xlsx":
            return _summary_xlsx(result, v)
        return response.json(result)
    except Exception as e:
        try:
            db.err_report.insert(er_dis=str(e), screen_dis="cost_centers_summary")
            db.commit()
        except Exception:
            pass
        return response.json({"err": 1, "mess": str(e)})


@auth.requires(can_view)
def cost_center_details():
    """كشف تفصيلي لمركز تكلفة واحد — كل السطور التي استخدمته في الفترة.

    Body / vars:
      cost_center — id (مطلوب)
      branch, period, date_from, date_to — اختياري

    Return:
      { err, center: {id,name}, lines: [...], grand: {...}, count }
    """
    try:
        v = _payload()
        cc_id = _int_or_zero(v.get("cost_center"))
        if cc_id <= 0:
            return response.json({"err": 1, "mess": "مركز التكلفة مطلوب"})
        center = db.key_cost_center[cc_id]
        if not center:
            return response.json({"err": 1, "mess": "مركز التكلفة غير موجود"})

        branch_id = _int_or_zero(v.get("branch"))
        period_id = _int_or_zero(v.get("period"))
        date_from = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_from")))
        date_to = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_to")))

        where = ["jem.is_active = 'T'", "jed.cost_center = %s"]
        params = [cc_id]
        if branch_id > 0:
            where.append("jed.branches = %s")
            params.append(branch_id)
        if period_id > 0:
            where.append("jed.account_periods = %s")
            params.append(period_id)
        if date_from:
            where.append("jed.journal_date >= %s")
            params.append(date_from)
        if date_to:
            where.append("jed.journal_date <= %s")
            params.append(date_to)
        where_sql = " AND ".join(where)

        sql = (
            "SELECT jed.id, jed.journal_entry_master AS journal_id, "
            "       jed.journal_date, jed.branches AS branch_id, "
            "       jed.account_periods AS period_id, "
            "       jed.account_no, jed.detail, "
            "       jed.debit::float AS debit, jed.credit::float AS credit, "
            "       jem.journal_detail AS master_disc, "
            "       at.account_name_ar "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            "LEFT JOIN accounting_tree at ON at.id = jed.accounting_tree "
            f"WHERE {where_sql} "
            "ORDER BY jed.journal_date, jed.journal_entry_master, jed.id"
        )
        rows = db.executesql(sql, placeholders=params, as_dict=True)

        # خرائط الفروع
        branch_ids = list({int(r["branch_id"]) for r in rows if r.get("branch_id")})
        bmap = {b.id: b.name for b in db(db.branches.id.belongs(branch_ids)).select()} if branch_ids else {}

        lines = []
        grand = {"debit": 0.0, "credit": 0.0}
        for r in rows:
            d = float(r["debit"] or 0)
            c = float(r["credit"] or 0)
            lines.append({
                "id": int(r["id"]),
                "journal_id": int(r["journal_id"]),
                "date": str(r["journal_date"]) if r["journal_date"] else None,
                "branch_id": int(r["branch_id"] or 0),
                "branch_name": bmap.get(int(r["branch_id"] or 0), "—"),
                "account_no": r.get("account_no") or "",
                "account_name": r.get("account_name_ar") or "",
                "detail": r.get("detail") or "",
                "master_disc": r.get("master_disc") or "",
                "debit": round(d, 2),
                "credit": round(c, 2),
            })
            grand["debit"] += d
            grand["credit"] += c
        grand["debit"] = round(grand["debit"], 2)
        grand["credit"] = round(grand["credit"], 2)
        grand["net"] = round(grand["debit"] - grand["credit"], 2)
        grand["lines"] = len(lines)

        result = {
            "err": 0,
            "center": {"id": int(center.id), "name": center.name,
                       "is_visible": int(center.show_cost or 0) == 1},
            "branch_id": branch_id,
            "period_id": period_id,
            "date_from": date_from or "",
            "date_to": date_to or "",
            "lines": lines,
            "grand": grand,
            "count": len(lines),
        }

        if str(v.get("format") or "").lower() == "xlsx":
            return _details_xlsx(result, v)
        return response.json(result)
    except Exception as e:
        try:
            db.err_report.insert(er_dis=str(e), screen_dis="cost_center_details")
            db.commit()
        except Exception:
            pass
        return response.json({"err": 1, "mess": str(e)})


# ============================ Excel helpers ============================

def _summary_xlsx(data, v):
    columns = [
        {"key": "id", "title": "م", "format": "number", "width": 6},
        {"key": "name", "title": "مركز التكلفة", "format": "text", "width": 30},
        {"key": "lines", "title": "عدد العمليات", "format": "number", "width": 14},
        {"key": "debit", "title": "إجمالي مدين", "format": "currency"},
        {"key": "credit", "title": "إجمالي دائن", "format": "currency"},
        {"key": "net", "title": "الصافي (مدين-دائن)", "format": "currency"},
    ]
    totals_row = {
        "id": "", "name": "الإجمالي",
        "lines": data["grand"]["lines"],
        "debit": data["grand"]["debit"],
        "credit": data["grand"]["credit"],
        "net": data["grand"]["net"],
    }
    meta = [
        ("من تاريخ", data["date_from"] or "—"),
        ("إلى تاريخ", data["date_to"] or "—"),
        ("عدد المراكز", data["count"]),
    ]
    fname = "cost_centers_summary_%s.xlsx" % (data["date_to"] or "all")
    return acc_export.xlsx_response(
        response, fname,
        title="ملخّص مراكز التكلفة",
        meta=meta, columns=columns, rows=data["items"], totals=totals_row,
        sheet_name="ملخّص المراكز",
    )


def _details_xlsx(data, v):
    columns = [
        {"key": "date", "title": "التاريخ", "format": "text", "width": 12},
        {"key": "journal_id", "title": "رقم القيد", "format": "number", "width": 10},
        {"key": "branch_name", "title": "الفرع", "format": "text", "width": 14},
        {"key": "account_no", "title": "رقم الحساب", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 26},
        {"key": "master_disc", "title": "بيان القيد", "format": "text", "width": 26},
        {"key": "detail", "title": "بيان السطر", "format": "text", "width": 26},
        {"key": "debit", "title": "مدين", "format": "currency"},
        {"key": "credit", "title": "دائن", "format": "currency"},
    ]
    totals_row = {
        "date": "", "journal_id": "", "branch_name": "",
        "account_no": "", "account_name": "", "master_disc": "",
        "detail": "الإجمالي",
        "debit": data["grand"]["debit"],
        "credit": data["grand"]["credit"],
    }
    meta = [
        ("مركز التكلفة", data["center"]["name"]),
        ("من تاريخ", data["date_from"] or "—"),
        ("إلى تاريخ", data["date_to"] or "—"),
        ("عدد السطور", data["grand"]["lines"]),
    ]
    slug = (data["center"]["name"] or str(data["center"]["id"])).replace(" ", "_")[:30]
    fname = "cost_center_%s_%s.xlsx" % (slug, data["date_to"] or "all")
    return acc_export.xlsx_response(
        response, fname,
        title="كشف مركز تكلفة — " + data["center"]["name"],
        meta=meta, columns=columns, rows=data["lines"], totals=totals_row,
        sheet_name="تفصيل المركز",
    )
