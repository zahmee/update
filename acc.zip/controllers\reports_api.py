# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_api — façade بعد التقسيم (Phase 2.2 — 2026-05-25).

التقارير قُسّمت لـ 4 controllers مخصّصة تحت الحد (600 سطر):
- `reports_account_api`     — acount_balanc, acount_balanc_2, acount_balanc_3
- `reports_trial_api`       — trial_balance
- `reports_statements_api`  — income_statement, balance_sheet
- `reports_journal_api`     — Journal_report

كذلك التقارير المتقدّمة تعيش في controllers مستقلة (كانت موجودة سابقاً):
- `reports_branches_api`    — account_branches_matrix, single_account_branches
- `reports_cash_flow_api`   — cash_flow_statement
- `reports_cost_centers_api` — cost_centers_summary, cost_center_details
- `reports_diag`            — unbalanced_journals

الدوال الميتة `acount_balanc_3_1` و`branches_account_report_1_1` حُذفت
(لم تكن مستدعاة من أيّ شاشة — الواجهات تستخدم endpoints أحدث في
`reports_branches_api`).

ملاحظة مهمة: web2py يكتشف الدوال المُتاحة عبر regex على نص الملف
(`REGEX_EXPOSED` في `gluon/compileapp.py`)، فالدوال المُحمَّلة عبر `exec`
**غير مرئية** لـ URL dispatcher. لذلك نُعرّف stubs أولاً (تكتشفها web2py)،
ثم الـ exec يستبدلها بالتنفيذات الحقيقية.
"""

import os


# ===== stubs (الترتيب مهم: قبل exec حتى تُستبدل بالتنفيذات الفعلية) =====
# reports_account_api
def acount_balanc(): pass
def acount_balanc_2(): pass
def acount_balanc_3(): pass

# reports_trial_api
def trial_balance(): pass

# reports_statements_api
def income_statement(): pass
def balance_sheet(): pass

# reports_journal_api
def Journal_report(): pass


# ===== تحميل التنفيذات الفعلية (تُستبدل الـ stubs أعلاه) =====
_dir = os.path.join(request.folder, 'controllers')
for _f in [
    'reports_account_api.py',
    'reports_trial_api.py',
    'reports_statements_api.py',
    'reports_journal_api.py',
]:
    with open(os.path.join(_dir, _f), encoding='utf-8') as _fh:
        exec(_fh.read(), globals())
