var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            branches: [],
            branche_name: '',
            branch_select: -1,
            assets: [],
            liabilities: [],
            total_assets: 0,
            total_liabilities: 0,
            net_income: 0,
            total_equity: 0,
            loaded: false,
            loading: false,
            exporting: false,
            report_time: '',
            end_date_iso: '',
            e_date: window.end
        };
    },
    computed: {
        displayEnd() {
            return this.end_date_iso || '—';
        },
        balanceDiff() {
            return Math.abs(Number(this.total_assets || 0) - Number(this.total_equity || 0));
        },
        isBalanced() {
            return this.balanceDiff < 0.01;
        }
    },
    created() {
        axios.get(this.URL + '/../../setting_api/get_all_branches').then(response => {
            if (response.data != "") {
                this.branches = response.data;
                this.branch_select = this.branches[0].id;
            }
        });
        // window.end من القالب بصيغة YYYY-MM-DD
        this.end_date_iso = this.e_date || '';
    },
    methods: {
        _dateArr(iso) {
            if (!iso) return null;
            var p = iso.split('-');
            return [Number(p[2]), Number(p[1]), Number(p[0])];
        },
        onChange() {
            this.loaded = false;
        },
        fmt(value) {
            var numberValue = Number(value || 0);
            return numberValue.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },
        abs(value) {
            return Math.abs(Number(value || 0));
        },
        rowLevel(row) {
            var accountNo = row && row.account_no ? String(row.account_no) : '';
            return Math.max(accountNo.length - 1, 0) * 0.35;
        },
        printReport() {
            window.print();
        },
        exportExcel() {
            if (!this.loaded || this.branch_select < 0) return;
            var me = this;
            this.exporting = true;
            var report_data = {
                branch_select: this.branch_select,
                end_date: this._dateArr(this.end_date_iso),
                format: 'xlsx',
            };
            axios.post(
                this.URL + '/../../reports_statements_api/balance_sheet/',
                report_data,
                { responseType: 'blob' }
            ).then(function (response) {
                var blob = new Blob([response.data], {
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                });
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = 'balance_sheet_' + me.end_date_iso + '.xlsx';
                document.body.appendChild(a); a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر التصدير' });
            }).finally(function () {
                me.exporting = false;
            });
        },
        get_report() {
            var me = this;
            var b_id = this.branch_select;
            this.loading = true;
            this.branches.forEach(function (el) {
                if (el.id === b_id) {
                    me.branche_name = el.name;
                }
            });

            var report_data = {
                branch_select: this.branch_select,
                end_date: this._dateArr(this.end_date_iso)
            };

            axios.post(
                this.URL + '/../../reports_statements_api/balance_sheet/',
                report_data
            ).then(function (response) {
                if (response.data && !response.data.err) {
                    me.assets = response.data.assets;
                    me.liabilities = response.data.liabilities;
                    me.total_assets = response.data.total_assets;
                    me.total_liabilities = response.data.total_liabilities;
                    me.net_income = response.data.net_income;
                    me.total_equity = response.data.total_equity;
                    me.report_time = new Date().toLocaleString('en-GB');
                    me.loaded = true;
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'خطأ',
                        text: response.data.mess || 'حدث خطأ أثناء تحميل البيانات'
                    });
                }
                me.loading = false;
            }).catch(function () {
                me.loading = false;
                Swal.fire({
                    icon: 'error',
                    title: 'خطأ',
                    text: 'تعذر الاتصال بخدمة التقرير'
                });
            });
        }
    }
});
var app = vueApp.mount('#app');
