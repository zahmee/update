# -*- coding: utf-8 -*-
"""
acc_dates — أدوات معالجة وتحقّق التواريخ المشتركة لنظام المحاسبة.

يوحّد 4 دوال متكرّرة كانت موزَّعة على 3 controllers:
- `parse_date_array`     — [d,m,y] أو {day,month,year} → date (يرفع ValueError بعربي)
- `parse_flexible_date`  — يقبل ISO أو [d,m,y] أو {day,month,year} → date
- `parse_iso`            — "YYYY-MM-DD" أو كائن date → date | None (لا يرفع)
- `parse_iso_strict`     — "YYYY-MM-DD" → date (يرفع ValueError)
- `to_iso`               — date → "YYYY-MM-DD"

دوال نقية (لا تعتمد على web2py / db) — قابلة للاختبار باستقلال.
"""

from datetime import date, datetime


def parse_date_array(value, what="التاريخ"):
    """يحوّل [يوم، شهر، سنة] أو {day,month,year} إلى date.

    يرفع ValueError برسالة عربية مفهومة عند الإدخال غير الصالح.
    استعمال نموذجي: الفلاتر من الواجهة القديمة التي ترسل arrays.
    """
    try:
        if isinstance(value, dict):
            d, m, y = int(value["day"]), int(value["month"]), int(value["year"])
        else:
            d, m, y = int(value[0]), int(value[1]), int(value[2])
        return date(y, m, d)
    except (KeyError, IndexError, TypeError, ValueError):
        raise ValueError(what + " غير صالح — تأكّد من إدخال يوم/شهر/سنة صحيحة")


def parse_flexible_date(value, what="التاريخ"):
    """يقبل تاريخاً من الواجهات القديمة أو الحديثة ويعيد date.

    الصيغ المقبولة:
    - ISO string: YYYY-MM-DD أو YYYY-MM-DDTHH:MM:SS
    - [day, month, year]
    - {"day": d, "month": m, "year": y}
    - date/datetime
    """
    parsed = parse_iso(value)
    if parsed is not None:
        return parsed
    return parse_date_array(value, what=what)


def parse_iso(value):
    """يحوّل سلسلة ISO أو كائن date إلى date.

    يرجع None عند الفشل أو الإدخال الفارغ (متسامح).
    استعمال نموذجي: قراءة date من JSON body في API.
    """
    if not value:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
    except Exception:
        return None


def parse_iso_strict(value, what="التاريخ"):
    """مثل parse_iso لكن يرفع ValueError عند الفشل (للحقول الإلزامية)."""
    result = parse_iso(value)
    if result is None:
        raise ValueError(what + " مطلوب بصيغة YYYY-MM-DD")
    return result


def to_iso(d):
    """يحوّل date/datetime إلى سلسلة YYYY-MM-DD، أو None إن لم يكن تاريخاً."""
    if not d:
        return None
    if isinstance(d, datetime):
        return d.date().isoformat()
    if isinstance(d, date):
        return d.isoformat()
    return None


def date_str(d):
    """يحوّل أي إدخال تاريخ (dict/list/str/date) إلى نص ISO قابل للعرض.

    متسامح — لا يرفع. للاستخدام في الترويسات وأسماء ملفات التصدير.
    """
    try:
        if isinstance(d, dict):
            return "%04d-%02d-%02d" % (int(d["year"]), int(d["month"]), int(d["day"]))
        if isinstance(d, (list, tuple)) and len(d) >= 3:
            return "%04d-%02d-%02d" % (int(d[2]), int(d[1]), int(d[0]))
        if isinstance(d, (date, datetime)):
            return to_iso(d) or ""
        return str(d) if d else ""
    except Exception:
        return str(d) if d else ""


def date_slug(d):
    """تاريخ بصيغة آمنة لأسماء الملفات: YYYY-MM-DD بلا / أو فراغات."""
    return date_str(d).replace("/", "-").replace(" ", "_")


def normalize_journal_date(v):
    """يقبل التاريخ سواء كان نص YYYY-MM-DD أو dict {day, month, year}.
    يُرجع نصاً YYYY-MM-DD أو None — متسامح، لا يرفع.

    يُستخدم في operations_api لتطبيع journal_date القادم من الواجهة.
    يختلف عن parse_iso في أنه يُرجع string (لا date object)، ويقبل dict.
    """
    if not v:
        return None
    if isinstance(v, str):
        s = v.strip()
        try:
            datetime.strptime(s[:10], "%Y-%m-%d")
            return s[:10]
        except Exception:
            return None
    if isinstance(v, dict):
        try:
            y = int(v.get("year"))
            m = int(v.get("month"))
            d = int(v.get("day"))
            return "%04d-%02d-%02d" % (y, m, d)
        except Exception:
            return None
    return None
