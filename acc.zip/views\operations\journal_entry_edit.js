// ======================  تعديل قيد يومية — منطق Vue 3  ======================
// مرآة لشاشة الإنشاء — مع تحميل بيانات أصلية، قفل الفرع، رصد التغييرات.

var _rowKey = 0;
function blankRow() {
    _rowKey += 1;
    return {
        _key: _rowKey,
        _detail_id: null,         // null = سطر جديد لم يُحفظ بعد
        account: null,
        debit: 0,
        credit: 0,
        detail: '',
        cost_center: 0,
    };
}

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// snapshot لاكتشاف التغييرات
function rowSnap(r) {
    return JSON.stringify({
        a: r.account ? r.account.id : 0,
        d: Number(r.debit) || 0,
        c: Number(r.credit) || 0,
        t: r.detail || '',
        cc: Number(r.cost_center) || 0,
    });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../operations_api/',
            settingApi: window.purl + '/../../setting_api/',
            listURL: window.listURL,
            journalId: window.journalId,

            loaded: false,
            loadError: '',
            saving: false,

            master: {
                id: 0, branches: 0, branch_name: '',
                account_periods: 0, period_disc: '', period_open: 0,
                journal_date: '', journal_save: '', journal_detail: '',
                audit: { created_by: '', created_on: '', modified_by: '', modified_on: '' },
            },

            accounts: [],
            cost_centers: [],
            rows: [],
            periodInfo: null,

            _origMasterSnap: '',
            _origRowsSnap: '',

            // المرفقات (Phase 3.5)
            attachments: [],
            uploadingAtt: false,
            attApi: window.purl + '/../../attachments_api/',
        };
    },

    computed: {
        totals() {
            var d = 0, c = 0;
            this.rows.forEach(r => {
                d += Number(r.debit) || 0;
                c += Number(r.credit) || 0;
            });
            d = Math.round(d * 100) / 100;
            c = Math.round(c * 100) / 100;
            var diff = Math.round((d - c) * 100) / 100;
            return {
                debit: d, credit: c, diff: diff,
                balanced: Math.abs(diff) < 0.005 && d > 0,
            };
        },
        lastUsedAccount() {
            for (var i = this.rows.length - 1; i >= 0; i--) {
                if (this.rows[i].account) return this.rows[i].account;
            }
            return null;
        },
        currentMasterSnap() {
            return JSON.stringify({
                date: this.master.journal_date,
                save: this.master.journal_save || '',
                detail: this.master.journal_detail || '',
            });
        },
        currentRowsSnap() {
            return JSON.stringify(this.rows.map(rowSnap));
        },
        hasUnsavedChanges() {
            return this.currentMasterSnap !== this._origMasterSnap
                || this.currentRowsSnap !== this._origRowsSnap;
        },
        canSave() {
            if (this.saving) return false;
            if (!this.master.journal_date) return false;
            if (!(this.master.journal_detail || '').trim()) return false;
            if (!this.periodInfo || this.periodInfo.open_period !== 1) return false;
            if (this.rows.length < 2) return false;
            // كل سطر سليم
            for (var i = 0; i < this.rows.length; i++) {
                var r = this.rows[i];
                if (!r.account) return false;
                var d = Number(r.debit) || 0, c = Number(r.credit) || 0;
                if (d === 0 && c === 0) return false;
                if (d > 0 && c > 0) return false;
            }
            if (!this.totals.balanced) return false;
            return true;
        },
        savePreview() {
            if (!this.master.journal_date) return 'أدخل تاريخ القيد';
            if (!this.periodInfo) return 'التاريخ خارج الدورات';
            if (this.periodInfo.open_period !== 1) return 'الدورة مقفلة';
            if (!(this.master.journal_detail || '').trim()) return 'أدخل البيان الإجمالي';
            if (this.rows.length < 2) return 'أضف سطرين على الأقل';
            for (var i = 0; i < this.rows.length; i++) {
                var r = this.rows[i];
                if (!r.account) return 'السطر ' + (i+1) + ' بلا حساب';
                var d = Number(r.debit) || 0, c = Number(r.credit) || 0;
                if (d === 0 && c === 0) return 'السطر ' + (i+1) + ' بلا قيمة';
                if (d > 0 && c > 0) return 'السطر ' + (i+1) + ': مدين ودائن معاً';
            }
            if (!this.totals.balanced) return 'القيد غير متوازن — الفرق: ' + fmtNumber(this.totals.diff);
            return '';
        },
    },

    created() { this.bootstrap(); },

    mounted() {
        window.addEventListener('beforeunload', this._bu = (e) => {
            if (this.hasUnsavedChanges) { e.preventDefault(); e.returnValue = ''; }
        });
        window.addEventListener('keydown', this._key = (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                if (this.canSave && this.hasUnsavedChanges) this.saveJournal();
            }
        });
    },
    unmounted() {
        window.removeEventListener('beforeunload', this._bu);
        window.removeEventListener('keydown', this._key);
    },

    methods: {
        bootstrap() {
            var self = this;
            // 1) جلب القيد نفسه
            axios.get(this.api + 'get_journal_entry_edit/' + this.journalId).then(res => {
                var d = res.data || {};
                if (d.err) {
                    self.loadError = d.mess || 'القيد غير موجود';
                    return;
                }
                self._applyData(d);
                // 2) جلب مراكز التكلفة + شجرة حسابات الفرع للدورة الأصلية
                return Promise.all([
                    axios.get(self.settingApi + 'key_cost_center').then(r => r.data || []),
                    axios.get(self.api + 'get_accounts_for_journal/'
                              + self.master.branches + '/' + self.master.account_periods)
                         .then(r => r.data || { accounts: [] }),
                    axios.get(self.settingApi + 'get_period_for_date',
                              { params: { d: self.master.journal_date } })
                         .then(r => r.data || null),
                ]);
            }).then(arr => {
                if (!arr) return;
                self.cost_centers = Array.isArray(arr[0]) ? arr[0] : [];
                self.accounts = (arr[1] && arr[1].accounts) ? arr[1].accounts : [];
                self.periodInfo = (arr[2] && !arr[2].err) ? arr[2] : null;
                // تأكد أن حسابات السطور موجودة في القائمة (id match)
                // إن كان account في سطر لا يطابق أي خيار، نُبقي object الذي حمّلناه
                self.rows.forEach(r => {
                    if (r.account) {
                        var found = self.accounts.find(a => Number(a.id) === Number(r.account.id));
                        if (found) r.account = found; // نستخدم النسخة الحديثة من القائمة
                    }
                });
                // التقاط snapshot بعد التحميل الكامل
                self._snapshotOriginal();
                self.loaded = true;
                self.loadAttachments();
            }).catch(err => {
                self.loadError = (err && err.message) || 'خطأ غير معروف';
            });
        },

        _applyData(d) {
            this.master = Object.assign({}, this.master, d.master || {});
            this.rows = (d.details || []).map(dt => {
                var r = blankRow();
                r._detail_id = dt.id;
                r.account = dt.account || null;
                r.debit = Number(dt.debit) || 0;
                r.credit = Number(dt.credit) || 0;
                r.detail = dt.detail || '';
                r.cost_center = Number(dt.cost_center) || 0;
                return r;
            });
            if (!this.rows.length) {
                this.rows = [blankRow(), blankRow()];
            }
        },

        _snapshotOriginal() {
            this._origMasterSnap = this.currentMasterSnap;
            this._origRowsSnap = this.currentRowsSnap;
        },

        onDateChange() {
            var self = this;
            this.periodInfo = null;
            if (!this.master.journal_date) return;
            axios.get(this.settingApi + 'get_period_for_date',
                      { params: { d: this.master.journal_date } })
                .then(res => {
                    var d = res.data || {};
                    self.periodInfo = d.err ? null : d;
                }).catch(() => {});
        },

        addRow() { this.rows.push(blankRow()); },

        removeRow(i) {
            if (this.rows.length <= 1) return;
            this.rows.splice(i, 1);
        },

        duplicateLastRow() {
            var last = null;
            for (var i = this.rows.length - 1; i >= 0; i--) {
                if (this.rows[i].account) { last = this.rows[i]; break; }
            }
            if (!last) return;
            var nr = blankRow();
            nr.account = last.account;
            nr.detail = last.detail;
            nr.cost_center = last.cost_center;
            this.rows.push(nr);
        },

        onAmountInput(r) {
            if ((Number(r.debit) || 0) < 0) r.debit = 0;
            if ((Number(r.credit) || 0) < 0) r.credit = 0;
        },

        faLabel(v) {
            v = Number(v);
            return v === 1 ? 'ميزانية' : v === 2 ? 'أ/خ' : v === 3 ? 'متاجرة' : '';
        },

        fmt(n) { return fmtNumber(n); },

        formatDateTime(s) {
            if (!s) return '—';
            // تنسيق ISO إلى عربي مقروء
            var d = new Date(s);
            if (isNaN(d.getTime())) return s;
            return d.toLocaleString('en-GB');
        },

        // نفس withPopper من شاشة الإنشاء — لإخراج dropdown vue-select من overflow
        withPopper(dropdownList, component, { width }) {
            var toggle = component.$refs.toggle;
            if (!toggle) return function () {};
            var update = function () {
                var rect = toggle.getBoundingClientRect();
                var minWidth = Math.max(parseFloat(width) || 0, 380);
                dropdownList.style.position = 'absolute';
                dropdownList.style.top = (rect.bottom + window.scrollY + 2) + 'px';
                dropdownList.style.left = (rect.left + window.scrollX) + 'px';
                dropdownList.style.width = minWidth + 'px';
                dropdownList.style.maxHeight = '320px';
                dropdownList.style.overflowY = 'auto';
                dropdownList.style.zIndex = 9999;
                dropdownList.style.background = '#fff';
                dropdownList.style.border = '1px solid var(--line-2, #d6d6d6)';
                dropdownList.style.borderRadius = '8px';
                dropdownList.style.boxShadow = '0 8px 24px rgba(0,0,0,0.12)';
            };
            update();
            window.addEventListener('scroll', update, true);
            window.addEventListener('resize', update);
            return function () {
                window.removeEventListener('scroll', update, true);
                window.removeEventListener('resize', update);
            };
        },

        reloadOriginal() {
            if (!this.hasUnsavedChanges) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'استرجاع البيانات الأصلية',
                text: 'سيتم التراجع عن كل التغييرات التي أجريتها. متابعة؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، استرجع',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(r => {
                if (!r.isConfirmed) return;
                // أعد تحميل القيد كاملاً
                self.loaded = false;
                self.bootstrap();
            });
        },

        saveJournal() {
            if (!this.canSave || !this.hasUnsavedChanges || this.saving) return;
            var self = this;
            var detail = this.rows.map(r => ({
                branches: this.master.branches,
                debit: Number(r.debit) || 0,
                credit: Number(r.credit) || 0,
                detail: (r.detail || '').trim(),
                account: r.account.account_no,
                accounting_tree: r.account.id,
                cost_center: Number(r.cost_center) || 0,
            }));
            var payload = {
                master: {
                    id: this.master.id,
                    branches: this.master.branches,
                    journal_date: this.master.journal_date,
                    journal_save: (this.master.journal_save || '').trim(),
                    journal_detail: (this.master.journal_detail || '').trim(),
                    debit_total: this.totals.debit,
                    credit_total: this.totals.credit,
                    journal_operations: detail.length,
                },
                detail: detail,
            };
            this.saving = true;
            axios.post(this.api + 'update_journal/', payload).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    self._snapshotOriginal();  // اعتبر الحالة الجديدة هي الأصلية
                    Swal.fire({
                        icon: 'success',
                        title: 'تم حفظ التعديلات',
                        text: 'القيد رقم ' + d.id,
                        showCancelButton: true,
                        confirmButtonText: 'استعراض القيد',
                        cancelButtonText: 'البقاء على التعديل',
                        timer: 4000,
                        timerProgressBar: true,
                    }).then(rr => {
                        if (rr.isConfirmed) {
                            window.location.href = self.URL + '/../journal_entry_print/' + d.id;
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'تعذّر الحفظ',
                        text: d.mess || 'حدث خطأ غير متوقع',
                    });
                }
            }).catch(err => {
                Swal.fire({
                    icon: 'error',
                    title: 'تعذّر الاتصال بالخادم',
                    text: (err && err.message) || '',
                });
            }).then(() => { self.saving = false; });
        },

        // ============ المرفقات (Phase 3.5) ============
        loadAttachments() {
            var self = this;
            axios.get(this.attApi + 'list_attachments/' + this.journalId).then(res => {
                if (res.data && res.data.err === 0) {
                    self.attachments = res.data.items || [];
                }
            }).catch(() => { /* صامت */ });
        },
        attachmentURL(id) {
            return this.attApi + 'download_attachment/' + id;
        },
        iconFor(mime) {
            if (!mime) return 'fa-file';
            if (mime.indexOf('pdf') >= 0) return 'fa-file-pdf';
            if (mime.indexOf('image') >= 0) return 'fa-file-image';
            if (mime.indexOf('sheet') >= 0 || mime.indexOf('excel') >= 0) return 'fa-file-excel';
            if (mime.indexOf('word') >= 0) return 'fa-file-word';
            return 'fa-file-alt';
        },
        fmtSize(bytes) {
            var n = Number(bytes) || 0;
            if (n < 1024) return n + ' B';
            if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
            return (n / 1024 / 1024).toFixed(2) + ' MB';
        },
        onAttachFile(ev) {
            var f = ev.target.files && ev.target.files[0];
            if (!f) return;
            var self = this;
            self.uploadingAtt = true;
            var fd = new FormData();
            fd.append('journal_id', this.journalId);
            fd.append('file', f);
            axios.post(this.attApi + 'upload_attachment', fd, {
                headers: { 'Content-Type': 'multipart/form-data' },
            }).then(res => {
                if (res.data && res.data.err === 0) {
                    AccUI.toastSaved('تم رفع المرفق');
                    self.loadAttachments();
                } else {
                    AccUI.toastError('تعذّر الرفع', (res.data && res.data.mess) || '');
                }
            }).catch(err => {
                AccUI.toastError('خطأ في الاتصال', (err && err.message) || '');
            }).then(() => {
                self.uploadingAtt = false;
                ev.target.value = '';  // امح القيمة ليتمكن المستخدم من إعادة الرفع
            });
        },
        deleteAttachment(a) {
            var self = this;
            AccUI.confirmDelete('حذف المرفق', 'سيُحذف الملف نهائياً: ' + a.filename)
                .then(r => {
                    if (!r.isConfirmed) return;
                    return axios.post(self.attApi + 'delete_attachment', { id: a.id });
                })
                .then(res => {
                    if (!res) return;
                    if (res.data && res.data.err === 0) {
                        AccUI.toastDeleted();
                        self.loadAttachments();
                    } else {
                        AccUI.toastError('تعذّر الحذف', (res.data && res.data.mess) || '');
                    }
                })
                .catch(err => {
                    AccUI.toastError('خطأ في الاتصال', (err && err.message) || '');
                });
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
