// ======================  تشخيص القيود غير المتوازنة — منطق Vue 3  ======================

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            diagApi: window.purl + '/../../reports_diag/',
            opsApi: window.purl + '/../../operations_api/',
            settingApi: window.purl + '/../../setting_api/',
            isAdmin: !!window.isAdmin,

            branches: [],
            periods: [],

            filters: {
                branch: 0,
                period: 0,
                date_from: '',
                date_to: '',
                issue_type: 'all',
            },

            entries: [],
            stats: null,
            loading: false,
            deleting: null,
            _loadSeq: 0,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        branchInfo() {
            if (this.filters.branch <= 0) return null;
            return this.branches.find(b => b.id === this.filters.branch) || null;
        },
        periodInfo() {
            if (this.filters.period <= 0) return null;
            return this.periods.find(p => p.id === this.filters.period) || null;
        },
        branchInfoText() {
            return this.branchInfo ? this.branchInfo.name : 'كل الفروع';
        },
        periodInfoText() {
            return this.periodInfo ? this.periodInfo.disc : 'كل الدورات';
        },
        filteredEntries() {
            if (this.filters.issue_type === 'all') return this.entries;
            return this.entries.filter(e => (e.issues || []).indexOf(this.filters.issue_type) !== -1);
        },
        grandTotals() {
            if (!this.filteredEntries.length) return null;
            var g = { master_debit: 0, master_credit: 0, sum_debit: 0, sum_credit: 0 };
            this.filteredEntries.forEach(e => {
                g.master_debit += Number(e.master_debit) || 0;
                g.master_credit += Number(e.master_credit) || 0;
                g.sum_debit += Number(e.sum_debit) || 0;
                g.sum_credit += Number(e.sum_credit) || 0;
            });
            return g;
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                // افتراضياً: بلا فلاتر — يفحص النظام كاملاً
                self.reload();
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        reload() {
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            var body = {
                branch: this.filters.branch || 0,
                period: this.filters.period || 0,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || '',
            };
            axios.post(this.diagApi + 'unbalanced_journals/', body).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: d.mess || 'تعذّر تنفيذ الفحص' });
                    self.entries = [];
                    self.stats = null;
                } else {
                    self.entries = Array.isArray(d.entries) ? d.entries : [];
                    self.stats = d.stats || null;
                }
            }).catch(err => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'خطأ في الاتصال', text: (err && err.message) || '' });
                self.entries = [];
                self.stats = null;
            }).finally(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        onPeriodChange() {
            // ملء مدى التواريخ تلقائياً من الدورة المختارة
            var p = this.periodInfo;
            if (p) {
                if (p.start_date) this.filters.date_from = p.start_date;
                if (p.end_date) this.filters.date_to = p.end_date;
            }
            this.reload();
        },

        resetFilters() {
            this.filters.branch = 0;
            this.filters.period = 0;
            this.filters.date_from = '';
            this.filters.date_to = '';
            this.filters.issue_type = 'all';
            this.reload();
        },

        hasIssue(e, type) { return (e.issues || []).indexOf(type) !== -1; },

        issueLabel(iss) {
            return {
                'lines_diff': 'سطور غير متوازنة',
                'master_vs_detail': 'رأس ≠ سطور',
                'empty_detail': 'بلا سطور',
            }[iss] || iss;
        },

        issueClass(iss) {
            return {
                'lines_diff': 'ar4-pill-bad',
                'master_vs_detail': 'ar4-pill-warn',
                'empty_detail': 'ar4-pill-violet',
            }[iss] || 'ar4-pill';
        },

        issueTitle(iss, e) {
            if (iss === 'lines_diff') {
                return 'مدين السطور = ' + fmtNumber(e.sum_debit)
                    + ' / دائن السطور = ' + fmtNumber(e.sum_credit)
                    + ' (الفرق ' + fmtNumber(e.lines_diff_amount) + ')';
            }
            if (iss === 'master_vs_detail') {
                return 'مدين: رأس ' + fmtNumber(e.master_debit) + ' vs سطور ' + fmtNumber(e.sum_debit)
                    + ' | دائن: رأس ' + fmtNumber(e.master_credit) + ' vs سطور ' + fmtNumber(e.sum_credit);
            }
            if (iss === 'empty_detail') {
                return 'القيد ليس له أي سطور تفصيلية — يحتاج إعادة إدخال أو حذف';
            }
            return iss;
        },

        editUrl(id) {
            return this.URL + '/../../operations/journal_entry_edit/' + id;
        },

        printUrl(id) {
            return this.URL + '/../../operations/journal_entry_print/' + id;
        },

        softDelete(entry) {
            if (!this.isAdmin) return;
            if (!entry.period_open) {
                Swal.fire({
                    icon: 'warning',
                    title: 'دورة مقفلة',
                    text: 'لا يمكن حذف قيد في دورة مالية مقفلة. أعد فتح الدورة من شاشة الفترات أولاً.',
                });
                return;
            }
            var self = this;
            var issues = (entry.issues || []).map(this.issueLabel).join(' + ');
            Swal.fire({
                icon: 'warning',
                title: 'تأكيد الحذف الناعم',
                html: '<div style="text-align:start;font-size:0.95rem;">' +
                      '<p>سيُحذف القيد <b>#' + entry.id + '</b> ' +
                      '(<b>' + (entry.disc || 'بدون بيان') + '</b>) ' +
                      'حذفاً ناعماً — يبقى الرأس كسجل تدقيق وتُحذف سطوره.</p>' +
                      '<p style="color:#9a2a1c;"><b>السبب المُكتشَف:</b> ' + issues + '</p>' +
                      '<p style="color:#6b7280;font-size:0.85rem;">' +
                      'يمكنك إعادة إنشاء القيد بشكل صحيح من شاشة العمليات بعد الحذف.</p>' +
                      '</div>',
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-trash-alt"></i> نعم، احذف ناعماً',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#9a2a1c',
                reverseButtons: true,
            }).then(result => {
                if (!result.isConfirmed) return;
                self.deleting = entry.id;
                var fd = new FormData();
                fd.append('id', entry.id);
                axios.post(self.opsApi + 'soft_delete_journal', fd).then(res => {
                    var d = res.data || {};
                    if (d.err) {
                        Swal.fire({ icon: 'error', title: 'تعذّر الحذف', text: d.mess || '' });
                    } else {
                        Swal.fire({
                            icon: 'success',
                            title: 'تمّ الحذف',
                            text: 'حُذف القيد #' + entry.id + ' حذفاً ناعماً.',
                            timer: 1800,
                            showConfirmButton: false,
                        });
                        // إعادة تحميل القائمة — القيد المحذوف لن يظهر بعد الآن
                        self.reload();
                    }
                }).catch(err => {
                    Swal.fire({
                        icon: 'error',
                        title: 'خطأ في الاتصال',
                        text: (err && err.message) || ''
                    });
                }).finally(() => {
                    self.deleting = null;
                });
            });
        },

        printReport() { window.print(); },

        exportCSV() {
            var rows = [[
                '#', 'رقم القيد', 'التاريخ', 'الفرع', 'الدورة', 'البيان',
                'عدد السطور', 'مدين الرأس', 'دائن الرأس', 'مدين السطور', 'دائن السطور',
                'أنواع الخلل'
            ]];
            this.filteredEntries.forEach((e, idx) => {
                rows.push([
                    idx + 1,
                    e.id,
                    e.date || '',
                    e.branch_name,
                    e.period_disc,
                    e.disc || '',
                    e.line_count,
                    fmtNumber(e.master_debit),
                    fmtNumber(e.master_credit),
                    fmtNumber(e.sum_debit),
                    fmtNumber(e.sum_credit),
                    (e.issues || []).map(this.issueLabel).join(' + '),
                ]);
            });
            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'unbalanced_journals_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        fmt(n) { return fmtNumber(n); },
    },
});

var app = vueApp.mount('#app');
