// ============================================================
//  جذر تطبيق Vue
// ============================================================
var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../setting_api/',
            isAdmin: !!window.isAdmin,
            account_periods: [],
            branches: [],
            final_account: [],
            flat: [],
            templateOptions: [
                { id: 3, name: 'دليل مبسط للحسابات الرئيسية' },
                { id: 5, name: 'دليل سعودي للمنشآت الصغيرة والمتوسطة' },
                { id: 1, name: 'دليل مختصر للمنشآت التجارية - 132 حساب' },
                { id: 4, name: 'دليل متوسط للمنشآت التجارية - 172 حساب' },
                { id: 2, name: 'دليل تفصيلي للمنشآت التجارية - 218 حساب' },
            ],
            period_select: -1,
            branch_select: -1,
            loading: false,
            saving: false,
            search: '',
            modal_open: false,
            select_row: blankRow(),
            openTrigger: 0,
            closeTrigger: 0,
        };
    },

    computed: {
        ready() {
            return Number(this.period_select) > 0 && Number(this.branch_select) > 0;
        },
        tree() { return buildTree(this.flat); },
        visibleTree() { return this.tree; },
        sortedFlat() {
            return this.flat.slice().sort(compareAccountNo);
        },
        rootCount() {
            return this.flat.filter(function (r) {
                return String(r.main_account || '0') === '0';
            }).length;
        },
        leafCount() {
            var parents = {};
            this.flat.forEach(function (r) {
                var p = String(r.main_account || '0');
                if (p !== '0') parents[p] = true;
            });
            return this.flat.filter(function (r) {
                return !parents[String(r.account_no)];
            }).length;
        },
        hiddenCount() {
            return this.flat.filter(function (r) {
                return Number(r.show_account) !== 1;
            }).length;
        },
        selectedPeriodName() {
            var id = Number(this.period_select);
            var p = this.account_periods.find(function (x) { return Number(x.id) === id; });
            return p ? p.disc : 'غير محدد';
        },
        selectedBranchName() {
            var id = Number(this.branch_select);
            var b = this.branches.find(function (x) { return Number(x.id) === id; });
            return b ? b.name : 'غير محدد';
        },
        is_edit() { return Number(this.select_row.id) > 0; },
        modal_title() {
            if (this.is_edit) return 'تعديل حساب';
            var m = String(this.select_row.main_account || '0');
            return m !== '0' ? 'إضافة حساب فرعي' : 'إضافة حساب رئيسي';
        },
        parent_label() {
            var m = String(this.select_row.main_account || '0');
            if (m === '0') return '';
            var p = this.flat.find(function (r) { return String(r.account_no) === m; });
            return p ? ('[' + p.account_no + '] ' + p.account_name_ar) : ('[' + m + ']');
        },
        suggested_no_placeholder() { return 'مثال: 1101'; },
        missing() {
            var m = [];
            var r = this.select_row;
            if (!(r.account_no || '').toString().trim()) m.push('رقم الحساب');
            else if (!/^[0-9]{1,15}$/.test(String(r.account_no || '').trim())) {
                m.push('رقم حساب رقمي');
            }
            var main = String(r.main_account || '0').trim();
            if (main !== '0' && !/^[0-9]{1,15}$/.test(main)) {
                m.push('رقم حساب رئيسي صحيح');
            }
            if (!(r.account_name_ar || '').trim()) m.push('اسم الحساب (عربي)');
            else if ((r.account_name_ar || '').trim().length < 3) {
                m.push('اسم حساب من 3 أحرف على الأقل');
            }
            return m;
        },
        is_valid() { return this.missing.length === 0; },
    },

    watch: {
        modal_open(open) {
            document.body.style.overflow = open ? 'hidden' : '';
        },
    },

    created() { this.bootstrap(); },

    mounted() { window.addEventListener('keydown', this.on_key); },

    unmounted() {
        window.removeEventListener('keydown', this.on_key);
        document.body.style.overflow = '';
    },

    methods: {
        bootstrap() {
            var self = this;
            axios.get(this.api + 'get_all_account_periods').then(function (r) {
                self.account_periods = Array.isArray(r.data) ? r.data : [];
                var open = self.account_periods.find(function (p) { return Number(p.open_period) === 1; });
                if (open) self.period_select = open.id;
                self.maybeAutoLoad();
            });
            axios.get(this.api + 'get_all_branches').then(function (r) {
                self.branches = Array.isArray(r.data) ? r.data : [];
                var main = self.branches.find(function (b) { return Number(b.is_main) === 1; });
                if (main) self.branch_select = main.id;
                else if (self.branches.length === 1) self.branch_select = self.branches[0].id;
                self.maybeAutoLoad();
            });
            axios.get(this.api + 'get_key_final_account').then(function (r) {
                self.final_account = Array.isArray(r.data) ? r.data : [];
            });
        },

        maybeAutoLoad() { if (this.ready) this.onChange(); },

        onChange() {
            if (!this.ready) { this.flat = []; return; }
            var self = this;
            this.loading = true;
            axios.get(this.api + 'get_accounting_tree/' + this.branch_select + '/' + this.period_select)
                .then(function (r) {
                    self.flat = Array.isArray(r.data) ? r.data.map(normalize) : [];
                })
                .catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر تحميل الدليل', text: 'تأكد من الاتصال.' });
                })
                .then(function () { self.loading = false; });
        },

        expand_all() { this.openTrigger++; },
        collapse_all() { this.closeTrigger++; },

        open_new(parentNode) {
            var r = blankRow();
            r.branches = this.branch_select;
            r.account_periods = this.period_select;
            if (parentNode) {
                r.main_account = String(parentNode.account_no);
                r.account_no = this.suggestNextAccountNo(parentNode);
                r.account_type = Number(parentNode.account_type) || 1;
                r.final_account = Number(parentNode.final_account) || 1;
            } else {
                r.main_account = '0';
                r.account_no = this.suggestRootAccountNo();
            }
            this.select_row = r;
            this.modal_open = true;
            this.focus_first();
        },

        open_edit(node) {
            this.select_row = normalize(node);
            this.modal_open = true;
            this.focus_first();
        },

        close_modal() {
            if (this.saving) return;
            this.modal_open = false;
        },

        focus_first() {
            var self = this;
            this.$nextTick(function () {
                if (self.$refs.firstInput) self.$refs.firstInput.focus();
            });
        },

        on_key(e) {
            if (e.key === 'Escape' && this.modal_open) this.close_modal();
        },

        suggestNextAccountNo(parent) {
            var parentNo = String(parent.account_no || '');
            var kids = (parent.children || []);
            if (!kids.length) return parentNo + '01';
            var parentLen = parentNo.length;
            var maxSuffix = 0, suffixLen = 2;
            kids.forEach(function (c) {
                var s = String(c.account_no || '').slice(parentLen);
                if (s.length) suffixLen = Math.max(suffixLen, s.length);
                var n = parseInt(s, 10);
                if (!isNaN(n) && n > maxSuffix) maxSuffix = n;
            });
            return parentNo + String(maxSuffix + 1).padStart(suffixLen, '0');
        },

        suggestRootAccountNo() {
            var max = 0;
            this.flat.forEach(function (c) {
                if (String(c.main_account || '0') === '0') {
                    var n = parseInt(c.account_no, 10);
                    if (!isNaN(n) && n > max) max = n;
                }
            });
            return String(max + 1);
        },

        payload() {
            var r = this.select_row;
            return {
                id: r.id,
                branches: this.branch_select,
                account_periods: this.period_select,
                account_no: String(r.account_no || '').trim(),
                account_name_ar: (r.account_name_ar || '').trim(),
                account_name_en: (r.account_name_en || '').trim(),
                main_account: String(r.main_account || '0').trim(),
                account_type: Number(r.account_type) || 1,
                final_account: Number(r.final_account) || 1,
                show_account: Number(r.show_account) === 2 ? 2 : 1,
                credit: 0,
                debit: 0,
            };
        },

        add_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'add_accounting_tree/', this.payload()).then(function (res) {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تمت الإضافة', timer: 1500, showConfirmButton: false });
                    self.onChange();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ' });
                }
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(function () { self.saving = false; });
        },

        update_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'update_accounting_tree/', this.payload()).then(function (res) {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تم الحفظ', timer: 1500, showConfirmButton: false });
                    self.onChange();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ' });
                }
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(function () { self.saving = false; });
        },

        delete_row() { this._do_delete(this.select_row); },
        quick_delete(node) { this._do_delete(node); },

        _do_delete(node) {
            if (this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'حذف الحساب',
                html: 'سيتم حذف الحساب <b>[' + (node.account_no || '') + ']</b> ' +
                    (node.account_name_ar || '') +
                    ' وجميع الحسابات التابعة له.<br><small>ممنوع إذا وُجدت قيود عليه.</small>',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                var p = {
                    id: node.id,
                    branches: self.branch_select,
                    account_periods: self.period_select,
                    account_no: node.account_no,
                };
                axios.post(self.api + 'delete_accounting_tree/', p).then(function (res) {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.modal_open = false;
                        Swal.fire({ icon: 'success', title: 'تم الحذف', timer: 1500, showConfirmButton: false });
                        self.onChange();
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الحذف', text: d.mess || 'حدث خطأ' });
                    }
                }).catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                }).then(function () { self.saving = false; });
            });
        },

        countByFinal(v) {
            return this.flat.filter(function (r) { return Number(r.final_account) === v; }).length;
        },

        finalAccountName(v) {
            var id = Number(v);
            var row = this.final_account.find(function (f) { return Number(f.id) === id; });
            if (row && row.name) return row.name;
            return id === 1 ? 'الميزانية' : id === 2 ? 'أرباح وخسائر' : id === 3 ? 'المتاجرة' : '';
        },

        accountTypeLabel(v) {
            var id = Number(v);
            return id === 1 ? 'دائن' : id === 2 ? 'مدين' : '';
        },

        import_template(n) {
            if (!this.ready || this.saving) return;
            var self = this;
            var tpl = this.templateOptions.find(function (x) { return Number(x.id) === Number(n); });
            var title = tpl ? tpl.name : ('دليل جاهز رقم ' + n);
            Swal.fire({
                icon: 'question',
                title: 'استيراد ' + title,
                html: 'سيُضاف الدليل إلى <b>' + this._esc(this.selectedBranchName) + '</b> / <b>' +
                    this._esc(this.selectedPeriodName) + '</b>.<br>' +
                    '<small>سيتم تجاوز الحسابات الموجودة مسبقاً وإضافة الحسابات الناقصة فقط.</small>',
                showCancelButton: true, confirmButtonText: 'استيراد', cancelButtonText: 'إلغاء',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.get(self.api + 'add_account_file/' + self.branch_select + '/' + self.period_select + '/' + n)
                    .then(function (res) {
                        var d = res.data || {};
                        if (d.mess === '0') {
                            var msg = 'تمت إضافة ' + (d.count || 0) + ' حساب.';
                            if (d.skipped) msg += ' تم تجاوز ' + d.skipped + ' حساب موجود مسبقاً.';
                            Swal.fire({
                                icon: 'success',
                                title: 'تم الاستيراد',
                                text: msg,
                            });
                            self.onChange();
                        } else {
                            Swal.fire({ icon: 'error', title: 'تعذّر الاستيراد', text: d.mess || 'حدث خطأ' });
                        }
                    }).catch(function () {
                        Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                    }).then(function () { self.saving = false; });
            });
        },

        export_json() {
            if (!this.ready || !this.flat.length) return;
            var data = this.flat.map(function (r) {
                return {
                    account_no: r.account_no,
                    account_name_ar: r.account_name_ar,
                    account_name_en: r.account_name_en,
                    main_account: r.main_account,
                    account_type: r.account_type,
                    final_account: r.final_account,
                    show_account: r.show_account,
                };
            });
            var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'accounting_tree_' + this.branch_select + '_' + this.period_select + '.json';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        import_json() {
            if (!this.ready || this.saving) return;
            var self = this;
            var input = document.createElement('input');
            input.type = 'file';
            input.accept = 'application/json,.json';
            input.onchange = function (e) {
                var file = e.target.files[0];
                if (!file) return;
                var fr = new FileReader();
                fr.onload = function () {
                    try {
                        var data = JSON.parse(fr.result);
                        if (!Array.isArray(data)) {
                            Swal.fire({ icon: 'error', title: 'ملف غير صالح', text: 'الملف يجب أن يحوي مصفوفة JSON.' });
                            return;
                        }
                        Swal.fire({
                            icon: 'question',
                            title: 'استيراد ' + data.length + ' حساب',
                            html: 'سيُضافون إلى <b>' + self._esc(self.selectedBranchName) + '</b> / <b>' +
                                self._esc(self.selectedPeriodName) + '</b>.<br>' +
                                '<small>سيتم فحص التكرارات والحسابات الرئيسية قبل الإدخال.</small>',
                            showCancelButton: true, confirmButtonText: 'نعم، استورد', cancelButtonText: 'إلغاء',
                        }).then(function (result) {
                            if (!result.isConfirmed) return;
                            self.saving = true;
                            axios.post(self.api + 'upload_data/', {
                                data: JSON.stringify(data),
                                branch: self.branch_select,
                                account_periods: self.period_select,
                            }).then(function (res) {
                                var d = res.data || {};
                                if (d.mess === '0') {
                                    var msg = 'تمت إضافة ' + (d.count || 0) + ' حساب.';
                                    if (d.skipped) msg += ' تم تجاوز ' + d.skipped + ' حساب موجود مسبقاً.';
                                    Swal.fire({ icon: 'success', title: 'تم الاستيراد', text: msg });
                                    self.onChange();
                                } else {
                                    Swal.fire({ icon: 'error', title: 'تعذّر الاستيراد', text: d.mess || 'حدث خطأ' });
                                }
                            }).catch(function () {
                                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                            }).then(function () { self.saving = false; });
                        });
                    } catch (err) {
                        Swal.fire({ icon: 'error', title: 'تعذّر قراءة الملف', text: String(err) });
                    }
                };
                fr.readAsText(file);
            };
            input.click();
        },

        // === نسخ شجرة الحسابات من دورة أخرى ===
        clone_from_period() {
            if (!this.ready || this.saving) return;
            var self = this;
            // ارفض إن كانت الدورة الحالية ليست فارغة
            if (this.flat.length > 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'الدورة الحالية ليست فارغة',
                    html: 'تحوي الدورة الحالية <b>' + this.flat.length + '</b> حساب. ' +
                        'لا يمكن النسخ — امسح الدليل أولاً من قائمة الأدوات.',
                });
                return;
            }
            // اجلب الدورات المصدر المتاحة
            axios.get(this.api + 'list_source_periods_for_clone', {
                params: { branch: this.branch_select, exclude: this.period_select },
            }).then(function (res) {
                var sources = Array.isArray(res.data) ? res.data : [];
                if (!sources.length) {
                    Swal.fire({
                        icon: 'info',
                        title: 'لا توجد دورات للنسخ منها',
                        text: 'لا توجد دورات أخرى تحوي حسابات لهذا الفرع.',
                    });
                    return;
                }
                var opts = sources.map(function (s) {
                    return '<option value="' + s.id + '">' +
                        self._esc(s.disc) + ' — ' + s.count + ' حساب' +
                        (s.start_date ? ' (' + String(s.start_date).slice(0, 4) + ')' : '') +
                        '</option>';
                }).join('');
                Swal.fire({
                    title: 'نسخ شجرة الحسابات',
                    html:
                        '<div style="text-align:start;">' +
                        '<p style="font-size:0.86rem; color:#666; margin-bottom:0.6rem;">' +
                        'اختر الدورة المصدر — ستُنسخ جميع حساباتها (بنفس الأرقام والتصنيفات) ' +
                        'إلى الدورة الحالية لنفس الفرع. ' +
                        'لن تُنسخ الأرصدة الافتتاحية ولا القيود.</p>' +
                        '<label for="cln-src" style="font-size:0.82rem; font-weight:500; display:block; margin-bottom:0.3rem;">الدورة المصدر</label>' +
                        '<select id="cln-src" class="form-select" style="font-family:inherit;">' + opts + '</select>' +
                        '</div>',
                    showCancelButton: true,
                    confirmButtonText: 'انسخ الآن',
                    cancelButtonText: 'إلغاء',
                    confirmButtonColor: '#0d6efd',
                    preConfirm: function () {
                        var el = document.getElementById('cln-src');
                        return el ? el.value : null;
                    },
                }).then(function (result) {
                    if (!result.isConfirmed || !result.value) return;
                    self.saving = true;
                    axios.post(self.api + 'clone_tree_to_period/', {
                        branch: self.branch_select,
                        source: result.value,
                        dest: self.period_select,
                    }).then(function (res) {
                        var d = res.data || {};
                        if (d.mess === '0') {
                            var msg = 'نُسخ ' + (d.count || 0) + ' حساب إلى الدورة الحالية.';
                            if (d.skipped) msg += ' تم تجاوز ' + d.skipped + ' حساب موجود مسبقاً.';
                            Swal.fire({
                                icon: 'success', title: 'تم النسخ',
                                text: msg,
                                timer: 2000, showConfirmButton: false,
                            });
                            self.onChange();
                        } else {
                            Swal.fire({ icon: 'warning', title: 'تعذّر النسخ', text: d.mess || 'حدث خطأ' });
                        }
                    }).catch(function () {
                        Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                    }).then(function () { self.saving = false; });
                });
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل الدورات' });
            });
        },

        // مساعد للهروب من HTML داخل SweetAlert
        _esc(s) {
            return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
                return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
            });
        },

        clear_all() {
            if (!this.ready || !this.flat.length || this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'مسح كل الدليل',
                html: '<b>تحذير:</b> سيتم حذف جميع الحسابات (' + this.flat.length + ') لهذا الفرع والدورة. ' +
                    'لا يمكن التراجع.<br>اكتب <b>حذف</b> للتأكيد:',
                input: 'text',
                showCancelButton: true,
                confirmButtonText: 'حذف الجميع',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
                inputValidator: function (v) {
                    return v === 'حذف' ? undefined : 'اكتب "حذف" للتأكيد';
                },
            }).then(function (result) {
                if (!result.isConfirmed) return;
                axios.get(self.api + 'clear_all_account_data/' + self.branch_select + '/' + self.period_select)
                    .then(function (res) {
                        var d = res.data || {};
                        Swal.fire({ icon: 'success', title: 'تم المسح', text: 'حُذف ' + (d.conut || 0) + ' حساب.' });
                        self.onChange();
                    }).catch(function () {
                        Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                    });
            });
        },
    },
});

registerAccountingTreeNode(vueApp);
var app = vueApp.mount('#app');
