# type: ignore


from gluon.contrib.appconfig import AppConfig
from gluon.tools import Auth
import json
import os
import pathlib
from datetime import datetime

if request.global_settings.web2py_version < "2.15.5":
    raise HTTP(500, "Requires web2py 2.15.5 or newer")
configuration = AppConfig(reload=True)


def _cfg(key, env=None, default=None):
    """يقرأ إعداداً من env إن وُجد، ثم من appconfig.ini.
    يسمح بإخراج الأسرار من Git عبر متغيرات بيئة."""
    if env:
        v = os.environ.get(env)
        if v is not None and v != "":
            return v
    v = configuration.get(key)
    if v in (None, ""):
        return default
    return v
c = datetime.now()
# exp = configuration.get("app.exp_date")
# if exp:
#     d1 = datetime.strptime(c.strftime("%Y-%m-%d"), "%Y-%m-%d")
#     d2 = datetime.strptime(exp, "%Y-%m-%d")
#     date_def = (d2 - d1).days
#     if date_def < 1:
#         raise HTTP(
#             400,
#             (
#                 "<h1 style='text-align: center;' > نعتذر منك لقد انتهى اشتراكك </h1>"
#                 f"<h2 style='text-align: center;' > {exp} </h2>"
#             ),
#         )
        
if not request.env.web2py_runtime_gae:
    db = DAL(
        _cfg("db.uri", env="ACC_DB_URI"),
        pool_size=_cfg("db.pool_size", default=10),
        migrate_enabled=_cfg("db.migrate", default=False),
        check_reserved=["all"],
    )
else:
    db = DAL("google:datastore+ndb")
    session.connect(request, response, db=db)
response.generic_patterns = []
_is_production = str(_cfg("app.production", env="ACC_PRODUCTION") or "").lower() in ("true", "1", "yes")
if request.is_local and not _is_production:
    response.generic_patterns.append("*")
response.formstyle = "bootstrap4_inline"
response.form_label_separator = ""
auth = Auth(db, host_names=_cfg("host.names", env="ACC_HOST_NAMES"))
auth.settings.extra_fields["auth_user"] = [
    Field("mobile", length=20, label="رقم الجوال"),
]
auth.define_tables(username=False, signature=False)
mail = auth.settings.mailer
mail.settings.server = (
    "logging" if request.is_local else configuration.get("smtp.server")
)
mail.settings.sender = _cfg("smtp.sender")
mail.settings.login = _cfg("smtp.login", env="ACC_SMTP_LOGIN")
mail.settings.tls = configuration.get("smtp.tls") or False
mail.settings.ssl = configuration.get("smtp.ssl") or False
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.settings.reset_password_requires_verification = True
response.meta.author = configuration.get("app.author")
response.meta.description = configuration.get("app.description")
response.meta.keywords = configuration.get("app.keywords")
response.meta.generator = configuration.get("app.generator")
response.show_toolbar = configuration.get("app.toolbar")
response.google_analytics_id = configuration.get("google.analytics_id")
if configuration.get("scheduler.enabled"):
    from gluon.scheduler import Scheduler

    scheduler = Scheduler(db, heartbeat=configuration.get("scheduler.heartbeat"))
# =================================================================================
auth.settings.create_user_groups = False
auth.settings.showid = False
T.force("ar")
response.delimiters = ("{{{", "}}}")
# =================================================================================
#                               start teble
# =================================================================================
# =============================================================================

if db(db.auth_group.id > 0).isempty() == True:
    db.auth_group.insert(role="admin")
    db.auth_group.insert(role="user")
    db.auth_group.insert(role="account")
    db.auth_group.insert(role="report")

if db(db.auth_user.id > 0).isempty() == True:
    import secrets

    _init_pw = secrets.token_urlsafe(9)
    user_id = db.auth_user.insert(
        first_name="admin",
        last_name="user",
        password=db.auth_user.password.validate(_init_pw)[0],
        email="admin@user.com",
    )
    # كلمة المرور الأولية تُكتب في ملف خاص (غير متاح عبر الويب) ليطّلع عليها المسؤول
    try:
        with open(
            os.path.join(request.folder, "private", "initial_admin_password.txt"), "w"
        ) as _f:
            _f.write("email: admin@user.com\npassword: " + _init_pw + "\n")
    except Exception:
        pass
if db(db.auth_membership.id > 0).isempty() == True:
    db.auth_membership.insert(
        user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
    )

# ==============================================================================
# مصفوفة صلاحيات النظام — مرّ بـ @auth.requires(can_xxx)
# هرم: admin > account > user > report (الأعلى يشمل الأدنى عند التطبيق)
#
# - can_admin   : مدير النظام فقط (مستخدمون، نسخ احتياطي، صيانة، إقفال فترات، تحديث ذاتي)
# - can_account : admin أو account (المحاسب الرئيسي: تعديل/حذف القيود + إعدادات محاسبية)
# - can_enter   : admin/account/user (الإدخال اليومي: قيود جديدة + مرفقات)
# - can_view    : كل الأدوار بما فيها report (قراءة فقط: التقارير والشاشات)
# ==============================================================================


def can_admin():
    return auth.has_membership("admin")


def can_account():
    return auth.has_membership("admin") or auth.has_membership("account")


def can_enter():
    return (auth.has_membership("admin") or auth.has_membership("account")
            or auth.has_membership("user"))


def can_view():
    return (auth.has_membership("admin") or auth.has_membership("account")
            or auth.has_membership("user") or auth.has_membership("report"))


def role_flags():
    """يُمرَّر للقوالب لإخفاء الأزرار غير المسموحة."""
    return dict(
        is_admin=auth.has_membership("admin"),
        is_account=auth.has_membership("account"),
        is_user=auth.has_membership("user"),
        is_report=auth.has_membership("report"),
        can_admin=can_admin(),
        can_account=can_account(),
        can_enter=can_enter(),
        can_view=can_view(),
    )


# ==============================================================================

# ============================================================================
# نعم لا
db.define_table(
    "key_yesno", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_yesno.id.label = "م"

if db(db.key_yesno.id > 0).isempty() == True:
    db.key_yesno.insert(name="نعم")
    db.key_yesno.insert(name="لا")
# ============================================================================
# انواع العمليات المحاسبية
db.define_table(
    "key_accounting_operations",
    Field("name", length=150, label="الوصف"),
    format="%(name)s",
)
db.key_accounting_operations.id.label = "م"

if db(db.key_accounting_operations.id > 0).isempty() == True:
    db.key_accounting_operations.insert(name="رصيد افتتاحي")
    db.key_accounting_operations.insert(name="اقفال نهاية الدورة المالية")
# ========================================= جدول الاخطاء  =======================
db.define_table(
    "err_report",
    Field("er_dis", "text", label="وصف الخطاء"),
    Field("screen_dis", "text", label="شاشة الخطأ"),
    auth.signature,
)
# ||============================>>>>  جدول الشاشات   <<<<<============================|||
"""
db.define_table('app_screen',
    Field('disc',length=250, label='الوصف'),
    Field('start_date', 'date', label='تاريخ البداية'),
    Field('end_date', 'date', label='تاريخ النهاية'),
    Field('open_period', 'reference key_yesno', label='فترة مفتوحة'),
    Field('status' ,'integer',label='الحالة'),
    Field('punch' ,'integer' , label='الوضع' )
    )
db.account_periods.id.label='م'
"""
# ||============================>>>>  جدول الفروع   <<<<<============================|||
db.define_table(
    "branches",
    Field("code", length=50, label="رمز الفرع"),
    Field("name", length=150, label="اسم الفرع"),
    Field("manager", length=150, label="مدير الفرع"),
    Field("site", length=250, label="الموقع"),
    Field("contact", length=100, label="الهاتف"),
    Field("email", length=150, label="البريد الإلكتروني"),
    Field("vat_no", length=50, label="الرقم الضريبي"),
    Field("cr_no", length=50, label="السجل التجاري"),
    Field("is_main", "reference key_yesno", default=2, label="الفرع الرئيسي"),
    Field("show_row", "reference key_yesno", default=1, label="يتم عرضة"),
)
db.branches.id.label = "م"

# ||============================>>>>  جدول الفترات المحاسبية   <<<<<============================|||
db.define_table(
    "account_periods",
    Field("disc", length=250, label="الوصف"),
    Field("start_date", "date", label="تاريخ البداية"),
    Field("end_date", "date", label="تاريخ النهاية"),
    Field("open_period", "reference key_yesno", label="فترة مفتوحة"),
    Field("status", "integer", label="الحالة"),
    Field("export", "boolean", default=False, label="تم ترحيل الارصدة"),
    Field("punch", "integer", label="الوضع"),
    Field("show_row", "reference key_yesno", default=1, label="يتم عرضة"),
    Field("period_type", length=20, default="year", label="نوع الدورة"),
    Field("notes", "text", label="ملاحظات"),
    Field("closed_on", "datetime", label="تاريخ الإقفال"),
    Field("closed_by", "reference auth_user", label="أُقفلت بواسطة"),
    auth.signature,
)
db.account_periods.id.label = "م"

# ============================================================================
# نوع الحساب
db.define_table(
    "key_account_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_account_type.id.label = "م"

if db(db.key_account_type.id > 0).isempty() == True:
    db.key_account_type.insert(name="دائن")
    db.key_account_type.insert(name="مدين")

# ||============================>>>>  جدول الشجرة المحاسبية   <<<<<============================|||
db.define_table(
    "accounting_tree",
    Field("account_periods", "reference account_periods", label="الدورة المالية"),
    Field("branches", "reference branches", label="الفرع"),
    Field("account_no", length=15, label="رقم الحساب"),
    Field("account_name_ar", length=250, label="اسم الحساب - عربي"),
    Field("account_name_en", length=250, label="اسم الحساب - انجليزي"),
    Field("main_account", length=15, label="الحساب الرئيسي"),
    Field("account_level", "integer", label="الرتبة"),
    Field("account_type", "integer", label="نوع الحساب"),
    Field("final_account", "integer", label="الحساب الختامي"),
    Field("show_account", "reference key_yesno", default=1, label="متاح"),
    Field("credit", "double", default=0, label="دائن"),
    Field("debit", "double", default=0, label="مدين"),
)
db.accounting_tree.id.label = "م"

# ||============================>>>>  الارصدة الافتتاحية و الختامية   <<<<<============================|||
db.define_table(
    "account_periods_opening",
    Field("account_periods", "reference account_periods", label="الدورة المالية"),
    Field("branches", "reference branches", label="الفرع"),
    Field("account_no", length=15, label="رقم الحساب"),
    Field("main_account", length=15, label="الحساب الرئيسي"),
    Field("credit", "double", default=0, label="دائن"),
    Field("debit", "double", default=0, label="مدين"),
    Field("export", "boolean", default=False, label="تم ترحيل الارصدة"),
    Field(
        "carried_from_period",
        "reference account_periods",
        label="مُرحَّل من دورة",
    ),
)
db.account_periods_opening.id.label = "م"

# ============================================================================
# مراكز التكلفة
db.define_table(
    "key_cost_center",
    Field("name", length=150, label="الوصف"),
    Field("show_cost", "reference key_yesno", default=1, label="متاح"),
    format="%(name)s",
)
db.key_cost_center.id.label = "م"

if db(db.key_cost_center.id > 0).isempty() == True:
    db.key_cost_center.insert(name="مركز - 1")
    db.key_cost_center.insert(name="مركز - 2")

# ============================================================================
# الحسابات الختامية
db.define_table(
    "key_final_account",
    Field("name", length=150, label="الوصف"),
    Field("show_account", "reference key_yesno", default=1, label="متاح"),
    format="%(name)s",
)
db.key_final_account.id.label = "م"

if db(db.key_final_account.id > 0).isempty() == True:
    db.key_final_account.insert(name="الميزانية")
    db.key_final_account.insert(name="الارباح و الخسائر")
    db.key_final_account.insert(name="متاجرة")

# ============================================================================
# جدول اليومية - الرئيسي
db.define_table(
    "journal_entry_master",
    Field("account_periods", "reference account_periods", label="الدورة المالية"),
    Field("journal_date", "date", label="تاريخ القيد"),
    Field("branches", "reference branches", label="الفرع"),
    Field("debit_total", "double", label="اجمالي - مدين"),
    Field("credit_total", "double", label="اجمالي - دائن"),
    Field("journal_detail", length=250, label="البيان"),
    Field("journal_operations", "integer", label="عدد العمليات"),
    Field("journal_save", length=20, label="رقم الدفتر"),
    auth.signature,
)
db.journal_entry_master.id.label = "م"

# ============================================================================
# جدول اليومية - التفاصيل
db.define_table(
    "journal_entry_detail",
    Field(
        "journal_entry_master",
        "reference journal_entry_master",
        label="اليومية الرئيسي",
    ),
    Field("account_periods", "reference account_periods", label="الدورة المالية"),
    Field("journal_date", "date", label="تاريخ القيد"),
    Field("branches", "reference branches", label="الفرع"),
    Field("debit", "double", label="مدين"),
    Field("credit", "double", label="دائن"),
    Field("detail", length=250, label="البيان"),
    Field("accounting_tree", "reference accounting_tree", label="رقم الحساب"),
    Field("account_no", length=15, label="رقم الحساب"),
    Field("cost_center", "integer", label="مركز التكلفة"),
)
db.journal_entry_detail.id.label = "م"

# ============================================================================
# رموز استعادة كلمة المرور عبر SMS
# يحتاج تطبيق migrations_manual/004_sms_password_reset.sql على القاعدة قبل الاستخدام.
db.define_table(
    "password_reset_otp",
    Field("user_id", "reference auth_user", label="المستخدم"),
    Field("code_hash", length=64, label="بصمة الرمز"),
    Field("salt", length=64, label="Salt"),
    Field("expires_on", "datetime", label="ينتهي في"),
    Field("attempts", "integer", default=0, label="المحاولات"),
    Field("used_on", "datetime", label="استخدم في"),
    Field("created_on", "datetime", default=request.now, label="أنشئ في"),
    Field("requested_ip", length=64, label="IP"),
    Field("user_agent", length=255, label="User Agent"),
    Field("sent_to_last4", length=8, label="آخر أرقام الجوال"),
    Field("send_status", "text", label="حالة الإرسال"),
)
db.password_reset_otp.id.label = "م"

# ============================================================================
# مرفقات القيود (Phase 3.5 — 2026-05-25)
# يحتاج تطبيق migrations_manual/001_journal_attachments.sql على القاعدة قبل الاستخدام.
db.define_table(
    "journal_attachments",
    Field("journal_id", "reference journal_entry_master", label="القيد"),
    Field("filename", length=255, label="اسم الملف"),
    Field("storage_name", length=255, label="اسم التخزين"),
    Field("mime_type", length=100, label="نوع MIME"),
    Field("file_size", "integer", label="الحجم (بايت)"),
    Field("uploaded_by", "reference auth_user", label="رفعها"),
    Field("uploaded_on", "datetime", default=request.now, label="تاريخ الرفع"),
    Field("notes", "text", label="ملاحظات"),
)
db.journal_attachments.id.label = "م"

# ============================================================================
# قوالب القيود (Phase 3.6 — 2026-05-25)
# يحتاج تطبيق migrations_manual/002_journal_templates.sql على القاعدة قبل الاستخدام.
db.define_table(
    "journal_templates",
    Field("name", length=150, requires=IS_NOT_EMPTY(), label="اسم القالب"),
    Field("description", "text", label="الوصف"),
    Field("lines_json", "text", label="السطور (JSON)"),
    Field("usage_count", "integer", default=0, label="مرات الاستخدام"),
    Field("is_active", "boolean", default=True, label="نشط"),
    auth.signature,
)
db.journal_templates.id.label = "م"


# current_time = c.strftime("%H:%M:%S")
# print("  -->  sb.py -->  " + current_time)

# def chk_date():
#     c = datetime.now()
#     configuration = AppConfig(reload=True)
#     exp = configuration.get("app.exp_date")
#     if exp:
#         d1 = datetime.strptime(c.strftime("%Y-%m-%d"), "%Y-%m-%d")
#         d2 = datetime.strptime(exp, "%Y-%m-%d")
#         print(d1)
#         print(d2)
#         date_def = (d2 - d1).days
#         print(date_def)
#         if date_def < 1:
#             raise HTTP(
#                 400,
#                 (
#                     "<h1 style='text-align: center;' > نعتذر منك لقد انتهى اشتراكك </h1>"
#                     f"<h2 style='text-align: center;' > {exp} </h2>"
#                 ),
#             )


# chk_date()
