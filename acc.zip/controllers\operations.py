# -*- coding: utf-8 -*-
#  type: ignore
"""operations — شاشات العمليات (إدخال القيود + القوالب + الطباعة).

الصلاحيات (راجع models/db.py:role_flags):
- index, index2, journal_entry, journal_entry_view, journal_entry_print: can_enter
- journal_entry_edit, journal_entry_delete: can_account (admin + account)
- templates: can_enter (تعديل القوالب نفسها = can_account داخل الـ API)
"""


@auth.requires(can_enter)
def index():
    response.title = "العمليات"
    return role_flags()


@auth.requires(can_enter)
def index2():
    """مكتب القيود الموحّد — يدمج اختيار الفرع وعرض القيود في شاشة واحدة.
    يقبل query params: branch, period, date_from, date_to, q (للوصول المباشر)."""
    response.title = "قيود اليومية"
    return role_flags()


@auth.requires(can_enter)
def journal_entry():
    return role_flags()


@auth.requires(can_enter)
def journal_entry_view():
    """رابط رجعي — يُعاد توجيهه لمكتب القيود الجديد.
    استدعاءات قديمة بشكل /journal_entry_view/<branch_id> تُحوَّل إلى index2?branch=N."""
    branch = request.args(0)
    target = URL("operations", "index2",
                 vars={"branch": branch} if branch else None)
    redirect(target)


@auth.requires(can_view)
def journal_entry_print():
    """طباعة القيد — متاحة للجميع بما فيهم report للقراءة."""
    data = {}
    data["master"] = db.journal_entry_master[request.args(0)]
    data["details"] = db(
        db.journal_entry_detail.journal_entry_master == request.args(0)
    ).select()
    return dict(data=data)


@auth.requires(can_account)
def journal_entry_delete():
    """رابط رجعي للحذف عبر URL — التدفّق الجديد يستخدم operations_api.soft_delete_journal
    من شاشة index2. هذا يبقى للتوافق مع الإشارات القديمة فقط."""
    mas = db.journal_entry_master[request.args(0)]
    if not mas:
        session.flash = "القيد غير موجود"
        redirect(URL("operations", "index2"))
    per = db.account_periods[mas.account_periods] if mas.account_periods else None
    if not per or per.open_period != 1:
        session.flash = "لا يمكن حذف قيد في فترة مالية مقفلة"
        redirect(URL("operations", "index2"))
    db(db.journal_entry_detail.journal_entry_master == mas.id).delete()
    mas.update_record(is_active=False)
    session.flash = "تم حذف القيد"
    redirect(URL("operations", "index2"))


@auth.requires(can_account)
def journal_entry_edit():
    """تعديل قيد — للمحاسب الرئيسي (admin/account) فقط."""
    return role_flags()


@auth.requires(can_enter)
def templates():
    """شاشة إدارة قوالب القيود (Phase 3.6 — 2026-05-25).
    العرض/الاستخدام = can_enter؛ التعديل = can_account داخل templates_api."""
    response.title = "قوالب القيود"
    return role_flags()
