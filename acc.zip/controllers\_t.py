# -*- coding: utf-8 -*-
#  type: ignore
# ============================================================
#  آلية تحديث النظام (مُحصَّنة 2026-05-25)
#
#    _t/up            : صفحة التحديث
#    _t/check_update  : فحص توفّر تحديث جديد (JSON)
#    _t/apply_update  : تنزيل + تحقّق + snapshot + تثبيت + rollback (JSON)
#    _t/rollback      : العودة لآخر snapshot ناجح
#
#  الحماية المُضافة:
#    1. SHA256 checksum مطلوب — الـ remote يرفع acc.sha256
#       (إن لم يكن متاحاً يُعرَض تحذير قابل للقبول صراحةً)
#    2. snapshot كامل للتطبيق قبل أي استبدال (private/snapshots/<timestamp>/)
#    3. zip-slip protection — رفض أي مسار خارج التطبيق
#    4. rollback تلقائي عند فشل extract
#    5. حد أقصى لحجم الـ zip (50 MB)
# ============================================================

import os
import shutil
import subprocess
import zipfile
import hashlib
import re
from datetime import datetime

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"
VER_FILE = "acc_ver.txt"
ZIP_FILE = "acc.zip"
SHA_FILE = "acc.sha256"

MAX_ZIP_SIZE = 50 * 1024 * 1024  # 50 MB
SNAPSHOT_KEEP = 5  # عدد snapshots التي نحتفظ بها


def _get_local_version():
    ver_file = os.path.join(request.folder, VER_FILE)
    try:
        with open(ver_file, "r") as f:
            return f.read().strip()
    except Exception:
        return "0"


def _curl_text(url, timeout=30):
    """يجلب نصاً عبر curl. يرفع Exception عند الفشل."""
    result = subprocess.run(
        ["curl", "-sL", "--max-time", str(timeout), url],
        capture_output=True, text=True, timeout=timeout + 10,
    )
    if result.returncode != 0:
        raise Exception("curl failed: " + (result.stderr or "unknown"))
    if not result.stdout.strip():
        raise Exception("استجابة فارغة من: " + url)
    return result.stdout.strip()


def _get_remote_version():
    ver = _curl_text(UPDATE_BASE_URL + VER_FILE, timeout=30)
    try:
        float(ver)
    except ValueError:
        raise Exception("استجابة غير صالحة من خادم التحديث")
    return ver


def _get_remote_sha256():
    """يحاول جلب checksum. يرجع None لو لم يكن متاحاً."""
    try:
        sha = _curl_text(UPDATE_BASE_URL + SHA_FILE, timeout=15)
        # SHA256 = 64 hex chars
        m = re.match(r"^[0-9a-fA-F]{64}", sha)
        if m:
            return m.group(0).lower()
        return None
    except Exception:
        return None


def _compute_sha256(path):
    """يحسب SHA256 لملف. مهم للتحقق."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _validate_zip_safety(zip_path, target_dir):
    """يفحص الـ zip ضد zip-slip ويتأكد من حجمه المعقول.
    يرفع Exception عند أي خطر."""
    target_abs = os.path.realpath(target_dir)
    total_size = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        for info in zf.infolist():
            # zip-slip: تحويل المسار لـ absolute والتأكد أنه داخل target
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/"):
                raise Exception("ملف خبيث في الـ zip: " + info.filename)
            extracted = os.path.realpath(os.path.join(target_abs, name))
            if not extracted.startswith(target_abs + os.sep) and extracted != target_abs:
                raise Exception("zip-slip محتمل: " + info.filename)
            # حجم ملف فردي + مجموع
            if info.file_size > MAX_ZIP_SIZE:
                raise Exception("ملف ضخم داخل الـ zip: " + info.filename)
            total_size += info.file_size
            if total_size > MAX_ZIP_SIZE * 2:  # decompressed total
                raise Exception("حجم الـ zip بعد فك الضغط كبير جداً")
    return True


def _snapshot_app(app_path):
    """يأخذ snapshot كامل للتطبيق قبل التحديث.
    يحفظ في private/snapshots/<timestamp>/"""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    snap_root = os.path.join(app_path, "private", "snapshots")
    os.makedirs(snap_root, exist_ok=True)
    snap_dir = os.path.join(snap_root, ts)
    # نسخ كل شيء ما عدا private/snapshots (تجنّب recursion)
    def _ignore(directory, contents):
        ig = []
        for c in contents:
            full = os.path.join(directory, c)
            rel = os.path.relpath(full, app_path)
            # تجنّب snapshots و cache و uploads (كبيرة)
            if rel.startswith(("private" + os.sep + "snapshots",
                              "cache", "sessions", "errors",
                              "uploads", "static" + os.sep + "dbbackup",
                              "__pycache__")):
                ig.append(c)
            elif c == "__pycache__":
                ig.append(c)
        return ig
    shutil.copytree(app_path, snap_dir, ignore=_ignore, dirs_exist_ok=False)
    # تنظيف snapshots قديمة (احتفظ بآخر N)
    _cleanup_old_snapshots(snap_root)
    return snap_dir


def _cleanup_old_snapshots(snap_root):
    try:
        entries = sorted([
            d for d in os.listdir(snap_root)
            if os.path.isdir(os.path.join(snap_root, d))
        ])
        for old in entries[:-SNAPSHOT_KEEP]:
            shutil.rmtree(os.path.join(snap_root, old), ignore_errors=True)
    except Exception:
        pass


def _restore_snapshot(snap_dir, app_path):
    """يستعيد التطبيق من snapshot. يحذف الملفات الجديدة ويعيد القديمة.

    خطر: يجب الحذر من حذف الـ snapshots والـ uploads نفسهم. لذلك
    نُحدّث الملفات بدلاً من حذف المجلد كاملاً."""
    for root, dirs, files in os.walk(snap_dir):
        rel = os.path.relpath(root, snap_dir)
        if rel == ".":
            rel = ""
        target_dir = os.path.join(app_path, rel) if rel else app_path
        os.makedirs(target_dir, exist_ok=True)
        for f in files:
            shutil.copy2(os.path.join(root, f), os.path.join(target_dir, f))


def _clear_pycache(app_path):
    for root, dirs, _files in os.walk(app_path):
        for d in dirs:
            if d == "__pycache__":
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)


@auth.requires(can_admin)
def up():
    return dict(local_ver=_get_local_version())


@auth.requires(can_admin)
def check_update():
    local_ver = _get_local_version()
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(status="error",
                                  message="فشل الاتصال بخادم التحديث: " + str(e)))
    try:
        has_update = float(remote_ver) > float(local_ver)
    except ValueError:
        has_update = False
    sha = _get_remote_sha256()
    return response.json(dict(
        status="ok",
        local_ver=local_ver,
        remote_ver=remote_ver,
        has_update=has_update,
        has_checksum=bool(sha),
        message=("يتوفر تحديث جديد: " + remote_ver) if has_update
        else "النسخة الحالية هي الأحدث",
    ))


@auth.requires(can_admin)
def apply_update():
    """تنزيل + تحقّق checksum + snapshot + استخراج آمن + rollback عند الفشل."""
    _appPath = request.folder
    saved_file = os.path.join(_appPath, ZIP_FILE)
    local_ver = _get_local_version()
    accept_unsigned = str(request.vars.get("accept_unsigned") or "").lower() in ("1", "true", "yes")

    # 1) فحص النسخة
    try:
        remote_ver = _get_remote_version()
    except Exception as e:
        return response.json(dict(status="error",
                                  message="فشل الاتصال: " + str(e)))
    try:
        is_newer = float(remote_ver) > float(local_ver)
    except ValueError:
        is_newer = False
    if not is_newer:
        return response.json(dict(status="up_to_date",
            message="النسخة الحالية ({}) هي الأحدث".format(local_ver)))

    # 2) فحص checksum — مطلوب افتراضياً
    expected_sha = _get_remote_sha256()
    if not expected_sha and not accept_unsigned:
        return response.json(dict(
            status="error",
            requires_confirmation=True,
            message="ملف checksum (acc.sha256) غير متاح على الخادم. "
                    "التحديث بدون توقيع خطر. أعد الاستدعاء مع accept_unsigned=true لتأكيد.",
        ))

    # 3) تنزيل الـ zip
    try:
        result = subprocess.run(
            ["curl", "-L", "--max-time", "120", "-o", saved_file,
             UPDATE_BASE_URL + ZIP_FILE],
            capture_output=True, text=True, timeout=150,
        )
        if result.returncode != 0:
            raise Exception(result.stderr or "curl download failed")
        if not os.path.exists(saved_file):
            raise Exception("الملف لم يُكتب")
        size = os.path.getsize(saved_file)
        if size < 100:
            raise Exception("الملف فارغ")
        if size > MAX_ZIP_SIZE:
            raise Exception("الملف أكبر من الحد المسموح (%d MB)" % (MAX_ZIP_SIZE // 1024 // 1024))
    except Exception as e:
        if os.path.exists(saved_file):
            os.remove(saved_file)
        return response.json(dict(status="error",
                                  message="فشل التنزيل: " + str(e)))

    # 4) فحص checksum إن وُجد
    if expected_sha:
        try:
            actual = _compute_sha256(saved_file)
            if actual.lower() != expected_sha.lower():
                os.remove(saved_file)
                return response.json(dict(
                    status="error",
                    message="checksum لا يطابق! الملف معطّل أو مُحرَّف. توقّف التحديث."
                ))
        except Exception as e:
            os.remove(saved_file)
            return response.json(dict(status="error",
                                      message="فشل التحقق من checksum: " + str(e)))

    # 5) zip safety check
    try:
        _validate_zip_safety(saved_file, _appPath)
    except Exception as e:
        os.remove(saved_file)
        return response.json(dict(status="error",
                                  message="الـ zip غير آمن: " + str(e)))

    # 6) snapshot قبل أي استبدال
    snap_dir = None
    try:
        snap_dir = _snapshot_app(_appPath)
    except Exception as e:
        os.remove(saved_file)
        return response.json(dict(status="error",
                                  message="فشل أخذ snapshot: " + str(e)))

    # 7) استخراج آمن مع rollback
    try:
        with zipfile.ZipFile(saved_file, "r") as zf:
            for info in zf.infolist():
                # تطبيع المسار
                info.filename = info.filename.replace("\\", "/")
                zf.extract(info, _appPath)
    except Exception as e:
        # rollback
        try:
            if snap_dir:
                _restore_snapshot(snap_dir, _appPath)
        except Exception:
            pass
        return response.json(dict(
            status="error",
            message="فشل فك الضغط: " + str(e) + ". تم استرجاع النسخة السابقة.",
            rolled_back=True,
        ))
    finally:
        if os.path.exists(saved_file):
            os.remove(saved_file)

    # 8) تنظيف
    _clear_pycache(_appPath)

    new_ver = _get_local_version()
    return response.json(dict(
        status="success",
        old_ver=local_ver,
        new_ver=new_ver,
        snapshot=os.path.basename(snap_dir) if snap_dir else None,
        message="تم التحديث بنجاح من {} إلى {}".format(local_ver, new_ver),
    ))


@auth.requires(can_admin)
def rollback():
    """العودة لـ snapshot بالاسم. الاستدعاء: /rollback?snapshot=20260525_143022"""
    snap_name = request.vars.get("snapshot")
    if not snap_name:
        # list available
        snap_root = os.path.join(request.folder, "private", "snapshots")
        if not os.path.exists(snap_root):
            return response.json(dict(status="error",
                                      message="لا توجد snapshots"))
        snaps = sorted([d for d in os.listdir(snap_root)
                       if os.path.isdir(os.path.join(snap_root, d))])
        return response.json(dict(status="ok", snapshots=snaps))
    # تحقق من الاسم (timestamps فقط)
    if not re.match(r"^\d{8}_\d{6}$", snap_name):
        return response.json(dict(status="error",
                                  message="اسم snapshot غير صالح"))
    snap_dir = os.path.join(request.folder, "private", "snapshots", snap_name)
    if not os.path.isdir(snap_dir):
        return response.json(dict(status="error",
                                  message="snapshot غير موجود"))
    try:
        _restore_snapshot(snap_dir, request.folder)
        _clear_pycache(request.folder)
        return response.json(dict(status="success",
                                  message="تم الاسترجاع من " + snap_name,
                                  new_ver=_get_local_version()))
    except Exception as e:
        return response.json(dict(status="error",
                                  message="فشل الاسترجاع: " + str(e)))
