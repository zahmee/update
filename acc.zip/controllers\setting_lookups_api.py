# -*- coding: utf-8 -*-
# type: ignore
"""
setting_lookups_api — جداول قيم (Lookup):
- الحسابات الختامية (Final Accounts) — key_final_account
- مراكز التكلفة (Cost Centers) — key_cost_center
- المستخدمون (users) — auth_user

استُخرج من setting_api.py في Phase 2.3 (2026-05-25).
"""


# ============================================================================
# =====================  الحسابات الختامية (Final Accounts)  =================
# ============================================================================
# جدول enum نظامي ثابت — IDs المسموح بها في كود التقارير: 1 (الميزانية)،
# 2 (الأرباح والخسائر)، 3 (المتاجرة). تعديل ID أو حذف صف نظامي يكسر التقارير.

_FINAL_SYSTEM_IDS = (1, 2, 3)


@auth.requires(can_view)
def get_key_final_account():
    """يستخدم من شاشة الشجرة المحاسبية (dropdown اختيار التصنيف الختامي)."""
    q = db(db.key_final_account).select(
        db.key_final_account.ALL, orderby=db.key_final_account.id
    )
    return response.json(q)


def _enrich_final_accounts(rows):
    """يُضيف usage_count + is_system لكل صف."""
    ids = [r.id for r in rows]
    usage = {}
    if ids:
        for row in db.executesql(
            "SELECT final_account, COUNT(*) FROM accounting_tree "
            "WHERE final_account IS NOT NULL "
            "  AND final_account IN ("
            + ",".join(["%s"] * len(ids))
            + ") "
            "GROUP BY final_account",
            placeholders=ids,
        ):
            usage[int(row[0])] = int(row[1])
    out = []
    for r in rows:
        d = r.as_dict()
        d["usage_count"] = int(usage.get(r.id, 0))
        d["is_system"] = r.id in _FINAL_SYSTEM_IDS
        out.append(d)
    return out


@auth.requires(can_view)
def get_all_final_accounts():
    rows = db(db.key_final_account.id > 0).select(
        db.key_final_account.ALL, orderby=db.key_final_account.id
    )
    return response.json(_enrich_final_accounts(rows))


def _validate_final_account(row, fa_id=None):
    name = (row.get("name") or "").strip()
    if not name:
        return "اسم الحساب الختامي مطلوب"
    if len(name) > 150:
        return "الاسم يتجاوز 150 حرفاً"
    dup = db.key_final_account.name == name
    if fa_id:
        dup &= db.key_final_account.id != fa_id
    if db(dup).count() > 0:
        return "يوجد حساب ختامي مسجل بنفس الاسم"
    return None


@auth.requires(can_account)
def add_final_account():
    """إضافة نوع ختامي مخصص — للأغراض التصنيفية فقط."""
    try:
        row = request.vars
        err = _validate_final_account(row)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        nid = db.key_final_account.insert(
            name=(row.get("name") or "").strip(),
            show_account=int(row.get("show_account") or 1),
        )
        db.commit()
        return response.json({"err": 0, "id": nid, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def update_final_account():
    """تعديل اسم/إتاحة الحساب الختامي. الـ ID محظور تغييره."""
    try:
        row = request.vars
        fid = row.get("id")
        rec = db.key_final_account[fid] if fid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "الحساب الختامي غير موجود"})
        err = _validate_final_account(row, fa_id=fid)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        new_show = int(row.get("show_account") or 1)
        if int(rec.id) in _FINAL_SYSTEM_IDS and new_show != 1:
            return response.json({
                "err": 1, "id": 0,
                "mess": "الحسابات الختامية النظامية (الميزانية، الأرباح والخسائر، المتاجرة) "
                        "يجب أن تبقى متاحة — لا يمكن إخفاؤها."
            })
        rec.update_record(
            name=(row.get("name") or "").strip(),
            show_account=new_show,
        )
        db.commit()
        return response.json({"err": 0, "id": fid, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_admin)
def delete_final_account():
    """حذف ممنوع للنظامية (1،2،3) ولأي صف عليه حسابات مرتبطة."""
    try:
        fid = request.vars.get("id")
        rec = db.key_final_account[fid] if fid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "الحساب الختامي غير موجود"})
        if int(rec.id) in _FINAL_SYSTEM_IDS:
            return response.json({
                "err": 2, "id": 0,
                "mess": "هذا تصنيف نظامي تعتمد عليه تقارير الميزانية والأرباح والخسائر "
                        "والمتاجرة. الحذف ممنوع. يمكنك تعديل اسمه فقط."
            })
        used = db(db.accounting_tree.final_account == int(fid)).count()
        if used > 0:
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن حذف هذا التصنيف لارتباطه بـ %d حساب في الشجرة المحاسبية. "
                        "أعد تصنيف تلك الحسابات أولاً." % used,
            })
        rec.delete_record()
        db.commit()
        return response.json({"err": 0, "id": fid, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


# ============================================================================
# =====================  مراكز التكلفة (Cost Centers)  =======================
# ============================================================================


@auth.requires(can_view)
def key_cost_center():
    """يُستخدم من شاشة القيود (يومية) — يُرجع المراكز المتاحة فقط."""
    q = db(db.key_cost_center.show_cost == 1).select(
        db.key_cost_center.ALL, orderby=db.key_cost_center.name
    )
    return response.json(q)


def _enrich_cost_centers(rows):
    """يُضيف عدد القيود المرتبطة بكل مركز."""
    ids = [r.id for r in rows]
    usage = {}
    if ids:
        for row in db.executesql(
            "SELECT cost_center, COUNT(*) FROM journal_entry_detail "
            "WHERE cost_center IS NOT NULL "
            "  AND cost_center IN ("
            + ",".join(["%s"] * len(ids))
            + ") "
            "GROUP BY cost_center",
            placeholders=ids,
        ):
            usage[int(row[0])] = int(row[1])
    out = []
    for r in rows:
        d = r.as_dict()
        d["usage_count"] = int(usage.get(r.id, 0))
        out.append(d)
    return out


@auth.requires(can_view)
def get_all_cost_centers():
    rows = db(db.key_cost_center.id > 0).select(
        db.key_cost_center.ALL, orderby=db.key_cost_center.id
    )
    return response.json(_enrich_cost_centers(rows))


def _validate_cost_center(row, cc_id=None):
    name = (row.get("name") or "").strip()
    if not name:
        return "اسم/وصف مركز التكلفة مطلوب"
    if len(name) > 150:
        return "اسم المركز يتجاوز 150 حرفاً"
    dup = db.key_cost_center.name == name
    if cc_id:
        dup &= db.key_cost_center.id != cc_id
    if db(dup).count() > 0:
        return "يوجد مركز تكلفة مسجل بنفس الاسم"
    return None


def _cost_center_fields(row):
    return dict(
        name=(row.get("name") or "").strip(),
        show_cost=int(row.get("show_cost") or 1),
    )


@auth.requires(can_account)
def add_cost_center():
    try:
        row = request.vars
        err = _validate_cost_center(row)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        nid = db.key_cost_center.insert(**_cost_center_fields(row))
        db.commit()
        return response.json({"err": 0, "id": nid, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def update_cost_center():
    try:
        row = request.vars
        cid = row.get("id")
        rec = db.key_cost_center[cid] if cid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "مركز التكلفة غير موجود"})
        err = _validate_cost_center(row, cc_id=cid)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        rec.update_record(**_cost_center_fields(row))
        db.commit()
        return response.json({"err": 0, "id": cid, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def delete_cost_center():
    """حذف فيزيائي ممنوع لمركز مستخدم في القيود — يُقترح الإخفاء بدلاً."""
    try:
        cid = request.vars.get("id")
        rec = db.key_cost_center[cid] if cid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "مركز التكلفة غير موجود"})
        used = db(db.journal_entry_detail.cost_center == int(cid)).count()
        if used > 0:
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن حذف المركز لارتباطه بـ %d قيد في النظام. "
                "أخفِ المركز بدلاً من حذفه ليظل تاريخه في القيود سليماً." % used,
            })
        rec.delete_record()
        db.commit()
        return response.json({"err": 0, "id": cid, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def toggle_cost_center_visibility():
    """تبديل تأشيرة العرض (متاح/مخفي) بدون إعادة كل الحقول."""
    try:
        cid = request.vars.get("id")
        rec = db.key_cost_center[cid] if cid else None
        if not rec:
            return response.json({"err": 1, "mess": "مركز التكلفة غير موجود"})
        new_v = 2 if int(rec.show_cost or 1) == 1 else 1
        rec.update_record(show_cost=new_v)
        db.commit()
        return response.json({"err": 0, "id": cid, "show_cost": new_v, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ============================================================================
# =====================  المستخدمون / الشاشات  ================================
# ============================================================================


@auth.requires(can_view)
def get_all_users():
    q = db(db.auth_user.id > 0).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
    )
    return response.json(q)


def get_screen_data():
    screens = [
        {"screen": "f001", "dis": "شاشة الصلاحيات", "level": 0},
        {"screen": "f002", "dis": "شاشة الدورات المالية", "level": 1},
        {"screen": "f003", "dis": "شاشة الشجرة المحاسبية", "level": 1},
        {"screen": "f004", "dis": "شاشة الفروع", "level": 1},
    ]
    return response.json(screens)
