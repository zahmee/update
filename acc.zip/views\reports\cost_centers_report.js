// ======================  تقرير مراكز التكلفة — منطق Vue 3  ======================
// شاشتان في واحدة: ملخّص (جدول كل المراكز) + تفصيل (سطور المركز المختار)

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_cost_centers_api/',
            settingApi: window.purl + '/../../setting_api/',

            branches: [],
            periods: [],

            filters: {
                branch: 0,
                period: 0,
                date_from: '',
                date_to: '',
                include_hidden: false,
            },

            summary: null,
            details: null,
            selectedCC: null,
            loading: false,
            _sumSeq: 0,
            _detSeq: 0,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                self.reloadSummary();
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        reloadSummary() {
            var self = this;
            var seq = ++this._sumSeq;
            this.loading = true;
            this.selectedCC = null;
            this.details = null;
            var body = {
                branch: this.filters.branch || 0,
                period: this.filters.period || 0,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || '',
                include_hidden: this.filters.include_hidden ? '1' : '',
            };
            axios.post(this.api + 'cost_centers_summary/', body).then(res => {
                if (seq !== self._sumSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: d.mess || '' });
                    self.summary = null;
                } else {
                    self.summary = d;
                }
            }).catch(() => {
                if (seq === self._sumSeq) self.summary = null;
            }).finally(() => {
                if (seq === self._sumSeq) self.loading = false;
            });
        },

        reloadAll() {
            this.reloadSummary();
            // إن كان هناك مركز مختار → أعد تحميل تفصيله أيضاً
            if (this.selectedCC) {
                var sel = this.selectedCC;
                setTimeout(() => { this.selectCC(sel); }, 50);
            }
        },

        selectCC(cc) {
            this.selectedCC = cc;
            var self = this;
            var seq = ++this._detSeq;
            this.details = null;
            var body = {
                cost_center: cc.id,
                branch: this.filters.branch || 0,
                period: this.filters.period || 0,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || '',
            };
            axios.post(this.api + 'cost_center_details/', body).then(res => {
                if (seq !== self._detSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: d.mess || '' });
                } else {
                    self.details = d;
                }
            });
        },

        onPeriodChange() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                if (p.start_date) this.filters.date_from = p.start_date;
                if (p.end_date) this.filters.date_to = p.end_date;
            }
            this.reloadAll();
        },

        resetToFullPeriod() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                this.filters.date_from = p.start_date || '';
                this.filters.date_to = p.end_date || '';
                this.reloadAll();
            }
        },

        printUrl(jid) { return this.URL + '/../../operations/journal_entry_print/' + jid; },

        printReport() { window.print(); },

        exportSummaryExcel() {
            if (!this.summary || !this.summary.count) return;
            var params = new URLSearchParams();
            Object.keys(this.filters).forEach(k => {
                var v = this.filters[k];
                if (v !== '' && v !== null && v !== undefined && v !== false) {
                    params.append(k, (typeof v === 'boolean') ? '1' : v);
                }
            });
            params.append('format', 'xlsx');
            window.open(this.api + 'cost_centers_summary?' + params.toString(), '_blank');
        },

        exportDetailExcel() {
            if (!this.selectedCC || !this.details) return;
            var params = new URLSearchParams();
            params.append('cost_center', this.selectedCC.id);
            ['branch', 'period', 'date_from', 'date_to'].forEach(k => {
                var v = this.filters[k];
                if (v !== '' && v !== null && v !== undefined) params.append(k, v);
            });
            params.append('format', 'xlsx');
            window.open(this.api + 'cost_center_details?' + params.toString(), '_blank');
        },

        fmt(n) { return fmtNumber(n); },

        fmtNet(n) {
            var v = Number(n) || 0;
            if (v === 0) return '0.00';
            if (v > 0) return fmtNumber(v) + ' (مدين)';
            return fmtNumber(-v) + ' (دائن)';
        },

        netClass(n) {
            var v = Number(n) || 0;
            if (v > 0) return 'is-debit';
            if (v < 0) return 'is-credit';
            return 'is-zero';
        },
    },
});

var app = vueApp.mount('#app');
