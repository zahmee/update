# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_statements_api — القوائم المالية المعيارية:
- income_statement  — قائمة الدخل (Income Statement)
- balance_sheet     — الميزانية العمومية (Balance Sheet)

استُخرج من reports_api.py في Phase 2.2 (2026-05-25).
"""

import acc_dates
import acc_export

_parse_date = acc_dates.parse_flexible_date


@auth.requires(can_view)
def income_statement():
    """قائمة الدخل - Income Statement
    تحسب الإيرادات والمصروفات وصافي الربح/الخسارة
    final_account=2 => أرباح وخسائر (P&L)
    final_account=3 => متاجرة (Trading)
    """
    try:
        row = request.vars
        da1 = row['start_date']
        da2 = row['end_date']
        branch_select = int(row['branch_select'])

        per = db(db.account_periods.open_period == 1).select(orderby=db.account_periods.id).first()

        qry = (
            "SELECT *, "
            "  (SELECT count(*) FROM accounting_tree tt1 "
            "   WHERE branches=%s "
            "    AND tt1.main_account = accounting_tree.account_no) AS tag1 "
            "FROM accounting_tree WHERE branches=%s "
            " AND account_periods=%s "
            " AND final_account IN (2, 3) "
            " ORDER BY final_account, account_no "
        )
        data = db.executesql(qry, placeholders=[
            branch_select, branch_select, int(per.id)], as_dict=True)

        revenues = []
        expenses = []
        trading = []

        for r in data:
            if r['main_account'] != '0':
                parent = db(
                    (db.accounting_tree.account_no == r['main_account']) &
                    (db.accounting_tree.branches == branch_select)
                ).select().first()
                if parent:
                    r['account_name'] = parent.account_name_ar + ' > ' + r['account_name_ar']
                else:
                    r['account_name'] = r['account_name_ar']
            else:
                r['account_name'] = r['account_name_ar']

            movement = (
                "SELECT COALESCE(SUM(debit),0) AS m_db, COALESCE(SUM(credit),0) AS m_cr "
                "FROM journal_entry_detail WHERE "
                " account_no LIKE %s "
                " AND journal_date >= %s "
                " AND journal_date <= %s "
                " AND branches = %s "
                " AND account_periods = %s "
            )
            movement_data = db.executesql(movement, placeholders=[
                str(r['account_no']) + '%',
                _parse_date(da1, "تاريخ البداية"),
                _parse_date(da2, "تاريخ النهاية"),
                branch_select, int(per.id)], as_dict=True)
            r['debit'] = round(float(movement_data[0]['m_db'] or 0), 2)
            r['credit'] = round(float(movement_data[0]['m_cr'] or 0), 2)
            r['balance'] = round(r['debit'] - r['credit'], 2)

            # ملاحظة محاسبية مهمة (Fix 2026-05-26): حسابات قائمة الدخل (P&L)
            # لا تحمل أرصدة افتتاحية في الواقع المحاسبي — تُغلق سنوياً للأرباح
            # المُحتجزة. لذا net يُحسب من حركة الفترة فقط، تماشياً مع
            # balance_sheet الذي يحسب net_income من journal_entry_detail فقط.
            # start_debit/start_credit تُحفظ كصفر للحفاظ على شكل الرد.
            r['start_debit'] = 0.0
            r['start_credit'] = 0.0
            r['net'] = round(r['debit'] - r['credit'], 2)

            if r['final_account'] == 3:
                trading.append(r)
            elif r['account_type'] == 1:
                revenues.append(r)
            else:
                expenses.append(r)

        total_revenues = round(sum(
            abs(r['net']) for r in revenues if r['tag1'] == 0
        ), 2)
        total_expenses = round(sum(
            abs(r['net']) for r in expenses if r['tag1'] == 0
        ), 2)
        total_trading = round(sum(
            -r['net'] for r in trading if r['tag1'] == 0
        ), 2)
        net_income = round(total_revenues - total_expenses + total_trading, 2)

        result = {
            'revenues': revenues,
            'expenses': expenses,
            'trading': trading,
            'total_revenues': total_revenues,
            'total_expenses': total_expenses,
            'total_trading': total_trading,
            'net_income': net_income
        }
        if str(row.get("format") or "").lower() == "xlsx":
            return _income_statement_xlsx(result, row, da1, da2, branch_select, per)
        return response.json(result)
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


def _income_statement_xlsx(data, row, da1, da2, branch_select, per):
    """يحوّل ردّ income_statement إلى xlsx."""
    branch = db.branches[branch_select]
    branch_name = branch.name if branch else "—"
    columns = [
        {"key": "account_no", "title": "رقم الحساب", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 32},
        {"key": "debit", "title": "مدين", "format": "currency"},
        {"key": "credit", "title": "دائن", "format": "currency"},
        {"key": "net", "title": "صافي", "format": "currency"},
    ]
    rows = []

    def _section(title, items):
        rows.append({"account_no": "", "account_name": "═══ " + title + " ═══",
                     "debit": "", "credit": "", "net": ""})
        for r in items:
            rows.append({
                "account_no": r["account_no"],
                "account_name": "    " + (r.get("account_name") or ""),
                "debit": r.get("debit", 0),
                "credit": r.get("credit", 0),
                "net": r["net"] if r.get("tag1", 0) == 0 else "",
            })

    _section("الإيرادات", data["revenues"])
    rows.append({"account_no": "", "account_name": "إجمالي الإيرادات",
                 "debit": "", "credit": "", "net": data["total_revenues"]})
    rows.append({"account_no": "", "account_name": "", "debit": "", "credit": "", "net": ""})
    _section("المصروفات", data["expenses"])
    rows.append({"account_no": "", "account_name": "إجمالي المصروفات",
                 "debit": "", "credit": "", "net": data["total_expenses"]})
    if data["trading"]:
        rows.append({"account_no": "", "account_name": "", "debit": "", "credit": "", "net": ""})
        _section("المتاجرة", data["trading"])
        rows.append({"account_no": "", "account_name": "إجمالي المتاجرة",
                     "debit": "", "credit": "", "net": data["total_trading"]})

    totals_row = {
        "account_no": "",
        "account_name": "صافي الربح (الخسارة)",
        "debit": "",
        "credit": "",
        "net": data["net_income"],
    }
    meta = [
        ("الفرع", branch_name),
        ("الدورة", per.disc if per else "—"),
        ("من", acc_dates.date_str(da1)),
        ("إلى", acc_dates.date_str(da2)),
    ]
    fname = "income_statement_%s.xlsx" % acc_dates.date_slug(da2)
    return acc_export.xlsx_response(
        response, fname,
        title="قائمة الدخل",
        meta=meta,
        columns=columns,
        rows=rows,
        totals=totals_row,
        sheet_name="قائمة الدخل",
    )


@auth.requires(can_view)
def balance_sheet():
    """الميزانية العمومية - Balance Sheet
    تحسب الأصول والخصوم وحقوق الملكية
    final_account=1 => الميزانية (Balance Sheet)
    """
    try:
        row = request.vars
        da2 = row['end_date']
        branch_select = int(row['branch_select'])

        per = db(db.account_periods.open_period == 1).select(orderby=db.account_periods.id).first()

        qry = (
            "SELECT *, "
            "  (SELECT count(*) FROM accounting_tree tt1 "
            "   WHERE branches=%s "
            "    AND tt1.main_account = accounting_tree.account_no) AS tag1 "
            "FROM accounting_tree WHERE branches=%s "
            " AND account_periods=%s "
            " AND final_account = 1 "
            " ORDER BY account_type, account_no "
        )
        data = db.executesql(qry, placeholders=[
            branch_select, branch_select, int(per.id)], as_dict=True)

        assets = []
        liabilities = []

        for r in data:
            if r['main_account'] != '0':
                parent = db(
                    (db.accounting_tree.account_no == r['main_account']) &
                    (db.accounting_tree.branches == branch_select)
                ).select().first()
                if parent:
                    r['account_name'] = parent.account_name_ar + ' > ' + r['account_name_ar']
                else:
                    r['account_name'] = r['account_name_ar']
            else:
                r['account_name'] = r['account_name_ar']

            movement = (
                "SELECT COALESCE(SUM(debit),0) AS m_db, COALESCE(SUM(credit),0) AS m_cr "
                "FROM journal_entry_detail WHERE "
                " account_no LIKE %s "
                " AND journal_date <= %s "
                " AND branches = %s "
                " AND account_periods = %s "
            )
            movement_data = db.executesql(movement, placeholders=[
                str(r['account_no']) + '%',
                _parse_date(da2, "تاريخ النهاية"),
                branch_select, int(per.id)], as_dict=True)
            r['debit'] = round(float(movement_data[0]['m_db'] or 0), 2)
            r['credit'] = round(float(movement_data[0]['m_cr'] or 0), 2)

            start_qry = (
                "SELECT COALESCE(SUM(debit),0) AS s_db, COALESCE(SUM(credit),0) AS s_cr "
                "FROM account_periods_opening WHERE "
                " account_no LIKE %s "
                " AND account_periods = %s "
                " AND branches = %s "
            )
            start_data = db.executesql(start_qry, placeholders=[
                str(r['account_no']) + '%', int(per.id), branch_select], as_dict=True)
            r['start_debit'] = round(float(start_data[0]['s_db'] or 0), 2)
            r['start_credit'] = round(float(start_data[0]['s_cr'] or 0), 2)

            total_debit = r['debit'] + r['start_debit']
            total_credit = r['credit'] + r['start_credit']

            if total_debit > total_credit:
                r['balance'] = round(total_debit - total_credit, 2)
            else:
                r['balance'] = round(total_credit - total_debit, 2) * -1

            if r['account_type'] == 2:
                r['balance'] = abs(round(total_debit - total_credit, 2))
                assets.append(r)
            else:
                r['balance'] = abs(round(total_credit - total_debit, 2))
                liabilities.append(r)

        pl_qry = (
            "SELECT "
            "  COALESCE(SUM(CASE WHEN account_type=2 THEN jd.debit - jd.credit ELSE 0 END), 0) AS total_expenses, "
            "  COALESCE(SUM(CASE WHEN account_type=1 THEN jd.credit - jd.debit ELSE 0 END), 0) AS total_revenues "
            "FROM journal_entry_detail jd "
            "INNER JOIN accounting_tree at ON jd.accounting_tree = at.id "
            "WHERE jd.branches = %s "
            " AND jd.account_periods = %s "
            " AND jd.journal_date <= %s "
            " AND at.final_account IN (2, 3) "
        )
        pl_data = db.executesql(pl_qry, placeholders=[
            branch_select, int(per.id),
            _parse_date(da2, "تاريخ النهاية")], as_dict=True)
        net_income = round(
            float(pl_data[0]['total_revenues'] or 0) - float(pl_data[0]['total_expenses'] or 0), 2
        )

        total_assets = round(sum(
            r['balance'] for r in assets if r['tag1'] == 0
        ), 2)
        total_liabilities = round(sum(
            r['balance'] for r in liabilities if r['tag1'] == 0
        ), 2)
        total_equity = round(total_liabilities + net_income, 2)

        result = {
            'assets': assets,
            'liabilities': liabilities,
            'total_assets': total_assets,
            'total_liabilities': total_liabilities,
            'net_income': net_income,
            'total_equity': total_equity
        }
        if str(row.get("format") or "").lower() == "xlsx":
            return _balance_sheet_xlsx(result, row, da2, branch_select, per)
        return response.json(result)
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


def _balance_sheet_xlsx(data, row, da2, branch_select, per):
    """يحوّل ردّ balance_sheet إلى xlsx."""
    branch = db.branches[branch_select]
    branch_name = branch.name if branch else "—"
    columns = [
        {"key": "account_no", "title": "رقم الحساب", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 32},
        {"key": "balance", "title": "الرصيد", "format": "currency"},
    ]
    rows = []
    rows.append({"account_no": "", "account_name": "═══ الأصول ═══", "balance": ""})
    for r in data["assets"]:
        rows.append({
            "account_no": r["account_no"],
            "account_name": "    " + (r.get("account_name") or ""),
            "balance": r["balance"] if r.get("tag1", 0) == 0 else "",
        })
    rows.append({
        "account_no": "",
        "account_name": "إجمالي الأصول",
        "balance": data["total_assets"],
    })
    rows.append({"account_no": "", "account_name": "", "balance": ""})
    rows.append({"account_no": "", "account_name": "═══ الخصوم وحقوق الملكية ═══", "balance": ""})
    for r in data["liabilities"]:
        rows.append({
            "account_no": r["account_no"],
            "account_name": "    " + (r.get("account_name") or ""),
            "balance": r["balance"] if r.get("tag1", 0) == 0 else "",
        })
    rows.append({
        "account_no": "",
        "account_name": "إجمالي الخصوم",
        "balance": data["total_liabilities"],
    })
    rows.append({
        "account_no": "",
        "account_name": "صافي الربح (الخسارة) من قائمة الدخل",
        "balance": data["net_income"],
    })
    totals_row = {
        "account_no": "",
        "account_name": "إجمالي الخصوم وحقوق الملكية",
        "balance": data["total_equity"],
    }
    health_msg = "متوازن" if abs(data["total_assets"] - data["total_equity"]) < 0.01 else (
        "غير متوازن (الفرق = %.2f)" % (data["total_assets"] - data["total_equity"])
    )
    meta = [
        ("الفرع", branch_name),
        ("الدورة", per.disc if per else "—"),
        ("حتى تاريخ", acc_dates.date_str(da2)),
        ("حالة التوازن", health_msg),
    ]
    fname = "balance_sheet_%s.xlsx" % acc_dates.date_slug(da2)
    return acc_export.xlsx_response(
        response, fname,
        title="الميزانية العمومية",
        meta=meta,
        columns=columns,
        rows=rows,
        totals=totals_row,
        sheet_name="الميزانية",
    )
