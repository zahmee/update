# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_account_api — كشوف الحساب:
- acount_balanc    — كشف حساب واحد + رصيد متحرّك
- acount_balanc_2  — كشف عدة حسابات (block per account)
- acount_balanc_3  — ملخص إجماليات حسابات (صف لكل حساب)

استُخرج من reports_api.py في Phase 2.2 (2026-05-25).
يعتمد على modules/acc_balance لمنطق الكشف نفسه.
"""

from datetime import datetime

import acc_balance
import acc_export
import acc_summary


# helper shim للتوافق مع كود acount_balanc_2/3
def _build_account_statement(branch_id, period_id, account_id, date_from, date_to):
    return acc_balance.build_account_statement(
        db, branch_id, period_id, account_id, date_from, date_to,
    )


def _parse_multi(v):
    """يحلّل بارامترات كشوف الحسابات المتعدّدة (مشترك بين acount_balanc_2/3).
    يُرجع {ok:True, branch_id, period, branch, account_ids, date_from, date_to}
    أو {ok:False, mess}."""
    try:
        branch_id = int(v.get("branch") or 0)
        period_id = int(v.get("period") or 0)
    except Exception:
        return {"ok": False, "mess": "قيمة فرع/دورة غير صحيحة"}
    if branch_id <= 0:
        return {"ok": False, "mess": "الفرع مطلوب"}

    raw_ids = v.get("account_ids")
    if raw_ids is None:
        return {"ok": False, "mess": "اختر حساباً واحداً على الأقل"}
    if isinstance(raw_ids, str):
        account_ids = [int(x) for x in raw_ids.split(",") if x.strip().isdigit()]
    elif isinstance(raw_ids, list):
        account_ids = []
        for x in raw_ids:
            try:
                account_ids.append(int(x))
            except Exception:
                pass
    else:
        account_ids = []
    if not account_ids:
        return {"ok": False, "mess": "اختر حساباً واحداً على الأقل"}

    if period_id <= 0:
        per = db(db.account_periods.open_period == 1).select(
            orderby=db.account_periods.id
        ).first()
        if not per:
            return {"ok": False, "mess": "لا توجد دورة"}
        period_id = per.id
    period = db.account_periods[period_id]
    if not period:
        return {"ok": False, "mess": "الدورة غير موجودة"}
    branch = db.branches[branch_id]
    if not branch:
        return {"ok": False, "mess": "الفرع غير موجود"}

    date_from = None
    date_to = None
    if v.get("date_from"):
        try:
            date_from = datetime.strptime(str(v.get("date_from"))[:10], "%Y-%m-%d").date()
        except Exception:
            pass
    if v.get("date_to"):
        try:
            date_to = datetime.strptime(str(v.get("date_to"))[:10], "%Y-%m-%d").date()
        except Exception:
            pass
    if not date_from:
        date_from = period.start_date
    if not date_to:
        date_to = period.end_date

    return {
        "ok": True, "branch_id": branch_id, "period": period, "branch": branch,
        "account_ids": account_ids, "date_from": date_from, "date_to": date_to,
    }


@auth.requires(can_view)
def acount_balanc():
    """كشف حساب — حركة حساب واحد عبر فترة مع رصيد متحرّك.
    vars: branch, period, account_id, date_from?, date_to? (YYYY-MM-DD).
    الرد: {err, account, opening, movements, totals, ending, health}. format=xlsx مدعوم.
    """
    try:
        v = request.vars
        try:
            branch_id = int(v.get("branch") or v.get("branch_select") or 0)
            account_id = int(v.get("account_id") or 0)
        except Exception:
            return response.json({"err": 1, "mess": "قيمة فرع/حساب غير صحيحة"})
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})
        if account_id <= 0:
            return response.json({"err": 1, "mess": "اختر الحساب"})

        acc = db.accounting_tree[account_id]
        if not acc:
            return response.json({"err": 1, "mess": "الحساب غير موجود"})
        if int(acc.branches) != branch_id:
            return response.json({"err": 1, "mess": "الحساب لا يتبع الفرع المحدد"})

        try:
            period_id = int(v.get("period") or 0)
        except Exception:
            period_id = 0
        if period_id <= 0:
            period_id = int(acc.account_periods or 0)
        if period_id <= 0:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة مالية"})
            period_id = per.id
        period = db.account_periods[period_id]
        if not period:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})

        date_from = None
        date_to = None
        if v.get("date_from"):
            try:
                date_from = datetime.strptime(str(v.get("date_from"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if v.get("date_to"):
            try:
                date_to = datetime.strptime(str(v.get("date_to"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if not date_from:
            date_from = period.start_date
        if not date_to:
            date_to = period.end_date

        # كشف الحساب نفسه من acc_balance (نفس منطق build_account_statement — DRY)
        st = acc_balance.build_account_statement(
            db, branch_id, period_id, account_id, date_from, date_to)
        if st is None:
            return response.json({"err": 1, "mess": "تعذّر بناء كشف الحساب"})

        movements = st["movements"]
        result = dict(st)
        result["err"] = 0
        result["branch"] = {
            "id": int(branch_id),
            "name": (db.branches[branch_id].name if db.branches[branch_id] else "—"),
        }
        result["period"] = {
            "id": int(period_id), "disc": period.disc,
            "open_period": int(period.open_period or 0),
            "start_date": str(period.start_date),
            "end_date": str(period.end_date),
        }
        result["date_from"] = str(date_from)
        result["date_to"] = str(date_to)
        result["health"] = {
            "running_matches": (not movements)
            or abs(movements[-1]["running_balance"] - st["ending"]["net"]) < 0.005,
        }
        if str(v.get("format") or "").lower() == "xlsx":
            return _account_report_xlsx(result)
        return response.json(result)
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


def _account_report_xlsx(data):
    """يحوّل ردّ acount_balanc إلى xlsx — كشف حركة حساب واحد."""
    columns = [
        {"key": "journal_date", "title": "التاريخ", "format": "text", "width": 12},
        {"key": "journal_id", "title": "رقم القيد", "format": "number", "width": 10},
        {"key": "account_no", "title": "حساب فرعي", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 26},
        {"key": "detail", "title": "البيان", "format": "text", "width": 30},
        {"key": "cost_center", "title": "مركز التكلفة", "format": "text", "width": 14},
        {"key": "debit", "title": "مدين", "format": "currency"},
        {"key": "credit", "title": "دائن", "format": "currency"},
        {"key": "running_balance", "title": "الرصيد", "format": "currency"},
    ]
    opening = data["opening"]
    rows = [{
        "journal_date": data["date_from"],
        "journal_id": "",
        "account_no": "",
        "account_name": "",
        "detail": "رصيد افتتاحي",
        "cost_center": "",
        "debit": opening["debit"],
        "credit": opening["credit"],
        "running_balance": opening["net"],
    }]
    for m in data["movements"]:
        rows.append({
            "journal_date": m.get("journal_date") or "",
            "journal_id": m.get("journal_id") or "",
            "account_no": m.get("account_no") or "",
            "account_name": m.get("account_name") or "",
            "detail": (m.get("master_detail") or "") + (
                " | " + m.get("detail") if m.get("detail") else ""
            ),
            "cost_center": m.get("cost_center_name") or "",
            "debit": m.get("debit") or 0,
            "credit": m.get("credit") or 0,
            "running_balance": m.get("running_balance") or 0,
        })
    totals = data["totals"]
    ending = data["ending"]
    totals_row = {
        "journal_date": data["date_to"],
        "journal_id": "",
        "account_no": "",
        "account_name": "",
        "detail": "",
        "cost_center": "الإجمالي",
        "debit": totals["debit"],
        "credit": totals["credit"],
        "running_balance": ending["net"],
    }
    acc_info = data["account"]
    meta = [
        ("الحساب", acc_info["account_no"] + " — " + acc_info["account_name"]),
        ("الفرع", data["branch"]["name"]),
        ("الدورة", data["period"]["disc"]),
        ("من", data["date_from"]),
        ("إلى", data["date_to"]),
        ("عدد العمليات", totals["count"]),
    ]
    fname = "account_%s_%s.xlsx" % (
        acc_info["account_no"].replace("/", "_"), data["date_to"],
    )
    return acc_export.xlsx_response(
        response, fname,
        title="كشف حساب — " + (acc_info["account_name"] or acc_info["account_no"]),
        meta=meta,
        columns=columns,
        rows=rows,
        totals=totals_row,
        sheet_name="كشف حساب",
    )


@auth.requires(can_view)
def acount_balanc_2():
    """كشف حساب متعدّد — يجمع كشوفات عدة حسابات في تقرير واحد.

    Body:
      branch, period (مطلوبان)
      account_ids — list[int]  أو CSV string لـ IDs
      date_from, date_to — YYYY-MM-DD (اختياري)

    Returns:
      {err, branch, period, date_from, date_to, entries: [...account-statements...],
       totals: {debit, credit, net_movement, count},
       opening_total: {debit, credit}, ending_total: {debit, credit}}
    """
    try:
        p = _parse_multi(request.vars)
        if not p["ok"]:
            return response.json({"err": 1, "mess": p["mess"]})
        branch_id = p["branch_id"]
        period = p["period"]
        period_id = period.id
        branch = p["branch"]
        account_ids = p["account_ids"]
        date_from = p["date_from"]
        date_to = p["date_to"]

        entries = []
        sum_open_debit = 0.0
        sum_open_credit = 0.0
        sum_period_debit = 0.0
        sum_period_credit = 0.0
        sum_end_debit = 0.0
        sum_end_credit = 0.0
        sum_movements_count = 0
        for aid in account_ids:
            # حساب رئيسي (له أبناء) → ملخّص إجماليات فروعه فقط؛ وإلا كشف حركة مفصّل
            st = acc_summary.build_children_summary(
                db, branch_id, period_id, aid, date_from, date_to)
            if st is None:
                st = _build_account_statement(branch_id, period_id, aid, date_from, date_to)
                if st is not None:
                    st["is_summary"] = False
            if st is None:
                continue
            entries.append(st)
            sum_open_debit += st["opening"]["debit"]
            sum_open_credit += st["opening"]["credit"]
            sum_period_debit += st["totals"]["debit"]
            sum_period_credit += st["totals"]["credit"]
            sum_end_debit += st["ending"]["debit"]
            sum_end_credit += st["ending"]["credit"]
            sum_movements_count += st["totals"].get("count", 0)

        return response.json({
            "err": 0,
            "branch": {"id": branch.id, "name": branch.name},
            "period": {
                "id": period.id, "disc": period.disc,
                "open_period": int(period.open_period or 0),
                "start_date": str(period.start_date),
                "end_date": str(period.end_date),
            },
            "date_from": str(date_from), "date_to": str(date_to),
            "entries": entries,
            "totals": {
                "debit": round(sum_period_debit, 2),
                "credit": round(sum_period_credit, 2),
                "net_movement": round(sum_period_debit - sum_period_credit, 2),
                "count": sum_movements_count,
                "accounts_count": len(entries),
            },
            "opening_total": {
                "debit": round(sum_open_debit, 2),
                "credit": round(sum_open_credit, 2),
            },
            "ending_total": {
                "debit": round(sum_end_debit, 2),
                "credit": round(sum_end_credit, 2),
            },
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_view)
def acount_balanc_3():
    """إجماليات مخصص — ملخص أرصدة لحسابات مختارة (صف واحد لكل حساب).
    يعيد استخدام helper `_build_account_statement` ويتجاهل movements.
    """
    try:
        p = _parse_multi(request.vars)
        if not p["ok"]:
            return response.json({"err": 1, "mess": p["mess"]})
        branch_id = p["branch_id"]
        period = p["period"]
        period_id = period.id
        branch = p["branch"]
        account_ids = p["account_ids"]
        date_from = p["date_from"]
        date_to = p["date_to"]

        items = []
        grand = {
            "open_debit": 0.0, "open_credit": 0.0,
            "mov_debit": 0.0, "mov_credit": 0.0,
            "close_debit": 0.0, "close_credit": 0.0,
        }
        for aid in account_ids:
            st = _build_account_statement(branch_id, period_id, aid, date_from, date_to)
            if st is None:
                continue
            items.append({
                "account": st["account"],
                "opening": st["opening"],
                "totals": st["totals"],
                "ending": st["ending"],
            })
            grand["open_debit"] += st["opening"]["debit"]
            grand["open_credit"] += st["opening"]["credit"]
            grand["mov_debit"] += st["totals"]["debit"]
            grand["mov_credit"] += st["totals"]["credit"]
            grand["close_debit"] += st["ending"]["debit"]
            grand["close_credit"] += st["ending"]["credit"]
        for k in grand:
            grand[k] = round(grand[k], 2)
        grand["mov_diff"] = round(grand["mov_debit"] - grand["mov_credit"], 2)

        return response.json({
            "err": 0,
            "branch": {"id": branch.id, "name": branch.name},
            "period": {
                "id": period.id, "disc": period.disc,
                "open_period": int(period.open_period or 0),
                "start_date": str(period.start_date),
                "end_date": str(period.end_date),
            },
            "date_from": str(date_from), "date_to": str(date_to),
            "items": items,
            "grand": grand,
            "count": len(items),
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_view)
def accounts_for_report():
    """/accounts_for_report/<branch>/[<period>] — كل حسابات الفرع/الدورة
    (رئيسية وفرعية) للاختيار في كشف الحساب المخصص. يشمل الآباء (بخلاف
    get_accounts_for_journal) وبصلاحية can_view. كل حساب يحمل is_parent +
    children_count + parent_name + المستوى/النوع/الحساب الختامي + label."""
    try:
        branch_id = int(request.args(0) or 0)
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})
        per_id = request.args(1)
        if per_id:
            per_id = int(per_id)
        else:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة مفتوحة"})
            per_id = per.id
        rows = db.executesql(
            "SELECT at.id, at.account_no, at.account_name_ar, at.main_account, "
            "       at.account_level, at.account_type, at.final_account, "
            "       (SELECT account_name_ar FROM accounting_tree p "
            "          WHERE p.branches = at.branches "
            "            AND p.account_periods = at.account_periods "
            "            AND p.account_no = at.main_account LIMIT 1) AS parent_name, "
            "       (SELECT COUNT(*) FROM accounting_tree c "
            "          WHERE c.branches = at.branches "
            "            AND c.account_periods = at.account_periods "
            "            AND c.main_account = at.account_no) AS children_count "
            "FROM accounting_tree at "
            "WHERE at.branches = %s AND at.account_periods = %s "
            "ORDER BY at.account_no",
            placeholders=[branch_id, per_id],
            as_dict=True,
        )
        out = []
        for r in rows:
            cc = int(r["children_count"] or 0)
            name = r["account_name_ar"] or ""
            label = r["account_no"] + " — " + name
            if r.get("parent_name"):
                label += "  ‹ " + r["parent_name"]
            out.append({
                "id": int(r["id"]),
                "account_no": r["account_no"],
                "name": name,
                "parent_name": r.get("parent_name") or "",
                "main_account": r.get("main_account") or "0",
                "account_level": int(r["account_level"] or 0),
                "account_type": int(r["account_type"] or 0),
                "final_account": int(r["final_account"] or 0),
                "children_count": cc,
                "is_parent": cc > 0,
                "label": label,
            })
        return response.json({"err": 0, "accounts": out, "period_id": per_id})
    except Exception as e:
        return response.json({"err": 3, "mess": str(e)})
