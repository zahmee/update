// ======================  كشف حساب مخصص (متعدّد) — منطق Vue 3  ======================
// عقد API الجديد: POST /reports_account_api/acount_balanc_2 يقبل account_ids كقائمة
// ويُرجع {branch, period, entries: [..account-statements..], totals, opening_total, ending_total}

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_account_api/',
            settingApi: window.purl + '/../../setting_api/',
            opsApi: window.purl + '/../../operations_api/',
            printJournalURL: window.printJournalURL,

            branches: [],
            periods: [],
            accounts: [],
            selectedAccounts: [],   // مصفوفة (multi-select)
            reportTitle: '',
            sumSort: { key: 'account_no', dir: 1 },  // ترتيب جدول ملخّص الحساب الرئيسي

            filters: {
                branch: 0,
                period: 0,
                date_from: '',
                date_to: '',
            },

            data: null,
            loading: false,
            _loadSeq: 0,
            _accountsT: null,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        canQuery() {
            return this.filters.branch > 0
                && this.filters.period > 0
                && this.selectedAccounts.length > 0;
        },
    },

    watch: {
        // عند تغيير قائمة الحسابات (إضافة/إزالة) → reload (مع debounce لتجنب الـ N requests)
        selectedAccounts: {
            handler(newVal) {
                var self = this;
                if (this._accountsT) clearTimeout(this._accountsT);
                this._accountsT = setTimeout(() => {
                    if (newVal && newVal.length > 0 && self.filters.branch > 0 && self.filters.period > 0) {
                        self.reload();
                    } else {
                        self.data = null;
                    }
                }, 250);
            },
            deep: true,
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.filters.branch = main.id;
                else if (self.branches.length === 1) self.filters.branch = self.branches[0].id;
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                if (self.filters.branch > 0 && self.filters.period > 0) {
                    self.loadAccounts();
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        loadAccounts() {
            if (!(this.filters.branch > 0 && this.filters.period > 0)) {
                this.accounts = [];
                return;
            }
            var self = this;
            // كل الحسابات (رئيسية وفرعية) — بصلاحية can_view، تشمل الآباء
            axios.get(this.api + 'accounts_for_report/'
                      + this.filters.branch + '/' + this.filters.period).then(r => {
                var d = r.data || {};
                self.accounts = (!d.err && d.accounts) ? d.accounts : [];
            }).catch(() => { self.accounts = []; });
        },

        onBranchChange() {
            this.selectedAccounts = [];
            this.data = null;
            this.loadAccounts();
        },

        onPeriodChange() {
            if (this.filters.period > 0) {
                var p = this.periods.find(p => Number(p.id) === Number(this.filters.period));
                if (p) {
                    if (p.start_date) this.filters.date_from = p.start_date;
                    if (p.end_date) this.filters.date_to = p.end_date;
                }
            }
            this.selectedAccounts = [];
            this.data = null;
            this.loadAccounts();
        },

        onFilterChange() {
            if (this.canQuery) this.reload();
        },

        clearAccounts() {
            this.selectedAccounts = [];
            this.data = null;
        },

        reload() {
            if (!this.canQuery) return;
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            var payload = {
                branch: this.filters.branch,
                period: this.filters.period,
                date_from: this.filters.date_from,
                date_to: this.filters.date_to,
                account_ids: this.selectedAccounts.map(a => a.id).join(','),
            };
            axios.post(this.api + 'acount_balanc_2/', payload).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess });
                    self.data = null;
                } else {
                    self.data = d;
                }
            }).catch(() => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                self.data = null;
            }).then(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        resetToFullPeriod() {
            if (!this.data) return;
            this.filters.date_from = this.data.period.start_date || '';
            this.filters.date_to = this.data.period.end_date || '';
            this.reload();
        },

        printReport() {
            this.now_str = new Date().toLocaleString('en-GB');
            this.$nextTick(() => window.print());
        },

        exportCSV() {
            if (!this.data) return;
            var rows = [
                ['الحساب', 'رقم القيد', 'التاريخ', 'البيان', 'مدين', 'دائن', 'الرصيد'],
            ];
            this.data.entries.forEach(e => {
                if (e.is_summary) {
                    // حساب رئيسي → صف إجماليات لكل حساب فرعي (بلا حركة)
                    rows.push(['== ' + e.account.account_no + ' — ' + e.account.account_name
                               + ' (حساب رئيسي — إجماليات فروعه) ==', '', '', '', '', '', '']);
                    (e.children || []).forEach(ch => {
                        rows.push([ch.account.account_no, '', '', ch.account.account_name,
                                   ch.totals.debit, ch.totals.credit, ch.ending.net]);
                    });
                    rows.push([e.account.account_no, '', '', 'إجمالي الحساب الرئيسي',
                               e.totals.debit, e.totals.credit, e.ending.net]);
                } else {
                    // حساب فرعي (ورقي) → كشف حركة مفصّل
                    rows.push(['== ' + e.account.account_no + ' — ' + e.account.account_name + ' ==',
                               '', '', '', '', '', '']);
                    rows.push([e.account.account_no, '', this.filters.date_from, 'رصيد افتتاحي',
                               e.opening.debit, e.opening.credit, e.opening.net]);
                    e.movements.forEach(r => {
                        rows.push([e.account.account_no, r.journal_id, r.journal_date,
                                   (r.master_detail || '') + (r.detail ? ' — ' + r.detail : ''),
                                   r.debit, r.credit, r.running_balance]);
                    });
                    rows.push([e.account.account_no, '', this.filters.date_to, 'الرصيد الختامي',
                               e.ending.debit, e.ending.credit, e.ending.net]);
                }
                rows.push(['', '', '', '', '', '', '']);  // فاصل
            });
            // إجمالي عام
            rows.push(['الإجمالي العام', '', '', '',
                       this.data.totals.debit, this.data.totals.credit,
                       this.data.totals.net_movement]);
            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'accounts_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        faLabel(v) {
            v = Number(v);
            return v === 1 ? 'ميزانية' : v === 2 ? 'أرباح وخسائر' : v === 3 ? 'متاجرة' : '';
        },

        // ---- ترتيب جدول ملخّص الحساب الرئيسي بالنقر على رأس العمود ----
        sumSortVal(ch, key) {
            switch (key) {
                case 'account_no': return ch.account.account_no || '';
                case 'account_name': return ch.account.account_name || '';
                case 'open_debit': return ch.opening.debit;
                case 'open_credit': return ch.opening.credit;
                case 'mov_debit': return ch.totals.debit;
                case 'mov_credit': return ch.totals.credit;
                case 'end_debit': return ch.ending.debit;
                case 'end_credit': return ch.ending.credit;
                default: return '';
            }
        },
        sortBy(key) {
            if (this.sumSort.key === key) this.sumSort.dir *= -1;
            else { this.sumSort.key = key; this.sumSort.dir = 1; }
        },
        sumSortIcon(key) {
            if (this.sumSort.key !== key) return 'fa-sort';
            return this.sumSort.dir > 0 ? 'fa-sort-up' : 'fa-sort-down';
        },
        sortedChildren(e) {
            var arr = (e.children || []).slice();
            var key = this.sumSort.key, dir = this.sumSort.dir, self = this;
            arr.sort(function (a, b) {
                var va = self.sumSortVal(a, key), vb = self.sumSortVal(b, key);
                if (typeof va === 'string' || typeof vb === 'string') {
                    return dir * String(va).localeCompare(String(vb), 'ar', { numeric: true });
                }
                return dir * ((va || 0) - (vb || 0));
            });
            return arr;
        },

        fmt(n) { return fmtNumber(n); },
        fmtCell(n) {
            var v = Number(n) || 0;
            return v === 0 ? '—' : fmtNumber(v);
        },

        withPopper(dropdownList, component, { width }) {
            var toggle = component.$refs.toggle;
            if (!toggle) return function () {};
            var update = function () {
                var rect = toggle.getBoundingClientRect();
                var minWidth = Math.max(parseFloat(width) || 0, 380);
                dropdownList.style.position = 'absolute';
                dropdownList.style.top = (rect.bottom + window.scrollY + 2) + 'px';
                dropdownList.style.left = (rect.left + window.scrollX) + 'px';
                dropdownList.style.width = minWidth + 'px';
                dropdownList.style.maxHeight = '320px';
                dropdownList.style.overflowY = 'auto';
                dropdownList.style.zIndex = 9999;
                dropdownList.style.background = '#fff';
                dropdownList.style.border = '1px solid var(--line-2, #d6d6d6)';
                dropdownList.style.borderRadius = '8px';
                dropdownList.style.boxShadow = '0 8px 24px rgba(0,0,0,0.12)';
            };
            update();
            window.addEventListener('scroll', update, true);
            window.addEventListener('resize', update);
            return function () {
                window.removeEventListener('scroll', update, true);
                window.removeEventListener('resize', update);
            };
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
