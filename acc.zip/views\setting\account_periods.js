// ======================  شاشة الفترات المحاسبية - منطق Vue 3  ======================

// سجل دورة فارغ
function blankRow() {
    return {
        id: -1, disc: '', start_date: '', end_date: '',
        open_period: 1, show_row: 1,
        period_type: 'year', notes: '',
        closed_on: null, closed_by_name: '',
        exported: false,
    };
}

// توحيد أنواع البيانات القادمة من الخادم
function normalize(c) {
    var r = blankRow();
    r.disc = (c.disc == null) ? '' : String(c.disc);
    r.start_date = (c.start_date == null) ? '' : String(c.start_date).slice(0, 10);
    r.end_date = (c.end_date == null) ? '' : String(c.end_date).slice(0, 10);
    r.id = Number(c.id);
    r.open_period = (Number(c.open_period) === 1) ? 1 : 2;
    r.show_row = (Number(c.show_row) === 2) ? 2 : 1;
    r.period_type = c.period_type || 'year';
    r.notes = (c.notes == null) ? '' : String(c.notes);
    r.closed_on = c.closed_on || null;
    r.closed_by_name = c.closed_by_name || '';
    r.exported = !!c['export'];
    return r;
}

// تاريخ اليوم بصيغة ISO المحلية
function todayISO() {
    var d = new Date();
    return d.getFullYear() + '-' +
        String(d.getMonth() + 1).padStart(2, '0') + '-' +
        String(d.getDate()).padStart(2, '0');
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../setting_api/',
            data: [],
            loading: true,
            saving: false,
            search: '',
            filter: 'all',          // 'all' | 'current' | 'open' | 'closed'
            today: todayISO(),
            modal_open: false,
            select_row: blankRow(),
            stats: null,
            isAdmin: !!window.isAdmin,
        };
    },

    computed: {
        is_edit() { return Number(this.select_row.id) > 0; },

        openCount() {
            return this.data.filter(function (c) { return Number(c.open_period) === 1; }).length;
        },
        closedCount() {
            return this.data.filter(function (c) { return Number(c.open_period) !== 1; }).length;
        },
        currentCount() {
            var t = this.today;
            return this.data.filter(function (c) {
                return c.start_date && c.end_date && c.start_date <= t && t <= c.end_date;
            }).length;
        },
        periodStats() {
            return this.data.reduce(function (acc, c) {
                acc.total += 1;
                if (Number(c.open_period) === 1) acc.open += 1;
                else acc.closed += 1;
                if (c.exported) acc.exported += 1;
                if (Number(c.show_row) === 1) acc.visible += 1;
                else acc.hidden += 1;
                return acc;
            }, { total: 0, open: 0, closed: 0, exported: 0, visible: 0, hidden: 0 });
        },
        currentPeriod() {
            var t = this.today;
            return this.data
                .filter(function (c) {
                    return c.start_date && c.end_date && c.start_date <= t && t <= c.end_date;
                })
                .sort(function (a, b) { return (b.start_date || '').localeCompare(a.start_date || ''); })[0] || null;
        },
        filterLabel() {
            return {
                all: 'كل الدورات',
                current: 'الدورة الجارية',
                open: 'الدورات المفتوحة',
                closed: 'الدورات المقفلة',
            }[this.filter] || 'كل الدورات';
        },

        filteredData() {
            var q = this.search.trim().toLowerCase();
            var f = this.filter;
            var t = this.today;
            return this.data
                .filter(function (c) {
                    // فلتر الحالة
                    if (f === 'open' && Number(c.open_period) !== 1) return false;
                    if (f === 'closed' && Number(c.open_period) === 1) return false;
                    if (f === 'current') {
                        if (!(c.start_date && c.end_date && c.start_date <= t && t <= c.end_date)) return false;
                    }
                    // فلتر البحث
                    if (q && ![c.disc, c.start_date, c.end_date]
                        .some(function (v) { return (v || '').toLowerCase().indexOf(q) !== -1; })) return false;
                    return true;
                })
                // ترتيب: الأحدث أولاً حسب تاريخ البداية
                .slice()
                .sort(function (a, b) { return (b.start_date || '').localeCompare(a.start_date || ''); });
        },

        missing() {
            var m = [];
            var r = this.select_row;
            if (!(r.disc || '').trim()) m.push('وصف الدورة');
            else if ((r.disc || '').trim().length < 3) m.push('وصف من 3 أحرف على الأقل');
            if (!r.start_date) m.push('تاريخ البداية');
            if (!r.end_date) m.push('تاريخ النهاية');
            if (r.start_date && r.end_date && r.start_date > r.end_date) m.push('ترتيب التواريخ');
            return m;
        },
        is_valid() { return this.missing.length === 0; },
    },

    watch: {
        modal_open(open) {
            document.body.style.overflow = open ? 'hidden' : '';
        },
    },

    created() { this.load(); },

    mounted() { window.addEventListener('keydown', this.on_key); },

    unmounted() {
        window.removeEventListener('keydown', this.on_key);
        document.body.style.overflow = '';
    },

    methods: {
        // هل الدورة هي الجارية (يقع فيها تاريخ اليوم)؟
        is_current(c) {
            return !!(c.start_date && c.end_date
                && c.start_date <= this.today && this.today <= c.end_date);
        },

        // استخراج السنة من تاريخ البداية للعرض على المربع
        year_of(c) {
            var s = c.start_date || c.end_date || '';
            return s ? String(s).slice(0, 4) : 'غير محدد';
        },

        // عدد أيام الدورة (شاملة الطرفين)
        days_of(c) {
            if (!c.start_date || !c.end_date) return 0;
            var s = new Date(c.start_date), e = new Date(c.end_date);
            if (isNaN(s) || isNaN(e)) return 0;
            return Math.max(0, Math.round((e - s) / 86400000) + 1);
        },

        // تحميل الدورات
        load() {
            var self = this;
            return axios.get(this.api + 'get_all_account_periodsA').then(function (res) {
                self.data = Array.isArray(res.data) ? res.data.map(normalize) : [];
                self.loading = false;
            }).catch(function () {
                self.loading = false;
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات', text: 'تأكد من الاتصال ثم أعد المحاولة.' });
            });
        },

        open_new() {
            var r = blankRow();
            // ذكاء افتراضي: ابتداءً من اليوم التالي لآخر دورة، وانتهاءً بعد سنة بيوم
            if (this.data.length) {
                var last = this.data.slice().sort(function (a, b) {
                    return (b.end_date || '').localeCompare(a.end_date || '');
                })[0];
                if (last && last.end_date) {
                    var s = new Date(last.end_date); s.setDate(s.getDate() + 1);
                    var e = new Date(s); e.setFullYear(e.getFullYear() + 1); e.setDate(e.getDate() - 1);
                    var iso = function (d) {
                        return d.getFullYear() + '-' +
                            String(d.getMonth() + 1).padStart(2, '0') + '-' +
                            String(d.getDate()).padStart(2, '0');
                    };
                    r.start_date = iso(s);
                    r.end_date = iso(e);
                    r.period_type = last.period_type || 'year';
                    r.disc = 'الدورة المالية ' + r.start_date.slice(0, 4);
                }
            }
            this.select_row = r;
            this.stats = null;
            this.modal_open = true;
            this.focus_first();
        },

        open_edit(c) {
            this.select_row = normalize(c);
            this.stats = null;
            this.modal_open = true;
            this.focus_first();
            this.load_stats(c.id);
        },

        close_modal() {
            if (this.saving) return;
            this.modal_open = false;
            this.stats = null;
        },

        clear_filters() {
            this.search = '';
            this.filter = 'all';
        },

        periodTypeLabel(v) {
            return {
                year: 'سنوية',
                half: 'نصف سنوية',
                quarter: 'ربع سنوية',
                month: 'شهرية',
                custom: 'مخصصة',
            }[v || 'year'] || 'سنوية';
        },

        statusLabel(c) {
            if (Number(c.open_period) === 1) return 'مفتوحة';
            if (c.exported) return 'مرحلة';
            return 'مقفلة';
        },

        // تحميل إحصائيات الدورة
        load_stats(pid) {
            var self = this;
            axios.get(this.api + 'period_stats', { params: { id: pid } }).then(function (res) {
                var d = res.data || {};
                if (d.err === 0) self.stats = d;
            }).catch(function () { /* صامت */ });
        },

        // تنسيق المبلغ
        fmt_money(n) {
            var v = Number(n) || 0;
            return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        },

        // تنسيق التاريخ
        fmt_date(s) {
            if (!s) return '';
            return String(s).slice(0, 10);
        },

        focus_first() {
            var self = this;
            this.$nextTick(function () {
                if (self.$refs.firstInput) self.$refs.firstInput.focus();
            });
        },

        on_key(e) {
            if (e.key === 'Escape' && this.modal_open) this.close_modal();
        },

        payload() {
            var r = this.select_row;
            return {
                id: r.id,
                disc: (r.disc || '').trim(),
                start_date: r.start_date,
                end_date: r.end_date,
                open_period: (Number(r.open_period) === 1) ? 1 : 2,
                show_row: (Number(r.show_row) === 2) ? 2 : 1,
                period_type: r.period_type || 'year',
                notes: (r.notes || '').trim(),
            };
        },

        add_row() {
            if (!this.is_valid || this.saving) return;
            this._send_add(this.payload());
        },

        _send_add(payload) {
            var self = this;
            this.saving = true;
            axios.post(this.api + 'add_account_periods/', payload).then(function (res) {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تمت الإضافة', text: 'تمت إضافة الدورة بنجاح.', timer: 1700, showConfirmButton: false });
                    self.load();
                    return;
                }
                // err=4: تأكيد إقفال الدورات المفتوحة السابقة
                if (d.err === 4 && Array.isArray(d.will_close) && d.will_close.length) {
                    var names = d.will_close.map(function (p) { return '<li>' + p.disc + '</li>'; }).join('');
                    Swal.fire({
                        icon: 'warning',
                        title: 'إقفال دورات سابقة',
                        html: '<div style="text-align:start; font-size:.9rem;">' +
                              'فتح هذه الدورة سيقفل تلقائياً الدورة(ات) المفتوحة حالياً:' +
                              '<ul style="margin:.5rem 0; padding-inline-start:1.2rem;">' + names + '</ul>' +
                              'هل تريد المتابعة؟</div>',
                        showCancelButton: true,
                        confirmButtonText: 'نعم، أقفل وافتح الجديدة',
                        cancelButtonText: 'إلغاء',
                        confirmButtonColor: '#d33',
                    }).then(function (r) {
                        if (r.isConfirmed) {
                            var p2 = Object.assign({}, payload, { confirm_close_others: 1 });
                            self._send_add(p2);
                        }
                    });
                    return;
                }
                Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ غير متوقع.' });
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: 'تعذّر الاتصال بالخادم.' });
            }).then(function () { self.saving = false; });
        },

        update_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'update_account_periods/', this.payload()).then(function (res) {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تم الحفظ', text: 'تم حفظ التعديلات بنجاح.', timer: 1700, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ غير متوقع.' });
                }
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: 'تعذّر الاتصال بالخادم.' });
            }).then(function () { self.saving = false; });
        },

        delete_row() {
            if (this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'حذف الدورة',
                html: 'سيتم حذف الدورة <b>' + (this.select_row.disc || '') + '</b> نهائياً. هل أنت متأكد؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'delete_account_periods/', { id: self.select_row.id }).then(function (res) {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.modal_open = false;
                        Swal.fire({ icon: 'success', title: 'تم الحذف', text: 'تم حذف الدورة بنجاح.', timer: 1700, showConfirmButton: false });
                        self.load();
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الحذف', text: d.mess || 'حدث خطأ غير متوقع.' });
                    }
                }).catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحذف', text: 'تعذّر الاتصال بالخادم.' });
                }).then(function () { self.saving = false; });
            });
        },

        // مزامنة حقول الحالة في select_row من البيانات المُحدَّثة بعد عملية إقفال/فتح/ترحيل
        syncClosureFields() {
            var id = this.select_row.id;
            var found = this.data.find(function (x) { return x.id === id; });
            if (found) {
                this.select_row.open_period = found.open_period;
                this.select_row.closed_on = found.closed_on || null;
                this.select_row.closed_by_name = found.closed_by_name || '';
                this.select_row.exported = found.exported;
            }
        },

        // معاينة الترحيل قبل التنفيذ
        carry_forward() {
            if (this.saving) return;
            var self = this;
            this.saving = true;
            axios.get(this.api + 'preview_carry_forward', { params: { id: this.select_row.id } })
                .then(function (res) {
                    var d = res.data || {};
                    if (d.err !== 0) {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الترحيل', text: d.mess || 'حدث خطأ' });
                        return;
                    }
                    if (!d.count) {
                        Swal.fire({ icon: 'info', title: 'لا أرصدة قابلة للترحيل', text: 'حسابات الميزانية للدورة الحالية بدون أرصدة فعلية.' });
                        return;
                    }
                    self._show_carry_preview(d);
                })
                .catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                })
                .then(function () { self.saving = false; });
        },

        // عرض معاينة الترحيل في حوار SweetAlert
        _show_carry_preview(d) {
            var self = this;
            var fm = function (n) { return self.fmt_money(n); };
            var rowsHtml = d.preview.map(function (p) {
                return '<tr>' +
                    '<td>' + (p.account_no || 'غير محدد') + '</td>' +
                    '<td>' + (p.account_name || 'غير محدد') + '</td>' +
                    '<td>' + (p.branch_name || 'غير محدد') + '</td>' +
                    '<td dir="ltr">' + fm(p.debit) + '</td>' +
                    '<td dir="ltr">' + fm(p.credit) + '</td>' +
                    '</tr>';
            }).join('');
            var html =
                '<div class="cf-preview">' +
                '<div class="cf-meta">إلى الدورة: <b>' + d.next_period_name + '</b> &nbsp;|&nbsp; ' +
                '<b>' + d.count + '</b> رصيد · حسابات الميزانية فقط</div>' +
                '<div class="cf-tablewrap"><table class="cf-table"><thead><tr>' +
                '<th>رقم الحساب</th><th>اسم الحساب</th><th>الفرع</th><th>مدين</th><th>دائن</th>' +
                '</tr></thead><tbody>' + rowsHtml +
                '<tr class="cf-total"><td colspan="3">الإجمالي</td>' +
                '<td dir="ltr">' + fm(d.total_debit) + '</td>' +
                '<td dir="ltr">' + fm(d.total_credit) + '</td></tr>' +
                '</tbody></table></div>' +
                (d.balanced
                    ? '<div class="cf-note ok"><i class="fas fa-check-circle"></i> الأرصدة متوازنة وجاهزة للترحيل.</div>'
                    : '<div class="cf-note warn"><i class="fas fa-exclamation-triangle"></i> فرق غير متوازن، راجع القيود قبل الترحيل.</div>') +
                '</div>';
            Swal.fire({
                title: 'معاينة ترحيل الأرصدة',
                html: html,
                width: 820,
                showCancelButton: true,
                confirmButtonText: 'نفّذ الترحيل',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#0d6efd',
            }).then(function (result) {
                if (result.isConfirmed) self._do_execute_carry();
            });
        },

        _do_execute_carry() {
            var self = this;
            this.saving = true;
            axios.post(this.api + 'execute_carry_forward/', { id: this.select_row.id })
                .then(function (res) {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        Swal.fire({
                            icon: 'success', title: 'تم الترحيل',
                            text: 'تم ترحيل ' + d.count + ' رصيد إلى دورة «' + d.next_period_name + '».',
                            timer: 2200, showConfirmButton: false,
                        });
                        self.load().then(function () { self.syncClosureFields(); });
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الترحيل', text: d.mess || 'حدث خطأ' });
                    }
                })
                .catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                })
                .then(function () { self.saving = false; });
        },

        // إلغاء الترحيل (يتطلب صلاحية مدير + عدم وجود قيود في الدورة التالية)
        revert_carry() {
            if (this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'إلغاء الترحيل',
                html: 'سيتم حذف الأرصدة الافتتاحية المُرحَّلة من الدورة التالية. ' +
                    'هذا ممكن فقط إذا لم تكن الدورة التالية تحتوي على قيود.',
                showCancelButton: true,
                confirmButtonText: 'نعم، ألغِ الترحيل',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'revert_carry_forward/', { id: self.select_row.id })
                    .then(function (res) {
                        var d = res.data || {};
                        if (d.mess === '0') {
                            Swal.fire({
                                icon: 'success', title: 'تم الإلغاء',
                                text: 'حُذفت ' + d.deleted + ' أرصدة افتتاحية مُرحَّلة.',
                                timer: 2000, showConfirmButton: false,
                            });
                            self.load().then(function () { self.syncClosureFields(); });
                        } else {
                            Swal.fire({ icon: 'warning', title: 'تعذّر الإلغاء', text: d.mess || 'حدث خطأ' });
                        }
                    })
                    .catch(function () {
                        Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                    })
                    .then(function () { self.saving = false; });
            });
        },

        close_period() {
            if (this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'إقفال الدورة المالية',
                html: 'بعد الإقفال <b>لن يمكن</b> إضافة أو تعديل أو حذف قيود في هذه الدورة. هل تريد المتابعة؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، أقفل',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'close_period/', { id: self.select_row.id }).then(function (res) {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.select_row.open_period = 2;
                        Swal.fire({ icon: 'success', title: 'تم الإقفال', text: 'تم إقفال الدورة المالية.', timer: 1700, showConfirmButton: false });
                        self.load().then(function () { self.syncClosureFields(); });
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الإقفال', text: d.mess || 'حدث خطأ غير متوقع.' });
                    }
                }).catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر الإقفال', text: 'تعذّر الاتصال بالخادم.' });
                }).then(function () { self.saving = false; });
            });
        },

        reopen_period() {
            if (this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'إعادة فتح الدورة',
                html: 'سيُسمح مجدداً بإضافة وتعديل القيود في هذه الدورة. هل تريد المتابعة؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، أعد الفتح',
                cancelButtonText: 'إلغاء',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'reopen_period/', { id: self.select_row.id }).then(function (res) {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.select_row.open_period = 1;
                        self.select_row.closed_on = null;
                        self.select_row.closed_by_name = '';
                        Swal.fire({ icon: 'success', title: 'تم إعادة الفتح', text: 'الدورة أصبحت مفتوحة للتعديل.', timer: 1700, showConfirmButton: false });
                        self.load().then(function () { self.syncClosureFields(); });
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر إعادة الفتح', text: d.mess || 'حدث خطأ غير متوقع.' });
                    }
                }).catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر إعادة الفتح', text: 'تعذّر الاتصال بالخادم.' });
                }).then(function () { self.saving = false; });
            });
        },

        print_list() { window.print(); },
    },
});

var app = vueApp.mount('#app');
