# -*- coding: utf-8 -*-
"""
acc_balance — منطق الكشف المحاسبي (المنطق الأساسي للأرصدة + الحركات).

الدالة الأهم: `build_account_statement(db, branch_id, period_id, account_id,
date_from, date_to)` — تبني كشف حساب كامل لحساب واحد عبر فترة، يستخدمه:
- acount_balanc (كشف حساب فرد)
- acount_balanc_2 (كشف موحَّد لعدة حسابات — تكرار)
- acount_balanc_3 (ملخّص إجماليات — تكرار)

المنطق المُتبَع:
1. التحقّق من وجود الحساب + انتمائه للفرع
2. جلب اسم الأب وعدد الأبناء (لتحديد إن كان حساباً مجمَّعاً)
3. حساب الرصيد الافتتاحي = افتتاحي الدورة + كل الحركة قبل date_from
4. جلب حركة المدى (date_from..date_to) مع enrich (parent names + cost centers)
5. حساب الرصيد المتحرّك لكل سطر (running_balance)
6. إرجاع dict نظيف جاهز للـ JSON

ميزة LIKE pattern: الحسابات الرئيسية ترى مجموع كل فروعها تلقائياً
(account_no = "11" يجلب كل ما يبدأ بـ "11" — "1110101"، "1110102"، إلخ).

الدالة dependency-injected: تأخذ `db` صراحةً → قابلة للاختبار.
"""


def build_account_statement(db, branch_id, period_id, account_id, date_from, date_to):
    """يبني كشف حساب كامل. يُرجع dict أو None إن لم يوجد الحساب/لم ينتمِ للفرع.

    Parameters
    ----------
    db          : PyDAL DAL instance
    branch_id   : int — id الفرع
    period_id   : int — id الدورة
    account_id  : int — id في accounting_tree
    date_from   : date | str — بداية المدى
    date_to     : date | str — نهاية المدى

    Returns
    -------
    dict {account, opening, movements, totals, ending} أو None
    """
    acc = db.accounting_tree[account_id]
    if not acc:
        return None
    if int(acc.branches) != int(branch_id):
        return None

    account_no = acc.account_no
    like_pat = account_no + "%"

    # ----- اسم الأب (للعرض في الـ context) -----
    parent_name = ""
    if acc.main_account and acc.main_account != "0":
        pr = db(
            (db.accounting_tree.account_no == acc.main_account)
            & (db.accounting_tree.branches == branch_id)
            & (db.accounting_tree.account_periods == period_id)
        ).select().first()
        if pr:
            parent_name = pr.account_name_ar or ""

    # ----- عدد الأبناء (لتحديد is_parent / is_rolled) -----
    children_count = db(
        (db.accounting_tree.main_account == account_no)
        & (db.accounting_tree.branches == branch_id)
        & (db.accounting_tree.account_periods == period_id)
    ).count()

    # ============== الافتتاحي ==============
    # افتتاحي الدورة من account_periods_opening
    opening_rows = db.executesql(
        "SELECT COALESCE(SUM(debit),0)::float, COALESCE(SUM(credit),0)::float "
        "FROM account_periods_opening "
        "WHERE branches = %s AND account_periods = %s AND account_no LIKE %s",
        placeholders=[branch_id, period_id, like_pat],
    )
    od_raw = float(opening_rows[0][0] or 0) if opening_rows else 0.0
    oc_raw = float(opening_rows[0][1] or 0) if opening_rows else 0.0

    # حركة ما قبل date_from — تُضاف للافتتاحي ليصبح "افتتاحي عند date_from"
    pre_rows = db.executesql(
        "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
        "FROM journal_entry_detail jed "
        "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
        "WHERE jem.is_active = 'T' "
        "  AND jed.branches = %s AND jed.account_periods = %s "
        "  AND jed.account_no LIKE %s AND jed.journal_date < %s",
        placeholders=[branch_id, period_id, like_pat, str(date_from)],
    )
    pd_ = float(pre_rows[0][0] or 0) if pre_rows else 0.0
    pc = float(pre_rows[0][1] or 0) if pre_rows else 0.0

    total_pre_debit = od_raw + pd_
    total_pre_credit = oc_raw + pc
    opening_net = round(total_pre_debit - total_pre_credit, 2)

    # ============== حركة الفترة ==============
    movements_raw = db.executesql(
        "SELECT jed.id, jed.journal_entry_master, jed.journal_date, "
        "       jed.account_no, jed.debit::float, jed.credit::float, "
        "       jed.detail, jed.cost_center, "
        "       jem.journal_detail AS master_detail, "
        "       jem.journal_save AS master_save, "
        "       at.account_name_ar, at.main_account "
        "FROM journal_entry_detail jed "
        "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
        "LEFT JOIN accounting_tree at ON at.id = jed.accounting_tree "
        "WHERE jem.is_active = 'T' "
        "  AND jed.branches = %s AND jed.account_periods = %s "
        "  AND jed.account_no LIKE %s "
        "  AND jed.journal_date >= %s AND jed.journal_date <= %s "
        "ORDER BY jed.journal_date, jed.journal_entry_master, jed.id",
        placeholders=[branch_id, period_id, like_pat, str(date_from), str(date_to)],
        as_dict=True,
    )

    # ----- enrich: أسماء الآباء + مراكز التكلفة -----
    all_main_nos = list({r["main_account"] for r in movements_raw
                        if r.get("main_account") and r["main_account"] != "0"})
    parent_map = {}
    if all_main_nos:
        for p in db(
            (db.accounting_tree.account_no.belongs(all_main_nos))
            & (db.accounting_tree.branches == branch_id)
            & (db.accounting_tree.account_periods == period_id)
        ).select(db.accounting_tree.account_no, db.accounting_tree.account_name_ar):
            parent_map[p.account_no] = p.account_name_ar or ""

    cc_ids = list({int(r["cost_center"]) for r in movements_raw if r.get("cost_center")})
    cc_map = {}
    if cc_ids:
        for c in db(db.key_cost_center.id.belongs(cc_ids)).select(
            db.key_cost_center.id, db.key_cost_center.name
        ):
            cc_map[int(c.id)] = c.name

    # ----- البناء + Running balance -----
    running = opening_net
    total_debit = 0.0
    total_credit = 0.0
    movements = []
    for r in movements_raw:
        d = float(r["debit"] or 0)
        c = float(r["credit"] or 0)
        running = round(running + d - c, 2)
        total_debit += d
        total_credit += c
        par = parent_map.get(r["main_account"], "") if r.get("main_account") else ""
        full = r["account_name_ar"] or ""
        if par:
            full = par + " > " + full
        movements.append({
            "id": int(r["id"]),
            "journal_id": int(r["journal_entry_master"]),
            "journal_date": str(r["journal_date"]) if r["journal_date"] else None,
            "account_no": r["account_no"],
            "account_name": full,
            "detail": r["detail"] or "",
            "master_detail": r["master_detail"] or "",
            "master_save": r["master_save"] or "",
            "debit": round(d, 2),
            "credit": round(c, 2),
            "cost_center_name": cc_map.get(int(r["cost_center"])) if r.get("cost_center") else "",
            "running_balance": running,
        })

    total_debit = round(total_debit, 2)
    total_credit = round(total_credit, 2)
    final_net = round(opening_net + total_debit - total_credit, 2)

    return {
        "account": {
            "id": int(acc.id),
            "account_no": acc.account_no,
            "account_name": acc.account_name_ar or "",
            "parent_name": parent_name,
            "main_account": acc.main_account or "0",
            "account_type": int(acc.account_type or 0),
            "final_account": int(acc.final_account or 0),
            "children_count": int(children_count or 0),
            "is_rolled": int(children_count or 0) > 0,
        },
        "opening": {
            "debit": round(opening_net, 2) if opening_net >= 0 else 0.0,
            "credit": round(-opening_net, 2) if opening_net < 0 else 0.0,
            "net": round(opening_net, 2),
        },
        "movements": movements,
        "totals": {
            "debit": total_debit,
            "credit": total_credit,
            "net_movement": round(total_debit - total_credit, 2),
            "count": len(movements),
        },
        "ending": {
            "debit": round(final_net, 2) if final_net >= 0 else 0.0,
            "credit": round(-final_net, 2) if final_net < 0 else 0.0,
            "net": final_net,
        },
    }


def compute_running_balance(opening_net, movements):
    """يحسب رصيد متحرّك لقائمة سطور بسيطة (debit/credit). مفيد للاختبار وللحالات
    التي لا تحتاج كل enrichment الـbuild_account_statement.

    movements: list of dicts بـ "debit"/"credit"
    Returns: list مع "running_balance" مضاف لكل سطر.
    """
    running = round(float(opening_net or 0), 2)
    out = []
    for m in (movements or []):
        d = float(m.get("debit") or 0)
        c = float(m.get("credit") or 0)
        running = round(running + d - c, 2)
        item = dict(m)
        item["running_balance"] = running
        out.append(item)
    return out


def is_health_ok(statement, tolerance=0.005):
    """تحقّق صحّي: آخر رصيد متحرّك يجب أن يساوي صافي الختامي."""
    if not statement:
        return False
    movements = statement.get("movements") or []
    ending_net = statement.get("ending", {}).get("net", 0.0)
    if not movements:
        # لا حركات → الختامي يجب أن يساوي الافتتاحي
        opening_net = statement.get("opening", {}).get("net", 0.0)
        return abs(ending_net - opening_net) < tolerance
    return abs(movements[-1]["running_balance"] - ending_net) < tolerance
