# -*- coding: utf-8 -*-
#  type: ignore


@auth.requires(can_view)
def index():
    """مكتب التقارير — يجمع كل التقارير المالية + رؤية تشخيصية حيّة."""
    response.title = "التقارير"
    # ===== رؤية تشخيصية للوحة الحالة =====
    # الدورة الافتراضية = أحدث دورة مفتوحة
    open_period = (
        db(db.account_periods.open_period == 1)
        .select(orderby=~db.account_periods.start_date)
        .first()
    )
    open_periods_count = db(db.account_periods.open_period == 1).count()
    branches_count = db(db.branches.show_row == 1).count()
    # عدد القيود النشطة
    journals_count = db(db.journal_entry_master.is_active == True).count()
    # آخر تاريخ قيد مسجَّل
    last_journal = (
        db(db.journal_entry_master.is_active == True)
        .select(orderby=~db.journal_entry_master.journal_date,
                limitby=(0, 1))
        .first()
    )
    last_date = str(last_journal.journal_date) if last_journal else None
    # عدد القيود غير المتوازنة (التشخيص الرئيسي)
    # تحذير: تأخذ كل القيود النشطة حتى لو في دورة مقفلة
    unbal_rows = db.executesql(
        "SELECT COUNT(*) FROM ( "
        "  SELECT jed.journal_entry_master "
        "  FROM journal_entry_detail jed "
        "  JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
        "  WHERE jem.is_active = 'T' "
        "  GROUP BY jed.journal_entry_master "
        "  HAVING ROUND(CAST(COALESCE(SUM(jed.debit),0) AS numeric), 2) "
        "      <> ROUND(CAST(COALESCE(SUM(jed.credit),0) AS numeric), 2) "
        ") t"
    )
    unbalanced_count = int(unbal_rows[0][0] or 0) if unbal_rows else 0
    return dict(
        open_period=open_period,
        open_periods_count=int(open_periods_count or 0),
        branches_count=int(branches_count or 0),
        journals_count=int(journals_count or 0),
        last_journal_date=last_date,
        unbalanced_count=unbalanced_count,
        is_admin=auth.has_membership("admin"),
    )


@auth.requires(can_view)
def account_report():
    response.title = "كشف حساب"
    return dict()


@auth.requires(can_view)
def account_report_2():
    response.title = "كشف حساب مخصص"
    return dict()


@auth.requires(can_view)
def account_report_3():
    response.title = "إجماليات مخصص"
    return dict()


@auth.requires(can_view)
def account_report_3_1():
    response.title = "إجماليات بالفروع"
    return dict()


@auth.requires(can_view)
def trial_balance():
    response.title = "ميزان المراجعة"
    return dict()


@auth.requires(can_view)
def branches_account_report_1_1():
    response.title = "رصيد حساب بالفروع"
    return dict()


@auth.requires(can_view)
def Journal_report():
    response.title = "دفتر اليومية"
    return dict()


@auth.requires(can_view)
def income_statement():
    qry = db(db.account_periods.open_period == 1).select(db.account_periods.ALL).last()
    return dict(start=qry.start_date, end=qry.end_date)


@auth.requires(can_view)
def balance_sheet():
    qry = db(db.account_periods.open_period == 1).select(db.account_periods.ALL).last()
    return dict(start=qry.start_date, end=qry.end_date)


@auth.requires(can_view)
def account_report_4():
    response.title = "أخطاء القيود"
    return dict(is_admin=auth.has_membership("admin"))


@auth.requires(can_view)
def cost_centers_report():
    response.title = "تقرير مراكز التكلفة"
    return dict()


@auth.requires(can_view)
def cash_flow():
    response.title = "قائمة التدفقات النقدية"
    return dict()
