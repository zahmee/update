# -*- coding: utf-8 -*-
#  type: ignore

import datetime
import os
import pathlib
import secrets

import acc_password_reset
import acc_schema
import acc_sms


@auth.requires(can_view)
def index():
    return role_flags()


def health():
    """فحص صحة النظام — لا يحتاج تسجيل دخول.
    يُرجع JSON بحالة DB والجداول والمجلدات والمساحة.
    استخدام: /acc/default/health أو cron job يفحصه دورياً.

    رمز الحالة:
      200: healthy
      503: degraded (هناك أخطاء)
    """
    out = {"status": "ok", "checks": {}, "errors": []}

    # 1. الاتصال بقاعدة البيانات
    try:
        db.executesql("SELECT 1")
        out["checks"]["db"] = "ok"
    except Exception as e:
        out["status"] = "degraded"
        out["checks"]["db"] = "fail"
        out["errors"].append("DB غير متاحة: " + str(e))

    # 2. الجداول الأساسية
    base = ["accounting_tree", "journal_entry_master", "journal_entry_detail",
            "account_periods", "branches", "auth_user"]
    missing = []
    for t in base:
        if not acc_schema.table_exists(db, t):
            missing.append(t)
    if missing:
        out["status"] = "degraded"
        out["checks"]["base_tables"] = "fail"
        out["errors"].append("جداول أساسية مفقودة: " + ", ".join(missing))
    else:
        out["checks"]["base_tables"] = "ok"

    # 3. الجداول الاختيارية (للإبلاغ فقط)
    opt = {
        "journal_attachments": acc_schema.table_exists(db, "journal_attachments"),
        "journal_templates": acc_schema.table_exists(db, "journal_templates"),
    }
    out["checks"]["optional_features"] = opt

    # 4. مجلدات الكتابة
    folders = {
        "private/dbbackup": request.folder + "private/dbbackup",
        "uploads/journal_attachments": request.folder + "uploads/journal_attachments",
    }
    folder_status = {}
    for label, p in folders.items():
        try:
            if not os.path.exists(p):
                os.makedirs(p, exist_ok=True)
            test = os.path.join(p, ".health_test")
            with open(test, "w") as f:
                f.write("ok")
            os.remove(test)
            folder_status[label] = "ok"
        except Exception as e:
            folder_status[label] = "fail: " + str(e)
            out["status"] = "degraded"
            out["errors"].append("مجلد غير قابل للكتابة: " + label)
    out["checks"]["folders"] = folder_status

    # 5. النسخة
    try:
        ver_file = pathlib.Path(request.folder) / "acc_ver.txt"
        with open(ver_file, "r") as f:
            out["version"] = f.read().strip()
    except Exception:
        out["version"] = "unknown"

    # 6. الـ Subscription
    try:
        from gluon.contrib.appconfig import AppConfig
        cfg = AppConfig(reload=True)
        exp = cfg.get("app.exp_date")
        if exp:
            from datetime import datetime as _dt, date as _date
            d = _dt.strptime(exp, "%Y-%m-%d").date()
            days_left = (d - _date.today()).days
            out["subscription_days_left"] = days_left
            if days_left < 0:
                out["status"] = "degraded"
                out["errors"].append("الاشتراك منتهٍ")
    except Exception:
        pass

    # رمز الحالة HTTP
    if out["status"] != "ok":
        response.status = 503
    return response.json(out)


@auth.requires(can_view)
def home_dashboard():
    """مؤشرات حيّة للصفحة الرئيسية (Phase 4.3).
    كل قسم محاط بـ try محلي حتى لا ينهار كامل اللوحة إن فشل أحدها.
    """
    out = {
        "err": 0, "period": None, "recent": [],
        "unbalanced": 0, "daily": [], "counts": {},
        "warnings": [],
    }
    # الدورة المفتوحة — قد لا توجد، لا نُسقط اللوحة
    per = None
    try:
        per = db(db.account_periods.open_period == 1).select(
            orderby=db.account_periods.id
        ).first()
        if per:
            out["period"] = {
                "id": per.id,
                "disc": per.disc,
                "start_date": str(per.start_date) if per.start_date else None,
                "end_date": str(per.end_date) if per.end_date else None,
            }
    except Exception as e:
        out["warnings"].append("تعذّر قراءة الدورة: " + str(e))

    # آخر 5 قيود — قد يكون الجدول فارغاً
    try:
        recent = db(db.journal_entry_master.is_active == True).select(
            db.journal_entry_master.id,
            db.journal_entry_master.journal_date,
            db.journal_entry_master.journal_detail,
            db.journal_entry_master.debit_total,
            db.journal_entry_master.credit_total,
            db.journal_entry_master.branches,
            orderby=~db.journal_entry_master.id,
            limitby=(0, 5),
        )
        bids = list({r.branches for r in recent if r.branches})
        bmap = {}
        if bids:
            for b in db(db.branches.id.belongs(bids)).select(
                db.branches.id, db.branches.name
            ):
                bmap[int(b.id)] = b.name
        out["recent"] = [{
            "id": int(r.id),
            "journal_date": str(r.journal_date) if r.journal_date else None,
            "journal_detail": r.journal_detail or "",
            "debit_total": float(r.debit_total or 0),
            "credit_total": float(r.credit_total or 0),
            "branch_name": bmap.get(int(r.branches), "—") if r.branches else "—",
        } for r in recent]
    except Exception as e:
        out["warnings"].append("تعذّر تحميل آخر القيود: " + str(e))

    # عداد القيود غير المتوازنة في الدورة المفتوحة
    try:
        if per:
            qry = (
                "SELECT COUNT(*) FROM ("
                "  SELECT jed.journal_entry_master "
                "  FROM journal_entry_detail jed "
                "  JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
                "  WHERE jem.is_active = 'T' "
                "    AND jed.account_periods = %s "
                "  GROUP BY jed.journal_entry_master "
                "  HAVING round(CAST(COALESCE(sum(jed.debit),0) AS numeric),2) "
                "       <> round(CAST(COALESCE(sum(jed.credit),0) AS numeric),2)"
                ") t"
            )
            r = db.executesql(qry, placeholders=[per.id])
            out["unbalanced"] = int(r[0][0] or 0) if r else 0
    except Exception as e:
        out["warnings"].append("تعذّر فحص توازن القيود: " + str(e))

    # إجمالي القيود يومياً في آخر 30 يوم
    try:
        today = datetime.date.today()
        start = today - datetime.timedelta(days=30)
        daily_rows = db.executesql(
            "SELECT journal_date::date AS d, COUNT(*)::int AS n, "
            "       COALESCE(SUM(debit_total),0)::float AS dt "
            "FROM journal_entry_master "
            "WHERE is_active = 'T' AND journal_date >= %s "
            "GROUP BY journal_date::date "
            "ORDER BY d",
            placeholders=[str(start)],
            as_dict=True,
        )
        out["daily"] = [{
            "date": str(r["d"]),
            "count": int(r["n"] or 0),
            "total": float(r["dt"] or 0),
        } for r in daily_rows]
    except Exception as e:
        out["warnings"].append("تعذّر تحميل النشاط اليومي: " + str(e))

    # عدّادات سريعة
    try:
        out["counts"] = {
            "branches": db(db.branches.show_row == 1).count(),
            "periods_open": db(db.account_periods.open_period == 1).count(),
            "accounts": db(db.accounting_tree.id > 0).count(),
            "journals_active": db(db.journal_entry_master.is_active == True).count(),
        }
    except Exception as e:
        out["warnings"].append("تعذّر تحميل العدّادات: " + str(e))

    try:
        return response.json(out)
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Embedded wiki (example) ----
def wiki():
    auth.wikimenu()  # add the wiki to the menu
    return auth.wiki()


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    action = request.args(0) or "login"
    response.title = {
        "profile": "الملف الشخصي",
        "login": "تسجيل الدخول",
        "register": "تسجيل حساب",
        "change_password": "تغيير كلمة المرور",
        "retrieve_password": "استعادة كلمة المرور",
    }.get(action, action.replace("_", " ").title())
    return dict(form=auth())


def _sms_cfg_bool(key, env=None, default=False):
    val = str(_cfg(key, env=env, default=str(default)) or "").lower()
    return val in ("true", "1", "yes", "on")


def _reset_generic_message():
    return "إذا كان البريد مرتبطاً بمستخدم لديه رقم جوال فسيصله رمز تحقق خلال لحظات."


def _reset_user_by_email(email):
    email = (email or "").strip().lower()
    if not email:
        return None
    return db(db.auth_user.email == email).select(db.auth_user.ALL, limitby=(0, 1)).first()


def _recent_reset_count(user_id, minutes):
    since = request.now - datetime.timedelta(minutes=minutes)
    return db(
        (db.password_reset_otp.user_id == user_id)
        & (db.password_reset_otp.created_on >= since)
    ).count()


def _send_reset_code(user):
    authz = _cfg("sms.authorization", env="ACC_SMS_AUTHORIZATION")
    sender = _cfg("sms.sender", env="ACC_SMS_SENDER")
    dry_run = _sms_cfg_bool("sms.dry_run", env="ACC_SMS_DRY_RUN", default=False)
    code = acc_password_reset.generate_otp()
    salt = secrets.token_hex(16)
    expires_on = request.now + datetime.timedelta(minutes=10)
    mobile = acc_sms.normalize_mobile(user.mobile)
    message = "رمز استعادة كلمة المرور في نظام المحاسبة: %s صالح لمدة 10 دقائق." % code

    if dry_run:
        result = {"ok": True, "status": "dry-run", "body": "SMS dry-run enabled"}
    else:
        result = acc_sms.send_oursms(authz, sender, mobile, message)
    if not result.get("ok"):
        raise RuntimeError("SMS send failed: " + str(result)[:500])

    db.password_reset_otp.insert(
        user_id=user.id,
        code_hash=acc_password_reset.hash_otp(code, salt),
        salt=salt,
        expires_on=expires_on,
        attempts=0,
        requested_ip=request.client,
        user_agent=(request.env.http_user_agent or "")[:255],
        sent_to_last4=acc_sms.normalize_mobile(user.mobile)[-4:],
        send_status=str(result)[:2000],
    )
    return result


def _handle_sms_code_request(email):
    user = _reset_user_by_email(email)
    if user and getattr(user, "mobile", None):
        if _recent_reset_count(user.id, 1) == 0 and _recent_reset_count(user.id, 60) < 5:
            try:
                _send_reset_code(user)
                db.commit()
            except Exception as e:
                db.rollback()
                try:
                    db.err_report.insert(
                        screen_dis="default.sms_password_reset",
                        er_dis=str(e)[:1000],
                    )
                    db.commit()
                except Exception:
                    db.rollback()
        else:
            db.commit()
    return {"kind": "info", "text": _reset_generic_message()}


def _handle_sms_password_reset(email, code, password, confirm):
    user = _reset_user_by_email(email)
    generic_error = "تعذر التحقق من الرمز. تأكد من البيانات أو اطلب رمزاً جديداً."
    if not user:
        return {"kind": "error", "text": generic_error}
    if password != confirm:
        return {"kind": "error", "text": "تأكيد كلمة المرور غير مطابق."}
    ok, msg = acc_password_reset.valid_password(password)
    if not ok:
        return {"kind": "error", "text": msg}

    token = db(
        (db.password_reset_otp.user_id == user.id)
        & (db.password_reset_otp.used_on == None)
        & (db.password_reset_otp.expires_on >= request.now)
    ).select(orderby=~db.password_reset_otp.id, limitby=(0, 1)).first()
    if not token:
        return {"kind": "error", "text": generic_error}
    if int(token.attempts or 0) >= 5:
        return {"kind": "error", "text": "تم تجاوز عدد المحاولات. اطلب رمزاً جديداً."}

    token.update_record(attempts=int(token.attempts or 0) + 1)
    if not acc_password_reset.verify_otp((code or "").strip(), token.salt, token.code_hash):
        db.commit()
        return {"kind": "error", "text": generic_error}

    fields = {"password": db.auth_user.password.validate(password)[0]}
    if "must_change_password" in db.auth_user.fields:
        fields["must_change_password"] = "F"
    user.update_record(**fields)
    token.update_record(used_on=request.now)
    db(
        (db.password_reset_otp.user_id == user.id)
        & (db.password_reset_otp.used_on == None)
        & (db.password_reset_otp.id != token.id)
    ).update(used_on=request.now)
    db.commit()
    return {"kind": "success", "text": "تم تغيير كلمة المرور. يمكنك تسجيل الدخول الآن."}


def sms_password_reset():
    """استعادة كلمة المرور عبر رمز SMS مؤقت."""
    response.title = "استعادة كلمة المرور عبر SMS"
    notice = None
    email = (request.vars.get("email") or "").strip().lower()
    if request.env.request_method == "POST":
        action = request.vars.get("action")
        try:
            if action == "request_code":
                notice = _handle_sms_code_request(email)
            elif action == "reset_password":
                notice = _handle_sms_password_reset(
                    email,
                    request.vars.get("code"),
                    request.vars.get("new_password") or "",
                    request.vars.get("confirm_password") or "",
                )
            else:
                notice = {"kind": "error", "text": "طلب غير معروف."}
        except Exception as e:
            db.rollback()
            notice = {"kind": "error", "text": "حدث خطأ أثناء معالجة الطلب."}
            try:
                db.err_report.insert(
                    screen_dis="default.sms_password_reset",
                    er_dis=str(e)[:1000],
                )
                db.commit()
            except Exception:
                db.rollback()
    return dict(notice=notice, email=email)


# ---- action to server uploaded static content (required) ---
@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


@auth.requires_login()
def about():
    """شاشة حول النظام — تعرض رقم النسخة و تاريخها و حالة التحديث"""
    response.title = "حول النظام"
    import subprocess
    import pathlib
    from gluon.contrib.appconfig import AppConfig

    configuration = AppConfig(reload=True)
    exp = configuration.get("app.exp_date")
    date_def = None
    if exp:
        d1 = datetime.datetime.strptime(
            datetime.datetime.now().strftime("%Y-%m-%d"), "%Y-%m-%d"
        )
        d2 = datetime.datetime.strptime(exp, "%Y-%m-%d")
        date_def = (d2 - d1).days

    # النسخة المحلية و تاريخها من acc_ver.txt (التاريخ = تاريخ تعديل الملف)
    app_path = pathlib.Path(__file__).resolve().parent.parent
    ver_file = app_path / "acc_ver.txt"
    local_ver = "0"
    ver_date = "-"
    try:
        with open(ver_file, "r") as f:
            local_ver = f.read().strip()
        ver_date = datetime.datetime.fromtimestamp(
            ver_file.stat().st_mtime
        ).strftime("%Y-%m-%d")
    except Exception:
        pass

    # نسخة الخادم — للتحقق من توفّر تحديث
    remote_ver = local_ver
    has_update = False
    update_error = None
    try:
        result = subprocess.run(
            ["curl", "-sL", "--max-time", "10",
             "https://github.com/zahmee/update/raw/refs/heads/main/acc_ver.txt"],
            capture_output=True, text=True, timeout=12,
        )
        if result.returncode == 0 and result.stdout.strip():
            rv = result.stdout.strip()
            try:
                has_update = float(rv) > float(local_ver)
                remote_ver = rv
            except ValueError:
                update_error = "استجابة غير صالحة من خادم التحديث"
        else:
            update_error = result.stderr or "empty response"
    except Exception as e:
        update_error = str(e)

    return dict(
        exp=exp,
        date_def=date_def,
        local_ver=local_ver,
        ver_date=ver_date,
        remote_ver=remote_ver,
        has_update=has_update,
        update_error=update_error,
    )


@auth.requires_login()
def history():
    """سجل إصدارات النظام"""
    return dict()
