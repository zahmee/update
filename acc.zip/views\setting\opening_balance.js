// ======================  الأرصدة الافتتاحية — منطق Vue 3  ======================
// نموذج العمل: يُعرض ويعدَّل ثلاثية (دورة × فرع × حساب). يجب أن يتوازن
// ∑المدين = ∑الدائن. لا يجوز مدين ودائن معاً على الحساب نفسه. الدورة المقفلة
// محمية إلا إن فتح المدير الباب صراحة.

function normalize(r) {
    return {
        id: Number(r.id),
        account_no: String(r.account_no || ''),
        main_account: String(r.main_account || '0'),
        account_name: String(r.account_name || r.account_name_ar || r.account_no || ''),
        account_name_en: String(r.account_name_en || ''),
        parent_name: r.parent_name ? String(r.parent_name) : '',
        account_type: Number(r.account_type) || 0,
        final_account: Number(r.final_account) || 0,
        debit: Number(r.debit) || 0,
        credit: Number(r.credit) || 0,
        carried_from_period: r.carried_from_period ? Number(r.carried_from_period) : null,
        carried_from_disc: r.carried_from_disc ? String(r.carried_from_disc) : '',
        _orig_debit: Number(r.debit) || 0,
        _orig_credit: Number(r.credit) || 0,
        _dirty: false,
        _flash: false,
    };
}

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../setting_api/',
            isAdmin: !!window.isAdmin,
            account_periods: [],
            branches: [],
            rows: [],
            period_info: null,
            period_select: -1,
            branch_select: -1,
            loading: false,
            saving: false,
            carrying: false,
            search: '',
            filter_fa: 0,            // 0=all, 1=BS, 2=P&L, 3=Trading
            allow_closed: false,     // مدير فقط: فتح الباب لتعديل دورة مقفلة
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        ready() {
            return Number(this.period_select) > 0 && Number(this.branch_select) > 0;
        },
        periodName() {
            var p = this.account_periods.find(p => Number(p.id) === Number(this.period_select));
            return p ? p.disc : '';
        },
        branchName() {
            var b = this.branches.find(b => Number(b.id) === Number(this.branch_select));
            return b ? b.name : '';
        },
        can_edit() {
            if (!this.period_info) return false;
            if (this.period_info.open_period === 1) return true;
            return this.isAdmin && this.allow_closed;
        },
        dirty_count() {
            return this.rows.filter(r => r._dirty).length;
        },
        totals() {
            var d = 0, c = 0, nz = 0;
            this.rows.forEach(r => {
                var dv = Number(r.debit) || 0;
                var cv = Number(r.credit) || 0;
                d += dv; c += cv;
                if (dv > 0 || cv > 0) nz++;
            });
            d = Math.round(d * 100) / 100;
            c = Math.round(c * 100) / 100;
            var diff = Math.round((d - c) * 100) / 100;
            return {
                debit: d,
                credit: c,
                diff: diff,
                nonzero: nz,
                balanced: Math.abs(diff) < 0.005 && (d > 0 || c > 0),
            };
        },
        filteredRows() {
            var q = (this.search || '').trim().toLowerCase();
            return this.rows.filter(r => {
                if (this.filter_fa !== 0 && Number(r.final_account) !== this.filter_fa) return false;
                if (!q) return true;
                return (String(r.account_no).toLowerCase().indexOf(q) !== -1)
                    || ((r.account_name || '').toLowerCase().indexOf(q) !== -1)
                    || ((r.account_name_en || '').toLowerCase().indexOf(q) !== -1);
            });
        },
        visibleRows() { return this.filteredRows; },
        visibleTotals() {
            var d = 0, c = 0;
            this.filteredRows.forEach(r => {
                d += Number(r.debit) || 0;
                c += Number(r.credit) || 0;
            });
            return {
                debit: Math.round(d * 100) / 100,
                credit: Math.round(c * 100) / 100,
            };
        },
    },

    created() { this.bootstrap(); },

    mounted() {
        // تحذير المستخدم عند مغادرة الصفحة مع وجود تغييرات غير محفوظة
        window.addEventListener('beforeunload', this._beforeUnload = (e) => {
            if (this.dirty_count > 0) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
        window.addEventListener('keydown', this._onKey = (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                if (this.can_edit && this.dirty_count > 0 && !this.saving) this.save_all();
            }
        });
    },
    unmounted() {
        if (this._beforeUnload) window.removeEventListener('beforeunload', this._beforeUnload);
        if (this._onKey) window.removeEventListener('keydown', this._onKey);
    },

    methods: {
        bootstrap() {
            var self = this;
            axios.get(this.api + 'get_all_account_periodsA').then(r => {
                self.account_periods = Array.isArray(r.data) ? r.data : [];
                // افتراضياً: أول دورة مفتوحة
                var open = self.account_periods.find(p => Number(p.open_period) === 1);
                if (open) self.period_select = open.id;
                else if (self.account_periods.length) self.period_select = self.account_periods[0].id;
                self.maybeAutoLoad();
            });
            axios.get(this.api + 'get_all_branches').then(r => {
                self.branches = Array.isArray(r.data) ? r.data : [];
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.branch_select = main.id;
                else if (self.branches.length === 1) self.branch_select = self.branches[0].id;
                self.maybeAutoLoad();
            });
        },

        maybeAutoLoad() { if (this.ready) this.onChange(); },

        onChange() {
            if (!this.ready) { this.rows = []; this.period_info = null; return; }
            // تحذير قبل تبديل السياق وثمة تغييرات غير محفوظة
            if (this.dirty_count > 0) {
                var self = this;
                var savedPeriod = this.period_select, savedBranch = this.branch_select;
                Swal.fire({
                    icon: 'warning',
                    title: 'يوجد تغييرات غير محفوظة',
                    text: 'سيتم فقدان ' + this.dirty_count + ' تغيير. متابعة؟',
                    showCancelButton: true,
                    confirmButtonText: 'متابعة',
                    cancelButtonText: 'إلغاء',
                    confirmButtonColor: '#d33',
                }).then(result => {
                    if (result.isConfirmed) self._doLoad();
                    else {
                        // عكس التبديل (يحتاج Vue tick)
                        self.$nextTick(() => {
                            // لا شيء — المستخدم سيعيد الاختيار يدوياً
                        });
                    }
                });
                return;
            }
            this._doLoad();
        },

        _doLoad() {
            var self = this;
            this.loading = true;
            this.allow_closed = false;
            axios.get(this.api + 'get_opening_periods_balance/'
                + this.branch_select + '/' + this.period_select)
                .then(r => {
                    var d = r.data || {};
                    if (d.err) {
                        Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess || 'حدث خطأ' });
                        self.rows = []; self.period_info = null;
                        return;
                    }
                    self.rows = Array.isArray(d.rows) ? d.rows.map(normalize) : [];
                    self.period_info = d.period || null;
                })
                .catch(() => {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                    self.rows = []; self.period_info = null;
                })
                .then(() => { self.loading = false; });
        },

        markDirty(r) {
            // مسح الحقل المقابل تلقائياً (لا يجوز مدين ودائن معاً)
            // لكن نسمح للمستخدم بمسحه بنفسه؛ هنا فقط نتجاهل القيم غير الصالحة
            var d = Number(r.debit) || 0;
            var c = Number(r.credit) || 0;
            if (d < 0) r.debit = 0;
            if (c < 0) r.credit = 0;
            r._dirty = (Number(r.debit) || 0) !== r._orig_debit
                    || (Number(r.credit) || 0) !== r._orig_credit;
            r._flash = false;
        },

        save_all() {
            if (!this.can_edit || this.dirty_count === 0 || this.saving) return;
            var self = this;
            var dirty = this.rows.filter(r => r._dirty);
            // فحص محلي قبل الإرسال
            for (var i = 0; i < dirty.length; i++) {
                var r = dirty[i];
                var d = Number(r.debit) || 0, c = Number(r.credit) || 0;
                if (d > 0 && c > 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'بيانات غير صحيحة',
                        html: 'السطر <b>[' + r.account_no + ']</b> فيه مدين ودائن معاً — اختر جانباً واحداً.',
                    });
                    return;
                }
            }
            // لا تقبل حفظ رصيد افتتاحي غير متوازن.
            var proceed = function () {
                self.saving = true;
                var payload = dirty.map(r => ({
                    id: r.id,
                    debit: Number(r.debit) || 0,
                    credit: Number(r.credit) || 0,
                }));
                var form = new FormData();
                form.append('rows', JSON.stringify(payload));
                if (self.allow_closed) form.append('allow_closed', '1');
                axios.post(self.api + 'bulk_update_opening_balances/', form, {
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                }).then(res => {
                    var d2 = res.data || {};
                    if (d2.mess === '0') {
                        dirty.forEach(r => {
                            r._orig_debit = Number(r.debit) || 0;
                            r._orig_credit = Number(r.credit) || 0;
                            r._dirty = false;
                            r._flash = true;
                            setTimeout(() => { r._flash = false; }, 1500);
                        });
                        Swal.fire({
                            icon: 'success', title: 'تم الحفظ',
                            text: 'حُفظت ' + (d2.count || dirty.length) + ' تعديل.',
                            timer: 1600, showConfirmButton: false,
                        });
                    } else {
                        Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d2.mess || 'حدث خطأ' });
                    }
                }).catch(() => {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                }).then(() => { self.saving = false; });
            };
            // التحقق من التوازن بعد التعديل (محلياً)
            var newDebit = 0, newCredit = 0;
            this.rows.forEach(r => { newDebit += Number(r.debit) || 0; newCredit += Number(r.credit) || 0; });
            var diff = Math.round((newDebit - newCredit) * 100) / 100;
            if (Math.abs(diff) >= 0.005) {
                Swal.fire({
                    icon: 'warning',
                    title: 'الميزانية الافتتاحية غير متوازنة',
                    html: 'الفرق بعد الحفظ: <b>' + fmtNumber(diff) + '</b><br>' +
                          '<small>يجب أن يتساوى إجمالي المدين والدائن قبل الحفظ.</small>',
                    confirmButtonText: 'مراجعة',
                    confirmButtonColor: '#0d6efd',
                });
                return;
            } else {
                proceed();
            }
        },

        preview_carry_previous() {
            if (!this.ready || !this.can_edit || this.carrying) return;
            if (this.dirty_count > 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'يوجد تغييرات غير محفوظة',
                    text: 'احفظ التغييرات أو أعد تحميل الصفحة قبل ترحيل أرصدة الدورة السابقة.',
                });
                return;
            }
            var self = this;
            this.carrying = true;
            var form = new FormData();
            form.append('branch', this.branch_select);
            form.append('period', this.period_select);
            axios.post(this.api + 'preview_previous_opening_balances/', form, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).then(res => {
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'warning', title: 'تعذّر الترحيل', text: d.mess || 'حدث خطأ' });
                    return;
                }
                if (d.closing && d.closing.needs_closing) {
                    self.prompt_close_result(d);
                    return;
                }
                if (!d.count) {
                    Swal.fire({
                        icon: 'info',
                        title: 'لا توجد أرصدة قابلة للترحيل',
                        text: 'لم يعثر النظام على أرصدة ميزانية غير صفرية في الدورة السابقة.',
                    });
                    return;
                }
                var replaceNote = d.existing_nonzero > 0
                    ? '<div class="text-danger mt-2">سيتم استبدال ' + d.existing_nonzero + ' رصيد افتتاحي حالي لحسابات الميزانية في هذا الفرع.</div>'
                    : '<div class="text-muted mt-2">لا توجد أرصدة حالية سيتم استبدالها.</div>';
                Swal.fire({
                    icon: 'question',
                    title: 'ترحيل أرصدة الدورة السابقة؟',
                    html:
                        '<div class="text-end">' +
                        '<div>من: <b>' + d.from_period_name + '</b></div>' +
                        '<div>إلى: <b>' + d.to_period_name + '</b></div>' +
                        '<div>عدد الحسابات: <b>' + d.count + '</b></div>' +
                        '<div>إجمالي المدين: <b>' + fmtNumber(d.total_debit) + '</b></div>' +
                        '<div>إجمالي الدائن: <b>' + fmtNumber(d.total_credit) + '</b></div>' +
                        replaceNote +
                        '</div>',
                    showCancelButton: true,
                    confirmButtonText: 'ترحيل الآن',
                    cancelButtonText: 'إلغاء',
                    confirmButtonColor: '#0f766e',
                }).then(result => {
                    if (result.isConfirmed) self.execute_carry_previous();
                });
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.carrying = false; });
        },

        prompt_close_result(d) {
            var closing = d.closing || {};
            if (!this.isAdmin) {
                Swal.fire({
                    icon: 'warning',
                    title: 'الدورة السابقة تحتاج إقفال نتيجة',
                    html:
                        '<div class="text-end">' +
                        '<div>الدورة: <b>' + (closing.source_period_name || d.from_period_name || '') + '</b></div>' +
                        '<div>صافي النتيجة: <b>' + fmtNumber(Math.abs(closing.net || 0)) + '</b></div>' +
                        '<div class="mt-2">إنشاء قيد الإقفال يتطلب صلاحية مدير قبل ترحيل الأرصدة.</div>' +
                        '</div>',
                });
                return;
            }
            var options = {};
            (closing.equity_accounts || []).forEach(a => {
                options[String(a.id)] = a.account_no + ' — ' + a.account_name;
            });
            if (!Object.keys(options).length) {
                Swal.fire({
                    icon: 'warning',
                    title: 'لا يوجد حساب إقفال مناسب',
                    text: 'أضف حساب حقوق ملكية/أرباح مرحلة ضمن حسابات الميزانية في الدورة السابقة ثم أعد المحاولة.',
                });
                return;
            }
            var resultLabel = closing.result_type === 'profit' ? 'ربح'
                : closing.result_type === 'loss' ? 'خسارة' : 'صفر';
            var closedNote = Number(closing.source_period_open) !== 1
                ? '<div class="text-danger mt-2">الدورة السابقة مقفلة؛ سيتم إنشاء قيد الإقفال بتأكيد المدير.</div>'
                : '';
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'إقفال نتيجة الدورة السابقة أولاً',
                html:
                    '<div class="text-end">' +
                    '<div>الدورة: <b>' + (closing.source_period_name || d.from_period_name || '') + '</b></div>' +
                    '<div>النتيجة: <b>' + resultLabel + ' ' + fmtNumber(Math.abs(closing.net || 0)) + '</b></div>' +
                    '<div>إجمالي أرصدة المصروفات: <b>' + fmtNumber(closing.debit || 0) + '</b></div>' +
                    '<div>إجمالي أرصدة الإيرادات: <b>' + fmtNumber(closing.credit || 0) + '</b></div>' +
                    closedNote +
                    '</div>',
                input: 'select',
                inputOptions: options,
                inputPlaceholder: 'اختر حساب ترحيل النتيجة',
                showCancelButton: true,
                confirmButtonText: 'إنشاء قيد الإقفال',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#0f766e',
                inputValidator: v => v ? undefined : 'اختر حساب ترحيل النتيجة',
            }).then(result => {
                if (result.isConfirmed) self.execute_close_result(d, result.value);
            });
        },

        execute_close_result(d, equityId) {
            var self = this;
            this.carrying = true;
            var form = new FormData();
            form.append('branch', this.branch_select);
            form.append('period', this.period_select);
            form.append('equity_account', equityId);
            if (d.closing && Number(d.closing.source_period_open) !== 1) {
                form.append('allow_closed', '1');
            }
            axios.post(this.api + 'close_previous_period_result/', form, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).then(res => {
                var data = res.data || {};
                if (data.mess === '0') {
                    Swal.fire({
                        icon: 'success',
                        title: data.already_closed ? 'النتيجة مقفلة مسبقاً' : 'تم إنشاء قيد الإقفال',
                        text: data.already_closed ? 'يمكن متابعة الترحيل الآن.' : 'رقم القيد: ' + (data.journal_save || data.journal_id),
                        timer: 1700,
                        showConfirmButton: false,
                    }).then(() => self.preview_carry_previous());
                } else {
                    Swal.fire({ icon: 'warning', title: 'تعذّر إنشاء قيد الإقفال', text: data.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.carrying = false; });
        },

        execute_carry_previous() {
            var self = this;
            this.carrying = true;
            var form = new FormData();
            form.append('branch', this.branch_select);
            form.append('period', this.period_select);
            if (this.allow_closed) form.append('allow_closed', '1');
            axios.post(this.api + 'carry_previous_opening_balances/', form, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            }).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    Swal.fire({
                        icon: 'success',
                        title: 'تم الترحيل',
                        text: 'تم ترحيل ' + (d.count || 0) + ' رصيد من دورة ' + (d.from_period_name || 'سابقة') + '.',
                        timer: 1800,
                        showConfirmButton: false,
                    });
                    self._doLoad();
                } else {
                    Swal.fire({ icon: 'warning', title: 'تعذّر الترحيل', text: d.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.carrying = false; });
        },

        clear_all() {
            if (!this.can_edit || this.totals.nonzero === 0) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'تصفير الأرصدة',
                html: '<b>تحذير:</b> سيتم تصفير جميع الأرصدة الافتتاحية (' + this.totals.nonzero + ' حساب) ' +
                      'لهذا الفرع والدورة. لا يمكن التراجع.<br>اكتب <b>تصفير</b> للتأكيد:',
                input: 'text',
                showCancelButton: true,
                confirmButtonText: 'صفّر الجميع',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
                inputValidator: (v) => v === 'تصفير' ? undefined : 'اكتب "تصفير" للتأكيد',
            }).then(result => {
                if (!result.isConfirmed) return;
                var form = new FormData();
                form.append('branch', self.branch_select);
                form.append('period', self.period_select);
                axios.post(self.api + 'clear_opening_balances/', form, {
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                }).then(res => {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        Swal.fire({
                            icon: 'success', title: 'تم التصفير',
                            text: 'صُفّرت أرصدة ' + (d.count || 0) + ' حساب.',
                            timer: 1500, showConfirmButton: false,
                        });
                        self._doLoad();
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر التصفير', text: d.mess || 'حدث خطأ' });
                    }
                }).catch(() => {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                });
            });
        },

        export_json() {
            if (!this.rows.length) return;
            var data = this.rows.map(r => ({
                account_no: r.account_no,
                account_name: r.account_name,
                main_account: r.main_account,
                debit: r.debit,
                credit: r.credit,
            }));
            var blob = new Blob([JSON.stringify(data, null, 2)],
                { type: 'application/json;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'opening_balance_' + this.branch_select + '_' + this.period_select + '.json';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        print_screen() {
            this.now_str = new Date().toLocaleString('en-GB');
            this.$nextTick(() => window.print());
        },

        countByFinal(v) {
            return this.rows.filter(r => Number(r.final_account) === v).length;
        },

        finalLabel(v) {
            v = Number(v);
            return v === 1 ? 'ميزانية' : v === 2 ? 'أ/خ' : v === 3 ? 'متاجرة' : '';
        },

        natureLabel(v) {
            v = Number(v);
            return v === 1 ? 'دائن' : v === 2 ? 'مدين' : '';
        },

        natureHint(r, side) {
            // إن كان الحساب بطبيعته مديناً نعرض placeholder في حقل المدين فقط، والعكس
            var t = Number(r.account_type);
            if (side === 'debit' && t === 2) return '0.00';
            if (side === 'credit' && t === 1) return '0.00';
            return '';
        },

        fmt(n) { return fmtNumber(n); },
    },
});

var app = vueApp.mount('#app');
