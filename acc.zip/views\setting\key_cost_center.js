// ======================  مراكز التكلفة — منطق Vue 3  ======================

function blankRow() {
    return { id: -1, name: '', show_cost: 1, usage_count: 0 };
}

function normalize(c) {
    return {
        id: Number(c.id),
        name: c.name == null ? '' : String(c.name),
        show_cost: Number(c.show_cost) === 2 ? 2 : 1,
        usage_count: Number(c.usage_count) || 0,
    };
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../setting_api/',
            isAdmin: !!window.isAdmin,
            data: [],
            loading: true,
            saving: false,
            search: '',
            filter_mode: 'all',  // all | visible | hidden | used | unused
            modal_open: false,
            select_row: blankRow(),
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        is_edit() { return Number(this.select_row.id) > 0; },
        filteredData() {
            var q = (this.search || '').trim().toLowerCase();
            var mode = this.filter_mode;
            return this.data.filter(c => {
                if (mode === 'visible' && Number(c.show_cost) !== 1) return false;
                if (mode === 'hidden' && Number(c.show_cost) === 1) return false;
                if (mode === 'used' && Number(c.usage_count) === 0) return false;
                if (mode === 'unused' && Number(c.usage_count) > 0) return false;
                if (!q) return true;
                return (c.name || '').toLowerCase().indexOf(q) !== -1;
            });
        },
        stats() {
            var s = { total: 0, visible: 0, hidden: 0, used: 0, total_usage: 0 };
            this.data.forEach(c => {
                s.total++;
                if (Number(c.show_cost) === 1) s.visible++;
                else s.hidden++;
                if (Number(c.usage_count) > 0) s.used++;
                s.total_usage += Number(c.usage_count) || 0;
            });
            return s;
        },
        filterLabel() {
            switch (this.filter_mode) {
                case 'visible': return 'المتاحة';
                case 'hidden': return 'المخفية';
                case 'used': return 'المستخدمة';
                case 'unused': return 'غير المستخدمة';
                default: return 'الكل';
            }
        },
        missing() {
            var m = [];
            if (!(this.select_row.name || '').trim()) m.push('اسم المركز');
            return m;
        },
        is_valid() { return this.missing.length === 0; },
    },

    watch: {
        modal_open(open) { document.body.style.overflow = open ? 'hidden' : ''; },
    },

    created() { this.load(); },

    mounted() { window.addEventListener('keydown', this.on_key); },

    unmounted() {
        window.removeEventListener('keydown', this.on_key);
        document.body.style.overflow = '';
    },

    methods: {
        load() {
            var self = this;
            this.loading = true;
            return axios.get(this.api + 'get_all_cost_centers').then(res => {
                self.data = Array.isArray(res.data) ? res.data.map(normalize) : [];
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: 'تأكد من الاتصال.' });
            }).then(() => { self.loading = false; });
        },

        open_new() {
            this.select_row = blankRow();
            this.modal_open = true;
            this.focus_first();
        },

        open_edit(c) {
            this.select_row = normalize(c);
            // احتفظ بعدّاد الاستخدام للعرض في النافذة
            this.select_row.usage_count = Number(c.usage_count) || 0;
            this.modal_open = true;
            this.focus_first();
        },

        close_modal() {
            if (this.saving) return;
            this.modal_open = false;
        },

        focus_first() {
            var self = this;
            this.$nextTick(() => {
                if (self.$refs.firstInput) self.$refs.firstInput.focus();
            });
        },

        on_key(e) {
            if (e.key === 'Escape' && this.modal_open) this.close_modal();
        },

        payload() {
            var r = this.select_row;
            return {
                id: r.id,
                name: (r.name || '').trim(),
                show_cost: Number(r.show_cost) === 2 ? 2 : 1,
            };
        },

        add_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'add_cost_center/', this.payload()).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تمت الإضافة',
                                timer: 1500, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.saving = false; });
        },

        update_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'update_cost_center/', this.payload()).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تم الحفظ',
                                timer: 1500, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.saving = false; });
        },

        delete_row() { this._do_delete(this.select_row); },
        quick_delete(c) { this._do_delete(c); },

        _do_delete(c) {
            if (this.saving) return;
            if (Number(c.usage_count) > 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'لا يمكن حذف هذا المركز',
                    html: 'المركز <b>' + (c.name || '') + '</b> مستخدم في ' +
                          '<b>' + c.usage_count + '</b> قيد. ' +
                          'أخفِ المركز بدلاً ليظل تاريخه في القيود سليماً.',
                    showCancelButton: true,
                    confirmButtonText: 'إخفاء المركز',
                    cancelButtonText: 'إلغاء',
                }).then(result => {
                    if (result.isConfirmed) this._toggle_to_hidden(c);
                });
                return;
            }
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'حذف مركز التكلفة',
                html: 'سيتم حذف <b>' + (c.name || '') + '</b> نهائياً. هل أنت متأكد؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(result => {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'delete_cost_center/', { id: c.id }).then(res => {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.modal_open = false;
                        Swal.fire({ icon: 'success', title: 'تم الحذف',
                                    timer: 1500, showConfirmButton: false });
                        self.load();
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الحذف', text: d.mess || 'حدث خطأ' });
                    }
                }).catch(() => {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                }).then(() => { self.saving = false; });
            });
        },

        _toggle_to_hidden(c) {
            // إن كان متاحاً نحوّله مخفياً
            if (Number(c.show_cost) !== 1) {
                Swal.fire({ icon: 'info', title: 'المركز مخفي بالفعل' });
                return;
            }
            this.toggle_visibility(c);
        },

        toggle_visibility(c) {
            var self = this;
            axios.post(this.api + 'toggle_cost_center_visibility/', { id: c.id }).then(res => {
                var d = res.data || {};
                if (d.mess === '0') {
                    c.show_cost = Number(d.show_cost) === 2 ? 2 : 1;
                    Swal.fire({
                        icon: 'success',
                        title: c.show_cost === 1 ? 'أصبح المركز متاحاً' : 'أصبح المركز مخفياً',
                        timer: 1300, showConfirmButton: false,
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحديث', text: d.mess || 'حدث خطأ' });
                }
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            });
        },

        print_screen() {
            this.now_str = new Date().toLocaleString('en-GB');
            this.$nextTick(() => window.print());
        },
    },
});

var app = vueApp.mount('#app');
