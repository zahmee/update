# -*- coding: utf-8 -*-
"""
acc_carry_forward — منطق ترحيل الأرصدة الختامية للدورة التالية.

المنطق المحاسبي:
- يُرحَّل الرصيد الختامي لحسابات الميزانية فقط (final_account=1).
- حسابات الأرباح والخسائر / المتاجرة تُغلق بقيود يدوية ولا تُرحَّل.
- صافي الرصيد = (مدين-الافتتاح + مدين-القيود) - (دائن-الافتتاح + دائن-القيود).
- إن كان موجباً → افتتاحي مدين للدورة التالية.
- إن كان سالباً → افتتاحي دائن للدورة التالية.
- الأرصدة الصفرية تُهمل.

المنطق الحسابي مُنفصل عن SQL ليكون قابلاً للاختبار وحدوياً.
"""


# تصنيف final_account للحسابات التي تُرحَّل (الميزانية فقط)
FINAL_BALANCE_SHEET = 1

# عتبة الصفر (لتجاهل أخطاء الفاصلة العائمة)
ZERO_THRESHOLD = 0.005


def compute_net(opening_debit, opening_credit, journal_debit, journal_credit):
    """صافي رصيد حساب = (افتتاحي + حركة) المدين - (افتتاحي + حركة) الدائن.

    Returns:
        float — موجب = رصيد مدين، سالب = رصيد دائن، صفر = لا يُرحَّل
    """
    od = float(opening_debit or 0)
    oc = float(opening_credit or 0)
    jd = float(journal_debit or 0)
    jc = float(journal_credit or 0)
    return round((od + jd) - (oc + jc), 2)


def split_to_sides(net):
    """يُقسّم الصافي إلى (مدين، دائن) حسب الإشارة.

    >>> split_to_sides(150.0)
    (150.0, 0)
    >>> split_to_sides(-200.0)
    (0, 200.0)
    >>> split_to_sides(0)
    (0, 0)
    """
    if net > 0:
        return (net, 0)
    if net < 0:
        return (0, -net)
    return (0, 0)


def is_carriable(net):
    """هل الصافي قابل للترحيل (غير صفر بفارق معقول)؟"""
    return abs(net) >= ZERO_THRESHOLD


def format_carry_row(raw):
    """يحوّل صفّ DB (dict من executesql) إلى صفّ ترحيل.

    Args:
        raw: dict بمفاتيح branches, name, account_no, account_name_ar,
             main_account, jd, jc, od, oc (كما من estimate query)

    Returns:
        dict جاهز للعرض/الحفظ، أو None إن كان صفرياً
    """
    net = compute_net(raw.get("od"), raw.get("oc"),
                      raw.get("jd"), raw.get("jc"))
    if not is_carriable(net):
        return None
    debit, credit = split_to_sides(net)
    return {
        "branch_id": raw.get("branches"),
        "branch_name": raw.get("name") or "—",
        "account_no": raw.get("account_no"),
        "account_name": raw.get("account_name_ar") or "",
        "main_account": raw.get("main_account") or "",
        "debit": debit,
        "credit": credit,
    }


def summarize_rows(rows):
    """يحسب الإجماليات لقائمة صفوف ترحيل.

    Returns:
        dict: {count, total_debit, total_credit, balanced}
    """
    total_debit = round(sum(r.get("debit", 0) for r in rows), 2)
    total_credit = round(sum(r.get("credit", 0) for r in rows), 2)
    return {
        "count": len(rows),
        "total_debit": total_debit,
        "total_credit": total_credit,
        "balanced": abs(total_debit - total_credit) < 0.01,
    }
