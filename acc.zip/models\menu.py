# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

# ----------------------------------------------------------------------------------------------------------------------
# القائمة الرئيسية للتطبيق
# ----------------------------------------------------------------------------------------------------------------------

response.menu = [
    ('الرئيسية', request.controller == 'default' and request.function == 'index',
     URL('default', 'index'), []),
    ('العمليات', request.controller == 'operations', URL('operations', 'index'), [
        ('قيد يومية جديد', False, URL('operations', 'journal_entry')),
        ('القيود المسجلة', False, URL('operations', 'index2')),
    ]),
    ('التقارير', request.controller == 'reports', URL('reports', 'index'), [
        ('دفتر اليومية', False, URL('reports', 'Journal_report')),
        ('ميزان المراجعة', False, URL('reports', 'trial_balance')),
        ('قائمة الدخل', False, URL('reports', 'income_statement')),
        ('الميزانية العمومية', False, URL('reports', 'balance_sheet')),
        ('كشف حساب', False, URL('reports', 'account_report')),
        ('كشف حساب مخصص', False, URL('reports', 'account_report_2')),
        ('إجماليات مخصص', False, URL('reports', 'account_report_3')),
    ]),
    ('الإعدادات', request.controller == 'setting', URL('setting', 'index'), [
        ('الشجرة المحاسبية', False, URL('setting', 'accounting_tree')),
        ('الفترات المحاسبية', False, URL('setting', 'account_periods')),
        ('الفروع', False, URL('setting', 'branches')),
        ('الأرصدة الافتتاحية', False, URL('setting', 'opening_balance')),
        ('مراكز التكلفة', False, URL('setting', 'key_cost_center')),
        ('الحسابات الختامية', False, URL('setting', 'key_final_account')),
    ]),
]

# ----------------------------------------------------------------------------------------------------------------------
# روابط التطوير (في وضع التطوير فقط)
# ----------------------------------------------------------------------------------------------------------------------

if not configuration.get('app.production'):
    _app = request.application
    response.menu += [
        (T('This App'), False, '#', [
            (T('Design'), False, URL('admin', 'default', 'design/%s' % _app)),
            (T('Database'), False, URL(_app, 'appadmin', 'index')),
            (T('Errors'), False, URL('admin', 'default', 'errors/' + _app)),
        ]),
    ]
