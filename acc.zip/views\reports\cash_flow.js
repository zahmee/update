// ======================  قائمة التدفقات النقدية — منطق Vue 3  ======================

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Component لقسم نشاط واحد (تشغيلي/استثماري/تمويلي)
var SectionBlock = {
    props: ['title', 'icon', 'data'],
    template: `
        <section class="cfs-section">
            <div class="cfs-section-head">
                <i :class="'fas ' + icon"></i>
                <span>{{ title }}</span>
                <span class="cfs-section-net" :class="netClass(data.net)">
                    صافي: {{ fmtNet(data.net) }}
                </span>
            </div>
            <table class="cfs-table" v-if="data.items.length">
                <thead>
                    <tr>
                        <th style="width:5rem;">الحساب</th>
                        <th>الاسم</th>
                        <th style="text-align:end;">داخل</th>
                        <th style="text-align:end;">خارج</th>
                        <th style="text-align:end;">صافي</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="it in data.items" :key="it.account_no">
                        <td>{{ it.account_no }}</td>
                        <td>{{ it.account_name }}</td>
                        <td class="cfs-num is-in">{{ it.inflow ? '+' + fmt(it.inflow) : '—' }}</td>
                        <td class="cfs-num is-out">{{ it.outflow ? '-' + fmt(it.outflow) : '—' }}</td>
                        <td class="cfs-num" :class="netClass(it.net)">{{ fmtNet(it.net) }}</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr class="cfs-foot">
                        <td colspan="2">إجمالي {{ title }}</td>
                        <td class="cfs-num is-in">+{{ fmt(data.total_inflow) }}</td>
                        <td class="cfs-num is-out">-{{ fmt(data.total_outflow) }}</td>
                        <td class="cfs-num" :class="netClass(data.net)">{{ fmtNet(data.net) }}</td>
                    </tr>
                </tfoot>
            </table>
            <div v-else style="padding:1rem;color:var(--ink-3);text-align:center;">
                لا توجد حركات في هذا النشاط ضمن الفترة.
            </div>
        </section>
    `,
    methods: {
        fmt(n) { return fmtNumber(n); },
        fmtNet(n) {
            var v = Number(n) || 0;
            if (v === 0) return '0.00';
            return (v > 0 ? '+' : '') + fmtNumber(v);
        },
        netClass(n) {
            var v = Number(n) || 0;
            if (v > 0) return 'is-in';
            if (v < 0) return 'is-out';
            return 'is-zero';
        },
    },
};

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_cash_flow_api/',
            settingApi: window.purl + '/../../setting_api/',
            opsApi: window.purl + '/../../operations_api/',

            branches: [],
            periods: [],
            accounts: [],
            selectedCash: [],

            filters: {
                branch: 0,
                period: 0,
                date_from: '',
                date_to: '',
            },

            data: null,
            loading: false,
            _loadSeq: 0,
            now_str: new Date().toLocaleString('en-GB'),

            sections: [
                { key: 'operating',  title: 'الأنشطة التشغيلية',  icon: 'fa-cogs' },
                { key: 'investing',  title: 'الأنشطة الاستثمارية', icon: 'fa-chart-line' },
                { key: 'financing',  title: 'الأنشطة التمويلية',   icon: 'fa-hand-holding-usd' },
            ],
        };
    },

    computed: {
        canQuery() {
            return this.filters.branch > 0
                && this.filters.period > 0
                && this.filters.date_from && this.filters.date_to
                && this.selectedCash.length > 0;
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.filters.branch = main.id;
                else if (self.branches.length === 1) self.filters.branch = self.branches[0].id;
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                if (self.filters.branch > 0 && self.filters.period > 0) {
                    self.loadAccounts();
                }
            });
        },

        loadAccounts() {
            var self = this;
            this.accounts = [];
            axios.get(this.opsApi + 'get_accounts_for_journal/' + this.filters.branch + '/' + this.filters.period)
                .then(res => {
                    var rows = (res.data && res.data.accounts) || res.data || [];
                    self.accounts = (Array.isArray(rows) ? rows : []).map(a => ({
                        id: a.id,
                        account_no: a.account_no,
                        name: a.account_name_ar || a.account_name || '',
                        label: a.account_no + ' — ' + (a.account_name_ar || a.account_name || ''),
                    }));
                });
        },

        onBranchChange() {
            this.data = null;
            this.selectedCash = [];
            if (this.filters.branch > 0 && this.filters.period > 0) this.loadAccounts();
        },

        onPeriodChange() {
            var p = this.periods.find(x => x.id === this.filters.period);
            if (p) {
                if (p.start_date) this.filters.date_from = p.start_date;
                if (p.end_date) this.filters.date_to = p.end_date;
            }
            this.data = null;
            this.selectedCash = [];
            if (this.filters.branch > 0 && this.filters.period > 0) this.loadAccounts();
        },

        reload() {
            if (!this.canQuery) return;
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            var body = {
                branch: this.filters.branch,
                period: this.filters.period,
                date_from: this.filters.date_from,
                date_to: this.filters.date_to,
                cash_account_ids: this.selectedCash.map(a => a.id),
            };
            axios.post(this.api + 'cash_flow_statement/', body).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'خطأ', text: d.mess || '' });
                    self.data = null;
                } else {
                    self.data = d;
                }
            }).catch(() => {
                if (seq === self._loadSeq) self.data = null;
            }).finally(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        printReport() { window.print(); },

        exportExcel() {
            if (!this.data) return;
            var me = this;
            var body = {
                branch: this.filters.branch,
                period: this.filters.period,
                date_from: this.filters.date_from,
                date_to: this.filters.date_to,
                cash_account_ids: this.selectedCash.map(a => a.id),
                format: 'xlsx',
            };
            axios.post(this.api + 'cash_flow_statement/', body, { responseType: 'blob' })
                .then(res => {
                    var blob = new Blob([res.data], {
                        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                    });
                    var url = URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = 'cash_flow_' + me.filters.date_to + '.xlsx';
                    document.body.appendChild(a); a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                });
        },

        fmt(n) { return fmtNumber(n); },
    },
});

vueApp.component('v-select', window['vue-select']);
vueApp.component('section-block', SectionBlock);
var app = vueApp.mount('#app');
