# -*- coding: utf-8 -*-
"""
acc_pdf — تصدير PDF (اختياري).

استراتيجيتان:
1. **عبر المتصفح** (الافتراضي): الواجهة تستخدم window.print() مع طباعة CSS
   متخصصة. الطباعة العربية RTL في المتصفحات حديثة ممتازة وأفضل من معظم
   مكتبات Python.

2. **server-side** (يتطلب `pip install weasyprint`): يحوّل HTML إلى bytes
   من PDF — يستخدمه acc_export.pdf_response().

تحقّق من توفّر weasyprint قبل المحاولة:
    from applications.acc.modules import acc_pdf
    if acc_pdf.is_available():
        acc_pdf.html_to_pdf(html_str)
    else:
        # اعرض pop-up: استخدم Ctrl+P → "Save as PDF"
"""


_AVAILABLE = None
_ERROR = None


def is_available():
    """يتحقّق من توفّر weasyprint بدون رفع خطأ."""
    global _AVAILABLE, _ERROR
    if _AVAILABLE is not None:
        return _AVAILABLE
    try:
        import weasyprint  # noqa: F401
        _AVAILABLE = True
    except Exception as e:
        _AVAILABLE = False
        _ERROR = str(e)
    return _AVAILABLE


def html_to_pdf(html, base_url=None):
    """يحوّل HTML إلى bytes من PDF.

    Raises:
        RuntimeError: إن لم تكن weasyprint مثبَّتة.

    Args:
        html: نص HTML كامل (مع <html>, <head>, <body>).
        base_url: مسار لحلّ الـ <link> و<img> النسبية (اختياري).

    Returns:
        bytes: محتوى ملف PDF.
    """
    if not is_available():
        raise RuntimeError(
            "weasyprint غير مثبَّتة. ثبّتها بـ: pip install weasyprint\n"
            "أو استخدم طباعة المتصفح (Ctrl+P → Save as PDF). الخطأ: " + (_ERROR or "؟")
        )
    import weasyprint
    return weasyprint.HTML(string=html, base_url=base_url).write_pdf()


def install_instructions():
    """رسالة مساعدة للمستخدم/الوكلاء."""
    return (
        "للحصول على تصدير PDF من الخادم:\n"
        "  1. ثبّت weasyprint:   pip install weasyprint\n"
        "  2. ثبّت متطلباته (Windows): تتبع تعليمات weasyprint للمكتبات الأصلية.\n"
        "\n"
        "بدلاً من ذلك: استخدم Ctrl+P في المتصفح ثم Save as PDF — "
        "صفحات النظام مُهيأة بـ @media print بتنسيق احترافي."
    )


# Helper للـ controller: يبني response PDF أو يُرجع 503 لو لم تتوفر weasyprint
def pdf_response(response, html, filename, base_url=None):
    """يرجع PDF لرد web2py، أو 503 لو لم تتوفر المكتبة.

    Args:
        response: كائن web2py response
        html: HTML كامل
        filename: اسم الملف للتنزيل
        base_url: لـ resolution المسارات النسبية

    Returns: bytes جاهزة للرد (أو يرفع HTTP 503).
    """
    if not is_available():
        from gluon.http import HTTP
        raise HTTP(503, install_instructions())
    pdf_bytes = html_to_pdf(html, base_url=base_url)
    response.headers["Content-Type"] = "application/pdf"
    response.headers["Content-Disposition"] = 'attachment; filename="%s"' % filename
    response.headers["Content-Length"] = str(len(pdf_bytes))
    return pdf_bytes
