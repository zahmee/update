# -*- coding: utf-8 -*-
#  type: ignore
"""setting — شاشات الإعدادات.

الصلاحيات (راجع models/db.py:role_flags):
- index, account_periods, branches, accounting_tree, key_*, opening_balance,
  app_users (شاشة العرض): can_view أو can_account حسب الحساسية. التعديل
  الفعلي يحدث في APIs ويُحرس بـ can_account/can_admin هناك.
- maintenance, dbbackup: can_admin فقط.
- users/membership/groups: شاشات SQLFORM.grid قديمة — حُذفت من index لصالح
  app_users الموحَّدة. تبقى للوصول المباشر بـ URL لمن يعرف الرابط (admin only).
"""

import os
import threading

_lock = threading.RLock()


@auth.requires(can_view)
def index():
    """مكتب الإعدادات الرئيسي — يعرض الأزرار حسب دور المستخدم."""
    response.title = "الإعدادات"
    return role_flags()


@auth.requires(can_view)
def account_periods():
    """عرض الفترات للجميع؛ الإنشاء/التحديث = can_account، الإقفال/الفتح = can_admin."""
    response.title = "الفترات المحاسبية"
    return role_flags()


@auth.requires(can_view)
def branches():
    """عرض للجميع؛ CRUD = can_account."""
    response.title = "الفروع"
    return role_flags()


@auth.requires(can_admin)
def users():
    """رابط قديم: واجهة المستخدمين الموحدة هي app_users."""
    session.flash = "تم نقل إدارة المستخدمين إلى الشاشة الموحدة."
    redirect(URL("setting", "app_users"))


@auth.requires(can_admin)
def membership():
    """رابط قديم: إدارة العضويات أصبحت ضمن app_users."""
    session.flash = "تم نقل إدارة العضويات إلى شاشة المستخدمين والأدوار."
    redirect(URL("setting", "app_users"))


@auth.requires(can_admin)
def app_users():
    """شاشة إدارة المستخدمين والأدوار — Vue 3 (rebuild 2026-05-25).
    APIs في setting_users_api.py؛ يحتاج admin للوصول."""
    response.title = "المستخدمون والأدوار"
    return role_flags()


@auth.requires(can_admin)
def groups():
    """رابط قديم: إدارة الأدوار أصبحت ضمن app_users."""
    session.flash = "تم نقل إدارة الأدوار إلى شاشة المستخدمين والأدوار."
    redirect(URL("setting", "app_users"))


@auth.requires(can_view)
def accounting_tree():
    """عرض الشجرة للجميع؛ CRUD = can_account."""
    response.title = "الشجرة المحاسبية"
    return role_flags()


@auth.requires(can_view)
def key_cost_center():
    """عرض مراكز التكلفة للجميع؛ CRUD = can_account."""
    response.title = "مراكز التكلفة"
    return role_flags()


from gluon.contrib.appconfig import AppConfig


@auth.requires(can_view)
def key_final_account():
    """عرض الحسابات الختامية للجميع؛ التعديل = can_account، الحذف = can_admin."""
    response.title = "الحسابات الختامية"
    return role_flags()


@auth.requires(can_view)
def opening_balance():
    """عرض الأرصدة الافتتاحية للجميع؛ التعديل = can_account."""
    response.title = "الأرصدة الافتتاحية"
    return role_flags()


@auth.requires(can_admin)
def maintenance():
    """مركز صيانة وتشغيل النظام — للمدير فقط.
    يجمع لمحات حيّة عن صحة النظام + اختصارات للأدوات الإدارية."""
    response.title = "الصيانة وأدوات النظام"

    stats = {"db_ok": True, "errors_count": 0, "snapshots_count": 0,
             "backups_count": 0, "unbalanced": 0, "active_journals": 0,
             "branches": 0, "periods_open": 0, "accounts": 0}
    try:
        stats["branches"] = db(db.branches.id > 0).count()
        stats["periods_open"] = db(db.account_periods.open_period == 1).count()
        stats["accounts"] = db(db.accounting_tree.id > 0).count()
        stats["active_journals"] = db(db.journal_entry_master.is_active == True).count()
    except Exception:
        stats["db_ok"] = False

    try:
        rows = db.executesql(
            """SELECT m.id FROM journal_entry_master m
               LEFT JOIN journal_entry_detail d
                 ON d.journal_entry_master = m.id
               WHERE m.is_active = 'T'
               GROUP BY m.id, m.debit_total, m.credit_total
               HAVING ABS(m.debit_total - COALESCE(SUM(d.debit), 0)) > 0.01
                  OR ABS(m.credit_total - COALESCE(SUM(d.credit), 0)) > 0.01
                  OR ABS(COALESCE(SUM(d.debit), 0) - COALESCE(SUM(d.credit), 0)) > 0.01
                  OR COUNT(d.id) < 2""")
        stats["unbalanced"] = len(rows)
    except Exception:
        pass

    try:
        stats["errors_count"] = db(db.err_report.id > 0).count()
    except Exception:
        pass

    import glob as _glob
    try:
        snap_dir = os.path.join(request.folder, "private", "snapshots")
        if os.path.isdir(snap_dir):
            stats["snapshots_count"] = len([
                d for d in os.listdir(snap_dir)
                if os.path.isdir(os.path.join(snap_dir, d))])
        backup_dir = os.path.join(request.folder, "private", "dbbackup")
        if os.path.isdir(backup_dir):
            stats["backups_count"] = len(_glob.glob(
                os.path.join(backup_dir, "acc_*.*")))
    except Exception:
        pass

    recent_errors = []
    try:
        for row in db(db.err_report.id > 0).select(
                orderby=~db.err_report.id, limitby=(0, 5)):
            recent_errors.append({
                "id": row.id,
                "screen": row.screen_dis or "",
                "desc": (row.er_dis or "")[:140],
            })
    except Exception:
        pass

    try:
        with open(os.path.join(request.folder, "acc_ver.txt"),
                  encoding="utf-8") as fh:
            version = fh.read().strip()
    except Exception:
        version = "؟"

    return dict(stats=stats, recent_errors=recent_errors, version=version)


# ========================================================================================================
# ------                               backup
# ========================================================================================================


@auth.requires(can_admin)
def dbbackup():
    """نسخة احتياطية لقاعدة البيانات — admin only.
    تُحفظ في private/dbbackup/ (غير متاحة عبر الويب) باسم مؤرّخ،
    يُحتفظ بآخر 10 نسخ فقط، ثم تُرسل النسخة للمستخدم للتنزيل."""
    import glob
    import time
    import subprocess
    from urllib.parse import urlparse, unquote

    configuration = AppConfig(reload=True)
    backup_dir = os.path.join(request.folder, "private", "dbbackup")
    if not os.path.isdir(backup_dir):
        os.makedirs(backup_dir)
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    backup_file = os.path.join(backup_dir, "acc_" + stamp + ".tar")

    uri = urlparse(configuration.get("db.uri"))
    dbname = (uri.path or "").lstrip("/") or configuration.get("db.dbname")
    env = dict(os.environ, PGPASSWORD=unquote(uri.password or ""))
    with open(backup_file, "wb") as out:
        result = subprocess.run(
            ["pg_dump", "-h", uri.hostname or "localhost",
             "-p", str(uri.port or 5432), "-U", uri.username or "admin",
             "-F", "t", dbname],
            env=env, stdout=out, stderr=subprocess.PIPE,
        )
    if result.returncode != 0:
        if os.path.exists(backup_file):
            os.remove(backup_file)
        return "فشل إنشاء النسخة الاحتياطية: " + result.stderr.decode("utf-8", "replace")

    for old in sorted(glob.glob(os.path.join(backup_dir, "acc_*.tar")))[:-10]:
        try:
            os.remove(old)
        except Exception:
            pass

    response.headers["Content-Type"] = "application/x-tar"
    response.headers["Content-Disposition"] = (
        'attachment; filename="acc_%s.tar"' % stamp
    )
    return response.stream(open(backup_file, "rb"), chunk_size=10 ** 6)
