// ======================  ميزان المراجعة — منطق Vue 3  ======================

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../reports_trial_api/',
            settingApi: window.purl + '/../../setting_api/',

            branches: [],
            periods: [],

            filters: {
                branch: 0,
                period: 0,
                date_from: '',
                date_to: '',
                max_level: 0,
                hide_zero: false,
            },

            accounts: [],
            totals: null,
            branchInfo: null,
            periodInfo: null,
            apiDateFrom: '',
            apiDateTo: '',
            health: null,
            loading: false,
            _loadSeq: 0,
            now_str: new Date().toLocaleString('en-GB'),
        };
    },

    computed: {
        canQuery() {
            return this.filters.branch > 0 && this.filters.period > 0;
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            Promise.all([
                axios.get(this.settingApi + 'get_all_branchesA').then(r => r.data || []),
                axios.get(this.settingApi + 'get_all_account_periodsA').then(r => r.data || []),
            ]).then(([branches, periods]) => {
                self.branches = Array.isArray(branches) ? branches : [];
                self.periods = Array.isArray(periods) ? periods : [];
                // افتراضيات: الفرع الرئيسي + أحدث دورة مفتوحة
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.filters.branch = main.id;
                else if (self.branches.length === 1) self.filters.branch = self.branches[0].id;
                var openP = self.periods.find(p => Number(p.open_period) === 1);
                if (openP) {
                    self.filters.period = openP.id;
                    if (openP.start_date) self.filters.date_from = openP.start_date;
                    if (openP.end_date) self.filters.date_to = openP.end_date;
                }
                if (self.canQuery) self.reload();
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات الأولية' });
            });
        },

        reload() {
            if (!this.canQuery) return;
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            axios.post(this.api + 'trial_balance/', this.filters).then(res => {
                if (seq !== self._loadSeq) return;
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess });
                    self.accounts = []; self.totals = null;
                    self.branchInfo = null; self.periodInfo = null; self.health = null;
                } else {
                    self.accounts = d.accounts || [];
                    self.totals = d.totals || null;
                    self.branchInfo = d.branch || null;
                    self.periodInfo = d.period || null;
                    self.health = d.health || null;
                    self.apiDateFrom = d.date_from || '';
                    self.apiDateTo = d.date_to || '';
                }
            }).catch(() => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                self.accounts = []; self.totals = null;
            }).then(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        onFilterChange() { this.reload(); },

        onPeriodChange() {
            // اختيار دورة → ملء التاريخ بمدى الدورة
            if (this.filters.period > 0) {
                var p = this.periods.find(p => Number(p.id) === Number(this.filters.period));
                if (p) {
                    if (p.start_date) this.filters.date_from = p.start_date;
                    if (p.end_date) this.filters.date_to = p.end_date;
                }
            }
            this.reload();
        },

        resetToFullPeriod() {
            if (!this.periodInfo) return;
            this.filters.date_from = this.periodInfo.start_date || '';
            this.filters.date_to = this.periodInfo.end_date || '';
            this.reload();
        },

        printReport() {
            this.now_str = new Date().toLocaleString('en-GB');
            this.$nextTick(() => window.print());
        },

        exportExcel() {
            if (!this.accounts.length || !this.canQuery) return;
            // نبني URL بالفلاتر + format=xlsx ونفتحه — المتصفّح يتولّى التنزيل
            var params = new URLSearchParams();
            Object.keys(this.filters).forEach(k => {
                var v = this.filters[k];
                if (v !== '' && v !== null && v !== undefined) {
                    params.append(k, (typeof v === 'boolean') ? (v ? '1' : '0') : v);
                }
            });
            params.append('format', 'xlsx');
            window.open(this.api + 'trial_balance?' + params.toString(), '_blank');
        },

        exportCSV() {
            if (!this.accounts.length) return;
            var rows = [
                ['#', 'رقم الحساب', 'اسم الحساب', 'نوع', 'مستوى',
                 'افتتاحي مدين', 'افتتاحي دائن',
                 'حركة مدين', 'حركة دائن',
                 'ختامي مدين', 'ختامي دائن'],
            ];
            this.accounts.forEach((a, i) => {
                rows.push([
                    i + 1, a.account_no, a.account_name,
                    a.is_leaf ? 'فرعي' : 'رئيسي',
                    a.level,
                    a.open_debit_net, a.open_credit_net,
                    a.mov_debit, a.mov_credit,
                    a.close_debit_net, a.close_credit_net,
                ]);
            });
            if (this.totals) {
                rows.push(['', '', 'الإجمالي', '', '',
                           this.totals.open_debit, this.totals.open_credit,
                           this.totals.mov_debit, this.totals.mov_credit,
                           this.totals.close_debit, this.totals.close_credit]);
                rows.push(['', '', 'الفرق', '', '',
                           this.totals.open_diff, '',
                           this.totals.mov_diff, '',
                           this.totals.close_diff, '']);
            }
            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'trial_balance_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        fmt(n) { return fmtNumber(n); },

        // اظهار '—' للصفر، وإلا الرقم منسّقاً
        fmtCell(n) {
            var v = Number(n) || 0;
            if (v === 0) return '—';
            return fmtNumber(v);
        },
    },
});

var app = vueApp.mount('#app');
