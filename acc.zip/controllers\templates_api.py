# -*- coding: utf-8 -*-
# type: ignore
"""
templates_api — قوالب قيود اليومية المتكرّرة (Phase 3.6).

يحتاج جدول `journal_templates` (migrations_manual/002_journal_templates.sql).

مثال على lines_json:
[
  {"accounting_tree": 12, "debit": 5000, "credit": 0, "detail": "راتب أساسي", "cost_center": 1},
  {"accounting_tree": 33, "debit": 0,    "credit": 5000, "detail": "راتب أساسي", "cost_center": null}
]

Endpoints:
- list_templates              — قائمة القوالب النشطة (للاختيار من شاشة القيد)
- get_template/<id>           — تفاصيل قالب واحد
- save_template               — POST: name, description, lines (JSON)
- update_template             — POST: id, name, description, lines
- delete_template             — soft delete (is_active=False)
- increment_usage/<id>        — يزيد عدّاد الاستخدام (يُستدعى بعد تطبيق القالب)
"""

import json

import acc_responses as resp
import acc_schema


def _ensure_table():
    if not acc_schema.table_exists(db, 'journal_templates'):
        return response.json(acc_schema.missing_table_response(
            'journal_templates', migration='002'
        ))
    return None


def _validate_lines(lines):
    """فحص بنية lines قبل الحفظ."""
    if not isinstance(lines, list):
        return "الـ lines يجب أن تكون قائمة"
    if len(lines) < 2:
        return "القالب يحتاج سطرين على الأقل"
    total_d = 0.0
    total_c = 0.0
    for i, line in enumerate(lines, 1):
        if not isinstance(line, dict):
            return "السطر %d ليس بنية صحيحة" % i
        if not line.get("accounting_tree"):
            return "السطر %d بلا حساب" % i
        try:
            d = float(line.get("debit") or 0)
            c = float(line.get("credit") or 0)
        except Exception:
            return "السطر %d قيمة غير رقمية" % i
        if d < 0 or c < 0:
            return "السطر %d قيمة سالبة" % i
        if d > 0 and c > 0:
            return "السطر %d مدين ودائن معاً غير مسموح" % i
        if d == 0 and c == 0:
            return "السطر %d بدون مبلغ" % i
        total_d += d
        total_c += c
    # القالب نفسه لا يحتاج بالضرورة أن يكون متوازناً (المستخدم قد يعدّل المبالغ)
    # لكن نضع علم balanced للعرض
    return None


def _parse_lines(raw):
    """يحوّل raw (str أو list) إلى list. يرفع ValueError."""
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except Exception:
            raise ValueError("صيغة JSON غير صحيحة في lines")
    if isinstance(raw, list):
        return raw
    raise ValueError("lines يجب أن تكون قائمة أو سلسلة JSON")


@auth.requires(can_view)
def list_templates():
    """قائمة القوالب النشطة (مرتَّبة حسب الشعبية)."""
    guard = _ensure_table()
    if guard: return guard
    try:
        rows = db(
            (db.journal_templates.is_active == True)
        ).select(
            orderby=[~db.journal_templates.usage_count, db.journal_templates.name]
        )
        items = []
        for r in rows:
            try:
                lines = json.loads(r.lines_json or "[]")
                lines_count = len(lines) if isinstance(lines, list) else 0
            except Exception:
                lines_count = 0
            items.append({
                "id": int(r.id),
                "name": r.name,
                "description": r.description or "",
                "lines_count": lines_count,
                "usage_count": int(r.usage_count or 0),
            })
        return response.json(resp.ok(items=items, count=len(items)))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_view)
def get_template():
    """تفاصيل قالب — يُرجع الـ lines كاملةً مع enrichment بأسماء الحسابات."""
    guard = _ensure_table()
    if guard: return guard
    try:
        tid = int(request.args(0) or 0)
        rec = db.journal_templates[tid] if tid else None
        if not rec or not rec.is_active:
            return response.json(resp.not_found("القالب"))
        try:
            lines = json.loads(rec.lines_json or "[]")
        except Exception:
            lines = []
        # enrichment: اسم الحساب لكل سطر
        atree_ids = list({int(l.get("accounting_tree")) for l in lines
                         if l.get("accounting_tree")})
        atree_map = {}
        if atree_ids:
            for a in db(db.accounting_tree.id.belongs(atree_ids)).select(
                db.accounting_tree.id, db.accounting_tree.account_no,
                db.accounting_tree.account_name_ar
            ):
                atree_map[int(a.id)] = {
                    "account_no": a.account_no,
                    "account_name": a.account_name_ar or "",
                }
        enriched = []
        for l in lines:
            aid = int(l.get("accounting_tree") or 0)
            enriched.append({
                **l,
                "account_info": atree_map.get(aid),
            })
        return response.json(resp.ok(
            id=int(rec.id),
            name=rec.name,
            description=rec.description or "",
            lines=enriched,
            usage_count=int(rec.usage_count or 0),
        ))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_account)
def save_template():
    """حفظ قالب جديد. POST: name, description, lines (JSON or list)."""
    guard = _ensure_table()
    if guard: return guard
    try:
        v = request.vars
        name = (v.get("name") or "").strip()
        if not name:
            return response.json(resp.fail("اسم القالب مطلوب"))
        if len(name) > 150:
            return response.json(resp.fail("الاسم يتجاوز 150 حرفاً"))
        # تكرار
        dup = db(
            (db.journal_templates.name == name)
            & (db.journal_templates.is_active == True)
        ).count()
        if dup > 0:
            return response.json(resp.fail("يوجد قالب بنفس الاسم"))
        try:
            lines = _parse_lines(v.get("lines"))
        except ValueError as ve:
            return response.json(resp.fail(str(ve)))
        err = _validate_lines(lines)
        if err:
            return response.json(resp.fail(err))
        nid = db.journal_templates.insert(
            name=name,
            description=(v.get("description") or "")[:5000],
            lines_json=json.dumps(lines, ensure_ascii=False),
            usage_count=0,
            is_active=True,
        )
        db.commit()
        return response.json(resp.ok(id=nid))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_account)
def update_template():
    """تعديل قالب. POST: id, name, description, lines."""
    guard = _ensure_table()
    if guard: return guard
    try:
        v = request.vars
        tid = int(v.get("id") or 0)
        rec = db.journal_templates[tid] if tid else None
        if not rec or not rec.is_active:
            return response.json(resp.not_found("القالب"))
        name = (v.get("name") or "").strip()
        if not name:
            return response.json(resp.fail("اسم القالب مطلوب"))
        # تكرار (ما عدا نفسه)
        dup = db(
            (db.journal_templates.name == name)
            & (db.journal_templates.id != tid)
            & (db.journal_templates.is_active == True)
        ).count()
        if dup > 0:
            return response.json(resp.fail("يوجد قالب آخر بنفس الاسم"))
        try:
            lines = _parse_lines(v.get("lines"))
        except ValueError as ve:
            return response.json(resp.fail(str(ve)))
        err = _validate_lines(lines)
        if err:
            return response.json(resp.fail(err))
        rec.update_record(
            name=name,
            description=(v.get("description") or "")[:5000],
            lines_json=json.dumps(lines, ensure_ascii=False),
        )
        db.commit()
        return response.json(resp.ok(id=tid))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_admin)
def delete_template():
    """حذف ناعم — admin فقط (is_active=False)."""
    guard = _ensure_table()
    if guard: return guard
    try:
        tid = int(request.vars.get("id") or 0)
        rec = db.journal_templates[tid] if tid else None
        if not rec:
            return response.json(resp.not_found("القالب"))
        rec.update_record(is_active=False)
        db.commit()
        return response.json(resp.ok(id=tid))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_enter)
def increment_usage():
    """يزيد عدّاد الاستخدام — يُستدعى عند تطبيق القالب على قيد جديد."""
    guard = _ensure_table()
    if guard: return guard
    try:
        tid = int(request.args(0) or 0)
        rec = db.journal_templates[tid] if tid else None
        if not rec:
            return response.json(resp.not_found("القالب"))
        rec.update_record(usage_count=int(rec.usage_count or 0) + 1)
        db.commit()
        return response.json(resp.ok(usage_count=int(rec.usage_count or 0)))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))
