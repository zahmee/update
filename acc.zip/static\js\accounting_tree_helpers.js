// ======================  الشجرة المحاسبية — منطق Vue 3  ======================

// سجل حساب فارغ
function blankRow() {
    return {
        id: -1,
        branches: -1,
        account_periods: -1,
        account_no: '',
        account_name_ar: '',
        account_name_en: '',
        main_account: '0',
        account_type: 1,
        final_account: 1,
        show_account: 1,
        credit: 0,
        debit: 0,
    };
}

// توحيد سجل قادم من الخادم
function normalize(c) {
    return {
        id: Number(c.id),
        branches: Number(c.branches),
        account_periods: Number(c.account_periods),
        account_no: String(c.account_no || ''),
        account_name_ar: c.account_name_ar == null ? '' : String(c.account_name_ar),
        account_name_en: c.account_name_en == null ? '' : String(c.account_name_en),
        main_account: String(c.main_account || '0'),
        account_type: Number(c.account_type) || 1,
        final_account: Number(c.final_account) || 1,
        show_account: Number(c.show_account) === 2 ? 2 : 1,
        credit: Number(c.credit) || 0,
        debit: Number(c.debit) || 0,
    };
}

// بناء الشجرة من قائمة مسطّحة
function buildTree(flat) {
    var byNo = {};
    flat.forEach(function (r) {
        byNo[String(r.account_no)] = Object.assign({}, r, { children: [] });
    });
    var roots = [];
    flat.forEach(function (r) {
        var node = byNo[String(r.account_no)];
        var parentNo = String(r.main_account || '0');
        if (parentNo !== '0' && byNo[parentNo]) {
            byNo[parentNo].children.push(node);
        } else {
            roots.push(node);
        }
    });
    function sortNodes(nodes) {
        nodes.sort(compareAccountNo);
        nodes.forEach(function (n) { if (n.children.length) sortNodes(n.children); });
    }
    sortNodes(roots);
    return roots;
}

function compareAccountNo(a, b) {
    var an = String(a.account_no || '');
    var bn = String(b.account_no || '');
    var aN = parseFloat(an), bN = parseFloat(bn);
    if (!isNaN(aN) && !isNaN(bN) && aN !== bN) return aN - bN;
    return an.localeCompare(bn);
}

function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
}

function highlight(text, q) {
    if (!q) return escapeHtml(text);
    var t = String(text || '');
    var lower = t.toLowerCase();
    var lq = q.toLowerCase();
    var i = lower.indexOf(lq);
    if (i === -1) return escapeHtml(t);
    return escapeHtml(t.slice(0, i)) +
        '<mark>' + escapeHtml(t.slice(i, i + q.length)) + '</mark>' +
        escapeHtml(t.slice(i + q.length));
}

