# -*- coding: utf-8 -*-
"""
acc_responses — توحيد عقود JSON للـ APIs.

كل الـ APIs يجب أن ترجع شكلاً موحَّداً:
- نجاح: {"err": 0, ...data}
- فشل تحقُّق:  {"err": 1, "mess": "..."}
- فشل صلاحيات/شرط:  {"err": 2, "mess": "..."}
- خطأ تقني: {"err": 3, "mess": "..."}

ملاحظة: لا يستدعي web2py مباشرة — يرجع dict، والمتحكم يلفّه بـ
`response.json(...)`. هذا يبقي الـ module بلا اعتمادية على web2py
runtime (للاختبار).

استعمال نموذجي:
    from applications.acc.modules import acc_responses as resp
    return response.json(resp.ok(branch=branch_id))
    return response.json(resp.fail("الفرع غير موجود"))
    return response.json(resp.forbidden("الدورة مقفلة"))
    return response.json(resp.error(e))
"""


# رموز err الموحَّدة (للوضوح في الاستدعاء)
OK = 0
VALIDATION = 1
FORBIDDEN = 2
INTERNAL = 3


def ok(**data):
    """رد نجاح. يقبل أي بيانات إضافية ككلمات مفتاحية.
    مثال: ok(id=5, count=3) → {"err": 0, "id": 5, "count": 3}
    """
    out = {"err": OK}
    out.update(data)
    return out


def fail(message, code=VALIDATION, **extra):
    """رد فشل (مع رسالة المستخدم). الافتراضي خطأ تحقق (err=1)."""
    out = {"err": code, "mess": str(message)}
    out.update(extra)
    return out


def forbidden(message, **extra):
    """رد منع — صلاحيات أو شرط محاسبي (err=2)."""
    return fail(message, code=FORBIDDEN, **extra)


def not_found(what="السجل"):
    """رد العنصر غير موجود — حالة شائعة."""
    return fail("%s غير موجود" % what, code=VALIDATION)


def error(exc, fallback="حدث خطأ تقني"):
    """رد خطأ تقني — يستخدم str(exc) أو fallback (err=3).
    رسالة Exception أحياناً غير عربية؛ لذلك fallback أمان."""
    msg = str(exc) if exc and str(exc).strip() else fallback
    return {"err": INTERNAL, "mess": msg}
