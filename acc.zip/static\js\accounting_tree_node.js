function registerAccountingTreeNode(vueApp) {
    vueApp.component('acc-node', {
        props: {
            node: { type: Object, required: true },
            search: { type: String, default: '' },
            selectedId: { type: [Number, String], default: null },
            isAdmin: { type: Boolean, default: false },
            level: { type: Number, default: 0 },
            openTrigger: { type: Number, default: 0 },
            closeTrigger: { type: Number, default: 0 },
        },
        data() {
            return { open: (this.level || 0) < 2 };
        },
        computed: {
            hasChildren() { return this.node.children && this.node.children.length > 0; },
            isSelected() { return Number(this.node.id) === Number(this.selectedId); },
            isHidden() { return Number(this.node.show_account) !== 1; },
            matchesSearch() {
                var q = (this.search || '').toLowerCase().trim();
                if (!q) return true;
                var n = this.node;
                return ((n.account_no || '').toLowerCase().indexOf(q) !== -1)
                    || ((n.account_name_ar || '').toLowerCase().indexOf(q) !== -1)
                    || ((n.account_name_en || '').toLowerCase().indexOf(q) !== -1);
            },
            descendantMatches() {
                var q = (this.search || '').toLowerCase().trim();
                if (!q || !this.hasChildren) return false;
                function check(n) {
                    if (((n.account_no || '').toLowerCase().indexOf(q) !== -1) ||
                        ((n.account_name_ar || '').toLowerCase().indexOf(q) !== -1) ||
                        ((n.account_name_en || '').toLowerCase().indexOf(q) !== -1)) return true;
                    return (n.children || []).some(check);
                }
                return this.node.children.some(check);
            },
            shouldShow() {
                var q = (this.search || '').toLowerCase().trim();
                if (!q) return true;
                return this.matchesSearch || this.descendantMatches;
            },
            finalLabel() {
                var v = Number(this.node.final_account);
                return v === 1 ? 'ميزانية' : v === 2 ? 'أ/خ' : v === 3 ? 'متاجرة' : '';
            },
            finalClass() {
                var v = Number(this.node.final_account);
                return v === 1 ? 'is-fa-1' : v === 2 ? 'is-fa-2' : v === 3 ? 'is-fa-3' : '';
            },
            typeLabel() {
                var v = Number(this.node.account_type);
                return v === 1 ? 'دائن' : v === 2 ? 'مدين' : '';
            },
            nameHtml() { return highlight(this.node.account_name_ar, (this.search || '').trim()); },
            noHtml() { return highlight(this.node.account_no, (this.search || '').trim()); },
        },
        watch: {
            search(v) {
                if (v && this.descendantMatches) this.open = true;
            },
            openTrigger() { this.open = true; },
            closeTrigger() { this.open = false; },
        },
        methods: {
            toggle() { this.open = !this.open; },
            onSelect() { this.$emit('select', this.node); },
            onAddChild(e) { e.stopPropagation(); this.$emit('add-child', this.node); },
            onDelete(e) { e.stopPropagation(); this.$emit('delete', this.node); },
        },
        template: '' +
            '<div v-if="shouldShow" class="atn" :class="{ \'atn-dim\': !matchesSearch && descendantMatches }">' +
            '  <div class="atn-row"' +
            '       :class="{ \'is-selected\': isSelected, \'is-hidden-acc\': isHidden, \'is-leaf\': !hasChildren }"' +
            '       :style="{ \'--lvl\': (level||0) }"' +
            '       @click="onSelect">' +
            '    <span class="atn-twist" v-if="hasChildren" @click.stop="toggle">' +
            '      <i class="fas" :class="open ? \'fa-chevron-down\' : \'fa-chevron-left\'"></i>' +
            '    </span>' +
            '    <span class="atn-twist atn-twist-empty" v-else></span>' +
            '    <span class="atn-icon" :class="finalClass">' +
            '      <i class="fas" :class="hasChildren ? (open ? \'fa-folder-open\' : \'fa-folder\') : \'fa-receipt\'"></i>' +
            '    </span>' +
            '    <span class="atn-no" v-html="noHtml"></span>' +
            '    <span class="atn-name" v-html="nameHtml"></span>' +
            '    <span class="atn-spacer"></span>' +
            '    <span class="atn-badge" :class="finalClass" v-if="finalLabel">{{ finalLabel }}</span>' +
            '    <span class="atn-type" v-if="typeLabel">{{ typeLabel }}</span>' +
            '    <span class="atn-hidden-flag" v-if="isHidden" title="غير ظاهر في القوائم">' +
            '      <i class="fas fa-eye-slash"></i>' +
            '    </span>' +
            '    <div class="atn-actions no-print" v-if="isAdmin">' +
            '      <button type="button" @click="onAddChild" title="إضافة حساب فرعي">' +
            '        <i class="fas fa-plus"></i>' +
            '      </button>' +
            '      <button type="button" @click="onDelete" title="حذف">' +
            '        <i class="fas fa-trash-alt"></i>' +
            '      </button>' +
            '    </div>' +
            '  </div>' +
            '  <div v-if="hasChildren && open" class="atn-children">' +
            '    <acc-node' +
            '      v-for="c in node.children"' +
            '      :key="c.id"' +
            '      :node="c"' +
            '      :search="search"' +
            '      :selected-id="selectedId"' +
            '      :is-admin="isAdmin"' +
            '      :level="(level||0) + 1"' +
            '      :open-trigger="openTrigger"' +
            '      :close-trigger="closeTrigger"' +
            '      @select="$emit(\'select\', $event)"' +
            '      @add-child="$emit(\'add-child\', $event)"' +
            '      @delete="$emit(\'delete\', $event)">' +
            '    </acc-node>' +
            '  </div>' +
            '</div>',
    });
}
