// ======================  قيد يومية — منطق Vue 3  ======================
// نموذج العمل: قيد محاسبي مزدوج — ∑المدين = ∑الدائن، على دورة مالية مفتوحة
// تشمل تاريخ القيد. كل سطر إما مدين أو دائن (ليس كلاهما)، ولا قيمة سالبة.

var _rowKey = 0;

function blankRow() {
    _rowKey += 1;
    return {
        _key: _rowKey,
        account: null,
        debit: 0,
        credit: 0,
        detail: '',
        cost_center: 0,
    };
}

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function todayISO() {
    var d = new Date();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var dd = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + m + '-' + dd;
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../operations_api/',
            settingApi: window.purl + '/../../setting_api/',
            tplApi: window.purl + '/../../templates_api/',
            viewURL: window.viewURL,
            bootstrapped: false,
            branches: [],
            cost_centers: [],
            open_periods: [],
            today_period: null,
            accounts: [],
            loadingAccounts: false,
            saving: false,
            master: {
                branch: -1,
                journal_date: '',
                journal_save: '',
                journal_detail: '',
            },
            rows: [blankRow(), blankRow()],
            periodInfo: null,            // الدورة المكتشفة من التاريخ
            dateProbe: { checked: false, found: false },
            _dateAbort: null,
            // ===== Templates integration =====
            showTplPicker: false,
            showSaveAsTpl: false,
            templates: [],
            tplLoading: false,
            tplSearch: '',
            newTplName: '',
            newTplDesc: '',
            savingTpl: false,
        };
    },

    computed: {
        dateMin() {
            // أصغر تاريخ بداية في الدورات المفتوحة
            if (!this.open_periods.length) return '';
            return this.open_periods.reduce(function (acc, p) {
                return (!acc || (p.start_date && p.start_date < acc)) ? p.start_date : acc;
            }, '');
        },
        dateMax() {
            if (!this.open_periods.length) return '';
            return this.open_periods.reduce(function (acc, p) {
                return (!acc || (p.end_date && p.end_date > acc)) ? p.end_date : acc;
            }, '');
        },
        totals() {
            var d = 0, c = 0;
            this.rows.forEach(r => {
                d += Number(r.debit) || 0;
                c += Number(r.credit) || 0;
            });
            d = Math.round(d * 100) / 100;
            c = Math.round(c * 100) / 100;
            var diff = Math.round((d - c) * 100) / 100;
            return {
                debit: d, credit: c, diff: diff,
                balanced: Math.abs(diff) < 0.005 && d > 0,
            };
        },
        validRows() {
            // سطور لها حساب + قيمة على جانب واحد
            return this.rows.filter(r => {
                if (!r.account) return false;
                var d = Number(r.debit) || 0;
                var c = Number(r.credit) || 0;
                if (d > 0 && c > 0) return false;
                if (d === 0 && c === 0) return false;
                return true;
            });
        },
        lastUsedAccount() {
            for (var i = this.rows.length - 1; i >= 0; i--) {
                if (this.rows[i].account) return this.rows[i].account;
            }
            return null;
        },
        canSave() {
            if (this.saving) return false;
            if (this.master.branch <= 0) return false;
            if (!this.master.journal_date) return false;
            if (!this.master.journal_detail.trim()) return false;
            if (!this.periodInfo || this.periodInfo.open_period !== 1) return false;
            if (this.validRows.length < 2) return false;
            if (this.validRows.length !== this.rows.length) return false; // كل السطور سليمة
            if (!this.totals.balanced) return false;
            return true;
        },
        filteredTemplates() {
            var q = (this.tplSearch || '').trim().toLowerCase();
            if (!q) return this.templates;
            return this.templates.filter(t =>
                (t.name || '').toLowerCase().includes(q) ||
                (t.description || '').toLowerCase().includes(q));
        },
        savePreview() {
            // رسالة توضح سبب تعطيل الحفظ
            if (this.master.branch <= 0) return 'اختر الفرع';
            if (!this.master.journal_date) return 'أدخل تاريخ القيد';
            if (!this.periodInfo) return 'التاريخ خارج الدورات المالية';
            if (this.periodInfo.open_period !== 1) return 'الدورة المختارة مقفلة';
            if (!this.master.journal_detail.trim()) return 'أدخل البيان الإجمالي';
            // السطور
            if (this.rows.length < 2) return 'أضف سطرين على الأقل';
            // أي سطر بلا حساب أو فيه خلل
            for (var i = 0; i < this.rows.length; i++) {
                var r = this.rows[i];
                if (!r.account) return 'السطر ' + (i+1) + ' بلا حساب';
                var d = Number(r.debit) || 0, c = Number(r.credit) || 0;
                if (d === 0 && c === 0) return 'السطر ' + (i+1) + ' بلا قيمة';
                if (d > 0 && c > 0) return 'السطر ' + (i+1) + ': مدين ودائن معاً';
            }
            if (!this.totals.balanced) return 'القيد غير متوازن — الفرق: ' + fmtNumber(this.totals.diff);
            return '';
        },
    },

    created() { this.bootstrap(); },

    mounted() {
        window.addEventListener('beforeunload', this._bu = (e) => {
            if (this.hasUnsavedWork()) { e.preventDefault(); e.returnValue = ''; }
        });
        window.addEventListener('keydown', this._key = (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                if (this.canSave) this.saveJournal();
            }
        });
    },
    unmounted() {
        window.removeEventListener('beforeunload', this._bu);
        window.removeEventListener('keydown', this._key);
    },

    methods: {
        bootstrap() {
            var self = this;
            axios.get(this.api + 'get_journal_bootstrap').then(res => {
                var d = res.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess || 'خطأ' });
                    return;
                }
                self.branches = d.branches || [];
                self.cost_centers = d.cost_centers || [];
                self.open_periods = d.open_periods || [];
                self.today_period = d.today_period || null;
                // افتراضي: الفرع الرئيسي
                var main = self.branches.find(b => Number(b.is_main) === 1);
                if (main) self.master.branch = main.id;
                else if (self.branches.length === 1) self.master.branch = self.branches[0].id;
                // افتراضي: تاريخ اليوم إن وقع في دورة مفتوحة
                if (d.today_period) {
                    self.master.journal_date = d.today;
                } else if (self.open_periods.length) {
                    // اختر بداية أحدث دورة مفتوحة
                    var p = self.open_periods[self.open_periods.length - 1];
                    self.master.journal_date = p.start_date || '';
                }
                self.bootstrapped = true;
                if (self.master.branch > 0) self.loadAccounts();
                if (self.master.journal_date) self.probeDate();
            }).catch(() => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            });
        },

        loadAccounts() {
            if (!(this.master.branch > 0)) { this.accounts = []; return; }
            var self = this;
            this.loadingAccounts = true;
            // نمرر period إن وُجدت لتجنب الالتباس
            var url = this.api + 'get_accounts_for_journal/' + this.master.branch;
            if (this.periodInfo && this.periodInfo.id) url += '/' + this.periodInfo.id;
            axios.get(url).then(res => {
                var d = res.data || {};
                if (d.err) {
                    self.accounts = [];
                    Swal.fire({ icon: 'error', title: 'تعذّر تحميل الحسابات', text: d.mess });
                } else {
                    self.accounts = d.accounts || [];
                }
            }).catch(() => {
                self.accounts = [];
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل الحسابات' });
            }).then(() => { self.loadingAccounts = false; });
        },

        onBranchChange() {
            if (this.rows.some(r => r.account)) {
                // لا يفترض الوصول لهنا (الـ select معطّل)، لكن للأمان
                return;
            }
            this.loadAccounts();
        },

        onDateChange() {
            this.probeDate();
        },

        probeDate() {
            var self = this;
            this.periodInfo = null;
            this.dateProbe = { checked: false, found: false };
            if (!this.master.journal_date) return;
            axios.get(this.settingApi + 'get_period_for_date',
                      { params: { d: this.master.journal_date } })
                .then(res => {
                    var d = res.data || {};
                    self.dateProbe.checked = true;
                    if (d.err) {
                        self.dateProbe.found = false;
                        self.periodInfo = null;
                    } else {
                        self.dateProbe.found = true;
                        self.periodInfo = d;
                        // إعادة تحميل الحسابات إن تغيّرت الدورة
                        self.loadAccounts();
                    }
                }).catch(() => {
                    self.dateProbe = { checked: true, found: false };
                    self.periodInfo = null;
                });
        },

        addRow() {
            this.rows.push(blankRow());
        },

        removeRow(i) {
            if (this.rows.length <= 1) return;
            this.rows.splice(i, 1);
        },

        duplicateLastRow() {
            var last = null;
            for (var i = this.rows.length - 1; i >= 0; i--) {
                if (this.rows[i].account) { last = this.rows[i]; break; }
            }
            if (!last) return;
            var nr = blankRow();
            nr.account = last.account;
            nr.detail = last.detail;
            nr.cost_center = last.cost_center;
            this.rows.push(nr);
        },

        onAccountSelected(r, acc) {
            // لا شيء حالياً — نحتفظ بـ hook لأنماط لاحقة (auto-fill cost center مثلاً)
        },

        // وضع القائمة المنسدلة لـ vue-select خارج الجدول المقطوع (append-to-body)
        // يحسب الموضع بناءً على الزر، ويستخدم عرضاً أوسع قليلاً لإظهار اسم الأب
        withPopper(dropdownList, component, { width }) {
            var toggle = component.$refs.toggle;
            if (!toggle) return function () {};
            var update = function () {
                var rect = toggle.getBoundingClientRect();
                var minWidth = Math.max(parseFloat(width) || 0, 380);
                dropdownList.style.position = 'absolute';
                dropdownList.style.top = (rect.bottom + window.scrollY + 2) + 'px';
                dropdownList.style.left = (rect.left + window.scrollX) + 'px';
                dropdownList.style.width = minWidth + 'px';
                dropdownList.style.maxHeight = '320px';
                dropdownList.style.overflowY = 'auto';
                dropdownList.style.zIndex = 9999;
                dropdownList.style.background = '#fff';
                dropdownList.style.border = '1px solid var(--line-2, #d6d6d6)';
                dropdownList.style.borderRadius = '8px';
                dropdownList.style.boxShadow = '0 8px 24px rgba(0,0,0,0.12)';
            };
            update();
            window.addEventListener('scroll', update, true);
            window.addEventListener('resize', update);
            return function () {
                window.removeEventListener('scroll', update, true);
                window.removeEventListener('resize', update);
            };
        },

        onAmountInput(r) {
            // منع السالب محلياً
            if ((Number(r.debit) || 0) < 0) r.debit = 0;
            if ((Number(r.credit) || 0) < 0) r.credit = 0;
        },

        faLabel(v) {
            v = Number(v);
            return v === 1 ? 'ميزانية' : v === 2 ? 'أ/خ' : v === 3 ? 'متاجرة' : '';
        },

        fmt(n) { return fmtNumber(n); },

        hasUnsavedWork() {
            return this.master.journal_detail.trim() !== '' ||
                   this.rows.some(r => r.account || Number(r.debit) > 0 || Number(r.credit) > 0);
        },

        resetForm() {
            var self = this;
            if (!this.hasUnsavedWork()) { this._resetSilent(); return; }
            Swal.fire({
                icon: 'warning',
                title: 'مسح القيد الحالي',
                text: 'سيتم فقدان كل ما أدخلته. متابعة؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، امسح',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(r => { if (r.isConfirmed) self._resetSilent(); });
        },

        _resetSilent() {
            this.master.journal_save = '';
            this.master.journal_detail = '';
            this.rows = [blankRow(), blankRow()];
            // نُبقي الفرع والتاريخ — مفيد لإدخال قيود متتابعة
        },

        // ===================== Templates =====================
        openTemplatePicker() {
            var self = this;
            this.showTplPicker = true;
            this.tplLoading = true;
            this.tplSearch = '';
            axios.get(this.tplApi + 'list_templates').then(res => {
                var d = res.data || {};
                if (d.err === 0) {
                    self.templates = d.items || [];
                } else {
                    self.templates = [];
                    Swal.fire({ icon: 'error', title: 'تعذّر تحميل القوالب',
                                text: d.mess || '' });
                }
            }).catch(() => {
                self.templates = [];
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
            }).then(() => { self.tplLoading = false; });
        },

        applyTemplate(t) {
            var self = this;
            // إن كان فيه بيانات حالية، اطلب تأكيد
            var doApply = function () {
                axios.get(self.tplApi + 'get_template/' + t.id).then(res => {
                    var d = res.data || {};
                    if (d.err !== 0) {
                        Swal.fire({ icon: 'error', title: 'تعذّر تحميل القالب',
                                    text: d.mess || '' });
                        return;
                    }
                    self._fillRowsFromTemplate(d);
                    self.showTplPicker = false;
                    // عدّاد الاستخدام (لا ننتظر)
                    var fd = new FormData();
                    axios.post(self.tplApi + 'increment_usage/' + t.id, fd).catch(() => {});
                });
            };
            if (this.hasUnsavedWork()) {
                Swal.fire({
                    icon: 'warning',
                    title: 'استبدال السطور الحالية',
                    text: 'سيُحلّ القالب محل السطور المُدخَلة. متابعة؟',
                    showCancelButton: true,
                    confirmButtonText: 'نعم، استبدِل',
                    cancelButtonText: 'إلغاء',
                    confirmButtonColor: '#d33',
                }).then(r => { if (r.isConfirmed) doApply(); });
            } else {
                doApply();
            }
        },

        _fillRowsFromTemplate(tpl) {
            var self = this;
            var missing = [];
            var newRows = [];
            (tpl.lines || []).forEach(function (l) {
                var acc = null;
                var info = l.account_info || null;
                // تطابق بحسب account_no (مرن عبر الفترات) ثم بحسب id كاحتياط
                if (info && info.account_no) {
                    acc = self.accounts.find(a => a.account_no === info.account_no);
                }
                if (!acc && l.accounting_tree) {
                    acc = self.accounts.find(a => a.id === Number(l.accounting_tree));
                }
                if (!acc) {
                    missing.push(info && info.account_no ?
                                 (info.account_no + ' — ' + (info.account_name || ''))
                                 : ('#' + l.accounting_tree));
                    return; // تخطّى السطر — لا حساب مطابق
                }
                var nr = blankRow();
                nr.account = acc;
                nr.debit = Number(l.debit) || 0;
                nr.credit = Number(l.credit) || 0;
                nr.detail = l.detail || '';
                nr.cost_center = Number(l.cost_center) || 0;
                newRows.push(nr);
            });
            if (!newRows.length) {
                Swal.fire({ icon: 'error', title: 'لا يمكن تطبيق القالب',
                            html: 'لا يوجد أي حساب من القالب في الشجرة الحالية.<br>' +
                                  'أنشئ الحسابات أو راجع القالب.' });
                return;
            }
            // ضع البيان الإجمالي من اسم القالب إن لم يكن المستخدم كتب شيئاً
            if (!self.master.journal_detail.trim()) {
                self.master.journal_detail = tpl.name || '';
            }
            self.rows = newRows;
            if (missing.length) {
                Swal.fire({
                    icon: 'info',
                    title: 'تم التطبيق مع تخطي بعض السطور',
                    html: 'لم تُوجَد ' + missing.length + ' حساب في الشجرة الحالية:<br>' +
                          '<ul style="text-align:start; max-height:160px; overflow:auto;">' +
                          missing.map(m => '<li>' + m + '</li>').join('') + '</ul>',
                    timer: 6000,
                    timerProgressBar: true,
                });
            } else {
                Swal.fire({
                    icon: 'success', title: 'تم تطبيق القالب',
                    text: 'تحقّق من المبالغ والتاريخ قبل الحفظ.',
                    toast: true, position: 'top-end',
                    showConfirmButton: false, timer: 2500,
                });
            }
        },

        openSaveAsTemplate() {
            if (this.validRows.length < 2 || !this.totals.balanced) return;
            this.newTplName = (this.master.journal_detail || '').trim().slice(0, 80);
            this.newTplDesc = '';
            this.showSaveAsTpl = true;
            this.$nextTick(() => {
                if (this.$refs.newTplInput) this.$refs.newTplInput.focus();
            });
        },

        confirmSaveAsTemplate() {
            var self = this;
            var name = (this.newTplName || '').trim();
            if (!name) return;
            var lines = this.validRows.map(r => ({
                accounting_tree: r.account.id,
                debit: Number(r.debit) || 0,
                credit: Number(r.credit) || 0,
                detail: (r.detail || '').trim(),
                cost_center: Number(r.cost_center) || 0,
            }));
            this.savingTpl = true;
            axios.post(this.tplApi + 'save_template', {
                name: name,
                description: (this.newTplDesc || '').trim(),
                lines: lines,
            }).then(res => {
                var d = res.data || {};
                if (d.err === 0) {
                    self.showSaveAsTpl = false;
                    Swal.fire({
                        icon: 'success', title: 'حُفظ القالب',
                        text: 'تستطيع استخدامه لاحقاً من زر "من قالب".',
                        toast: true, position: 'top-end',
                        showConfirmButton: false, timer: 2500,
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ',
                                text: d.mess || '' });
                }
            }).catch(err => {
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال',
                            text: (err && err.message) || '' });
            }).then(() => { self.savingTpl = false; });
        },

        saveJournal() {
            if (!this.canSave) return;
            var self = this;
            // تحقّق محلي: cost_center يجب أن يكون ضمن قائمة المراكز المتاحة
            // (Fix 2026-05-26: يمنع رفض الخادم بعد الإرسال + رسالة واضحة)
            var validCcIds = this.cost_centers.map(c => c.id);
            for (var i = 0; i < this.rows.length; i++) {
                var cc = Number(this.rows[i].cost_center) || 0;
                if (cc > 0 && validCcIds.indexOf(cc) === -1) {
                    Swal.fire({
                        icon: 'error',
                        title: 'مركز تكلفة غير صالح',
                        text: 'السطر ' + (i + 1) + ': مركز التكلفة غير ضمن المراكز المتاحة. اختره من القائمة.',
                    });
                    return;
                }
            }
            // البناء بنفس عقد save_journal القديم (للتوافق)
            var detail = this.rows.map(r => ({
                branches: this.master.branch,
                debit: Number(r.debit) || 0,
                credit: Number(r.credit) || 0,
                detail: (r.detail || '').trim(),
                account: r.account.account_no,
                accounting_tree: r.account.id,
                cost_center: Number(r.cost_center) || 0,
            }));
            var payload = {
                master: {
                    branches: this.master.branch,
                    journal_date: this.master.journal_date,
                    journal_save: (this.master.journal_save || '').trim(),
                    journal_detail: this.master.journal_detail.trim(),
                    debit_total: this.totals.debit,
                    credit_total: this.totals.credit,
                    journal_operations: detail.length,
                },
                detail: detail,
            };
            this.saving = true;
            axios.post(this.api + 'save_journal/', payload).then(res => {
                var d = res.data || {};
                if (d.id && d.id > 0) {
                    Swal.fire({
                        icon: 'success',
                        title: 'تم حفظ القيد',
                        html: 'رقم القيد: <b>' + d.id + '</b><br>المدين/الدائن: <b>' + fmtNumber(self.totals.debit) + '</b>',
                        showDenyButton: true,
                        confirmButtonText: 'قيد جديد',
                        denyButtonText: 'استعراض القيد',
                        timer: 5000,
                        timerProgressBar: true,
                    }).then(rr => {
                        if (rr.isDenied) {
                            window.location.href = self.URL + '/../journal_entry_print/' + d.id;
                        } else {
                            self._resetSilent();
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'تعذّر الحفظ',
                        text: d.mess || 'حدث خطأ غير متوقع',
                    });
                }
            }).catch(err => {
                Swal.fire({
                    icon: 'error',
                    title: 'تعذّر الاتصال بالخادم',
                    text: (err && err.message) || '',
                });
            }).then(() => { self.saving = false; });
        },
    },
});

vueApp.component('v-select', window['vue-select']);
var app = vueApp.mount('#app');
