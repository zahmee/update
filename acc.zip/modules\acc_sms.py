# -*- coding: utf-8 -*-
"""SMS helpers for password reset and notifications."""

import json
import re
import urllib.error
import urllib.request


_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def normalize_mobile(value, default_country="966"):
    """Return a gateway-friendly digit-only mobile number."""
    raw = (value or "").strip().translate(_AR_DIGITS)
    digits = re.sub(r"\D+", "", raw)
    if digits.startswith("00"):
        digits = digits[2:]
    if digits.startswith("0") and len(digits) == 10:
        return default_country + digits[1:]
    if digits.startswith("5") and len(digits) == 9:
        return default_country + digits
    return digits


def is_plausible_mobile(value):
    mobile = normalize_mobile(value)
    return bool(re.match(r"^9665\d{8}$", mobile) or re.match(r"^05\d{8}$", value or ""))


def mask_mobile(value):
    mobile = normalize_mobile(value)
    if len(mobile) < 4:
        return "****"
    return "*" * max(0, len(mobile) - 4) + mobile[-4:]


def send_oursms(authorization, sender, mobile, message, timeout=10):
    """Send an SMS through oursms.com using the same payload shape as asbab5."""
    if not authorization:
        return {"ok": False, "status": None, "body": "SMS authorization is missing"}
    if not sender:
        return {"ok": False, "status": None, "body": "SMS sender is missing"}
    dest = normalize_mobile(mobile)
    if not dest:
        return {"ok": False, "status": None, "body": "mobile is missing"}

    payload = {
        "src": sender,
        "dests": [dest],
        "body": message,
        "priority": 0,
        "delay": 0,
        "validity": 0,
        "maxParts": 0,
        "dlr": 0,
        "prevDups": 0,
        "msgClass": "promotional",
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "https://api.oursms.com/msgs/sms",
        data=data,
        headers={
            "Authorization": "Bearer " + authorization,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", "replace")
            return {"ok": 200 <= resp.status < 300, "status": resp.status, "body": body}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        return {"ok": False, "status": e.code, "body": body}
    except Exception as e:
        return {"ok": False, "status": None, "body": str(e)}
