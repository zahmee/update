// ======================  مكتب قيود اليومية — منطق Vue 3  ======================
// شاشة موحَّدة لعرض القيود مع فلترة شاملة (فرع، دورة، تاريخ، نص)،
// إحصائيات حيّة، إجراءات (عرض/تعديل/حذف)، تصدير CSV، pagination.

function fmtNumber(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// قراءة query string بسيطة (?branch=N&period=M&…)
function readQS() {
    var qs = (window.location.search || '').replace(/^\?/, '');
    var out = {};
    qs.split('&').forEach(function (kv) {
        if (!kv) return;
        var p = kv.split('=');
        out[decodeURIComponent(p[0] || '')] = decodeURIComponent(p[1] || '');
    });
    return out;
}

var vueApp = Vue.createApp({
    data() {
        var qs = readQS();
        return {
            URL: window.purl,
            api: window.purl + '/../../operations_api/',
            settingApi: window.purl + '/../../setting_api/',
            newURL: window.purlNew,
            printURL: window.purlPrint,
            editURL: window.purlEdit,
            isAdmin: !!window.isAdmin,

            branches: [],
            periods: [],
            items: [],
            stats: null,
            total: 0,
            totalPages: 1,
            loading: true,

            filters: {
                branch: Number(qs.branch) || 0,
                period: Number(qs.period) || 0,
                date_from: qs.date_from || '',
                date_to: qs.date_to || '',
                q: qs.q || '',
                include_deleted: false,
                page: 1,
                per_page: 25,
            },
            _searchT: null,
            _loadSeq: 0,
        };
    },

    computed: {
        hasActiveFilters() {
            return this.filters.branch > 0
                || this.filters.period > 0
                || !!this.filters.date_from
                || !!this.filters.date_to
                || !!this.filters.q
                || this.filters.include_deleted;
        },
        visiblePages() {
            // أرقام صفحات قابلة للضغط حول الصفحة الحالية (نافذة ±3)
            var p = this.filters.page;
            var n = this.totalPages;
            var s = Math.max(1, p - 3);
            var e = Math.min(n, p + 3);
            var out = [];
            for (var i = s; i <= e; i++) out.push(i);
            return out;
        },
    },

    created() { this.bootstrap(); },

    methods: {
        bootstrap() {
            var self = this;
            // الفروع
            axios.get(this.settingApi + 'get_all_branchesA').then(r => {
                self.branches = Array.isArray(r.data) ? r.data : [];
            }).catch(() => {});
            // الدورات
            axios.get(this.settingApi + 'get_all_account_periodsA').then(r => {
                self.periods = Array.isArray(r.data) ? r.data : [];
            }).catch(() => {});
            // تحميل أوّلي
            this.reload();
        },

        reload() {
            var self = this;
            var seq = ++this._loadSeq;
            this.loading = true;
            // الإحصائيات + القائمة بالتوازي
            Promise.all([
                axios.get(this.api + 'list_journals', { params: this._filterParams() }),
                axios.get(this.api + 'list_journals_stats', { params: this._filterParams(true) }),
            ]).then(([listRes, statsRes]) => {
                if (seq !== self._loadSeq) return; // تجاوزه طلب أحدث
                var d = listRes.data || {};
                if (d.err) {
                    Swal.fire({ icon: 'error', title: 'تعذّر التحميل', text: d.mess });
                    self.items = []; self.total = 0; self.totalPages = 1;
                } else {
                    self.items = d.items || [];
                    self.total = d.total || 0;
                    self.totalPages = d.pages || 1;
                    if (self.filters.page > self.totalPages) {
                        self.filters.page = self.totalPages || 1;
                    }
                }
                var s = statsRes.data || {};
                self.stats = s.err ? null : s;
            }).catch(() => {
                if (seq !== self._loadSeq) return;
                Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                self.items = []; self.stats = null;
            }).then(() => {
                if (seq === self._loadSeq) self.loading = false;
            });
        },

        _filterParams(forStats) {
            var p = {
                branch: this.filters.branch || 0,
                period: this.filters.period || 0,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || '',
                q: this.filters.q || '',
                include_deleted: this.filters.include_deleted ? '1' : '',
            };
            if (!forStats) {
                p.page = this.filters.page;
                p.per_page = this.filters.per_page;
            }
            return p;
        },

        onFilterChange() {
            this.filters.page = 1;
            this.reload();
        },

        onSearchInput() {
            // debounce 300ms
            var self = this;
            if (this._searchT) clearTimeout(this._searchT);
            this._searchT = setTimeout(() => { self.onFilterChange(); }, 300);
        },

        clearFilters() {
            this.filters.branch = 0;
            this.filters.period = 0;
            this.filters.date_from = '';
            this.filters.date_to = '';
            this.filters.q = '';
            this.filters.include_deleted = false;
            this.filters.page = 1;
            this.reload();
        },

        goToPage(p) {
            p = Math.max(1, Math.min(this.totalPages, Number(p) || 1));
            if (p === this.filters.page) return;
            this.filters.page = p;
            this.reload();
        },

        openPrint(r) {
            window.open(this.printURL + '/' + r.id, '_blank');
        },

        openEdit(r) {
            if (!this.isAdmin) return;
            if (!r.is_active) {
                Swal.fire({ icon: 'info', title: 'القيد محذوف', text: 'لا يمكن تعديل قيد محذوف.' });
                return;
            }
            if (r.period_open !== 1) {
                Swal.fire({ icon: 'warning', title: 'الدورة مقفلة',
                            text: 'لا يمكن تعديل قيد في دورة مالية مقفلة.' });
                return;
            }
            window.location.href = this.editURL + '/' + r.id;
        },

        deleteJournal(r) {
            if (!this.isAdmin) return;
            if (!r.is_active) {
                Swal.fire({ icon: 'info', title: 'القيد محذوف مسبقاً' });
                return;
            }
            if (r.period_open !== 1) {
                Swal.fire({ icon: 'warning', title: 'الدورة مقفلة',
                            text: 'لا يمكن حذف قيد في دورة مالية مقفلة.' });
                return;
            }
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'حذف قيد اليومية',
                html: 'سيتم حذف قيد رقم <b>' + r.id + '</b> (حذف ناعم — يبقى الرأس في السجل).<br>' +
                      '<small>المبلغ: ' + fmtNumber(r.debit_total) + '</small>',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
            }).then(result => {
                if (!result.isConfirmed) return;
                axios.post(self.api + 'soft_delete_journal/', { id: r.id }).then(res => {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        Swal.fire({ icon: 'success', title: 'تم الحذف',
                                    timer: 1400, showConfirmButton: false });
                        self.reload();
                    } else {
                        Swal.fire({ icon: 'error', title: 'تعذّر الحذف', text: d.mess || 'حدث خطأ' });
                    }
                }).catch(() => {
                    Swal.fire({ icon: 'error', title: 'تعذّر الاتصال بالخادم' });
                });
            });
        },

        editTitle(r) {
            if (!r.is_active) return 'القيد محذوف';
            if (r.period_open !== 1) return 'الدورة مقفلة';
            return 'تعديل';
        },

        deleteTitle(r) {
            if (!r.is_active) return 'محذوف مسبقاً';
            if (r.period_open !== 1) return 'الدورة مقفلة — لا يمكن الحذف';
            return 'حذف';
        },

        exportCSV() {
            if (!this.items.length) return;
            var rows = [
                ['#', 'التاريخ', 'الفرع', 'الدورة', 'البيان', 'رقم الحفظ',
                 'عدد العمليات', 'مدين', 'دائن', 'الحالة'],
            ];
            this.items.forEach(r => {
                rows.push([
                    r.id, r.journal_date, r.branch_name, r.period_disc,
                    r.journal_detail, r.journal_save,
                    r.journal_operations, r.debit_total, r.credit_total,
                    r.is_active ? 'نشط' : 'محذوف',
                ]);
            });
            var csv = rows.map(row => row.map(cell => {
                var s = String(cell == null ? '' : cell);
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s.replace(/"/g, '""') + '"';
                }
                return s;
            }).join(',')).join('\n');
            // BOM لتمييز UTF-8 في Excel
            var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            var stamp = new Date().toISOString().slice(0, 10);
            a.download = 'journals_' + stamp + '.csv';
            document.body.appendChild(a); a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },

        fmt(n) { return fmtNumber(n); },
    },
});

var app = vueApp.mount('#app');
