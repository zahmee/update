# -*- coding: utf-8 -*-
# type: ignore
"""
setting_tree_api — شجرة الحسابات (Accounting Tree) + استيراد + استنساخ.

استُخرج من setting_api.py في Phase 2.3 (2026-05-25).
"""

import json
import os
import re

import acc_tree_import


_ACCOUNT_NO_RE = re.compile(r"^[0-9]{1,15}$")
_VALID_ACCOUNT_TYPES = (1, 2)
_VALID_FINAL_ACCOUNTS = (1, 2, 3)


def _validate_account_payload(row):
    acc_no = str(row.get("account_no") or "").strip()
    ar = (row.get("account_name_ar") or "").strip()
    main = str(row.get("main_account") or "0").strip()
    if not acc_no:
        return "رقم الحساب مطلوب"
    if not _ACCOUNT_NO_RE.match(acc_no):
        return "رقم الحساب يجب أن يكون أرقاماً فقط وبحد أقصى 15 رقماً"
    if main and main != "0" and not _ACCOUNT_NO_RE.match(main):
        return "رقم الحساب الرئيسي غير صحيح"
    if not ar:
        return "اسم الحساب (عربي) مطلوب"
    if len(ar) < 3:
        return "اسم الحساب يجب ألا يقل عن 3 أحرف"
    try:
        account_type = int(row.get("account_type") or 0)
        final_account = int(row.get("final_account") or 0)
    except Exception:
        return "تصنيف الحساب غير صحيح"
    if account_type not in _VALID_ACCOUNT_TYPES:
        return "طبيعة الحساب غير صحيحة"
    if final_account not in _VALID_FINAL_ACCOUNTS:
        return "الحساب الختامي غير صحيح"
    return None


def _resolve_account_level(branch, period, main_account, seen=None):
    """يحسب مستوى الحساب من علاقة الأب داخل نفس الفرع والدورة."""
    main = str(main_account or "0").strip()
    if not main or main == "0":
        return 1
    seen = seen or set()
    if main in seen:
        return None
    seen.add(main)
    parent = db(
        (db.accounting_tree.branches == branch)
        & (db.accounting_tree.account_periods == period)
        & (db.accounting_tree.account_no == main)
    ).select(db.accounting_tree.account_level, db.accounting_tree.main_account).first()
    if not parent:
        return None
    if parent.account_level:
        return int(parent.account_level) + 1
    parent_level = _resolve_account_level(branch, period, parent.main_account, seen)
    return parent_level + 1 if parent_level else None


def _insert_tree_rows(raw_rows, branch, period):
    """Validate and insert imported chart rows into one branch/period."""
    try:
        branch = int(branch)
        period = int(period)
    except Exception:
        return {"err": 1, "id": 0, "mess": "الفرع أو الدورة غير محددين."}
    if not db.branches[branch]:
        return {"err": 1, "id": 0, "mess": "الفرع المحدد غير موجود."}
    if not db.account_periods[period]:
        return {"err": 1, "id": 0, "mess": "الدورة المحددة غير موجودة."}

    rows = acc_tree_import.normalize_chart_rows(raw_rows)
    err = acc_tree_import.validate_chart_rows(rows)
    if err:
        return {"err": 1, "id": 0, "mess": err}

    account_nos = [r["account_no"] for r in rows]
    existing = db(
        (db.accounting_tree.branches == branch)
        & (db.accounting_tree.account_periods == period)
        & (db.accounting_tree.account_no.belongs(account_nos))
    ).select(
        db.accounting_tree.account_no,
        limitby=(0, 6),
        orderby=db.accounting_tree.account_no,
    )
    existing_nos = set([str(r.account_no) for r in existing])

    count = 0
    skipped = 0
    for row in acc_tree_import.sort_chart_rows(rows):
        if row["account_no"] in existing_nos:
            skipped += 1
            continue
        main = row["main_account"]
        level = 1 if main == "0" else _resolve_account_level(branch, period, main)
        if not level:
            db.rollback()
            return {
                "err": 1,
                "id": 0,
                "mess": "الحساب الرئيسي «%s» غير موجود." % main,
            }
        db.accounting_tree.insert(
            branches=branch,
            account_periods=period,
            account_no=row["account_no"],
            account_name_ar=row["account_name_ar"],
            account_name_en=row["account_name_en"],
            main_account=main,
            account_level=level,
            account_type=row["account_type"],
            final_account=row["final_account"],
            show_account=row["show_account"],
            credit=0,
            debit=0,
        )
        count += 1
    db.commit()
    total = db(
        (db.accounting_tree.branches == branch)
        & (db.accounting_tree.account_periods == period)
    ).count()
    return {"err": 0, "mess": "0", "count": count, "skipped": skipped, "conut": total}


@auth.requires(can_view)
def get_accounting_tree():
    """شجرة الحسابات لفرع ودورة (يعرض اسم الأصل في كل سطر فرعي)."""
    if request.args(1):
        per = request.args(1)
    else:
        per = (
            db(db.account_periods.open_period == 1)
            .select(orderby=db.account_periods.id)
            .first()
            .id
        )
    q = db(
        (db.accounting_tree.branches == request.args(0))
        & (db.accounting_tree.account_periods == per)
    ).select(db.accounting_tree.ALL, orderby=db.accounting_tree.account_no)
    index = 0
    for r in q:
        r.inx = index
        index = index + 1
        r["show_plus"] = 0
        if r["main_account"] != "0":
            parent = (
                db(
                    (db.accounting_tree.branches == int(request.args(0)))
                    & (db.accounting_tree.account_periods == int(per))
                    & (db.accounting_tree.account_no == r["main_account"])
                )
                .select(db.accounting_tree.account_name_ar)
                .first()
            )
            ms_name = parent.account_name_ar if parent else r["main_account"]
            r["account_name"] = ms_name + " > " + r["account_name_ar"]
            r["show"] = 1
        else:
            r["account_name"] = r["account_name_ar"]
            r["show"] = 0
    return response.json(q)


@auth.requires(can_view)
def get_accounting_tree2():
    q = db(db.accounting_tree.branches == request.args(0)).select(
        db.accounting_tree.account_no,
        db.accounting_tree.account_name_ar,
        db.accounting_tree.account_name_en,
        db.accounting_tree.main_account,
        db.accounting_tree.account_level,
        db.accounting_tree.account_type,
        db.accounting_tree.final_account,
        db.accounting_tree.show_account,
        orderby=db.accounting_tree.account_no,
    )
    return response.json(q)


@auth.requires(can_account)
def upload_data():
    """رفع شجرة حسابات من JSON طرف العميل."""
    try:
        loaded_json = json.loads(request.vars.get("data") or "[]")
        result = _insert_tree_rows(
            loaded_json,
            request.vars.get("branch"),
            request.vars.get("account_periods"),
        )
        return response.json(result)
    except ValueError:
        db.rollback()
        return response.json({"err": 1, "id": 0, "mess": "ملف JSON غير صالح."})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def add_accounting_tree():
    try:
        row = request.vars
        acc_no = str(row.get("account_no") or "").strip()
        ar = (row.get("account_name_ar") or "").strip()
        main = str(row.get("main_account") or "0").strip()
        err = _validate_account_payload(row)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        dup = db(
            (db.accounting_tree.branches == row["branches"])
            & (db.accounting_tree.account_no == acc_no)
            & (db.accounting_tree.account_periods == row["account_periods"])
        ).count()
        if dup > 0:
            return response.json({
                "err": 1, "id": 0,
                "mess": "يوجد حساب مسجل بهذا الرقم مسبقاً في نفس الفرع والدورة.",
            })
        if main and main != "0":
            parent_count = db(
                (db.accounting_tree.branches == row["branches"])
                & (db.accounting_tree.account_no == main)
                & (db.accounting_tree.account_periods == row["account_periods"])
            ).count()
            if parent_count == 0:
                return response.json({
                    "err": 1, "id": 0,
                    "mess": "الحساب الرئيسي «%s» غير موجود." % main,
                })
            if not acc_no.startswith(main):
                return response.json({
                    "err": 1, "id": 0,
                    "mess": "رقم الحساب الفرعي يجب أن يبدأ برقم الحساب الرئيسي «%s»." % main,
                })
        level = _resolve_account_level(row["branches"], row["account_periods"], main)
        if not level:
            return response.json({
                "err": 1, "id": 0,
                "mess": "تعذّر تحديد مستوى الحساب — تحقق من الحساب الرئيسي.",
            })
        nid = db.accounting_tree.insert(
            branches=row["branches"],
            account_periods=row["account_periods"],
            account_no=acc_no,
            account_name_ar=ar,
            account_name_en=(row.get("account_name_en") or "").strip(),
            main_account=main,
            account_level=level,
            account_type=int(row.get("account_type") or 1),
            final_account=int(row.get("final_account") or 1),
            show_account=int(row.get("show_account") or 1),
        )
        db.commit()
        return response.json({"err": 0, "id": nid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_admin)
def clear_all_account_data():
    q = db(
        (db.accounting_tree.branches == request.args(0))
        & (db.accounting_tree.account_periods == request.args(1))
    ).delete()
    return response.json({"mess": "0", "conut": q})


# ===========  نسخ شجرة الحسابات من دورة إلى أخرى (لنفس الفرع)  ===========
@auth.requires(can_view)
def list_source_periods_for_clone():
    """يُرجع الدورات التي تحوي حسابات للفرع — لاستخدامها كمصدر للنسخ."""
    try:
        branch = int(request.vars.get("branch") or 0)
        exclude = int(request.vars.get("exclude") or 0)
        if not branch:
            return response.json([])
        rows = db.executesql(
            "SELECT ap.id, ap.disc, ap.start_date, ap.end_date, "
            "       (SELECT COUNT(*) FROM accounting_tree at "
            "        WHERE at.account_periods = ap.id AND at.branches = %s) AS cnt "
            "FROM account_periods ap "
            "WHERE ap.id != %s "
            "ORDER BY ap.start_date DESC, ap.id DESC",
            placeholders=[branch, exclude],
        )
        out = []
        for r in rows:
            cnt = int(r[4] or 0)
            if cnt <= 0:
                continue
            out.append({
                "id": r[0],
                "disc": r[1],
                "start_date": str(r[2]) if r[2] else None,
                "end_date": str(r[3]) if r[3] else None,
                "count": cnt,
            })
        return response.json(out)
    except Exception as e:
        print(e)
        return response.json([])


@auth.requires(can_admin)
def clone_tree_to_period():
    """نسخ شجرة الحسابات من دورة مصدر إلى دورة وجهة لنفس الفرع."""
    try:
        branch = int(request.vars.get("branch") or 0)
        source = int(request.vars.get("source") or 0)
        dest = int(request.vars.get("dest") or 0)
        if not (branch and source and dest):
            return response.json({"err": 1, "mess": "البيانات ناقصة"})
        if source == dest:
            return response.json({"err": 1, "mess": "لا يمكن النسخ من الدورة إلى نفسها"})
        if not db.account_periods[source]:
            return response.json({"err": 1, "mess": "الدورة المصدر غير موجودة"})
        if not db.account_periods[dest]:
            return response.json({"err": 1, "mess": "الدورة الوجهة غير موجودة"})
        rows = db(
            (db.accounting_tree.branches == branch)
            & (db.accounting_tree.account_periods == source)
        ).select(orderby=db.accounting_tree.account_no)
        if not rows:
            return response.json({"err": 1, "mess": "الدورة المصدر لا تحتوي على دليل حسابات."})
        raw_rows = [dict(
            account_no=r.account_no,
            account_name_ar=r.account_name_ar,
            account_name_en=r.account_name_en,
            main_account=r.main_account,
            account_type=r.account_type,
            final_account=r.final_account,
            show_account=r.show_account,
        ) for r in rows]
        return response.json(_insert_tree_rows(raw_rows, branch, dest))
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_account)
def add_account_file():
    """استيراد شجرة جاهزة من ملف JSON بمسار ثابت داخل static/."""
    try:
        template_id = request.args(2)
        template_file = acc_tree_import.template_filename(template_id)
        if not template_file:
            return response.json({"err": 1, "id": 0, "mess": "الدليل الجاهز غير معروف."})
        filename = os.path.join(request.folder, "static", template_file)
        with open(filename, "r", encoding="utf-8") as f:
            datastore = json.load(f)
        result = _insert_tree_rows(datastore, request.args(0), request.args(1))
        return response.json(result)
    except ValueError:
        db.rollback()
        return response.json({"err": 1, "id": 0, "mess": "ملف الدليل الجاهز غير صالح."})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def update_accounting_tree():
    try:
        row = request.vars
        edit_row = db.accounting_tree[row["id"]]
        err = _validate_account_payload(row)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        qry_data = (
            "select * from journal_entry_detail "
            " where account_periods = %s "
            " and  branches = %s "
            " and account_no like %s "
        )
        qry_data_ph = [
            int(row["account_periods"]), int(row["branches"]),
            str(edit_row["account_no"]) + "%"]
        if (edit_row.account_no == row["account_no"]) and (
            edit_row.main_account == row["main_account"]
        ):
            level = _resolve_account_level(
                row["branches"], row["account_periods"], row["main_account"]
            )
            edit_row.account_name_ar = row["account_name_ar"]
            edit_row.account_name_en = row["account_name_en"]
            edit_row.account_level = level or edit_row.account_level
            edit_row.account_type = row["account_type"]
            edit_row.final_account = row["final_account"]
            edit_row.show_account = row["show_account"]
            edit_row.credit = row["credit"]
            edit_row.debit = row["debit"]
            edit_row.update_record()
            db.commit()
            return response.json({"err": 0, "id": row["id"], "mess": "0"})
        else:
            has_data = db.executesql(qry_data, placeholders=qry_data_ph)
            if len(has_data) > 0:
                return response.json({
                    "err": 3, "id": 0,
                    "mess": "لا يمكن تعديل الحساب لوجود قيود عليه ( " + str(len(has_data)) + " )",
                })

            new_acc_no = str(row["account_no"]).strip()
            new_main = str(row.get("main_account") or "0").strip()
            dup = db(
                (db.accounting_tree.branches == row["branches"])
                & (db.accounting_tree.account_periods == row["account_periods"])
                & (db.accounting_tree.account_no == new_acc_no)
                & (db.accounting_tree.id != row["id"])
            ).count()
            if dup > 0:
                return response.json({
                    "err": 1, "id": 0,
                    "mess": "يوجد حساب آخر بنفس الرقم في نفس الفرع والدورة.",
                })
            if new_main and new_main != "0":
                parent_count = db(
                    (db.accounting_tree.branches == row["branches"])
                    & (db.accounting_tree.account_periods == row["account_periods"])
                    & (db.accounting_tree.account_no == new_main)
                ).count()
                if parent_count == 0:
                    return response.json({
                        "err": 1, "id": 0,
                        "mess": "الحساب الرئيسي «%s» غير موجود." % new_main,
                    })
                if not new_acc_no.startswith(new_main):
                    return response.json({
                        "err": 1, "id": 0,
                        "mess": "رقم الحساب يجب أن يبدأ برقم الحساب الرئيسي «%s»." % new_main,
                    })
            kids = db(
                (db.accounting_tree.main_account == edit_row.account_no)
                & (db.accounting_tree.branches == row["branches"])
                & (db.accounting_tree.account_periods == row["account_periods"])
            ).count()
            if kids > 0:
                return response.json({
                    "err": 1, "id": 0,
                    "mess": "يوجد %d حساب فرعي تابع لهذا الحساب — لا يمكن تعديل رقمه." % kids,
                })
            edit_row.account_no = new_acc_no
            edit_row.account_name_ar = row["account_name_ar"]
            edit_row.account_name_en = row["account_name_en"]
            edit_row.main_account = new_main
            edit_row.account_level = _resolve_account_level(
                row["branches"], row["account_periods"], new_main
            )
            edit_row.account_type = row["account_type"]
            edit_row.final_account = row["final_account"]
            edit_row.show_account = row["show_account"]
            edit_row.credit = row["credit"]
            edit_row.debit = row["debit"]
            edit_row.update_record()
            db.commit()
            return response.json({"err": 0, "id": row["id"], "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def delete_accounting_tree():
    try:
        row = request.vars
        edit_row = db.accounting_tree[row["id"]]
        qry_data = (
            "select * from journal_entry_detail "
            " where account_periods = %s "
            " and  branches = %s "
            " and account_no like %s "
        )
        has_data = db.executesql(qry_data, placeholders=[
            int(row["account_periods"]), int(row["branches"]),
            str(row["account_no"]) + "%"])
        if len(has_data) > 0:
            return response.json({
                "err": 3, "id": 0,
                "mess": "لا يمكن حذف الحساب لوجود قيود عليه ( " + str(len(has_data)) + " )",
            })
        edit_row.delete_record()
        db.commit()
        qry = (
            "delete from account_periods_opening "
            " where account_periods=%s "
            " and  account_no not in "
            " ( select account_no from accounting_tree where accounting_tree.branches = account_periods_opening.branches) "
        )
        db.executesql(qry, placeholders=[int(row["account_periods"])])
        qry = (
            "delete from accounting_tree "
            " where account_periods=%s "
            " and branches = %s "
            " and account_no like %s "
        )
        db.executesql(qry, placeholders=[
            int(row["account_periods"]), int(row["branches"]),
            str(row["account_no"]) + "%"])
        return response.json({"err": 0, "id": row["id"], "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_view)
def get_accounting_tree_last():
    """آخر مستوى ورقي من شجرة الحسابات (للقيود)."""
    per = (
        db(db.account_periods.open_period == 1)
        .select(orderby=db.account_periods.id)
        .first()
    )
    qry = (
        " select *,(select disc from account_periods where id=%s ) as per  "
        " from accounting_tree where branches=%s "
        " and  account_periods=%s and account_no not in "
        " ( select main_account from accounting_tree where branches=%s ) "
        " order by account_no"
    )
    data = db.executesql(qry, placeholders=[
        int(per.id), int(request.args(0)), int(per.id),
        int(request.args(0))], as_dict=True)
    for row in data:
        if row["main_account"] != "0":
            parent = (
                db(
                    (db.accounting_tree.branches == int(request.args(0)))
                    & (db.accounting_tree.account_periods == int(per.id))
                    & (db.accounting_tree.account_no == row["main_account"])
                )
                .select(db.accounting_tree.account_name_ar)
                .first()
            )
            ms_name = parent.account_name_ar if parent else row["main_account"]
            row["account_name"] = ms_name + " > " + row["account_name_ar"]
        else:
            row["account_name"] = row["account_name_ar"]
    return response.json(data)
