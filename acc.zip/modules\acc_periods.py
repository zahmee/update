# -*- coding: utf-8 -*-
"""
acc_periods — أدوات الفترات المالية (Period resolution + state checks).

يوحّد دوال مشتركة كانت موزَّعة:
- `resolve(db, arg)`        — يُرجع سجل الدورة بـ id، أو أول دورة مفتوحة عند الإهمال
- `is_open(db, period_id)`  — bool هل الدورة مفتوحة
- `latest_open(db)`         — أحدث دورة مفتوحة (الافتراضية للواجهات)
- `containing(db, date)`    — الدورة التي تحتوي تاريخاً معيّناً
- `get(db, period_id)`      — جلب الدورة بأمان، None إن لم توجد

كل الدوال تأخذ `db` صراحةً (dependency injection) — قابلة للاختبار باستقلال عن web2py.
"""

from datetime import date as _date_cls


def get(db, period_id):
    """يجلب الدورة بـ id بأمان — None إن لم توجد أو id غير صالح."""
    if not period_id:
        return None
    try:
        return db.account_periods[int(period_id)]
    except Exception:
        return None


def is_open(db, period_id):
    """True إذا كانت الفترة مفتوحة (open_period == 1)."""
    per = get(db, period_id)
    return bool(per) and int(per.open_period or 0) == 1


def latest_open(db):
    """أحدث دورة مفتوحة — تُستخدم كافتراضية للشاشات."""
    return (
        db(db.account_periods.open_period == 1)
        .select(orderby=~db.account_periods.start_date)
        .first()
    )


def first_open(db):
    """أول دورة مفتوحة (بـ id) — السلوك القديم لـ _resolve_period عند الإهمال."""
    return (
        db(db.account_periods.open_period == 1)
        .select(orderby=db.account_periods.id)
        .first()
    )


def resolve(db, arg, prefer="first_open"):
    """يُرجع كائن الدورة بناءً على المعرّف، أو fallback عند الإهمال.

    arg     — id الدورة (int/str) أو None
    prefer  — "first_open" (افتراضي، السلوك المتوافق) أو "latest_open"

    يطابق سلوك _resolve_period القديم في setting_api.py.
    """
    if arg:
        per = get(db, arg)
        if per:
            return per
    return first_open(db) if prefer == "first_open" else latest_open(db)


def containing(db, day):
    """الدورة التي تحتوي تاريخاً معيّناً (start_date <= day <= end_date).

    day — كائن date أو ISO string. يُرجع None إن لم توجد دورة تحتويه.
    """
    if not day:
        return None
    if isinstance(day, str):
        try:
            from datetime import datetime as _dt
            day = _dt.strptime(day[:10], "%Y-%m-%d").date()
        except Exception:
            return None
    if not isinstance(day, _date_cls):
        return None
    return (
        db(
            (db.account_periods.start_date <= day)
            & (db.account_periods.end_date >= day)
        )
        .select()
        .first()
    )


def period_dates(per):
    """يعيد (start_date, end_date) كـ strings ISO من سجل دورة، أو (None, None)."""
    if not per:
        return None, None
    sd = per.start_date.isoformat() if per.start_date else None
    ed = per.end_date.isoformat() if per.end_date else None
    return sd, ed


def to_dict(per):
    """تحويل سجل دورة إلى dict للـ JSON payload (موحَّد عبر الشاشات)."""
    if not per:
        return None
    sd, ed = period_dates(per)
    return {
        "id": int(per.id),
        "disc": per.disc,
        "start_date": sd,
        "end_date": ed,
        "open": int(per.open_period or 0) == 1,
    }
