# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_journal_api — دفتر اليومية (Journal Day-book) فقط.

استُخرج من reports_api.py في Phase 2.2 (2026-05-25) لتقليل حجم الملف الأم.
يحتوي:
- Journal_report — كل القيود + سطورها التفصيلية مع إحصائيات
- _journal_report_xlsx — تصدير xlsx
"""

import acc_dates
import acc_export


@auth.requires(can_view)
def Journal_report():
    """دفتر اليومية — يُرجع القيود + سطورها مع إحصائيات.

    Query/form vars:
      branch     — id الفرع (مطلوب > 0، أو 0 = كل الفروع)
      period     — id الدورة (0 = الكل، اختياري)
      date_from  — YYYY-MM-DD
      date_to    — YYYY-MM-DD
      q          — نص بحث (يبحث في رقم القيد، البيان، أو بيان السطر)
      account_no — رقم حساب لتصفية القيود التي تحويه (اختياري)

    الردّ:
      {err, entries: [{master:{...}, details:[{...}], balance_ok, diff}],
       stats: {count, debit, credit, diff, balanced}}
    """
    try:
        v = request.vars
        try:
            branch = int(v.get("branch") or 0)
            period = int(v.get("period") or 0)
        except Exception:
            return response.json({"err": 1, "mess": "قيمة فرع/دورة غير صحيحة"})
        date_from = acc_dates.parse_iso(v.get("date_from"))
        date_to = acc_dates.parse_iso(v.get("date_to"))
        q_text = (v.get("q") or "").strip()
        account_no = (v.get("account_no") or "").strip()

        m = db.journal_entry_master
        cond = (m.is_active == True)
        if branch > 0:
            cond &= (m.branches == branch)
        if period > 0:
            cond &= (m.account_periods == period)
        if date_from:
            cond &= (m.journal_date >= date_from)
        if date_to:
            cond &= (m.journal_date <= date_to)
        if q_text:
            try:
                qid = int(q_text)
                cond &= ((m.id == qid)
                         | m.journal_detail.contains(q_text)
                         | m.journal_save.contains(q_text))
            except Exception:
                cond &= (m.journal_detail.contains(q_text)
                         | m.journal_save.contains(q_text))
        if account_no:
            ids_with_acc = [r.journal_entry_master for r in db(
                db.journal_entry_detail.account_no == account_no
            ).select(db.journal_entry_detail.journal_entry_master, distinct=True)]
            if ids_with_acc:
                cond &= m.id.belongs(ids_with_acc)
            else:
                cond &= (m.id == 0)

        masters = db(cond).select(orderby=[m.journal_date, m.id])
        master_ids = [r.id for r in masters]
        if not master_ids:
            return response.json({
                "err": 0,
                "entries": [],
                "stats": {"count": 0, "debit": 0, "credit": 0, "diff": 0, "balanced": True},
            })

        all_details = db(
            db.journal_entry_detail.journal_entry_master.belongs(master_ids)
        ).select(orderby=[db.journal_entry_detail.journal_entry_master,
                          db.journal_entry_detail.id])
        details_by_master = {}
        atree_ids = list({int(r.accounting_tree) for r in all_details if r.accounting_tree})
        atree_map = {}
        if atree_ids:
            for at in db(db.accounting_tree.id.belongs(atree_ids)).select(
                db.accounting_tree.id, db.accounting_tree.account_no,
                db.accounting_tree.account_name_ar, db.accounting_tree.main_account,
            ):
                atree_map[int(at.id)] = at
        cc_ids = list({int(r.cost_center) for r in all_details if r.cost_center})
        cc_map = {}
        if cc_ids:
            for c in db(db.key_cost_center.id.belongs(cc_ids)).select(
                db.key_cost_center.id, db.key_cost_center.name
            ):
                cc_map[int(c.id)] = c.name

        for r in all_details:
            mid = int(r.journal_entry_master)
            at = atree_map.get(int(r.accounting_tree)) if r.accounting_tree else None
            details_by_master.setdefault(mid, []).append({
                "id": int(r.id),
                "account_no": r.account_no or (at.account_no if at else ""),
                "account_name": (at.account_name_ar if at else "") or "",
                "detail": r.detail or "",
                "debit": float(r.debit or 0),
                "credit": float(r.credit or 0),
                "cost_center_id": int(r.cost_center or 0) or None,
                "cost_center_name": cc_map.get(int(r.cost_center)) if r.cost_center else "",
            })

        bids = list({int(r.branches) for r in masters if r.branches})
        pids = list({int(r.account_periods) for r in masters if r.account_periods})
        bmap = {b.id: b.name for b in db(db.branches.id.belongs(bids)).select()} if bids else {}
        pmap = {p.id: p.disc for p in db(db.account_periods.id.belongs(pids)).select()} if pids else {}

        entries = []
        total_debit = 0.0
        total_credit = 0.0
        for mas in masters:
            dets = details_by_master.get(int(mas.id), [])
            sum_d = round(sum(d["debit"] for d in dets), 2)
            sum_c = round(sum(d["credit"] for d in dets), 2)
            md = float(mas.debit_total or 0)
            mc = float(mas.credit_total or 0)
            entry_balanced = (
                abs(sum_d - sum_c) < 0.005 and
                abs(sum_d - md) < 0.005 and
                abs(sum_c - mc) < 0.005
            )
            total_debit += sum_d
            total_credit += sum_c
            entries.append({
                "master": {
                    "id": int(mas.id),
                    "journal_date": str(mas.journal_date) if mas.journal_date else None,
                    "journal_detail": mas.journal_detail or "",
                    "journal_save": mas.journal_save or "",
                    "journal_operations": int(mas.journal_operations or 0),
                    "branch_id": int(mas.branches or 0),
                    "branch_name": bmap.get(int(mas.branches), "—") if mas.branches else "—",
                    "period_id": int(mas.account_periods or 0),
                    "period_disc": pmap.get(int(mas.account_periods), "—") if mas.account_periods else "—",
                    "debit_total": md,
                    "credit_total": mc,
                },
                "details": dets,
                "sum_debit": sum_d,
                "sum_credit": sum_c,
                "balance_ok": entry_balanced,
                "diff": round(sum_d - sum_c, 2),
            })
        total_debit = round(total_debit, 2)
        total_credit = round(total_credit, 2)
        result = {
            "err": 0,
            "entries": entries,
            "stats": {
                "count": len(entries),
                "debit": total_debit,
                "credit": total_credit,
                "diff": round(total_debit - total_credit, 2),
                "balanced": abs(total_debit - total_credit) < 0.005,
            },
        }
        if str(v.get("format") or "").lower() == "xlsx":
            return _journal_report_xlsx(result, v)
        return response.json(result)
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


def _journal_report_xlsx(data, v):
    """يحوّل ردّ Journal_report إلى xlsx — سطر لكل (قيد × سطر)."""
    columns = [
        {"key": "journal_id", "title": "رقم القيد", "format": "number", "width": 10},
        {"key": "date", "title": "التاريخ", "format": "text", "width": 12},
        {"key": "branch", "title": "الفرع", "format": "text", "width": 14},
        {"key": "master_disc", "title": "بيان القيد", "format": "text", "width": 30},
        {"key": "account_no", "title": "رقم الحساب", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 28},
        {"key": "detail", "title": "بيان السطر", "format": "text", "width": 26},
        {"key": "cost_center", "title": "مركز التكلفة", "format": "text", "width": 14},
        {"key": "debit", "title": "مدين", "format": "currency"},
        {"key": "credit", "title": "دائن", "format": "currency"},
    ]
    rows = []
    for entry in data["entries"]:
        mas = entry["master"]
        for d in entry["details"]:
            rows.append({
                "journal_id": mas["id"],
                "date": mas.get("journal_date") or "",
                "branch": mas.get("branch_name") or "",
                "master_disc": mas.get("journal_detail") or "",
                "account_no": d.get("account_no") or "",
                "account_name": d.get("account_name") or "",
                "detail": d.get("detail") or "",
                "cost_center": d.get("cost_center_name") or "",
                "debit": d.get("debit") or 0,
                "credit": d.get("credit") or 0,
            })
    stats = data["stats"]
    totals_row = {
        "journal_id": "",
        "date": "",
        "branch": "",
        "master_disc": "",
        "account_no": "",
        "account_name": "",
        "detail": "",
        "cost_center": "الإجمالي",
        "debit": stats.get("debit", 0),
        "credit": stats.get("credit", 0),
    }
    meta = [
        ("من تاريخ", v.get("date_from") or "—"),
        ("إلى تاريخ", v.get("date_to") or "—"),
        ("عدد القيود", stats.get("count", 0)),
        ("حالة التوازن", "متوازن" if stats.get("balanced") else "غير متوازن"),
    ]
    if v.get("q"):
        meta.append(("بحث", v.get("q")))
    if v.get("account_no"):
        meta.append(("حساب", v.get("account_no")))
    fname = "journal_report_%s.xlsx" % (v.get("date_to") or "all")
    return acc_export.xlsx_response(
        response, fname,
        title="دفتر اليومية",
        meta=meta,
        columns=columns,
        rows=rows,
        totals=totals_row,
        sheet_name="دفتر اليومية",
    )
