# -*- coding: utf-8 -*-
# type: ignore
"""
attachments_api — إدارة مرفقات القيود المحاسبية (Phase 3.5).

يحتاج جدول `journal_attachments` (راجع migrations_manual/001_journal_attachments.sql).
الملفات تُخزَّن في `uploads/journal_attachments/`.

Endpoints:
- list_attachments/<journal_id>  — قائمة المرفقات على قيد
- upload_attachment              — رفع ملف (POST: journal_id, file)
- download_attachment/<id>       — تنزيل ملف
- delete_attachment/<id>         — حذف (مدير أو من رفعها)
"""

import os
import uuid
import mimetypes

from applications.acc.modules import acc_responses as resp, acc_schema


def _ensure_table():
    """فحص وجود الجدول قبل أي استعلام. يرجع None إن كان موجوداً،
    أو رد JSON إن كان مفقوداً."""
    if not acc_schema.table_exists(db, 'journal_attachments'):
        return response.json(acc_schema.missing_table_response(
            'journal_attachments', migration='001'
        ))
    return None


# الإعدادات
ALLOWED_MIMES = {
    "application/pdf",
    "image/jpeg", "image/png", "image/gif", "image/webp",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}
MAX_SIZE = 10 * 1024 * 1024  # 10 MB


def _storage_dir():
    """مسار التخزين — يُنشأ إن لم يكن موجوداً."""
    d = os.path.join(request.folder, "uploads", "journal_attachments")
    if not os.path.exists(d):
        os.makedirs(d, exist_ok=True)
    return d


@auth.requires(can_view)
def list_attachments():
    """قائمة المرفقات على قيد. الاستدعاء: /list_attachments/<journal_id>"""
    guard = _ensure_table()
    if guard: return guard
    try:
        jid = int(request.args(0) or 0)
        if jid <= 0:
            return response.json(resp.fail("معرّف القيد مطلوب"))
        rows = db(db.journal_attachments.journal_id == jid).select(
            orderby=db.journal_attachments.uploaded_on
        )
        # أسماء الرافعين
        uids = list({r.uploaded_by for r in rows if r.uploaded_by})
        names = {}
        if uids:
            for u in db(db.auth_user.id.belongs(uids)).select(
                db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
            ):
                names[u.id] = ((u.first_name or "") + " " + (u.last_name or "")).strip()
        items = []
        for r in rows:
            items.append({
                "id": int(r.id),
                "filename": r.filename,
                "mime_type": r.mime_type,
                "file_size": int(r.file_size or 0),
                "uploaded_on": str(r.uploaded_on),
                "uploaded_by": int(r.uploaded_by or 0),
                "uploaded_by_name": names.get(r.uploaded_by, "—"),
                "notes": r.notes or "",
            })
        return response.json(resp.ok(items=items, count=len(items)))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_enter)
def upload_attachment():
    """رفع ملف. POST: journal_id, file (multipart), notes (اختياري)."""
    guard = _ensure_table()
    if guard: return guard
    try:
        jid = int(request.vars.get("journal_id") or 0)
        if jid <= 0:
            return response.json(resp.fail("معرّف القيد مطلوب"))
        # تحقّق من وجود القيد
        master = db.journal_entry_master[jid]
        if not master or not master.is_active:
            return response.json(resp.fail("القيد غير موجود أو محذوف"))
        # الملف
        uploaded = request.vars.get("file")
        if not uploaded or not hasattr(uploaded, "filename"):
            return response.json(resp.fail("لم يُرفَق ملف"))
        # MIME
        mime, _ = mimetypes.guess_type(uploaded.filename)
        if not mime:
            mime = "application/octet-stream"
        if mime not in ALLOWED_MIMES:
            return response.json(resp.fail("نوع ملف غير مدعوم: %s" % mime))
        # حجم
        uploaded.file.seek(0, 2)  # end
        size = uploaded.file.tell()
        uploaded.file.seek(0)
        if size > MAX_SIZE:
            return response.json(resp.fail(
                "الملف أكبر من الحد المسموح (%d MB)" % (MAX_SIZE // (1024*1024))
            ))
        if size == 0:
            return response.json(resp.fail("الملف فارغ"))
        # حفظ على القرص
        ext = os.path.splitext(uploaded.filename)[1].lower()
        storage_name = "%s%s" % (uuid.uuid4().hex, ext)
        full_path = os.path.join(_storage_dir(), storage_name)
        with open(full_path, "wb") as f:
            f.write(uploaded.file.read())
        # تسجيل في DB
        nid = db.journal_attachments.insert(
            journal_id=jid,
            filename=uploaded.filename[:255],
            storage_name=storage_name,
            mime_type=mime[:100],
            file_size=size,
            uploaded_by=auth.user_id,
            uploaded_on=request.now,
            notes=(request.vars.get("notes") or "")[:1000],
        )
        db.commit()
        return response.json(resp.ok(id=nid, filename=uploaded.filename, size=size))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))


@auth.requires(can_view)
def download_attachment():
    """تنزيل مرفق. الاستدعاء: /download_attachment/<id>"""
    if not acc_schema.table_exists(db, 'journal_attachments'):
        raise HTTP(503, "المرفقات غير مفعَّلة. طبّق migrations_manual/001 أولاً.")
    try:
        aid = int(request.args(0) or 0)
        rec = db.journal_attachments[aid] if aid else None
        if not rec:
            raise HTTP(404, "المرفق غير موجود")
        full_path = os.path.join(_storage_dir(), rec.storage_name)
        if not os.path.exists(full_path):
            raise HTTP(404, "الملف المخزّن مفقود")
        response.headers["Content-Type"] = rec.mime_type or "application/octet-stream"
        # filename* للحفاظ على اسم عربي عند التنزيل (RFC 5987)
        import urllib.parse
        encoded = urllib.parse.quote(rec.filename)
        response.headers["Content-Disposition"] = (
            "attachment; filename*=UTF-8''%s" % encoded
        )
        with open(full_path, "rb") as f:
            return f.read()
    except HTTP:
        raise
    except Exception as e:
        return response.json(resp.error(e))


@auth.requires(can_enter)
def delete_attachment():
    """حذف مرفق — admin أو من رفعه فقط."""
    guard = _ensure_table()
    if guard: return guard
    try:
        aid = int(request.vars.get("id") or request.args(0) or 0)
        rec = db.journal_attachments[aid] if aid else None
        if not rec:
            return response.json(resp.not_found("المرفق"))
        # صلاحية
        is_admin = auth.has_membership("admin")
        is_owner = int(rec.uploaded_by or 0) == int(auth.user_id or 0)
        if not (is_admin or is_owner):
            return response.json(resp.forbidden("غير مسموح بحذف مرفق رفعه شخص آخر"))
        # احذف الملف
        full_path = os.path.join(_storage_dir(), rec.storage_name)
        if os.path.exists(full_path):
            try:
                os.remove(full_path)
            except Exception:
                pass  # نواصل لحذف السجل
        rec.delete_record()
        db.commit()
        return response.json(resp.ok(id=aid))
    except Exception as e:
        db.rollback()
        return response.json(resp.error(e))
