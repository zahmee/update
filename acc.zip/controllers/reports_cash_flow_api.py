# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_cash_flow_api — قائمة التدفقات النقدية (نهج الطريقة المباشرة المبسَّطة).

المنهج: المستخدم يختار حسابات النقدية (الصندوق، البنوك، إلخ)، والنظام:
  1. يحسب الرصيد الافتتاحي والختامي للنقدية
  2. يجمع كل سطور القيود التي يكون أحد طرفيها حساب نقدية
  3. يجمّع الـ counterparty (الطرف غير النقدي) ويصنّفه حسب طبيعته:
     - تشغيلية: حسابات قائمة الدخل (final_account in (2, 3))
     - استثمارية: أصول الميزانية (final_account=1, account_type=2)
     - تمويلية: خصوم وحقوق الميزانية (final_account=1, account_type=1)
  4. يعرض إجمالي الداخل/الخارج لكل نشاط + تفاصيل الـcounterparties

عقد API:
  POST cash_flow_statement
  Body:
    branch     — id الفرع (مطلوب)
    period     — id الدورة (مطلوب)
    date_from  — YYYY-MM-DD (مطلوب)
    date_to    — YYYY-MM-DD (مطلوب)
    cash_account_ids — list أو CSV من ids حسابات النقدية (مطلوب)
    format     — "xlsx" للتصدير
"""

import json

from applications.acc.modules import acc_dates, acc_periods, acc_export


def _payload():
    try:
        if request.body and request.body.read(1):
            request.body.seek(0)
            payload = json.loads(request.body.read().decode("utf-8") or "{}")
        else:
            payload = {}
    except Exception:
        payload = {}
    v = dict(request.vars or {})
    v.update(payload)
    return v


def _int_or_zero(x):
    try:
        return int(x)
    except Exception:
        return 0


def _classify_activity(final_account, account_type):
    """يصنّف حساباً (غير نقدي) كنشاط تشغيلي/استثماري/تمويلي."""
    fa = int(final_account or 0)
    at = int(account_type or 0)
    if fa in (2, 3):
        return "operating"
    if fa == 1 and at == 2:
        return "investing"
    if fa == 1 and at == 1:
        return "financing"
    return "operating"  # افتراضي


@auth.requires(can_view)
def cash_flow_statement():
    """قائمة التدفقات النقدية."""
    try:
        v = _payload()
        branch_id = _int_or_zero(v.get("branch"))
        period_id = _int_or_zero(v.get("period"))
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})
        if period_id <= 0:
            return response.json({"err": 1, "mess": "الدورة المالية مطلوبة"})

        per = acc_periods.get(db, period_id)
        if not per:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        branch = db.branches[branch_id]
        if not branch:
            return response.json({"err": 1, "mess": "الفرع غير موجود"})

        # cash_account_ids — list أو CSV
        raw = v.get("cash_account_ids") or v.get("cash_accounts") or []
        if isinstance(raw, str):
            raw = [s.strip() for s in raw.split(",") if s.strip()]
        cash_ids = [int(x) for x in raw if str(x).strip().isdigit()]
        if not cash_ids:
            return response.json({"err": 1, "mess": "اختر حساب نقدية واحداً على الأقل"})

        date_from = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_from"))) or str(per.start_date)
        date_to = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_to"))) or str(per.end_date)

        # جلب حسابات النقدية المختارة
        cash_accs = db(
            (db.accounting_tree.id.belongs(cash_ids))
            & (db.accounting_tree.branches == branch_id)
        ).select()
        if not cash_accs:
            return response.json({"err": 1, "mess": "حسابات النقدية المختارة غير صالحة لهذا الفرع"})

        cash_account_nos = [a.account_no for a in cash_accs]
        cash_accounts_info = [{
            "id": int(a.id),
            "account_no": a.account_no,
            "account_name": a.account_name_ar or "",
        } for a in cash_accs]

        # ============== 1) أرصدة النقدية: افتتاحي + قبل التاريخ + ختامي ==============
        cash_balances = []
        total_opening = 0.0
        total_ending = 0.0

        for cash_acc in cash_accs:
            like_pat = cash_acc.account_no + "%"

            # افتتاحي من account_periods_opening
            op_rows = db.executesql(
                "SELECT COALESCE(SUM(debit),0)::float, COALESCE(SUM(credit),0)::float "
                "FROM account_periods_opening "
                "WHERE branches=%s AND account_periods=%s AND account_no LIKE %s",
                placeholders=[branch_id, period_id, like_pat],
            )
            op_d = float(op_rows[0][0] or 0)
            op_c = float(op_rows[0][1] or 0)

            # حركة ما قبل التاريخ (تُضاف للافتتاحي)
            pre_rows = db.executesql(
                "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
                "FROM journal_entry_detail jed "
                "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
                "WHERE jem.is_active='T' AND jed.branches=%s AND jed.account_periods=%s "
                "  AND jed.account_no LIKE %s AND jed.journal_date < %s",
                placeholders=[branch_id, period_id, like_pat, date_from],
            )
            pre_d = float(pre_rows[0][0] or 0)
            pre_c = float(pre_rows[0][1] or 0)

            # حركة الفترة
            mov_rows = db.executesql(
                "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
                "FROM journal_entry_detail jed "
                "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
                "WHERE jem.is_active='T' AND jed.branches=%s AND jed.account_periods=%s "
                "  AND jed.account_no LIKE %s AND jed.journal_date >= %s AND jed.journal_date <= %s",
                placeholders=[branch_id, period_id, like_pat, date_from, date_to],
            )
            mov_d = float(mov_rows[0][0] or 0)
            mov_c = float(mov_rows[0][1] or 0)

            opening_net = round((op_d + pre_d) - (op_c + pre_c), 2)  # افتراض: نقدية = مدين بطبيعتها
            mov_net = round(mov_d - mov_c, 2)
            ending_net = round(opening_net + mov_net, 2)
            cash_balances.append({
                "id": int(cash_acc.id),
                "account_no": cash_acc.account_no,
                "account_name": cash_acc.account_name_ar or "",
                "opening": opening_net,
                "inflows": round(mov_d, 2),
                "outflows": round(mov_c, 2),
                "net_change": mov_net,
                "ending": ending_net,
            })
            total_opening += opening_net
            total_ending += ending_net

        total_opening = round(total_opening, 2)
        total_ending = round(total_ending, 2)
        total_net_change = round(total_ending - total_opening, 2)

        # ============== 2) سطور القيود التي تشمل النقدية ==============
        # نريد كل القيود التي يكون أحد سطورها حساب نقدية
        # ثم نأخذ السطور الأخرى (counterparties) ونصنّفها
        cash_nos_placeholders = ",".join(["%s"] * len(cash_account_nos))
        master_ids_sql = (
            "SELECT DISTINCT jed.journal_entry_master AS jid "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            "WHERE jem.is_active='T' "
            "  AND jed.branches=%s AND jed.account_periods=%s "
            "  AND jed.journal_date >= %s AND jed.journal_date <= %s "
            f"  AND jed.account_no IN ({cash_nos_placeholders})"
        )
        params = [branch_id, period_id, date_from, date_to] + cash_account_nos
        master_id_rows = db.executesql(master_ids_sql, placeholders=params, as_dict=True)
        master_ids = [int(r["jid"]) for r in master_id_rows]

        # تجميع الـ counterparties
        operating = {}  # account_no -> {"name", "inflow", "outflow"}
        investing = {}
        financing = {}
        category_maps = {"operating": operating, "investing": investing, "financing": financing}

        if master_ids:
            # جلب كل سطور هذه القيود
            ids_csv = ",".join(["%s"] * len(master_ids))
            lines_sql = (
                "SELECT jed.account_no, jed.debit::float as d, jed.credit::float as c, "
                "       at.account_name_ar, at.account_type, at.final_account "
                "FROM journal_entry_detail jed "
                "LEFT JOIN accounting_tree at ON at.id = jed.accounting_tree "
                f"WHERE jed.journal_entry_master IN ({ids_csv})"
            )
            line_rows = db.executesql(lines_sql, placeholders=master_ids, as_dict=True)

            cash_no_set = set(cash_account_nos)
            for r in line_rows:
                acc_no = r.get("account_no")
                if not acc_no or acc_no in cash_no_set:
                    continue  # تخطّى سطر النقدية نفسه — نحن نريد الـ counterparty
                d = float(r["d"] or 0)
                c = float(r["c"] or 0)
                if d == 0 and c == 0:
                    continue
                # السطر غير النقدي مدين → النقدية دائنة → نقد خارج
                # السطر غير النقدي دائن → النقدية مدين → نقد داخل
                outflow = d  # المبلغ الذي ذهب لهذا الحساب
                inflow = c   # المبلغ الذي جاء من هذا الحساب
                cat = _classify_activity(r.get("final_account"), r.get("account_type"))
                bucket = category_maps[cat]
                if acc_no not in bucket:
                    bucket[acc_no] = {
                        "account_no": acc_no,
                        "account_name": r.get("account_name_ar") or "",
                        "inflow": 0.0,
                        "outflow": 0.0,
                    }
                bucket[acc_no]["inflow"] += inflow
                bucket[acc_no]["outflow"] += outflow

        # تنسيق الـ buckets
        def _format_bucket(bucket):
            items = []
            sum_in, sum_out = 0.0, 0.0
            for v in sorted(bucket.values(),
                          key=lambda x: -(x["inflow"] + x["outflow"])):
                v["inflow"] = round(v["inflow"], 2)
                v["outflow"] = round(v["outflow"], 2)
                v["net"] = round(v["inflow"] - v["outflow"], 2)
                items.append(v)
                sum_in += v["inflow"]
                sum_out += v["outflow"]
            return {
                "items": items,
                "total_inflow": round(sum_in, 2),
                "total_outflow": round(sum_out, 2),
                "net": round(sum_in - sum_out, 2),
                "count": len(items),
            }

        operating_data = _format_bucket(operating)
        investing_data = _format_bucket(investing)
        financing_data = _format_bucket(financing)

        # إجمالي صافي التدفق من الأنشطة الثلاثة
        net_from_activities = round(
            operating_data["net"] + investing_data["net"] + financing_data["net"], 2
        )
        # check: net_from_activities يجب أن يساوي total_net_change
        reconciles = abs(net_from_activities - total_net_change) < 0.01

        result = {
            "err": 0,
            "branch": {"id": int(branch.id), "name": branch.name},
            "period": acc_periods.to_dict(per),
            "date_from": date_from,
            "date_to": date_to,
            "cash_accounts": cash_accounts_info,
            "cash_balances": cash_balances,
            "total_opening": total_opening,
            "total_ending": total_ending,
            "total_net_change": total_net_change,
            "operating": operating_data,
            "investing": investing_data,
            "financing": financing_data,
            "net_from_activities": net_from_activities,
            "reconciles": reconciles,
            "difference": round(net_from_activities - total_net_change, 2),
        }

        if str(v.get("format") or "").lower() == "xlsx":
            return _cash_flow_xlsx(result)
        return response.json(result)
    except Exception as e:
        try:
            db.err_report.insert(er_dis=str(e), screen_dis="cash_flow_statement")
            db.commit()
        except Exception:
            pass
        return response.json({"err": 1, "mess": str(e)})


def _cash_flow_xlsx(data):
    columns = [
        {"key": "account_no", "title": "رقم الحساب", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 32},
        {"key": "inflow", "title": "تدفق داخل", "format": "currency"},
        {"key": "outflow", "title": "تدفق خارج", "format": "currency"},
        {"key": "net", "title": "الصافي", "format": "currency"},
    ]
    rows = []

    def _section(title, section):
        rows.append({"account_no": "", "account_name": "═══ " + title + " ═══",
                     "inflow": "", "outflow": "", "net": ""})
        for it in section["items"]:
            rows.append(it)
        rows.append({"account_no": "", "account_name": "إجمالي " + title,
                     "inflow": section["total_inflow"],
                     "outflow": section["total_outflow"],
                     "net": section["net"]})
        rows.append({"account_no": "", "account_name": "",
                     "inflow": "", "outflow": "", "net": ""})

    _section("الأنشطة التشغيلية", data["operating"])
    _section("الأنشطة الاستثمارية", data["investing"])
    _section("الأنشطة التمويلية", data["financing"])

    rows.append({"account_no": "", "account_name": "صافي التدفق النقدي من الأنشطة",
                 "inflow": "", "outflow": "", "net": data["net_from_activities"]})
    rows.append({"account_no": "", "account_name": "النقدية في بداية الفترة",
                 "inflow": "", "outflow": "", "net": data["total_opening"]})

    totals_row = {
        "account_no": "",
        "account_name": "النقدية في نهاية الفترة",
        "inflow": "", "outflow": "",
        "net": data["total_ending"],
    }
    meta = [
        ("الفرع", data["branch"]["name"]),
        ("الدورة", data["period"]["disc"]),
        ("من", data["date_from"]),
        ("إلى", data["date_to"]),
        ("حسابات النقدية", ", ".join(a["account_name"] for a in data["cash_accounts"])),
        ("التحقّق", "متوازن" if data["reconciles"] else ("غير متوازن (فرق %.2f)" % data["difference"])),
    ]
    fname = "cash_flow_%s.xlsx" % data["date_to"]
    return acc_export.xlsx_response(
        response, fname,
        title="قائمة التدفقات النقدية",
        meta=meta, columns=columns, rows=rows, totals=totals_row,
        sheet_name="التدفقات النقدية",
    )
