# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_account_api — كشوف الحساب:
- acount_balanc    — كشف حساب واحد + رصيد متحرّك
- acount_balanc_2  — كشف عدة حسابات (block per account)
- acount_balanc_3  — ملخص إجماليات حسابات (صف لكل حساب)

استُخرج من reports_api.py في Phase 2.2 (2026-05-25).
يعتمد على modules/acc_balance لمنطق الكشف نفسه.
"""

from datetime import datetime

from applications.acc.modules import acc_balance, acc_export


# helper shim للتوافق مع كود acount_balanc_2/3
def _build_account_statement(branch_id, period_id, account_id, date_from, date_to):
    return acc_balance.build_account_statement(
        db, branch_id, period_id, account_id, date_from, date_to,
    )


@auth.requires(can_view)
def acount_balanc():
    """كشف حساب — حركة حساب واحد عبر فترة مع رصيد متحرّك.

    عقد جديد (يستبدل القديم):
      branch     — id الفرع (مطلوب)
      period     — id الدورة (مطلوب — يحدد منها الافتتاحي والـ scope)
      account_id — id الحساب في accounting_tree (مطلوب)
      date_from  — YYYY-MM-DD (اختياري — افتراضي: بداية الدورة)
      date_to    — YYYY-MM-DD (اختياري — افتراضي: نهاية الدورة)

    الرد:
      {err, account, opening, movements, totals, health}
    """
    try:
        v = request.vars
        try:
            branch_id = int(v.get("branch") or v.get("branch_select") or 0)
            account_id = int(v.get("account_id") or 0)
        except Exception:
            return response.json({"err": 1, "mess": "قيمة فرع/حساب غير صحيحة"})
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})
        if account_id <= 0:
            return response.json({"err": 1, "mess": "اختر الحساب"})

        acc = db.accounting_tree[account_id]
        if not acc:
            return response.json({"err": 1, "mess": "الحساب غير موجود"})
        if int(acc.branches) != branch_id:
            return response.json({"err": 1, "mess": "الحساب لا يتبع الفرع المحدد"})
        account_no = acc.account_no
        like_pat = account_no + "%"

        try:
            period_id = int(v.get("period") or 0)
        except Exception:
            period_id = 0
        if period_id <= 0:
            period_id = int(acc.account_periods or 0)
        if period_id <= 0:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة مالية"})
            period_id = per.id
        period = db.account_periods[period_id]
        if not period:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})

        date_from = None
        date_to = None
        if v.get("date_from"):
            try:
                date_from = datetime.strptime(str(v.get("date_from"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if v.get("date_to"):
            try:
                date_to = datetime.strptime(str(v.get("date_to"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if not date_from:
            date_from = period.start_date
        if not date_to:
            date_to = period.end_date

        parent_name = ""
        if acc.main_account and acc.main_account != "0":
            pr = db(
                (db.accounting_tree.account_no == acc.main_account)
                & (db.accounting_tree.branches == branch_id)
                & (db.accounting_tree.account_periods == period_id)
            ).select().first()
            if pr:
                parent_name = pr.account_name_ar or ""

        children_count = db(
            (db.accounting_tree.main_account == account_no)
            & (db.accounting_tree.branches == branch_id)
            & (db.accounting_tree.account_periods == period_id)
        ).count()

        opening_rows = db.executesql(
            "SELECT COALESCE(SUM(debit),0)::float, COALESCE(SUM(credit),0)::float "
            "FROM account_periods_opening "
            "WHERE branches = %s AND account_periods = %s AND account_no LIKE %s",
            placeholders=[branch_id, period_id, like_pat],
        )
        open_debit_raw = float(opening_rows[0][0] or 0) if opening_rows else 0.0
        open_credit_raw = float(opening_rows[0][1] or 0) if opening_rows else 0.0

        pre_rows = db.executesql(
            "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            "WHERE jem.is_active = 'T' "
            "  AND jed.branches = %s AND jed.account_periods = %s "
            "  AND jed.account_no LIKE %s "
            "  AND jed.journal_date < %s",
            placeholders=[branch_id, period_id, like_pat, str(date_from)],
        )
        pre_debit = float(pre_rows[0][0] or 0) if pre_rows else 0.0
        pre_credit = float(pre_rows[0][1] or 0) if pre_rows else 0.0

        total_pre_debit = open_debit_raw + pre_debit
        total_pre_credit = open_credit_raw + pre_credit
        opening_net = round(total_pre_debit - total_pre_credit, 2)
        if opening_net >= 0:
            opening_debit_display = round(opening_net, 2)
            opening_credit_display = 0.0
        else:
            opening_debit_display = 0.0
            opening_credit_display = round(-opening_net, 2)

        movements_raw = db.executesql(
            "SELECT jed.id, jed.journal_entry_master, jed.journal_date, "
            "       jed.account_no, jed.debit::float, jed.credit::float, "
            "       jed.detail, jed.cost_center, "
            "       jem.journal_detail AS master_detail, "
            "       jem.journal_save AS master_save, "
            "       at.account_name_ar, at.main_account "
            "FROM journal_entry_detail jed "
            "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
            "LEFT JOIN accounting_tree at ON at.id = jed.accounting_tree "
            "WHERE jem.is_active = 'T' "
            "  AND jed.branches = %s AND jed.account_periods = %s "
            "  AND jed.account_no LIKE %s "
            "  AND jed.journal_date >= %s AND jed.journal_date <= %s "
            "ORDER BY jed.journal_date, jed.journal_entry_master, jed.id",
            placeholders=[branch_id, period_id, like_pat, str(date_from), str(date_to)],
            as_dict=True,
        )

        all_main_nos = list({r["main_account"] for r in movements_raw
                            if r.get("main_account") and r["main_account"] != "0"})
        parent_map = {}
        if all_main_nos:
            for p in db(
                (db.accounting_tree.account_no.belongs(all_main_nos))
                & (db.accounting_tree.branches == branch_id)
                & (db.accounting_tree.account_periods == period_id)
            ).select(db.accounting_tree.account_no, db.accounting_tree.account_name_ar):
                parent_map[p.account_no] = p.account_name_ar or ""

        cc_ids = list({int(r["cost_center"]) for r in movements_raw if r.get("cost_center")})
        cc_map = {}
        if cc_ids:
            for c in db(db.key_cost_center.id.belongs(cc_ids)).select(
                db.key_cost_center.id, db.key_cost_center.name
            ):
                cc_map[int(c.id)] = c.name

        running = opening_net
        total_debit = 0.0
        total_credit = 0.0
        movements = []
        for r in movements_raw:
            d = float(r["debit"] or 0)
            c = float(r["credit"] or 0)
            running = round(running + d - c, 2)
            total_debit += d
            total_credit += c
            par_name = parent_map.get(r["main_account"], "") if r.get("main_account") else ""
            full_name = r["account_name_ar"] or ""
            if par_name:
                full_name = par_name + " > " + full_name
            movements.append({
                "id": int(r["id"]),
                "journal_id": int(r["journal_entry_master"]),
                "journal_date": str(r["journal_date"]) if r["journal_date"] else None,
                "account_no": r["account_no"],
                "account_name": full_name,
                "detail": r["detail"] or "",
                "master_detail": r["master_detail"] or "",
                "master_save": r["master_save"] or "",
                "debit": round(d, 2),
                "credit": round(c, 2),
                "cost_center_name": cc_map.get(int(r["cost_center"])) if r.get("cost_center") else "",
                "running_balance": running,
            })

        total_debit = round(total_debit, 2)
        total_credit = round(total_credit, 2)
        final_net = round(opening_net + total_debit - total_credit, 2)
        if final_net >= 0:
            final_debit_display = round(final_net, 2)
            final_credit_display = 0.0
        else:
            final_debit_display = 0.0
            final_credit_display = round(-final_net, 2)

        result = {
            "err": 0,
            "account": {
                "id": int(acc.id),
                "account_no": acc.account_no,
                "account_name": acc.account_name_ar or "",
                "parent_name": parent_name,
                "main_account": acc.main_account or "0",
                "account_type": int(acc.account_type or 0),
                "final_account": int(acc.final_account or 0),
                "children_count": int(children_count or 0),
                "is_rolled": int(children_count or 0) > 0,
            },
            "branch": {"id": int(branch_id), "name": (db.branches[branch_id].name if db.branches[branch_id] else "—")},
            "period": {
                "id": int(period_id), "disc": period.disc,
                "open_period": int(period.open_period or 0),
                "start_date": str(period.start_date),
                "end_date": str(period.end_date),
            },
            "date_from": str(date_from), "date_to": str(date_to),
            "opening": {
                "debit": opening_debit_display,
                "credit": opening_credit_display,
                "net": round(opening_net, 2),
                "raw_debit": round(total_pre_debit, 2),
                "raw_credit": round(total_pre_credit, 2),
            },
            "movements": movements,
            "totals": {
                "debit": total_debit,
                "credit": total_credit,
                "net_movement": round(total_debit - total_credit, 2),
                "count": len(movements),
            },
            "ending": {
                "debit": final_debit_display,
                "credit": final_credit_display,
                "net": final_net,
            },
            "health": {
                "running_matches": (not movements) or abs(movements[-1]["running_balance"] - final_net) < 0.005,
            },
        }
        if str(v.get("format") or "").lower() == "xlsx":
            return _account_report_xlsx(result)
        return response.json(result)
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


def _account_report_xlsx(data):
    """يحوّل ردّ acount_balanc إلى xlsx — كشف حركة حساب واحد."""
    columns = [
        {"key": "journal_date", "title": "التاريخ", "format": "text", "width": 12},
        {"key": "journal_id", "title": "رقم القيد", "format": "number", "width": 10},
        {"key": "account_no", "title": "حساب فرعي", "format": "text", "width": 14},
        {"key": "account_name", "title": "الحساب", "format": "text", "width": 26},
        {"key": "detail", "title": "البيان", "format": "text", "width": 30},
        {"key": "cost_center", "title": "مركز التكلفة", "format": "text", "width": 14},
        {"key": "debit", "title": "مدين", "format": "currency"},
        {"key": "credit", "title": "دائن", "format": "currency"},
        {"key": "running_balance", "title": "الرصيد", "format": "currency"},
    ]
    opening = data["opening"]
    rows = [{
        "journal_date": data["date_from"],
        "journal_id": "",
        "account_no": "",
        "account_name": "",
        "detail": "رصيد افتتاحي",
        "cost_center": "",
        "debit": opening["debit"],
        "credit": opening["credit"],
        "running_balance": opening["net"],
    }]
    for m in data["movements"]:
        rows.append({
            "journal_date": m.get("journal_date") or "",
            "journal_id": m.get("journal_id") or "",
            "account_no": m.get("account_no") or "",
            "account_name": m.get("account_name") or "",
            "detail": (m.get("master_detail") or "") + (
                " | " + m.get("detail") if m.get("detail") else ""
            ),
            "cost_center": m.get("cost_center_name") or "",
            "debit": m.get("debit") or 0,
            "credit": m.get("credit") or 0,
            "running_balance": m.get("running_balance") or 0,
        })
    totals = data["totals"]
    ending = data["ending"]
    totals_row = {
        "journal_date": data["date_to"],
        "journal_id": "",
        "account_no": "",
        "account_name": "",
        "detail": "",
        "cost_center": "الإجمالي",
        "debit": totals["debit"],
        "credit": totals["credit"],
        "running_balance": ending["net"],
    }
    acc_info = data["account"]
    meta = [
        ("الحساب", acc_info["account_no"] + " — " + acc_info["account_name"]),
        ("الفرع", data["branch"]["name"]),
        ("الدورة", data["period"]["disc"]),
        ("من", data["date_from"]),
        ("إلى", data["date_to"]),
        ("عدد العمليات", totals["count"]),
    ]
    fname = "account_%s_%s.xlsx" % (
        acc_info["account_no"].replace("/", "_"), data["date_to"],
    )
    return acc_export.xlsx_response(
        response, fname,
        title="كشف حساب — " + (acc_info["account_name"] or acc_info["account_no"]),
        meta=meta,
        columns=columns,
        rows=rows,
        totals=totals_row,
        sheet_name="كشف حساب",
    )


@auth.requires(can_view)
def acount_balanc_2():
    """كشف حساب متعدّد — يجمع كشوفات عدة حسابات في تقرير واحد.

    Body:
      branch, period (مطلوبان)
      account_ids — list[int]  أو CSV string لـ IDs
      date_from, date_to — YYYY-MM-DD (اختياري)

    Returns:
      {err, branch, period, date_from, date_to, entries: [...account-statements...],
       totals: {debit, credit, net_movement, count},
       opening_total: {debit, credit}, ending_total: {debit, credit}}
    """
    try:
        v = request.vars
        try:
            branch_id = int(v.get("branch") or 0)
            period_id = int(v.get("period") or 0)
        except Exception:
            return response.json({"err": 1, "mess": "قيمة فرع/دورة غير صحيحة"})
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})

        raw_ids = v.get("account_ids")
        if raw_ids is None:
            return response.json({"err": 1, "mess": "اختر حساباً واحداً على الأقل"})
        if isinstance(raw_ids, str):
            account_ids = [int(x) for x in raw_ids.split(",") if x.strip().isdigit()]
        elif isinstance(raw_ids, list):
            account_ids = []
            for x in raw_ids:
                try:
                    account_ids.append(int(x))
                except Exception:
                    pass
        else:
            account_ids = []
        if not account_ids:
            return response.json({"err": 1, "mess": "اختر حساباً واحداً على الأقل"})

        if period_id <= 0:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة"})
            period_id = per.id
        period = db.account_periods[period_id]
        if not period:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        branch = db.branches[branch_id]
        if not branch:
            return response.json({"err": 1, "mess": "الفرع غير موجود"})

        date_from = None
        date_to = None
        if v.get("date_from"):
            try:
                date_from = datetime.strptime(str(v.get("date_from"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if v.get("date_to"):
            try:
                date_to = datetime.strptime(str(v.get("date_to"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if not date_from:
            date_from = period.start_date
        if not date_to:
            date_to = period.end_date

        entries = []
        sum_open_debit = 0.0
        sum_open_credit = 0.0
        sum_period_debit = 0.0
        sum_period_credit = 0.0
        sum_end_debit = 0.0
        sum_end_credit = 0.0
        sum_movements_count = 0
        for aid in account_ids:
            st = _build_account_statement(branch_id, period_id, aid, date_from, date_to)
            if st is None:
                continue
            entries.append(st)
            sum_open_debit += st["opening"]["debit"]
            sum_open_credit += st["opening"]["credit"]
            sum_period_debit += st["totals"]["debit"]
            sum_period_credit += st["totals"]["credit"]
            sum_end_debit += st["ending"]["debit"]
            sum_end_credit += st["ending"]["credit"]
            sum_movements_count += st["totals"]["count"]

        return response.json({
            "err": 0,
            "branch": {"id": branch.id, "name": branch.name},
            "period": {
                "id": period.id, "disc": period.disc,
                "open_period": int(period.open_period or 0),
                "start_date": str(period.start_date),
                "end_date": str(period.end_date),
            },
            "date_from": str(date_from), "date_to": str(date_to),
            "entries": entries,
            "totals": {
                "debit": round(sum_period_debit, 2),
                "credit": round(sum_period_credit, 2),
                "net_movement": round(sum_period_debit - sum_period_credit, 2),
                "count": sum_movements_count,
                "accounts_count": len(entries),
            },
            "opening_total": {
                "debit": round(sum_open_debit, 2),
                "credit": round(sum_open_credit, 2),
            },
            "ending_total": {
                "debit": round(sum_end_debit, 2),
                "credit": round(sum_end_credit, 2),
            },
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_view)
def acount_balanc_3():
    """إجماليات مخصص — ملخص أرصدة لحسابات مختارة (صف واحد لكل حساب).
    يعيد استخدام helper `_build_account_statement` ويتجاهل movements.
    """
    try:
        v = request.vars
        try:
            branch_id = int(v.get("branch") or 0)
            period_id = int(v.get("period") or 0)
        except Exception:
            return response.json({"err": 1, "mess": "قيمة فرع/دورة غير صحيحة"})
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})

        raw_ids = v.get("account_ids")
        if raw_ids is None:
            return response.json({"err": 1, "mess": "اختر حساباً واحداً على الأقل"})
        if isinstance(raw_ids, str):
            account_ids = [int(x) for x in raw_ids.split(",") if x.strip().isdigit()]
        elif isinstance(raw_ids, list):
            account_ids = []
            for x in raw_ids:
                try:
                    account_ids.append(int(x))
                except Exception:
                    pass
        else:
            account_ids = []
        if not account_ids:
            return response.json({"err": 1, "mess": "اختر حساباً واحداً على الأقل"})

        if period_id <= 0:
            per = db(db.account_periods.open_period == 1).select(
                orderby=db.account_periods.id
            ).first()
            if not per:
                return response.json({"err": 1, "mess": "لا توجد دورة"})
            period_id = per.id
        period = db.account_periods[period_id]
        if not period:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        branch = db.branches[branch_id]
        if not branch:
            return response.json({"err": 1, "mess": "الفرع غير موجود"})

        date_from = None
        date_to = None
        if v.get("date_from"):
            try:
                date_from = datetime.strptime(str(v.get("date_from"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if v.get("date_to"):
            try:
                date_to = datetime.strptime(str(v.get("date_to"))[:10], "%Y-%m-%d").date()
            except Exception:
                pass
        if not date_from:
            date_from = period.start_date
        if not date_to:
            date_to = period.end_date

        items = []
        grand = {
            "open_debit": 0.0, "open_credit": 0.0,
            "mov_debit": 0.0, "mov_credit": 0.0,
            "close_debit": 0.0, "close_credit": 0.0,
        }
        for aid in account_ids:
            st = _build_account_statement(branch_id, period_id, aid, date_from, date_to)
            if st is None:
                continue
            items.append({
                "account": st["account"],
                "opening": st["opening"],
                "totals": st["totals"],
                "ending": st["ending"],
            })
            grand["open_debit"] += st["opening"]["debit"]
            grand["open_credit"] += st["opening"]["credit"]
            grand["mov_debit"] += st["totals"]["debit"]
            grand["mov_credit"] += st["totals"]["credit"]
            grand["close_debit"] += st["ending"]["debit"]
            grand["close_credit"] += st["ending"]["credit"]
        for k in grand:
            grand[k] = round(grand[k], 2)
        grand["mov_diff"] = round(grand["mov_debit"] - grand["mov_credit"], 2)

        return response.json({
            "err": 0,
            "branch": {"id": branch.id, "name": branch.name},
            "period": {
                "id": period.id, "disc": period.disc,
                "open_period": int(period.open_period or 0),
                "start_date": str(period.start_date),
                "end_date": str(period.end_date),
            },
            "date_from": str(date_from), "date_to": str(date_to),
            "items": items,
            "grand": grand,
            "count": len(items),
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
