# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_diag — تشخيصات سلامة البيانات المحاسبية.

ملف صغير منفصل عن reports_api.py لاحترام قاعدة 600 سطر للملف الواحد،
ولأن هذه الـ endpoints تهدف للتدقيق وليس لعرض التقارير العادية.

Endpoints:
- unbalanced_journals  — يرجع القيود غير المتوازنة بأنواعها الثلاثة:
    * lines_diff: مجموع المدين في السطور ≠ مجموع الدائن في السطور
    * master_vs_detail: مجاميع الرأس ≠ مجاميع السطور (مثل القيد #32)
    * both: الاثنين معاً
"""

import json

# طبقة الخدمة المشتركة في modules/ — استخراج Phase 2
from applications.acc.modules import acc_periods, acc_dates


@auth.requires(can_view)
def unbalanced_journals():
    """يرجع كل القيود المختلّة (active فقط) عبر كل الدورات افتراضياً.

    Body / vars (كلها اختيارية — بلا فلاتر يفحص النظام كلّه):
      branch     — id الفرع
      period     — id الدورة
      date_from  — YYYY-MM-DD
      date_to    — YYYY-MM-DD

    الرد:
      { err, entries: [...], stats: {...}, count }
    """
    try:
        # قراءة المتغيرات (POST body JSON أو form vars)
        try:
            if request.body and request.body.read(1):
                request.body.seek(0)
                payload = json.loads(request.body.read().decode("utf-8") or "{}")
            else:
                payload = {}
        except Exception:
            payload = {}
        v = dict(request.vars or {})
        v.update(payload)

        def _int_or_none(x):
            try:
                n = int(x)
                return n if n > 0 else None
            except Exception:
                return None

        branch_id = _int_or_none(v.get("branch"))
        period_id = _int_or_none(v.get("period"))
        # تحقّق من صيغة التاريخ (لا يكسر إن كان فارغاً — الفلتر اختياري)
        df = acc_dates.parse_iso(v.get("date_from"))
        dt = acc_dates.parse_iso(v.get("date_to"))
        date_from = acc_dates.to_iso(df)
        date_to = acc_dates.to_iso(dt)

        # بناء WHERE بأمان (positional placeholders كباقي الكود)
        where = ["jem.is_active = 'T'"]
        params = []
        if branch_id:
            where.append("jem.branches = %s")
            params.append(branch_id)
        if period_id:
            where.append("jem.account_periods = %s")
            params.append(period_id)
        if date_from:
            where.append("jem.journal_date >= %s")
            params.append(date_from)
        if date_to:
            where.append("jem.journal_date <= %s")
            params.append(date_to)
        where_sql = " AND ".join(where)

        sql = (
            "SELECT jem.id, jem.journal_date, jem.branches AS branch_id, "
            "       jem.account_periods AS period_id, "
            "       jem.debit_total, jem.credit_total, jem.journal_detail, "
            "       COUNT(jed.id) AS line_count, "
            "       ROUND(CAST(COALESCE(SUM(jed.debit),0) AS numeric), 2) AS sum_debit, "
            "       ROUND(CAST(COALESCE(SUM(jed.credit),0) AS numeric), 2) AS sum_credit "
            "FROM journal_entry_master jem "
            "LEFT JOIN journal_entry_detail jed ON jed.journal_entry_master = jem.id "
            f"WHERE {where_sql} "
            "GROUP BY jem.id, jem.journal_date, jem.branches, jem.account_periods, "
            "         jem.debit_total, jem.credit_total, jem.journal_detail "
            "HAVING ROUND(CAST(COALESCE(SUM(jed.debit),0) AS numeric), 2) "
            "       <> ROUND(CAST(COALESCE(SUM(jed.credit),0) AS numeric), 2) "
            "   OR  ROUND(CAST(COALESCE(SUM(jed.debit),0) AS numeric), 2) "
            "       <> ROUND(CAST(COALESCE(jem.debit_total,0) AS numeric), 2) "
            "   OR  ROUND(CAST(COALESCE(SUM(jed.credit),0) AS numeric), 2) "
            "       <> ROUND(CAST(COALESCE(jem.credit_total,0) AS numeric), 2) "
            "ORDER BY jem.journal_date DESC, jem.id DESC"
        )
        rows = db.executesql(sql, placeholders=params, as_dict=True)

        # خرائط مراجع
        branches = {b.id: b.name for b in db(db.branches).select(db.branches.id, db.branches.name)}
        periods = {
            p.id: {"disc": p.disc, "open_period": int(p.open_period or 0)}
            for p in db(db.account_periods).select(
                db.account_periods.id, db.account_periods.disc, db.account_periods.open_period
            )
        }

        entries = []
        n_lines_diff = 0
        n_master_diff = 0
        n_both = 0
        n_empty = 0
        for r in rows:
            sd = float(r["sum_debit"] or 0)
            sc = float(r["sum_credit"] or 0)
            md = float(r["debit_total"] or 0)
            mc = float(r["credit_total"] or 0)
            issues = []
            if round(sd, 2) != round(sc, 2):
                issues.append("lines_diff")
            if round(sd, 2) != round(md, 2) or round(sc, 2) != round(mc, 2):
                issues.append("master_vs_detail")
            if int(r["line_count"] or 0) == 0:
                issues.append("empty_detail")
                n_empty += 1
            if "lines_diff" in issues and "master_vs_detail" in issues:
                n_both += 1
            elif "lines_diff" in issues:
                n_lines_diff += 1
            elif "master_vs_detail" in issues:
                n_master_diff += 1

            per = periods.get(int(r["period_id"] or 0), {})
            entries.append({
                "id": int(r["id"]),
                "date": str(r["journal_date"]) if r["journal_date"] else None,
                "branch_id": int(r["branch_id"] or 0),
                "branch_name": branches.get(int(r["branch_id"] or 0), "—"),
                "period_id": int(r["period_id"] or 0),
                "period_disc": per.get("disc", "—"),
                "period_open": per.get("open_period", 0) == 1,
                "disc": r.get("journal_detail") or "",
                "line_count": int(r["line_count"] or 0),
                "master_debit": md,
                "master_credit": mc,
                "sum_debit": sd,
                "sum_credit": sc,
                "lines_diff_amount": round(sd - sc, 2),
                "master_vs_lines_debit": round(md - sd, 2),
                "master_vs_lines_credit": round(mc - sc, 2),
                "issues": issues,
            })

        stats = {
            "total": len(entries),
            "lines_diff_only": n_lines_diff,
            "master_vs_detail_only": n_master_diff,
            "both": n_both,
            "empty_detail": n_empty,
        }
        return response.json({"err": 0, "entries": entries, "stats": stats, "count": len(entries)})
    except Exception as e:
        try:
            db.err_report.insert(er_dis=str(e), screen_dis="reports_diag.unbalanced_journals")
            db.commit()
        except Exception:
            pass
        return response.json({"err": 1, "mess": str(e)})
