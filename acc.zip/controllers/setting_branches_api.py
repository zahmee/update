# -*- coding: utf-8 -*-
# type: ignore
"""
setting_branches_api — إدارة الفروع (Branches).

استُخرج من setting_api.py في Phase 2.3 (2026-05-25).
"""


@auth.requires(can_view)
def get_all_branches():
    q = db(db.branches.show_row == 1).select(db.branches.ALL, orderby=db.branches.id)
    return response.json(q)


@auth.requires(can_view)
def get_all_branchesA():
    q = db(db.branches.id > 0).select(db.branches.ALL, orderby=db.branches.id)
    return response.json(q)


def _validate_branch(row, branch_id=None):
    """التحقق من صحة بيانات الفرع — يُرجع رسالة الخطأ أو None."""
    name = (row.get("name") or "").strip()
    code = (row.get("code") or "").strip()
    email = (row.get("email") or "").strip()
    if not name:
        return "اسم الفرع مطلوب"
    if not code:
        return "رمز الفرع مطلوب"
    if email and ("@" not in email or "." not in email.split("@")[-1]):
        return "صيغة البريد الإلكتروني غير صحيحة"
    dup_name = db.branches.name == name
    dup_code = db.branches.code == code
    if branch_id:
        dup_name &= db.branches.id != branch_id
        dup_code &= db.branches.id != branch_id
    if db(dup_name).count() > 0:
        return "اسم الفرع مستخدم مسبقاً لفرع آخر"
    if db(dup_code).count() > 0:
        return "رمز الفرع مستخدم مسبقاً لفرع آخر"
    return None


def _branch_fields(row):
    return dict(
        code=(row.get("code") or "").strip(),
        name=(row.get("name") or "").strip(),
        manager=(row.get("manager") or "").strip(),
        site=(row.get("site") or "").strip(),
        contact=(row.get("contact") or "").strip(),
        email=(row.get("email") or "").strip(),
        vat_no=(row.get("vat_no") or "").strip(),
        cr_no=(row.get("cr_no") or "").strip(),
        is_main=int(row.get("is_main") or 2),
        show_row=int(row.get("show_row") or 1),
    )


@auth.requires(can_account)
def add_branches():
    try:
        row = request.vars
        err = _validate_branch(row)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        fields = _branch_fields(row)
        nid = db.branches.insert(**fields)
        if fields["is_main"] == 1:
            db(db.branches.id != nid).update(is_main=2)
        db.commit()
        return response.json({"err": 0, "id": nid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def update_branches():
    try:
        row = request.vars
        bid = row.get("id")
        rec = db.branches[bid] if bid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "الفرع غير موجود"})
        err = _validate_branch(row, branch_id=bid)
        if err:
            return response.json({"err": 1, "id": 0, "mess": err})
        fields = _branch_fields(row)
        rec.update_record(**fields)
        if fields["is_main"] == 1:
            db(db.branches.id != bid).update(is_main=2)
        db.commit()
        return response.json({"err": 0, "id": bid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})


@auth.requires(can_account)
def delete_branches():
    try:
        bid = request.vars.get("id")
        rec = db.branches[bid] if bid else None
        if not rec:
            return response.json({"err": 1, "id": 0, "mess": "الفرع غير موجود"})
        used = (
            db(db.journal_entry_master.branches == bid).count()
            + db(db.journal_entry_detail.branches == bid).count()
            + db(db.accounting_tree.branches == bid).count()
            + db(db.account_periods_opening.branches == bid).count()
        )
        if used > 0:
            return response.json({
                "err": 2, "id": 0,
                "mess": "لا يمكن حذف الفرع لارتباطه بـ %d سجل في النظام. أوقف عرضه بدلاً من حذفه." % used,
            })
        rec.delete_record()
        db.commit()
        return response.json({"err": 0, "id": bid, "mess": "0"})
    except Exception as e:
        db.rollback()
        print(e)
        return response.json({"err": 3, "id": 0, "mess": str(e)})
