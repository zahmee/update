# -*- coding: utf-8 -*-
#  type: ignore
"""
reports_branches_api — تقارير مقارنة الحسابات بين الفروع.

Endpoints:
- account_branches_matrix — يخدم account_report_3_1 (مصفوفة حسابات × فروع)
- single_account_branches — يخدم branches_account_report_1_1 (حساب واحد بكل تفاصيل بكل فرع)

ملف منفصل عن reports_api.py لاحترام قاعدة 600 سطر للملف الواحد،
ويجمع منطق "العرض حسب الفرع" الذي يتشاركه الـ screen-ين.
"""

import json
from datetime import date

# طبقة الخدمة المشتركة في modules/ — استخراج Phase 2
from applications.acc.modules import acc_periods, acc_dates


def _parse_payload():
    """قراءة POST body JSON أو request.vars بشكل متسامح."""
    try:
        if request.body and request.body.read(1):
            request.body.seek(0)
            payload = json.loads(request.body.read().decode("utf-8") or "{}")
        else:
            payload = {}
    except Exception:
        payload = {}
    v = dict(request.vars or {})
    v.update(payload)
    return v


def _int_or_zero(x):
    try:
        return int(x)
    except Exception:
        return 0


def _account_meta(account_id):
    """ميتاداتا الحساب: id, account_no, account_name, branches, period_id, is_parent."""
    acc = db.accounting_tree[account_id]
    if not acc:
        return None
    children = db(
        (db.accounting_tree.main_account == acc.account_no)
        & (db.accounting_tree.branches == acc.branches)
        & (db.accounting_tree.account_periods == acc.account_periods)
    ).count()
    return {
        "id": int(acc.id),
        "account_no": acc.account_no,
        "account_name": acc.account_name_ar or "",
        "branch_id": int(acc.branches) if acc.branches else 0,
        "period_id": int(acc.account_periods) if acc.account_periods else 0,
        "is_parent": children > 0,
    }


def _branch_movement(period_id, account_no_like, branch_id, date_from, date_to):
    """مدين/دائن حساب (بنمط LIKE للتجميع الشجري) في فرع/فترة/مدى."""
    rows = db.executesql(
        "SELECT COALESCE(SUM(jed.debit),0)::float, COALESCE(SUM(jed.credit),0)::float "
        "FROM journal_entry_detail jed "
        "JOIN journal_entry_master jem ON jem.id = jed.journal_entry_master "
        "WHERE jem.is_active = 'T' "
        "  AND jem.account_periods = %s "
        "  AND jed.account_no LIKE %s "
        "  AND jed.branches = %s "
        "  AND jed.journal_date >= %s "
        "  AND jed.journal_date <= %s",
        placeholders=[period_id, account_no_like, branch_id, str(date_from), str(date_to)],
    )
    if not rows:
        return 0.0, 0.0
    return float(rows[0][0] or 0), float(rows[0][1] or 0)


def _branch_opening(period_id, account_no_like, branch_id):
    """افتتاحي حساب (بنمط LIKE) في فرع/فترة."""
    rows = db.executesql(
        "SELECT COALESCE(SUM(debit),0)::float, COALESCE(SUM(credit),0)::float "
        "FROM account_periods_opening "
        "WHERE account_periods = %s AND account_no LIKE %s AND branches = %s",
        placeholders=[period_id, account_no_like, branch_id],
    )
    if not rows:
        return 0.0, 0.0
    return float(rows[0][0] or 0), float(rows[0][1] or 0)


@auth.requires(can_view)
def account_branches_matrix():
    """مصفوفة [حسابات × فروع] — لكل (حساب، فرع) مدين/دائن/صافي.

    Body:
      period          — id الدورة (مطلوب)
      account_ids     — list من ids (مطلوب — على الأقل واحد)
      date_from/date_to — YYYY-MM-DD (اختياري — افتراضي مدى الدورة)
      include_opening — bool (افتراضي false)

    Return:
      { err, period, branches, accounts, grand_by_branch, grand }
    """
    try:
        v = _parse_payload()
        period_id = _int_or_zero(v.get("period"))
        if period_id <= 0:
            return response.json({"err": 1, "mess": "الدورة المالية مطلوبة"})
        per = acc_periods.get(db, period_id)
        if not per:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})

        # account_ids قد تأتي list أو CSV string
        raw_ids = v.get("account_ids") or v.get("accounts") or []
        if isinstance(raw_ids, str):
            raw_ids = [s.strip() for s in raw_ids.split(",") if s.strip()]
        account_ids = [int(x) for x in raw_ids if str(x).strip().isdigit()]
        if not account_ids:
            return response.json({"err": 1, "mess": "اختر حساباً واحداً على الأقل"})

        date_from = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_from"))) or str(per.start_date)
        date_to = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_to"))) or str(per.end_date)
        include_opening = bool(v.get("include_opening")) and str(v.get("include_opening")).lower() not in ("false", "0", "")

        # الفروع الفاعلة
        branches = [
            {"id": int(b.id), "name": b.name, "is_main": int(b.is_main or 0)}
            for b in db(db.branches.show_row == 1).select(orderby=db.branches.id)
        ]

        accounts_out = []
        grand_by_branch = {b["id"]: {"debit": 0.0, "credit": 0.0, "opening": 0.0} for b in branches}
        grand = {"debit": 0.0, "credit": 0.0, "opening": 0.0}

        for aid in account_ids:
            meta = _account_meta(aid)
            if not meta:
                continue
            like_pat = meta["account_no"] + "%"
            by_branch = {}
            acc_total = {"debit": 0.0, "credit": 0.0, "opening": 0.0}
            for b in branches:
                d, c = _branch_movement(period_id, like_pat, b["id"], date_from, date_to)
                op = 0.0
                if include_opening:
                    od, oc = _branch_opening(period_id, like_pat, b["id"])
                    op = round(od - oc, 2)
                by_branch[b["id"]] = {
                    "debit": round(d, 2),
                    "credit": round(c, 2),
                    "net": round(d - c, 2),
                    "opening": op,
                    "closing": round(op + d - c, 2),
                }
                acc_total["debit"] += d
                acc_total["credit"] += c
                acc_total["opening"] += op
                grand_by_branch[b["id"]]["debit"] += d
                grand_by_branch[b["id"]]["credit"] += c
                grand_by_branch[b["id"]]["opening"] += op
            grand["debit"] += acc_total["debit"]
            grand["credit"] += acc_total["credit"]
            grand["opening"] += acc_total["opening"]
            accounts_out.append({
                "id": meta["id"],
                "account_no": meta["account_no"],
                "account_name": meta["account_name"],
                "is_parent": meta["is_parent"],
                "home_branch_id": meta["branch_id"],
                "by_branch": by_branch,
                "total": {
                    "debit": round(acc_total["debit"], 2),
                    "credit": round(acc_total["credit"], 2),
                    "net": round(acc_total["debit"] - acc_total["credit"], 2),
                    "opening": round(acc_total["opening"], 2),
                    "closing": round(acc_total["opening"] + acc_total["debit"] - acc_total["credit"], 2),
                },
            })

        # تقريب الإجمالي
        for b in branches:
            gb = grand_by_branch[b["id"]]
            gb["debit"] = round(gb["debit"], 2)
            gb["credit"] = round(gb["credit"], 2)
            gb["opening"] = round(gb["opening"], 2)
            gb["net"] = round(gb["debit"] - gb["credit"], 2)
            gb["closing"] = round(gb["opening"] + gb["debit"] - gb["credit"], 2)
        grand["debit"] = round(grand["debit"], 2)
        grand["credit"] = round(grand["credit"], 2)
        grand["opening"] = round(grand["opening"], 2)
        grand["net"] = round(grand["debit"] - grand["credit"], 2)
        grand["closing"] = round(grand["opening"] + grand["debit"] - grand["credit"], 2)

        return response.json({
            "err": 0,
            "period": acc_periods.to_dict(per),
            "date_from": date_from, "date_to": date_to,
            "include_opening": include_opening,
            "branches": branches,
            "accounts": accounts_out,
            "grand_by_branch": grand_by_branch,
            "grand": grand,
        })
    except Exception as e:
        try:
            db.err_report.insert(er_dis=str(e), screen_dis="reports_branches_api.account_branches_matrix")
            db.commit()
        except Exception:
            pass
        return response.json({"err": 1, "mess": str(e)})


@auth.requires(can_view)
def single_account_branches():
    """حساب واحد بتفاصيل أعمق: لكل فرع → افتتاحي + حركة + ختامي.

    Body:
      period      — id الدورة (مطلوب)
      account_id  — id الحساب (مطلوب — يحدد account_no؛ سنطبّقه على كل الفروع)
      date_from/date_to — اختياري

    Return:
      { err, period, account, branches: [{branch, opening, movement, closing}], grand }
    """
    try:
        v = _parse_payload()
        period_id = _int_or_zero(v.get("period"))
        account_id = _int_or_zero(v.get("account_id"))
        if period_id <= 0:
            return response.json({"err": 1, "mess": "الدورة المالية مطلوبة"})
        if account_id <= 0:
            return response.json({"err": 1, "mess": "الحساب مطلوب"})
        per = acc_periods.get(db, period_id)
        if not per:
            return response.json({"err": 1, "mess": "الدورة غير موجودة"})
        meta = _account_meta(account_id)
        if not meta:
            return response.json({"err": 1, "mess": "الحساب غير موجود"})

        date_from = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_from"))) or str(per.start_date)
        date_to = acc_dates.to_iso(acc_dates.parse_iso(v.get("date_to"))) or str(per.end_date)
        like_pat = meta["account_no"] + "%"

        branches_rows = db(db.branches.show_row == 1).select(orderby=db.branches.id)
        branches_out = []
        grand = {"open_debit": 0.0, "open_credit": 0.0,
                 "mov_debit": 0.0, "mov_credit": 0.0,
                 "close_debit": 0.0, "close_credit": 0.0,
                 "active_branches": 0}

        for b in branches_rows:
            od, oc = _branch_opening(period_id, like_pat, int(b.id))
            md, mc = _branch_movement(period_id, like_pat, int(b.id), date_from, date_to)
            opening_net = round(od - oc, 2)
            mov_net = round(md - mc, 2)
            closing_net = round(opening_net + mov_net, 2)
            close_debit = closing_net if closing_net > 0 else 0.0
            close_credit = -closing_net if closing_net < 0 else 0.0
            has_activity = (od or oc or md or mc)
            if has_activity:
                grand["active_branches"] += 1
            branches_out.append({
                "branch_id": int(b.id), "branch_name": b.name,
                "is_main": int(b.is_main or 0) == 1,
                "open_debit": round(od, 2), "open_credit": round(oc, 2),
                "opening_net": opening_net,
                "mov_debit": round(md, 2), "mov_credit": round(mc, 2),
                "mov_net": mov_net,
                "close_debit": round(close_debit, 2),
                "close_credit": round(close_credit, 2),
                "closing_net": closing_net,
                "has_activity": bool(has_activity),
            })
            grand["open_debit"] += od
            grand["open_credit"] += oc
            grand["mov_debit"] += md
            grand["mov_credit"] += mc
            grand["close_debit"] += close_debit
            grand["close_credit"] += close_credit

        for k in ("open_debit", "open_credit", "mov_debit", "mov_credit", "close_debit", "close_credit"):
            grand[k] = round(grand[k], 2)
        grand["opening_net"] = round(grand["open_debit"] - grand["open_credit"], 2)
        grand["mov_net"] = round(grand["mov_debit"] - grand["mov_credit"], 2)
        grand["closing_net"] = round(grand["close_debit"] - grand["close_credit"], 2)

        return response.json({
            "err": 0,
            "period": acc_periods.to_dict(per),
            "date_from": date_from, "date_to": date_to,
            "account": meta,
            "branches": branches_out,
            "grand": grand,
        })
    except Exception as e:
        try:
            db.err_report.insert(er_dis=str(e), screen_dis="reports_branches_api.single_account_branches")
            db.commit()
        except Exception:
            pass
        return response.json({"err": 1, "mess": str(e)})
