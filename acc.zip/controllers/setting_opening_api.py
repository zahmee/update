# -*- coding: utf-8 -*-
# type: ignore
"""
setting_opening_api — الأرصدة الافتتاحية (Opening Balances).

استُخرج من setting_api.py في Phase 2.3 (2026-05-25).
"""

import json

from applications.acc.modules import acc_carry_forward, acc_periods


_resolve_period = lambda arg: acc_periods.resolve(db, arg)


def _sync_opening_rows(period_id, branch_id):
    """تنظيف وزيادة سجلات account_periods_opening للثلاثية (دورة، فرع):
    - حذف سجلات لحسابات لم تعد موجودة في الشجرة.
    - إضافة سجلات بصفر لكل حساب موجود في الشجرة ولا يوجد له سجل افتتاحي.
    لا يلمس القيم الموجودة."""
    db.executesql(
        "DELETE FROM account_periods_opening "
        "WHERE account_periods = %s AND branches = %s "
        "  AND account_no NOT IN ( "
        "    SELECT account_no FROM accounting_tree "
        "    WHERE branches = %s AND account_periods = %s )",
        placeholders=[period_id, branch_id, branch_id, period_id],
    )
    missing = db.executesql(
        "SELECT account_no, main_account FROM accounting_tree "
        "WHERE account_periods = %s AND branches = %s "
        "  AND account_no NOT IN ( "
        "    SELECT account_no FROM account_periods_opening "
        "    WHERE account_periods = %s AND branches = %s )",
        placeholders=[period_id, branch_id, period_id, branch_id],
        as_dict=True,
    )
    for row in missing:
        db.account_periods_opening.insert(
            account_periods=period_id,
            branches=branch_id,
            account_no=row["account_no"],
            main_account=row["main_account"],
            credit=0,
            debit=0,
            export=False,
        )
    db.commit()


@auth.requires(can_view)
def get_opening_periods_balance():
    """يُرجع صفوف الأرصدة الافتتاحية للورقية (الحسابات النهائية) لفرع ودورة.
    الاستدعاء: /get_opening_periods_balance/<branch>/[<period>]
    إن لم تُمرّر الدورة تُختار أول دورة مفتوحة."""
    try:
        branch_id = int(request.args(0) or 0)
        if branch_id <= 0:
            return response.json({"err": 1, "mess": "الفرع مطلوب"})
        per = _resolve_period(request.args(1))
        if not per:
            return response.json({"err": 1, "mess": "لا توجد دورة مالية"})
        _sync_opening_rows(per.id, branch_id)
        rows = db.executesql(
            "SELECT apo.id, apo.account_periods, apo.branches, apo.account_no, "
            "       apo.main_account, apo.credit, apo.debit, apo.export, "
            "       apo.carried_from_period, "
            "       at.account_name_ar, at.account_name_en, "
            "       at.account_type, at.final_account, at.show_account, "
            "       cf.disc AS carried_from_disc, "
            "       (SELECT account_name_ar FROM accounting_tree "
            "          WHERE branches = apo.branches "
            "            AND account_periods = apo.account_periods "
            "            AND account_no = apo.main_account LIMIT 1) AS parent_name "
            "FROM account_periods_opening apo "
            "LEFT JOIN accounting_tree at "
            "  ON at.account_no = apo.account_no "
            " AND at.branches = apo.branches "
            " AND at.account_periods = apo.account_periods "
            "LEFT JOIN account_periods cf ON cf.id = apo.carried_from_period "
            "WHERE apo.account_periods = %s AND apo.branches = %s "
            "  AND apo.account_no NOT IN ( "
            "    SELECT main_account FROM accounting_tree "
            "    WHERE branches = %s AND account_periods = %s "
            "      AND main_account IS NOT NULL ) "
            "ORDER BY apo.account_no",
            placeholders=[per.id, branch_id, branch_id, per.id],
            as_dict=True,
        )
        for r in rows:
            r["debit"] = float(r["debit"] or 0)
            r["credit"] = float(r["credit"] or 0)
            r["account_name"] = (r["account_name_ar"] or r["account_no"] or "")
            if r.get("parent_name"):
                r["display_name"] = r["parent_name"] + " ‹ " + r["account_name"]
            else:
                r["display_name"] = r["account_name"]
        return response.json({
            "err": 0,
            "rows": rows,
            "period": {
                "id": per.id,
                "disc": per.disc,
                "open_period": int(per.open_period or 0),
                "start_date": str(per.start_date) if per.start_date else None,
                "end_date": str(per.end_date) if per.end_date else None,
            },
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


def _coerce_amount(v):
    """يُحوّل قيمة مالية إلى float — يرفض السالب والقيم غير الرقمية."""
    if v in (None, "", "null", "undefined"):
        return 0.0
    try:
        x = float(v)
    except Exception:
        raise ValueError("قيمة غير رقمية")
    if x < 0:
        raise ValueError("لا يُسمح بقيمة سالبة")
    if x > 1e12:
        raise ValueError("القيمة تتجاوز الحد الأقصى")
    return round(x, 2)


def _validate_opening_amounts(debit, credit):
    """تحقق من ثنائي مدين/دائن لسطر واحد."""
    if debit > 0 and credit > 0:
        return "لا يجوز إدخال مدين ودائن معاً على نفس الحساب"
    return None


def _can_edit_period(per, allow_closed=False):
    """يحدد قابلية تعديل أرصدة دورة."""
    if not per:
        return False, "الدورة المالية غير موجودة"
    if int(per.open_period or 0) != 1 and not allow_closed:
        return False, "الدورة المالية مقفلة — لا يمكن تعديل الأرصدة"
    if int(per.open_period or 0) != 1 and allow_closed and not auth.has_membership("admin"):
        return False, "تعديل دورة مقفلة يتطلب صلاحية مدير"
    return True, None


def _previous_period(per):
    """أقرب دورة مالية سابقة حسب تاريخ النهاية، مع رجوع احتياطي للمعرف."""
    if not per:
        return None
    if per.start_date:
        prev = db(db.account_periods.end_date < per.start_date).select(
            db.account_periods.ALL,
            orderby=~db.account_periods.end_date,
            limitby=(0, 1),
        ).first()
        if prev:
            return prev
    return db(db.account_periods.id < per.id).select(
        db.account_periods.ALL,
        orderby=~db.account_periods.id,
        limitby=(0, 1),
    ).first()


def _previous_carry_rows(target_period_id, previous_period_id, branch_id):
    """حساب أرصدة الدورة السابقة لحسابات الميزانية الموجودة في الدورة الحالية."""
    rows = db.executesql(
        """
        SELECT
            at.branches,
            br.name,
            at.account_no,
            at.account_name_ar,
            at.main_account,
            COALESCE((SELECT SUM(jed.debit)
                        FROM journal_entry_detail jed
                        JOIN journal_entry_master jem
                          ON jem.id = jed.journal_entry_master
                       WHERE jem.is_active = 'T'
                         AND jed.account_periods = %s
                         AND jed.branches = %s
                         AND jed.account_no = at.account_no), 0) AS jd,
            COALESCE((SELECT SUM(jed.credit)
                        FROM journal_entry_detail jed
                        JOIN journal_entry_master jem
                          ON jem.id = jed.journal_entry_master
                       WHERE jem.is_active = 'T'
                         AND jed.account_periods = %s
                         AND jed.branches = %s
                         AND jed.account_no = at.account_no), 0) AS jc,
            COALESCE((SELECT SUM(debit) FROM account_periods_opening
                       WHERE account_periods = %s
                         AND branches = %s
                         AND account_no = at.account_no), 0) AS od,
            COALESCE((SELECT SUM(credit) FROM account_periods_opening
                       WHERE account_periods = %s
                         AND branches = %s
                         AND account_no = at.account_no), 0) AS oc
        FROM accounting_tree at
        LEFT JOIN branches br ON br.id = at.branches
        WHERE at.account_periods = %s
          AND at.branches = %s
          AND at.final_account = %s
          AND at.account_no NOT IN (
            SELECT main_account FROM accounting_tree
            WHERE branches = %s
              AND account_periods = %s
              AND main_account IS NOT NULL
          )
        ORDER BY at.account_no
        """,
        placeholders=[
            int(previous_period_id), int(branch_id),
            int(previous_period_id), int(branch_id),
            int(previous_period_id), int(branch_id),
            int(previous_period_id), int(branch_id),
            int(target_period_id), int(branch_id),
            acc_carry_forward.FINAL_BALANCE_SHEET,
            int(branch_id), int(target_period_id),
        ],
        as_dict=True,
    )
    out = []
    for row in rows:
        formatted = acc_carry_forward.format_carry_row(row)
        if formatted:
            out.append(formatted)
    return out


def _current_balance_sheet_nonzero_count(period_id, branch_id):
    rows = db.executesql(
        """
        SELECT COUNT(*) AS n
        FROM account_periods_opening apo
        JOIN accounting_tree at
          ON at.account_periods = apo.account_periods
         AND at.branches = apo.branches
         AND at.account_no = apo.account_no
        WHERE apo.account_periods = %s
          AND apo.branches = %s
          AND at.final_account = %s
          AND (COALESCE(apo.debit, 0) <> 0 OR COALESCE(apo.credit, 0) <> 0)
          AND at.account_no NOT IN (
            SELECT main_account FROM accounting_tree
            WHERE branches = %s
              AND account_periods = %s
              AND main_account IS NOT NULL
          )
        """,
        placeholders=[
            int(period_id), int(branch_id),
            acc_carry_forward.FINAL_BALANCE_SHEET,
            int(branch_id), int(period_id),
        ],
        as_dict=True,
    )
    return int(rows[0]["n"] or 0) if rows else 0


@auth.requires(can_account)
def preview_previous_opening_balances():
    """معاينة ترحيل رصيد الدورة السابقة إلى افتتاحيات الدورة المختارة والفرع المختار."""
    try:
        branch_id = int(request.vars.get("branch") or request.args(0) or 0)
        period_id = int(request.vars.get("period") or request.args(1) or 0)
        if not (branch_id and period_id):
            return response.json({"err": 1, "mess": "الفرع والدورة مطلوبان"})
        per = db.account_periods[period_id]
        if not per:
            return response.json({"err": 1, "mess": "الدورة المالية غير موجودة"})
        prev = _previous_period(per)
        if not prev:
            return response.json({"err": 1, "mess": "لا توجد دورة مالية سابقة لهذه الدورة"})
        rows = _previous_carry_rows(per.id, prev.id, branch_id)
        summary = acc_carry_forward.summarize_rows(rows)
        closing = None
        closing_helper = globals().get("_closing_result_summary")
        if closing_helper:
            closing = closing_helper(prev.id, branch_id)
            closing.update({
                "source_period_id": int(prev.id),
                "source_period_name": prev.disc,
                "source_period_open": int(prev.open_period or 0),
            })
        return response.json({
            "err": 0,
            "from_period_id": prev.id,
            "from_period_name": prev.disc,
            "to_period_id": per.id,
            "to_period_name": per.disc,
            "count": summary["count"],
            "total_debit": summary["total_debit"],
            "total_credit": summary["total_credit"],
            "balanced": summary["balanced"],
            "existing_nonzero": _current_balance_sheet_nonzero_count(per.id, branch_id),
            "closing": closing,
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_account)
def carry_previous_opening_balances():
    """استبدال افتتاحيات الميزانية للفرع المختار بأرصدة الدورة السابقة المحسوبة."""
    try:
        branch_id = int(request.vars.get("branch") or request.args(0) or 0)
        period_id = int(request.vars.get("period") or request.args(1) or 0)
        if not (branch_id and period_id):
            return response.json({"err": 1, "mess": "الفرع والدورة مطلوبان"})
        per = db.account_periods[period_id]
        if not per:
            return response.json({"err": 1, "mess": "الدورة المالية غير موجودة"})
        allow_closed = str(request.vars.get("allow_closed") or "").lower() in (
            "1", "true", "yes"
        )
        can, msg = _can_edit_period(per, allow_closed=allow_closed)
        if not can:
            return response.json({"err": 2, "mess": msg})
        prev = _previous_period(per)
        if not prev:
            return response.json({"err": 1, "mess": "لا توجد دورة مالية سابقة لهذه الدورة"})
        closing_helper = globals().get("_closing_result_summary")
        if closing_helper:
            closing = closing_helper(prev.id, branch_id)
            if closing.get("needs_closing"):
                closing.update({
                    "source_period_id": int(prev.id),
                    "source_period_name": prev.disc,
                    "source_period_open": int(prev.open_period or 0),
                })
                return response.json({
                    "err": 4,
                    "mess": "يجب إقفال نتيجة الدورة السابقة قبل ترحيل الأرصدة الافتتاحية",
                    "closing": closing,
                })
        rows = _previous_carry_rows(per.id, prev.id, branch_id)
        if not rows:
            return response.json({"err": 1, "mess": "لا توجد أرصدة ميزانية قابلة للترحيل من الدورة السابقة"})

        _sync_opening_rows(per.id, branch_id)
        db.executesql(
            """
            UPDATE account_periods_opening
               SET debit = 0, credit = 0, carried_from_period = NULL
             WHERE account_periods = %s
               AND branches = %s
               AND account_no IN (
                 SELECT account_no FROM accounting_tree
                  WHERE account_periods = %s
                    AND branches = %s
                    AND final_account = %s
                    AND account_no NOT IN (
                      SELECT main_account FROM accounting_tree
                       WHERE account_periods = %s
                         AND branches = %s
                         AND main_account IS NOT NULL
                    )
               )
            """,
            placeholders=[
                int(per.id), int(branch_id),
                int(per.id), int(branch_id),
                acc_carry_forward.FINAL_BALANCE_SHEET,
                int(per.id), int(branch_id),
            ],
        )

        updated = 0
        for row in rows:
            rec = db(
                (db.account_periods_opening.account_periods == per.id)
                & (db.account_periods_opening.branches == branch_id)
                & (db.account_periods_opening.account_no == row["account_no"])
            ).select(limitby=(0, 1)).first()
            if rec:
                rec.update_record(
                    main_account=row["main_account"],
                    debit=row["debit"],
                    credit=row["credit"],
                    carried_from_period=prev.id,
                )
            else:
                db.account_periods_opening.insert(
                    account_periods=per.id,
                    branches=branch_id,
                    account_no=row["account_no"],
                    main_account=row["main_account"],
                    debit=row["debit"],
                    credit=row["credit"],
                    export=False,
                    carried_from_period=prev.id,
                )
            updated += 1
        db.commit()
        summary = acc_carry_forward.summarize_rows(rows)
        return response.json({
            "err": 0,
            "mess": "0",
            "count": updated,
            "from_period_name": prev.disc,
            "total_debit": summary["total_debit"],
            "total_credit": summary["total_credit"],
        })
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_account)
def update_opening_periods_balance():
    """تحديث رصيد افتتاحي لسطر واحد — مع فحص التوازن الجانبي وحماية الدورة المقفلة."""
    try:
        row = request.vars
        rec = db.account_periods_opening[row.get("id")] if row.get("id") else None
        if not rec:
            return response.json({"err": 1, "mess": "السطر غير موجود"})
        per = db.account_periods[rec.account_periods]
        allow_closed = str(row.get("allow_closed") or "").lower() in ("1", "true", "yes")
        can, msg = _can_edit_period(per, allow_closed=allow_closed)
        if not can:
            return response.json({"err": 2, "mess": msg})
        try:
            debit = _coerce_amount(row.get("debit"))
            credit = _coerce_amount(row.get("credit"))
        except ValueError as ve:
            return response.json({"err": 1, "mess": str(ve)})
        err = _validate_opening_amounts(debit, credit)
        if err:
            return response.json({"err": 1, "mess": err})
        rec.update_record(debit=debit, credit=credit)
        db.commit()
        return response.json({"err": 0, "id": rec.id, "debit": debit, "credit": credit, "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_account)
def bulk_update_opening_balances():
    """حفظ مجموعة أسطر دفعةً واحدة بمعاملة قاعدة بيانات واحدة.
    يفحص جميع الأسطر قبل الحفظ — إن فشل أيٌّ منها تُرفض الدفعة كاملةً."""
    try:
        raw = request.vars.get("rows")
        if not raw:
            return response.json({"err": 1, "mess": "لا توجد بيانات"})
        if isinstance(raw, str):
            try:
                rows = json.loads(raw)
            except Exception:
                return response.json({"err": 1, "mess": "صيغة البيانات غير صحيحة"})
        else:
            rows = raw
        if not isinstance(rows, list) or not rows:
            return response.json({"err": 1, "mess": "لا توجد أسطر للحفظ"})
        allow_closed = str(request.vars.get("allow_closed") or "").lower() in ("1", "true", "yes")
        prepared = []
        period_cache = {}
        for i, r in enumerate(rows, 1):
            rid = r.get("id") if isinstance(r, dict) else None
            if not rid:
                return response.json({"err": 1, "mess": "السطر رقم %d بلا معرّف" % i})
            rec = db.account_periods_opening[rid]
            if not rec:
                return response.json({"err": 1, "mess": "السطر #%s غير موجود" % rid})
            if rec.account_periods not in period_cache:
                period_cache[rec.account_periods] = db.account_periods[rec.account_periods]
            per = period_cache[rec.account_periods]
            can, msg = _can_edit_period(per, allow_closed=allow_closed)
            if not can:
                return response.json({"err": 2, "mess": msg})
            try:
                debit = _coerce_amount(r.get("debit"))
                credit = _coerce_amount(r.get("credit"))
            except ValueError as ve:
                return response.json({"err": 1, "mess": "السطر [%s] %s" % (rec.account_no, str(ve))})
            err = _validate_opening_amounts(debit, credit)
            if err:
                return response.json({"err": 1, "mess": "السطر [%s] %s" % (rec.account_no, err)})
            prepared.append((rec, debit, credit))
        for rec, debit, credit in prepared:
            rec.update_record(debit=debit, credit=credit)
        db.commit()
        return response.json({"err": 0, "count": len(prepared), "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@auth.requires(can_admin)
def clear_opening_balances():
    """تصفير جميع الأرصدة الافتتاحية لفرع ودورة — مدير فقط."""
    try:
        branch_id = int(request.vars.get("branch") or request.args(0) or 0)
        period_id = int(request.vars.get("period") or request.args(1) or 0)
        if not (branch_id and period_id):
            return response.json({"err": 1, "mess": "الفرع والدورة مطلوبان"})
        per = db.account_periods[period_id]
        can, msg = _can_edit_period(per, allow_closed=False)
        if not can:
            return response.json({"err": 2, "mess": msg})
        n = db(
            (db.account_periods_opening.account_periods == period_id)
            & (db.account_periods_opening.branches == branch_id)
        ).update(debit=0, credit=0)
        db.commit()
        return response.json({"err": 0, "count": int(n or 0), "mess": "0"})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
