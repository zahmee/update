// ======================  شاشة الفروع - منطق Vue 3  ======================

// سجل فرع فارغ
function blankRow() {
    return {
        id: -1, code: '', name: '', manager: '', site: '',
        contact: '', email: '', vat_no: '', cr_no: '',
        is_main: 2, show_row: 1,
    };
}

// توحيد أنواع البيانات القادمة من الخادم
function normalize(c) {
    var r = blankRow();
    ['code', 'name', 'manager', 'site', 'contact', 'email', 'vat_no', 'cr_no']
        .forEach(function (k) { r[k] = (c[k] == null) ? '' : String(c[k]); });
    r.id = Number(c.id);
    r.is_main = (Number(c.is_main) === 1) ? 1 : 2;
    r.show_row = (Number(c.show_row) === 2) ? 2 : 1;
    return r;
}

var vueApp = Vue.createApp({
    data() {
        return {
            URL: window.purl,
            api: window.purl + '/../../setting_api/',
            data: [],
            loading: true,
            saving: false,
            search: '',
            filter_mode: 'all',
            modal_open: false,
            select_row: blankRow(),
        };
    },

    computed: {
        // وضع التعديل عند فتح فرع موجود
        is_edit() {
            return Number(this.select_row.id) > 0;
        },
        // تصفية الفروع حسب البحث
        filteredData() {
            var q = this.search.trim().toLowerCase();
            var mode = this.filter_mode;
            return this.data.filter(function (c) {
                if (mode === 'visible' && Number(c.show_row) !== 1) return false;
                if (mode === 'hidden' && Number(c.show_row) === 1) return false;
                if (mode === 'main' && Number(c.is_main) !== 1) return false;
                if (!q) return true;
                return [c.code, c.name, c.manager, c.site, c.contact, c.vat_no, c.email, c.cr_no]
                    .some(function (v) { return (v || '').toLowerCase().indexOf(q) !== -1; });
            });
        },
        branchStats() {
            return this.data.reduce(function (acc, c) {
                acc.total += 1;
                if (Number(c.show_row) === 1) acc.visible += 1;
                else acc.hidden += 1;
                if (Number(c.is_main) === 1) acc.main += 1;
                return acc;
            }, { total: 0, visible: 0, hidden: 0, main: 0 });
        },
        filterLabel() {
            return {
                all: 'كل الفروع',
                visible: 'الفروع الظاهرة',
                hidden: 'الفروع المخفية',
                main: 'الفرع الرئيسي',
            }[this.filter_mode] || 'كل الفروع';
        },
        // صحة البريد الإلكتروني (اختياري)
        email_ok() {
            var e = (this.select_row.email || '').trim();
            if (!e) return true;
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
        },
        // الحقول الناقصة لإتمام الحفظ
        missing() {
            var m = [];
            if (!(this.select_row.code || '').trim()) m.push('رمز الفرع');
            if (!(this.select_row.name || '').trim()) m.push('اسم الفرع');
            if (!this.email_ok) m.push('بريد إلكتروني صحيح');
            return m;
        },
        is_valid() {
            return this.missing.length === 0;
        },
    },

    watch: {
        // منع تمرير الصفحة الخلفية عند فتح النافذة
        modal_open(open) {
            document.body.style.overflow = open ? 'hidden' : '';
        },
    },

    created() {
        this.load();
    },

    mounted() {
        window.addEventListener('keydown', this.on_key);
    },

    unmounted() {
        window.removeEventListener('keydown', this.on_key);
        document.body.style.overflow = '';
    },

    methods: {
        // تحميل قائمة الفروع
        load() {
            var self = this;
            return axios.get(this.api + 'get_all_branchesA').then(function (res) {
                self.data = Array.isArray(res.data) ? res.data.map(normalize) : [];
                self.loading = false;
            }).catch(function () {
                self.loading = false;
                Swal.fire({ icon: 'error', title: 'تعذّر تحميل البيانات', text: 'تأكد من الاتصال ثم أعد المحاولة.' });
            });
        },

        // فتح النافذة لإضافة فرع جديد
        open_new() {
            this.select_row = blankRow();
            this.modal_open = true;
            this.focus_first();
        },

        // فتح النافذة لتعديل فرع
        open_edit(c) {
            this.select_row = normalize(c);
            this.modal_open = true;
            this.focus_first();
        },

        // إغلاق النافذة
        close_modal() {
            if (this.saving) return;
            this.modal_open = false;
        },

        // تصفير البحث والتصفية عند حالة عدم وجود نتائج
        clear_filters() {
            this.search = '';
            this.filter_mode = 'all';
        },

        // اختصار مرئي ثابت داخل الجدول
        branchInitials(c) {
            var text = ((c.name || c.code || '').trim());
            if (!text) return 'ف';
            var parts = text.split(/\s+/).filter(Boolean);
            if (parts.length > 1) return (parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
            return text.slice(0, 2).toUpperCase();
        },

        // تركيز أول حقل عند فتح النافذة
        focus_first() {
            var self = this;
            this.$nextTick(function () {
                if (self.$refs.firstInput) self.$refs.firstInput.focus();
            });
        },

        // إغلاق النافذة بمفتاح Esc
        on_key(e) {
            if (e.key === 'Escape' && this.modal_open) this.close_modal();
        },

        // تجهيز بيانات الإرسال
        payload() {
            var r = this.select_row;
            return {
                id: r.id,
                code: (r.code || '').trim(),
                name: (r.name || '').trim(),
                manager: (r.manager || '').trim(),
                site: (r.site || '').trim(),
                contact: (r.contact || '').trim(),
                email: (r.email || '').trim(),
                vat_no: (r.vat_no || '').trim(),
                cr_no: (r.cr_no || '').trim(),
                is_main: (Number(r.is_main) === 1) ? 1 : 2,
                show_row: (Number(r.show_row) === 2) ? 2 : 1,
            };
        },

        // إضافة فرع
        add_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'add_branches/', this.payload()).then(function (res) {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تمت الإضافة', text: 'تمت إضافة الفرع بنجاح.', timer: 1700, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ غير متوقع.' });
                }
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: 'تعذّر الاتصال بالخادم.' });
            }).then(function () { self.saving = false; });
        },

        // تعديل فرع
        update_row() {
            if (!this.is_valid || this.saving) return;
            var self = this;
            this.saving = true;
            axios.post(this.api + 'update_branches/', this.payload()).then(function (res) {
                var d = res.data || {};
                if (d.mess === '0') {
                    self.modal_open = false;
                    Swal.fire({ icon: 'success', title: 'تم الحفظ', text: 'تم حفظ التعديلات بنجاح.', timer: 1700, showConfirmButton: false });
                    self.load();
                } else {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: d.mess || 'حدث خطأ غير متوقع.' });
                }
            }).catch(function () {
                Swal.fire({ icon: 'error', title: 'تعذّر الحفظ', text: 'تعذّر الاتصال بالخادم.' });
            }).then(function () { self.saving = false; });
        },

        // حذف فرع
        delete_row() {
            if (this.saving) return;
            var self = this;
            Swal.fire({
                icon: 'warning',
                title: 'حذف الفرع',
                html: 'سيتم حذف الفرع <b>' + (this.select_row.name || '') + '</b> نهائياً. هل أنت متأكد؟',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                axios.post(self.api + 'delete_branches/', { id: self.select_row.id }).then(function (res) {
                    var d = res.data || {};
                    if (d.mess === '0') {
                        self.modal_open = false;
                        Swal.fire({ icon: 'success', title: 'تم الحذف', text: 'تم حذف الفرع بنجاح.', timer: 1700, showConfirmButton: false });
                        self.load();
                    } else {
                        Swal.fire({ icon: 'warning', title: 'تعذّر الحذف', text: d.mess || 'حدث خطأ غير متوقع.' });
                    }
                }).catch(function () {
                    Swal.fire({ icon: 'error', title: 'تعذّر الحذف', text: 'تعذّر الاتصال بالخادم.' });
                }).then(function () { self.saving = false; });
            });
        },

        // طباعة القائمة
        print_list() {
            window.print();
        },
    },
});

var app = vueApp.mount('#app');
