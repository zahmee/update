# -*- coding: utf-8 -*-
"""
acc_validation — تحقّقات سلامة البيانات المحاسبية المشتركة.

`validate_journal(db, row_detail, account_periods, branch_id=None)` هي الدالة
الحرجة التي تحمي مدخلات القيد قبل الحفظ — تطابق عقد `_validate_journal`
القديم في operations_api.py مع دعم dependency injection للـ db.

الفحوصات بترتيب التطبيق:
1. وجود فترة محتوية للتاريخ
2. وجود سطرين على الأقل (القيد المزدوج)
3. لكل سطر: حساب صالح + جانب واحد فقط + قيمة موجبة
4. مركز التكلفة (إن وُجد) ضمن المتاح
5. مجموع المدين > 0
6. مجموع المدين = مجموع الدائن (متوازن ±0.005)

الدالة dependency-injected: تأخذ `db` كبارامتر، فقابلة للاختبار بـ mock.

في حالة الفشل تُرجع نصاً عربياً يصف الخطأ؛ في حالة النجاح تُرجع None.
"""


def validate_journal(db, row_detail, account_periods, branch_id=None):
    """التحقق من سلامة القيد — يُرجع رسالة خطأ أو None."""
    if not account_periods:
        return "تاريخ القيد خارج الفترات المالية المفتوحة"
    if not row_detail:
        return "لا يوجد تفاصيل للقيد"
    if len(row_detail) < 2:
        return "القيد المزدوج يحتاج سطرين على الأقل"

    valid_cost_ids = set()
    _cost_ids_loaded = False

    for i, r in enumerate(row_detail, 1):
        # حساب
        try:
            atid = int(r.get("accounting_tree") or 0)
        except Exception:
            atid = 0
        if atid <= 0:
            return "السطر %d بلا حساب — اختر الحساب المحاسبي" % i
        at = db.accounting_tree[atid]
        if not at:
            return "السطر %d يشير إلى حساب غير موجود" % i
        if branch_id and int(at.branches) != int(branch_id):
            return "السطر %d يستخدم حساباً من فرع آخر" % i

        # مبلغ
        try:
            d = float(r.get("debit") or 0)
            c = float(r.get("credit") or 0)
        except Exception:
            return "السطر %d فيه قيمة غير رقمية" % i
        if d < 0 or c < 0:
            return "السطر %d فيه قيمة سالبة — لا يُسمح" % i
        if d > 0 and c > 0:
            return "السطر %d فيه مدين ودائن معاً — اختر جانباً واحداً" % i
        if d == 0 and c == 0:
            return "السطر %d بلا قيمة" % i

        # مركز التكلفة (إن مُرر)
        try:
            cc = int(r.get("cost_center") or 0)
        except Exception:
            cc = 0
        if cc > 0:
            if not _cost_ids_loaded:
                for cr in db(db.key_cost_center.show_cost == 1).select(db.key_cost_center.id):
                    valid_cost_ids.add(int(cr.id))
                _cost_ids_loaded = True
            if cc not in valid_cost_ids:
                return "السطر %d يحوي مركز تكلفة غير متاح" % i

    total_debit = round(sum(float(r.get("debit") or 0) for r in row_detail), 2)
    total_credit = round(sum(float(r.get("credit") or 0) for r in row_detail), 2)
    if total_debit <= 0:
        return "لا يمكن حفظ قيد بقيمة صفرية"
    if abs(total_debit - total_credit) >= 0.005:
        return (
            "القيد غير متوازن — إجمالي المدين %.2f لا يساوي إجمالي الدائن %.2f"
            % (total_debit, total_credit)
        )
    return None


def compute_totals(row_detail):
    """يحسب (total_debit, total_credit) مدوَّرَين لرقمَين عشريَّين.

    دالة منفصلة لاستعمالها مباشرة بعد التحقق (operations_api يستخدمها مرتَّين).
    """
    total_debit = round(sum(float(r.get("debit") or 0) for r in (row_detail or [])), 2)
    total_credit = round(sum(float(r.get("credit") or 0) for r in (row_detail or [])), 2)
    return total_debit, total_credit


def is_balanced(row_detail, tolerance=0.005):
    """True إذا كانت السطور متوازنة وإجمالي المدين > 0."""
    td, tc = compute_totals(row_detail)
    if td <= 0:
        return False
    return abs(td - tc) < tolerance
