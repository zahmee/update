# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الترميزات الأساسية (Lookup Tables)
# البيانات الافتتاحية في: scripts/seed_data.py
# ===========================================================================================

# جدول الوحدات للبضائع
db.define_table("key_unit", Field("name", length=150, label="الوصف"), format="%(name)s", on_define=id_label("م"))

# ============================================================================
# جدول طرق الدفع
db.define_table(
    "key_payment_method",
    Field("name", length=150, label="الوصف"),
    Field(
        "account_source",
        length=10,
        default="none",
        label="مصدر الحساب",
        requires=IS_IN_SET(("cash", "bank", "none")),
    ),
    format="%(name)s",
    on_define=id_label("م"),
)

# ترحيل آمن لطرق الدفع الموجودة قبل فصل حسابات الكاش والبنك. لا تُغيّر
# أسماء الطرق ولا الحركات التاريخية؛ تضيف فقط تصنيف المصدر الذي تستخدمه
# اليوميات الجديدة لتوزيع السداد على الحساب الصحيح.
_payment_source_by_name = {
    "نقدي": "cash",
    "شبكة الكترونية": "bank",
    "شبكة إلكترونية": "bank",
    "تحويل في الحساب": "bank",
    "شيك": "bank",
}
_payment_sources_changed = False
if _first_run:  # ترحيل لمرة واحدة لكل عملية خادم — انظر _first_run في db.py
    for _method in db(db.key_payment_method.id > 0).select():
        _expected_source = _payment_source_by_name.get((_method.name or "").strip(), "none")
        if _method.account_source not in ("cash", "bank", "none") or (
            _method.account_source == "none" and _expected_source != "none"
        ):
            _method.update_record(account_source=_expected_source)
            _payment_sources_changed = True
if _payment_sources_changed:
    db.commit()

# =============================================================================
# جدول فئات الأسر
db.define_table(
    "key_family_type", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# ==============================================================================
# جدول تصنيفات البضائع
db.define_table("key_type", Field("name", length=150, label="الوصف"), format="%(name)s", on_define=id_label("م"))

# ==============================================================================
# جدول انواع السداد
db.define_table(
    "key_payment_type", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)

# ==============================================================================
# جدول تصنيف الفواتير / سندات الاستلام
db.define_table(
    "key_invoce_type", Field("name", length=150, label="الوصف"), format="%(name)s",
    on_define=id_label("م"),
)
