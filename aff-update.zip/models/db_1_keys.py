# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الترميزات الأساسية (Lookup Tables)
# البيانات الافتتاحية في: scripts/seed_data.py
# ===========================================================================================

# جدول الوحدات للبضائع
db.define_table("key_unit", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_unit.id.label = "م"

# ============================================================================
# جدول طرق الدفع
db.define_table(
    "key_payment_method", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_method.id.label = "م"

# =============================================================================
# جدول فئات الأسر
db.define_table(
    "key_family_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_family_type.id.label = "م"

# ==============================================================================
# جدول تصنيفات البضائع
db.define_table("key_type", Field("name", length=150, label="الوصف"), format="%(name)s")
db.key_type.id.label = "م"

# ==============================================================================
# جدول انواع السداد
db.define_table(
    "key_payment_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_payment_type.id.label = "م"

# ==============================================================================
# جدول تصنيف الفواتير / سندات الاستلام
db.define_table(
    "key_invoce_type", Field("name", length=150, label="الوصف"), format="%(name)s"
)
db.key_invoce_type.id.label = "م"
