# -*- coding: utf-8 -*-
#  type: ignore
response.title = request.application.replace('_', ' ').title()
response.subtitle = 'نظام الأسر والموردين'

response.meta.author = 'ahmed zahmah <zahmee@gmail.com>'
response.meta.description = 'نظام الأسر والموردين'
response.meta.keywords = 'web2py, python, framework'
response.meta.generator = 'Web2py Web Framework'

# القائمة الرئيسية تُبنى داخل layout.html حسب صلاحيات الشاشات (screens_rules)
# كما هو معمول به في المشروع المرجعي
response.menu = []

DEVELOPMENT_MENU = True
