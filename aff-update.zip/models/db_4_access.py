# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الصلاحيات والشاشات ودوال التحقق (Access Control)
# ===========================================================================================

#  جدول الأنظمة
db.define_table(
    "systems",
    Field("name", length=270, label="اسم النظام"),
    format="%(name)s",
)
db.systems.id.label = "م"

# ===========================================================================================
#  جدول الشاشات
db.define_table(
    "screens",
    Field("systems", "reference systems", default=1, label="النظام"),
    Field("name", length=270, label="اسم الشاشة"),
    Field("screen_code", "integer", label="كود الشاشة"),
    format="%(screen_code)s - %(name)s",
)

# ===========================================================================================
#  جدول صلاحيات الشاشات
db.define_table(
    "screens_rules",
    Field("to_user", "reference auth_user", label="المستخدم"),
    Field("screens", "reference screens", label="الشاشة"),
    Field("can_log_in", "boolean", default=False, label="الدخول"),
    Field("can_add", "boolean", default=False, label="الاضافة"),
    Field("can_edit", "boolean", default=False, label="التعديل"),
    Field("can_delete", "boolean", default=False, label="الحذف"),
    Field("can_close", "boolean", default=False, label="إقفال اليومية"),
    Field("can_reopen", "boolean", default=False, label="إعادة فتح اليومية"),
)
# ===========================================================================================
# ===========================================================================================
# ===========================================================================================
#  جدول معلومات الجهه
db.define_table(
    "important_info",
    Field(
        "name",
        length=370,
        label="الاسم ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "vat",
        length=100,
        label="الرقم الضريبي ",
    ),
    Field(
        "tel",
        length=25,
        label="رقم الهاتف الارضي ",
    ),
    Field(
        "mobile",
        length=25,
        label="رقم الجوال / الواتس آب ",
    ),
    Field(
        "address",
        "text",
        default=" ",
        label="العنوان",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "msg1",
        "text",
        default=" ",
        label="رسالة للعميل",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "msg2",
        "text",
        default=" ",
        label="رسالة آخر الفاتورة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "logo",
        "upload",
        autodelete=True,
        label="الشعار",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("change_count", "boolean", label="تعديل الكمية بالسعر"),
    Field("change_count_amount", "double", default=0, label="مبلغ فاتورة تعديل الكمية"),
)
# ===========================================================================================
# ===========================================================================================
#  إعدادات الرسائل النصية (سجل واحد) — التحكم في الإرسال وصيغ الرسائل
#  العناصر المتاحة في الصيغ: {name} {amount} {date} {doc} {org}
db.define_table(
    "sms_settings",
    Field("enabled", "boolean", default=False, label="تفعيل خدمة الرسائل النصية"),
    Field("on_receipt", "boolean", default=False, label="إرسال عند استلام بضاعة (أسرة/مورد)"),
    Field("on_return", "boolean", default=False, label="إرسال عند المرتجعات"),
    Field("on_payment", "boolean", default=False, label="إرسال عند السدادات"),
    Field(
        "tpl_receipt",
        "text",
        default="عزيزي {name}، تم تسجيل سند استلام رقم {doc} بمبلغ {amount} ريال بتاريخ {date}. {org}",
        label="صيغة رسالة الاستلام",
    ),
    Field(
        "tpl_return",
        "text",
        default="عزيزي {name}، تم تسجيل سند مرتجع رقم {doc} بمبلغ {amount} ريال بتاريخ {date}. {org}",
        label="صيغة رسالة المرتجع",
    ),
    Field(
        "tpl_payment",
        "text",
        default="عزيزي {name}، تم تسجيل سداد بمبلغ {amount} ريال بتاريخ {date}. شكراً لتعاملكم. {org}",
        label="صيغة رسالة السداد",
    ),
    auth.signature,
)
# ===========================================================================================
# ===========================================================================================


def can_access(*argument):
    if auth.user:
        if auth.user.first_name:

            def decorator(function):
                def wrapper(*args, **kwargs):
                    if auth.has_membership("admin"):
                        return function(*args, **kwargs)
                    for code in argument:
                        screen_row = db(db.screens.screen_code == code).select().first()
                        if screen_row:
                            acc = db(
                                (db.screens_rules.screens == screen_row.id)
                                & (db.screens_rules.to_user == auth.user.id)
                                & (db.screens_rules.can_log_in == True)
                            ).select().first()
                            if acc:
                                return function(*args, **kwargs)
                    return redirect(URL("default", "not_allow"))

                return wrapper

            return decorator
        else:
            return redirect(URL("default", "not_allow"))
    else:
        return redirect(URL("default", "not_allow"))


def screens_rules(sc):
    if not auth.user:
        return None
    # السماح لـ admin دائماً
    if auth.has_membership("admin"):
        class AdminScreen:
            can_log_in = True
            can_add = True
            can_edit = True
            can_delete = True
            can_close = True
            can_reopen = True
        return AdminScreen()
    screen_code = db(db.screens.screen_code == sc).select().first()
    if not screen_code:
        return None
    acc = (
        db(
            (db.screens_rules.screens == screen_code.id)
            & (db.screens_rules.to_user == auth.user.id)
        )
        .select()
        .first()
    )
    return acc


def has_any_screen(*codes):
    """تحقق إذا كان المستخدم لديه صلاحية دخول لأي شاشة من القائمة المعطاة"""
    if not auth.user:
        return False
    if auth.has_membership("admin"):
        return True
    screen_rows = db(db.screens.screen_code.belongs(list(codes))).select(db.screens.id)
    if not screen_rows:
        return False
    id_list = [r.id for r in screen_rows]
    rule = db(
        (db.screens_rules.screens.belongs(id_list))
        & (db.screens_rules.to_user == auth.user.id)
        & (db.screens_rules.can_log_in == True)
    ).select(db.screens_rules.id, limitby=(0, 1)).first()
    return rule is not None
