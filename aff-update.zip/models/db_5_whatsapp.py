# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
#  رسائل واتساب عبر الواجهة الرسمية من ميتا (WhatsApp Cloud API)
#
#  wa_settings : سجل واحد — تفعيل الخدمة ومفاتيح الأحداث
#  wa_messages : قائمة الإرسال وسجل الحالات. تُضاف الرسالة داخل معاملة الحفظ نفسها (قبل
#                db.commit في المتحكم)، فلا تضيع رسالة ولا تُرسل لحركة تراجع حفظها؛ ثم تُرسل
#                فوراً بعد الحفظ، وتُحدَّث حالتها من إشعارات ميتا (وصلت، قُرئت، فشلت).
#  wa_inbound  : ردود العملاء الواردة عبر نقطة الاستقبال (controllers/whatsapp_hook.py)
#
#  الاتصال بميتا في modules/whatsapp_cloud.py، وبيانات الربط wa_config من db.py.
# ===========================================================================================
import whatsapp_cloud

db.define_table(
    "wa_settings",
    Field("enabled", "boolean", default=False, label="تفعيل رسائل واتساب"),
    Field("on_receipt", "boolean", default=False, label="إرسال عند استلام بضاعة"),
    Field("on_return", "boolean", default=False, label="إرسال عند المرتجعات"),
    Field("on_payment", "boolean", default=False, label="إرسال عند السدادات"),
    auth.signature,
)

db.define_table(
    "wa_messages",
    Field("event", length=20, label="الحدث"),
    Field("party_kind", length=10, label="نوع الطرف"),
    Field("party_id", "integer", label="الطرف"),
    Field("party_name", length=270, label="الاسم"),
    Field("mobile", length=20, label="الجوال"),
    Field("template", length=128, label="القالب"),
    Field("params", "json", label="المتغيرات"),
    Field("preview", "text", label="نص الرسالة"),
    Field("doc_ref", length=64, label="المرجع"),
    Field("status", length=12, default="pending", label="الحالة"),
    Field("attempts", "integer", default=0, label="المحاولات"),
    Field("next_attempt_at", "datetime", label="المحاولة التالية"),
    Field("wamid", length=128, label="معرّف الرسالة لدى ميتا"),
    Field("error_code", "integer", label="رمز الخطأ"),
    Field("error_text", "text", label="الخطأ"),
    Field("status_at", "datetime", label="وقت آخر حالة"),
    auth.signature,
    on_define=id_label("م"),
)

db.define_table(
    "wa_inbound",
    Field("wamid", length=128, label="معرّف الرسالة لدى ميتا"),
    Field("from_mobile", length=20, label="من"),
    Field("from_name", length=270, label="اسم المرسل في واتساب"),
    Field("party_kind", length=10, label="نوع الطرف"),
    Field("party_id", "integer", label="الطرف"),
    Field("party_name", length=270, label="الاسم في النظام"),
    Field("msg_type", length=20, label="النوع"),
    Field("body", "text", label="النص"),
    Field("received_at", "datetime", label="وقت الإرسال"),
    Field("created_on", "datetime", default=request.now, label="وقت الاستلام"),
    on_define=id_label("م"),
)

# فهارس البحث بمعرّف ميتا وقائمة الإرسال، ومنع تكرار الرد الوارد إن أعادت ميتا إرساله.
if _first_run:
    try:
        db.commit()
        db.wa_messages, db.wa_inbound  # بناء الجدولين (وترحيلهما) قبل الفهارس
        for _sql in (
            "CREATE INDEX IF NOT EXISTS wa_messages_wamid_idx ON wa_messages (wamid)",
            "CREATE INDEX IF NOT EXISTS wa_messages_queue_idx ON wa_messages (status, next_attempt_at)",
            "CREATE UNIQUE INDEX IF NOT EXISTS wa_inbound_wamid_uq ON wa_inbound (wamid)",
        ):
            db.executesql(_sql)
        db.commit()
    except Exception:
        db.rollback()

WA_EVENT_LABELS = {"receipt": "سند استلام", "return": "سند مرتجع", "payment": "سداد"}
WA_EVENT_FLAGS = {"receipt": "on_receipt", "return": "on_return", "payment": "on_payment"}
# ترتيب الحالات: إشعارات ميتا قد تصل بغير ترتيبها، فلا تُستبدل حالة بأقدم منها.
WA_STATUS_RANK = {"pending": 0, "sending": 0, "accepted": 1, "sent": 2, "delivered": 3, "read": 4}
# دقائق الانتظار قبل كل إعادة محاولة للأخطاء المؤقتة؛ بعدها تُعدّ الرسالة فاشلة.
WA_RETRY_MINUTES = (1, 5, 30, 120, 720)
WA_STALE_MINUTES = 10


def wa_settings_row():
    return db(db.wa_settings.id > 0).select(limitby=(0, 1)).first()


def wa_missing_config():
    return whatsapp_cloud.missing_config(wa_config)


def _wa_insert(event, kind, party, template_key, params, mobile, doc_ref=""):
    """إضافة رسالة لقائمة الإرسال. يعيد رقمها، أو None إن كان الرقم غير صالح."""
    to = whatsapp_cloud.normalize_msisdn(mobile)
    if not to:
        return None
    tpl = whatsapp_cloud.TEMPLATES[template_key]
    params = [whatsapp_cloud.clean_param(p) for p in params]
    return db.wa_messages.insert(
        event=event,
        party_kind=kind or "",
        party_id=party.id if party else None,
        party_name=(party.name if party else "") or "",
        mobile=to,
        template=tpl["name"],
        params=params,
        preview=whatsapp_cloud.render_preview(tpl["body"], params),
        doc_ref=str(doc_ref or ""),
        status="pending",
        attempts=0,
        next_attempt_at=request.now,
    )


def wa_notify(event, kind, party, amount=None, doc=None, date=None):
    """
    إشعار تلقائي بحركة (استلام، مرتجع، سداد): يُضاف لقائمة الإرسال داخل معاملة الحفظ
    الجارية، أي قبل db.commit في المتحكم، ثم يُرسل بعدها عبر wa_send_queued.
    يعيد رقم الرسالة، أو None إن كان الإرسال غير مُفعّل أو غير ممكن. لا يرفع استثناء.

        wa_id = wa_notify("receipt", "family", family, amount=total, doc=receipt_no, date=day)
        db.commit()
        wa_send_queued(wa_id)
    """
    try:
        if not party or event not in WA_EVENT_LABELS or wa_missing_config():
            return None
        cfg = wa_settings_row()
        if not cfg or not cfg.enabled or not cfg[WA_EVENT_FLAGS[event]]:
            return None
        params = [
            party.name,
            WA_EVENT_LABELS[event],
            doc or "-",
            whatsapp_cloud.fmt_amount(amount),
            str(date or request.now.date()),
        ]
        return _wa_insert(event, kind, party, "notice", params, party.mobile, doc_ref=doc)
    except Exception:
        return None


def wa_queue_statement(kind, party):
    """كشف الرصيد الصافي لطرف واحد (إرسال يدوي). يعيد (رقم الرسالة، رسالة الخطأ)."""
    if not party.mobile:
        return None, "لا يوجد رقم جوال لهذا السجل"
    due = party_net_due(kind, party)
    net = due["net_due"]
    if net > 0:
        side = "مستحقة لكم"
    elif net < 0:
        side = "مستحقة عليكم"
    else:
        side = "ولا توجد مستحقات"
    params = [party.name, str(request.now.date()), whatsapp_cloud.fmt_amount(abs(net)), side]
    message_id = _wa_insert("statement", kind, party, "statement", params, party.mobile)
    if not message_id:
        return None, "رقم الجوال غير صالح: يجب أن يكون بصيغة 05XXXXXXXX"
    return message_id, ""


def wa_queue_test(mobile):
    """رسالة تجريبية بقالب الإشعار وقيمه النموذجية. يعيد (رقم الرسالة، رسالة الخطأ)."""
    params = whatsapp_cloud.TEMPLATES["notice"]["example"]
    message_id = _wa_insert("test", "", None, "notice", params, mobile)
    if not message_id:
        return None, "رقم الجوال غير صالح: يجب أن يكون بصيغة 05XXXXXXXX"
    return message_id, ""


def wa_dispatch(message_id):
    """
    إرسال رسالة واحدة من القائمة إن كانت بانتظار الإرسال. يحجزها أولاً بتحديث مشروط
    فلا يرسلها طلبان معاً، ثم يحفظ النتيجة: مقبولة، أو إعادة محاولة لاحقاً، أو فاشلة.
    يعيد نتيجة الإرسال {ok, error_text, retryable, ...}. لا يرفع استثناء.
    """
    try:
        row = db.wa_messages[message_id]
        if not row or row.status != "pending":
            return {"ok": False, "error_text": "الرسالة ليست بانتظار الإرسال"}
        attempts = (row.attempts or 0) + 1
        claimed = db(
            (db.wa_messages.id == row.id) & (db.wa_messages.status == "pending")
        ).update(status="sending", attempts=attempts, status_at=request.now)
        db.commit()
        if not claimed:
            return {"ok": False, "error_text": "الرسالة قيد الإرسال من طلب آخر"}

        res = whatsapp_cloud.send_template(wa_config, row.mobile, row.template, row.params or [])
        now = request.now
        if res["ok"]:
            vals = dict(status="accepted", wamid=res["wamid"], error_code=None, error_text=None,
                        next_attempt_at=None, status_at=now)
        elif res.get("retryable") and attempts < len(WA_RETRY_MINUTES):
            vals = dict(status="pending", error_code=res.get("error_code"), error_text=res.get("error_text"),
                        next_attempt_at=now + datetime.timedelta(minutes=WA_RETRY_MINUTES[attempts - 1]),
                        status_at=now)
        else:
            vals = dict(status="failed", error_code=res.get("error_code"), error_text=res.get("error_text"),
                        next_attempt_at=None, status_at=now)
        db((db.wa_messages.id == row.id) & (db.wa_messages.status == "sending")).update(**vals)
        db.commit()
        return res
    except Exception as e:
        db.rollback()
        return {"ok": False, "error_text": "تعذّر إرسال رسالة واتساب: %s" % e}


def wa_retry_due(limit=3):
    """معالجة الرسائل المستحقة لإعادة المحاولة، وتعليم المعلّقة منذ مدة طويلة بالفشل."""
    try:
        stale = request.now - datetime.timedelta(minutes=WA_STALE_MINUTES)
        db((db.wa_messages.status == "sending") & (db.wa_messages.status_at < stale)).update(
            status="failed",
            next_attempt_at=None,
            error_text="انقطع الإرسال قبل تأكيد النتيجة؛ تحقّق من وصول الرسالة قبل إعادة المحاولة",
        )
        db.commit()
        due = db(
            (db.wa_messages.status == "pending") & (db.wa_messages.next_attempt_at <= request.now)
        ).select(db.wa_messages.id, orderby=db.wa_messages.next_attempt_at, limitby=(0, limit))
        for row in due:
            wa_dispatch(row.id)
    except Exception:
        db.rollback()


def wa_send_queued(*message_ids):
    """
    إرسال الرسائل المحددة فوراً بعد db.commit في المتحكم. إن نجح أي منها (الاتصال بميتا
    سليم)، تُعالج معها رسائل متأخرة مستحقة لإعادة المحاولة. لا يرفع استثناء.
    """
    ok = False
    for message_id in message_ids:
        if message_id:
            ok = wa_dispatch(message_id).get("ok") or ok
    if ok:
        wa_retry_due()
    return ok


def wa_find_party(mobile):
    """أسرة أو مورد بهذا الرقم: (النوع، الصف)، أو (None، None)."""
    local = whatsapp_cloud.local_mobile(mobile)
    if not local:
        return None, None
    family = db(db.families.mobile == local).select(
        db.families.id, db.families.name, limitby=(0, 1)).first()
    if family:
        return "family", family
    supplier = db(db.suppliers.mobile == local).select(
        db.suppliers.id, db.suppliers.name, limitby=(0, 1)).first()
    if supplier:
        return "supplier", supplier
    return None, None


def wa_apply_webhook(payload):
    """تطبيق إشعار ميتا: تحديث حالات الرسائل المرسلة وحفظ ردود العملاء. يعيد (الحالات، الردود)."""
    statuses, inbound = whatsapp_cloud.parse_webhook(payload)
    for st in statuses:
        new = st["status"]
        if not st["wamid"] or new not in ("sent", "delivered", "read", "failed"):
            continue
        row = db(db.wa_messages.wamid == st["wamid"]).select(limitby=(0, 1)).first()
        if not row:
            continue  # رسالة لم تُرسل من هذا النظام
        at = st["timestamp"] or request.now
        if new == "failed":
            if row.status in ("delivered", "read"):
                continue
            row.update_record(
                status="failed",
                error_code=st["error_code"],
                error_text=whatsapp_cloud.describe_error(st["error_code"], st["error_text"]),
                status_at=at,
            )
        elif row.status != "failed" and WA_STATUS_RANK[new] > WA_STATUS_RANK.get(row.status, 0):
            row.update_record(status=new, status_at=at)

    for msg in inbound:
        if not msg["wamid"] or not db(db.wa_inbound.wamid == msg["wamid"]).isempty():
            continue
        kind, party = wa_find_party(msg["from"])
        db.wa_inbound.insert(
            wamid=msg["wamid"],
            from_mobile=msg["from"] or "",
            from_name=msg["name"] or "",
            party_kind=kind or "",
            party_id=party.id if party else None,
            party_name=party.name if party else "",
            msg_type=msg["type"],
            body=msg["text"],
            received_at=msg["timestamp"] or request.now,
        )
    db.commit()
    return len(statuses), len(inbound)
