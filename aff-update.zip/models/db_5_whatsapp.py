# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
#  رسائل واتساب: عبر بوابة واتساب المركزية (wahub) إن ضُبط قسم [wahub]، وإلا عبر الواجهة
#  الرسمية من ميتا مباشرة (WhatsApp Cloud API) بقسم [whatsapp].
#
#  wa_settings : سجل واحد — تفعيل الخدمة ومفاتيح الأحداث
#  wa_messages : قائمة الإرسال وسجل الحالات. تُضاف الرسالة داخل معاملة الحفظ نفسها (قبل
#                db.commit في المتحكم)، فلا تضيع رسالة ولا تُرسل لحركة تراجع حفظها؛ ثم تُرسل
#                فوراً بعد الحفظ، وتُحدَّث حالتها من الإشعارات (وصلت، قُرئت، فشلت).
#  wa_inbound  : ردود العملاء الواردة، من ميتا مباشرة (controllers/whatsapp_hook.py) أو من
#                البوابة (controllers/wahub_hook.py)
#
#  الاتصال بميتا في modules/whatsapp_cloud.py، وبالبوابة في modules/wahub_client.py، وبيانات
#  الربط wa_config و wahub_config من db.py.
# ===========================================================================================
import secrets

import wahub_client
import whatsapp_cloud

db.define_table(
    "wa_settings",
    Field("enabled", "boolean", default=False, label="تفعيل رسائل واتساب"),
    Field("on_receipt", "boolean", default=False, label="إرسال عند استلام بضاعة"),
    Field("on_return", "boolean", default=False, label="إرسال عند المرتجعات"),
    Field("on_payment", "boolean", default=False, label="إرسال عند السدادات"),
    auth.signature,
)

db.define_table(
    "wa_messages",
    Field("event", length=20, label="الحدث"),
    Field("party_kind", length=10, label="نوع الطرف"),
    Field("party_id", "integer", label="الطرف"),
    Field("party_name", length=270, label="الاسم"),
    Field("mobile", length=20, label="الجوال"),
    Field("template", length=128, label="القالب"),
    Field("params", "json", label="المتغيرات"),
    Field("preview", "text", label="نص الرسالة"),
    Field("doc_ref", length=64, label="المرجع"),
    Field("status", length=12, default="pending", label="الحالة"),
    Field("attempts", "integer", default=0, label="المحاولات"),
    Field("next_attempt_at", "datetime", label="المحاولة التالية"),
    Field("wamid", length=128, label="معرّف الرسالة لدى ميتا"),
    Field("hub_ref", length=64, label="مرجع الرسالة في البوابة"),
    Field("hub_id", "integer", label="رقم الرسالة في البوابة"),
    Field("error_code", "integer", label="رمز الخطأ"),
    Field("error_text", "text", label="الخطأ"),
    Field("status_at", "datetime", label="وقت آخر حالة"),
    auth.signature,
    on_define=id_label("م"),
)

db.define_table(
    "wa_inbound",
    Field("wamid", length=128, label="معرّف الرسالة لدى ميتا"),
    Field("from_mobile", length=20, label="من"),
    Field("from_name", length=270, label="اسم المرسل في واتساب"),
    Field("party_kind", length=10, label="نوع الطرف"),
    Field("party_id", "integer", label="الطرف"),
    Field("party_name", length=270, label="الاسم في النظام"),
    Field("msg_type", length=20, label="النوع"),
    Field("body", "text", label="النص"),
    Field("received_at", "datetime", label="وقت الإرسال"),
    Field("created_on", "datetime", default=request.now, label="وقت الاستلام"),
    on_define=id_label("م"),
)

# فهارس البحث بمعرّف ميتا ومرجع البوابة وقائمة الإرسال، ومنع تكرار الرد الوارد إن أُعيد إرساله.
if _first_run:
    try:
        db.commit()
        db.wa_messages, db.wa_inbound  # بناء الجدولين (وترحيلهما) قبل الفهارس
        for _sql in (
            "CREATE INDEX IF NOT EXISTS wa_messages_wamid_idx ON wa_messages (wamid)",
            "CREATE INDEX IF NOT EXISTS wa_messages_hub_ref_idx ON wa_messages (hub_ref)",
            "CREATE INDEX IF NOT EXISTS wa_messages_queue_idx ON wa_messages (status, next_attempt_at)",
            "CREATE UNIQUE INDEX IF NOT EXISTS wa_inbound_wamid_uq ON wa_inbound (wamid)",
        ):
            db.executesql(_sql)
        db.commit()
    except Exception:
        db.rollback()

WA_EVENT_LABELS = {"receipt": "سند استلام", "return": "سند مرتجع", "payment": "سداد"}
WA_EVENT_FLAGS = {"receipt": "on_receipt", "return": "on_return", "payment": "on_payment"}
# ترتيب الحالات: الإشعارات قد تصل بغير ترتيبها، فلا تُستبدل حالة بأقدم منها.
# queued: سُلّمت للبوابة وتنتظر إرسالها لميتا (طريقة البوابة فقط).
WA_STATUS_RANK = {"pending": 0, "sending": 0, "queued": 1, "accepted": 2, "sent": 3, "delivered": 4, "read": 5}
# دقائق الانتظار قبل كل إعادة محاولة للأخطاء المؤقتة؛ بعدها تُعدّ الرسالة فاشلة.
WA_RETRY_MINUTES = (1, 5, 30, 120, 720)
WA_STALE_MINUTES = 10
WA_UNKNOWN_OUTCOME = "انقطع الإرسال قبل تأكيد النتيجة؛ تحقّق من وصول الرسالة قبل إعادة المحاولة"


def wa_settings_row():
    return db(db.wa_settings.id > 0).select(limitby=(0, 1)).first()


def wa_missing_config():
    """مفاتيح الربط الناقصة لطريقة الإرسال الحالية. البوابة لا تُعتمد إلا برابطها ومفتاحها معاً."""
    if WA_VIA_HUB:
        return []
    return whatsapp_cloud.missing_config(wa_config)


def _wa_insert(event, kind, party, template_key, params, mobile, doc_ref=""):
    """إضافة رسالة لقائمة الإرسال. يعيد رقمها، أو None إن كان الرقم غير صالح."""
    to = whatsapp_cloud.normalize_msisdn(mobile)
    if not to:
        return None
    tpl = whatsapp_cloud.TEMPLATES[template_key]
    params = [whatsapp_cloud.clean_param(p) for p in params]
    return db.wa_messages.insert(
        event=event,
        party_kind=kind or "",
        party_id=party.id if party else None,
        party_name=(party.name if party else "") or "",
        mobile=to,
        template=tpl["name"],
        params=params,
        preview=whatsapp_cloud.render_preview(tpl["body"], params),
        doc_ref=str(doc_ref or ""),
        status="pending",
        attempts=0,
        next_attempt_at=request.now,
    )


def wa_notify(event, kind, party, amount=None, doc=None, date=None):
    """
    إشعار تلقائي بحركة (استلام، مرتجع، سداد): يُضاف لقائمة الإرسال داخل معاملة الحفظ
    الجارية، أي قبل db.commit في المتحكم، ثم يُرسل بعدها عبر wa_send_queued.
    يعيد رقم الرسالة، أو None إن كان الإرسال غير مُفعّل أو غير ممكن. لا يرفع استثناء.

        wa_id = wa_notify("receipt", "family", family, amount=total, doc=receipt_no, date=day)
        db.commit()
        wa_send_queued(wa_id)
    """
    try:
        if not party or event not in WA_EVENT_LABELS or wa_missing_config():
            return None
        cfg = wa_settings_row()
        if not cfg or not cfg.enabled or not cfg[WA_EVENT_FLAGS[event]]:
            return None
        params = [
            party.name,
            WA_EVENT_LABELS[event],
            doc or "-",
            whatsapp_cloud.fmt_amount(amount),
            str(date or request.now.date()),
        ]
        return _wa_insert(event, kind, party, "notice", params, party.mobile, doc_ref=doc)
    except Exception:
        return None


def wa_queue_statement(kind, party):
    """كشف الرصيد الصافي لطرف واحد (إرسال يدوي). يعيد (رقم الرسالة، رسالة الخطأ)."""
    if not party.mobile:
        return None, "لا يوجد رقم جوال لهذا السجل"
    due = party_net_due(kind, party)
    net = due["net_due"]
    if net > 0:
        side = "مستحقة لكم"
    elif net < 0:
        side = "مستحقة عليكم"
    else:
        side = "ولا توجد مستحقات"
    params = [party.name, str(request.now.date()), whatsapp_cloud.fmt_amount(abs(net)), side]
    message_id = _wa_insert("statement", kind, party, "statement", params, party.mobile)
    if not message_id:
        return None, "رقم الجوال غير صالح: يجب أن يكون بصيغة 05XXXXXXXX"
    return message_id, ""


def wa_queue_test(mobile):
    """رسالة تجريبية بقالب الإشعار وقيمه النموذجية. يعيد (رقم الرسالة، رسالة الخطأ)."""
    params = whatsapp_cloud.TEMPLATES["notice"]["example"]
    message_id = _wa_insert("test", "", None, "notice", params, mobile)
    if not message_id:
        return None, "رقم الجوال غير صالح: يجب أن يكون بصيغة 05XXXXXXXX"
    return message_id, ""


def wa_dispatch(message_id):
    """
    إرسال رسالة واحدة من القائمة إن كانت بانتظار الإرسال: للبوابة إن كانت مضبوطة، وإلا لميتا
    مباشرة. يحجزها أولاً بتحديث مشروط فلا يرسلها طلبان معاً، ثم يحفظ النتيجة: مقبولة، أو
    إعادة محاولة لاحقاً، أو فاشلة. يعيد نتيجة الإرسال {ok, error_text, retryable, ...}.
    لا يرفع استثناء.
    """
    try:
        row = db.wa_messages[message_id]
        if not row or row.status != "pending":
            return {"ok": False, "error_text": "الرسالة ليست بانتظار الإرسال"}
        attempts = (row.attempts or 0) + 1
        claim = dict(status="sending", attempts=attempts, status_at=request.now)
        if WA_VIA_HUB and not row.hub_ref:
            # مرجع ثابت يُحفظ قبل الإرسال: البوابة لا تكرر رسالة بمرجع استلمته من قبل، فإعادة
            # المحاولة به آمنة حتى لو انقطع الاتصال بعد وصول الطلب
            claim["hub_ref"] = "aff-%d-%s" % (row.id, secrets.token_hex(3))
        claimed = db(
            (db.wa_messages.id == row.id) & (db.wa_messages.status == "pending")
        ).update(**claim)
        db.commit()
        if not claimed:
            return {"ok": False, "error_text": "الرسالة قيد الإرسال من طلب آخر"}

        now = request.now
        if WA_VIA_HUB:
            res = wahub_client.send(wahub_config, claim.get("hub_ref") or row.hub_ref, row.mobile,
                                    row.template, row.params or [], language=whatsapp_cloud.TEMPLATE_LANG)
            done, code = dict(status="queued"), res.get("http_status")
        else:
            res = whatsapp_cloud.send_template(wa_config, row.mobile, row.template, row.params or [])
            done, code = dict(status="accepted", wamid=res.get("wamid")), res.get("error_code")
        if res["ok"]:
            vals = dict(done, error_code=None, error_text=None, next_attempt_at=None, status_at=now)
        elif res.get("retryable") and attempts < len(WA_RETRY_MINUTES):
            vals = dict(status="pending", error_code=code, error_text=res.get("error_text"),
                        next_attempt_at=now + datetime.timedelta(minutes=WA_RETRY_MINUTES[attempts - 1]),
                        status_at=now)
        else:
            vals = dict(status="failed", error_code=code, error_text=res.get("error_text"),
                        next_attempt_at=None, status_at=now)
        db((db.wa_messages.id == row.id) & (db.wa_messages.status == "sending")).update(**vals)
        if res["ok"] and WA_VIA_HUB:
            # إشعار البوابة قد يسبق هذا التحديث، فرقمها يُحفظ دائماً؛ والمرجع المكرر يعيد حالتها لديها
            db(db.wa_messages.id == row.id).update(hub_id=res.get("hub_id"))
            if res.get("duplicate"):
                wa_apply_status(db.wa_messages[row.id], res.get("status"), now,
                                error_text="انتهت هذه الرسالة بالفشل في البوابة؛ أعد إرسالها لمحاولة جديدة")
        db.commit()
        return res
    except Exception as e:
        db.rollback()
        return {"ok": False, "error_text": "تعذّر إرسال رسالة واتساب: %s" % e}


def wa_retry_due(limit=3):
    """معالجة الرسائل المستحقة لإعادة المحاولة، والرسائل المعلّقة منذ مدة طويلة."""
    try:
        stuck = (db.wa_messages.status == "sending") & (
            db.wa_messages.status_at < request.now - datetime.timedelta(minutes=WA_STALE_MINUTES))
        # بمرجع البوابة: إعادتها لقائمة الإرسال آمنة، فالبوابة لا تكرر المرجع نفسه
        db(stuck & (db.wa_messages.hub_ref != None)).update(status="pending", next_attempt_at=request.now)
        # مباشرة لميتا: النتيجة مجهولة، وإعادة الإرسال قد تكرر الرسالة
        db(stuck & (db.wa_messages.hub_ref == None)).update(
            status="failed", next_attempt_at=None, error_text=WA_UNKNOWN_OUTCOME)
        db.commit()
        due = db(
            (db.wa_messages.status == "pending") & (db.wa_messages.next_attempt_at <= request.now)
        ).select(db.wa_messages.id, orderby=db.wa_messages.next_attempt_at, limitby=(0, limit))
        for row in due:
            wa_dispatch(row.id)
    except Exception:
        db.rollback()


def wa_send_queued(*message_ids):
    """
    إرسال الرسائل المحددة فوراً بعد db.commit في المتحكم. إن نجح أي منها (الاتصال سليم)،
    تُعالج معها رسائل متأخرة مستحقة لإعادة المحاولة. لا يرفع استثناء.
    """
    ok = False
    for message_id in message_ids:
        if message_id:
            ok = wa_dispatch(message_id).get("ok") or ok
    if ok:
        wa_retry_due()
    return ok


def wa_requeue(row):
    """إعادة رسالة فاشلة أو منتظرة لقائمة الإرسال (إعادة الإرسال اليدوية)."""
    vals = dict(status="pending", next_attempt_at=request.now)
    if row.hub_id:
        # استلمتها البوابة وانتهت بالفشل: محاولة جديدة بمرجع جديد، وإلا عدّتها البوابة تكراراً
        vals.update(hub_ref=None, hub_id=None)
    row.update_record(**vals)


def wa_apply_status(row, new, at, error_code=None, error_text=None, recover=False):
    """
    حالة جديدة لرسالة من إشعار (ميتا أو البوابة) دون الرجوع لحالة أقدم. يعيد True إن تغيّرت.
    recover: حالة ناجحة أحدث من الفشل تُقبل، لأن البوابة قد تعيد إرسال رسالة فاشلة من لوحتها.
    """
    if new == "failed":
        if row.status in ("delivered", "read"):
            return False
        row.update_record(status="failed", error_code=error_code, error_text=error_text,
                          next_attempt_at=None, status_at=at)
        return True
    if new not in WA_STATUS_RANK:
        return False
    if row.status == "failed":
        if not (recover and (row.status_at is None or at > row.status_at)):
            return False
    elif WA_STATUS_RANK[new] <= WA_STATUS_RANK.get(row.status, 0):
        return False
    row.update_record(status=new, status_at=at, error_code=None, error_text=None, next_attempt_at=None)
    return True


def wa_find_party(mobile):
    """أسرة أو مورد بهذا الرقم: (النوع، الصف)، أو (None، None)."""
    local = whatsapp_cloud.local_mobile(mobile)
    if not local:
        return None, None
    family = db(db.families.mobile == local).select(
        db.families.id, db.families.name, limitby=(0, 1)).first()
    if family:
        return "family", family
    supplier = db(db.suppliers.mobile == local).select(
        db.suppliers.id, db.suppliers.name, limitby=(0, 1)).first()
    if supplier:
        return "supplier", supplier
    return None, None


def _wa_store_inbound(key, mobile, name, msg_type, body, at):
    """حفظ رسالة واردة مرة واحدة فقط، مع ربطها بالأسرة أو المورد صاحب الرقم."""
    if not key or not db(db.wa_inbound.wamid == key).isempty():
        return False
    kind, party = wa_find_party(mobile)
    db.wa_inbound.insert(
        wamid=key,
        from_mobile=mobile or "",
        from_name=name or "",
        party_kind=kind or "",
        party_id=party.id if party else None,
        party_name=party.name if party else "",
        msg_type=msg_type or "",
        body=body or "",
        received_at=at or request.now,
    )
    return True


def wa_apply_webhook(payload):
    """تطبيق إشعار ميتا: تحديث حالات الرسائل المرسلة وحفظ ردود العملاء. يعيد (الحالات، الردود)."""
    statuses, inbound = whatsapp_cloud.parse_webhook(payload)
    for st in statuses:
        if not st["wamid"] or st["status"] not in ("sent", "delivered", "read", "failed"):
            continue
        row = db(db.wa_messages.wamid == st["wamid"]).select(limitby=(0, 1)).first()
        if not row:
            continue  # رسالة لم تُرسل من هذا النظام
        wa_apply_status(row, st["status"], st["timestamp"] or request.now, error_code=st["error_code"],
                        error_text=whatsapp_cloud.describe_error(st["error_code"], st["error_text"]))
    for msg in inbound:
        _wa_store_inbound(msg["wamid"], msg["from"], msg["name"], msg["type"], msg["text"], msg["timestamp"])
    db.commit()
    return len(statuses), len(inbound)


def _hub_time(value):
    """وقت البوابة (ISO مع فرق التوقيت) بتوقيت الخادم المحلي كبقية أوقات النظام، أو None."""
    try:
        moment = datetime.datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    return moment.astimezone().replace(tzinfo=None) if moment.tzinfo else moment


def wa_apply_hub_event(payload):
    """
    تطبيق إشعار من البوابة: حالة رسالة أرسلها النظام، أو رد عميل، أو طلب إيقاف الرسائل.
    أي حدث آخر (مثل الإشعار التجريبي) لا يحتاج شيئاً. يعيد True إن تغيّر شيء.
    """
    payload = payload if isinstance(payload, dict) else {}
    event = payload.get("event")
    at = _hub_time(payload.get("at")) or request.now
    changed = False
    if event == "message.status":
        ref = str(payload.get("ref") or "")
        row = db(db.wa_messages.hub_ref == ref).select(limitby=(0, 1)).first() if ref else None
        if row:
            if payload.get("id") and row.hub_id != payload.get("id"):
                row.update_record(hub_id=payload.get("id"))
            try:
                code = int(payload["error_code"]) if payload.get("error_code") is not None else None
            except (TypeError, ValueError):
                code = None
            changed = wa_apply_status(row, payload.get("status"), at, error_code=code,
                                      error_text=payload.get("error_text") or "", recover=True)
    elif event == "message.inbound" and payload.get("inbound_id"):
        changed = _wa_store_inbound("hub-in:%s" % payload["inbound_id"], payload.get("from"),
                                    payload.get("name"), payload.get("type"), payload.get("text"), at)
    elif event == "optout" and payload.get("msisdn"):
        note = ("طلب صاحب الرقم إيقاف رسائل واتساب، فلن تُرسل له رسائل بعد الآن"
                if payload.get("source") == "keyword" else "أُوقفت رسائل واتساب لهذا الرقم من لوحة البوابة")
        changed = _wa_store_inbound("hub-optout:%s:%s" % (payload["msisdn"], payload.get("at") or ""),
                                    payload["msisdn"], "", "optout", note, at)
    db.commit()
    return changed
