# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# جداول الأعمال (Business Tables)
# الأسر - الموردين - البضائع المستلمة - مرتجع البضاعة - التسديد
# ===========================================================================================

# ------------------------------------------------------------------------------------
#  جدول الأسر
db.define_table(
    "families",
    Field(
        "name",
        length=260,
        label="اسم الأسرة",
        required=True,
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("family_no", length=15, label="رقم الأسرة"),
    Field("mobile", length=10, label="رقم جوال التواصل"),
    Field("national_id", length=10, label="رقم الهوية / السجل"),
    Field("family_type", "reference key_family_type", label="فئة الأسرة"),
    Field("members_count", "integer", default=1, label="عدد أفراد الأسرة"),
    Field("guardian_name", length=150, label="اسم ولي الأسرة"),
    Field("address", "text", label="العنوان"),
    Field("reg_date", "date", default=request.now, label="تاريخ التسجيل"),
    Field("prev_bal_for", "double", default=0, label="الرصيد السابق له"),
    Field("prev_bal_on", "double", default=0, label="الرصيد السابق عليه"),
    Field("sale_percent", "double", default=0, label="نسبة المبيعات %"),
    Field("stoped", "boolean", default=False, label="ملف مقفل"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
    format="%(id)s - %(name)s",
)
db.families.id.label = "م"

# ------------------------------------------------------------------------------------
#  جدول الموردين
db.define_table(
    "suppliers",
    Field(
        "name",
        length=260,
        label="اسم المورد",
        required=True,
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("tel", "text", label="هواتف المورد"),
    Field("mobile", length=10, label="رقم الجوال"),
    Field("address", "text", label="العنوان"),
    Field("bank_account", "text", label="رقم الحساب في البنك"),
    Field("days_to_pay", "integer", label="عدد الأيام للسداد"),
    Field("reg_date", "date", default=request.now, label="تاريخ التسجيل"),
    Field("prev_bal_for", "double", default=0, label="الرصيد السابق له"),
    Field("prev_bal_on", "double", default=0, label="الرصيد السابق عليه"),
    Field("sale_percent", "double", default=0, label="نسبة المبيعات %"),
    Field("stoped", "boolean", default=False, label="موقف"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
    format="%(id)s - %(name)s",
)
db.suppliers.id.label = "م"

# ------------------------------------------------------------------------------------
#  البضائع المستلمة (سند استلام بضاعة)
#  قد تكون واردة من مورد (تزيد مستحقات المورد)
#  أو مسلمة لأسرة على الحساب (تزيد مستحقات الأسرة)
db.define_table(
    "goods_received",
    Field("receipt_no", length=15, label="رقم سند الاستلام"),
    Field(
        "receipt_date",
        "date",
        label="تاريخ الاستلام",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("receipt_time", "time", label="وقت الاستلام"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field("family", "reference families", label="الأسرة"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("invoce_type", "reference key_invoce_type", label="نوع السند"),
    Field(
        "bill_total",
        "double",
        default=0,
        label="اجمالي المبلغ",
        readable=False,
        writable=False,
    ),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
    format="%(receipt_no)s",
)
db.goods_received.id.label = "م"

#  اصناف البضائع المستلمة (تفاصيل سند الاستلام)
db.define_table(
    "goods_received_items",
    Field(
        "goods_received",
        "reference goods_received",
        label="سند الاستلام",
        readable=False,
        writable=False,
    ),
    Field(
        "item_name",
        length=260,
        label="اسم البضاعة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("item_type", "reference key_type", label="التصنيف"),
    Field("unit", "reference key_unit", label="الوحدة"),
    Field("quantity", "double", default=1, label="الكمية"),
    Field("price", "double", default=0, label="السعر"),
    Field("total", "double", default=0, label="الاجمالي"),
    auth.signature,
)
db.goods_received_items.id.label = "م"

# ------------------------------------------------------------------------------------
#  مرتجع البضاعة (سند مرتجع)
#  مرتجع الى مورد (يخصم من مستحقاته) او مرتجع من أسرة (يخصم من مستحقاتها)
db.define_table(
    "goods_return",
    Field("return_no", length=15, label="رقم سند المرتجع"),
    Field(
        "return_date",
        "date",
        label="تاريخ المرتجع",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("return_time", "time", label="وقت المرتجع"),
    Field("supplier", "reference suppliers", label="المورد"),
    Field("family", "reference families", label="الأسرة"),
    Field(
        "total",
        "double",
        default=0,
        label="اجمالي المبلغ",
        readable=False,
        writable=False,
    ),
    Field("note", "text", label="سبب المرتجع / ملاحظات"),
    auth.signature,
    format="%(return_no)s",
)
db.goods_return.id.label = "م"

#  اصناف مرتجع البضاعة (تفاصيل سند المرتجع)
db.define_table(
    "goods_return_items",
    Field(
        "goods_return",
        "reference goods_return",
        label="سند المرتجع",
        readable=False,
        writable=False,
    ),
    Field(
        "item_name",
        length=260,
        label="اسم البضاعة",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("item_type", "reference key_type", label="التصنيف"),
    Field("unit", "reference key_unit", label="الوحدة"),
    Field("quantity", "double", default=1, label="الكمية"),
    Field("price", "double", default=0, label="السعر"),
    Field("total", "double", default=0, label="الاجمالي"),
    auth.signature,
)
db.goods_return_items.id.label = "م"

# ------------------------------------------------------------------------------------
#  تسديد الموردين
db.define_table(
    "supplier_payments",
    Field("supplier", "reference suppliers", label="المورد"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("payment_type", "reference key_payment_type", label="نوع السداد"),
    Field(
        "pay_total",
        "double",
        label="المبلغ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "pay_date",
        "date",
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("pay_time", "time", label="وقت السداد"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.supplier_payments.id.label = "م"

# ------------------------------------------------------------------------------------
#  تسديد الأسر
db.define_table(
    "family_payments",
    Field("family", "reference families", label="الأسرة"),
    Field("payment_method", "reference key_payment_method", label="طريقة الدفع"),
    Field("payment_type", "reference key_payment_type", label="نوع السداد"),
    Field(
        "amount",
        "double",
        label="المبلغ",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field(
        "pay_date",
        "date",
        label="تاريخ السداد",
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("pay_time", "time", label="وقت السداد"),
    Field("pay_note", "text", label="ملاحظات السداد"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
)
db.family_payments.id.label = "م"

# ------------------------------------------------------------------------------------
#  يوميات الصندوق (قيد يومي واحد لكل تاريخ)
#  الاجماليات تُحسب عند الحفظ في cashbox_api.save_entry:
#    total_in        = opening_balance + pos_total + bank_withdrawal
#    total_out       = misc_expenses + paid_to_suppliers
#    closing_balance = total_in - total_out
#    net_sales       = pos_total - paid_to_suppliers (اسم عمود قديم للتوافق)
#    cash_difference = actual_closing_cash - closing_balance
db.define_table(
    "cash_journal",
    Field(
        "register_date",
        "date",
        label="تاريخ اليومية",
        required=True,
        unique=True,
        requires=IS_NOT_EMPTY(error_message="يجب ادخال هذا الحقل"),
    ),
    Field("opening_balance", "decimal(18,2)", default=0, label="الرصيد الافتتاحي"),
    Field("pos_total", "decimal(18,2)", default=0, label="مبيعات نقاط البيع / الشبكة"),
    Field("bank_withdrawal", "decimal(18,2)", default=0, label="سحب من البنك"),
    Field("misc_expenses", "decimal(18,2)", default=0, label="مصروفات متنوعة"),
    Field("paid_to_suppliers", "decimal(18,2)", default=0, label="المسدد للموردين والأسر"),
    Field("family_received", "decimal(18,2)", default=0, label="المستلم من الأسر", readable=False, writable=False),
    Field("family_returned", "decimal(18,2)", default=0, label="المرتجع للأسر", readable=False, writable=False),
    Field("family_net_sales", "decimal(18,2)", default=0, label="صافي مبيعات الأسر", readable=False, writable=False),
    Field("family_commission_rate", "decimal(7,4)", default=0, label="متوسط نسبة المتجر", readable=False, writable=False),
    Field("family_commission_amount", "decimal(18,2)", default=0, label="حصة المتجر من الأسر", readable=False, writable=False),
    Field("family_net_amount", "decimal(18,2)", default=0, label="صافي مبلغ الأسر", readable=False, writable=False),
    Field("family_summary_captured_at", "datetime", label="وقت حفظ ملخص الأسر", readable=False, writable=False),
    Field(
        "total_in",
        "decimal(18,2)",
        default=0,
        label="إجمالي الوارد",
        readable=False,
        writable=False,
    ),
    Field(
        "total_out",
        "decimal(18,2)",
        default=0,
        label="إجمالي المنصرف",
        readable=False,
        writable=False,
    ),
    Field(
        "closing_balance",
        "decimal(18,2)",
        default=0,
        label="الرصيد الختامي",
        readable=False,
        writable=False,
    ),
    Field(
        "net_sales",
        "decimal(18,2)",
        default=0,
        label="صافي الحركة بعد المسدد",
        readable=False,
        writable=False,
    ),
    Field("actual_closing_cash", "decimal(18,2)", label="الكاش الفعلي آخر الفترة"),
    Field(
        "cash_difference",
        "decimal(18,2)",
        label="فرق الصندوق",
        readable=False,
        writable=False,
    ),
    Field("difference_reason", "text", label="سبب فرق الصندوق"),
    Field("locked", "boolean", default=False, label="يومية مقفلة"),
    Field("locked_at", "datetime", label="وقت الإقفال", readable=False, writable=False),
    Field("locked_by", "reference auth_user", label="أقفل بواسطة", readable=False, writable=False),
    Field("reopened_at", "datetime", label="وقت إعادة الفتح", readable=False, writable=False),
    Field("reopened_by", "reference auth_user", label="أعيد فتحها بواسطة", readable=False, writable=False),
    Field("reopen_reason", "text", label="سبب إعادة الفتح"),
    Field("note", "text", label="ملاحظات"),
    auth.signature,
    format="%(register_date)s",
)
db.cash_journal.id.label = "م"

# web2py لا ينشئ دائماً فهرس unique عند ترقية جدول SQLite موجود.
# هذا الفهرس هو خط الدفاع النهائي بجانب تحقق الـ API.
if getattr(db._adapter, "dbengine", "") == "sqlite":
    db.executesql(
        "CREATE UNIQUE INDEX IF NOT EXISTS cash_journal_register_date_uq "
        "ON cash_journal (register_date)"
    )

# سجل تدقيق مستقل لكل عملية إقفال أو إعادة فتح.
db.define_table(
    "cash_journal_events",
    Field("cash_journal", "reference cash_journal", label="اليومية", ondelete="CASCADE"),
    Field("event_type", length=20, label="العملية"),
    Field("event_at", "datetime", default=request.now, label="الوقت"),
    Field("performed_by", "reference auth_user", label="المستخدم"),
    Field("expected_cash", "decimal(18,2)", label="الكاش المتوقع"),
    Field("actual_cash", "decimal(18,2)", label="الكاش الفعلي"),
    Field("cash_difference", "decimal(18,2)", label="الفرق"),
    Field("note", "text", label="السبب / الملاحظات"),
)

# تفصيل لقطة الأسر عند الإقفال. الاسم والنسبة محفوظان لضمان ثبات التقفيلة
# حتى لو تغير ملف الأسرة لاحقاً.
db.define_table(
    "cash_journal_family_summary",
    Field("cash_journal", "reference cash_journal", label="اليومية", ondelete="CASCADE"),
    Field("family", "reference families", label="الأسرة", ondelete="SET NULL"),
    Field("family_name", length=260, label="اسم الأسرة وقت الإقفال"),
    Field("sale_percent", "decimal(7,4)", default=0, label="النسبة وقت الإقفال"),
    Field("received", "decimal(18,2)", default=0, label="المستلم"),
    Field("returned", "decimal(18,2)", default=0, label="المرتجع"),
    Field("net_sales", "decimal(18,2)", default=0, label="صافي المبيعات"),
    Field("commission_amount", "decimal(18,2)", default=0, label="حصة المتجر"),
    Field("net_amount", "decimal(18,2)", default=0, label="صافي الأسرة"),
)
