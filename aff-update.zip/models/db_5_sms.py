# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
#  الإشعارات النصية التلقائية للأحداث (استلام / مرتجع / سداد)
#  تُستدعى من الـ APIs بعد db.commit()، ومعزولة تماماً: لا ترفع استثناء أبداً
#  حتى لا يُسقط فشلُ الرسالة عمليةَ الحفظ.
# ===========================================================================================

# ربط كل حدث بحقلي (التفعيل، الصيغة) في جدول sms_settings
_SMS_EVENT_FIELDS = {
    "receipt": ("on_receipt", "tpl_receipt"),
    "return":  ("on_return",  "tpl_return"),
    "payment": ("on_payment", "tpl_payment"),
}


def _sms_fmt_amount(value):
    """تنسيق المبلغ: صحيح بلا كسور، وإلا خانتان عشريتان."""
    try:
        f = float(value or 0)
    except (TypeError, ValueError):
        return str(value or "")
    return str(int(f)) if f == int(f) else ("%.2f" % f)


def sms_notify(event, mobile, name="", amount=None, doc=None, date=None):
    """
    إرسال إشعار تلقائي إن كانت خدمة الرسائل مفعّلة والحدث مُفعّلاً في الإعدادات.
    معزولة تماماً: تُعيد dict موحّد {ok, mess, ...} ولا ترفع استثناء مهما حدث.

        sms_notify("receipt", family.mobile, name=family.name,
                   amount=total, doc=receipt_no, date=receipt_date)
    """
    try:
        fields = _SMS_EVENT_FIELDS.get(event)
        if not fields:
            return {"ok": False, "mess": "حدث غير معروف"}
        flag_field, tpl_field = fields

        cfg = db(db.sms_settings.id > 0).select().first()
        # المفتاح الرئيسي + مفتاح الحدث يجب أن يكونا مُفعّلين
        if not cfg or not cfg.enabled or not cfg[flag_field]:
            return {"ok": False, "mess": "الإرسال التلقائي غير مُفعّل لهذا الحدث"}
        if not (sms_authorization and sms_sender):
            return {"ok": False, "mess": "بيانات مزوّد الرسائل غير مضبوطة"}

        template = (cfg[tpl_field] or "").strip()
        if not template:
            return {"ok": False, "mess": "لا توجد صيغة للرسالة"}

        import send_sms

        org_row = db(db.important_info.id > 0).select(db.important_info.name).first()
        org = (org_row.name if org_row else "") or ""

        message = send_sms.render_template(
            template,
            name=name or "",
            amount=_sms_fmt_amount(amount),
            date=str(date or ""),
            doc=str(doc or ""),
            org=org,
        )
        # إرسال آمن (يُطبّع الرقم السعودي ولا يرفع استثناء)
        return send_sms.send_message(sms_authorization, sms_sender, mobile, message)
    except Exception as e:
        return {"ok": False, "mess": "تعذّر إرسال الإشعار النصي: " + str(e)}
