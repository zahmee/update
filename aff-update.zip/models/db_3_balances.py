# -*- coding: utf-8 -*-
#  type: ignore
# ===========================================================================================
# حساب المستحق الموحّد للموردين والأسر (Net Due)
#   صافي البضاعة = المستلم − المرتجع
#   العمولة       = صافي البضاعة × نسبة المبيعات ÷ 100
#   المستحق       = صافي البضاعة − العمولة + السابق له − السابق عليه − المدفوع
#   موجب = «له» (ندفع له) ، سالب = «عليه» (يدفع لنا)
# دوال مشتركة تُستدعى من كل المتحكمات (المتحكمات تشارك نطاق النماذج).
# ===========================================================================================


def _bal_sum(query, field):
    row = db(query).select(field.sum()).first()
    return (row[field.sum()] or 0) if row else 0


def compute_due(received, returned, paid, prev_for, prev_on, sale_percent):
    """الصيغة النقية — تُرجع تفصيل المستحق من القيم المجمّعة"""
    received = received or 0
    returned = returned or 0
    paid = paid or 0
    prev_for = prev_for or 0
    prev_on = prev_on or 0
    sale_percent = sale_percent or 0
    net_goods = received - returned
    commission = net_goods * sale_percent / 100.0
    net_due = net_goods - commission + prev_for - prev_on - paid
    return {
        "received": round(received, 2),
        "returned": round(returned, 2),
        "net_goods": round(net_goods, 2),
        "sale_percent": round(sale_percent, 2),
        "commission": round(commission, 2),
        "prev_for": round(prev_for, 2),
        "prev_on": round(prev_on, 2),
        "paid": round(paid, 2),
        "net_due": round(net_due, 2),
        "side": "له" if net_due >= 0 else "عليه",
    }


def party_aggregates(kind, party_id):
    """مجاميع طرف واحد: (المستلم، المرتجع، المدفوع)"""
    if kind == "supplier":
        recv = _bal_sum(db.goods_received.supplier == party_id, db.goods_received.bill_total)
        ret = _bal_sum(db.goods_return.supplier == party_id, db.goods_return.total)
        paid = _bal_sum(db.supplier_payments.supplier == party_id, db.supplier_payments.pay_total)
    else:
        recv = _bal_sum(db.goods_received.family == party_id, db.goods_received.bill_total)
        ret = _bal_sum(db.goods_return.family == party_id, db.goods_return.total)
        paid = _bal_sum(db.family_payments.family == party_id, db.family_payments.amount)
    return recv, ret, paid


def party_net_due(kind, row):
    """تفصيل المستحق لطرف واحد (صف من families أو suppliers)"""
    recv, ret, paid = party_aggregates(kind, row.id)
    return compute_due(recv, ret, paid, row.prev_bal_for, row.prev_bal_on, row.sale_percent)


def _grouped_sum(table, party_field, value_field):
    """خريطة {party_id: sum} مجمّعة على مستوى الجدول (لتفادي N+1 في القوائم)"""
    q = table[party_field] != None
    rows = db(q).select(table[party_field], value_field.sum(), groupby=table[party_field])
    return {r[table[party_field]]: (r[value_field.sum()] or 0) for r in rows}


def party_due_maps(kind):
    """خريطة {party_id: تفصيل المستحق} لكل الأطراف من نوع معيّن — للقوائم"""
    if kind == "supplier":
        recv = _grouped_sum(db.goods_received, "supplier", db.goods_received.bill_total)
        ret = _grouped_sum(db.goods_return, "supplier", db.goods_return.total)
        paid = _grouped_sum(db.supplier_payments, "supplier", db.supplier_payments.pay_total)
        parties = db(db.suppliers.id > 0).select()
    else:
        recv = _grouped_sum(db.goods_received, "family", db.goods_received.bill_total)
        ret = _grouped_sum(db.goods_return, "family", db.goods_return.total)
        paid = _grouped_sum(db.family_payments, "family", db.family_payments.amount)
        parties = db(db.families.id > 0).select()
    out = {}
    for p in parties:
        out[p.id] = compute_due(
            recv.get(p.id, 0), ret.get(p.id, 0), paid.get(p.id, 0),
            p.prev_bal_for, p.prev_bal_on, p.sale_percent,
        )
    return out


def locked_day(day):
    """إرجاع يومية الصندوق المقفلة لتاريخ معين، إن وجدت."""
    if not day:
        return None
    return db(
        (db.cash_journal.register_date == day)
        & (db.cash_journal.locked == True)
    ).select(db.cash_journal.id, db.cash_journal.register_date, limitby=(0, 1)).first()


def locked_day_message(day):
    """رسالة منع موحدة للحركات المالية بعد قفل اليومية."""
    if locked_day(day):
        return "لا يمكن تعديل أو حذف حركة بتاريخ %s لأن يومية الصندوق مقفلة" % day
    return ""
