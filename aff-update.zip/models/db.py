# -*- coding: utf-8 -*-
#  type: ignore


import datetime
from gluon.contrib.appconfig import AppConfig
from gluon.tools import Auth

if request.global_settings.web2py_version < "2.15.5":
    raise HTTP(500, "Requires web2py 2.15.5 or newer")

# تطوير محلي فقط: إعادة تحميل وحدات modules/ تلقائياً عند تعديلها (بلا إعادة تشغيل)
if request.is_local:
    from gluon.custom_import import track_changes
    track_changes(True)

configuration = AppConfig(reload=True)
sms_authorization = configuration.get("sms.authorization")
sms_sender = configuration.get("sms.sender")
c = datetime.datetime.now()
exp = configuration.get("app.exp_date")
if exp:
    d1 = datetime.datetime.strptime(c.strftime("%Y-%m-%d"), "%Y-%m-%d")
    d2 = datetime.datetime.strptime(exp, "%Y-%m-%d")
    date_def = (d2 - d1).days
    if date_def < 1:
        raise HTTP(
            400,
            (
                "<h1 style='text-align: center;' > نعتذر منك لقد انتهى اشتراكك </h1>"
                f"<h2 style='text-align: center;' > {exp} </h2>"
            ),
        )


if not request.env.web2py_runtime_gae:
    # ---------------------------------------------------------------------
    # if NOT running on Google App Engine use SQLite or other DB
    # ---------------------------------------------------------------------
    db = DAL(
        configuration.get("db.uri"),
        pool_size=configuration.get("db.pool_size"),
        migrate_enabled=configuration.get("db.migrate"),
        check_reserved=["postgres"],
    )
else:
    db = DAL("google:datastore+ndb")
    session.connect(request, response, db=db)

response.generic_patterns = []
if request.is_local and not configuration.get("app.production"):
    response.generic_patterns.append("*")

response.formstyle = "bootstrap4_inline"
response.form_label_separator = ""

auth = Auth(db, host_names=configuration.get("host.names"))

auth.settings.extra_fields["auth_user"] = []
auth.define_tables(username=False, signature=False)

# -------------------------------------------------------------------------
# configure email
# -------------------------------------------------------------------------
mail = auth.settings.mailer
mail.settings.server = (
    "logging" if request.is_local else configuration.get("smtp.server")
)
mail.settings.sender = configuration.get("smtp.sender")
mail.settings.login = configuration.get("smtp.login")
mail.settings.tls = configuration.get("smtp.tls") or False
mail.settings.ssl = configuration.get("smtp.ssl") or False

# -------------------------------------------------------------------------
# configure auth policy
# -------------------------------------------------------------------------
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.settings.reset_password_requires_verification = True
auth.settings.actions_disabled = ['register', 'bulk_register']

# -------------------------------------------------------------------------
# read more at http://dev.w3.org/html5/markup/meta.name.html
# -------------------------------------------------------------------------
response.meta.author = configuration.get("app.author")
response.meta.description = configuration.get("app.description")
response.meta.keywords = configuration.get("app.keywords")
response.meta.generator = configuration.get("app.generator")
response.show_toolbar = configuration.get("app.toolbar")

# -------------------------------------------------------------------------
# your http://google.com/analytics id
# -------------------------------------------------------------------------
response.google_analytics_id = configuration.get("google.analytics_id")

# -------------------------------------------------------------------------
# maybe use the scheduler
# -------------------------------------------------------------------------
if configuration.get("scheduler.enabled"):
    from gluon.scheduler import Scheduler

    scheduler = Scheduler(db, heartbeat=configuration.get("scheduler.heartbeat"))

# -------------------------------------------------------------------------
# after defining tables, uncomment below to enable auditing
# -------------------------------------------------------------------------
# auth.enable_record_versioning(db)
auth.settings.create_user_groups = False
auth.settings.showid = False
T.force("ar")
response.delimiters = ("{{{", "}}}")

# ===========================================================================================
# Table definitions are split into separate model files:
#   db_1_keys.py       - Lookup/key tables (key_unit, key_payment_method, etc.)
#   db_2_business.py   - Families, Suppliers, Goods Received, Returns, Payments
#   db_4_access.py     - Screens, screens_rules, important_info, can_access(), screens_rules()
# ===========================================================================================
