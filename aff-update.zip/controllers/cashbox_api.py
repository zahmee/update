# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  يوميات الصندوق - APIs
#  قيد يومي واحد لكل تاريخ، الاجماليات تحسب عند الحفظ
# ======================================================================================
import api_helpers as api
import cashbox_domain as cash


def _clean_text(value):
    return (value or "").strip()


def _is_true(value):
    return str(value or "").lower() in ("true", "1", "yes", "on")


def _user_names(user_ids):
    ids = [uid for uid in set(user_ids) if uid]
    if not ids:
        return {}
    rows = db(db.auth_user.id.belongs(ids)).select(
        db.auth_user.id, db.auth_user.first_name, db.auth_user.last_name
    )
    return {
        row.id: ("%s %s" % (row.first_name or "", row.last_name or "")).strip()
        for row in rows
    }


def _row_to_dict(r, user_names=None):
    names = user_names or {}
    return {
        "id": r.id,
        "register_date": str(r.register_date or ""),
        "separated_accounts": bool(r.separated_accounts),
        "opening_balance": cash.json_money(r.opening_balance or 0),
        "cash_sales": cash.json_money(r.cash_sales or 0),
        "pos_total": cash.json_money(r.pos_total or 0),
        "bank_withdrawal": cash.json_money(r.bank_withdrawal or 0),
        "misc_expenses": cash.json_money(r.misc_expenses or 0),
        "paid_to_suppliers": cash.json_money(r.paid_to_suppliers or 0),
        "cash_paid_to_suppliers": cash.json_money(r.cash_paid_to_suppliers or 0),
        "cash_deposit_to_bank": cash.json_money(r.cash_deposit_to_bank or 0),
        "bank_opening_balance": cash.json_money(r.bank_opening_balance or 0),
        "bank_deposit": cash.json_money(r.bank_deposit or 0),
        "bank_paid_to_suppliers": cash.json_money(r.bank_paid_to_suppliers or 0),
        "bank_expenses": cash.json_money(r.bank_expenses or 0),
        "bank_closing_balance": cash.json_money(r.bank_closing_balance or 0),
        "actual_closing_bank": cash.json_money(r.actual_closing_bank),
        "bank_difference": cash.json_money(r.bank_difference),
        "bank_difference_reason": r.bank_difference_reason or "",
        "pos_fees": cash.json_money(r.pos_fees or 0),
        "pos_net_to_bank": cash.json_money(
            cash.money(r.pos_total or 0) - cash.money(r.pos_fees or 0)
        ),
        "unallocated_payments": cash.json_money(r.unallocated_payments or 0),
        "family_received": cash.json_money(r.family_received or 0),
        "family_returned": cash.json_money(r.family_returned or 0),
        "family_net_sales": cash.json_money(r.family_net_sales or 0),
        "family_commission_rate": float(r.family_commission_rate or 0),
        "family_commission_amount": cash.json_money(r.family_commission_amount or 0),
        "family_net_amount": cash.json_money(r.family_net_amount or 0),
        "total_in": cash.json_money(r.total_in or 0),
        "total_out": cash.json_money(r.total_out or 0),
        "closing_balance": cash.json_money(r.closing_balance or 0),
        "net_sales": cash.json_money(r.net_sales or 0),
        "actual_closing_cash": cash.json_money(r.actual_closing_cash),
        "cash_difference": cash.json_money(r.cash_difference),
        "difference_reason": r.difference_reason or "",
        "locked": bool(r.locked),
        "locked_at": str(r.locked_at or ""),
        "locked_by": r.locked_by,
        "locked_by_name": names.get(r.locked_by, ""),
        "reopened_at": str(r.reopened_at or ""),
        "reopened_by": r.reopened_by,
        "reopened_by_name": names.get(r.reopened_by, ""),
        "reopen_reason": r.reopen_reason or "",
        "note": r.note or "",
    }


def _payment_totals_for(day):
    """قسّم سدادات اليوم حسب الحساب المرتبط بطريقة السداد."""
    totals = {"cash": cash.ZERO, "bank": cash.ZERO, "none": cash.ZERO}
    supplier_rows = db(db.supplier_payments.pay_date == day).select(
        db.supplier_payments.payment_method,
        db.supplier_payments.pay_total,
    )
    family_rows = db(db.family_payments.pay_date == day).select(
        db.family_payments.payment_method,
        db.family_payments.amount,
    )
    for row in supplier_rows:
        source = payment_account_source(row.payment_method)
        totals[source] += cash.money(row.pay_total)
    for row in family_rows:
        source = payment_account_source(row.payment_method)
        totals[source] += cash.money(row.amount)
    totals["total"] = (totals["cash"] + totals["bank"] + totals["none"]).quantize(cash.CENT)
    return totals


def _paid_total_for(day):
    """مجموع المسدد الفعلي لليوم، للتوافق مع اليوميات القديمة."""
    return _payment_totals_for(day)["total"]


def _family_summary_for(day):
    """ملخص استلام ومرتجع الأسر في يوم واحد، محسوب حسب نسبة كل أسرة."""
    received_rows = db(
        (db.goods_received.receipt_date == day)
        & (db.goods_received.family != None)
    ).select(
        db.goods_received.family,
        db.goods_received.bill_total.sum(),
        groupby=db.goods_received.family,
    )
    returned_rows = db(
        (db.goods_return.return_date == day)
        & (db.goods_return.family != None)
    ).select(
        db.goods_return.family,
        db.goods_return.total.sum(),
        groupby=db.goods_return.family,
    )
    received = {
        row[db.goods_received.family]: row[db.goods_received.bill_total.sum()] or 0
        for row in received_rows
    }
    returned = {
        row[db.goods_return.family]: row[db.goods_return.total.sum()] or 0
        for row in returned_rows
    }
    family_ids = set(received) | set(returned)
    if not family_ids:
        summary = cash.calculate_family_summary([])
        summary["source"] = "live"
        return summary

    families = db(db.families.id.belongs(list(family_ids))).select(
        db.families.id, db.families.name, db.families.sale_percent
    )
    family_map = {row.id: row for row in families}
    entries = []
    for family_id in family_ids:
        family = family_map.get(family_id)
        entries.append({
            "family_id": family_id,
            "family_name": family.name if family else "أسرة رقم %s" % family_id,
            "sale_percent": family.sale_percent if family else 0,
            "received": received.get(family_id, 0),
            "returned": returned.get(family_id, 0),
        })
    entries.sort(key=lambda item: item["family_name"] or "")
    summary = cash.calculate_family_summary(entries)
    summary["source"] = "live"
    return summary


def _family_summary_from_snapshot(journal):
    if not journal.family_summary_captured_at:
        summary = _family_summary_for(str(journal.register_date))
        summary["source"] = "legacy_live"
        return summary
    rows = db(
        db.cash_journal_family_summary.cash_journal == journal.id
    ).select(orderby=db.cash_journal_family_summary.family_name)
    return {
        "source": "snapshot",
        "received": journal.family_received or 0,
        "returned": journal.family_returned or 0,
        "net_sales": journal.family_net_sales or 0,
        "commission_rate": cash.percentage(journal.family_commission_rate or 0),
        "commission_amount": journal.family_commission_amount or 0,
        "net_amount": journal.family_net_amount or 0,
        "details": [{
            "family_id": row.family,
            "family_name": row.family_name or "أسرة غير معرّفة",
            "sale_percent": row.sale_percent or 0,
            "received": row.received or 0,
            "returned": row.returned or 0,
            "net_sales": row.net_sales or 0,
            "commission_amount": row.commission_amount or 0,
            "net_amount": row.net_amount or 0,
        } for row in rows],
    }


def _family_summary_json(summary):
    return {
        "source": summary.get("source", "live"),
        "received": cash.json_money(summary["received"]),
        "returned": cash.json_money(summary["returned"]),
        "net_sales": cash.json_money(summary["net_sales"]),
        "commission_rate": float(summary["commission_rate"] or 0),
        "commission_amount": cash.json_money(summary["commission_amount"]),
        "net_amount": cash.json_money(summary["net_amount"]),
        "details": [{
            "family_id": item["family_id"],
            "family_name": item["family_name"],
            "sale_percent": float(item["sale_percent"] or 0),
            "received": cash.json_money(item["received"]),
            "returned": cash.json_money(item["returned"]),
            "net_sales": cash.json_money(item["net_sales"]),
            "commission_amount": cash.json_money(item["commission_amount"]),
            "net_amount": cash.json_money(item["net_amount"]),
        } for item in summary["details"]],
    }


def _carried_balance(actual, expected):
    """رحّل الفعلي عند وجوده، وإلا المتوقع."""
    return cash.money(actual if actual is not None else expected)


def _account_opening_suggestions(day):
    """أرصدة افتتاحية للكاش والبنك دون خلط اليوميات القديمة بهما."""
    previous = db(
        (db.cash_journal.register_date < day)
        & (db.cash_journal.separated_accounts == True)
    ).select(orderby=~db.cash_journal.register_date, limitby=(0, 1)).first()
    if previous:
        return {
            "initial": False,
            "source_date": str(previous.register_date or ""),
            "previous_locked": bool(previous.locked),
            "cash": _carried_balance(previous.actual_closing_cash, previous.closing_balance),
            "bank": _carried_balance(previous.actual_closing_bank, previous.bank_closing_balance),
        }

    # أول يوم فصل: نأخذ الكاش الفعلي فقط من آخر يومية قديمة. لا نستخدم
    # رصيدها المتوقع لأنه كان يخلط نقاط البيع بالكاش. البنك يُدخل مرة
    # واحدة من المستخدم، ثم تدخل مبيعات الشبكة في رصيده التراكمي.
    legacy = db(db.cash_journal.register_date < day).select(
        orderby=~db.cash_journal.register_date, limitby=(0, 1)
    ).first()
    legacy_cash = None
    if legacy and legacy.actual_closing_cash is not None:
        legacy_cash = cash.money(legacy.actual_closing_cash)
    return {
        "initial": True,
        "source_date": str(legacy.register_date or "") if legacy else "",
        "previous_locked": bool(legacy.locked) if legacy else True,
        "cash": legacy_cash,
        "bank": None,
    }


def _later_separated_journal(day, exclude_id=0):
    query = (
        (db.cash_journal.register_date > day)
        & (db.cash_journal.separated_accounts == True)
    )
    if exclude_id:
        query &= db.cash_journal.id != exclude_id
    return db(query).select(
        db.cash_journal.id,
        db.cash_journal.register_date,
        limitby=(0, 1),
        orderby=db.cash_journal.register_date,
    ).first()


@can_access(5001)
def get_entries():
    """قائمة يوميات الصندوق مع فلتر تاريخ وترقيم صفحات"""
    ReqVar = request.vars
    try:
        pg = max(0, int(ReqVar.page or 0))
        requested_count = int(ReqVar.RecordCount or 20)
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="بيانات ترقيم الصفحات غير صحيحة"))
    rc = requested_count if requested_count in (20, 50, 100) else 20

    try:
        date_from, date_to = cash.validate_date_range(
            _clean_text(ReqVar.date_from), _clean_text(ReqVar.date_to)
        )
    except ValueError as e:
        return response.json(api.api_error(mess=str(e)))

    query = db.cash_journal.id > 0
    if date_from:
        query &= db.cash_journal.register_date >= date_from.isoformat()
    if date_to:
        query &= db.cash_journal.register_date <= date_to.isoformat()

    count = db(query).count()
    offset = pg * rc
    rows = db(query).select(
        orderby=~db.cash_journal.register_date, limitby=(offset, offset + rc)
    )
    names = _user_names(
        [r.locked_by for r in rows] + [r.reopened_by for r in rows]
    )
    data = [_row_to_dict(r, names) for r in rows]
    return response.json(api.api_list(rows=data, count=count, page=pg, page_size=rc))


@can_access(5001)
def get_entry_by_date():
    """يومية تاريخ معين + افتتاحيات الحسابات وسدادات اليوم موزعة حسب المصدر."""
    day_text = _clean_text(request.vars.date) or request.now.strftime("%Y-%m-%d")
    try:
        day = cash.parse_iso_date(day_text, required=True)
    except ValueError as e:
        return response.json(api.api_error(mess=str(e)))
    row = db(db.cash_journal.register_date == day.isoformat()).select().first()
    names = _user_names(
        [row.locked_by, row.reopened_by] if row else []
    )
    family_summary = (
        _family_summary_from_snapshot(row)
        if row and row.locked
        else _family_summary_for(day.isoformat())
    )
    payments = _payment_totals_for(day.isoformat())
    openings = _account_opening_suggestions(day.isoformat())
    later = _later_separated_journal(day.isoformat()) if not row else None
    can_create = True
    create_message = ""
    if later:
        can_create = False
        create_message = (
            "لا يمكن إنشاء يومية سابقة ليومية الحسابات المنفصلة بتاريخ %s"
            % later.register_date
        )
    elif not row and not openings["initial"] and not openings["previous_locked"]:
        can_create = False
        create_message = "يجب إقفال اليومية السابقة قبل إنشاء يومية جديدة"

    legacy_suggested = row.opening_balance if row and not row.separated_accounts else openings["cash"]
    return response.json(api.api_ok(data={
        "entry": _row_to_dict(row, names) if row else None,
        "suggested_opening": cash.json_money(legacy_suggested),
        "suggested_openings": {
            "cash": cash.json_money(openings["cash"]),
            "bank": cash.json_money(openings["bank"]),
            "initial": openings["initial"],
            "source_date": openings["source_date"],
        },
        "suggested_paid": cash.json_money(payments["total"]),
        "payment_totals": {
            "cash": cash.json_money(payments["cash"]),
            "bank": cash.json_money(payments["bank"]),
            "unallocated": cash.json_money(payments["none"]),
            "total": cash.json_money(payments["total"]),
        },
        "can_create": can_create,
        "create_message": create_message,
        "family_summary": _family_summary_json(family_summary),
    }))


@can_access(5001)
def save_entry():
    """حفظ يومية (ادراج او تعديل) — التاريخ هو مفتاح اليومية ولا يتكرر"""
    try:
        if request.env.request_method != "POST":
            return response.json(api.api_error(mess="طريقة الطلب غير مسموحة"))
        sc = screens_rules(5001)
        data = request.vars
        try:
            rec_id = int(data.id or 0)
        except (TypeError, ValueError):
            return response.json(api.api_error(mess="معرف اليومية غير صحيح"))
        day = cash.parse_iso_date(_clean_text(data.register_date), required=True)
        day_text = day.isoformat()
        lock_after_save = _is_true(data.lock_after_save)

        # تحديد السجل: بالمعرف او بالتاريخ (منع تكرار يومية لنفس التاريخ)
        if rec_id:
            row = db.cash_journal[rec_id]
            if not row:
                return response.json(api.api_error(mess="السجل غير موجود"))
            if not (sc and sc.can_edit):
                return response.json(api.api_error(mess="لا تملك صلاحية التعديل"))
            if str(row.register_date) != day_text:
                return response.json(api.api_error(mess="لا يمكن تغيير تاريخ يومية موجودة. أنشئ يومية جديدة للتاريخ المطلوب"))
            if row.locked:
                return response.json(api.api_error(mess="اليومية مقفلة. يجب إعادة فتحها قبل التعديل"))
        else:
            row = None
            if not (sc and sc.can_add):
                return response.json(api.api_error(mess="لا تملك صلاحية الاضافة"))
        duplicate = db(
            (db.cash_journal.register_date == day_text)
            & (db.cash_journal.id != rec_id)
        ).select(db.cash_journal.id, limitby=(0, 1)).first()
        if duplicate:
            return response.json(api.api_error(mess="توجد يومية مسجلة لهذا التاريخ"))

        is_separated = bool(row.separated_accounts) if row else True
        if not row and is_separated:
            later = _later_separated_journal(day_text)
            if later:
                return response.json(api.api_error(
                    mess="لا يمكن إنشاء يومية قبل يومية الحسابات المنفصلة بتاريخ %s"
                    % later.register_date
                ))

        payments = _payment_totals_for(day_text)
        submitted_paid = cash.money(data.paid_to_suppliers)
        if lock_after_save and submitted_paid != payments["total"]:
            return response.json(api.api_error(
                mess="تغير إجمالي السدادات أثناء العمل. حدّث القيمة ثم أعد الإقفال"
            ))

        bank_difference_reason = _clean_text(data.bank_difference_reason)
        difference_reason = _clean_text(data.difference_reason)

        if is_separated:
            openings = _account_opening_suggestions(day_text)
            if not openings["initial"]:
                if not openings["previous_locked"]:
                    return response.json(api.api_error(
                        mess="يجب إقفال اليومية السابقة قبل حفظ يومية جديدة"
                    ))
                opening_cash = openings["cash"]
                opening_bank = openings["bank"]
            else:
                opening_cash = cash.money(data.opening_balance, allow_none=True)
                if opening_cash is None:
                    opening_cash = openings["cash"]
                opening_bank = cash.money(data.bank_opening_balance, allow_none=True)
                if opening_cash is None:
                    return response.json(api.api_error(mess="أدخل الرصيد الافتتاحي للكاش"))
                if opening_bank is None:
                    return response.json(api.api_error(mess="أدخل الرصيد الافتتاحي للبنك لأول يوم فصل"))

            totals = cash.calculate_separated_totals(
                opening_cash=opening_cash,
                cash_sales=data.cash_sales,
                bank_withdrawal=data.bank_withdrawal,
                cash_expenses=data.misc_expenses,
                cash_paid_to_parties=payments["cash"],
                cash_deposit_to_bank=data.cash_deposit_to_bank,
                opening_bank=opening_bank,
                bank_deposit=data.bank_deposit,
                bank_paid_to_parties=payments["bank"],
                bank_expenses=data.bank_expenses,
                pos_sales=data.pos_total,
                actual_closing_cash=data.actual_closing_cash,
                actual_closing_bank=data.actual_closing_bank,
            )
            # السداد غير المصنف يبقى ظاهراً في المفتوح، لكنه لا يُحمل على
            # حساب تخميني ويمنع الإقفال حتى تُصحح طريقة السداد.
            totals["unallocated_payments"] = payments["none"]
            totals["paid_to_suppliers"] = payments["total"]
            totals["net_sales"] = (totals["net_sales"] - payments["none"]).quantize(cash.CENT)
            totals["separated_accounts"] = True
        else:
            totals = cash.calculate_totals(
                data.opening_balance,
                data.pos_total,
                data.bank_withdrawal,
                data.misc_expenses,
                payments["total"],
                data.actual_closing_cash,
            )
            totals["separated_accounts"] = False

        family_summary = _family_summary_for(day_text)
        if lock_after_save:
            if not (sc and sc.can_close):
                return response.json(api.api_error(mess="لا تملك صلاحية إقفال اليومية"))
            if totals["actual_closing_cash"] is None:
                return response.json(api.api_error(mess="أدخل الكاش الفعلي آخر الفترة قبل الإقفال"))
            if cash.difference_needs_reason(totals["cash_difference"]) and not difference_reason:
                return response.json(api.api_error(mess="يجب كتابة سبب فرق الصندوق قبل الإقفال"))
            if is_separated:
                if payments["none"] != cash.ZERO:
                    return response.json(api.api_error(
                        mess="توجد سدادات بلا طريقة مرتبطة بالكاش أو البنك. صححها قبل الإقفال"
                    ))
                if totals["actual_closing_bank"] is None:
                    return response.json(api.api_error(mess="أدخل رصيد البنك الفعلي قبل الإقفال"))
                if cash.difference_needs_reason(totals["bank_difference"]) and not bank_difference_reason:
                    return response.json(api.api_error(mess="يجب كتابة سبب فرق البنك قبل الإقفال"))

        vals = {
            key: value for key, value in totals.items()
            if key in db.cash_journal.fields
        }
        vals.update({
            "difference_reason": difference_reason if totals["cash_difference"] is not None else "",
            "bank_difference_reason": (
                bank_difference_reason
                if is_separated and totals["bank_difference"] is not None else ""
            ),
            "pos_difference_reason": "",
            "locked": lock_after_save,
            "note": _clean_text(data.note),
            "family_received": family_summary["received"],
            "family_returned": family_summary["returned"],
            "family_net_sales": family_summary["net_sales"],
            "family_commission_rate": family_summary["commission_rate"],
            "family_commission_amount": family_summary["commission_amount"],
            "family_net_amount": family_summary["net_amount"],
        })
        if lock_after_save:
            vals.update({
                "locked_at": request.now,
                "locked_by": auth.user.id,
                "family_summary_captured_at": request.now,
            })

        if row:
            row.update_record(**vals)
            rec_id = row.id
        else:
            rec_id = db.cash_journal.insert(register_date=day_text, **vals)
        if lock_after_save:
            db(
                db.cash_journal_family_summary.cash_journal == rec_id
            ).delete()
            for item in family_summary["details"]:
                db.cash_journal_family_summary.insert(
                    cash_journal=rec_id,
                    family=item["family_id"],
                    family_name=item["family_name"],
                    sale_percent=item["sale_percent"],
                    received=item["received"],
                    returned=item["returned"],
                    net_sales=item["net_sales"],
                    commission_amount=item["commission_amount"],
                    net_amount=item["net_amount"],
                )
            db.cash_journal_events.insert(
                cash_journal=rec_id,
                event_type="close",
                event_at=request.now,
                performed_by=auth.user.id,
                expected_cash=totals["closing_balance"],
                actual_cash=totals["actual_closing_cash"],
                cash_difference=totals["cash_difference"],
                expected_bank=totals.get("bank_closing_balance"),
                actual_bank=totals.get("actual_closing_bank"),
                bank_difference=totals.get("bank_difference"),
                expected_pos=None,
                actual_pos=None,
                pos_difference=None,
                note=" | ".join(filter(None, (
                    difference_reason,
                    bank_difference_reason,
                ))),
            )
        db.commit()
        saved = db.cash_journal[rec_id]
        names = _user_names([saved.locked_by, saved.reopened_by])
        message = "تم حفظ وإقفال اليومية" if lock_after_save else "تم حفظ اليومية"
        return response.json(api.api_ok(data=_row_to_dict(saved, names), mess=message))
    except ValueError as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(5001)
def reopen_entry():
    """إعادة فتح يومية مقفلة مع توثيق السبب والمستخدم والوقت."""
    try:
        if request.env.request_method != "POST":
            return response.json(api.api_error(mess="طريقة الطلب غير مسموحة"))
        sc = screens_rules(5001)
        if not (sc and sc.can_reopen):
            return response.json(api.api_error(mess="لا تملك صلاحية إعادة فتح اليومية"))
        try:
            rec_id = int(request.vars.id or 0)
        except (TypeError, ValueError):
            return response.json(api.api_error(mess="معرف اليومية غير صحيح"))
        row = db.cash_journal[rec_id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if not row.locked:
            return response.json(api.api_error(mess="اليومية مفتوحة بالفعل"))
        if row.separated_accounts:
            later = _later_separated_journal(str(row.register_date), row.id)
            if later:
                return response.json(api.api_error(
                    mess="أعد فتح اليوميات بالترتيب من الأحدث؛ توجد يومية لاحقة بتاريخ %s"
                    % later.register_date
                ))
        reason = _clean_text(request.vars.reopen_reason)
        if not reason:
            return response.json(api.api_error(mess="يجب كتابة سبب إعادة فتح اليومية"))
        row.update_record(
            locked=False,
            reopened_at=request.now,
            reopened_by=auth.user.id,
            reopen_reason=reason,
        )
        db.cash_journal_events.insert(
            cash_journal=row.id,
            event_type="reopen",
            event_at=request.now,
            performed_by=auth.user.id,
            expected_cash=row.closing_balance,
            actual_cash=row.actual_closing_cash,
            cash_difference=row.cash_difference,
            expected_bank=row.bank_closing_balance if row.separated_accounts else None,
            actual_bank=row.actual_closing_bank if row.separated_accounts else None,
            bank_difference=row.bank_difference if row.separated_accounts else None,
            expected_pos=None,
            actual_pos=None,
            pos_difference=None,
            note=reason,
        )
        db.commit()
        return response.json(api.api_ok(mess="تمت إعادة فتح اليومية"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@can_access(5001)
def get_entry_events():
    """سجل عمليات الإقفال وإعادة الفتح ليومية محددة."""
    try:
        rec_id = int(request.vars.id or 0)
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="معرف اليومية غير صحيح"))
    if not db.cash_journal[rec_id]:
        return response.json(api.api_error(mess="السجل غير موجود"))
    rows = db(db.cash_journal_events.cash_journal == rec_id).select(
        orderby=~db.cash_journal_events.event_at
    )
    names = _user_names([row.performed_by for row in rows])
    data = [{
        "id": row.id,
        "event_type": row.event_type,
        "event_at": str(row.event_at or ""),
        "performed_by_name": names.get(row.performed_by, ""),
        "expected_cash": cash.json_money(row.expected_cash),
        "actual_cash": cash.json_money(row.actual_cash),
        "cash_difference": cash.json_money(row.cash_difference),
        "expected_bank": cash.json_money(row.expected_bank),
        "actual_bank": cash.json_money(row.actual_bank),
        "bank_difference": cash.json_money(row.bank_difference),
        "note": row.note or "",
    } for row in rows]
    return response.json(api.api_ok(data=data))


@can_access(5001)
def delete_entry():
    """حذف يومية صندوق"""
    try:
        if request.env.request_method != "POST":
            return response.json(api.api_error(mess="طريقة الطلب غير مسموحة"))
        sc = screens_rules(5001)
        if not (sc and sc.can_delete):
            return response.json(api.api_error(mess="لا تملك صلاحية الحذف"))
        row = db.cash_journal[int(request.vars.id or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        if row.locked:
            return response.json(api.api_error(mess="لا يمكن حذف يومية مقفلة. افتح القفل أولاً ثم احذفها"))
        if row.separated_accounts:
            later = _later_separated_journal(str(row.register_date), row.id)
            if later:
                return response.json(api.api_error(
                    mess="لا يمكن حذفها قبل حذف اليوميات اللاحقة؛ توجد يومية بتاريخ %s"
                    % later.register_date
                ))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok(mess="تم الحذف"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
