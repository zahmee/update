# -*- coding: utf-8 -*-
#  type: ignore
# ======================================================================================
#  الرسائل النصية — إرسال يدوي + فحص الرصيد (صلاحية مستقلة 9303)
# ======================================================================================
import json as _json
import api_helpers as api
import send_sms


def _credentials_ok():
    return bool(sms_authorization and sms_sender)


@can_access(9303)
def send():
    """شاشة الإرسال اليدوي."""
    q = db(db.sms_settings.id > 0).select().first()
    org = db(db.important_info.id > 0).select(db.important_info.name).first()
    return dict(info={
        "credentials_ok": _credentials_ok(),
        "sender": sms_sender or "",
        "auto_enabled": bool(q.enabled) if q else False,
        "org_name": (org.name if org else "") or "",
    })


@can_access(9303)
def recipients():
    """بحث الأسر والموردين لاختيار المستلم (يعيد من لديه رقم جوال فقط)."""
    term = (request.vars.q or "").strip()
    out = []
    if term:
        fq = db.families.name.contains(term) | db.families.mobile.contains(term)
        for r in db(fq).select(
            db.families.id, db.families.name, db.families.mobile,
            orderby=db.families.name, limitby=(0, 12),
        ):
            if r.mobile:
                out.append({"type": "family", "label": "أسرة",
                            "id": r.id, "name": r.name or "", "mobile": r.mobile})
        sq = db.suppliers.name.contains(term) | db.suppliers.mobile.contains(term)
        for r in db(sq).select(
            db.suppliers.id, db.suppliers.name, db.suppliers.mobile,
            orderby=db.suppliers.name, limitby=(0, 12),
        ):
            if r.mobile:
                out.append({"type": "supplier", "label": "مورد",
                            "id": r.id, "name": r.name or "", "mobile": r.mobile})
    return response.json(api.api_list(rows=out, count=len(out)))


@can_access(9301, 9303)
def balance():
    """فحص اتصال/رصيد المزوّد (قراءة فقط، لا إرسال)."""
    if not _credentials_ok():
        return response.json(api.api_error(mess="بيانات مزوّد الرسائل غير مضبوطة في إعدادات النظام"))
    try:
        raw = send_sms.SMS(sms_authorization, sms_sender).getbalance()
    except Exception as e:
        return response.json(api.api_error(mess="تعذّر الاتصال بالمزوّد: " + str(e)))
    data = {}
    try:
        data = _json.loads(raw)
    except (ValueError, TypeError):
        pass
    if "credits" not in data:
        # استجابة غير متوقعة (مفتاح غير صحيح غالباً)
        return response.json(api.api_error(mess="استجابة غير متوقعة من المزوّد: " + str(raw)[:200]))
    return response.json(api.api_ok(
        data={"credits": data.get("credits"), "expiryDate": data.get("expiryDate")},
        mess="تم الاتصال بالمزوّد بنجاح",
    ))


@can_access(9303)
def send_manual():
    """إرسال رسالة يدوية إلى رقم واحد (مستقل عن مفتاح الإرسال التلقائي)."""
    mobile = (request.vars.mobile or "").strip()
    message = (request.vars.message or "").strip()
    if not message:
        return response.json(api.api_error(mess="نص الرسالة مطلوب"))
    if len(message) > 500:
        return response.json(api.api_error(mess="نص الرسالة طويل جداً (الحد 500 حرف)"))
    target = send_sms.normalize_saudi_mobile(mobile)
    if not target:
        return response.json(api.api_error(mess="رقم الجوال غير صالح — بصيغة 05XXXXXXXX"))
    if not _credentials_ok():
        return response.json(api.api_error(mess="بيانات مزوّد الرسائل غير مضبوطة في إعدادات النظام"))
    res = send_sms.send_message(sms_authorization, sms_sender, target, message)
    if res["ok"]:
        return response.json(api.api_ok(data={"mobile": target}, mess="تم إرسال الرسالة بنجاح"))
    return response.json(api.api_error(mess=res["mess"]))
