# -*- coding: utf-8 -*-
#  type: ignore
# ======================================================================================
#  واتساب — سجل الرسائل والردود وإرسال كشف الرصيد (9304)، وفحص الربط والقوالب (9301)
#  قائمة الإرسال والسجل في models/db_5_whatsapp.py، والاتصال بميتا في modules/whatsapp_cloud.py
#  وببوابة واتساب المركزية في modules/wahub_client.py (إن ضُبط قسم [wahub])
# ======================================================================================
import api_helpers as api

WA_STATUS_GROUPS = {
    "queued": ("pending", "sending", "queued"),
    "failed": ("failed",),
    "done": ("accepted", "sent", "delivered", "read"),
}
WA_EVENT_NAMES = {
    "receipt": "سند استلام",
    "return": "سند مرتجع",
    "payment": "سداد",
    "statement": "كشف رصيد",
    "test": "رسالة تجريبية",
}
WA_KIND_NAMES = {"family": "أسرة", "supplier": "مورد"}
WA_PAGE_SIZE = 25


def _post_only():
    """عمليات الإرسال تُقبل بطلب POST فقط، فلا يكفي فتح رابط خارجي لتنفيذها."""
    if request.env.request_method != "POST":
        raise HTTP(405, "Method Not Allowed")


def _page():
    try:
        return max(int(request.vars.page or 0), 0)
    except (TypeError, ValueError):
        return 0


def _fmt_dt(value):
    return value.strftime("%Y-%m-%d %H:%M") if value else ""


def _config_error():
    missing = wa_missing_config()
    if missing:
        return response.json(api.api_error(mess=whatsapp_cloud.missing_text(missing)))
    return None


def _hub_only_error():
    """في طريقة البوابة تُدار القوالب واشتراك الإشعارات من لوحتها، لا من هذا النظام."""
    if WA_VIA_HUB:
        return response.json(api.api_error(mess="الإرسال يتم عبر بوابة واتساب، وهذا الإجراء من لوحة البوابة"))
    return None


def _send_result(res, message_id):
    if res.get("ok"):
        mess = "سُلّمت الرسالة لبوابة واتساب، وتُرسل خلال ثوانٍ" if WA_VIA_HUB else "تم إرسال الرسالة إلى واتساب"
        return response.json(api.api_ok(data={"id": message_id}, mess=mess))
    row = db.wa_messages[message_id]
    if row and row.status == "pending":
        return response.json(api.api_error(
            data={"id": message_id},
            mess="تعذّر الإرسال الآن، وستبقى الرسالة بانتظار إعادة المحاولة: %s" % (res.get("error_text") or ""),
        ))
    return response.json(api.api_error(
        data={"id": message_id},
        mess="تعذّر إرسال الرسالة: %s" % (res.get("error_text") or ""),
    ))


# ======================================================================================
#  السجل والإرسال اليدوي (9304)
# ======================================================================================
@can_access(9304)
def index():
    cfg = wa_settings_row()
    sc = screens_rules(9301)
    return dict(info={
        "config_ok": not wa_missing_config(),
        "enabled": bool(cfg and cfg.enabled),
        "can_settings": bool(sc and sc.can_log_in),
    })


@can_access(9304)
def messages():
    """الرسائل المرسلة مع تصفية بمجموعة الحالة والبحث، وأعداد كل مجموعة."""
    page = _page()
    term = (request.vars.q or "").strip()
    base = db.wa_messages.id > 0
    if term:
        base &= (
            db.wa_messages.party_name.contains(term)
            | db.wa_messages.mobile.contains(term)
            | db.wa_messages.doc_ref.contains(term)
        )
    query = base
    group = request.vars.group or ""
    if group in WA_STATUS_GROUPS:
        query &= db.wa_messages.status.belongs(WA_STATUS_GROUPS[group])
    count = db(query).count()
    rows = db(query).select(
        orderby=~db.wa_messages.id, limitby=(page * WA_PAGE_SIZE, (page + 1) * WA_PAGE_SIZE)
    )
    counter = db.wa_messages.id.count()
    by_status = {
        r[db.wa_messages.status]: r[counter]
        for r in db(base).select(db.wa_messages.status, counter, groupby=db.wa_messages.status)
    }
    groups = {
        name: sum(by_status.get(s, 0) for s in statuses)
        for name, statuses in WA_STATUS_GROUPS.items()
    }
    groups["all"] = sum(by_status.values())
    data = [{
        "id": r.id,
        "created_on": _fmt_dt(r.created_on),
        "event_name": WA_EVENT_NAMES.get(r.event, r.event or ""),
        "party_name": r.party_name or "",
        "kind_name": WA_KIND_NAMES.get(r.party_kind, ""),
        "mobile": r.mobile or "",
        "doc_ref": r.doc_ref or "",
        "preview": r.preview or "",
        "status": r.status,
        "status_at": _fmt_dt(r.status_at),
        "attempts": r.attempts or 0,
        "next_attempt_at": _fmt_dt(r.next_attempt_at),
        "error_text": r.error_text or "",
    } for r in rows]
    return response.json(api.api_list(rows=data, count=count, groups=groups, page_size=WA_PAGE_SIZE))


@can_access(9304)
def inbound():
    """ردود العملاء الواردة عبر نقطة الاستقبال."""
    page = _page()
    term = (request.vars.q or "").strip()
    query = db.wa_inbound.id > 0
    if term:
        query &= (
            db.wa_inbound.from_mobile.contains(term)
            | db.wa_inbound.from_name.contains(term)
            | db.wa_inbound.party_name.contains(term)
            | db.wa_inbound.body.contains(term)
        )
    count = db(query).count()
    rows = db(query).select(
        orderby=~db.wa_inbound.id, limitby=(page * WA_PAGE_SIZE, (page + 1) * WA_PAGE_SIZE)
    )
    data = [{
        "id": r.id,
        "received_at": _fmt_dt(r.received_at),
        "from_mobile": r.from_mobile or "",
        "from_name": r.from_name or "",
        "party_name": r.party_name or "",
        "kind_name": WA_KIND_NAMES.get(r.party_kind, ""),
        "msg_type": r.msg_type or "",
        "body": r.body or "",
    } for r in rows]
    return response.json(api.api_list(rows=data, count=count, page_size=WA_PAGE_SIZE))


@can_access(9304)
def retry():
    """إعادة إرسال رسالة فاشلة أو بانتظار إعادة المحاولة."""
    _post_only()
    try:
        row = db.wa_messages[int(request.vars.id or 0)]
    except (TypeError, ValueError):
        row = None
    if not row:
        return response.json(api.api_error(mess="الرسالة غير موجودة"))
    if row.status not in ("failed", "pending"):
        return response.json(api.api_error(mess="لا يُعاد إرسال إلا الرسائل الفاشلة أو المنتظرة"))
    error = _config_error()
    if error:
        return error
    wa_requeue(row)
    db.commit()
    return _send_result(wa_dispatch(row.id), row.id)


@can_access(9304)
def send_statement():
    """إرسال كشف الرصيد الصافي لأسرة أو مورد."""
    _post_only()
    kind = (request.vars.kind or "").strip()
    if kind not in WA_KIND_NAMES:
        return response.json(api.api_error(mess="نوع السجل غير صحيح"))
    table = db.families if kind == "family" else db.suppliers
    try:
        party = table[int(request.vars.id or 0)]
    except (TypeError, ValueError):
        party = None
    if not party:
        return response.json(api.api_error(mess="السجل غير موجود"))
    error = _config_error()
    if error:
        return error
    try:
        message_id, mess = wa_queue_statement(kind, party)
        if not message_id:
            return response.json(api.api_error(mess=mess))
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر تجهيز كشف الرصيد: %s" % e))
    return _send_result(wa_dispatch(message_id), message_id)


# ======================================================================================
#  فحص الربط والقوالب ورسالة تجريبية (9301) — تستدعيها شاشة setup/whatsapp_settings
# ======================================================================================
@can_access(9301)
def check():
    """بيانات رقم الإرسال (قراءة فقط): من البوابة في طريقتها، وإلا من ميتا مباشرة."""
    error = _config_error()
    if error:
        return error
    if WA_VIA_HUB:
        res = wahub_client.status(wahub_config)
        if not res["ok"]:
            return response.json(api.api_error(mess=res["error_text"]))
        sender = res["data"].get("sender") or {}
        data = {
            "display_phone_number": sender.get("display_phone") or "",
            "verified_name": sender.get("name") or "",
            "quality_rating": sender.get("quality") or "",
            "platform_type": "WAHUB",
            "client_name": (res["data"].get("client") or {}).get("name") or "",
        }
        return response.json(api.api_ok(data=data, mess="تم الاتصال ببوابة واتساب بنجاح"))
    res = whatsapp_cloud.get_phone_info(wa_config)
    if not res["ok"]:
        return response.json(api.api_error(mess=res["error_text"]))
    return response.json(api.api_ok(data=res["data"], mess="تم الاتصال بواتساب بنجاح"))


@can_access(9301)
def templates():
    """حالة القوالب التي يحتاجها النظام: من البوابة في طريقتها، وإلا من ميتا مباشرة."""
    if not WA_VIA_HUB:
        res = whatsapp_cloud.template_status(wa_config)
        if not res["ok"]:
            return response.json(api.api_error(mess=res["error_text"]))
        return response.json(api.api_ok(data=res["data"]))
    res = wahub_client.templates(wahub_config)
    if not res["ok"]:
        return response.json(api.api_error(mess=res["error_text"]))
    found = {t.get("name"): t for t in res["data"] if t.get("language") == whatsapp_cloud.TEMPLATE_LANG}
    data = [{
        "key": key, "name": tpl["name"], "title": tpl["title"], "body": tpl["body"],
        "category": (found.get(tpl["name"]) or {}).get("category") or tpl["category"],
        "status": (found.get(tpl["name"]) or {}).get("status") or "MISSING",
        "rejected_reason": "",
    } for key, tpl in whatsapp_cloud.TEMPLATES.items()]
    return response.json(api.api_ok(data=data))


@can_access(9301)
def submit_template():
    """تقديم قالب ناقص لميتا للمراجعة."""
    _post_only()
    error = _hub_only_error()
    if error:
        return error
    res = whatsapp_cloud.create_template(wa_config, request.vars.key or "")
    if not res["ok"]:
        return response.json(api.api_error(mess=res["error_text"]))
    return response.json(api.api_ok(data=res["data"], mess="تم تقديم القالب لميتا للمراجعة"))


@can_access(9301)
def subscription():
    """هل التطبيق مشترك في إشعارات حساب واتساب للأعمال؟"""
    error = _hub_only_error()
    if error:
        return error
    res = whatsapp_cloud.app_subscription(wa_config)
    if not res["ok"]:
        return response.json(api.api_error(mess=res["error_text"]))
    return response.json(api.api_ok(data=res["data"]))


@can_access(9301)
def subscribe():
    """اشتراك التطبيق في إشعارات الحساب، بدونه لا تصل حالات الرسائل ولا الردود."""
    _post_only()
    error = _hub_only_error()
    if error:
        return error
    res = whatsapp_cloud.subscribe_app(wa_config)
    if not res["ok"]:
        return response.json(api.api_error(mess=res["error_text"]))
    return response.json(api.api_ok(mess="تم اشتراك التطبيق في إشعارات حساب واتساب للأعمال"))


@can_access(9301)
def send_test():
    """رسالة تجريبية بقالب الإشعار وقيمه النموذجية إلى رقم يُدخله المستخدم."""
    _post_only()
    error = _config_error()
    if error:
        return error
    try:
        message_id, mess = wa_queue_test(request.vars.mobile or "")
        if not message_id:
            return response.json(api.api_error(mess=mess))
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر تجهيز الرسالة التجريبية: %s" % e))
    return _send_result(wa_dispatch(message_id), message_id)
