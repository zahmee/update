# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  الأسر - الشاشات
# ======================================================================================


@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    # زر إرسال كشف الرصيد عبر واتساب لمن لديه شاشة واتساب
    sc_wa = screens_rules(9304)
    can_whatsapp = bool(sc_wa and sc_wa.can_log_in)
    return dict(can_add=can_add, can_edit=can_edit, can_delete=can_delete, can_whatsapp=can_whatsapp)


@can_access(1002)
def pay():
    """سجل تسديدات أسرة معينة"""
    sc = screens_rules(1002)
    try:
        family_id = int(request.args(0))
    except (ValueError, TypeError):
        redirect(URL("families", "index"))
    family = db.families[family_id]
    if not family:
        redirect(URL("families", "index"))
    return dict(
        family=family,
        family_id=family_id,
        can_add=sc.can_add,
        can_edit=sc.can_edit,
        can_delete=sc.can_delete,
        can_cancel=can_cancel_locked_payment(1002),
    )


@can_access(1003)
def settlement():
    """تصفية مستحقات أسرة"""
    return dict()


# شاشة «كل سدادات الأسر» (pay_all) حُذفت — استُبدلت بالشاشة الموحّدة suppliers/payment
# (تسديد الموردين والأسر مع حساب المستحق).
