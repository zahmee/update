# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  الأسر - الشاشات
# ======================================================================================


@can_access(1001)
def index():
    sc = screens_rules(1001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict(can_add=can_add, can_edit=can_edit, can_delete=can_delete)


@can_access(1002)
def pay():
    """سجل تسديدات أسرة معينة"""
    sc = screens_rules(1002)
    try:
        family_id = int(request.args(0))
    except (ValueError, TypeError):
        redirect(URL("families", "index"))
    family = db.families[family_id]
    if not family:
        redirect(URL("families", "index"))
    return dict(
        family=family,
        family_id=family_id,
        can_add=sc.can_add,
        can_edit=sc.can_edit,
        can_delete=sc.can_delete,
    )


@can_access(1003)
def settlement():
    """تصفية مستحقات أسرة"""
    return dict()


# شاشة «كل سدادات الأسر» (pay_all) حُذفت — استُبدلت بالشاشة الموحّدة suppliers/payment
# (تسديد الموردين والأسر مع حساب المستحق).
