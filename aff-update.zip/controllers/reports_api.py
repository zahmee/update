# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  التقارير - APIs
#  ملخص يومي - الصندوق الشهري - ملخص السدادات - أرصدة الموردين والأسر
# ======================================================================================
import api_helpers as api
import cashbox_domain as cash
import datetime


def _clean_text(value):
    return (value or "").strip()


def _default_range():
    """النطاق الافتراضي: الشهر الحالي"""
    today = request.now.date()
    return today.replace(day=1).isoformat(), today.isoformat()


def _daily_maps(start_date, end_date):
    """مجاميع يومية: مستلم - مرتجع - مسدد (موردين + أسر)"""
    recv_q = db.goods_received.id > 0
    if start_date:
        recv_q &= db.goods_received.receipt_date >= start_date
    if end_date:
        recv_q &= db.goods_received.receipt_date <= end_date
    recv_rows = db(recv_q).select(
        db.goods_received.receipt_date,
        db.goods_received.bill_total.sum(),
        groupby=db.goods_received.receipt_date,
    )
    recv_map = {
        str(r[db.goods_received.receipt_date]): (r[db.goods_received.bill_total.sum()] or 0)
        for r in recv_rows
    }

    ret_q = db.goods_return.id > 0
    if start_date:
        ret_q &= db.goods_return.return_date >= start_date
    if end_date:
        ret_q &= db.goods_return.return_date <= end_date
    ret_rows = db(ret_q).select(
        db.goods_return.return_date,
        db.goods_return.total.sum(),
        groupby=db.goods_return.return_date,
    )
    ret_map = {
        str(r[db.goods_return.return_date]): (r[db.goods_return.total.sum()] or 0)
        for r in ret_rows
    }

    spay_q = db.supplier_payments.id > 0
    if start_date:
        spay_q &= db.supplier_payments.pay_date >= start_date
    if end_date:
        spay_q &= db.supplier_payments.pay_date <= end_date
    spay_rows = db(spay_q).select(
        db.supplier_payments.pay_date,
        db.supplier_payments.pay_total.sum(),
        groupby=db.supplier_payments.pay_date,
    )
    paid_map = {
        str(r[db.supplier_payments.pay_date]): (r[db.supplier_payments.pay_total.sum()] or 0)
        for r in spay_rows
    }

    fpay_q = db.family_payments.id > 0
    if start_date:
        fpay_q &= db.family_payments.pay_date >= start_date
    if end_date:
        fpay_q &= db.family_payments.pay_date <= end_date
    fpay_rows = db(fpay_q).select(
        db.family_payments.pay_date,
        db.family_payments.amount.sum(),
        groupby=db.family_payments.pay_date,
    )
    for r in fpay_rows:
        day = str(r[db.family_payments.pay_date])
        paid_map[day] = paid_map.get(day, 0) + (r[db.family_payments.amount.sum()] or 0)

    return recv_map, ret_map, paid_map


@can_access(6001)
def daily_summary():
    """الملخص اليومي: مستلم / مرتجع / مسدد / صافي لكل يوم في نطاق تاريخ"""
    start_date = _clean_text(request.vars.start_date)
    end_date = _clean_text(request.vars.end_date)
    if not start_date and not end_date:
        start_date, end_date = _default_range()

    recv_map, ret_map, paid_map = _daily_maps(start_date, end_date)
    days = sorted(set(recv_map) | set(ret_map) | set(paid_map))
    data = []
    for day in days:
        recv = round(recv_map.get(day, 0), 2)
        ret = round(ret_map.get(day, 0), 2)
        paid = round(paid_map.get(day, 0), 2)
        data.append({
            "day": day,
            "received": recv,
            "returned": ret,
            "paid": paid,
            "net": round(recv - ret, 2),
        })
    totals = {
        "received": round(sum(d["received"] for d in data), 2),
        "returned": round(sum(d["returned"] for d in data), 2),
        "paid": round(sum(d["paid"] for d in data), 2),
        "net": round(sum(d["net"] for d in data), 2),
    }
    return response.json(api.api_ok(data={"rows": data, "totals": totals}))


@can_access(6001)
def cash_monthly():
    """الصندوق الشهري: يوميات الصندوق لشهر وسنة محددين"""
    try:
        year = int(request.vars.year or 0)
        month = int(request.vars.month or 0)
        if not (1 <= month <= 12) or year < 2000:
            raise ValueError
    except (TypeError, ValueError):
        year = request.now.year
        month = request.now.month

    start = datetime.date(year, month, 1)
    if month == 12:
        end = datetime.date(year, 12, 31)
    else:
        end = datetime.date(year, month + 1, 1) - datetime.timedelta(days=1)

    rows = db(
        (db.cash_journal.register_date >= start.isoformat())
        & (db.cash_journal.register_date <= end.isoformat())
    ).select(orderby=db.cash_journal.register_date)

    data = []
    for r in rows:
        data.append({
            "register_date": str(r.register_date or ""),
            "opening_balance": cash.json_money(r.opening_balance or 0),
            "pos_total": cash.json_money(r.pos_total or 0),
            "bank_withdrawal": cash.json_money(r.bank_withdrawal or 0),
            "misc_expenses": cash.json_money(r.misc_expenses or 0),
            "paid_to_suppliers": cash.json_money(r.paid_to_suppliers or 0),
            "total_in": cash.json_money(r.total_in or 0),
            "total_out": cash.json_money(r.total_out or 0),
            "closing_balance": cash.json_money(r.closing_balance or 0),
            "net_sales": cash.json_money(r.net_sales or 0),
            "actual_closing_cash": cash.json_money(r.actual_closing_cash),
            "cash_difference": cash.json_money(r.cash_difference),
            "locked": bool(r.locked),
        })
    totals = {
        "pos_total": round(sum(d["pos_total"] for d in data), 2),
        "bank_withdrawal": round(sum(d["bank_withdrawal"] for d in data), 2),
        "misc_expenses": round(sum(d["misc_expenses"] for d in data), 2),
        "paid_to_suppliers": round(sum(d["paid_to_suppliers"] for d in data), 2),
        "net_sales": round(sum(d["net_sales"] for d in data), 2),
        "closing_balance": data[-1]["closing_balance"] if data else 0,
        "actual_closing_cash": data[-1]["actual_closing_cash"] if data else None,
        "cash_difference": round(sum((d["cash_difference"] or 0) for d in data), 2),
    }
    return response.json(api.api_ok(data={"rows": data, "totals": totals, "year": year, "month": month}))


@can_access(6001)
def payments_summary():
    """ملخص السدادات: عدد ومجموع السدادات لكل جهة في نطاق تاريخ (تنازلي)"""
    start_date = _clean_text(request.vars.start_date)
    end_date = _clean_text(request.vars.end_date)
    if not start_date and not end_date:
        start_date, end_date = _default_range()

    data = []

    sup_q = db.supplier_payments.id > 0
    if start_date:
        sup_q &= db.supplier_payments.pay_date >= start_date
    if end_date:
        sup_q &= db.supplier_payments.pay_date <= end_date
    sup_rows = db(sup_q).select(
        db.supplier_payments.supplier,
        db.supplier_payments.pay_total.sum(),
        db.supplier_payments.id.count(),
        groupby=db.supplier_payments.supplier,
    )
    sup_names = {r.id: r.name for r in db(db.suppliers.id > 0).select()}
    for r in sup_rows:
        data.append({
            "kind": "supplier",
            "kind_name": "مورد",
            "name": sup_names.get(r[db.supplier_payments.supplier], "-"),
            "payments_count": r[db.supplier_payments.id.count()] or 0,
            "total_paid": round(r[db.supplier_payments.pay_total.sum()] or 0, 2),
        })

    fam_q = db.family_payments.id > 0
    if start_date:
        fam_q &= db.family_payments.pay_date >= start_date
    if end_date:
        fam_q &= db.family_payments.pay_date <= end_date
    fam_rows = db(fam_q).select(
        db.family_payments.family,
        db.family_payments.amount.sum(),
        db.family_payments.id.count(),
        groupby=db.family_payments.family,
    )
    fam_names = {r.id: r.name for r in db(db.families.id > 0).select()}
    for r in fam_rows:
        data.append({
            "kind": "family",
            "kind_name": "أسرة",
            "name": fam_names.get(r[db.family_payments.family], "-"),
            "payments_count": r[db.family_payments.id.count()] or 0,
            "total_paid": round(r[db.family_payments.amount.sum()] or 0, 2),
        })

    data.sort(key=lambda x: x["total_paid"], reverse=True)
    totals = {
        "payments_count": sum(d["payments_count"] for d in data),
        "total_paid": round(sum(d["total_paid"] for d in data), 2),
    }
    return response.json(api.api_ok(data={"rows": data, "totals": totals}))


@can_access(6001)
def balances():
    """أرصدة الموردين والأسر بالصيغة الموحّدة: صافي البضاعة − العمولة + سابق له − سابق عليه − المدفوع"""
    kind_filter = _clean_text(request.vars.kind)

    def _rows_for(kind, kind_name):
        due_maps = party_due_maps(kind)
        table = db.suppliers if kind == "supplier" else db.families
        out = []
        for r in db(table.id > 0).select(orderby=table.name):
            due = due_maps.get(r.id)
            if not due:
                continue
            out.append({
                "kind": kind,
                "kind_name": kind_name,
                "name": r.name,
                "stoped": bool(r.stoped),
                "prev_for": due["prev_for"],
                "prev_on": due["prev_on"],
                "received": due["received"],
                "returned": due["returned"],
                "commission": due["commission"],
                "paid": due["paid"],
                "balance": due["net_due"],
                "side": due["side"],
            })
        return out

    data = []
    if kind_filter in ("", "all", "supplier"):
        data += _rows_for("supplier", "مورد")
    if kind_filter in ("", "all", "family"):
        data += _rows_for("family", "أسرة")

    data.sort(key=lambda x: (x["kind"], -abs(x["balance"])))
    totals = {
        "received": round(sum(d["received"] for d in data), 2),
        "returned": round(sum(d["returned"] for d in data), 2),
        "commission": round(sum(d["commission"] for d in data), 2),
        "paid": round(sum(d["paid"] for d in data), 2),
        "balance": round(sum(d["balance"] for d in data), 2),
    }
    return response.json(api.api_ok(data={"rows": data, "totals": totals}))
