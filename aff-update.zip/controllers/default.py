# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime
import cashbox_domain as cash
"""
صلاحيات الشاشات تُدار عبر @can_access(screen_code) كما في المشروع المرجعي
"""


# ---- الصفحة الرئيسية ----
def _dashboard_sum(query, field):
    row = db(query).select(field.sum()).first()
    return cash.money(row[field.sum()] or 0) if row else cash.ZERO


def _today_family_activity(day):
    """حركة الأسر اليومية مجمعة لكل أسرة، مع تطبيق نسبة كل أسرة على حدة."""
    receipt_count = db.goods_received.id.count()
    return_count = db.goods_return.id.count()
    receipt_rows = db(
        (db.goods_received.receipt_date == day)
        & (db.goods_received.family != None)
    ).select(
        db.goods_received.family,
        db.goods_received.bill_total.sum(),
        receipt_count,
        groupby=db.goods_received.family,
    )
    return_rows = db(
        (db.goods_return.return_date == day)
        & (db.goods_return.family != None)
    ).select(
        db.goods_return.family,
        db.goods_return.total.sum(),
        return_count,
        groupby=db.goods_return.family,
    )
    received = {
        row[db.goods_received.family]: row[db.goods_received.bill_total.sum()] or 0
        for row in receipt_rows
    }
    returned = {
        row[db.goods_return.family]: row[db.goods_return.total.sum()] or 0
        for row in return_rows
    }
    receipt_counts = {
        row[db.goods_received.family]: row[receipt_count] or 0
        for row in receipt_rows
    }
    return_counts = {
        row[db.goods_return.family]: row[return_count] or 0
        for row in return_rows
    }
    family_ids = set(received) | set(returned)
    if not family_ids:
        summary = cash.calculate_family_summary([])
        return summary, [], 0

    family_rows = db(db.families.id.belongs(list(family_ids))).select(
        db.families.id, db.families.name, db.families.sale_percent
    )
    family_map = {row.id: row for row in family_rows}
    inputs = []
    for family_id in family_ids:
        family = family_map.get(family_id)
        inputs.append({
            "family_id": family_id,
            "family_name": family.name if family else "أسرة رقم %s" % family_id,
            "sale_percent": family.sale_percent if family else 0,
            "received": received.get(family_id, 0),
            "returned": returned.get(family_id, 0),
        })
    summary = cash.calculate_family_summary(inputs)
    rows = []
    for item in summary["details"]:
        family_id = item["family_id"]
        rows.append({
            "family_id": family_id,
            "family_name": item["family_name"],
            "receipt_count": int(receipt_counts.get(family_id, 0)),
            "return_count": int(return_counts.get(family_id, 0)),
            "sale_percent": float(item["sale_percent"]),
            "received": cash.json_money(item["received"]),
            "returned": cash.json_money(item["returned"]),
            "net_sales": cash.json_money(item["net_sales"]),
            "commission_amount": cash.json_money(item["commission_amount"]),
            "net_amount": cash.json_money(item["net_amount"]),
        })
    rows.sort(key=lambda item: (-item["received"], item["family_name"] or ""))
    return summary, rows, len(received)


@auth.requires_login()
def index():
    stats = {}
    stats["families"] = db(db.families.id > 0).count()
    stats["suppliers"] = db(db.suppliers.stoped != True).count()
    stats["total_receipts"] = db(db.goods_received.id > 0).count()
    stats["total_returns"] = db(db.goods_return.id > 0).count()

    # إجمالي المستحقات بالصيغة الموحّدة = مجموع المستحق لكل طرف
    # (صافي البضاعة − العمولة + سابق له − سابق عليه − المدفوع) — models/db_3_balances.py
    sup_due = party_due_maps("supplier")
    fam_due = party_due_maps("family")
    stats["suppliers_balance"] = round(sum(d["net_due"] for d in sup_due.values()), 2)
    stats["families_balance"] = round(sum(d["net_due"] for d in fam_due.values()), 2)

    today = request.now.strftime("%Y-%m-%d")
    family_summary, today_families, received_families_count = _today_family_activity(today)
    family_today = {
        "received_families_count": received_families_count,
        "received": cash.json_money(family_summary["received"]),
        "returned": cash.json_money(family_summary["returned"]),
        "net_sales": cash.json_money(family_summary["net_sales"]),
        "commission_rate": float(family_summary["commission_rate"]),
        "commission_amount": cash.json_money(family_summary["commission_amount"]),
        "net_amount": cash.json_money(family_summary["net_amount"]),
    }

    supplier_paid = _dashboard_sum(
        db.supplier_payments.pay_date == today, db.supplier_payments.pay_total
    )
    family_paid = _dashboard_sum(
        db.family_payments.pay_date == today, db.family_payments.amount
    )
    cash_row = db(db.cash_journal.register_date == today).select(
        limitby=(0, 1)
    ).first()
    operations_today = {
        "receipt_count": db(db.goods_received.receipt_date == today).count(),
        "return_count": db(db.goods_return.return_date == today).count(),
        "payment_count": (
            db(db.supplier_payments.pay_date == today).count()
            + db(db.family_payments.pay_date == today).count()
        ),
        "payment_total": cash.json_money(supplier_paid + family_paid),
        "cash_status": (
            "closed" if cash_row and cash_row.locked
            else "open" if cash_row
            else "not_started"
        ),
        "cash_expected": cash.json_money(cash_row.closing_balance) if cash_row else None,
        "cash_actual": cash.json_money(cash_row.actual_closing_cash) if cash_row else None,
        "cash_difference": cash.json_money(cash_row.cash_difference) if cash_row else None,
    }

    return dict(
        stats=stats,
        family_today=family_today,
        today_families=today_families,
        operations_today=operations_today,
    )


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


# ---- action to server uploaded static content (required) ---
@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def not_allow():
    return dict()


@auth.requires_login()
def about():
    from gluon.contrib.appconfig import AppConfig
    configuration = AppConfig(reload=True)
    exp = configuration.get("app.exp_date")
    date_def = None
    if exp:
        d1 = datetime.strptime(datetime.now().strftime("%Y-%m-%d"), "%Y-%m-%d")
        d2 = datetime.strptime(exp, "%Y-%m-%d")
        date_def = (d2 - d1).days

    info = db(db.important_info.id > 0).select().first()

    raw_mobile = info.mobile if info and info.mobile else ""
    if raw_mobile.startswith("0"):
        wa_num = "966" + raw_mobile[1:]
    else:
        wa_num = raw_mobile

    return dict(
        exp=exp,
        date_def=date_def,
        info=info,
        wa_num=wa_num,
    )
