# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  مرتجع البضاعة - APIs
#  نمط العمل: سند مرتجع رئيسي + اصناف تفصيلية، يؤثر على الارصدة فور حفظه (لا يوجد اعتماد)
# ======================================================================================
import api_helpers as api
import datetime


def _parse_time(value):
    """تحويل نص الوقت HH:MM او HH:MM:SS الى كائن time"""
    value = (value or "").strip()
    if not value:
        return None
    try:
        parts = value.split(":")
        return datetime.time(int(parts[0]), int(parts[1]), int(parts[2]) if len(parts) > 2 else 0)
    except (ValueError, IndexError):
        return None


def _clean_text(value):
    return (value or "").strip()


def _parse_items(vars_):
    """قراءة الاصناف المرسلة كقوائم متوازية quantity[], price[] (و item_name[] اختياري)"""
    def _list(key):
        v = vars_.get(key)
        if v is None:
            return []
        if isinstance(v, list):
            return v
        return [v]

    names = _list("item_name")
    qtys = _list("quantity")
    prices = _list("price")
    units = _list("unit")
    types = _list("item_type")

    items = []
    for i in range(max(len(names), len(qtys), len(prices))):
        name = _clean_text(names[i]) if i < len(names) else ""
        try:
            qty = float(qtys[i]) if i < len(qtys) and qtys[i] not in (None, "") else 1
        except (TypeError, ValueError):
            qty = 1
        try:
            price = float(prices[i]) if i < len(prices) and prices[i] not in (None, "") else 0
        except (TypeError, ValueError):
            price = 0
        if qty <= 0:
            qty = 1
        if price < 0:
            price = 0
        try:
            unit = int(units[i]) if i < len(units) and units[i] not in (None, "") else None
        except (TypeError, ValueError):
            unit = None
        try:
            itype = int(types[i]) if i < len(types) and types[i] not in (None, "") else None
        except (TypeError, ValueError):
            itype = None
        if not name:
            name = "صنف %d" % (len(items) + 1)
        items.append({
            "item_name": name,
            "item_type": itype,
            "unit": unit,
            "quantity": qty,
            "price": price,
            "total": round(qty * price, 2),
        })
    return items


def _next_no():
    row = db(db.goods_return.id > 0).select(db.goods_return.id.max()).first()
    return (row[db.goods_return.id.max()] or 0) + 1


@can_access(4001)
def get_refs():
    """بيانات القوائم المنسدلة للشاشة"""
    suppliers = [{"id": r.id, "name": r.name} for r in db(db.suppliers.stoped != True).select(orderby=db.suppliers.name)]
    families = [{"id": r.id, "name": r.name} for r in db(db.families.stoped != True).select(orderby=db.families.name)]
    return response.json(api.api_ok(data={
        "suppliers": suppliers, "families": families,
        "next_no": _next_no(),
    }))


@can_access(4001)
def get_returns():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)

    query = db.goods_return.id > 0
    entity = ReqVar.entity or "all"
    if entity == "supplier":
        query &= db.goods_return.supplier != None
    elif entity == "family":
        query &= db.goods_return.family != None
    # فلتر مورد محدد (بحث في المورد)
    supplier_id = int(ReqVar.supplier or 0)
    if supplier_id:
        query &= db.goods_return.supplier == supplier_id
    # فلتر التاريخ: من / الى
    date_from = _clean_text(ReqVar.date_from)
    date_to = _clean_text(ReqVar.date_to)
    if date_from:
        query &= db.goods_return.return_date >= date_from
    if date_to:
        query &= db.goods_return.return_date <= date_to

    if ReqVar.SearchText and ReqVar.SearchText.strip():
        for word in ReqVar.SearchText.strip().split():
            query &= db.goods_return.return_no.contains(word) | db.goods_return.note.contains(word)

    count = db(query).count()
    offset = pg * rc
    rows = db(query).select(orderby=~db.goods_return.id, limitby=(offset, offset + rc))

    sup_names = {r.id: r.name for r in db(db.suppliers.id > 0).select()}
    fam_names = {r.id: r.name for r in db(db.families.id > 0).select()}
    cnt_rows = db(db.goods_return_items.id > 0).select(
        db.goods_return_items.goods_return,
        db.goods_return_items.id.count(),
        groupby=db.goods_return_items.goods_return,
    )
    cnt_map = {
        r[db.goods_return_items.goods_return]: r[db.goods_return_items.id.count()]
        for r in cnt_rows
    }

    data = []
    for r in rows:
        data.append({
            "id": r.id,
            "return_no": r.return_no or "",
            "return_date": str(r.return_date or ""),
            "return_time": str(r.return_time or "")[:5],
            "supplier": r.supplier or 0,
            "supplier_name": sup_names.get(r.supplier, ""),
            "family": r.family or 0,
            "family_name": fam_names.get(r.family, ""),
            "items_count": cnt_map.get(r.id, 0),
            "total": r.total or 0,
            "note": r.note or "",
        })
    return response.json(api.api_list(rows=data, count=count))


@can_access(4001)
def get_return():
    """تفاصيل سند مرتجع مع اصنافه"""
    try:
        rec_id = int(request.args(0))
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="السند غير موجود"))
    rec = db.goods_return[rec_id]
    if not rec:
        return response.json(api.api_error(mess="السند غير موجود"))
    items = db(db.goods_return_items.goods_return == rec_id).select(
        orderby=db.goods_return_items.id
    )
    unit_names = {r.id: r.name for r in db(db.key_unit.id > 0).select()}
    type_names = {r.id: r.name for r in db(db.key_type.id > 0).select()}
    sup = db.suppliers[rec.supplier] if rec.supplier else None
    fam = db.families[rec.family] if rec.family else None
    return response.json(api.api_ok(data={
        "master": {
            "id": rec.id,
            "return_no": rec.return_no or "",
            "return_date": str(rec.return_date or ""),
            "return_time": str(rec.return_time or "")[:5],
            "supplier": rec.supplier or 0,
            "supplier_name": sup.name if sup else "",
            "family": rec.family or 0,
            "family_name": fam.name if fam else "",
            "total": rec.total or 0,
            "note": rec.note or "",
        },
        "items": [{
            "id": it.id,
            "item_name": it.item_name,
            "item_type": it.item_type or 0,
            "item_type_name": type_names.get(it.item_type, ""),
            "unit": it.unit or 0,
            "unit_name": unit_names.get(it.unit, ""),
            "quantity": it.quantity,
            "price": it.price,
            "total": it.total,
        } for it in items],
    }))


@can_access(4001)
def save_return():
    """حفظ سند مرتجع جديد او تعديل سند (رئيسي + اصناف) — يحتسب فوراً في الارصدة"""
    try:
        data = request.vars
        rec_id = int(data.id or 0)
        is_new = rec_id == 0
        supplier_id = int(data.supplier or 0) or None
        family_id = int(data.family or 0) or None
        if supplier_id and family_id:
            return response.json(api.api_error(mess="اختر جهة واحدة فقط: مورد أو أسرة"))
        if not supplier_id and not family_id:
            return response.json(api.api_error(mess="يجب اختيار المورد او الأسرة"))
        if supplier_id and not db.suppliers[supplier_id]:
            return response.json(api.api_error(mess="المورد غير موجود"))
        if family_id and not db.families[family_id]:
            return response.json(api.api_error(mess="الأسرة غير موجودة"))

        items = _parse_items(data)
        if not items:
            return response.json(api.api_error(mess="يجب ادخال صنف واحد على الاقل"))

        return_date = _clean_text(data.return_date) or request.now.strftime("%Y-%m-%d")
        lock_msg = locked_day_message(return_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        total = round(sum(it["total"] for it in items), 2)
        master_vals = {
            "return_date": return_date,
            "return_time": _parse_time(data.return_time),
            "supplier": supplier_id,
            "family": family_id,
            "note": data.note,
            "total": total,
        }

        if rec_id:
            rec = db.goods_return[rec_id]
            if not rec:
                return response.json(api.api_error(mess="السند غير موجود"))
            lock_msg = locked_day_message(rec.return_date)
            if lock_msg:
                return response.json(api.api_error(mess=lock_msg))
            rec.update_record(**master_vals)
            db(db.goods_return_items.goods_return == rec_id).delete()
            for it in items:
                db.goods_return_items.insert(goods_return=rec_id, **it)
        else:
            return_no = _clean_text(data.return_no) or str(_next_no())
            rec_id = db.goods_return.insert(return_no=return_no, **master_vals)
            for it in items:
                db.goods_return_items.insert(goods_return=rec_id, **it)
        db.commit()
        # إشعار نصي تلقائي عند إنشاء سند مرتجع جديد (معزول — لا يُسقط الحفظ)
        if is_new:
            party = db.families[family_id] if family_id else db.suppliers[supplier_id]
            if party:
                sms_notify("return", party.mobile, name=party.name,
                           amount=total, doc=return_no, date=return_date)
        return response.json(api.api_ok(data={"id": rec_id}, mess="تم الحفظ بنجاح"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(4001)
def delete_return():
    """حذف سند مرتجع مع اصنافه"""
    try:
        sc = screens_rules(4001)
        if not (sc and sc.can_delete):
            return response.json(api.api_error(mess="لا تملك صلاحية الحذف"))
        rec = db.goods_return[int(request.vars.id or 0)]
        if not rec:
            return response.json(api.api_error(mess="السند غير موجود"))
        lock_msg = locked_day_message(rec.return_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        db(db.goods_return_items.goods_return == rec.id).delete()
        rec.delete_record()
        db.commit()
        return response.json(api.api_ok(mess="تم الحذف"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
