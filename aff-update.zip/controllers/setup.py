# -*- coding: utf-8 -*-
#  type: ignore
from datetime import datetime, timedelta
import re
import api_helpers as api
import aff_seed


def _setup_json_error(message):
    return response.json({"err": 3, "mess": message})


def _valid_email(value):
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", (value or "").strip()))


def _validate_user_payload(data, user_id=None):
    errors = []
    first_name = (data.first_name or "").strip()
    last_name = (data.last_name or "").strip()
    email = (data.email or "").strip().lower()
    password = (data.password or "").strip()
    if not first_name:
        errors.append("الاسم الأول مطلوب")
    if not email or not _valid_email(email):
        errors.append("البريد الإلكتروني غير صحيح")
    if not user_id and len(password) < 4:
        errors.append("كلمة المرور مطلوبة ولا تقل عن 4 أحرف")

    existing = db(db.auth_user.email == email).select(db.auth_user.id, limitby=(0, 1)).first() if email else None
    if existing and (not user_id or int(existing.id) != int(user_id)):
        errors.append("البريد الإلكتروني مستخدم مسبقاً")

    return errors, {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "password": password,
    }


def _valid_auth_user_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.auth_user(row_id) else None


def _valid_group_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.auth_group(row_id) else None


def _valid_screen_id(value):
    try:
        row_id = int(value)
    except (TypeError, ValueError):
        return None
    return row_id if db.screens(row_id) else None


@can_access(9301)
def index():
    return dict()


# ===========================================================================================
#  شاشات الترميزات (CRUD) — واجهة Vue موحّدة عبر قائمة بيضاء بالجداول المسموح بها
# ===========================================================================================
_LOOKUP_TABLES = {
    "unit":         {"table": "key_unit",           "title": "الوحدات",          "subtitle": "وحدات قياس البضائع",     "field_label": "الوصف",        "deletable": True},
    "invoice_type": {"table": "key_invoce_type",    "title": "أنواع السندات",    "subtitle": "تصنيف سندات الاستلام",   "field_label": "الوصف",        "deletable": True},
    "type":         {"table": "key_type",           "title": "تصنيف البضائع",    "subtitle": "تصنيفات البضائع",        "field_label": "الوصف",        "deletable": True},
    "payment":      {"table": "key_payment_method", "title": "طريقة الدفع",      "subtitle": "طرق دفع السندات والسداد", "field_label": "الوصف",        "deletable": True},
    "payment_type": {"table": "key_payment_type",   "title": "أنواع السداد",     "subtitle": "أنواع سداد الأسر والموردين", "field_label": "الوصف",     "deletable": True},
    "family_type":  {"table": "key_family_type",    "title": "فئات الأسر",       "subtitle": "تصنيف الأسر المسجلة",    "field_label": "الوصف",        "deletable": True},
}


def _lookup_page(key):
    cfg = _LOOKUP_TABLES.get(key)
    if not cfg:
        raise HTTP(404)
    response.view = "setup/lookup_crud.html"
    return dict(lookup_key=key, cfg=cfg)


@can_access(9301)
def unit_key():
    return _lookup_page("unit")


@can_access(9301)
def key_invoce_type():
    return _lookup_page("invoice_type")


@can_access(9301)
def type_key():
    return _lookup_page("type")


@can_access(9301)
def payment_method_key():
    return _lookup_page("payment")


@can_access(9301)
def payment_type_key():
    return _lookup_page("payment_type")


@can_access(9301)
def family_type_key():
    return _lookup_page("family_type")


@can_access(9301)
def lookup_list():
    cfg = _LOOKUP_TABLES.get(request.vars.key)
    if not cfg:
        return response.json(api.api_error(mess="جدول غير معروف"))
    table = db[cfg["table"]]
    extra = cfg.get("extra")
    query = table.id > 0
    search = (request.vars.q or "").strip()
    if search:
        query &= table.name.contains(search)
    select_fields = [table.id, table.name]
    if extra:
        select_fields.append(table[extra["field"]])
    rows = db(query).select(*select_fields, orderby=table.name)
    data = []
    for r in rows:
        item = {"id": r.id, "name": r.name or ""}
        if extra:
            item["extra"] = r[extra["field"]] or ""
        data.append(item)
    return response.json(api.api_list(rows=data, count=len(data)))


@can_access(9301)
def lookup_save():
    cfg = _LOOKUP_TABLES.get(request.vars.key)
    if not cfg:
        return response.json(api.api_error(mess="جدول غير معروف"))
    table = db[cfg["table"]]
    name = (request.vars.name or "").strip()
    if not name:
        return response.json(api.api_error(mess="يجب إدخال " + cfg["field_label"]))
    values = {"name": name}
    extra = cfg.get("extra")
    if extra:
        ev = (request.vars.extra or "").strip()
        if ev not in extra["options"]:
            ev = extra.get("default") or extra["options"][0]
        values[extra["field"]] = ev
    try:
        rec_id = request.vars.id
        if rec_id and str(rec_id).isdigit() and table(int(rec_id)):
            table(int(rec_id)).update_record(**values)
        else:
            rec_id = table.insert(**values)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(data={"id": rec_id}, mess="تم الحفظ بنجاح"))


@can_access(9301)
def lookup_delete():
    cfg = _LOOKUP_TABLES.get(request.vars.key)
    if not cfg:
        return response.json(api.api_error(mess="جدول غير معروف"))
    if not cfg["deletable"]:
        return response.json(api.api_error(mess="لا يمكن حذف هذا النوع من السجلات"))
    table = db[cfg["table"]]
    rec_id = request.vars.id
    if not (rec_id and str(rec_id).isdigit() and table(int(rec_id))):
        return response.json(api.api_error(mess="السجل غير موجود"))
    try:
        db(table.id == int(rec_id)).delete()
        db.commit()
    except Exception:
        db.rollback()
        return response.json(api.api_error(mess="تعذّر الحذف، قد يكون السجل مستخدماً في النظام"))
    return response.json(api.api_ok(mess="تم الحذف بنجاح"))


# ===========================================================================================
#  المستخدمين والمجموعات والشاشات
# ===========================================================================================
@can_access(9302)
def membership():
    grid = SQLFORM.grid(
        db.auth_membership,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9302)
def users():
    grid = SQLFORM.grid(
        db.auth_user,
        user_signature=False,
        editable=True,
        deletable=False,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


@can_access(9302)
def groups():
    grid = SQLFORM.grid(
        db.auth_group,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
    )
    return dict(grid=grid)


def _sync_screens():
    valid_codes = {r["screen_code"] for r in aff_seed.SCREENS_CODE}
    # إضافة الشاشات الناقصة
    for r in aff_seed.SCREENS_CODE:
        if not db(db.screens.screen_code == r["screen_code"]).select().first():
            db.screens.insert(systems=r["systems"], name=r["name"], screen_code=r["screen_code"])
    # حذف الشاشات التي لم تعد موجودة في القائمة
    for row in db(~db.screens.screen_code.belongs(list(valid_codes))).select():
        db(db.screens_rules.screens == row.id).delete()
        row.delete_record()
    db.commit()


@can_access(9302)
def screens():
    _sync_screens()
    db.screens.systems.readable = False
    db.screens.systems.writable = False
    grid = SQLFORM.grid(
        db.screens,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        maxtextlengths={"screens.name": 250},
    )
    return dict(grid=grid)


@can_access(9302)
def screens_rules():
    _sync_screens()
    q = db.screens_rules.to_user == request.args(0)
    db.screens_rules.to_user.default = request.args(0)
    db.screens_rules.to_user.readable = False
    db.screens_rules.to_user.writable = False
    grid = SQLFORM.grid(
        q,
        user_signature=False,
        editable=True,
        deletable=True,
        create=True,
        csv=False,
        searchable=False,
        showbuttontext=True,
        orderby=db.screens_rules.screens,
        maxtextlengths={"screens_rules.screens": 250},
        args=request.args[:1],
    )
    return dict(grid=grid)


screens_code = aff_seed.SCREENS_CODE


@can_access(9302)
def grant_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.commit()
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=True, can_add=True, can_edit=True, can_delete=True,
                can_close=True, can_reopen=True,
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=True,
                can_add=True,
                can_edit=True,
                can_delete=True,
                can_close=True,
                can_reopen=True,
            )
    db.commit()
    redirect(URL("setup", "users_management"))


@can_access(9302)
def delete_all():
    for r in screens_code:
        screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
        if not screen_code:
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
    db.commit()
    for r in db(db.screens.id > 0).select():
        acc = (
            db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == request.args(0))
            )
            .select()
            .first()
        )
        if acc:
            acc.update_record(
                can_log_in=False, can_add=False, can_edit=False, can_delete=False,
                can_close=False, can_reopen=False,
            )
        else:
            db.screens_rules.validate_and_insert(
                screens=r.id,
                to_user=request.args(0),
                can_log_in=False,
                can_add=False,
                can_edit=False,
                can_delete=False,
                can_close=False,
                can_reopen=False,
            )
    db.commit()
    redirect(URL("setup", "users_management"))


# ===========================================================================================
#  معلومات الجهة والشعار
# ===========================================================================================
@can_access(9301)
def important_info():
    q = db(db.important_info.id > 0).select().first()
    info = {
        "name": "", "vat": "", "tel": "", "mobile": "",
        "address": "", "msg1": "", "msg2": "",
    }
    if q:
        info = {
            "name": q.name or "",
            "vat": q.vat or "",
            "tel": q.tel or "",
            "mobile": q.mobile or "",
            "address": (q.address or "").strip(),
            "msg1": (q.msg1 or "").strip(),
            "msg2": (q.msg2 or "").strip(),
        }
    return dict(info=info)


def _validate_important_info(data):
    """التحقق من قيم حقول معلومات الجهة (يُستخدم في الحفظ على السيرفر)."""
    errors = []
    name = (data.name or "").strip()
    vat = (data.vat or "").strip()
    tel = (data.tel or "").strip()
    mobile = (data.mobile or "").strip()
    address = (data.address or "").strip()
    msg1 = (data.msg1 or "").strip()
    msg2 = (data.msg2 or "").strip()

    if not name:
        errors.append("الاسم مطلوب")
    # الرقم الضريبي والهاتف والجوال اختيارية للحفظ
    if not address:
        errors.append("العنوان مطلوب")
    if not msg1:
        errors.append("رسالة العميل مطلوبة")
    if not msg2:
        errors.append("رسالة آخر الفاتورة مطلوبة")

    vals = dict(
        name=name, vat=vat, tel=tel, mobile=mobile,
        address=address, msg1=msg1, msg2=msg2,
    )
    return errors, vals


@can_access(9301)
def important_info_save():
    data = request.vars
    errors, vals = _validate_important_info(data)
    if errors:
        return response.json(api.api_error(mess=" | ".join(errors)))
    try:
        q = db(db.important_info.id > 0).select().first()
        if q:
            q.update_record(**vals)
        else:
            db.important_info.insert(**vals)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(mess="تم حفظ المعلومات بنجاح"))


@can_access(9301)
def important_info_2():
    q = db(db.important_info.id > 0).select().first()
    logo = (q.logo or "") if q else ""
    info = {
        "logo": logo,
        "logo_url": URL("default", "download", args=[logo]) if logo else "",
    }
    return dict(info=info)


@can_access(9301)
def important_info_2_save():
    data = request.vars
    q = db(db.important_info.id > 0).select().first()
    if not q:
        return response.json(api.api_error(mess="لا يوجد سجل لمعلومات النظام"))
    if not (data.logo is not None and hasattr(data.logo, "file")):
        return response.json(api.api_error(mess="يرجى اختيار ملف الشعار"))

    fname = data.logo.filename or ""
    ext = fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
    if ext not in ("png", "jpg", "jpeg", "gif", "webp", "svg"):
        return response.json(api.api_error(mess="صيغة الصورة غير مدعومة (PNG, JPG, GIF, WEBP, SVG)"))

    try:
        stored = db.important_info.logo.store(data.logo.file, data.logo.filename)
        q.update_record(logo=stored)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(
        data={"logo": stored, "logo_url": URL("default", "download", args=[stored])},
        mess="تم حفظ الشعار بنجاح",
    ))


# ===========================================================================================
#  إعدادات الرسائل النصية (SMS)
# ===========================================================================================
_SMS_DEFAULTS = {
    "enabled": False,
    "on_receipt": False,
    "on_return": False,
    "on_payment": False,
    "tpl_receipt": "عزيزي {name}، تم تسجيل سند استلام رقم {doc} بمبلغ {amount} ريال بتاريخ {date}. {org}",
    "tpl_return": "عزيزي {name}، تم تسجيل سند مرتجع رقم {doc} بمبلغ {amount} ريال بتاريخ {date}. {org}",
    "tpl_payment": "عزيزي {name}، تم تسجيل سداد بمبلغ {amount} ريال بتاريخ {date}. شكراً لتعاملكم. {org}",
}


def _as_bool(value):
    return str(value) in ("1", "true", "True", "on")


@can_access(9301)
def sms_settings():
    q = db(db.sms_settings.id > 0).select().first()
    info = dict(_SMS_DEFAULTS)
    if q:
        info = {
            "enabled": bool(q.enabled),
            "on_receipt": bool(q.on_receipt),
            "on_return": bool(q.on_return),
            "on_payment": bool(q.on_payment),
            "tpl_receipt": (q.tpl_receipt or "").strip() or _SMS_DEFAULTS["tpl_receipt"],
            "tpl_return": (q.tpl_return or "").strip() or _SMS_DEFAULTS["tpl_return"],
            "tpl_payment": (q.tpl_payment or "").strip() or _SMS_DEFAULTS["tpl_payment"],
        }
    # هل بيانات الاعتماد لدى المزوّد مضبوطة؟ (لعرض تنبيه في الواجهة)
    info["credentials_ok"] = bool(sms_authorization and sms_sender)
    return dict(info=info)


@can_access(9301)
def sms_settings_save():
    data = request.vars
    vals = {
        "enabled": _as_bool(data.enabled),
        "on_receipt": _as_bool(data.on_receipt),
        "on_return": _as_bool(data.on_return),
        "on_payment": _as_bool(data.on_payment),
        "tpl_receipt": (data.tpl_receipt or "").strip(),
        "tpl_return": (data.tpl_return or "").strip(),
        "tpl_payment": (data.tpl_payment or "").strip(),
    }
    # التحقق: صيغة الحدث المُفعّل يجب ألا تكون فارغة
    errors = []
    if vals["on_receipt"] and not vals["tpl_receipt"]:
        errors.append("صيغة رسالة الاستلام مطلوبة عند تفعيلها")
    if vals["on_return"] and not vals["tpl_return"]:
        errors.append("صيغة رسالة المرتجع مطلوبة عند تفعيلها")
    if vals["on_payment"] and not vals["tpl_payment"]:
        errors.append("صيغة رسالة السداد مطلوبة عند تفعيلها")
    if errors:
        return response.json(api.api_error(mess=" | ".join(errors)))
    # إبقاء الصيغ الفارغة على القيم الافتراضية بدل تخزين فراغ
    for key in ("tpl_receipt", "tpl_return", "tpl_payment"):
        if not vals[key]:
            vals[key] = _SMS_DEFAULTS[key]
    try:
        q = db(db.sms_settings.id > 0).select().first()
        if q:
            q.update_record(**vals)
        else:
            db.sms_settings.insert(**vals)
        db.commit()
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
    return response.json(api.api_ok(mess="تم حفظ إعدادات الرسائل النصية بنجاح"))


# ===========================================================================================
#  البيانات الافتتاحية
# ===========================================================================================
@can_access(9301)
def seed_data():
    return dict()


@can_access(9301)
def run_seed_data():
    try:
        logs = []
        aff_seed.run_seed(db, log=logs.append)
        return response.json(api.api_ok(data=logs, mess="تمت التهيئة بنجاح"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


# ===========================================================================================
#  إدارة المستخدمين والصلاحيات (Vue)
# ===========================================================================================
@can_access(9302)
def users_management():
    return dict()


@can_access(9302)
def get_users():
    """جلب المستخدمين مع pagination وبحث وفلتر الحالة"""
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    search = (request.vars.SearchText or "").strip()
    status_filter = request.vars.status_filter or "all"
    offset = pg * rc

    query = db.auth_user.id > 0
    if search:
        query &= (
            db.auth_user.first_name.contains(search)
            | db.auth_user.last_name.contains(search)
            | db.auth_user.email.contains(search)
        )
    if status_filter == "active":
        query &= (db.auth_user.registration_key == None) | (
            db.auth_user.registration_key == ""
        )
    elif status_filter == "disabled":
        query &= (db.auth_user.registration_key != None) & (
            db.auth_user.registration_key != ""
        )

    count = db(query).count()
    rows = db(query).select(
        db.auth_user.id,
        db.auth_user.first_name,
        db.auth_user.last_name,
        db.auth_user.email,
        db.auth_user.registration_key,
        orderby=db.auth_user.id,
        limitby=(offset, offset + rc),
    )
    data = []
    for r in rows:
        full_name = " ".join(
            x for x in [(r.first_name or "").strip(), (r.last_name or "").strip()] if x
        ) or r.first_name or r.last_name or r.email
        data.append({
            "id": r.id,
            "first_name": r.first_name,
            "last_name": r.last_name,
            "email": r.email,
            "registration_key": r.registration_key,
            "full_name": full_name,
        })
    return response.json({"data": data, "count": count})


@can_access(9302)
def save_user():
    """إضافة أو تعديل مستخدم"""
    try:
        data = request.vars
        user_id = data.get("id")
        if user_id:
            row = db.auth_user[user_id]
            if not row:
                return _setup_json_error("المستخدم غير موجود")
            errors, clean = _validate_user_payload(data, user_id=user_id)
            if errors:
                return _setup_json_error(" | ".join(errors))
            row.update_record(
                first_name=clean["first_name"],
                last_name=clean["last_name"],
                email=clean["email"],
            )
            if clean["password"]:
                row.update_record(password=db.auth_user.password.validate(clean["password"])[0])
        else:
            errors, clean = _validate_user_payload(data)
            if errors:
                return _setup_json_error(" | ".join(errors))
            password = db.auth_user.password.validate(clean["password"])[0]
            user_id = db.auth_user.insert(
                first_name=clean["first_name"],
                last_name=clean["last_name"],
                email=clean["email"],
                password=password,
            )
        db.commit()
        return response.json({"err": 0, "id": user_id})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def delete_user():
    """حذف/تعطيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if not row:
            return _setup_json_error("المستخدم غير موجود")
        row.update_record(registration_key="disabled")
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def enable_user():
    """تفعيل مستخدم"""
    try:
        user_id = request.args(0)
        row = db.auth_user[user_id]
        if not row:
            return _setup_json_error("المستخدم غير موجود")
        row.update_record(registration_key=None)
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def get_groups():
    """جلب كل المجموعات"""
    rows = db(db.auth_group.id > 0).select(db.auth_group.id, db.auth_group.role, orderby=db.auth_group.role)
    return response.json(rows.as_list())


@can_access(9302)
def get_user_membership():
    """جلب عضويات المستخدم"""
    user_id = request.args(0)
    rows = db(
        (db.auth_membership.user_id == user_id)
        & (db.auth_group.id == db.auth_membership.group_id)
    ).select(db.auth_membership.ALL, db.auth_group.role)
    data = [
        {
            "id": r.auth_membership.id,
            "user_id": r.auth_membership.user_id,
            "group_id": r.auth_membership.group_id,
            "role": r.auth_group.role,
        }
        for r in rows
    ]
    return response.json(data)


@can_access(9302)
def save_membership():
    """حفظ أو حذف عضوية"""
    try:
        data = request.vars
        user_id = data.get("user_id")
        group_id = data.get("group_id")
        checked = data.get("checked") == "true"
        user_id = _valid_auth_user_id(user_id)
        group_id = _valid_group_id(group_id)
        if not user_id:
            return _setup_json_error("المستخدم غير موجود")
        if not group_id:
            return _setup_json_error("المجموعة غير موجودة")

        if checked:
            existing = db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).select().first()
            if not existing:
                db.auth_membership.insert(user_id=user_id, group_id=group_id)
        else:
            db(
                (db.auth_membership.user_id == user_id) & (db.auth_membership.group_id == group_id)
            ).delete()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ===================== API for screens_rules Vue.js =====================

@can_access(9302)
def get_screens_rules():
    """جلب صلاحيات الشاشات للمستخدم مع pagination"""
    user_id = request.args(0)
    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 20)
    offset = pg * rc
    query = (db.screens_rules.to_user == user_id) & (
        db.screens.id == db.screens_rules.screens
    )
    rows = db(query).select(
        db.screens_rules.ALL,
        db.screens.name,
        db.screens.screen_code,
        orderby=db.screens.screen_code,
        limitby=(offset, offset + rc),
    )
    count = db(db.screens_rules.to_user == user_id).count()
    data = [
        {
            "id": r.screens_rules.id,
            "screens": r.screens_rules.screens,
            "can_log_in": r.screens_rules.can_log_in,
            "can_add": r.screens_rules.can_add,
            "can_edit": r.screens_rules.can_edit,
            "can_delete": r.screens_rules.can_delete,
            "can_close": r.screens_rules.can_close,
            "can_reopen": r.screens_rules.can_reopen,
            "screen_name": r.screens.name,
            "screen_code": r.screens.screen_code,
        }
        for r in rows
    ]
    return response.json({"data": data, "count": count})


@can_access(9302)
def get_available_screens():
    """جلب الشاشات غير المضافة للمستخدم"""
    user_id = request.args(0)
    used = db(db.screens_rules.to_user == user_id)._select(db.screens_rules.screens)
    rows = db(~db.screens.id.belongs(used)).select(
        db.screens.id,
        db.screens.name,
        db.screens.screen_code,
        orderby=db.screens.screen_code,
    )
    data = [{"id": r.id, "name": r.name, "screen_code": r.screen_code} for r in rows]
    return response.json(data)


@can_access(9302)
def save_rule():
    """حفظ أو تحديث صلاحية"""
    try:
        data = request.vars
        rule_id = data.get("id")
        if rule_id:
            row = db.screens_rules[rule_id]
            if not row:
                return _setup_json_error("الصلاحية غير موجودة")
            row.update_record(
                can_log_in=data.get("can_log_in") == "true",
                can_add=data.get("can_add") == "true",
                can_edit=data.get("can_edit") == "true",
                can_delete=data.get("can_delete") == "true",
                can_close=data.get("can_close") == "true",
                can_reopen=data.get("can_reopen") == "true",
            )
        else:
            user_id = _valid_auth_user_id(data.get("to_user"))
            screen_id = _valid_screen_id(data.get("screens"))
            if not user_id:
                return _setup_json_error("المستخدم غير موجود")
            if not screen_id:
                return _setup_json_error("الشاشة غير موجودة")
            db.screens_rules.insert(
                to_user=user_id,
                screens=screen_id,
                can_log_in=data.get("can_log_in") == "true",
                can_add=data.get("can_add") == "true",
                can_edit=data.get("can_edit") == "true",
                can_delete=data.get("can_delete") == "true",
                can_close=data.get("can_close") == "true",
                can_reopen=data.get("can_reopen") == "true",
            )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def delete_rule():
    """حذف صلاحية"""
    try:
        row = db.screens_rules[request.args(0)]
        if not row:
            return _setup_json_error("الصلاحية غير موجودة")
        row.delete_record()
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


# ===================== API grant_all / delete_all / add_missing for Vue.js =====================

@can_access(9302)
def api_grant_all():
    """منح جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=True, can_add=True, can_edit=True, can_delete=True,
                    can_close=True, can_reopen=True,
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=True,
                    can_add=True,
                    can_edit=True,
                    can_delete=True,
                    can_close=True,
                    can_reopen=True,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def api_delete_all():
    """حذف جميع الصلاحيات عبر API"""
    try:
        user_id = request.args(0)
        for r in screens_code:
            screen_code = db(db.screens.screen_code == r["screen_code"]).select().first()
            if not screen_code:
                db.screens.insert(
                    systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
                )
        db.commit()
        for r in db(db.screens.id > 0).select():
            acc = (
                db(
                    (db.screens_rules.screens == r.id)
                    & (db.screens_rules.to_user == user_id)
                )
                .select()
                .first()
            )
            if acc:
                acc.update_record(
                    can_log_in=False, can_add=False, can_edit=False, can_delete=False,
                    can_close=False, can_reopen=False,
                )
            else:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=False,
                    can_add=False,
                    can_edit=False,
                    can_delete=False,
                    can_close=False,
                    can_reopen=False,
                )
        db.commit()
        return response.json({"err": 0})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})


@can_access(9302)
def api_add_missing_screens():
    """مزامنة شاشات المستخدم: إضافة الناقصة بدون صلاحيات + حذف المُلغاة"""
    try:
        user_id = request.args(0)
        _sync_screens()
        valid_codes = {r["screen_code"] for r in screens_code}

        # حذف screens_rules للشاشات غير الموجودة في القائمة
        removed = 0
        for row in db(db.screens_rules.to_user == user_id).select():
            screen = db.screens[row.screens]
            if not screen or screen.screen_code not in valid_codes:
                row.delete_record()
                removed += 1

        # إضافة الشاشات الناقصة بدون صلاحيات
        added = 0
        for r in db(db.screens.id > 0).select():
            acc = db(
                (db.screens_rules.screens == r.id)
                & (db.screens_rules.to_user == user_id)
            ).select().first()
            if not acc:
                db.screens_rules.validate_and_insert(
                    screens=r.id,
                    to_user=user_id,
                    can_log_in=False,
                    can_add=False,
                    can_edit=False,
                    can_delete=False,
                    can_close=False,
                    can_reopen=False,
                )
                added += 1

        db.commit()
        return response.json({"err": 0, "added": added, "removed": removed})
    except Exception as e:
        db.rollback()
        return response.json({"err": 3, "mess": str(e)})
