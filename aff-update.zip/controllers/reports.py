# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  التقارير - الشاشة
# ======================================================================================


@can_access(6001)
def index():
    sc = screens_rules(6001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict(can_add=can_add, can_edit=can_edit, can_delete=can_delete)
