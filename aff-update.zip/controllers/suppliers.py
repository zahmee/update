# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  الموردين - الشاشات
#  ملاحظة: شاشة استعراض الموردين (index) حُذفت — التسجيل والتعديل أصبح من
#  الشاشة الموحدة families/index (تسجيل الموردين والأسر).
# ======================================================================================


@can_access(2106)
def account():
    """كشف حساب مورد"""
    try:
        supplier_id = int(request.args(0))
    except (ValueError, TypeError):
        redirect(URL("families", "index"))
    supplier = db.suppliers[supplier_id]
    if not supplier:
        redirect(URL("families", "index"))
    return dict(supplier=supplier, supplier_id=supplier_id)


@can_access(2107)
def payment():
    """شاشة تسديد الموردين"""
    sc = screens_rules(2107)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    return dict(can_add=can_add, can_edit=can_edit, can_delete=can_delete)
