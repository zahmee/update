# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  يوميات الصندوق - الشاشة
# ======================================================================================


@can_access(5001)
def index():
    sc = screens_rules(5001)
    can_add = sc.can_add
    can_edit = sc.can_edit
    can_delete = sc.can_delete
    can_close = sc.can_close
    can_reopen = sc.can_reopen
    return dict(
        can_add=can_add,
        can_edit=can_edit,
        can_delete=can_delete,
        can_close=can_close,
        can_reopen=can_reopen,
    )
