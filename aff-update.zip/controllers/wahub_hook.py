# -*- coding: utf-8 -*-
#  type: ignore
# ======================================================================================
#  نقطة استقبال إشعارات بوابة واتساب المركزية (wahub) — عامة بلا تسجيل دخول.
#    POST: حالات الرسائل المرسلة عبر البوابة، وردود العملاء، وطلبات الإيقاف؛ موقّعة بترويسة
#          X-Wahub-Signature بسرّ النظام في البوابة (قسم [wahub] callback_secret).
#  البوابة تعيد المحاولة حتى يرد النظام بنجاح، والمعالجة لا تكرر شيئاً إن أُعيد الإشعار.
#  ملف مستقل عمداً: مُزخرِف can_access يحوّل غير المسجّلين عند تحميل ملف المتحكم كله.
#  الرابط: https://<النطاق>/aff/wahub_hook
# ======================================================================================
import json
import logging

_log = logging.getLogger("web2py.app.aff.wahub")


def index():
    session.forget(response)
    response.headers["Content-Type"] = "text/plain; charset=utf-8"
    if request.env.request_method != "POST":
        raise HTTP(405, "Method Not Allowed")

    request.body.seek(0)
    raw = request.body.read()
    signature = request.env.http_x_wahub_signature
    if not wahub_client.verify_signature(wahub_config.get("callback_secret"), raw, signature):
        raise HTTP(403, "Invalid signature")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise HTTP(400, "Invalid JSON")
    try:
        wa_apply_hub_event(payload)
    except Exception:
        # خطأ عابر (قفل قاعدة البيانات مثلاً): البوابة تعيد الإشعار لاحقاً
        db.rollback()
        _log.exception("wahub callback processing failed")
        raise HTTP(500, "Error")
    return "OK"
