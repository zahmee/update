# -*- coding: utf-8 -*-
#  type: ignore
# ======================================================================================
#  نقطة استقبال إشعارات واتساب من ميتا (Webhook) — عامة بلا تسجيل دخول.
#    GET : مصافحة التحقق عند ضبط الرابط في لوحة تطبيق ميتا (hub.verify_token).
#    POST: حالات الرسائل (وصلت، قُرئت، فشلت) وردود العملاء، موقّعة بـ X-Hub-Signature-256.
#  ملف مستقل عمداً: مُزخرِف can_access يحوّل غير المسجّلين عند تحميل ملف المتحكم كله.
#  الرابط: https://<النطاق>/aff/whatsapp_hook/index
# ======================================================================================
import hmac
import json
import logging

_log = logging.getLogger("web2py.app.aff.whatsapp")


def index():
    session.forget(response)
    response.headers["Content-Type"] = "text/plain; charset=utf-8"
    method = request.env.request_method

    if method == "GET":
        mode = request.get_vars.get("hub.mode")
        token = str(request.get_vars.get("hub.verify_token") or "").encode("utf-8")
        expected = (wa_config.get("verify_token") or "").encode("utf-8")
        if mode == "subscribe" and expected and hmac.compare_digest(token, expected):
            return str(request.get_vars.get("hub.challenge") or "")
        raise HTTP(403, "Forbidden")

    if method != "POST":
        raise HTTP(405, "Method Not Allowed")

    request.body.seek(0)
    raw = request.body.read()
    signature = request.env.http_x_hub_signature_256
    if not whatsapp_cloud.verify_signature(wa_config.get("app_secret"), raw, signature):
        raise HTTP(403, "Invalid signature")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise HTTP(400, "Invalid JSON")
    try:
        wa_apply_webhook(payload)
    except Exception:
        # خطأ عابر (قفل قاعدة البيانات مثلاً): ميتا تعيد الإرسال لاحقاً، والمعالجة لا تكرر شيئاً
        db.rollback()
        _log.exception("WhatsApp webhook processing failed")
        raise HTTP(500, "Error")
    return "OK"
