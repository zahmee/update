# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  الأسر - APIs
# ======================================================================================
import api_helpers as api
import re
import datetime


def _parse_time(value):
    """تحويل نص الوقت HH:MM او HH:MM:SS الى نص HH:MM:SS يقبله web2py"""
    value = (value or "").strip()
    if not value:
        return None
    try:
        parts = value.split(":")
        t = datetime.time(int(parts[0]), int(parts[1]), int(parts[2]) if len(parts) > 2 else 0)
        return t.strftime("%H:%M:%S")
    except (ValueError, IndexError):
        return None


@can_access(1001, 1002)
def get_refs():
    """بيانات القوائم المنسدلة لشاشات الأسر والتسديد"""
    family_types = [{"id": r.id, "name": r.name} for r in db(db.key_family_type.id > 0).select(orderby=db.key_family_type.name)]
    pms = [{"id": r.id, "name": r.name} for r in db(db.key_payment_method.id > 0).select(orderby=db.key_payment_method.name)]
    pts = [{"id": r.id, "name": r.name} for r in db(db.key_payment_type.id > 0).select(orderby=db.key_payment_type.name)]
    return response.json(api.api_ok(data={
        "family_types": family_types,
        "payment_methods": pms,
        "payment_types": pts,
    }))


@can_access(1003)
def settlement_refs():
    """قائمة الأسر النشطة لشاشة التصفية"""
    families = [{
        "id": r.id,
        "name": r.name,
        "mobile": r.mobile or "",
        "sale_percent": round(r.sale_percent or 0, 2),
    } for r in db(db.families.stoped != True).select(orderby=db.families.name)]
    return response.json(api.api_ok(data={"families": families}))


def _date_range_filter(query, table, date_field, date_from, date_to):
    if date_from:
        query &= table[date_field] >= date_from
    if date_to:
        query &= table[date_field] <= date_to
    return query


def _sum_for(query, field):
    row = db(query).select(field.sum()).first()
    return round((row[field.sum()] or 0) if row else 0, 2)


def _money_row(value):
    return round(value or 0, 2)


@can_access(1003)
def family_settlement():
    """تصفية أسرة: المستلم، المرتجع، الصافي، النسبة، المستحق، المدفوع، الباقي"""
    try:
        family_id = int(request.vars.family_id or 0)
    except (TypeError, ValueError):
        family_id = 0
    family = db.families[family_id]
    if not family:
        return response.json(api.api_error(mess="اختر الأسرة أولاً"))

    date_from = _clean_text(request.vars.date_from)
    date_to = _clean_text(request.vars.date_to)
    limited_period = bool(date_from or date_to)

    recv_q = _date_range_filter(
        db.goods_received.family == family_id,
        db.goods_received,
        "receipt_date",
        date_from,
        date_to,
    )
    ret_q = _date_range_filter(
        db.goods_return.family == family_id,
        db.goods_return,
        "return_date",
        date_from,
        date_to,
    )
    pay_q = _date_range_filter(
        db.family_payments.family == family_id,
        db.family_payments,
        "pay_date",
        date_from,
        date_to,
    )

    received = _sum_for(recv_q, db.goods_received.bill_total)
    returned = _sum_for(ret_q, db.goods_return.total)
    paid = _sum_for(pay_q, db.family_payments.amount)
    net_sold = round(received - returned, 2)
    sale_percent = round(family.sale_percent or 0, 2)
    commission = round(net_sold * sale_percent / 100.0, 2)

    # في عرض فترة محددة نفصل الرصيد السابق حتى لا يبدو جزءاً من مبيعات الفترة.
    prev_for = 0 if limited_period else _money_row(family.prev_bal_for)
    prev_on = 0 if limited_period else _money_row(family.prev_bal_on)
    due_before_payments = round(net_sold - commission + prev_for - prev_on, 2)
    remaining = round(due_before_payments - paid, 2)

    recv_rows = db(recv_q).select(orderby=~db.goods_received.id, limitby=(0, 200))
    ret_rows = db(ret_q).select(orderby=~db.goods_return.id, limitby=(0, 200))
    pay_rows = db(pay_q).select(orderby=~db.family_payments.id, limitby=(0, 200))

    return response.json(api.api_ok(data={
        "family": {
            "id": family.id,
            "name": family.name,
            "mobile": family.mobile or "",
            "sale_percent": sale_percent,
            "prev_bal_for": _money_row(family.prev_bal_for),
            "prev_bal_on": _money_row(family.prev_bal_on),
        },
        "range": {
            "date_from": date_from,
            "date_to": date_to,
            "limited_period": limited_period,
        },
        "summary": {
            "received": received,
            "returned": returned,
            "net_sold": net_sold,
            "sale_percent": sale_percent,
            "commission": commission,
            "prev_for_used": prev_for,
            "prev_on_used": prev_on,
            "due_before_payments": due_before_payments,
            "paid": paid,
            "remaining": remaining,
            "side": "له" if remaining >= 0 else "عليه",
        },
        "received": [{
            "id": r.id,
            "doc_no": r.receipt_no or r.id,
            "doc_date": str(r.receipt_date or ""),
            "total": _money_row(r.bill_total),
            "note": r.note or "",
        } for r in recv_rows],
        "returns": [{
            "id": r.id,
            "doc_no": r.return_no or r.id,
            "doc_date": str(r.return_date or ""),
            "total": _money_row(r.total),
            "note": r.note or "",
        } for r in ret_rows],
        "payments": [{
            "id": r.id,
            "pay_date": str(r.pay_date or ""),
            "amount": _money_row(r.amount),
            "note": r.note or r.pay_note or "",
        } for r in pay_rows],
    }))


def _clean_text(value):
    return (value or "").strip()


def _validate_family_payload(data, row_id=None):
    name = _clean_text(data.name)
    mobile = _clean_text(data.mobile)
    national_id = _clean_text(data.national_id)
    family_no = _clean_text(data.family_no)
    guardian_name = _clean_text(data.guardian_name)
    address = _clean_text(data.address)
    try:
        members_count = int(data.members_count or 1)
    except (TypeError, ValueError):
        members_count = 1
    try:
        family_type = int(data.family_type or 0) or None
    except (TypeError, ValueError):
        family_type = None

    errors = []
    if not name:
        errors.append("اسم الأسرة مطلوب")
    if mobile and not re.match(r"^05\d{8}$", mobile):
        errors.append("رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05")
    if members_count < 1:
        errors.append("عدد أفراد الأسرة يجب أن يكون 1 أو أكثر")

    if mobile:
        duplicate_query = db.families.mobile == mobile
        if row_id:
            duplicate_query &= db.families.id != row_id
        if db(duplicate_query).select(db.families.id, limitby=(0, 1)).first():
            errors.append("يوجد هذا الرقم مسجل مسبقا")

    # الحقول المرجعية الفارغة (None) تُزال حتى لا يرفضها المدقق التلقائي
    clean = {
        "name": name,
        "family_no": family_no,
        "mobile": mobile,
        "national_id": national_id,
        "family_type": family_type,
        "members_count": members_count,
        "guardian_name": guardian_name,
        "address": address,
    }
    return errors, {k: v for k, v in clean.items() if v is not None}


@can_access(1001)
def get_families():
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    ft = int(ReqVar.familyType or 0)

    query = db.families.id > 0
    if ReqVar.SearchText and ReqVar.SearchText.strip():
        words = ReqVar.SearchText.strip().split()
        for word in words:
            query &= (
                db.families.name.contains(word)
                | db.families.mobile.contains(word)
                | db.families.family_no.contains(word)
                | db.families.national_id.contains(word)
            )
    if ft != 0:
        query &= db.families.family_type == ft

    sort_col = ReqVar.SortBy if ReqVar.SortBy in ("id", "name", "mobile") else "id"
    sa = (ReqVar.sequence or "true") == "true"
    orderby = db.families[sort_col] if sa else ~db.families[sort_col]

    count = db(query).count()
    offset = pg * rc
    rows = db(query).select(orderby=orderby, limitby=(offset, offset + rc))

    due_maps = party_due_maps("family")
    empty = compute_due(0, 0, 0, 0, 0, 0)
    type_names = {
        r.id: r.name for r in db(db.key_family_type.id > 0).select()
    }

    data = []
    for r in rows:
        # المستحق الموحّد (موجب = له، سالب = عليه) — انظر models/db_3_balances.py
        due = due_maps.get(r.id, empty)
        data.append({
            "id": r.id,
            "name": r.name,
            "family_no": r.family_no or "",
            "mobile": r.mobile or "",
            "national_id": r.national_id or "",
            "guardian_name": r.guardian_name or "",
            "address": r.address or "",
            "members_count": r.members_count or 1,
            "family_type": r.family_type or 0,
            "family_type_name": type_names.get(r.family_type, ""),
            "stoped": bool(r.stoped),
            "prev_bal_for": due["prev_for"],
            "prev_bal_on": due["prev_on"],
            "fam_recv": due["received"],
            "fam_ret": due["returned"],
            "fam_pay": due["paid"],
            "commission": due["commission"],
            "fam_bal": due["net_due"],
        })
    return response.json(api.api_list(rows=data, count=count))


@can_access(1001)
def new_family():
    try:
        data = request.vars
        errors, clean_data = _validate_family_payload(data)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        nid = db.families.validate_and_insert(**clean_data)
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        db.commit()
        return response.json(api.api_ok(data=nid))
    except Exception as e:
        print(e)
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1001)
def edit_family():
    try:
        data = request.vars
        row = db.families[data.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        errors, clean_data = _validate_family_payload(data, row_id=row.id)
        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))
        row.update_record(**clean_data)
        db.commit()
        return response.json(api.api_ok(data=row))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1001)
def toggle_family_stop():
    """قفل / فتح ملف الأسرة"""
    try:
        row = db.families[request.vars.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.update_record(stoped=not bool(row.stoped))
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "stoped": bool(row.stoped)}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@can_access(1001)
def get_fast_data():
    """مختصر حركة الأسرة: آخر التسديدات وآخر سندات الاستلام"""
    try:
        family_id = request.args(0)
        qry1 = db(
            db.family_payments.family == family_id
        ).select(
            orderby=~db.family_payments.id,
            limitby=(0, 10),
        )
        qry2 = db(
            db.goods_received.family == family_id
        ).select(
            orderby=~db.goods_received.id,
            limitby=(0, 10),
        )
        pays = []
        for p in qry1:
            pays.append({
                "id": p.id,
                "amount": p.amount,
                "pay_date": str(p.pay_date or ""),
                "pay_note": p.pay_note or "",
                "created_on": str(p.created_on or ""),
            })
        docs = []
        for g in qry2:
            docs.append({
                "id": g.id,
                "receipt_no": g.receipt_no or "",
                "bill_total": g.bill_total or 0,
                "receipt_date": str(g.receipt_date or ""),
            })
        return response.json(api.api_ok(data={"in": pays, "out": docs}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


# ======================================================================================
#  تسديد الأسر - APIs
# ======================================================================================
@can_access(1002)
def save_family_pay():
    try:
        data = request.vars
        family_id = int(data.family or 0)
        family = db.families[family_id]
        if not family:
            return response.json(api.api_error(mess="الأسرة غير موجودة"))
        try:
            amount = float(data.amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return response.json(api.api_error(mess="يجب إدخال مبلغ صحيح أكبر من صفر"))
        pay_date = _clean_text(data.pay_date) or request.now.strftime("%Y-%m-%d")
        lock_msg = locked_day_message(pay_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        pay_vals = {
            "family": family_id,
            "amount": amount,
            "pay_date": pay_date,
            "pay_time": _parse_time(data.pay_time),
            "payment_method": int(data.payment_method or 0) or None,
            "payment_type": int(data.payment_type or 0) or None,
            "note": data.note,
            "pay_note": data.pay_note,
        }
        pay_vals = {k: v for k, v in pay_vals.items() if v is not None}
        nid = db.family_payments.validate_and_insert(**pay_vals)
        if nid.get("errors") if isinstance(nid, dict) else nid.errors:
            db.rollback()
            return response.json(api.api_error(mess=str(nid.get("errors") if isinstance(nid, dict) else nid.errors)))
        db.commit()
        # إشعار نصي تلقائي بالسداد (معزول — لا يُسقط الحفظ)
        new_id = nid.get("id") if isinstance(nid, dict) else nid.id
        sms_notify("payment", family.mobile, name=family.name,
                   amount=amount, doc=new_id, date=pay_date)
        return response.json(api.api_ok(data=nid))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1002)
def get_family_pays():
    family_id = int(request.vars.family_id or 0)
    if not family_id:
        return response.json(api.api_error(mess="معرف الأسرة مطلوب"))

    pg = int(request.vars.page or 0)
    rc = int(request.vars.RecordCount or 15)
    offset = pg * rc

    query = db.family_payments.family == family_id
    # فلتر التاريخ: من / الى
    date_from = _clean_text(request.vars.date_from)
    date_to = _clean_text(request.vars.date_to)
    if date_from:
        query &= db.family_payments.pay_date >= date_from
    if date_to:
        query &= db.family_payments.pay_date <= date_to

    count = db(query).count()
    rows = db(query).select(orderby=~db.family_payments.id, limitby=(offset, offset + rc))
    total_row = db(query).select(db.family_payments.amount.sum()).first()
    total = total_row[db.family_payments.amount.sum()] or 0

    pm_names = {r.id: r.name for r in db(db.key_payment_method.id > 0).select()}
    pt_names = {r.id: r.name for r in db(db.key_payment_type.id > 0).select()}
    data = []
    for r in rows:
        data.append({
            "id": r.id,
            "amount": r.amount,
            "pay_date": str(r.pay_date or ""),
            "pay_time": str(r.pay_time or "")[:5],
            "payment_method": r.payment_method or 0,
            "payment_method_name": pm_names.get(r.payment_method, ""),
            "payment_type": r.payment_type or 0,
            "payment_type_name": pt_names.get(r.payment_type, ""),
            "pay_note": r.pay_note or "",
            "note": r.note or "",
            "created_on": str(r.created_on or ""),
        })
    return response.json(api.api_list(rows=data, count=count, total_amount=float(total)))


@can_access(1002)
def edit_family_pay():
    try:
        data = request.vars
        row = db.family_payments[int(data.id)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        try:
            amount = float(data.amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return response.json(api.api_error(mess="يجب إدخال مبلغ صحيح أكبر من صفر"))
        lock_msg = locked_day_message(row.pay_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        updates = {
            "amount": amount,
            "pay_note": data.pay_note,
            "payment_method": int(data.payment_method or 0) or None,
            "payment_type": int(data.payment_type or 0) or None,
        }
        if data.pay_time:
            updates["pay_time"] = _parse_time(data.pay_time)
        row.update_record(**updates)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@can_access(1002)
def delete_family_pay():
    try:
        pay_id = int(request.vars.id or 0)
        row = db.family_payments[pay_id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        lock_msg = locked_day_message(row.pay_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok())
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


# ======================================================================================
#  التسجيل الموحد للموردين والأسر - APIs
# ======================================================================================
PARTY_KINDS = ("family", "supplier")
PARTY_KIND_NAMES = {"family": "أسرة", "supplier": "مورد"}


def _party_table(kind):
    return db.families if kind == "family" else db.suppliers


def _parse_money(value):
    try:
        return round(float(value or 0), 2)
    except (TypeError, ValueError):
        return None


def _party_row_to_dict(r, kind):
    reg = r.reg_date or (r.created_on.date() if r.created_on else None)
    return {
        "id": r.id,
        "kind": kind,
        "kind_name": PARTY_KIND_NAMES[kind],
        "name": r.name,
        "mobile": r.mobile or "",
        "reg_date": str(reg or ""),
        "prev_bal_for": round(r.prev_bal_for or 0, 2),
        "prev_bal_on": round(r.prev_bal_on or 0, 2),
        "sale_percent": round(r.sale_percent or 0, 2),
        "stoped": bool(r.stoped),
    }


@can_access(1001)
def get_parties():
    """قائمة موحدة: الأسر + الموردون مع بحث وتصفية حسب النوع وترقيم صفحات"""
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    kind_filter = _clean_text(ReqVar.kind)
    words = _clean_text(ReqVar.SearchText).split()

    kinds = [kind_filter] if kind_filter in PARTY_KINDS else list(PARTY_KINDS)
    items = []
    for kind in kinds:
        table = _party_table(kind)
        query = table.id > 0
        for word in words:
            query &= table.name.contains(word) | table.mobile.contains(word)
        for r in db(query).select():
            items.append(_party_row_to_dict(r, kind))

    sort_col = ReqVar.SortBy if ReqVar.SortBy in ("id", "name", "mobile", "reg_date") else "id"
    sa = (ReqVar.sequence or "true") == "true"
    items.sort(key=lambda x: (x[sort_col], x["kind"]), reverse=not sa)

    count = len(items)
    offset = pg * rc
    page_items = items[offset:offset + rc]
    return response.json(api.api_list(rows=page_items, count=count))


@can_access(1001)
def save_party():
    """حفظ سجل جديد أو تعديل سجل (أسرة أو مورد) من الشاشة الموحدة"""
    try:
        data = request.vars
        kind = _clean_text(data.kind)
        if kind not in PARTY_KINDS:
            return response.json(api.api_error(mess="نوع السجل غير صحيح"))
        table = _party_table(kind)

        name = _clean_text(data.name)
        mobile = _clean_text(data.mobile)
        reg_date = _clean_text(data.reg_date)
        bal_for = _parse_money(data.prev_bal_for)
        bal_on = _parse_money(data.prev_bal_on)
        percent = _parse_money(data.sale_percent)

        errors = []
        if not name:
            errors.append("الاسم مطلوب")
        if mobile and not re.match(r"^05\d{8}$", mobile):
            errors.append("رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05")
        if bal_for is None or bal_for < 0:
            errors.append("الرصيد السابق له يجب أن يكون صفراً أو أكثر")
        if bal_on is None or bal_on < 0:
            errors.append("الرصيد السابق عليه يجب أن يكون صفراً أو أكثر")
        if percent is None or percent < 0 or percent > 100:
            errors.append("النسبة يجب أن تكون بين 0 و 100")
        if reg_date:
            try:
                datetime.datetime.strptime(reg_date, "%Y-%m-%d")
            except ValueError:
                errors.append("تاريخ التسجيل غير صحيح")

        row_id = int(data.id or 0)
        row = table[row_id] if row_id else None
        if row_id and not row:
            return response.json(api.api_error(mess="السجل غير موجود"))

        # منع تكرار رقم الجوال داخل نفس الجدول
        if mobile:
            dup = table.mobile == mobile
            if row:
                dup &= table.id != row.id
            if db(dup).select(table.id, limitby=(0, 1)).first():
                errors.append("يوجد هذا الرقم مسجل مسبقا")

        if errors:
            return response.json(api.api_error(mess=" | ".join(errors)))

        clean = {
            "name": name,
            "mobile": mobile,
            "prev_bal_for": bal_for,
            "prev_bal_on": bal_on,
            "sale_percent": percent,
        }
        if reg_date:
            clean["reg_date"] = reg_date

        if row:
            row.update_record(**clean)
            db.commit()
            return response.json(api.api_ok(data={"id": row.id, "kind": kind}))
        nid = table.validate_and_insert(**clean)
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        db.commit()
        new_id = nid.get("id") if isinstance(nid, dict) else nid.id
        return response.json(api.api_ok(data={"id": new_id, "kind": kind}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(1001)
def toggle_party_stop():
    """قفل / فتح سجل (أسرة أو مورد) من الشاشة الموحدة"""
    try:
        kind = _clean_text(request.vars.kind)
        if kind not in PARTY_KINDS:
            return response.json(api.api_error(mess="نوع السجل غير صحيح"))
        table = _party_table(kind)
        row = table[request.vars.id]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        row.update_record(stoped=not bool(row.stoped))
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "kind": kind, "stoped": bool(row.stoped)}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
