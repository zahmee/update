# -*- coding: utf-8 -*-
#  type: ignore

# ======================================================================================
#  الموردين - APIs
#  ملاحظة: شاشة استعراض الموردين (suppliers/index) حُذفت وأصبح التسجيل
#  والتعديل من الشاشة الموحدة families/index (انظر families_api.save_party).
# ======================================================================================
import api_helpers as api
import datetime


def _parse_time(value):
    """تحويل نص الوقت HH:MM او HH:MM:SS الى نص HH:MM:SS يقبله web2py"""
    value = (value or "").strip()
    if not value:
        return None
    try:
        parts = value.split(":")
        t = datetime.time(int(parts[0]), int(parts[1]), int(parts[2]) if len(parts) > 2 else 0)
        return t.strftime("%H:%M:%S")
    except (ValueError, IndexError):
        return None


def _clean_text(value):
    return (value or "").strip()


# ======================================================================================
#  كشف حساب مورد
# ======================================================================================
@can_access(2106)
def get_account():
    try:
        supplier_id = int(request.args(0))
    except (TypeError, ValueError):
        return response.json(api.api_error(mess="معرف المورد مطلوب"))
    supplier = db.suppliers[supplier_id]
    if not supplier:
        return response.json(api.api_error(mess="المورد غير موجود"))

    movement_limit = 100
    received_count = db(db.goods_received.supplier == supplier_id).count()
    returns_count = db(db.goods_return.supplier == supplier_id).count()
    payments_count = db(db.supplier_payments.supplier == supplier_id).count()

    recv = db(
        (db.goods_received.supplier == supplier_id)
    ).select(orderby=~db.goods_received.id, limitby=(0, movement_limit))
    ret = db(
        (db.goods_return.supplier == supplier_id)
    ).select(orderby=~db.goods_return.id, limitby=(0, movement_limit))
    pay = db(
        (db.supplier_payments.supplier == supplier_id)
    ).select(orderby=~db.supplier_payments.id, limitby=(0, movement_limit))

    pm_names = {r.id: r.name for r in db(db.key_payment_method.id > 0).select()}
    it_names = {r.id: r.name for r in db(db.key_invoce_type.id > 0).select()}
    pt_names = {r.id: r.name for r in db(db.key_payment_type.id > 0).select()}

    def _doc_row(g, no_field, date_field, total_field):
        return {
            "id": g.id,
            "doc_no": g[no_field] or "",
            "doc_date": str(g[date_field] or ""),
            "total": g[total_field] or 0,
            "payment_method_name": pm_names.get(g.payment_method, "") if "payment_method" in g else "",
            "invoce_type_name": it_names.get(g.invoce_type, "") if "invoce_type" in g else "",
            "note": g.note or "",
        }

    recv_list = [
        _doc_row(g, "receipt_no", "receipt_date", "bill_total")
        for g in recv
    ]
    ret_list = [
        _doc_row(g, "return_no", "return_date", "total")
        for g in ret
    ]
    pay_list = []
    for p in pay:
        pay_list.append({
            "id": p.id,
            "pay_total": p.pay_total or 0,
            "pay_date": str(p.pay_date or ""),
            "payment_method_name": pm_names.get(p.payment_method, ""),
            "payment_type_name": pt_names.get(p.payment_type, ""),
            "note": p.note or "",
        })

    # المجاميع النهائية تُحسب من كامل حركة المورد، لا من قائمة العرض المحدودة.
    due = party_net_due("supplier", supplier)

    return response.json(api.api_ok(data={
        "supplier": {"id": supplier.id, "name": supplier.name},
        "received": recv_list,
        "returns": ret_list,
        "payments": pay_list,
        "movement_limit": movement_limit,
        "received_count": received_count,
        "returns_count": returns_count,
        "payments_count": payments_count,
        "sum_recv": due["received"],
        "sum_ret": due["returned"],
        "sum_pay": due["paid"],
        "net_goods": due["net_goods"],
        "sale_percent": due["sale_percent"],
        "commission": due["commission"],
        "prev_bal_for": due["prev_for"],
        "prev_bal_on": due["prev_on"],
        "balance": due["net_due"],
        "side": due["side"],
    }))


# ======================================================================================
#  التسديد الموحّد (موردون + أسر) - APIs — شاشة 2107
#  supplier_payments.pay_total / family_payments.amount موحّدان في الاستجابة باسم amount
# ======================================================================================
PAY_KINDS = ("supplier", "family")
PAY_KIND_NAMES = {"supplier": "مورد", "family": "أسرة"}


def _pay_party_table(kind):
    return db.suppliers if kind == "supplier" else db.families


@can_access(2107)
def pay_get_refs():
    """الأطراف (موردون + أسر) + طرق الدفع + أنواع السداد للشاشة الموحّدة"""
    parties = []
    for r in db(db.suppliers.stoped != True).select(orderby=db.suppliers.name):
        parties.append({"id": r.id, "kind": "supplier", "kind_name": "مورد", "name": r.name})
    for r in db(db.families.stoped != True).select(orderby=db.families.name):
        parties.append({"id": r.id, "kind": "family", "kind_name": "أسرة", "name": r.name})
    pms = [{"id": r.id, "name": r.name} for r in db(db.key_payment_method.id > 0).select(orderby=db.key_payment_method.name)]
    pts = [{"id": r.id, "name": r.name} for r in db(db.key_payment_type.id > 0).select(orderby=db.key_payment_type.name)]
    return response.json(api.api_ok(data={
        "parties": parties, "payment_methods": pms, "payment_types": pts,
    }))


@can_access(2107)
def pay_get_due():
    """تفصيل المستحق لطرف (مورد/أسرة) لعرضه قبل التسديد"""
    kind = _clean_text(request.vars.kind)
    if kind not in PAY_KINDS:
        return response.json(api.api_error(mess="نوع الطرف غير صحيح"))
    row = _pay_party_table(kind)[int(request.vars.party_id or 0)]
    if not row:
        return response.json(api.api_error(mess="الطرف غير موجود"))
    due = party_net_due(kind, row)
    due.update({
        "kind": kind,
        "kind_name": PAY_KIND_NAMES[kind],
        "party_id": row.id,
        "name": row.name,
    })
    return response.json(api.api_ok(data=due))


def _pay_row(kind, r):
    """تطبيع صف تسديد من الجدولين إلى شكل موحّد"""
    if kind == "supplier":
        amount = r.pay_total or 0
        party_id = r.supplier
        pay_note = ""
    else:
        amount = r.amount or 0
        party_id = r.family
        pay_note = r.pay_note or ""
    return {
        "id": r.id,
        "kind": kind,
        "kind_name": PAY_KIND_NAMES[kind],
        "party_id": party_id,
        "amount": round(amount, 2),
        "pay_date": str(r.pay_date or ""),
        "pay_time": str(r.pay_time or "")[:5],
        "payment_method": r.payment_method or 0,
        "payment_type": r.payment_type or 0,
        "pay_note": pay_note,
        "note": r.note or "",
    }


@can_access(2107)
def pay_list():
    """سجل موحّد لكل التسديدات (موردون + أسر) مع فلاتر وترقيم صفحات"""
    ReqVar = request.vars
    pg = int(ReqVar.page or 0)
    rc = int(ReqVar.RecordCount or 20)
    kind_filter = _clean_text(ReqVar.kind)
    party_id = int(ReqVar.party_id or 0)
    date_from = _clean_text(ReqVar.date_from)
    date_to = _clean_text(ReqVar.date_to)
    search = _clean_text(ReqVar.SearchText)

    pm_names = {r.id: r.name for r in db(db.key_payment_method.id > 0).select()}
    pt_names = {r.id: r.name for r in db(db.key_payment_type.id > 0).select()}
    sup_names = {r.id: r.name for r in db(db.suppliers.id > 0).select()}
    fam_names = {r.id: r.name for r in db(db.families.id > 0).select()}

    kinds = [kind_filter] if kind_filter in PAY_KINDS else list(PAY_KINDS)
    items = []
    for kind in kinds:
        table = db.supplier_payments if kind == "supplier" else db.family_payments
        party_field = table.supplier if kind == "supplier" else table.family
        names = sup_names if kind == "supplier" else fam_names
        q = table.id > 0
        if party_id:
            q &= party_field == party_id
        if date_from:
            q &= table.pay_date >= date_from
        if date_to:
            q &= table.pay_date <= date_to
        for r in db(q).select(orderby=~table.id):
            item = _pay_row(kind, r)
            item["party_name"] = names.get(item["party_id"], "")
            if search and search not in (item["party_name"] or ""):
                continue
            item["payment_method_name"] = pm_names.get(item["payment_method"], "")
            item["payment_type_name"] = pt_names.get(item["payment_type"], "")
            items.append(item)

    items.sort(key=lambda x: (x["pay_date"], x["id"]), reverse=True)
    count = len(items)
    total = round(sum(x["amount"] for x in items), 2)
    offset = pg * rc
    page_items = items[offset:offset + rc]
    return response.json(api.api_list(rows=page_items, count=count, total_amount=total))


def _pay_common_vals(data):
    """القيم المشتركة بين الجدولين"""
    return {
        "pay_date": _clean_text(data.pay_date) or request.now.strftime("%Y-%m-%d"),
        "pay_time": _parse_time(data.pay_time),
        "payment_method": int(data.payment_method or 0) or None,
        "payment_type": int(data.payment_type or 0) or None,
        "note": data.note,
    }


@can_access(2107)
def pay_save():
    """حفظ تسديد جديد لمورد أو أسرة (يُدرج في الجدول الصحيح)"""
    try:
        data = request.vars
        kind = _clean_text(data.kind)
        if kind not in PAY_KINDS:
            return response.json(api.api_error(mess="نوع الطرف غير صحيح"))
        party = _pay_party_table(kind)[int(data.party_id or 0)]
        if not party:
            return response.json(api.api_error(mess="الطرف غير موجود"))
        try:
            amount = float(data.amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return response.json(api.api_error(mess="يجب إدخال مبلغ صحيح أكبر من صفر"))

        vals = _pay_common_vals(data)
        lock_msg = locked_day_message(vals["pay_date"])
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        if kind == "supplier":
            vals.update({"supplier": party.id, "pay_total": amount})
            table = db.supplier_payments
        else:
            vals.update({"family": party.id, "amount": amount, "pay_note": data.pay_note})
            table = db.family_payments
        vals = {k: v for k, v in vals.items() if v is not None}
        nid = table.validate_and_insert(**vals)
        insert_errors = nid.get("errors") if isinstance(nid, dict) else nid.errors
        if insert_errors:
            db.rollback()
            return response.json(api.api_error(mess=str(insert_errors)))
        db.commit()
        new_id = nid.get("id") if isinstance(nid, dict) else nid.id
        # إشعار نصي تلقائي بالسداد لمورد أو أسرة (معزول — لا يُسقط الحفظ)
        sms_notify("payment", party.mobile, name=party.name,
                   amount=amount, doc=new_id, date=vals["pay_date"])
        return response.json(api.api_ok(data={"id": new_id, "kind": kind}, mess="تم حفظ التسديد بنجاح"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=e))


@can_access(2107)
def pay_edit():
    """تعديل تسديد (مورد أو أسرة)"""
    try:
        data = request.vars
        kind = _clean_text(data.kind)
        if kind not in PAY_KINDS:
            return response.json(api.api_error(mess="نوع الطرف غير صحيح"))
        table = db.supplier_payments if kind == "supplier" else db.family_payments
        row = table[int(data.id or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        try:
            amount = float(data.amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return response.json(api.api_error(mess="يجب إدخال مبلغ صحيح أكبر من صفر"))
        updates = {
            "pay_date": _clean_text(data.pay_date) or row.pay_date,
            "payment_method": int(data.payment_method or 0) or None,
            "payment_type": int(data.payment_type or 0) or None,
            "note": data.note,
        }
        lock_msg = locked_day_message(row.pay_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        lock_msg = locked_day_message(updates["pay_date"])
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        if data.pay_time:
            updates["pay_time"] = _parse_time(data.pay_time)
        if kind == "supplier":
            updates["pay_total"] = amount
        else:
            updates["amount"] = amount
            updates["pay_note"] = data.pay_note
        row.update_record(**updates)
        db.commit()
        return response.json(api.api_ok(data={"id": row.id, "kind": kind}))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))


@can_access(2107)
def pay_delete():
    """حذف تسديد (مورد أو أسرة)"""
    try:
        kind = _clean_text(request.vars.kind)
        if kind not in PAY_KINDS:
            return response.json(api.api_error(mess="نوع الطرف غير صحيح"))
        table = db.supplier_payments if kind == "supplier" else db.family_payments
        row = table[int(request.vars.id or 0)]
        if not row:
            return response.json(api.api_error(mess="السجل غير موجود"))
        lock_msg = locked_day_message(row.pay_date)
        if lock_msg:
            return response.json(api.api_error(mess=lock_msg))
        row.delete_record()
        db.commit()
        return response.json(api.api_ok(mess="تم الحذف"))
    except Exception as e:
        db.rollback()
        return response.json(api.api_error(mess=str(e)))
