/**
 * Vue 3 application bootstrap for the server-rendered web2py screens.
 *
 * The application uses one small Vue root per page and keeps its templates in
 * the HTML response. This helper normalizes the former Vue 2 root options,
 * registers the Vue 3 build of vue-select when present, and provides the small
 * $http surface used by the users-management screen through the Fetch API.
 */
(function (global) {
    'use strict';

    function addQuery(url, params) {
        if (!params) return url;
        var query = new URLSearchParams();
        Object.keys(params).forEach(function (key) {
            var value = params[key];
            if (Array.isArray(value)) {
                value.forEach(function (item) { query.append(key, item == null ? '' : item); });
            } else if (value !== undefined && value !== null) {
                query.append(key, value);
            }
        });
        var text = query.toString();
        if (!text) return url;
        return url + (url.indexOf('?') === -1 ? '?' : '&') + text;
    }

    function encodeBody(body) {
        if (body == null) return undefined;
        if (typeof body === 'string' || body instanceof FormData ||
            body instanceof URLSearchParams || body instanceof Blob) {
            return body;
        }

        var encoded = new URLSearchParams();
        Object.keys(body).forEach(function (key) {
            var value = body[key];
            if (Array.isArray(value)) {
                value.forEach(function (item) { encoded.append(key, item == null ? '' : item); });
            } else if (value !== undefined && value !== null) {
                encoded.append(key, value);
            }
        });
        return encoded;
    }

    function readResponse(response) {
        return response.text().then(function (text) {
            var body = null;
            if (text) {
                try {
                    body = JSON.parse(text);
                } catch (ignore) {
                    body = text;
                }
            }
            var result = {
                body: body,
                status: response.status,
                ok: response.ok,
                headers: response.headers
            };
            if (!response.ok) {
                var message = body && body.mess ? body.mess : 'تعذر إكمال الطلب';
                var error = new Error(message);
                error.response = result;
                throw error;
            }
            return result;
        });
    }

    var http = {
        get: function (url, options) {
            return fetch(addQuery(url, options && options.params), {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }).then(readResponse);
        },
        post: function (url, body) {
            return fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: encodeBody(body)
            }).then(readResponse);
        }
    };

    function resolveVueSelect() {
        var candidate = global['vue-select'] || global.VueSelect;
        if (!candidate) return null;
        return candidate.VueSelect || candidate.default || candidate;
    }

    global.mountVueApp = function (options) {
        if (!global.Vue || typeof global.Vue.createApp !== 'function') {
            throw new Error('Vue 3 was not loaded before the page application.');
        }

        var normalized = Object.assign({}, options || {});
        var target = normalized.el || '#app';
        delete normalized.el;

        // Vue 2 allowed an object on the root instance. Vue 3 requires a
        // factory; each page has one root, so retaining the same object is safe.
        if (normalized.data && typeof normalized.data !== 'function') {
            var initialData = normalized.data;
            normalized.data = function () { return initialData; };
        }

        var vueApp = global.Vue.createApp(normalized);
        var vueSelect = resolveVueSelect();
        if (vueSelect) vueApp.component('v-select', vueSelect);

        // Native Fetch replacement for the retired vue-resource dependency.
        vueApp.config.globalProperties.$http = http;

        var instance = vueApp.mount(target);
        Object.defineProperty(instance, '$vueApp', {
            configurable: false,
            enumerable: false,
            value: vueApp
        });
        return instance;
    };

    global.AppHttp = http;
})(window);
