var API_BASE = window.location.origin + window.location.pathname.replace(/\/reports\/index(\.js)?\/?$/, '/reports_api/');
var reportMoneyFormatter = new Intl.NumberFormat('ar-SA-u-nu-latn', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});

var REPORT_TITLES = {
    daily_summary: 'الملخص اليومي: المستلم والمرتجع والمسدد',
    cash_monthly: 'الصندوق الشهري: يوميات الصندوق',
    payments_summary: 'ملخص السدادات لكل جهة',
    balances: 'أرصدة الموردين والأسر'
};

function monthStart() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-01';
}

function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

var app = new Vue({
    el: '#app',
    data: {
        reportType: 'daily_summary',
        filters: {
            start_date: monthStart(),
            end_date: todayStr(),
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            kind: 'all'
        },
        rows: [],
        totals: {},
        loading: false,
        ran: false
    },
    computed: {
        usesDateRange: function () {
            return this.reportType === 'daily_summary' || this.reportType === 'payments_summary';
        },
        reportTitle: function () {
            return REPORT_TITLES[this.reportType] || '';
        },
        reportSubtitle: function () {
            if (this.usesDateRange) {
                return 'الفترة من ' + (this.filters.start_date || 'البداية') + ' إلى ' + (this.filters.end_date || 'اليوم');
            }
            if (this.reportType === 'cash_monthly') {
                return 'شهر ' + this.filters.month + ' / ' + this.filters.year;
            }
            return 'حتى تاريخ ' + todayStr();
        },
        totalCards: function () {
            var t = this.totals || {};
            var fmt = this.fmt;
            if (this.reportType === 'daily_summary') {
                return [
                    { label: 'إجمالي المستلم', value: fmt(t.received) },
                    { label: 'إجمالي المرتجع', value: fmt(t.returned) },
                    { label: 'إجمالي المسدد', value: fmt(t.paid) },
                    { label: 'صافي المستلم', value: fmt(t.net) }
                ];
            }
            if (this.reportType === 'cash_monthly') {
                return [
                    { label: 'مبيعات الشهر', value: fmt(t.pos_total) },
                    { label: 'المسدد للجهات', value: fmt(t.paid_to_suppliers) },
                    { label: 'فرق الصندوق خلال الشهر', value: fmt(t.cash_difference) },
                    { label: 'آخر كاش فعلي', value: t.actual_closing_cash == null ? '-' : fmt(t.actual_closing_cash) }
                ];
            }
            if (this.reportType === 'payments_summary') {
                return [
                    { label: 'عدد السدادات', value: t.payments_count || 0 },
                    { label: 'إجمالي المسدد', value: fmt(t.total_paid) }
                ];
            }
            return [
                { label: 'إجمالي المستلم', value: fmt(t.received) },
                { label: 'إجمالي المسدد', value: fmt(t.paid) },
                { label: 'صافي الأرصدة', value: fmt(t.balance) }
            ];
        }
    },
    created: function () {
        this.run_report();
    },
    methods: {
        fmt: function (x) {
            var value = Number(x || 0);
            return reportMoneyFormatter.format(Number.isFinite(value) ? value : 0);
        },
        run_report: function () {
            var self = this;
            self.loading = true;
            self.ran = false;
            var params = {};
            if (this.usesDateRange) {
                params.start_date = this.filters.start_date || '';
                params.end_date = this.filters.end_date || '';
            } else if (this.reportType === 'cash_monthly') {
                params.year = this.filters.year;
                params.month = this.filters.month;
            } else if (this.reportType === 'balances') {
                params.kind = this.filters.kind;
            }
            fetch(API_BASE + this.reportType + '?' + new URLSearchParams(params).toString())
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.loading = false;
                    self.ran = true;
                    if (Api.isOk(res)) {
                        self.rows = (res.data && res.data.rows) || [];
                        self.totals = (res.data && res.data.totals) || {};
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.loading = false;
                    self.ran = true;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        print_report: function () {
            window.print();
        }
    }
});
