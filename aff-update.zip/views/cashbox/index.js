var API_BASE = window.location.origin + window.location.pathname.replace(/\/cashbox\/index(\.js)?\/?$/, '/cashbox_api/');

var moneyFormatter = new Intl.NumberFormat('ar-SA-u-nu-latn', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});

function localDateString(date) {
    var d = date || new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function blank_entry() {
    return {
        id: 0,
        register_date: localDateString(),
        opening_balance: 0,
        pos_total: 0,
        bank_withdrawal: 0,
        misc_expenses: 0,
        paid_to_suppliers: 0,
        actual_closing_cash: null,
        cash_difference: null,
        difference_reason: '',
        locked: false,
        locked_at: '',
        locked_by_name: '',
        reopened_at: '',
        reopened_by_name: '',
        reopen_reason: '',
        note: ''
    };
}

function blank_family_summary() {
    return {
        source: 'live',
        received: 0,
        returned: 0,
        net_sales: 0,
        commission_rate: 0,
        commission_amount: 0,
        net_amount: 0,
        details: []
    };
}

function family_summary_from_row(row) {
    return {
        source: row.locked ? 'snapshot' : 'live',
        received: row.family_received || 0,
        returned: row.family_returned || 0,
        net_sales: row.family_net_sales || 0,
        commission_rate: row.family_commission_rate || 0,
        commission_amount: row.family_commission_amount || 0,
        net_amount: row.family_net_amount || 0,
        details: []
    };
}

function entry_from_row(row) {
    return {
        id: row.id,
        register_date: row.register_date,
        opening_balance: row.opening_balance,
        pos_total: row.pos_total,
        bank_withdrawal: row.bank_withdrawal,
        misc_expenses: row.misc_expenses,
        paid_to_suppliers: row.paid_to_suppliers,
        actual_closing_cash: row.actual_closing_cash,
        cash_difference: row.cash_difference,
        difference_reason: row.difference_reason || '',
        locked: !!row.locked,
        locked_at: row.locked_at || '',
        locked_by_name: row.locked_by_name || '',
        reopened_at: row.reopened_at || '',
        reopened_by_name: row.reopened_by_name || '',
        reopen_reason: row.reopen_reason || '',
        note: row.note || ''
    };
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data_row_count: 0,
        loading: false,
        saving: false,
        suggestionsLoading: false,
        selectedRow: -1,
        edit_row_data: {},
        getData: { page: 0, RecordCount: 20, date_from: '', date_to: '' },
        entry: blank_entry(),
        familySummary: blank_family_summary(),
        suggested: { opening: null, paid: null },
        events: [],
        fetchSequence: 0,
        suggestionSequence: 0,
        canAdd: CAN_ADD,
        canEdit: CAN_EDIT,
        canDelete: CAN_DELETE,
        canClose: CAN_CLOSE,
        canReopen: CAN_REOPEN
    },
    computed: {
        totalPages: function () {
            if (this.data_row_count <= 0) return 1;
            return Math.ceil(this.data_row_count / Number(this.getData.RecordCount));
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var currentPage = this.getData.page + 1;
            var totalPages = this.totalPages;
            var range = [];
            var delta = 2;
            var last = -1;
            for (var i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
                    if (last !== -1 && i - last > 1) range.push('...');
                    range.push(i);
                    last = i;
                }
            }
            return range;
        },
        pageTotals: function () {
            var totals = { pos: 0, bank: 0, misc: 0, paid: 0, tin: 0, tout: 0, net: 0, difference: 0 };
            for (var i = 0; i < this.data.length; i++) {
                var row = this.data[i];
                totals.pos += Number(row.pos_total || 0);
                totals.bank += Number(row.bank_withdrawal || 0);
                totals.misc += Number(row.misc_expenses || 0);
                totals.paid += Number(row.paid_to_suppliers || 0);
                totals.tin += Number(row.total_in || 0);
                totals.tout += Number(row.total_out || 0);
                totals.net += Number(row.net_sales || 0);
                totals.difference += Number(row.cash_difference || 0);
            }
            var latest = this.data.length ? this.data[0] : null;
            return {
                pos: this.fmt(totals.pos),
                bank: this.fmt(totals.bank),
                misc: this.fmt(totals.misc),
                paid: this.fmt(totals.paid),
                tin: this.fmt(totals.tin),
                tout: this.fmt(totals.tout),
                net: this.fmt(totals.net),
                lastClosing: latest ? this.fmt(latest.closing_balance) : '-',
                lastActual: latest ? this.fmtMaybe(latest.actual_closing_cash) : '-',
                difference: this.fmt(totals.difference),
                differenceRaw: totals.difference
            };
        },
        totalIn: function () {
            return Number(this.entry.opening_balance || 0)
                + Number(this.entry.pos_total || 0)
                + Number(this.entry.bank_withdrawal || 0);
        },
        totalOut: function () {
            return Number(this.entry.misc_expenses || 0)
                + Number(this.entry.paid_to_suppliers || 0);
        },
        closingBalance: function () {
            return this.totalIn - this.totalOut;
        },
        netSales: function () {
            return Number(this.entry.pos_total || 0) - Number(this.entry.paid_to_suppliers || 0);
        },
        cashDifference: function () {
            if (this.entry.actual_closing_cash === null || this.entry.actual_closing_cash === '') return null;
            return Number(this.entry.actual_closing_cash) - this.closingBalance;
        },
        hasCashDifference: function () {
            return this.cashDifference !== null && Math.abs(this.cashDifference) >= 0.005;
        },
        canEditEntry: function () {
            return this.entry.id ? this.canEdit : this.canAdd;
        },
        formReadOnly: function () {
            return !!this.entry.locked || !this.canEditEntry;
        }
    },
    created: function () {
        this.fetchData();
    },
    methods: {
        fmt: function (value) {
            var number = Number(value || 0);
            return moneyFormatter.format(Number.isFinite(number) ? number : 0);
        },
        fmtMaybe: function (value) {
            return value === null || value === '' || typeof value === 'undefined' ? '-' : this.fmt(value);
        },
        varianceClass: function (value) {
            var number = Number(value || 0);
            if (number > 0.004) return 'cash-variance-positive';
            if (number < -0.004) return 'cash-variance-negative';
            return '';
        },
        rowNumber: function (index) {
            return this.getData.page * Number(this.getData.RecordCount) + index + 1;
        },
        validDateRange: function () {
            if (this.getData.date_from && this.getData.date_to && this.getData.date_from > this.getData.date_to) {
                Swal.fire('تنبيه', 'تاريخ البداية يجب ألا يكون بعد تاريخ النهاية', 'warning');
                return false;
            }
            return true;
        },
        fetchData: function () {
            if (!this.validDateRange()) return;
            var self = this;
            var sequence = ++self.fetchSequence;
            self.loading = true;
            var params = {
                page: self.getData.page,
                RecordCount: self.getData.RecordCount,
                date_from: self.getData.date_from,
                date_to: self.getData.date_to
            };
            fetch(API_BASE + 'get_entries?' + new URLSearchParams(params).toString())
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (sequence !== self.fetchSequence) return;
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.data = res.data || [];
                        self.data_row_count = res.count || 0;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    if (sequence !== self.fetchSequence) return;
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.fetchData();
        },
        resetFilters: function () {
            this.getData.date_from = '';
            this.getData.date_to = '';
            this.onChange();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.fetchData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = row;
        },
        showEntryModal: function () {
            bootstrap.Modal.getOrCreateInstance(document.getElementById('entryModal')).show();
        },
        hideEntryModal: function () {
            var modal = bootstrap.Modal.getInstance(document.getElementById('entryModal'));
            if (modal) modal.hide();
        },
        new_entry_click: function () {
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.entry = blank_entry();
            this.familySummary = blank_family_summary();
            this.suggested = { opening: null, paid: null };
            this.events = [];
            this.showEntryModal();
            this.refreshSuggestions(true);
        },
        edit_entry_click: function () {
            if (this.selectedRow === -1) return;
            this.entry = entry_from_row(this.edit_row_data);
            this.familySummary = family_summary_from_row(this.edit_row_data);
            this.suggested = {
                opening: this.edit_row_data.opening_balance,
                paid: this.edit_row_data.paid_to_suppliers
            };
            this.events = [];
            this.showEntryModal();
            this.refreshSuggestions(false);
            this.fetchEvents();
        },
        on_date_change: function () {
            if (!this.entry.id) this.refreshSuggestions(true);
        },
        refreshSuggestions: function (autoFillOpening) {
            var self = this;
            if (!self.entry.register_date) return;
            var requestedDate = self.entry.register_date;
            var sequence = ++self.suggestionSequence;
            self.suggestionsLoading = true;
            fetch(API_BASE + 'get_entry_by_date?date=' + encodeURIComponent(requestedDate))
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (sequence !== self.suggestionSequence || self.entry.register_date !== requestedDate) return;
                    self.suggestionsLoading = false;
                    if (!Api.isOk(res)) {
                        Api.showError(res);
                        return;
                    }
                    var data = res.data || {};
                    self.suggested = {
                        opening: data.suggested_opening != null ? data.suggested_opening : null,
                        paid: data.suggested_paid != null ? data.suggested_paid : 0
                    };
                    self.familySummary = data.family_summary || blank_family_summary();
                    if (!self.entry.locked) self.entry.paid_to_suppliers = self.suggested.paid;
                    if (autoFillOpening && !self.entry.id && Number(self.entry.opening_balance || 0) === 0
                            && self.suggested.opening !== null) {
                        self.entry.opening_balance = self.suggested.opening;
                    }
                    if (data.entry && !self.entry.id) {
                        self.entry = entry_from_row(data.entry);
                        self.fetchEvents();
                        Swal.fire('يومية موجودة', 'تم فتح اليومية المسجلة لهذا التاريخ بدل إنشاء نسخة مكررة.', 'info');
                    }
                })
                .catch(function () {
                    if (sequence !== self.suggestionSequence) return;
                    self.suggestionsLoading = false;
                    Swal.fire('تعذر التحديث', 'لم نتمكن من جلب الرصيد السابق والمسدد الفعلي.', 'warning');
                });
        },
        fetchEvents: function () {
            var self = this;
            if (!self.entry.id) {
                self.events = [];
                return;
            }
            fetch(API_BASE + 'get_entry_events?id=' + encodeURIComponent(self.entry.id))
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.events = Api.isOk(res) ? (res.data || []) : [];
                })
                .catch(function () { self.events = []; });
        },
        validateEntry: function (lockAfterSave) {
            if (!this.entry.register_date) {
                Swal.fire('تنبيه', 'اختر تاريخ اليومية', 'warning');
                return false;
            }
            var fields = ['opening_balance', 'pos_total', 'bank_withdrawal', 'misc_expenses'];
            for (var i = 0; i < fields.length; i++) {
                var value = Number(this.entry[fields[i]]);
                if (!Number.isFinite(value) || value < 0) {
                    Swal.fire('تنبيه', 'جميع المبالغ يجب أن تكون أرقامًا تساوي صفرًا أو أكثر', 'warning');
                    return false;
                }
            }
            if (this.entry.actual_closing_cash !== null && this.entry.actual_closing_cash !== '') {
                var actual = Number(this.entry.actual_closing_cash);
                if (!Number.isFinite(actual) || actual < 0) {
                    Swal.fire('تنبيه', 'الكاش الفعلي يجب أن يكون رقمًا يساوي صفرًا أو أكثر', 'warning');
                    return false;
                }
            }
            if (lockAfterSave && (this.entry.actual_closing_cash === null || this.entry.actual_closing_cash === '')) {
                Swal.fire('تنبيه', 'أدخل الكاش الفعلي آخر الفترة قبل الإقفال', 'warning');
                return false;
            }
            if (lockAfterSave && this.hasCashDifference && !String(this.entry.difference_reason || '').trim()) {
                Swal.fire('تنبيه', 'اكتب سبب فرق الصندوق قبل الإقفال', 'warning');
                return false;
            }
            return true;
        },
        save_entry: function (lockAfterSave) {
            if (this.saving || !this.validateEntry(lockAfterSave)) return;
            var self = this;
            self.saving = true;
            var body = new URLSearchParams();
            body.append('id', self.entry.id || 0);
            body.append('register_date', self.entry.register_date);
            body.append('opening_balance', self.entry.opening_balance || 0);
            body.append('pos_total', self.entry.pos_total || 0);
            body.append('bank_withdrawal', self.entry.bank_withdrawal || 0);
            body.append('misc_expenses', self.entry.misc_expenses || 0);
            body.append('paid_to_suppliers', self.entry.paid_to_suppliers || 0);
            body.append('actual_closing_cash', self.entry.actual_closing_cash == null ? '' : self.entry.actual_closing_cash);
            body.append('difference_reason', self.entry.difference_reason || '');
            body.append('lock_after_save', lockAfterSave ? 'true' : 'false');
            body.append('note', self.entry.note || '');
            fetch(API_BASE + 'save_entry', { method: 'POST', body: body })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.saving = false;
                    if (Api.isOk(res)) {
                        self.hideEntryModal();
                        self.selectedRow = -1;
                        self.edit_row_data = {};
                        self.fetchData();
                        Swal.fire({ icon: 'success', title: 'تم', text: res.mess || 'تم حفظ اليومية', timer: 1800, showConfirmButton: false });
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.saving = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        confirmClose: function () {
            if (!this.validateEntry(true)) return;
            var self = this;
            Swal.fire({
                title: 'إقفال اليومية؟',
                html: 'المتوقع: <strong>' + self.fmt(self.closingBalance) + '</strong> ر.س<br>'
                    + 'الفعلي: <strong>' + self.fmt(self.entry.actual_closing_cash) + '</strong> ر.س<br>'
                    + 'الفرق: <strong>' + self.fmt(self.cashDifference) + '</strong> ر.س<br>'
                    + '<hr class="my-2">صافي مبيعات الأسر: <strong>' + self.fmt(self.familySummary.net_sales) + '</strong> ر.س<br>'
                    + 'حصة المتجر: <strong>' + self.fmt(self.familySummary.commission_amount) + '</strong> ر.س',
                icon: self.hasCashDifference ? 'warning' : 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم، احفظ وأقفل',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#0f766e'
            }).then(function (result) {
                if (result.isConfirmed) self.save_entry(true);
            });
        },
        reopen_entry_click: function () {
            var self = this;
            Swal.fire({
                title: 'إعادة فتح اليومية',
                input: 'textarea',
                inputLabel: 'سبب إعادة الفتح',
                inputPlaceholder: 'اكتب سببًا واضحًا يمكن مراجعته لاحقًا',
                inputAttributes: { 'aria-label': 'سبب إعادة فتح اليومية' },
                showCancelButton: true,
                confirmButtonText: 'إعادة الفتح',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b7791f',
                inputValidator: function (value) {
                    if (!String(value || '').trim()) return 'سبب إعادة الفتح مطلوب';
                }
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                var body = new URLSearchParams();
                body.append('id', self.entry.id);
                body.append('reopen_reason', String(result.value || '').trim());
                fetch(API_BASE + 'reopen_entry', { method: 'POST', body: body })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        self.saving = false;
                        if (Api.isOk(res)) {
                            self.hideEntryModal();
                            self.fetchData();
                            Swal.fire({ icon: 'success', title: 'تمت إعادة الفتح', timer: 1600, showConfirmButton: false });
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () {
                        self.saving = false;
                        Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                    });
            });
        },
        delete_entry_click: function () {
            if (this.selectedRow === -1 || this.edit_row_data.locked) return;
            var self = this;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'سيتم حذف يومية ' + self.edit_row_data.register_date + ' نهائيًا. هل أنت متأكد؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b42318'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                fetch(API_BASE + 'delete_entry?id=' + encodeURIComponent(self.edit_row_data.id), { method: 'POST' })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        if (Api.isOk(res)) {
                            self.selectedRow = -1;
                            self.edit_row_data = {};
                            self.fetchData();
                            Swal.fire({ icon: 'success', title: 'تم الحذف', timer: 1500, showConfirmButton: false });
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
            });
        },
        printList: function () {
            window.print();
        },
        exportCsv: function () {
            var headers = [
                'التاريخ', 'الحالة', 'الرصيد الافتتاحي', 'المبيعات', 'سحب بنكي', 'مصروفات',
                'المسدد للجهات', 'إجمالي الوارد', 'إجمالي المنصرف', 'الرصيد المتوقع',
                'الكاش الفعلي', 'فرق الصندوق', 'صافي بعد المسدد', 'المستلم من الأسر',
                'المرتجع للأسر', 'صافي مبيعات الأسر', 'متوسط نسبة المتجر %', 'حصة المتجر من الأسر',
                'صافي مبلغ الأسر', 'الملاحظات'
            ];
            var lines = [headers];
            for (var i = 0; i < this.data.length; i++) {
                var row = this.data[i];
                lines.push([
                    row.register_date, row.locked ? 'مقفل' : 'مفتوح', row.opening_balance, row.pos_total,
                    row.bank_withdrawal, row.misc_expenses, row.paid_to_suppliers, row.total_in, row.total_out,
                    row.closing_balance, row.actual_closing_cash, row.cash_difference, row.net_sales,
                    row.family_received, row.family_returned, row.family_net_sales, row.family_commission_rate,
                    row.family_commission_amount, row.family_net_amount, row.note || ''
                ]);
            }
            var csv = lines.map(function (line) {
                return line.map(function (value) {
                    var text = value == null ? '' : String(value);
                    return '"' + text.replace(/"/g, '""') + '"';
                }).join(',');
            }).join('\r\n');
            var blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(blob);
            var link = document.createElement('a');
            link.href = url;
            link.download = 'cashbox-' + localDateString() + '.csv';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }
    }
});
