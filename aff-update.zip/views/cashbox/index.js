var API_BASE = window.location.origin + window.location.pathname.replace(/\/cashbox\/index(\.js)?\/?$/, '/cashbox_api/');

var moneyFormatter = new Intl.NumberFormat('ar-SA-u-nu-latn', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});

function localDateString(date) {
    var d = date || new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function blank_entry() {
    return {
        id: 0,
        register_date: localDateString(),
        separated_accounts: true,
        opening_balance: null,
        cash_sales: 0,
        pos_total: 0,
        bank_withdrawal: 0,
        misc_expenses: 0,
        paid_to_suppliers: 0,
        cash_paid_to_suppliers: 0,
        cash_deposit_to_bank: 0,
        bank_opening_balance: null,
        bank_deposit: 0,
        bank_paid_to_suppliers: 0,
        bank_expenses: 0,
        bank_closing_balance: 0,
        actual_closing_bank: null,
        bank_difference: null,
        bank_difference_reason: '',
        pos_fees: 0,
        pos_net_to_bank: 0,
        unallocated_payments: 0,
        actual_closing_cash: null,
        cash_difference: null,
        difference_reason: '',
        locked: false,
        locked_at: '',
        locked_by_name: '',
        reopened_at: '',
        reopened_by_name: '',
        reopen_reason: '',
        note: ''
    };
}

function blank_family_summary() {
    return {
        source: 'live',
        received: 0,
        returned: 0,
        net_sales: 0,
        commission_rate: 0,
        commission_amount: 0,
        net_amount: 0,
        details: []
    };
}

function blank_suggestions() {
    return {
        opening: null,
        openings: { cash: null, bank: null, initial: true, source_date: '' },
        paid: null,
        payments: { cash: 0, bank: 0, unallocated: 0, total: 0 }
    };
}

function family_summary_from_row(row) {
    return {
        source: row.locked ? 'snapshot' : 'live',
        received: row.family_received || 0,
        returned: row.family_returned || 0,
        net_sales: row.family_net_sales || 0,
        commission_rate: row.family_commission_rate || 0,
        commission_amount: row.family_commission_amount || 0,
        net_amount: row.family_net_amount || 0,
        details: []
    };
}

function entry_from_row(row) {
    return {
        id: row.id,
        register_date: row.register_date,
        separated_accounts: !!row.separated_accounts,
        opening_balance: row.opening_balance,
        cash_sales: row.cash_sales || 0,
        pos_total: row.pos_total,
        bank_withdrawal: row.bank_withdrawal,
        misc_expenses: row.misc_expenses,
        paid_to_suppliers: row.paid_to_suppliers,
        cash_paid_to_suppliers: row.cash_paid_to_suppliers || 0,
        cash_deposit_to_bank: row.cash_deposit_to_bank || 0,
        bank_opening_balance: row.bank_opening_balance || 0,
        bank_deposit: row.bank_deposit || 0,
        bank_paid_to_suppliers: row.bank_paid_to_suppliers || 0,
        bank_expenses: row.bank_expenses || 0,
        bank_closing_balance: row.bank_closing_balance || 0,
        actual_closing_bank: row.actual_closing_bank,
        bank_difference: row.bank_difference,
        bank_difference_reason: row.bank_difference_reason || '',
        pos_fees: row.pos_fees || 0,
        pos_net_to_bank: row.pos_net_to_bank || 0,
        unallocated_payments: row.unallocated_payments || 0,
        actual_closing_cash: row.actual_closing_cash,
        cash_difference: row.cash_difference,
        difference_reason: row.difference_reason || '',
        locked: !!row.locked,
        locked_at: row.locked_at || '',
        locked_by_name: row.locked_by_name || '',
        reopened_at: row.reopened_at || '',
        reopened_by_name: row.reopened_by_name || '',
        reopen_reason: row.reopen_reason || '',
        note: row.note || ''
    };
}

var app = mountVueApp({
    el: '#app',
    data: {
        data: [],
        data_row_count: 0,
        loading: false,
        saving: false,
        suggestionsLoading: false,
        selectedRow: -1,
        edit_row_data: {},
        getData: { page: 0, RecordCount: 20, date_from: '', date_to: '' },
        entry: blank_entry(),
        familySummary: blank_family_summary(),
        suggested: blank_suggestions(),
        events: [],
        fetchSequence: 0,
        suggestionSequence: 0,
        canAdd: CAN_ADD,
        canEdit: CAN_EDIT,
        canDelete: CAN_DELETE,
        canClose: CAN_CLOSE,
        canReopen: CAN_REOPEN
    },
    computed: {
        totalPages: function () {
            if (this.data_row_count <= 0) return 1;
            return Math.ceil(this.data_row_count / Number(this.getData.RecordCount));
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var currentPage = this.getData.page + 1;
            var totalPages = this.totalPages;
            var range = [];
            var delta = 2;
            var last = -1;
            for (var i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
                    if (last !== -1 && i - last > 1) range.push('...');
                    range.push(i);
                    last = i;
                }
            }
            return range;
        },
        pageTotals: function () {
            var totals = { cashSales: 0, posSales: 0, posFees: 0, paid: 0, cashDifference: 0, bankDifference: 0 };
            for (var i = 0; i < this.data.length; i++) {
                var row = this.data[i];
                totals.cashSales += Number(row.cash_sales || 0);
                totals.posSales += Number(row.pos_total || 0);
                totals.posFees += Number(row.pos_fees || 0);
                totals.paid += Number(row.paid_to_suppliers || 0);
                totals.cashDifference += Number(row.cash_difference || 0);
                totals.bankDifference += Number(row.bank_difference || 0);
            }
            var latest = this.data.length ? this.data[0] : null;
            return {
                cashSales: this.fmt(totals.cashSales),
                posSales: this.fmt(totals.posSales),
                posFees: this.fmt(totals.posFees),
                paid: this.fmt(totals.paid),
                cashDifference: this.fmt(totals.cashDifference),
                cashDifferenceRaw: totals.cashDifference,
                bankDifference: this.fmt(totals.bankDifference),
                bankDifferenceRaw: totals.bankDifference,
                lastCash: latest ? this.fmt(latest.closing_balance) : '-',
                lastBank: latest && latest.separated_accounts ? this.fmt(latest.bank_closing_balance) : '-'
            };
        },
        isSeparated: function () {
            return !!this.entry.separated_accounts;
        },
        totalIn: function () {
            if (!this.isSeparated) {
                return Number(this.entry.opening_balance || 0)
                    + Number(this.entry.pos_total || 0)
                    + Number(this.entry.bank_withdrawal || 0);
            }
            return Number(this.entry.opening_balance || 0)
                + Number(this.entry.cash_sales || 0)
                + Number(this.entry.bank_withdrawal || 0);
        },
        totalOut: function () {
            if (!this.isSeparated) {
                return Number(this.entry.misc_expenses || 0)
                    + Number(this.entry.paid_to_suppliers || 0);
            }
            return Number(this.entry.misc_expenses || 0)
                + Number(this.entry.cash_paid_to_suppliers || 0)
                + Number(this.entry.cash_deposit_to_bank || 0);
        },
        closingBalance: function () {
            return this.totalIn - this.totalOut;
        },
        netSales: function () {
            return Number(this.entry.pos_total || 0)
                + (this.isSeparated ? Number(this.entry.cash_sales || 0) : 0)
                - Number(this.entry.paid_to_suppliers || 0);
        },
        bankClosingBalance: function () {
            return Number(this.entry.bank_opening_balance || 0)
                + Number(this.entry.bank_deposit || 0)
                + Number(this.entry.cash_deposit_to_bank || 0)
                + this.posNetToBank
                - Number(this.entry.bank_withdrawal || 0)
                - Number(this.entry.bank_paid_to_suppliers || 0)
                - Number(this.entry.bank_expenses || 0);
        },
        posGross: function () {
            var gross = Number(this.entry.pos_total || 0);
            return Math.round((gross + Number.EPSILON) * 100) / 100;
        },
        posFee: function () {
            var grossHalalas = Math.round(this.posGross * 100);
            return Math.round(grossHalalas * 8 / 1000) / 100;
        },
        posNetToBank: function () {
            return this.posGross - this.posFee;
        },
        cashDifference: function () {
            if (this.entry.actual_closing_cash === null || this.entry.actual_closing_cash === '') return null;
            return Number(this.entry.actual_closing_cash) - this.closingBalance;
        },
        hasCashDifference: function () {
            return this.cashDifference !== null && Math.abs(this.cashDifference) >= 0.005;
        },
        bankDifference: function () {
            if (this.entry.actual_closing_bank === null || this.entry.actual_closing_bank === '') return null;
            return Number(this.entry.actual_closing_bank) - this.bankClosingBalance;
        },
        hasBankDifference: function () {
            return this.bankDifference !== null && Math.abs(this.bankDifference) >= 0.005;
        },
        openingReadOnly: function () {
            return this.formReadOnly || (this.isSeparated && !this.suggested.openings.initial);
        },
        canEditEntry: function () {
            return this.entry.id ? this.canEdit : this.canAdd;
        },
        formReadOnly: function () {
            return !!this.entry.locked || !this.canEditEntry;
        }
    },
    created: function () {
        this.fetchData();
    },
    methods: {
        fmt: function (value) {
            var number = Number(value || 0);
            return moneyFormatter.format(Number.isFinite(number) ? number : 0);
        },
        fmtMaybe: function (value) {
            return value === null || value === '' || typeof value === 'undefined' ? '-' : this.fmt(value);
        },
        varianceClass: function (value) {
            var number = Number(value || 0);
            if (number > 0.004) return 'cash-variance-positive';
            if (number < -0.004) return 'cash-variance-negative';
            return '';
        },
        rowNumber: function (index) {
            return this.getData.page * Number(this.getData.RecordCount) + index + 1;
        },
        validDateRange: function () {
            if (this.getData.date_from && this.getData.date_to && this.getData.date_from > this.getData.date_to) {
                Swal.fire('تنبيه', 'تاريخ البداية يجب ألا يكون بعد تاريخ النهاية', 'warning');
                return false;
            }
            return true;
        },
        fetchData: function () {
            if (!this.validDateRange()) return;
            var self = this;
            var sequence = ++self.fetchSequence;
            self.loading = true;
            var params = {
                page: self.getData.page,
                RecordCount: self.getData.RecordCount,
                date_from: self.getData.date_from,
                date_to: self.getData.date_to
            };
            fetch(API_BASE + 'get_entries?' + new URLSearchParams(params).toString())
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (sequence !== self.fetchSequence) return;
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.data = res.data || [];
                        self.data_row_count = res.count || 0;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    if (sequence !== self.fetchSequence) return;
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.fetchData();
        },
        resetFilters: function () {
            this.getData.date_from = '';
            this.getData.date_to = '';
            this.onChange();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.fetchData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = row;
        },
        showEntryModal: function () {
            bootstrap.Modal.getOrCreateInstance(document.getElementById('entryModal')).show();
        },
        hideEntryModal: function () {
            var modal = bootstrap.Modal.getInstance(document.getElementById('entryModal'));
            if (modal) modal.hide();
        },
        new_entry_click: function () {
            this.selectedRow = -1;
            this.edit_row_data = {};
            this.entry = blank_entry();
            this.familySummary = blank_family_summary();
            this.suggested = blank_suggestions();
            this.events = [];
            this.showEntryModal();
            this.refreshSuggestions(true);
        },
        edit_entry_click: function () {
            if (this.selectedRow === -1) return;
            this.entry = entry_from_row(this.edit_row_data);
            this.familySummary = family_summary_from_row(this.edit_row_data);
            this.suggested = {
                opening: this.edit_row_data.opening_balance,
                openings: {
                    cash: this.edit_row_data.opening_balance,
                    bank: this.edit_row_data.bank_opening_balance,
                    initial: false,
                    source_date: ''
                },
                paid: this.edit_row_data.paid_to_suppliers,
                payments: {
                    cash: this.edit_row_data.cash_paid_to_suppliers || 0,
                    bank: this.edit_row_data.bank_paid_to_suppliers || 0,
                    unallocated: this.edit_row_data.unallocated_payments || 0,
                    total: this.edit_row_data.paid_to_suppliers || 0
                }
            };
            this.events = [];
            this.showEntryModal();
            this.refreshSuggestions(false);
            this.fetchEvents();
        },
        on_date_change: function () {
            if (!this.entry.id) this.refreshSuggestions(true);
        },
        refreshSuggestions: function (autoFillOpening) {
            var self = this;
            if (!self.entry.register_date) return;
            var requestedDate = self.entry.register_date;
            var sequence = ++self.suggestionSequence;
            self.suggestionsLoading = true;
            fetch(API_BASE + 'get_entry_by_date?date=' + encodeURIComponent(requestedDate))
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (sequence !== self.suggestionSequence || self.entry.register_date !== requestedDate) return;
                    self.suggestionsLoading = false;
                    if (!Api.isOk(res)) {
                        Api.showError(res);
                        return;
                    }
                    var data = res.data || {};
                    self.suggested = {
                        opening: data.suggested_opening != null ? data.suggested_opening : null,
                        openings: data.suggested_openings || blank_suggestions().openings,
                        paid: data.suggested_paid != null ? data.suggested_paid : 0,
                        payments: data.payment_totals || blank_suggestions().payments
                    };
                    self.familySummary = data.family_summary || blank_family_summary();
                    if (data.entry && !self.entry.id) {
                        self.entry = entry_from_row(data.entry);
                        self.fetchEvents();
                        Swal.fire('يومية موجودة', 'تم فتح اليومية المسجلة لهذا التاريخ بدل إنشاء نسخة مكررة.', 'info');
                    }
                    if (!self.entry.locked) {
                        self.entry.paid_to_suppliers = self.suggested.payments.total;
                        self.entry.cash_paid_to_suppliers = self.suggested.payments.cash;
                        self.entry.bank_paid_to_suppliers = self.suggested.payments.bank;
                        self.entry.unallocated_payments = self.suggested.payments.unallocated;
                    }
                    if (autoFillOpening && !self.entry.id) {
                        if (self.entry.separated_accounts) {
                            if ((self.entry.opening_balance === null || self.entry.opening_balance === '')
                                    && self.suggested.openings.cash !== null) {
                                self.entry.opening_balance = self.suggested.openings.cash;
                            }
                            if ((self.entry.bank_opening_balance === null || self.entry.bank_opening_balance === '')
                                    && self.suggested.openings.bank !== null) {
                                self.entry.bank_opening_balance = self.suggested.openings.bank;
                            }
                        } else if (self.suggested.opening !== null) {
                            self.entry.opening_balance = self.suggested.opening;
                        }
                    }
                    if (!data.can_create && !data.entry) {
                        Swal.fire('لا يمكن إنشاء اليومية', data.create_message || 'راجع ترتيب اليوميات السابقة', 'warning');
                    }
                })
                .catch(function () {
                    if (sequence !== self.suggestionSequence) return;
                    self.suggestionsLoading = false;
                    Swal.fire('تعذر التحديث', 'لم نتمكن من جلب الرصيد السابق والمسدد الفعلي.', 'warning');
                });
        },
        fetchEvents: function () {
            var self = this;
            if (!self.entry.id) {
                self.events = [];
                return;
            }
            fetch(API_BASE + 'get_entry_events?id=' + encodeURIComponent(self.entry.id))
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.events = Api.isOk(res) ? (res.data || []) : [];
                })
                .catch(function () { self.events = []; });
        },
        validateEntry: function (lockAfterSave) {
            if (!this.entry.register_date) {
                Swal.fire('تنبيه', 'اختر تاريخ اليومية', 'warning');
                return false;
            }
            var fields = this.isSeparated
                ? [
                    'opening_balance', 'cash_sales', 'pos_total', 'bank_withdrawal',
                    'misc_expenses', 'cash_deposit_to_bank', 'bank_opening_balance',
                    'bank_deposit', 'bank_expenses'
                ]
                : ['opening_balance', 'pos_total', 'bank_withdrawal', 'misc_expenses'];
            for (var i = 0; i < fields.length; i++) {
                if (this.entry[fields[i]] === null || this.entry[fields[i]] === '') {
                    Swal.fire('تنبيه', 'أدخل الأرصدة الافتتاحية والمبالغ المطلوبة', 'warning');
                    return false;
                }
                var value = Number(this.entry[fields[i]]);
                if (!Number.isFinite(value) || value < 0) {
                    Swal.fire('تنبيه', 'جميع المبالغ يجب أن تكون أرقامًا تساوي صفرًا أو أكثر', 'warning');
                    return false;
                }
            }
            if (this.isSeparated && (this.closingBalance < -0.004 || this.bankClosingBalance < -0.004)) {
                Swal.fire('تنبيه', 'إحدى الحركات تتجاوز الرصيد المتاح في حسابها', 'warning');
                return false;
            }
            if (this.entry.actual_closing_cash !== null && this.entry.actual_closing_cash !== '') {
                var actual = Number(this.entry.actual_closing_cash);
                if (!Number.isFinite(actual) || actual < 0) {
                    Swal.fire('تنبيه', 'الكاش الفعلي يجب أن يكون رقمًا يساوي صفرًا أو أكثر', 'warning');
                    return false;
                }
            }
            if (lockAfterSave && (this.entry.actual_closing_cash === null || this.entry.actual_closing_cash === '')) {
                Swal.fire('تنبيه', 'أدخل الكاش الفعلي آخر الفترة قبل الإقفال', 'warning');
                return false;
            }
            if (this.isSeparated) {
                var actualFields = [['actual_closing_bank', 'رصيد البنك الفعلي']];
                for (var j = 0; j < actualFields.length; j++) {
                    var actualValue = this.entry[actualFields[j][0]];
                    if (actualValue !== null && actualValue !== ''
                            && (!Number.isFinite(Number(actualValue)) || Number(actualValue) < 0)) {
                        Swal.fire('تنبيه', actualFields[j][1] + ' يجب أن يكون صفراً أو أكثر', 'warning');
                        return false;
                    }
                    if (lockAfterSave && (actualValue === null || actualValue === '')) {
                        Swal.fire('تنبيه', 'أدخل ' + actualFields[j][1] + ' قبل الإقفال', 'warning');
                        return false;
                    }
                }
                if (lockAfterSave && Number(this.entry.unallocated_payments || 0) !== 0) {
                    Swal.fire('تنبيه', 'توجد سدادات بلا طريقة مرتبطة بالكاش أو البنك. صححها أولاً.', 'warning');
                    return false;
                }
                if (lockAfterSave && this.hasBankDifference && !String(this.entry.bank_difference_reason || '').trim()) {
                    Swal.fire('تنبيه', 'اكتب سبب فرق البنك قبل الإقفال', 'warning');
                    return false;
                }
            }
            if (lockAfterSave && this.hasCashDifference && !String(this.entry.difference_reason || '').trim()) {
                Swal.fire('تنبيه', 'اكتب سبب فرق الصندوق قبل الإقفال', 'warning');
                return false;
            }
            return true;
        },
        save_entry: function (lockAfterSave) {
            if (this.saving || !this.validateEntry(lockAfterSave)) return;
            var self = this;
            self.saving = true;
            var body = new URLSearchParams();
            body.append('id', self.entry.id || 0);
            body.append('register_date', self.entry.register_date);
            body.append('opening_balance', self.entry.opening_balance == null ? '' : self.entry.opening_balance);
            body.append('cash_sales', self.entry.cash_sales || 0);
            body.append('pos_total', self.entry.pos_total || 0);
            body.append('bank_withdrawal', self.entry.bank_withdrawal || 0);
            body.append('misc_expenses', self.entry.misc_expenses || 0);
            body.append('paid_to_suppliers', self.entry.paid_to_suppliers || 0);
            body.append('cash_deposit_to_bank', self.entry.cash_deposit_to_bank || 0);
            body.append('bank_opening_balance', self.entry.bank_opening_balance == null ? '' : self.entry.bank_opening_balance);
            body.append('bank_deposit', self.entry.bank_deposit || 0);
            body.append('bank_expenses', self.entry.bank_expenses || 0);
            body.append('actual_closing_cash', self.entry.actual_closing_cash == null ? '' : self.entry.actual_closing_cash);
            body.append('actual_closing_bank', self.entry.actual_closing_bank == null ? '' : self.entry.actual_closing_bank);
            body.append('difference_reason', self.entry.difference_reason || '');
            body.append('bank_difference_reason', self.entry.bank_difference_reason || '');
            body.append('lock_after_save', lockAfterSave ? 'true' : 'false');
            body.append('note', self.entry.note || '');
            fetch(API_BASE + 'save_entry', { method: 'POST', body: body })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.saving = false;
                    if (Api.isOk(res)) {
                        self.hideEntryModal();
                        self.selectedRow = -1;
                        self.edit_row_data = {};
                        self.fetchData();
                        Swal.fire({ icon: 'success', title: 'تم', text: res.mess || 'تم حفظ اليومية', timer: 1800, showConfirmButton: false });
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.saving = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        confirmClose: function () {
            if (!this.validateEntry(true)) return;
            var self = this;
            var balancesHtml = self.isSeparated
                ? '<div class="text-end">'
                    + '<strong>الكاش:</strong> متوقع ' + self.fmt(self.closingBalance)
                    + '، فعلي ' + self.fmt(self.entry.actual_closing_cash)
                    + '، فرق ' + self.fmt(self.cashDifference) + '<br>'
                    + '<strong>البنك:</strong> متوقع ' + self.fmt(self.bankClosingBalance)
                    + '، فعلي ' + self.fmt(self.entry.actual_closing_bank)
                    + '، فرق ' + self.fmt(self.bankDifference) + '<br>'
                    + '<strong>الشبكة ضمن البنك:</strong> إجمالي ' + self.fmt(self.entry.pos_total)
                    + '، رسوم ' + self.fmt(self.posFee)
                    + '، صافي ' + self.fmt(self.posNetToBank) + '</div>'
                : 'المتوقع: <strong>' + self.fmt(self.closingBalance) + '</strong> ر.س<br>'
                    + 'الفعلي: <strong>' + self.fmt(self.entry.actual_closing_cash) + '</strong> ر.س<br>'
                    + 'الفرق: <strong>' + self.fmt(self.cashDifference) + '</strong> ر.س<br>';
            Swal.fire({
                title: 'إقفال اليومية؟',
                html: balancesHtml
                    + '<hr class="my-2">صافي مبيعات الأسر: <strong>' + self.fmt(self.familySummary.net_sales) + '</strong> ر.س<br>'
                    + 'حصة المتجر: <strong>' + self.fmt(self.familySummary.commission_amount) + '</strong> ر.س',
                icon: (self.hasCashDifference || self.hasBankDifference) ? 'warning' : 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم، احفظ وأقفل',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#0f766e'
            }).then(function (result) {
                if (result.isConfirmed) self.save_entry(true);
            });
        },
        reopen_entry_click: function () {
            var self = this;
            Swal.fire({
                // داخل نافذة اليومية؛ وإلا يمنع حبس التركيز في Bootstrap الكتابة في مربع السبب
                target: document.getElementById('entryModal'),
                title: 'إعادة فتح اليومية',
                input: 'textarea',
                inputLabel: 'سبب إعادة الفتح',
                inputPlaceholder: 'اكتب سببًا واضحًا يمكن مراجعته لاحقًا',
                inputAttributes: { 'aria-label': 'سبب إعادة فتح اليومية' },
                showCancelButton: true,
                confirmButtonText: 'إعادة الفتح',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b7791f',
                inputValidator: function (value) {
                    if (!String(value || '').trim()) return 'سبب إعادة الفتح مطلوب';
                }
            }).then(function (result) {
                if (!result.isConfirmed) return;
                self.saving = true;
                var body = new URLSearchParams();
                body.append('id', self.entry.id);
                body.append('reopen_reason', String(result.value || '').trim());
                fetch(API_BASE + 'reopen_entry', { method: 'POST', body: body })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        self.saving = false;
                        if (Api.isOk(res)) {
                            self.hideEntryModal();
                            self.fetchData();
                            Swal.fire({ icon: 'success', title: 'تمت إعادة الفتح', timer: 1600, showConfirmButton: false });
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () {
                        self.saving = false;
                        Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                    });
            });
        },
        delete_entry_click: function () {
            if (this.selectedRow === -1 || this.edit_row_data.locked) return;
            var self = this;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'سيتم حذف يومية ' + self.edit_row_data.register_date + ' نهائيًا. هل أنت متأكد؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b42318'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                fetch(API_BASE + 'delete_entry?id=' + encodeURIComponent(self.edit_row_data.id), { method: 'POST' })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        if (Api.isOk(res)) {
                            self.selectedRow = -1;
                            self.edit_row_data = {};
                            self.fetchData();
                            Swal.fire({ icon: 'success', title: 'تم الحذف', timer: 1500, showConfirmButton: false });
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
            });
        },
        printList: function () {
            window.print();
        },
        exportCsv: function () {
            var headers = [
                'التاريخ', 'الحالة', 'النمط', 'افتتاحي الكاش', 'مبيعات الكاش', 'مبيعات الشبكة',
                'سحب البنك إلى الكاش', 'مصروفات الكاش', 'سداد الكاش', 'إيداع الكاش في البنك',
                'إقفال الكاش المتوقع', 'الكاش الفعلي', 'فرق الكاش',
                'افتتاحي البنك', 'وارد بنكي', 'سداد البنك', 'مصروفات البنك',
                'إقفال البنك المتوقع', 'البنك الفعلي', 'فرق البنك',
                'رسوم الشبكة (8 لكل ألف)', 'صافي الشبكة الداخل للبنك',
                'إجمالي المسدد', 'صافي بعد المسدد', 'المستلم من الأسر',
                'المرتجع للأسر', 'صافي مبيعات الأسر', 'متوسط نسبة المتجر %', 'حصة المتجر من الأسر',
                'صافي مبلغ الأسر', 'الملاحظات'
            ];
            var lines = [headers];
            for (var i = 0; i < this.data.length; i++) {
                var row = this.data[i];
                lines.push([
                    row.register_date, row.locked ? 'مقفل' : 'مفتوح', row.separated_accounts ? 'منفصل' : 'قديم',
                    row.opening_balance, row.cash_sales, row.pos_total, row.bank_withdrawal,
                    row.misc_expenses, row.cash_paid_to_suppliers, row.cash_deposit_to_bank,
                    row.closing_balance, row.actual_closing_cash, row.cash_difference,
                    row.bank_opening_balance, row.bank_deposit, row.bank_paid_to_suppliers, row.bank_expenses,
                    row.bank_closing_balance, row.actual_closing_bank, row.bank_difference,
                    row.pos_fees, row.pos_net_to_bank, row.paid_to_suppliers, row.net_sales,
                    row.family_received, row.family_returned, row.family_net_sales, row.family_commission_rate,
                    row.family_commission_amount, row.family_net_amount, row.note || ''
                ]);
            }
            var csv = lines.map(function (line) {
                return line.map(function (value) {
                    var text = value == null ? '' : String(value);
                    return '"' + text.replace(/"/g, '""') + '"';
                }).join(',');
            }).join('\r\n');
            var blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(blob);
            var link = document.createElement('a');
            link.href = url;
            link.download = 'cashbox-' + localDateString() + '.csv';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }
    }
});
