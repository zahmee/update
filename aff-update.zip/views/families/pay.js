var API_BASE = window.location.origin + window.location.pathname.replace(/\/families\/pay(\.js)?(\/\d+)?\/?$/, '/families_api/');

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data_row_count: 0,
        total_amount: 0,
        selectedRow: -1,
        edit_row_data: {},
        getData: { page: 0, RecordCount: 20, date_from: '', date_to: '' },
        refs: { payment_methods: [], payment_types: [] },
        canAdd: CAN_ADD,
        canEdit: CAN_EDIT,
        canDelete: CAN_DELETE
    },
    computed: {
        totalPages: function () {
            if (this.data_row_count <= 0) return 1;
            return Math.ceil(this.data_row_count / this.getData.RecordCount);
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var currentPage = this.getData.page + 1;
            var totalPages = this.totalPages;
            var range = [];
            var delta = 2;
            var l = -1;
            for (var i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
                    if (l !== -1 && i - l > 1) range.push('...');
                    range.push(i);
                    l = i;
                }
            }
            return range;
        }
    },
    created: function () {
        this.get_refs();
        this.fetchData();
    },
    methods: {
        fmt: function (x) { return parseFloat(x || 0).toFixed(2); },
        get_refs: function () {
            var self = this;
            fetch(API_BASE + 'get_refs')
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) self.refs = res.data;
                })
                .catch(function () { });
        },
        fetchData: function () {
            var self = this;
            var params = {
                family_id: FAMILY_ID,
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                date_from: this.getData.date_from,
                date_to: this.getData.date_to
            };
            fetch(API_BASE + 'get_family_pays?' + new URLSearchParams(params).toString())
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        self.data = res.data || [];
                        self.data_row_count = res.count || 0;
                        self.total_amount = res.total_amount || 0;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.fetchData();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.fetchData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = row;
        },
        new_pay_click: function () {
            this.selectedRow = -1;
            this.edit_row_data = {
                id: 0,
                amount: '',
                pay_date: new Date().toISOString().slice(0, 10),
                pay_time: new Date().toTimeString().slice(0, 5),
                payment_method: 0,
                payment_type: 0,
                pay_note: '',
                note: ''
            };
        },
        edit_pay_click: function () {
            if (this.selectedRow === -1) return;
            this.edit_row_data = Object.assign({}, this.data[this.selectedRow]);
        },
        save_pay_data: function () {
            var self = this;
            var amount = parseFloat(this.edit_row_data.amount || 0);
            if (!(amount > 0)) {
                Swal.fire('تنبيه', 'أدخل مبلغاً صحيحاً أكبر من صفر', 'warning');
                return;
            }
            var qs = new URLSearchParams();
            var url;
            if (this.edit_row_data.id) {
                url = 'edit_family_pay';
                qs.append('id', this.edit_row_data.id);
                qs.append('amount', amount);
                qs.append('pay_note', this.edit_row_data.pay_note || '');
                qs.append('pay_time', this.edit_row_data.pay_time || '');
                qs.append('payment_method', this.edit_row_data.payment_method || 0);
                qs.append('payment_type', this.edit_row_data.payment_type || 0);
            } else {
                url = 'save_family_pay';
                qs.append('family', FAMILY_ID);
                qs.append('amount', amount);
                qs.append('pay_date', this.edit_row_data.pay_date || '');
                qs.append('pay_time', this.edit_row_data.pay_time || '');
                qs.append('payment_method', this.edit_row_data.payment_method || 0);
                qs.append('payment_type', this.edit_row_data.payment_type || 0);
                qs.append('pay_note', this.edit_row_data.pay_note || '');
                qs.append('note', this.edit_row_data.note || '');
            }
            fetch(API_BASE + url + '?' + qs.toString(), { method: 'POST' })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        bootstrap.Modal.getInstance(document.getElementById('payModal')).hide();
                        self.fetchData();
                        Swal.fire('تم', 'تم حفظ البيانات بنجاح', 'success');
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        delete_pay_click: function () {
            if (this.selectedRow === -1) return;
            var self = this;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف هذا السداد؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b42318'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                fetch(API_BASE + 'delete_family_pay?id=' + self.edit_row_data.id, { method: 'POST' })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        if (Api.isOk(res)) {
                            self.selectedRow = -1;
                            self.fetchData();
                            Swal.fire('تم', 'تم حذف السداد بنجاح', 'success');
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
            });
        }
    }
});
