var API_BASE = window.location.origin + window.location.pathname.replace(/\/families\/index(\.js)?\/?$/, '/families_api/');

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data_row_count: 0,
        loading: false,
        selectedRow: -1,
        new_row: true,
        edit_row_data: {},
        getData: { page: 0, RecordCount: 20, SearchText: '', SortBy: 'id', sortAsc: false, kind: '' },
        canAdd: CAN_ADD,
        canEdit: CAN_EDIT,
        canDelete: CAN_DELETE,
        _searchTimer: null
    },
    computed: {
        totalFor: function () {
            var total = 0;
            for (var i = 0; i < this.data.length; i++) total += parseFloat(this.data[i].prev_bal_for || 0);
            return total.toFixed(2);
        },
        totalOn: function () {
            var total = 0;
            for (var i = 0; i < this.data.length; i++) total += parseFloat(this.data[i].prev_bal_on || 0);
            return total.toFixed(2);
        },
        totalPages: function () {
            if (this.data_row_count <= 0) return 1;
            return Math.ceil(this.data_row_count / this.getData.RecordCount);
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var currentPage = this.getData.page + 1;
            var totalPages = this.totalPages;
            var range = [];
            var delta = 2;
            var l = -1;
            for (var i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
                    if (l !== -1 && i - l > 1) range.push('...');
                    range.push(i);
                    l = i;
                }
            }
            return range;
        }
    },
    created: function () {
        this.fetchData();
    },
    methods: {
        fmt: function (x) { return parseFloat(x || 0).toFixed(2); },
        fetchData: function () {
            var self = this;
            self.loading = true;
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                SortBy: this.getData.SortBy,
                sequence: this.getData.sortAsc ? 'true' : 'false',
                kind: this.getData.kind
            };
            fetch(API_BASE + 'get_parties?' + new URLSearchParams(params).toString())
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.data = res.data || [];
                        self.data_row_count = res.count || 0;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        debouncedSearch: function () {
            var self = this;
            clearTimeout(this._searchTimer);
            this._searchTimer = setTimeout(function () { self.onChange(); }, 400);
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.fetchData();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.fetchData();
        },
        sortBy: function (col) {
            if (this.getData.SortBy === col) {
                this.getData.sortAsc = !this.getData.sortAsc;
            } else {
                this.getData.SortBy = col;
                this.getData.sortAsc = true;
            }
            this.onChange();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.new_row = false;
            this.edit_row_data = row;
        },
        new_row_click: function () {
            this.selectedRow = -1;
            this.new_row = true;
            this.edit_row_data = {
                id: 0,
                kind: 'family',
                name: '',
                reg_date: new Date().toISOString().slice(0, 10),
                mobile: '',
                prev_bal_for: '',
                prev_bal_on: '',
                sale_percent: ''
            };
        },
        edit_row: function () {
            if (this.selectedRow === -1) return;
            this.new_row = false;
            this.edit_row_data = Object.assign({}, this.data[this.selectedRow]);
        },
        cancel_data: function () {
            this.selectedRow = -1;
        },
        save_data: function () {
            var self = this;
            if (!this.edit_row_data.name || String(this.edit_row_data.name).trim() === '') {
                Swal.fire('تنبيه', 'الاسم مطلوب', 'warning');
                return;
            }
            if (this.edit_row_data.mobile && !/^05\d{8}$/.test(String(this.edit_row_data.mobile))) {
                Swal.fire('تنبيه', 'رقم الجوال يجب أن يبدأ بـ 05 ويتكون من 10 أرقام', 'warning');
                return;
            }
            var balFor = parseFloat(this.edit_row_data.prev_bal_for || 0);
            var balOn = parseFloat(this.edit_row_data.prev_bal_on || 0);
            if (isNaN(balFor) || balFor < 0 || isNaN(balOn) || balOn < 0) {
                Swal.fire('تنبيه', 'الرصيد السابق يجب أن يكون صفراً أو أكثر', 'warning');
                return;
            }
            var percent = parseFloat(this.edit_row_data.sale_percent || 0);
            if (isNaN(percent) || percent < 0 || percent > 100) {
                Swal.fire('تنبيه', 'النسبة يجب أن تكون بين 0 و 100', 'warning');
                return;
            }
            var fields = ['id', 'kind', 'name', 'reg_date', 'mobile', 'prev_bal_for', 'prev_bal_on', 'sale_percent'];
            var qs = new URLSearchParams();
            fields.forEach(function (f) { qs.append(f, self.edit_row_data[f] == null ? '' : self.edit_row_data[f]); });
            fetch(API_BASE + 'save_party?' + qs.toString(), { method: 'POST' })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        bootstrap.Modal.getInstance(document.getElementById('partyModal')).hide();
                        self.selectedRow = -1;
                        self.fetchData();
                        Swal.fire('تم', 'تم حفظ البيانات بنجاح', 'success');
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        toggle_stop: function () {
            if (this.selectedRow === -1) return;
            var self = this;
            var isStoped = !!this.edit_row_data.stoped;
            Swal.fire({
                title: 'تأكيد',
                text: isStoped ? 'هل تريد فتح هذا السجل؟' : 'هل تريد قفل هذا السجل؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم',
                cancelButtonText: 'لا'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                var qs = new URLSearchParams();
                qs.append('id', self.edit_row_data.id);
                qs.append('kind', self.edit_row_data.kind);
                fetch(API_BASE + 'toggle_party_stop?' + qs.toString(), { method: 'POST' })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        if (Api.isOk(res)) {
                            var newVal = !isStoped;
                            self.edit_row_data.stoped = newVal;
                            if (self.selectedRow > -1 && self.data[self.selectedRow]) {
                                self.data[self.selectedRow].stoped = newVal;
                            }
                            Swal.fire('تم', newVal ? 'تم قفل السجل' : 'تم فتح السجل', 'success');
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
            });
        }
    }
});
