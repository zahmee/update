Vue.component('v-select', VueSelect.VueSelect);

var API_BASE = window.location.origin + window.location.pathname.replace(/\/families\/settlement(\.js)?\/?$/, '/families_api/');

function todayStr() {
    return new Date().toISOString().slice(0, 10);
}

var app = new Vue({
    el: '#app',
    data: {
        loading: false,
        refs: { families: [] },
        filters: {
            family: null,
            date_from: '',
            date_to: todayStr()
        },
        result: null
    },
    computed: {
        s: function () {
            return (this.result && this.result.summary) || {};
        },
        hasResult: function () {
            return !!this.result;
        },
        periodLabel: function () {
            if (!this.result) return '';
            var r = this.result.range || {};
            if (!r.limited_period) return 'كل الحركة حتى الآن';
            return 'الفترة من ' + (r.date_from || 'البداية') + ' إلى ' + (r.date_to || 'اليوم');
        }
    },
    created: function () {
        this.get_refs();
    },
    methods: {
        fmt: function (x) { return parseFloat(x || 0).toFixed(2); },
        get_refs: function () {
            var self = this;
            fetch(API_BASE + 'settlement_refs')
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) self.refs = res.data || { families: [] };
                })
                .catch(function () { });
        },
        run: function () {
            var self = this;
            if (!this.filters.family) {
                Swal.fire('تنبيه', 'اختر الأسرة أولاً', 'warning');
                return;
            }
            self.loading = true;
            var params = {
                family_id: this.filters.family.id,
                date_from: this.filters.date_from || '',
                date_to: this.filters.date_to || ''
            };
            fetch(API_BASE + 'family_settlement?' + new URLSearchParams(params).toString())
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.result = res.data || null;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        clearDates: function () {
            this.filters.date_from = '';
            this.filters.date_to = '';
        },
        printPage: function () {
            window.print();
        }
    }
});
