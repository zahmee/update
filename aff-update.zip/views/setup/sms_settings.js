var app = new Vue({
    el: '#app',
    data: {
        saving: false,
        checking: false,
        credentialsOk: true,
        balance: { checked: false, ok: null, credits: null, expiry: '' },
        form: emptyForm(),
        original: emptyForm(),
        // العناصر النائبة المتاحة في الصيغ
        tokens: [
            { k: '{name}', ar: 'الاسم' },
            { k: '{amount}', ar: 'المبلغ' },
            { k: '{date}', ar: 'التاريخ' },
            { k: '{doc}', ar: 'رقم السند' },
            { k: '{org}', ar: 'اسم الجهة' }
        ]
    },
    computed: {
        // هل توجد تغييرات غير محفوظة؟
        dirty: function () {
            return JSON.stringify(this.form) !== JSON.stringify(this.original);
        }
    },
    mounted: function () {
        var d = window.SMS_DATA || {};
        this.credentialsOk = d.credentials_ok !== false;
        var loaded = {
            enabled: !!d.enabled,
            on_receipt: !!d.on_receipt,
            on_return: !!d.on_return,
            on_payment: !!d.on_payment,
            tpl_receipt: d.tpl_receipt || '',
            tpl_return: d.tpl_return || '',
            tpl_payment: d.tpl_payment || ''
        };
        this.form = loaded;
        this.original = clone(loaded);
    },
    methods: {
        // إدراج عنصر نائب عند موضع المؤشر في الصيغة المحددة
        insert: function (field, token) {
            var el = this.$refs[field];
            var cur = this.form[field] || '';
            if (el && typeof el.selectionStart === 'number') {
                var s = el.selectionStart, e = el.selectionEnd;
                this.form[field] = cur.slice(0, s) + token + cur.slice(e);
                this.$nextTick(function () {
                    el.focus();
                    var pos = s + token.length;
                    el.setSelectionRange(pos, pos);
                });
            } else {
                this.form[field] = cur + token;
            }
        },
        // التحقق قبل الإرسال: صيغة الحدث المُفعّل يجب ألا تكون فارغة
        validate: function () {
            if (!this.form.enabled) { return true; }
            var f = this.form, bad = [];
            if (f.on_receipt && !String(f.tpl_receipt).trim()) { bad.push('الاستلام'); }
            if (f.on_return && !String(f.tpl_return).trim()) { bad.push('المرتجع'); }
            if (f.on_payment && !String(f.tpl_payment).trim()) { bad.push('السداد'); }
            if (bad.length) {
                Swal.fire('تنبيه', 'يرجى إدخال صيغة الرسالة لـ: ' + bad.join('، '), 'warning');
                return false;
            }
            return true;
        },
        reset: function () {
            this.form = clone(this.original);
        },
        // فحص اتصال/رصيد المزوّد (قراءة فقط)
        checkBalance: function () {
            var self = this;
            self.checking = true;
            Api.get(window.SMS_URLS.balance).then(function (res) {
                if (Api.isOk(res)) {
                    var d = Api.getData(res) || {};
                    self.balance = { checked: true, ok: true, credits: d.credits, expiry: d.expiryDate || '' };
                } else {
                    self.balance = { checked: true, ok: false, credits: null, expiry: '' };
                    Api.showError(res);
                }
            }).finally(function () { self.checking = false; });
        },
        save: function () {
            var self = this;
            if (!self.validate()) { return; }
            var f = self.form;
            var body = new FormData();
            body.append('enabled', f.enabled ? '1' : '0');
            body.append('on_receipt', f.on_receipt ? '1' : '0');
            body.append('on_return', f.on_return ? '1' : '0');
            body.append('on_payment', f.on_payment ? '1' : '0');
            body.append('tpl_receipt', f.tpl_receipt || '');
            body.append('tpl_return', f.tpl_return || '');
            body.append('tpl_payment', f.tpl_payment || '');

            self.saving = true;
            Api.post(window.SMS_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    self.original = clone(self.form);
                    Api.showSuccess(res.mess || 'تم حفظ الإعدادات بنجاح');
                } else {
                    Api.showError(res);
                }
            }).finally(function () {
                self.saving = false;
            });
        }
    }
});

function emptyForm() {
    return {
        enabled: false,
        on_receipt: false,
        on_return: false,
        on_payment: false,
        tpl_receipt: '',
        tpl_return: '',
        tpl_payment: ''
    };
}

function clone(o) {
    return JSON.parse(JSON.stringify(o));
}
