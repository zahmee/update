var app = mountVueApp({
    el: '#app',
    data: {
        info: { config: [], templates: [], send_ok: false, webhook_url: '' },
        form: emptyForm(),
        original: emptyForm(),
        saving: false,
        checking: false,
        phone: { data: null, error: '' },
        templates: [],
        tplLoading: false,
        tplError: '',
        submitting: '',
        sub: { checked: false, subscribed: false, text: '' },
        subLoading: false,
        testMobile: '',
        testing: false,
        testResult: { ok: null, text: '' }
    },
    computed: {
        // هل توجد تغييرات غير محفوظة؟
        dirty: function () {
            return JSON.stringify(this.form) !== JSON.stringify(this.original);
        }
    },
    mounted: function () {
        var d = window.WA_DATA || {};
        this.info = d;
        var loaded = {
            enabled: !!d.enabled,
            on_receipt: !!d.on_receipt,
            on_return: !!d.on_return,
            on_payment: !!d.on_payment
        };
        this.form = loaded;
        this.original = clone(loaded);
        // نص القوالب معروف محلياً؛ حالتها لدى ميتا تُجلب عند توفر بيانات الربط
        this.templates = (d.templates || []).map(function (t) {
            return Object.assign({ status: '', rejected_reason: '' }, t);
        });
        if (this.configOk('token') && this.configOk('waba_id')) {
            this.loadTemplates();
            this.loadSubscription();
        }
    },
    methods: {
        configOk: function (key) {
            return (this.info.config || []).some(function (k) { return k.key === key && k.ok; });
        },
        qualityName: function (v) {
            return { GREEN: 'عالية', YELLOW: 'متوسطة', RED: 'منخفضة' }[v] || 'غير محددة';
        },
        platformName: function (v) {
            return { CLOUD_API: 'الواجهة السحابية', ON_PREMISE: 'خادم محلي', NOT_APPLICABLE: 'غير مفعّل' }[v] || (v || '-');
        },
        statusChip: function (s) {
            var map = {
                APPROVED: { text: 'معتمد', cls: 'chip-ok' },
                PENDING: { text: 'قيد المراجعة', cls: 'chip-wait' },
                IN_APPEAL: { text: 'قيد الاعتراض', cls: 'chip-wait' },
                REJECTED: { text: 'مرفوض', cls: 'chip-bad' },
                PAUSED: { text: 'موقوف مؤقتاً', cls: 'chip-bad' },
                DISABLED: { text: 'معطّل', cls: 'chip-bad' },
                MISSING: { text: 'غير مقدَّم', cls: 'chip-none' }
            };
            return map[s] || { text: s, cls: 'chip-none' };
        },
        checkConnection: function () {
            var self = this;
            self.checking = true;
            self.phone = { data: null, error: '' };
            Api.get(window.WA_URLS.check).then(function (res) {
                if (Api.isOk(res)) {
                    self.phone = { data: Api.getData(res) || {}, error: '' };
                } else {
                    self.phone = { data: null, error: Api.getError(res) };
                }
            }).finally(function () { self.checking = false; });
        },
        loadTemplates: function () {
            var self = this;
            self.tplLoading = true;
            self.tplError = '';
            Api.get(window.WA_URLS.templates).then(function (res) {
                if (Api.isOk(res)) {
                    self.templates = Api.getData(res) || [];
                } else {
                    self.tplError = Api.getError(res);
                }
            }).finally(function () { self.tplLoading = false; });
        },
        submitTemplate: function (t) {
            var self = this;
            Swal.fire({
                title: 'تقديم القالب للمراجعة',
                text: 'سيُرسل نص القالب «' + t.title + '» إلى ميتا للمراجعة. متابعة؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'تقديم',
                cancelButtonText: 'إلغاء'
            }).then(function (result) {
                if (!result.isConfirmed) { return; }
                var body = new FormData();
                body.append('key', t.key);
                self.submitting = t.key;
                Api.post(window.WA_URLS.submit, body).then(function (res) {
                    if (Api.isOk(res)) {
                        Api.showSuccess(res.mess);
                        self.loadTemplates();
                    } else {
                        Api.showError(res);
                    }
                }).finally(function () { self.submitting = ''; });
            });
        },
        loadSubscription: function () {
            var self = this;
            self.subLoading = true;
            Api.get(window.WA_URLS.subscription).then(function (res) {
                if (Api.isOk(res)) {
                    var d = Api.getData(res) || {};
                    self.sub = {
                        checked: true,
                        subscribed: !!d.subscribed,
                        text: d.subscribed
                            ? 'التطبيق مشترك في إشعارات الحساب: ' + (d.apps || []).join('، ')
                            : 'التطبيق غير مشترك، فلن تصل حالات الرسائل ولا الردود'
                    };
                } else {
                    self.sub = { checked: false, subscribed: false, text: Api.getError(res) };
                }
            }).finally(function () { self.subLoading = false; });
        },
        subscribe: function () {
            var self = this;
            self.subLoading = true;
            Api.post(window.WA_URLS.subscribe, new FormData()).then(function (res) {
                if (Api.isOk(res)) {
                    Api.showSuccess(res.mess);
                    self.loadSubscription();
                } else {
                    Api.showError(res);
                    self.subLoading = false;
                }
            });
        },
        copyUrl: function (url) {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(url).then(function () { Api.showSuccess('تم نسخ الرابط'); });
            } else {
                Swal.fire({ title: 'انسخ الرابط', input: 'text', inputValue: url, inputAttributes: { dir: 'ltr', readonly: true } });
            }
        },
        sendTest: function () {
            var self = this;
            if (!/^05\d{8}$/.test(self.testMobile)) {
                Swal.fire('تنبيه', 'رقم الجوال يجب أن يبدأ بـ 05 ويتكون من 10 أرقام', 'warning');
                return;
            }
            var body = new FormData();
            body.append('mobile', self.testMobile);
            self.testing = true;
            self.testResult = { ok: null, text: '' };
            Api.post(window.WA_URLS.test, body).then(function (res) {
                self.testResult = Api.isOk(res)
                    ? { ok: true, text: 'قبلت ميتا الرسالة، وتظهر حالة وصولها في سجل واتساب.' }
                    : { ok: false, text: Api.getError(res) };
            }).finally(function () { self.testing = false; });
        },
        reset: function () {
            this.form = clone(this.original);
        },
        save: function () {
            var self = this;
            var f = self.form;
            var body = new FormData();
            body.append('enabled', f.enabled ? '1' : '0');
            body.append('on_receipt', f.on_receipt ? '1' : '0');
            body.append('on_return', f.on_return ? '1' : '0');
            body.append('on_payment', f.on_payment ? '1' : '0');
            self.saving = true;
            Api.post(window.WA_URLS.save, body).then(function (res) {
                if (Api.isOk(res)) {
                    self.original = clone(self.form);
                    Api.showSuccess(res.mess || 'تم حفظ الإعدادات بنجاح');
                } else {
                    Api.showError(res);
                }
            }).finally(function () { self.saving = false; });
        }
    }
});

function emptyForm() {
    return { enabled: false, on_receipt: false, on_return: false, on_payment: false };
}

function clone(o) {
    return JSON.parse(JSON.stringify(o));
}
