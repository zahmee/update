var app = new Vue({
    el: '#app',
    data: {
        credentialsOk: true,
        sender: '',
        form: { mobile: '', message: '' },
        search: '',
        results: [],
        showResults: false,
        searching: false,
        chosenName: '',
        sending: false,
        checking: false,
        balance: { checked: false, ok: null, credits: null, expiry: '' },
        _t: null
    },
    computed: {
        charCount: function () { return (this.form.message || '').length; },
        segments: function () {
            var n = this.charCount;
            if (n === 0) return 0;
            return n <= 70 ? 1 : Math.ceil(n / 67);
        }
    },
    mounted: function () {
        var d = window.SMS_SEND_DATA || {};
        this.credentialsOk = d.credentials_ok !== false;
        this.sender = d.sender || '';
    },
    methods: {
        onSearch: function () {
            var self = this;
            var term = (self.search || '').trim();
            if (self._t) { clearTimeout(self._t); }
            if (term.length < 2) { self.results = []; self.showResults = false; return; }
            self.showResults = true;
            self.searching = true;
            self._t = setTimeout(function () {
                Api.get(window.SMS_SEND_URLS.recipients + '?q=' + encodeURIComponent(term))
                    .then(function (res) {
                        self.results = (res && res.data) ? res.data : [];
                    })
                    .finally(function () { self.searching = false; });
            }, 300);
        },
        pick: function (r) {
            this.form.mobile = r.mobile || '';
            this.chosenName = r.label + ': ' + r.name;
            this.search = '';
            this.results = [];
            this.showResults = false;
        },
        clearChosen: function () {
            this.chosenName = '';
            this.form.mobile = '';
        },
        checkBalance: function () {
            var self = this;
            self.checking = true;
            Api.get(window.SMS_SEND_URLS.balance).then(function (res) {
                if (Api.isOk(res)) {
                    var d = Api.getData(res) || {};
                    self.balance = { checked: true, ok: true, credits: d.credits, expiry: d.expiryDate || '' };
                    Swal.fire({
                        icon: 'success',
                        title: 'الحساب فعّال',
                        html: 'الرصيد المتبقٍ: <b>' + d.credits + '</b>' +
                              (d.expiryDate ? '<br>تنتهي الصلاحية: ' + d.expiryDate : ''),
                        confirmButtonText: 'حسناً'
                    });
                } else {
                    self.balance = { checked: true, ok: false, credits: null, expiry: '' };
                    Api.showError(res);
                }
            }).finally(function () { self.checking = false; });
        },
        doSend: function () {
            var self = this;
            var msg = (self.form.message || '').trim();
            var mob = (self.form.mobile || '').trim();
            if (!/^05\d{8}$/.test(mob)) {
                Swal.fire('تنبيه', 'رقم الجوال غير صحيح — بصيغة 05XXXXXXXX', 'warning');
                return;
            }
            if (!msg) {
                Swal.fire('تنبيه', 'يرجى كتابة نص الرسالة', 'warning');
                return;
            }
            Swal.fire({
                title: 'تأكيد الإرسال',
                html: 'إرسال الرسالة إلى <b dir="ltr">' + mob + '</b>؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'إرسال',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#0f766e'
            }).then(function (result) {
                if (!result.value) { return; }
                var body = new FormData();
                body.append('mobile', mob);
                body.append('message', msg);
                self.sending = true;
                Api.post(window.SMS_SEND_URLS.send, body).then(function (res) {
                    if (Api.isOk(res)) {
                        Api.showSuccess(res.mess || 'تم إرسال الرسالة بنجاح');
                        self.form.message = '';
                    } else {
                        Api.showError(res);
                    }
                }).finally(function () { self.sending = false; });
            });
        }
    }
});
