Vue.component('v-select', VueSelect.VueSelect);

var API_BASE = window.location.origin + window.location.pathname.replace(/\/goods\/index(\.js)?\/?$/, '/goods_api/');

function blank_item() {
    return { quantity: 1, price: 0 };
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data_row_count: 0,
        loading: false,
        selectedRow: -1,
        edit_row_data: {},
        getData: { page: 0, RecordCount: 20, SearchText: '', supplier: null, entity: 'all', date_from: '', date_to: '' },
        refs: { payment_methods: [], suppliers: [], families: [], next_no: 1 },
        entry: { id: 0, receipt_no: '', receipt_date: '', receipt_time: '', entity: 'supplier', supplier: null, family: null, payment_method: 0, note: '', items: [] },
        details: { master: {}, items: [] },
        canAdd: CAN_ADD,
        canEdit: CAN_EDIT,
        canDelete: CAN_DELETE,
        _searchTimer: null
    },
    computed: {
        pageTotal: function () {
            var total = 0;
            for (var i = 0; i < this.data.length; i++) total += parseFloat(this.data[i].bill_total || 0);
            return total.toFixed(2);
        },
        entryTotal: function () {
            var total = 0;
            for (var i = 0; i < this.entry.items.length; i++) {
                var it = this.entry.items[i];
                total += (parseFloat(it.quantity) || 0) * (parseFloat(it.price) || 0);
            }
            return total.toFixed(2);
        },
        totalPages: function () {
            if (this.data_row_count <= 0) return 1;
            return Math.ceil(this.data_row_count / this.getData.RecordCount);
        },
        currentPage: function () {
            return this.getData.page + 1;
        },
        visiblePages: function () {
            var currentPage = this.getData.page + 1;
            var totalPages = this.totalPages;
            var range = [];
            var delta = 2;
            var l = -1;
            for (var i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
                    if (l !== -1 && i - l > 1) range.push('...');
                    range.push(i);
                    l = i;
                }
            }
            return range;
        }
    },
    created: function () {
        this.get_refs();
        this.fetchData();
    },
    methods: {
        fmt: function (x) { return parseFloat(x || 0).toFixed(2); },
        row_total: function (it) {
            return ((parseFloat(it.quantity) || 0) * (parseFloat(it.price) || 0)).toFixed(2);
        },
        get_refs: function () {
            var self = this;
            fetch(API_BASE + 'get_refs')
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) self.refs = res.data;
                })
                .catch(function () { });
        },
        fetchData: function () {
            var self = this;
            self.loading = true;
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                SearchText: this.getData.SearchText,
                supplier: this.getData.supplier || '',
                entity: this.getData.entity,
                date_from: this.getData.date_from,
                date_to: this.getData.date_to
            };
            fetch(API_BASE + 'get_receipts?' + new URLSearchParams(params).toString())
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.data = res.data || [];
                        self.data_row_count = res.count || 0;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        debouncedSearch: function () {
            var self = this;
            clearTimeout(this._searchTimer);
            this._searchTimer = setTimeout(function () { self.onChange(); }, 400);
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.fetchData();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.fetchData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
            this.edit_row_data = row;
        },
        cancel_data: function () {
            this.selectedRow = -1;
        },
        add_item: function () {
            this.entry.items.push(blank_item());
        },
        remove_item: function (i) {
            if (this.entry.items.length <= 1) return;
            this.entry.items.splice(i, 1);
        },
        new_receipt: function () {
            this.selectedRow = -1;
            this.entry = {
                id: 0,
                receipt_no: String(this.refs.next_no || ''),
                receipt_date: new Date().toISOString().slice(0, 10),
                receipt_time: new Date().toTimeString().slice(0, 5),
                entity: 'supplier',
                supplier: null,
                family: null,
                payment_method: 0,
                note: '',
                items: [blank_item()]
            };
            bootstrap.Modal.getOrCreateInstance(document.getElementById('receiptModal')).show();
        },
        edit_receipt: function () {
            if (this.selectedRow === -1) return;
            var self = this;
            fetch(API_BASE + 'get_receipt/' + this.edit_row_data.id)
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (!Api.isOk(res)) {
                        Api.showError(res);
                        return;
                    }
                    var m = res.data.master;
                    self.entry = {
                        id: m.id,
                        receipt_no: m.receipt_no,
                        receipt_date: m.receipt_date,
                        receipt_time: m.receipt_time || '',
                        entity: m.supplier ? 'supplier' : 'family',
                        supplier: m.supplier || null,
                        family: m.family || null,
                        payment_method: m.payment_method || 0,
                        note: m.note || '',
                        items: (res.data.items || []).map(function (it) {
                            return {
                                quantity: it.quantity,
                                price: it.price
                            };
                        })
                    };
                    if (!self.entry.items.length) self.entry.items = [blank_item()];
                    bootstrap.Modal.getOrCreateInstance(document.getElementById('receiptModal')).show();
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        show_details: function () {
            if (this.selectedRow === -1) return;
            var self = this;
            self.details = { master: {}, items: [] };
            fetch(API_BASE + 'get_receipt/' + this.edit_row_data.id)
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        self.details = res.data;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        save_receipt: function () {
            var self = this;
            var entityId = this.entry.entity === 'supplier' ? this.entry.supplier : this.entry.family;
            if (!entityId) {
                Swal.fire('تنبيه', this.entry.entity === 'supplier' ? 'اختر المورد' : 'اختر الأسرة', 'warning');
                return;
            }
            var validItems = this.entry.items.filter(function (it) {
                return (parseFloat(it.quantity) || 0) > 0;
            });
            if (!validItems.length) {
                Swal.fire('تنبيه', 'أدخل بنداً واحداً على الأقل بكمية أكبر من صفر', 'warning');
                return;
            }
            var body = new URLSearchParams();
            body.append('id', this.entry.id || 0);
            body.append('receipt_no', this.entry.receipt_no || '');
            body.append('receipt_date', this.entry.receipt_date || '');
            body.append('receipt_time', this.entry.receipt_time || '');
            body.append('supplier', this.entry.entity === 'supplier' ? entityId : '');
            body.append('family', this.entry.entity === 'family' ? entityId : '');
            body.append('payment_method', this.entry.payment_method || 0);
            body.append('note', this.entry.note || '');
            validItems.forEach(function (it) {
                body.append('quantity', it.quantity == null || it.quantity === '' ? 1 : it.quantity);
                body.append('price', it.price == null || it.price === '' ? 0 : it.price);
            });
            fetch(API_BASE + 'save_receipt', { method: 'POST', body: body })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        bootstrap.Modal.getInstance(document.getElementById('receiptModal')).hide();
                        self.get_refs();
                        self.fetchData();
                        Swal.fire('تم', 'تم حفظ السند بنجاح', 'success');
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        delete_receipt: function () {
            if (this.selectedRow === -1) return;
            var self = this;
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'سيتم حذف السند مع جميع أصنافه. هل أنت متأكد؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b42318'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                fetch(API_BASE + 'delete_receipt?id=' + self.edit_row_data.id, { method: 'POST' })
                    .then(function (response) { return response.json(); })
                    .then(function (res) {
                        if (Api.isOk(res)) {
                            self.selectedRow = -1;
                            self.fetchData();
                            Swal.fire('تم', 'تم حذف السند بنجاح', 'success');
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
            });
        }
    }
});
