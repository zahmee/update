var searchTimer = null;

var app = mountVueApp({
    el: '#app',
    data: {
        info: window.WA_DATA || {},
        urls: window.WA_URLS || {},
        tab: 'sent',
        group: '',
        q: '',
        page: 0,
        pageSize: 25,
        count: 0,
        rows: [],
        groups: {},
        loading: false,
        busy: 0,
        groupList: [
            { key: '', text: 'الكل' },
            { key: 'queued', text: 'بانتظار الإرسال' },
            { key: 'failed', text: 'فشلت' },
            { key: 'done', text: 'أُرسلت' }
        ]
    },
    computed: {
        totalPages: function () {
            return Math.max(1, Math.ceil(this.count / this.pageSize));
        }
    },
    created: function () {
        this.fetchData();
    },
    methods: {
        statusInfo: function (s) {
            var map = {
                pending: { text: 'بانتظار الإرسال', cls: 'st-wait' },
                sending: { text: 'قيد الإرسال', cls: 'st-wait' },
                queued: { text: 'لدى البوابة', cls: 'st-wait' },
                accepted: { text: 'قبلتها ميتا', cls: 'st-go' },
                sent: { text: 'أُرسلت', cls: 'st-go' },
                delivered: { text: 'وصلت', cls: 'st-ok' },
                read: { text: 'قُرئت', cls: 'st-read' },
                failed: { text: 'فشلت', cls: 'st-bad' }
            };
            return map[s] || { text: s, cls: 'st-go' };
        },
        fetchData: function () {
            var self = this;
            var params = new URLSearchParams({ page: self.page, q: self.q });
            if (self.tab === 'sent') { params.append('group', self.group); }
            var url = (self.tab === 'sent' ? self.urls.messages : self.urls.inbound) + '?' + params.toString();
            self.loading = true;
            Api.get(url).then(function (res) {
                if (Api.isOk(res)) {
                    self.rows = res.data || [];
                    self.count = res.count || 0;
                    self.pageSize = res.page_size || self.pageSize;
                    if (res.groups) { self.groups = Object.assign({ '': res.groups.all }, res.groups); }
                } else {
                    Api.showError(res);
                }
            }).finally(function () { self.loading = false; });
        },
        switchTab: function (tab) {
            if (this.tab === tab) { return; }
            this.tab = tab;
            this.page = 0;
            this.rows = [];
            this.fetchData();
        },
        setGroup: function (key) {
            this.group = key;
            this.page = 0;
            this.fetchData();
        },
        debouncedSearch: function () {
            var self = this;
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function () {
                self.page = 0;
                self.fetchData();
            }, 400);
        },
        goPage: function (p) {
            if (p < 0 || p >= this.totalPages) { return; }
            this.page = p;
            this.fetchData();
        },
        retry: function (r) {
            var self = this;
            Swal.fire({
                title: 'إعادة الإرسال',
                text: 'إعادة إرسال الرسالة إلى ' + (r.party_name || r.mobile) + '؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'إرسال',
                cancelButtonText: 'إلغاء'
            }).then(function (result) {
                if (!result.isConfirmed) { return; }
                var body = new FormData();
                body.append('id', r.id);
                self.busy = r.id;
                Api.post(self.urls.retry, body).then(function (res) {
                    if (Api.isOk(res)) {
                        Api.showSuccess(res.mess);
                    } else {
                        Api.showError(res);
                    }
                    self.fetchData();
                }).finally(function () { self.busy = 0; });
            });
        }
    }
});
