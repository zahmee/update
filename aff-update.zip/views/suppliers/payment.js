Vue.component('v-select', VueSelect.VueSelect);

var API_BASE = window.location.origin + window.location.pathname.replace(/\/suppliers\/payment(\.js)?\/?$/, '/suppliers_api/');

function blank_entry() {
    return {
        id: 0,
        kind: 'supplier',
        party_id: null,
        amount: '',
        pay_date: new Date().toISOString().slice(0, 10),
        pay_time: new Date().toTimeString().slice(0, 5),
        payment_method: 0,
        payment_type: 0,
        note: ''
    };
}

var app = new Vue({
    el: '#app',
    data: {
        data: [],
        data_row_count: 0,
        total_amount: 0,
        loading: false,
        selectedRow: -1,
        getData: { page: 0, RecordCount: 20, kind: '', party: null, date_from: '', date_to: '' },
        refs: { parties: [], payment_methods: [], payment_types: [] },
        entry: blank_entry(),
        due: null,
        canAdd: CAN_ADD,
        canEdit: CAN_EDIT,
        canDelete: CAN_DELETE
    },
    computed: {
        filterParties: function () {
            var k = this.getData.kind;
            if (!k) return this.refs.parties;
            return this.refs.parties.filter(function (p) { return p.kind === k; });
        },
        entryParties: function () {
            var k = this.entry.kind;
            return this.refs.parties.filter(function (p) { return p.kind === k; });
        },
        pageTotal: function () {
            var total = 0;
            for (var i = 0; i < this.data.length; i++) total += parseFloat(this.data[i].amount || 0);
            return total.toFixed(2);
        },
        totalPages: function () {
            if (this.data_row_count <= 0) return 1;
            return Math.ceil(this.data_row_count / this.getData.RecordCount);
        },
        currentPage: function () { return this.getData.page + 1; },
        visiblePages: function () {
            var currentPage = this.getData.page + 1;
            var totalPages = this.totalPages;
            var range = [];
            var delta = 2;
            var l = -1;
            for (var i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
                    if (l !== -1 && i - l > 1) range.push('...');
                    range.push(i);
                    l = i;
                }
            }
            return range;
        }
    },
    created: function () {
        this.get_refs();
        this.fetchData();
    },
    methods: {
        fmt: function (x) { return parseFloat(x || 0).toFixed(2); },
        get_refs: function () {
            var self = this;
            fetch(API_BASE + 'pay_get_refs')
                .then(function (r) { return r.json(); })
                .then(function (res) { if (Api.isOk(res)) self.refs = res.data; })
                .catch(function () { });
        },
        fetchData: function () {
            var self = this;
            self.loading = true;
            var kind = this.getData.party ? this.getData.party.kind : this.getData.kind;
            var party_id = this.getData.party ? this.getData.party.id : 0;
            var params = {
                page: this.getData.page,
                RecordCount: this.getData.RecordCount,
                kind: kind || '',
                party_id: party_id || 0,
                date_from: this.getData.date_from,
                date_to: this.getData.date_to
            };
            fetch(API_BASE + 'pay_list?' + new URLSearchParams(params).toString())
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.data = res.data || [];
                        self.data_row_count = res.count || 0;
                        self.total_amount = res.total_amount || 0;
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        },
        onChange: function () {
            this.getData.page = 0;
            this.selectedRow = -1;
            this.fetchData();
        },
        onKindFilterChange: function () {
            // تصفية النوع تُلغي اختيار الطرف إن لم يعد مطابقاً
            if (this.getData.party && this.getData.kind && this.getData.party.kind !== this.getData.kind) {
                this.getData.party = null;
            }
            this.onChange();
        },
        goToPage: function (page) {
            if (page === '...' || page < 1 || page > this.totalPages) return;
            this.getData.page = page - 1;
            this.selectedRow = -1;
            this.fetchData();
        },
        rowSelect: function (index, row) {
            this.selectedRow = index;
        },
        new_pay_click: function () {
            this.selectedRow = -1;
            this.entry = blank_entry();
            this.due = null;
        },
        edit_pay_click: function () {
            if (this.selectedRow === -1) return;
            var row = this.data[this.selectedRow];
            this.entry = {
                id: row.id,
                kind: row.kind,
                party_id: row.party_id,
                amount: row.amount,
                pay_date: row.pay_date,
                pay_time: row.pay_time || '',
                payment_method: row.payment_method || 0,
                payment_type: row.payment_type || 0,
                note: row.note || ''
            };
            this.due = null;
            this.onPartyChange();
        },
        onEntryKindChange: function () {
            this.entry.party_id = null;
            this.due = null;
        },
        onPartyChange: function () {
            var self = this;
            this.due = null;
            if (!this.entry.party_id) return;
            var qs = new URLSearchParams({ kind: this.entry.kind, party_id: this.entry.party_id });
            fetch(API_BASE + 'pay_get_due?' + qs.toString())
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        self.due = res.data;
                        // للتسديد الجديد: عبّئ المبلغ بالمستحق إن كان موجباً
                        if (!self.entry.id && self.due.net_due > 0 && (self.entry.amount === '' || !self.entry.amount)) {
                            self.entry.amount = self.due.net_due;
                        }
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { });
        },
        save_pay_data: function () {
            var self = this;
            if (!this.entry.party_id) {
                Swal.fire('تنبيه', this.entry.kind === 'supplier' ? 'اختر المورد' : 'اختر الأسرة', 'warning');
                return;
            }
            var amount = parseFloat(this.entry.amount || 0);
            if (!(amount > 0)) {
                Swal.fire('تنبيه', 'أدخل مبلغاً صحيحاً أكبر من صفر', 'warning');
                return;
            }
            var qs = new URLSearchParams();
            var url;
            if (this.entry.id) {
                url = 'pay_edit';
                qs.append('id', this.entry.id);
                qs.append('kind', this.entry.kind);
            } else {
                url = 'pay_save';
                qs.append('kind', this.entry.kind);
                qs.append('party_id', this.entry.party_id);
            }
            qs.append('amount', amount);
            qs.append('pay_date', this.entry.pay_date || '');
            qs.append('pay_time', this.entry.pay_time || '');
            qs.append('payment_method', this.entry.payment_method || 0);
            qs.append('payment_type', this.entry.payment_type || 0);
            qs.append('note', this.entry.note || '');
            fetch(API_BASE + url + '?' + qs.toString(), { method: 'POST' })
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    if (Api.isOk(res)) {
                        bootstrap.Modal.getInstance(document.getElementById('paymentModal')).hide();
                        self.selectedRow = -1;
                        self.fetchData();
                        Swal.fire({ icon: 'success', title: 'تم حفظ التسديد بنجاح', showConfirmButton: false, timer: 1400 });
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
        },
        delete_pay_click: function () {
            if (this.selectedRow === -1) return;
            var self = this;
            var row = this.data[this.selectedRow];
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف هذا التسديد؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'تراجع',
                confirmButtonColor: '#b42318'
            }).then(function (result) {
                if (!result.isConfirmed) return;
                var qs = new URLSearchParams({ id: row.id, kind: row.kind });
                fetch(API_BASE + 'pay_delete?' + qs.toString(), { method: 'POST' })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        if (Api.isOk(res)) {
                            self.selectedRow = -1;
                            self.fetchData();
                            Swal.fire({ icon: 'success', title: 'تم حذف التسديد', showConfirmButton: false, timer: 1400 });
                        } else {
                            Api.showError(res);
                        }
                    })
                    .catch(function () { Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error'); });
            });
        }
    }
});
