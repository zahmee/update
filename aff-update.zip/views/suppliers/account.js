var API_BASE = window.location.origin + window.location.pathname.replace(/\/suppliers\/account(\.js)?(\/\d+)?\/?$/, '/suppliers_api/');

var app = new Vue({
    el: '#app',
    data: {
        loading: false,
        account: {
            supplier: {},
            received: [],
            returns: [],
            payments: [],
            sum_recv: 0,
            sum_ret: 0,
            sum_pay: 0,
            movement_limit: 100,
            received_count: 0,
            returns_count: 0,
            payments_count: 0,
            balance: 0
        }
    },
    created: function () {
        this.fetchData();
    },
    methods: {
        fmt: function (x) { return parseFloat(x || 0).toFixed(2); },
        fetchData: function () {
            var self = this;
            self.loading = true;
            fetch(API_BASE + 'get_account/' + SUPPLIER_ID)
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    self.loading = false;
                    if (Api.isOk(res)) {
                        self.account = Object.assign({
                            supplier: {},
                            received: [],
                            returns: [],
                            payments: [],
                            sum_recv: 0,
                            sum_ret: 0,
                            sum_pay: 0,
                            movement_limit: 100,
                            received_count: 0,
                            returns_count: 0,
                            payments_count: 0,
                            balance: 0
                        }, res.data || {});
                    } else {
                        Api.showError(res);
                    }
                })
                .catch(function () {
                    self.loading = false;
                    Swal.fire('خطأ', 'حصل خطأ في الاتصال بالسيرفر', 'error');
                });
        }
    }
});
