# -*- coding: utf-8 -*-
"""
ربط واتساب عبر الواجهة الرسمية من ميتا (WhatsApp Cloud API).

وحدة نقية لا تعتمد على web2py: بناء الطلبات، الإرسال، تصنيف الأخطاء، إدارة القوالب،
والتحقق من توقيع الإشعارات الواردة وتفكيكها. منطق قائمة الإرسال والسجل في
models/db_5_whatsapp.py، وبيانات الربط من private/appconfig.ini قسم [whatsapp].

    import whatsapp_cloud as wa
    res = wa.send_template(cfg, "9665XXXXXXXX", "aff_transaction_notice", ["محمد", ...])
    if res["ok"]:
        res["wamid"]
"""
import datetime
import hashlib
import hmac

import httpx

from send_sms import normalize_saudi_mobile

GRAPH_BASE = "https://graph.facebook.com"
DEFAULT_API_VERSION = "v26.0"
TEMPLATE_LANG = "ar"
# الإرسال يجري داخل طلب الحفظ: مهلة اتصال قصيرة، ومهلة قراءة أطول قليلاً.
TIMEOUT = httpx.Timeout(10.0, connect=5.0)

# القوالب التي يحتاجها النظام — المصدر الوحيد لنصّها وترتيب متغيراتها.
# الإرسال يمرّر المتغيرات بهذا الترتيب، وشاشة الإعدادات تقدّم النص نفسه لميتا للمراجعة.
# قيود ميتا: لا يبدأ النص بمتغير ولا ينتهي به، ولا متغيران متجاوران، ونص ثابت كافٍ حولها.
TEMPLATES = {
    "notice": {
        "name": "aff_transaction_notice",
        "category": "UTILITY",
        "title": "إشعار حركة: استلام، مرتجع، سداد",
        "body": (
            "مرحباً {{1}}، نفيدكم بأنه تم تسجيل {{2}} رقم {{3}} في حسابكم لدينا "
            "بمبلغ {{4}} ريال بتاريخ {{5}}. للاستفسار عن هذه العملية يرجى التواصل معنا."
        ),
        "example": ["محمد أحمد", "سند استلام", "1024", "350", "2026-10-03"],
        # مع اسم الفرع: قالب الفرع (يُدرج الاسم متغيراً في موضع at)، وإلى أن تعتمده ميتا يُلحق
        # الاسم بآخر متغير هنا بعد كلمة join
        "branch": {"template": "notice_branch", "at": 2, "join": "في"},
    },
    "statement": {
        "name": "aff_account_statement",
        "category": "UTILITY",
        "title": "كشف الرصيد الصافي",
        "body": (
            "مرحباً {{1}}، نفيدكم بأن صافي رصيد حسابكم لدينا حتى تاريخ {{2}} "
            "هو {{3}} ريال {{4}}. للاستفسار عن تفاصيل الحساب يرجى التواصل معنا."
        ),
        "example": ["محمد أحمد", "2026-10-03", "1250", "مستحقة لكم"],
        # strip: يُحذف من أول آخر متغير في قالب الفرع (ولا توجد مستحقات ← لا توجد مستحقات)
        "branch": {"template": "statement_branch", "at": 1, "join": "لدى", "strip": "و"},
    },
    # قالبا الفرع: منظّمان بسطور ورموز، واسم الفرع فيهما. سطر جديد مسموح في نص القالب فقط، لا في المتغيرات.
    "notice_branch": {
        "name": "aff_branch_transaction_notice",
        "category": "UTILITY",
        "title": "إشعار حركة باسم الفرع",
        "body": (
            "مرحباً {{1}} 👋\n\n"
            "*تم تسجيل {{2}} في حسابكم لدى {{3}}*\n\n"
            "📄 رقم المستند: {{4}}\n"
            "💰 المبلغ: {{5}} ريال\n"
            "📅 التاريخ: {{6}}\n\n"
            "للاستفسار عن هذه العملية يرجى التواصل معنا."
        ),
        "example": ["محمد أحمد", "سند استلام", "فرع تندحة", "1024", "350", "2026-10-06"],
    },
    "statement_branch": {
        "name": "aff_branch_account_statement",
        "category": "UTILITY",
        "title": "كشف الرصيد الصافي باسم الفرع",
        "body": (
            "مرحباً {{1}} 👋\n\n"
            "*ملخص حسابكم لدى {{2}}*\n\n"
            "📅 حتى تاريخ: {{3}}\n"
            "💰 صافي الرصيد: {{4}} ريال ({{5}})\n\n"
            "للاستفسار عن تفاصيل الحساب يرجى التواصل معنا."
        ),
        "example": ["محمد أحمد", "فرع تندحة", "2026-10-06", "1250", "مستحقة لكم"],
    },
}

# أخطاء مؤقتة تستحق إعادة المحاولة لاحقاً (حدود السرعة وتعطّل الخدمة)
RETRYABLE_CODES = {1, 2, 4, 80007, 130429, 131000, 131016, 131056}

ERROR_TEXTS = {
    100: "بيانات الطلب غير صحيحة",
    190: "مفتاح الربط منتهي الصلاحية أو غير صحيح",
    368: "الحساب مقيّد مؤقتاً بسبب مخالفة السياسات",
    80007: "تجاوز حد الطلبات لحساب واتساب للأعمال",
    130429: "تجاوز حد سرعة الإرسال",
    131000: "خطأ مؤقت من ميتا",
    131008: "متغير مطلوب في القالب مفقود",
    131009: "قيمة أحد المتغيرات غير صالحة",
    131016: "خدمة واتساب غير متاحة مؤقتاً",
    131026: "تعذّر توصيل الرسالة لهذا الرقم، وقد لا يكون مسجلاً في واتساب",
    131030: "الرقم غير مضاف لقائمة المستلمين المسموح بها في الحساب التجريبي",
    131031: "حساب واتساب للأعمال مقفل",
    131042: "مشكلة في وسيلة الدفع لحساب واتساب للأعمال",
    131048: "تقييد الإرسال بسبب انخفاض جودة الرقم",
    131049: "لم تُسلَّم الرسالة ضمن حدود ميتا للحفاظ على تجربة المستخدم",
    131050: "العميل أوقف استقبال هذا النوع من الرسائل",
    131056: "رسائل كثيرة لنفس الرقم في وقت قصير",
    132000: "عدد المتغيرات لا يطابق القالب المعتمد",
    132001: "القالب غير موجود أو غير معتمد بالعربية",
    132005: "نص الرسالة بعد التعبئة أطول من المسموح",
    132007: "محتوى المتغيرات يخالف سياسة القوالب",
    132012: "صيغة أحد المتغيرات لا تطابق القالب",
    132015: "القالب موقوف مؤقتاً بسبب انخفاض جودته",
    132016: "القالب معطّل بسبب انخفاض جودته",
    133010: "رقم الإرسال غير مسجّل في الواجهة الرسمية",
}

PHONE_FIELDS = ("display_phone_number", "verified_name", "quality_rating", "platform_type")

# مفاتيح قسم [whatsapp] في appconfig.ini بأسمائها في الواجهة
CONFIG_LABELS = {
    "token": "مفتاح الربط",
    "phone_number_id": "معرّف رقم الإرسال",
    "waba_id": "معرّف حساب واتساب للأعمال",
    "app_secret": "سرّ التطبيق",
    "verify_token": "رمز التحقق لرابط الاستقبال",
}

MEDIA_LABELS = {
    "image": "صورة",
    "video": "فيديو",
    "audio": "رسالة صوتية",
    "document": "مستند",
    "sticker": "ملصق",
    "location": "موقع",
    "contacts": "جهة اتصال",
}


# ======================================================================================
#  تجهيز البيانات
# ======================================================================================
def normalize_msisdn(mobile):
    """رقم سعودي بصيغة الواجهة: أرقام فقط مع رمز الدولة (9665XXXXXXXX)، أو None."""
    number = normalize_saudi_mobile(mobile)
    return number[1:] if number else None


def local_mobile(msisdn):
    """9665XXXXXXXX إلى 05XXXXXXXX (صيغة التخزين في النظام) للمطابقة مع الأسر والموردين."""
    number = normalize_msisdn(msisdn)
    return "0" + number[3:] if number else None


def clean_param(value):
    """ميتا ترفض متغيراً فارغاً، أو فيه سطر جديد أو مسافة جدولة أو مسافات متتالية كثيرة."""
    text = " ".join(str("" if value is None else value).split())
    return text[:200] or "-"


def fmt_amount(value):
    """المبلغ صحيحاً بلا كسور، وإلا بخانتين عشريتين."""
    try:
        number = round(float(value or 0), 2)
    except (TypeError, ValueError):
        return clean_param(value)
    return str(int(number)) if number == int(number) else "%.2f" % number


def render_preview(body, params):
    """نص الرسالة كما سيصل للعميل، لعرضه في السجل."""
    text = body
    for index, value in enumerate(params, 1):
        text = text.replace("{{%d}}" % index, value)
    return text


def compose(key, params, branch="", branch_template=True):
    """القالب والمتغيرات مع اسم الفرع، من متغيرات القالب الأساسي key. يعيد (مفتاح القالب، المتغيرات):
    بلا اسم فرع يبقى القالب كما هو؛ ومع الاسم قالب الفرع إن طُلب، وإلا القالب الأساسي والاسم ملحق
    بآخر متغير (... بتاريخ 2026-10-06 في فرع تندحة)."""
    params = [clean_param(p) for p in params]
    spec = TEMPLATES[key].get("branch")
    branch = " ".join(str(branch or "").split())
    if not branch or not spec:
        return key, params
    if branch_template:
        strip = spec.get("strip")
        if strip and params[-1].startswith(strip):
            params[-1] = params[-1][len(strip):].strip() or params[-1]
        params.insert(spec["at"], clean_param(branch))
        return spec["template"], params
    params[-1] = clean_param("%s %s %s" % (params[-1], spec["join"], branch))
    return key, params


def unbranch(name, params):
    """رسالة بقالب فرع لم تعتمده ميتا بعد: إلى القالب الأساسي واسم الفرع ملحق بآخر متغير.
    يعيد (مفتاح القالب الأساسي، المتغيرات)، أو None إن لم يكن name قالب فرع."""
    for key, tpl in TEMPLATES.items():
        spec = tpl.get("branch")
        if spec and TEMPLATES[spec["template"]]["name"] == name:
            params = list(params or [])
            branch = params.pop(spec["at"])
            return compose(key, params, branch, branch_template=False)
    return None


def template_key(name):
    """مفتاح القالب في TEMPLATES من اسمه لدى ميتا."""
    return next((key for key, tpl in TEMPLATES.items() if tpl["name"] == name), None)


def build_template_payload(to, template, params, lang=TEMPLATE_LANG):
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to,
        "type": "template",
        "template": {"name": template, "language": {"code": lang}},
    }
    if params:
        payload["template"]["components"] = [{
            "type": "body",
            "parameters": [{"type": "text", "text": clean_param(p)} for p in params],
        }]
    return payload


# ======================================================================================
#  الاتصال بواجهة ميتا
# ======================================================================================
def api_root(cfg):
    version = str(cfg.get("api_version") or "").strip() or DEFAULT_API_VERSION
    if not version.startswith("v"):
        version = "v" + version
    base = str(cfg.get("base_url") or "").strip().rstrip("/") or GRAPH_BASE
    return "%s/%s" % (base, version)


def missing_config(cfg, keys=("token", "phone_number_id")):
    """أسماء مفاتيح الإعداد الناقصة من القائمة المطلوبة."""
    return [key for key in keys if not str(cfg.get(key) or "").strip()]


def missing_text(missing):
    """رسالة موحّدة بالمفاتيح الناقصة بأسمائها العربية."""
    return "بيانات ربط واتساب غير مكتملة في ملف إعدادات النظام: %s" % "، ".join(
        CONFIG_LABELS.get(key, key) for key in missing
    )


def describe_error(code, detail=""):
    """وصف عربي للخطأ مع تفاصيل ميتا ورمزه، للعرض في السجل."""
    detail = " ".join(str(detail or "").split())[:300]
    text = " — ".join(part for part in (ERROR_TEXTS.get(code), detail) if part)
    text = text or "خطأ غير معروف"
    return "%s (%s)" % (text, code) if code else text


def _fail(text, retryable=False, code=None, http_status=None):
    return {
        "ok": False,
        "error_code": code,
        "error_text": text,
        "retryable": retryable,
        "http_status": http_status,
    }


def _error_result(http_status, body):
    error = body.get("error") if isinstance(body, dict) else None
    code, detail = None, ""
    if isinstance(error, dict):
        code = error.get("code")
        error_data = error.get("error_data")
        detail = (error_data.get("details") if isinstance(error_data, dict) else "") or error.get("message") or ""
    retryable = http_status >= 500 or http_status == 429 or code in RETRYABLE_CODES
    if not detail and not code:
        detail = "استجابة غير متوقعة من ميتا (HTTP %s)" % http_status
    return _fail(describe_error(code, detail), retryable=retryable, code=code, http_status=http_status)


def _request(cfg, method, path, json_body=None, params=None, transport=None):
    """طلب واحد إلى واجهة ميتا. يعيد dict موحّداً ولا يرفع استثناء."""
    url = "%s/%s" % (api_root(cfg), path.lstrip("/"))
    headers = {"Authorization": "Bearer %s" % str(cfg.get("token") or "").strip()}
    try:
        with httpx.Client(transport=transport, timeout=TIMEOUT) as client:
            resp = client.request(method, url, json=json_body, params=params, headers=headers)
    except (httpx.ConnectError, httpx.ConnectTimeout) as e:
        # الطلب لم يصل إلى ميتا أصلاً: إعادة المحاولة آمنة
        return _fail("تعذّر الاتصال بخوادم ميتا: %s" % e, retryable=True)
    except httpx.HTTPError as e:
        # ربما وصل الطلب وقُبل قبل انقطاع الرد: إعادة المحاولة تلقائياً قد تكرر الرسالة
        return _fail(
            "انقطع الاتصال قبل وصول رد ميتا، وقد تكون الرسالة أُرسلت؛ تحقّق قبل إعادة المحاولة (%s)" % e.__class__.__name__,
        )
    try:
        body = resp.json()
    except ValueError:
        body = None
    if resp.status_code >= 400 or not isinstance(body, dict) or "error" in body:
        return _error_result(resp.status_code, body)
    return {"ok": True, "body": body, "http_status": resp.status_code}


def send_template(cfg, to, template, params, lang=TEMPLATE_LANG, transport=None):
    """إرسال رسالة قالب إلى رقم واحد. يعيد {ok, wamid, error_code, error_text, retryable}."""
    missing = missing_config(cfg)
    if missing:
        return _fail(missing_text(missing))
    res = _request(
        cfg, "POST", "%s/messages" % str(cfg["phone_number_id"]).strip(),
        json_body=build_template_payload(to, template, params, lang), transport=transport,
    )
    if not res["ok"]:
        return res
    messages = res["body"].get("messages") or []
    wamid = messages[0].get("id") if messages and isinstance(messages[0], dict) else None
    if not wamid:
        return _fail("استجابة غير متوقعة من ميتا: لا يوجد معرّف للرسالة", http_status=res["http_status"])
    return {
        "ok": True,
        "wamid": wamid,
        "error_code": None,
        "error_text": None,
        "retryable": False,
        "http_status": res["http_status"],
    }


def get_phone_info(cfg, transport=None):
    """بيانات رقم الإرسال لدى ميتا: الرقم الظاهر، الاسم المعتمد، تقييم الجودة، نوع المنصة."""
    missing = missing_config(cfg)
    if missing:
        return _fail(missing_text(missing))
    res = _request(
        cfg, "GET", str(cfg["phone_number_id"]).strip(),
        params={"fields": ",".join(PHONE_FIELDS)}, transport=transport,
    )
    if not res["ok"]:
        return res
    return {"ok": True, "data": {key: res["body"].get(key) for key in PHONE_FIELDS}}


def template_status(cfg, transport=None):
    """حالة كل قالب يحتاجه النظام لدى ميتا: APPROVED أو PENDING أو REJECTED أو MISSING."""
    missing = missing_config(cfg, ("token", "waba_id"))
    if missing:
        return _fail(missing_text(missing))
    res = _request(
        cfg, "GET", "%s/message_templates" % str(cfg["waba_id"]).strip(),
        params={"fields": "name,status,language,category,rejected_reason", "limit": 200},
        transport=transport,
    )
    if not res["ok"]:
        return res
    found = {
        t.get("name"): t
        for t in res["body"].get("data") or []
        if isinstance(t, dict) and t.get("language") == TEMPLATE_LANG
    }
    data = []
    for key, tpl in TEMPLATES.items():
        remote = found.get(tpl["name"]) or {}
        reason = remote.get("rejected_reason") or ""
        data.append({
            "key": key,
            "name": tpl["name"],
            "title": tpl["title"],
            "body": tpl["body"],
            "category": remote.get("category") or tpl["category"],
            "status": remote.get("status") or "MISSING",
            "rejected_reason": "" if reason == "NONE" else reason,
        })
    return {"ok": True, "data": data}


def create_template(cfg, key, transport=None):
    """تقديم قالب من TEMPLATES لميتا للمراجعة."""
    tpl = TEMPLATES.get(key)
    if not tpl:
        return _fail("قالب غير معروف")
    missing = missing_config(cfg, ("token", "waba_id"))
    if missing:
        return _fail(missing_text(missing))
    payload = {
        "name": tpl["name"],
        "language": TEMPLATE_LANG,
        "category": tpl["category"],
        "components": [{
            "type": "BODY",
            "text": tpl["body"],
            "example": {"body_text": [tpl["example"]]},
        }],
    }
    res = _request(
        cfg, "POST", "%s/message_templates" % str(cfg["waba_id"]).strip(),
        json_body=payload, transport=transport,
    )
    if not res["ok"]:
        return res
    body = res["body"]
    return {"ok": True, "data": {
        "id": body.get("id"),
        "status": body.get("status") or "PENDING",
        "category": body.get("category") or tpl["category"],
    }}


def app_subscription(cfg, transport=None):
    """التطبيقات المشتركة في إشعارات حساب واتساب للأعمال (شرط لوصول الإشعارات)."""
    missing = missing_config(cfg, ("token", "waba_id"))
    if missing:
        return _fail(missing_text(missing))
    res = _request(cfg, "GET", "%s/subscribed_apps" % str(cfg["waba_id"]).strip(), transport=transport)
    if not res["ok"]:
        return res
    apps = [
        (item.get("whatsapp_business_api_data") or {}).get("name") or ""
        for item in res["body"].get("data") or []
        if isinstance(item, dict)
    ]
    return {"ok": True, "data": {"subscribed": bool(apps), "apps": apps}}


def subscribe_app(cfg, transport=None):
    """اشتراك التطبيق صاحب المفتاح في إشعارات حساب واتساب للأعمال."""
    missing = missing_config(cfg, ("token", "waba_id"))
    if missing:
        return _fail(missing_text(missing))
    res = _request(cfg, "POST", "%s/subscribed_apps" % str(cfg["waba_id"]).strip(), transport=transport)
    if not res["ok"]:
        return res
    if not res["body"].get("success"):
        return _fail("لم تؤكد ميتا الاشتراك", http_status=res["http_status"])
    return {"ok": True}


# ======================================================================================
#  الإشعارات الواردة من ميتا (Webhook)
# ======================================================================================
def verify_signature(app_secret, raw_body, header_value):
    """تحقق X-Hub-Signature-256: بصمة HMAC-SHA256 للجسم الخام بسرّ التطبيق."""
    secret = str(app_secret or "").strip()
    signature = str(header_value or "").strip()
    if not secret or not signature.startswith("sha256="):
        return False
    expected = hmac.new(secret.encode("utf-8"), raw_body or b"", hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature[7:].strip().lower())


def _timestamp(value):
    try:
        return datetime.datetime.fromtimestamp(int(value))
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def _message_text(message):
    kind = message.get("type")
    if kind == "text":
        return (message.get("text") or {}).get("body") or ""
    if kind == "button":
        return (message.get("button") or {}).get("text") or ""
    if kind == "interactive":
        interactive = message.get("interactive") or {}
        reply = interactive.get("button_reply") or interactive.get("list_reply") or {}
        return reply.get("title") or ""
    if kind == "reaction":
        return "تفاعل: %s" % ((message.get("reaction") or {}).get("emoji") or "")
    if kind in MEDIA_LABELS:
        media = message.get(kind)
        caption = media.get("caption") if isinstance(media, dict) else ""
        return "[%s]%s" % (MEDIA_LABELS[kind], (" " + caption) if caption else "")
    return "[رسالة غير مدعومة]"


def parse_webhook(payload):
    """تفكيك إشعار ميتا إلى (حالات الرسائل المرسلة، الرسائل الواردة من العملاء)."""
    statuses, inbound = [], []
    if not isinstance(payload, dict) or payload.get("object") != "whatsapp_business_account":
        return statuses, inbound
    for entry in payload.get("entry") or []:
        for change in (entry or {}).get("changes") or []:
            if not isinstance(change, dict) or change.get("field") != "messages":
                continue
            value = change.get("value") or {}
            names = {
                c.get("wa_id"): (c.get("profile") or {}).get("name") or ""
                for c in value.get("contacts") or []
                if isinstance(c, dict)
            }
            for status in value.get("statuses") or []:
                error = (status.get("errors") or [{}])[0] or {}
                error_data = error.get("error_data")
                statuses.append({
                    "wamid": status.get("id"),
                    "status": status.get("status"),
                    "timestamp": _timestamp(status.get("timestamp")),
                    "recipient": status.get("recipient_id"),
                    "error_code": error.get("code"),
                    "error_text": (
                        (error_data.get("details") if isinstance(error_data, dict) else "")
                        or error.get("message") or error.get("title") or ""
                    ),
                })
            for message in value.get("messages") or []:
                sender = message.get("from")
                inbound.append({
                    "wamid": message.get("id"),
                    "from": sender,
                    "name": names.get(sender, ""),
                    "timestamp": _timestamp(message.get("timestamp")),
                    "type": message.get("type") or "",
                    "text": _message_text(message),
                })
    return statuses, inbound
