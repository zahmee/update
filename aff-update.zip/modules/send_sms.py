# -*- coding: utf-8 -*-
"""
خدمة الرسائل النصية (SMS) عبر مزود oursms.com
منقولة من نظام asbab5 مع تحسينات بسيطة (مهلة زمنية + دوال مساعدة).

الاستخدام في أي كنترولر (بيانات الاعتماد متاحة كمتغيرات عامة من models/db.py):

    import send_sms

    # إرسال مباشر (نفس واجهة asbab5)
    p = send_sms.SMS(sms_authorization, sms_sender)
    p.send("+9665xxxxxxxx", "نص الرسالة")

    # إرسال آمن لا يرفع استثناء ويُطبّع الرقم السعودي تلقائياً
    res = send_sms.send_message(sms_authorization, sms_sender, "05xxxxxxxx", "نص الرسالة")
    if res["ok"]:
        ...
"""
import httpx

API_BASE = "https://api.oursms.com"
DEFAULT_TIMEOUT = 15  # ثوانٍ — يمنع تعليق طلب الويب إذا تأخر مزود الرسائل


class SMS:
    def __init__(self, authorization, sender):
        self.sender = sender
        self.Authorization = authorization

    def _headers(self):
        return {"Authorization": "Bearer " + (self.Authorization or "")}

    def getbalance(self) -> str:
        """جلب رصيد الحساب لدى المزود."""
        url = API_BASE + "/billing/credits"
        resp = httpx.get(url, headers=self._headers(), timeout=DEFAULT_TIMEOUT)
        return resp.text

    def send(self, mobile, mess, msg_class="promotional") -> str:
        """إرسال رسالة إلى رقم واحد. يُعيد نص استجابة المزود (JSON نصّي)."""
        data = {
            "src": self.sender,
            "dests": [mobile],
            "body": mess,
            "priority": 0,
            "delay": 0,
            "validity": 0,
            "maxParts": 0,
            "dlr": 0,
            "prevDups": 0,
            "msgClass": msg_class,
        }
        url = API_BASE + "/msgs/sms"
        resp = httpx.post(url, json=data, headers=self._headers(), timeout=DEFAULT_TIMEOUT)
        return resp.text


def normalize_saudi_mobile(mobile):
    """
    يُحوّل رقم جوال سعودي إلى صيغة E.164 المطلوبة من المزود (+9665XXXXXXXX).
    يقبل: 05XXXXXXXX أو 5XXXXXXXX أو 9665XXXXXXXX أو +9665XXXXXXXX.
    يُعيد None إذا كان الرقم غير صالح.
    """
    if not mobile:
        return None
    digits = "".join(ch for ch in str(mobile) if ch.isdigit())
    if digits.startswith("00966"):
        digits = digits[5:]
    elif digits.startswith("966"):
        digits = digits[3:]
    elif digits.startswith("0"):
        digits = digits[1:]
    # الآن يجب أن يكون 5XXXXXXXX (9 خانات تبدأ بـ 5)
    if len(digits) == 9 and digits.startswith("5"):
        return "+966" + digits
    return None


class _SafeDict(dict):
    """يُبقي أي عنصر نائب غير معروف كما هو بدل رفع KeyError."""
    def __missing__(self, key):
        return "{" + key + "}"


def render_template(template, mapping=None, **kwargs):
    """
    يركّب صيغة رسالة عبر استبدال العناصر النائبة {name} {amount} {date} {doc} {org} ...
    آمن: أي عنصر غير مُمرّر يبقى نصّاً كما هو، ولا يرفع استثناء أبداً.

        render_template("عزيزي {name}", name="محمد")  -> "عزيزي محمد"
    """
    data = dict(mapping or {})
    data.update(kwargs)
    data = {k: ("" if v is None else str(v)) for k, v in data.items()}
    try:
        return (template or "").format_map(_SafeDict(data))
    except Exception:
        return template or ""


def send_message(authorization, sender, mobile, message, msg_class="promotional",
                 normalize=True):
    """
    غلاف إرسال آمن: يُطبّع الرقم السعودي (اختيارياً) ولا يرفع استثناء أبداً،
    حتى لا يُسقط فشلُ الرسالة النصية بقيةَ العملية (نفس نمط العزل في asbab5).

    يُعيد dict موحّد: {"ok": bool, "mess": str, "response": str|None}
    """
    target = normalize_saudi_mobile(mobile) if normalize else mobile
    if not target:
        return {"ok": False, "mess": "رقم الجوال غير صالح", "response": None}
    if not authorization or not sender:
        return {"ok": False, "mess": "إعدادات الرسائل النصية غير مكتملة", "response": None}
    try:
        resp = SMS(authorization, sender).send(target, message, msg_class=msg_class)
        return {"ok": True, "mess": "تم إرسال الرسالة", "response": resp}
    except Exception as e:
        return {"ok": False, "mess": "تعذّر إرسال الرسالة النصية: " + str(e), "response": None}
