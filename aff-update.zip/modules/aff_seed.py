# -*- coding: utf-8 -*-
"""
وحدة البيانات الافتتاحية للنظام (Seed)
تُستخدم من:
  - سكربت التهيئة: python web2py.py -S aff -M -R applications/aff/scripts/seed_data.py
  - شاشة الاعدادات: setup/run_seed_data
"""

# شاشات النظام — المصدر الموحد لأكواد الشاشات
SCREENS_CODE = [
    {"systems": 1, "name": "الأسر - استعراض الأسر", "screen_code": 1001},
    {"systems": 1, "name": "الأسر - سدادات الأسرة", "screen_code": 1002},
    {"systems": 1, "name": "الأسر - تصفية أسرة", "screen_code": 1003},
    {"systems": 1, "name": "الموردين - كشف حساب مورد", "screen_code": 2106},
    {"systems": 1, "name": "الموردين والأسر - التسديد الموحّد", "screen_code": 2107},
    {"systems": 1, "name": "البضائع المستلمة - القائمة والادخال", "screen_code": 3001},
    {"systems": 1, "name": "مرتجع البضاعة - القائمة والادخال", "screen_code": 4001},
    {"systems": 1, "name": "الصندوق - يوميات الصندوق", "screen_code": 5001},
    {"systems": 1, "name": "التقارير - التقارير المالية", "screen_code": 6001},
    {"systems": 1, "name": "الإدارة - إعدادات النظام", "screen_code": 9301},
    {"systems": 1, "name": "الإدارة - إدارة المستخدمين والصلاحيات", "screen_code": 9302},
    {"systems": 1, "name": "الرسائل النصية - إرسال يدوي", "screen_code": 9303},
]


def run_seed(db, log=print):
    """تهيئة البيانات الافتتاحية — آمنة للتكرار (لا تكرر السجلات الموجودة)"""
    log("بدء تهيئة البيانات الافتتاحية...")

    # ===================================================================
    # 1) جداول الترميزات الأساسية
    # ===================================================================
    if db(db.key_unit.id > 0).isempty():
        for name in ["قطعة", "علبة", "كرتون", "كيلو", "جرام", "لتر", "شنطة"]:
            db.key_unit.insert(name=name)
        log("  + key_unit")

    if db(db.key_payment_method.id > 0).isempty():
        for name in ["نقدي", "شبكة الكترونية", "آجل", "تحويل في الحساب", "شيك"]:
            db.key_payment_method.insert(name=name)
        log("  + key_payment_method")

    if db(db.key_family_type.id > 0).isempty():
        for name in ["أسرة عامة", "أسر أيتام", "أرامل", "مطلقات", "أسر محتاجة"]:
            db.key_family_type.insert(name=name)
        log("  + key_family_type")

    if db(db.key_type.id > 0).isempty():
        for name in ["مواد غذائية", "مواد تموينية", "أدوات منزلية", "ملابس"]:
            db.key_type.insert(name=name)
        log("  + key_type")

    if db(db.key_payment_type.id > 0).isempty():
        for name in ["سداد مستحقات", "خصم مكتسب", "مرتجعات/فاتورة", "مرتجعات/اصناف"]:
            db.key_payment_type.insert(name=name)
        log("  + key_payment_type")

    if db(db.key_invoce_type.id > 0).isempty():
        for name in ["مشتريات", "توريد", "هدايا", "تبرعات"]:
            db.key_invoce_type.insert(name=name)
        log("  + key_invoce_type")

    # ===================================================================
    # 2) مجموعات الصلاحيات والمستخدم الافتراضي
    # ===================================================================
    if db(db.auth_group.id > 0).isempty():
        db.auth_group.insert(role="admin")
        db.auth_group.insert(role="user")
        db.auth_group.insert(role="account")
        db.auth_group.insert(role="report")
        log("  + auth_group")

    if db(db.auth_user.id > 0).isempty():
        password = db.auth_user.password.validate("admin")[0]
        user_id = db.auth_user.insert(
            first_name="admin", last_name="user", password=password, email="admin@user.com"
        )
        log("  + auth_user (admin)")
        if db(db.auth_membership.id > 0).isempty():
            db.auth_membership.insert(
                user_id=user_id, group_id=db(db.auth_group.id > 0).select().first().id
            )
            log("  + auth_membership")

    # ===================================================================
    # 3) بيانات التشغيل
    # ===================================================================
    if db(db.systems.id > 0).isempty():
        db.systems.insert(name="نظام الأسر والموردين")
        log("  + systems")

    # شاشات النظام
    added_screens = 0
    for r in SCREENS_CODE:
        if not db(db.screens.screen_code == r["screen_code"]).select().first():
            db.screens.insert(
                systems=r["systems"], name=r["name"], screen_code=r["screen_code"]
            )
            added_screens += 1
    if added_screens:
        log("  + screens (%s)" % added_screens)

    # ===================================================================
    # 4) بيانات المنشأة
    # ===================================================================
    if db(db.important_info.id > 0).isempty():
        db.important_info.insert(
            name="نظام الأسر والموردين",
            vat="0",
            tel="0",
            mobile="05",
            address="العنوان",
            msg1="----",
            msg2="----",
        )
        log("  + important_info")

    # ===================================================================
    # 5) سجلات افتراضية للأعمال
    # ===================================================================
    if db(db.suppliers.id > 0).isempty():
        db.suppliers.insert(name="مورد عام - مورد نقدي")
        log("  + suppliers")

    if db(db.families.id > 0).isempty():
        db.families.insert(name="أسرة عامة", mobile="0500000000", members_count=1)
        log("  + families")

    db.commit()
    log("تمت التهيئة بنجاح.")
