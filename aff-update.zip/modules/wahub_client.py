# -*- coding: utf-8 -*-
"""
الإرسال عبر بوابة واتساب المركزية (wahub) بدل ميتا مباشرة.

وحدة نقية لا تعتمد على web2py. البوابة تحفظ الرسالة فوراً ثم ترسلها لميتا وتعيد المحاولة،
وتُبلغ النظام بحالات الرسائل وردود العملاء بطلبات موقّعة إلى controllers/wahub_hook.py.
بيانات الربط من private/appconfig.ini قسم [wahub]: url و key و callback_secret.

    import wahub_client as hub
    res = hub.send(cfg, "aff-1024-a1b2c3", "966551234567", "aff_transaction_notice", ["محمد", ...])
    if res["ok"]:
        res["hub_id"], res["status"]
"""
import hashlib
import hmac

import httpx

# الإرسال يجري داخل طلب الحفظ، والبوابة ترد فوراً دون انتظار ميتا: مهلة قصيرة تكفي.
TIMEOUT = httpx.Timeout(10.0, connect=5.0)

# مفاتيح قسم [wahub] في appconfig.ini بأسمائها في الواجهة
CONFIG_LABELS = {
    "url": "رابط البوابة",
    "key": "مفتاح النظام في البوابة",
    "callback_secret": "سرّ إشعارات البوابة",
}


def missing_config(cfg, keys=("url", "key")):
    """أسماء مفاتيح الإعداد الناقصة من القائمة المطلوبة."""
    return [key for key in keys if not str(cfg.get(key) or "").strip()]


def missing_text(missing):
    return "بيانات ربط بوابة واتساب غير مكتملة في ملف إعدادات النظام: %s" % "، ".join(
        CONFIG_LABELS.get(key, key) for key in missing
    )


def _fail(text, retryable=False, code=None, http_status=None):
    return {"ok": False, "error_code": code, "error_text": text, "retryable": retryable,
            "http_status": http_status}


def _request(cfg, method, path, json_body=None, transport=None):
    """طلب واحد إلى واجهة البوابة. يعيد dict موحّداً ولا يرفع استثناء."""
    missing = missing_config(cfg)
    if missing:
        return _fail(missing_text(missing))
    url = "%s/api/v1/%s" % (str(cfg["url"]).strip().rstrip("/"), path)
    headers = {"Authorization": "Bearer %s" % str(cfg["key"]).strip(), "Accept": "application/json"}
    try:
        with httpx.Client(transport=transport, timeout=TIMEOUT) as client:
            resp = client.request(method, url, json=json_body, headers=headers)
    except httpx.HTTPError as e:
        # الإرسال بمرجع ثابت: إن كانت البوابة استلمت الرسالة فلن تكررها، فإعادة المحاولة آمنة دائماً
        return _fail("تعذّر الاتصال ببوابة واتساب (%s)" % e.__class__.__name__, retryable=True)
    try:
        body = resp.json()
    except ValueError:
        body = None
    if not isinstance(body, dict):
        return _fail("استجابة غير متوقعة من بوابة واتساب (HTTP %s)" % resp.status_code,
                     retryable=resp.status_code >= 500, http_status=resp.status_code)
    if resp.status_code >= 400 or not body.get("ok"):
        text = body.get("mess") or "رفضت بوابة واتساب الطلب (HTTP %s)" % resp.status_code
        return _fail(text, retryable=resp.status_code >= 500 or resp.status_code == 429,
                     code=body.get("error"), http_status=resp.status_code)
    return {"ok": True, "body": body, "http_status": resp.status_code}


def send(cfg, ref, to, template, params, language="ar", transport=None):
    """تسليم رسالة قالب للبوابة. المرجع نفسه لا يُرسل مرتين. يعيد {ok, hub_id, status, duplicate}."""
    res = _request(cfg, "POST", "messages", json_body={
        "ref": ref, "to": to, "template": template, "language": language, "params": list(params or []),
    }, transport=transport)
    if not res["ok"]:
        return res
    body = res["body"]
    return {"ok": True, "hub_id": body.get("id"), "status": body.get("status") or "queued",
            "duplicate": bool(body.get("duplicate")), "error_code": None, "error_text": None,
            "retryable": False, "http_status": res["http_status"]}


def status(cfg, transport=None):
    """صاحب المفتاح في البوابة ورقم الإرسال المرتبط به (لفحص الربط)."""
    res = _request(cfg, "GET", "status", transport=transport)
    return {"ok": True, "data": res["body"].get("data") or {}} if res["ok"] else res


def templates(cfg, transport=None):
    """قوالب رقم الإرسال في البوابة مع حالتها لدى ميتا."""
    res = _request(cfg, "GET", "templates", transport=transport)
    return {"ok": True, "data": res["body"].get("data") or []} if res["ok"] else res


def create_template(cfg, tpl, language="ar", transport=None):
    """تقديم قالب يحتاجه النظام لميتا عبر البوابة (من TEMPLATES). القالب المقدَّم من قبل لا يُقدَّم ثانية."""
    res = _request(cfg, "POST", "templates", json_body={
        "name": tpl["name"], "language": language, "category": tpl["category"], "body": tpl["body"],
        "example": list(tpl["example"]),
    }, transport=transport)
    if not res["ok"]:
        return res
    body = res["body"]
    return {"ok": True, "data": {"status": body.get("status") or "PENDING", "duplicate": bool(body.get("duplicate"))}}


def verify_signature(secret, raw_body, header_value):
    """تحقق X-Wahub-Signature: بصمة HMAC-SHA256 للجسم الخام بسرّ إشعارات النظام."""
    secret = str(secret or "").strip()
    signature = str(header_value or "").strip()
    if not secret or not signature.startswith("sha256="):
        return False
    expected = hmac.new(secret.encode("utf-8"), raw_body or b"", hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature[7:].strip().lower())
