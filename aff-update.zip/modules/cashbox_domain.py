# -*- coding: utf-8 -*-
"""Pure cashbox calculations and validation helpers."""

import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


CENT = Decimal("0.01")
PERCENT_UNIT = Decimal("0.0001")
ZERO = Decimal("0.00")
POS_FEE_PER_THOUSAND = Decimal("8.00")
POS_FEE_RATE = POS_FEE_PER_THOUSAND / Decimal("1000")


def money(value, allow_none=False):
    """Return a non-negative monetary Decimal rounded to halalas."""
    if value is None or str(value).strip() == "":
        if allow_none:
            return None
        return ZERO
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("المبلغ يجب أن يكون رقماً صحيحاً")
    if not amount.is_finite() or amount < ZERO:
        raise ValueError("المبلغ يجب أن يكون صفراً أو أكثر")
    return amount.quantize(CENT, rounding=ROUND_HALF_UP)


def percentage(value):
    """Return a percentage between 0 and 100 with four-decimal precision."""
    if value is None or str(value).strip() == "":
        return ZERO
    try:
        rate = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("النسبة يجب أن تكون رقماً صحيحاً")
    if not rate.is_finite() or rate < ZERO or rate > Decimal("100"):
        raise ValueError("النسبة يجب أن تكون بين صفر و100")
    return rate.quantize(PERCENT_UNIT, rounding=ROUND_HALF_UP)


def calculate_family_summary(entries):
    """Calculate per-family and aggregate daily consignment sales values.

    Commission is rounded per family before aggregation so the total matches
    the individual family settlements exactly. The displayed aggregate rate is
    weighted by the absolute net sales because families can have different
    rates and a day can contain return-only rows.
    """
    details = []
    received_total = ZERO
    returned_total = ZERO
    net_total = ZERO
    commission_total = ZERO
    family_net_total = ZERO
    weighted_rate_total = ZERO
    weight_total = ZERO

    for entry in entries:
        received = money(entry.get("received"))
        returned = money(entry.get("returned"))
        rate = percentage(entry.get("sale_percent"))
        net_sales = (received - returned).quantize(CENT, rounding=ROUND_HALF_UP)
        commission = (net_sales * rate / Decimal("100")).quantize(
            CENT, rounding=ROUND_HALF_UP
        )
        family_net = (net_sales - commission).quantize(CENT, rounding=ROUND_HALF_UP)
        weight = abs(net_sales)

        received_total += received
        returned_total += returned
        net_total += net_sales
        commission_total += commission
        family_net_total += family_net
        weighted_rate_total += weight * rate
        weight_total += weight
        details.append({
            "family_id": entry.get("family_id"),
            "family_name": entry.get("family_name") or "أسرة غير معرّفة",
            "sale_percent": rate,
            "received": received,
            "returned": returned,
            "net_sales": net_sales,
            "commission_amount": commission,
            "net_amount": family_net,
        })

    weighted_rate = (
        ZERO if weight_total == ZERO
        else (weighted_rate_total / weight_total).quantize(
            PERCENT_UNIT, rounding=ROUND_HALF_UP
        )
    )
    return {
        "received": received_total.quantize(CENT),
        "returned": returned_total.quantize(CENT),
        "net_sales": net_total.quantize(CENT),
        "commission_rate": weighted_rate,
        "commission_amount": commission_total.quantize(CENT),
        "net_amount": family_net_total.quantize(CENT),
        "details": details,
    }


def calculate_totals(opening_balance, pos_total, bank_withdrawal,
                     misc_expenses, paid_to_parties, actual_closing_cash=None):
    """Calculate a legacy (combined-account) journal.

    This function is intentionally kept for journals created before account
    separation.  New journals must use ``calculate_separated_totals`` so a
    historical row is never silently reinterpreted under the new rules.
    """
    opening = money(opening_balance)
    pos = money(pos_total)
    bank = money(bank_withdrawal)
    misc = money(misc_expenses)
    paid = money(paid_to_parties)
    actual = money(actual_closing_cash, allow_none=True)

    total_in = (opening + pos + bank).quantize(CENT)
    total_out = (misc + paid).quantize(CENT)
    closing = (total_in - total_out).quantize(CENT)
    net_after_payments = (pos - paid).quantize(CENT)
    difference = None if actual is None else (actual - closing).quantize(CENT)

    return {
        "opening_balance": opening,
        "pos_total": pos,
        "bank_withdrawal": bank,
        "misc_expenses": misc,
        "paid_to_suppliers": paid,
        "total_in": total_in,
        "total_out": total_out,
        "closing_balance": closing,
        # Kept under the legacy column name for database/report compatibility.
        "net_sales": net_after_payments,
        "actual_closing_cash": actual,
        "cash_difference": difference,
    }


def calculate_separated_totals(
    opening_cash,
    cash_sales,
    bank_withdrawal,
    cash_expenses,
    cash_paid_to_parties,
    cash_deposit_to_bank,
    opening_bank,
    bank_deposit,
    bank_paid_to_parties,
    bank_expenses,
    pos_sales,
    actual_closing_cash=None,
    actual_closing_bank=None,
):
    """Calculate independent cash and cumulative-bank balances.

    POS/network sales belong to the cumulative bank balance.  The bank is
    credited with the sale after an automatic fee of 8 SAR per 1,000 SAR
    (0.8%).  Transfers are double-sided but are not income or expense:

    * ``bank_withdrawal`` decreases bank and increases physical cash.
    * ``cash_deposit_to_bank`` decreases cash and increases bank.
    * POS sales increase bank by the net value after the automatic fee.

    The legacy columns ``opening_balance``, ``total_in``, ``total_out`` and
    ``closing_balance`` represent the physical-cash account for separated
    journals. ``pos_total`` stores gross POS sales and ``pos_fees`` stores the
    automatically calculated fee for compatibility and reporting.
    """
    opening_cash = money(opening_cash)
    cash_sales = money(cash_sales)
    bank_withdrawal = money(bank_withdrawal)
    cash_expenses = money(cash_expenses)
    cash_paid = money(cash_paid_to_parties)
    cash_deposit = money(cash_deposit_to_bank)

    opening_bank = money(opening_bank)
    bank_deposit = money(bank_deposit)
    bank_paid = money(bank_paid_to_parties)
    bank_expenses = money(bank_expenses)

    pos_sales = money(pos_sales)
    pos_fees = (pos_sales * POS_FEE_RATE).quantize(CENT, rounding=ROUND_HALF_UP)
    pos_net_to_bank = (pos_sales - pos_fees).quantize(CENT)

    actual_cash = money(actual_closing_cash, allow_none=True)
    actual_bank = money(actual_closing_bank, allow_none=True)

    cash_total_in = (opening_cash + cash_sales + bank_withdrawal).quantize(CENT)
    cash_total_out = (cash_expenses + cash_paid + cash_deposit).quantize(CENT)
    cash_closing = (cash_total_in - cash_total_out).quantize(CENT)

    bank_closing = (
        opening_bank
        + bank_deposit
        + cash_deposit
        + pos_net_to_bank
        - bank_withdrawal
        - bank_paid
        - bank_expenses
    ).quantize(CENT)

    if cash_closing < ZERO:
        raise ValueError("حركة الكاش تتجاوز الرصيد المتاح")
    if bank_closing < ZERO:
        raise ValueError("حركة البنك تتجاوز الرصيد المتاح")

    cash_difference = (
        None if actual_cash is None else (actual_cash - cash_closing).quantize(CENT)
    )
    bank_difference = (
        None if actual_bank is None else (actual_bank - bank_closing).quantize(CENT)
    )
    total_paid = (cash_paid + bank_paid).quantize(CENT)
    total_sales = (cash_sales + pos_sales).quantize(CENT)

    return {
        "opening_balance": opening_cash,
        "cash_sales": cash_sales,
        "bank_withdrawal": bank_withdrawal,
        "misc_expenses": cash_expenses,
        "cash_paid_to_suppliers": cash_paid,
        "cash_deposit_to_bank": cash_deposit,
        "total_in": cash_total_in,
        "total_out": cash_total_out,
        "closing_balance": cash_closing,
        "actual_closing_cash": actual_cash,
        "cash_difference": cash_difference,
        "bank_opening_balance": opening_bank,
        "bank_deposit": bank_deposit,
        "bank_paid_to_suppliers": bank_paid,
        "bank_expenses": bank_expenses,
        "bank_closing_balance": bank_closing,
        "actual_closing_bank": actual_bank,
        "bank_difference": bank_difference,
        "pos_total": pos_sales,
        "pos_settlement": pos_sales,
        "pos_fees": pos_fees,
        "pos_net_to_bank": pos_net_to_bank,
        # Deprecated separate-POS columns are deliberately cleared.  They
        # remain in the schema only so no destructive migration is required.
        "pos_opening_balance": ZERO,
        "pos_closing_balance": ZERO,
        "actual_closing_pos": None,
        "pos_difference": None,
        "paid_to_suppliers": total_paid,
        # Kept under the legacy name for report compatibility.
        "net_sales": (total_sales - total_paid).quantize(CENT),
    }


def parse_iso_date(value, required=False):
    text = (value or "").strip()
    if not text:
        if required:
            raise ValueError("يجب اختيار التاريخ")
        return None
    try:
        return datetime.datetime.strptime(text, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        raise ValueError("صيغة التاريخ غير صحيحة")


def validate_date_range(date_from, date_to):
    start = parse_iso_date(date_from)
    end = parse_iso_date(date_to)
    if start and end and start > end:
        raise ValueError("تاريخ البداية يجب ألا يكون بعد تاريخ النهاية")
    return start, end


def difference_needs_reason(difference):
    return difference is not None and difference != ZERO


def json_money(value):
    """Convert a DAL/Decimal money value to a JSON-safe number."""
    if value is None:
        return None
    return float(Decimal(str(value)).quantize(CENT, rounding=ROUND_HALF_UP))
