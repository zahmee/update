# -*- coding: utf-8 -*-
"""Pure cashbox calculations and validation helpers."""

import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


CENT = Decimal("0.01")
PERCENT_UNIT = Decimal("0.0001")
ZERO = Decimal("0.00")


def money(value, allow_none=False):
    """Return a non-negative monetary Decimal rounded to halalas."""
    if value is None or str(value).strip() == "":
        if allow_none:
            return None
        return ZERO
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("المبلغ يجب أن يكون رقماً صحيحاً")
    if not amount.is_finite() or amount < ZERO:
        raise ValueError("المبلغ يجب أن يكون صفراً أو أكثر")
    return amount.quantize(CENT, rounding=ROUND_HALF_UP)


def percentage(value):
    """Return a percentage between 0 and 100 with four-decimal precision."""
    if value is None or str(value).strip() == "":
        return ZERO
    try:
        rate = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("النسبة يجب أن تكون رقماً صحيحاً")
    if not rate.is_finite() or rate < ZERO or rate > Decimal("100"):
        raise ValueError("النسبة يجب أن تكون بين صفر و100")
    return rate.quantize(PERCENT_UNIT, rounding=ROUND_HALF_UP)


def calculate_family_summary(entries):
    """Calculate per-family and aggregate daily consignment sales values.

    Commission is rounded per family before aggregation so the total matches
    the individual family settlements exactly. The displayed aggregate rate is
    weighted by the absolute net sales because families can have different
    rates and a day can contain return-only rows.
    """
    details = []
    received_total = ZERO
    returned_total = ZERO
    net_total = ZERO
    commission_total = ZERO
    family_net_total = ZERO
    weighted_rate_total = ZERO
    weight_total = ZERO

    for entry in entries:
        received = money(entry.get("received"))
        returned = money(entry.get("returned"))
        rate = percentage(entry.get("sale_percent"))
        net_sales = (received - returned).quantize(CENT, rounding=ROUND_HALF_UP)
        commission = (net_sales * rate / Decimal("100")).quantize(
            CENT, rounding=ROUND_HALF_UP
        )
        family_net = (net_sales - commission).quantize(CENT, rounding=ROUND_HALF_UP)
        weight = abs(net_sales)

        received_total += received
        returned_total += returned
        net_total += net_sales
        commission_total += commission
        family_net_total += family_net
        weighted_rate_total += weight * rate
        weight_total += weight
        details.append({
            "family_id": entry.get("family_id"),
            "family_name": entry.get("family_name") or "أسرة غير معرّفة",
            "sale_percent": rate,
            "received": received,
            "returned": returned,
            "net_sales": net_sales,
            "commission_amount": commission,
            "net_amount": family_net,
        })

    weighted_rate = (
        ZERO if weight_total == ZERO
        else (weighted_rate_total / weight_total).quantize(
            PERCENT_UNIT, rounding=ROUND_HALF_UP
        )
    )
    return {
        "received": received_total.quantize(CENT),
        "returned": returned_total.quantize(CENT),
        "net_sales": net_total.quantize(CENT),
        "commission_rate": weighted_rate,
        "commission_amount": commission_total.quantize(CENT),
        "net_amount": family_net_total.quantize(CENT),
        "details": details,
    }


def calculate_totals(opening_balance, pos_total, bank_withdrawal,
                     misc_expenses, paid_to_parties, actual_closing_cash=None):
    """Calculate the journal totals using Decimal arithmetic."""
    opening = money(opening_balance)
    pos = money(pos_total)
    bank = money(bank_withdrawal)
    misc = money(misc_expenses)
    paid = money(paid_to_parties)
    actual = money(actual_closing_cash, allow_none=True)

    total_in = (opening + pos + bank).quantize(CENT)
    total_out = (misc + paid).quantize(CENT)
    closing = (total_in - total_out).quantize(CENT)
    net_after_payments = (pos - paid).quantize(CENT)
    difference = None if actual is None else (actual - closing).quantize(CENT)

    return {
        "opening_balance": opening,
        "pos_total": pos,
        "bank_withdrawal": bank,
        "misc_expenses": misc,
        "paid_to_suppliers": paid,
        "total_in": total_in,
        "total_out": total_out,
        "closing_balance": closing,
        # Kept under the legacy column name for database/report compatibility.
        "net_sales": net_after_payments,
        "actual_closing_cash": actual,
        "cash_difference": difference,
    }


def parse_iso_date(value, required=False):
    text = (value or "").strip()
    if not text:
        if required:
            raise ValueError("يجب اختيار التاريخ")
        return None
    try:
        return datetime.datetime.strptime(text, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        raise ValueError("صيغة التاريخ غير صحيحة")


def validate_date_range(date_from, date_to):
    start = parse_iso_date(date_from)
    end = parse_iso_date(date_to)
    if start and end and start > end:
        raise ValueError("تاريخ البداية يجب ألا يكون بعد تاريخ النهاية")
    return start, end


def difference_needs_reason(difference):
    return difference is not None and difference != ZERO


def json_money(value):
    """Convert a DAL/Decimal money value to a JSON-safe number."""
    if value is None:
        return None
    return float(Decimal(str(value)).quantize(CENT, rounding=ROUND_HALF_UP))
