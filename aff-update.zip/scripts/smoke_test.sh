#!/bin/bash
# اختبار شامل لتطبيق aff عبر خادم web2py مؤقت
cd /d/web2py
PORT=8123
BASE="http://127.0.0.1:$PORT/aff"
JAR=/tmp/aff_cookies.txt
rm -f $JAR /tmp/w2p_aff.log

python web2py.py -a testpass -i 127.0.0.1 -p $PORT --no-banner >/tmp/w2p_aff.log 2>&1 &
WPID=$!
sleep 10

PASS=0; FAIL=0
check() { # name expected actual
  if [ "$2" == "$3" ]; then PASS=$((PASS+1)); echo "PASS: $1 ($3)";
  else FAIL=$((FAIL+1)); echo "FAIL: $1 expected=$2 got=$3"; fi
}

# 1) صفحة الدخول
C=$(curl -s -c $JAR -o /tmp/p1.html -w "%{http_code}" "$BASE/default/user/login"); check "login page" 200 $C
grep -q "تسجيل" /tmp/p1.html && echo "  login page has Arabic content OK" || echo "  WARN: login content missing"

# استخراج الحقول المخفية من النموذج (_formkey / _next)
FORMKEY=$(grep -o 'name="_formkey"[^>]*value="[^"]*"' /tmp/p1.html | head -1 | sed 's/.*value="\([^"]*\)".*/\1/')
NEXTV=$(grep -o 'name="_next"[^>]*value="[^"]*"' /tmp/p1.html | head -1 | sed 's/.*value="\([^"]*\)".*/\1/')
echo "  formkey=${FORMKEY:0:12}... next=$NEXTV"

# 2) تسجيل الدخول admin
C=$(curl -s -b $JAR -c $JAR -o /tmp/p2.html -w "%{http_code}" -X POST "$BASE/default/user/login" \
  --data-urlencode "email=admin@user.com" --data-urlencode "password=admin" \
  --data-urlencode "_formname=login" --data-urlencode "_formkey=$FORMKEY" --data-urlencode "_next=$NEXTV")
check "login post redirect" 303 $C

# 3) الصفحات الرئيسية
for P in "default/index" "families/index" "goods/index" "returns/index" \
         "suppliers/payment" "setup/index" "setup/users_management" \
         "setup/unit_key" "setup/important_info" "setup/screens" "setup/seed_data" "default/about"; do
  C=$(curl -s -b $JAR -o /tmp/pg.html -w "%{http_code}" "$BASE/$P")
  check "GET $P" 200 $C
done

# 4) ملفات JS المصاحبة
for P in "families/index.js" "goods/index.js" "returns/index.js"; do
  C=$(curl -s -b $JAR -o /dev/null -w "%{http_code}" "$BASE/$P")
  check "GET $P" 200 $C
done

# 5) APIs قراءة
check "api get_families ok" true $(curl -s -b $JAR "$BASE/families_api/get_families" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api families get_refs ok" true $(curl -s -b $JAR "$BASE/families_api/get_refs" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api get_parties ok" true $(curl -s -b $JAR "$BASE/families_api/get_parties" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api goods get_refs ok" true $(curl -s -b $JAR "$BASE/goods_api/get_refs" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api returns get_refs ok" true $(curl -s -b $JAR "$BASE/returns_api/get_refs" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api get_receipts ok" true $(curl -s -b $JAR "$BASE/goods_api/get_receipts" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api get_returns ok" true $(curl -s -b $JAR "$BASE/returns_api/get_returns" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api pay_list ok" true $(curl -s -b $JAR "$BASE/suppliers_api/pay_list" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api pay_get_refs ok" true $(curl -s -b $JAR "$BASE/suppliers_api/pay_get_refs" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api get_users count" 1 $(curl -s -b $JAR "$BASE/setup/get_users" | python -c "import sys,json;d=json.load(sys.stdin);print(d.get('count'))" 2>/dev/null)

# 6) اضافة أسرة جديدة
check "api new_family ok" true $(curl -s -b $JAR -X POST "$BASE/families_api/new_family" --data-urlencode "name=أسرة اختبار" --data-urlencode "mobile=0512345678" --data-urlencode "members_count=4" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)

# 7) سند استلام من مورد مع اصناف (مصفوفات متوازية)
RESP=$(curl -s -b $JAR -X POST "$BASE/goods_api/save_receipt" \
  --data-urlencode "supplier=1" --data-urlencode "receipt_date=2026-07-17" \
  --data-urlencode "payment_method=1" --data-urlencode "invoce_type=1" \
  --data-urlencode "item_name=أرز" --data-urlencode "item_name=سكر" \
  --data-urlencode "quantity=2" --data-urlencode "quantity=3" \
  --data-urlencode "price=50" --data-urlencode "price=20" \
  --data-urlencode "unit=1" --data-urlencode "unit=1" \
  --data-urlencode "item_type=1" --data-urlencode "item_type=1")
check "api save_receipt ok" true $(echo "$RESP" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
RECID=$(echo "$RESP" | python -c "import sys,json;d=json.load(sys.stdin);print(d.get('data',{}).get('id'))" 2>/dev/null)
echo "  receipt id=$RECID"
check "receipt total 160" 160.0 $(curl -s -b $JAR "$BASE/goods_api/get_receipt/$RECID" | python -c "import sys,json;d=json.load(sys.stdin);print(d['data']['master']['bill_total'])" 2>/dev/null)
# لا يوجد اعتماد — السند يحتسب فور حفظه

# 8) سند مرتجع لأسرة (يحتسب فوراً بلا اعتماد)
RESP2=$(curl -s -b $JAR -X POST "$BASE/returns_api/save_return" \
  --data-urlencode "family=1" --data-urlencode "return_date=2026-07-17" \
  --data-urlencode "item_name=زيت" --data-urlencode "quantity=1" --data-urlencode "price=30" \
  --data-urlencode "unit=1" --data-urlencode "item_type=1")
check "api save_return ok" true $(echo "$RESP2" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
RETID=$(echo "$RESP2" | python -c "import sys,json;d=json.load(sys.stdin);print(d.get('data',{}).get('id'))" 2>/dev/null)

# 9) تسديد مورد و أسرة عبر الشاشة الموحّدة (pay_save)
check "api pay_save supplier ok" true $(curl -s -b $JAR -X POST "$BASE/suppliers_api/pay_save?kind=supplier&party_id=1&amount=60&pay_date=2026-07-17&payment_method=1&payment_type=1" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api pay_save family ok" true $(curl -s -b $JAR -X POST "$BASE/suppliers_api/pay_save?kind=family&party_id=1&amount=25&pay_date=2026-07-17&payment_method=1&payment_type=1" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
# المستحق للمورد 1 بعد التسديد (pay_get_due): 160 مستلم − 60 مسدد = 100
check "api pay_get_due supplier 100" 100.0 $(curl -s -b $JAR "$BASE/suppliers_api/pay_get_due?kind=supplier&party_id=1" | python -c "import sys,json;d=json.load(sys.stdin);print(d['data']['net_due'])" 2>/dev/null)

# 10) التحقق من الارصدة
# المورد 1: مستلم 160 - مرتجع 0 - مسدد 60 = 100
check "supplier balance 100" 100.0 $(curl -s -b $JAR "$BASE/suppliers_api/get_account/1" | python -c "import sys,json;d=json.load(sys.stdin);print(d['data']['balance'])" 2>/dev/null)
# الأسرة 1: مستلم 0 - مرتجع 30 - مسدد 25 = -55
check "family balance -55" -55.0 $(curl -s -b $JAR "$BASE/families_api/get_families" | python -c "import sys,json;d=json.load(sys.stdin);r=[x for x in d['data'] if x['id']==1][0];print(r['fam_bal'])" 2>/dev/null)

# 11) حذف سند (متاح دائماً — لا يوجد اعتماد يقفل السند)
RESP3=$(curl -s -b $JAR -X POST "$BASE/goods_api/save_receipt" --data-urlencode "supplier=1" --data-urlencode "item_name=مؤقت" --data-urlencode "quantity=1" --data-urlencode "price=5")
TMPID=$(echo "$RESP3" | python -c "import sys,json;d=json.load(sys.stdin);print(d.get('data',{}).get('id'))" 2>/dev/null)
check "api delete receipt ok" true $(curl -s -b $JAR -X POST "$BASE/goods_api/delete_receipt?id=$TMPID" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)

# 12) شاشة lookups
check "api lookup_list ok" true $(curl -s -b $JAR "$BASE/setup/lookup_list?key=unit" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)
check "api lookup_save ok" true $(curl -s -b $JAR -X POST "$BASE/setup/lookup_save?key=unit&name=درزن" | python -c "import sys,json;d=json.load(sys.stdin);print(str(d.get('ok')).lower())" 2>/dev/null)

# 13) إدارة المستخدمين APIs
check "api save_user ok" 0 $(curl -s -b $JAR -X POST "$BASE/setup/save_user?first_name=test&last_name=user&email=test@user.com&password=1234" | python -c "import sys,json;d=json.load(sys.stdin);print(d.get('err'))" 2>/dev/null)
check "api api_grant_all ok" 0 $(curl -s -b $JAR -X POST "$BASE/setup/api_grant_all/2" | python -c "import sys,json;d=json.load(sys.stdin);print(d.get('err'))" 2>/dev/null)

echo "================================"
echo "RESULT: PASS=$PASS FAIL=$FAIL"
kill $WPID 2>/dev/null
sleep 1
kill -9 $WPID 2>/dev/null
echo "server stopped"
