# -*- coding: utf-8 -*-
"""Build upload-ready releases for the aff web2py application.

Outputs:
* web2py.app.<app>-v<version>.w2p: upload through web2py Admin.
* <app>-v<version>.zip: complete application folder for manual deployment.
* <app>-update.zip: code-only update archive, optionally copied to the update repo.
"""

from __future__ import print_function

import argparse
import fnmatch
import hashlib
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import zipfile


APP_DIRECTORIES = (
    "controllers",
    "cron",
    "languages",
    "models",
    "modules",
    "scripts",
    "static",
    "views",
    "uploads",
)
RUNTIME_DIRECTORIES = ("cache", "databases", "errors", "sessions")
ROOT_FILES = ("__init__.py", "PRODUCT.md", "VERSION.txt", "zip_app.bat")
UPDATE_DIRECTORIES = ("controllers", "models", "modules", "scripts", "static", "views")
EXCLUDED_NAMES = {"__pycache__", ".pytest_cache", ".mypy_cache", ".DS_Store", "Thumbs.db"}
EXCLUDED_PATTERNS = ("*.pyc", "*.pyo", "*.log", "*.tmp", "*.bak", "*.zip", "*.w2p")
PRIVATE_DEV_PATTERNS = ("asbab_*", "chunk-*.js", "explore_asbab.py")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build full ZIP/W2P releases and the legacy update package."
    )
    parser.add_argument(
        "--code-only",
        action="store_true",
        help="Do not include the current database. Uploaded files are still included.",
    )
    parser.add_argument(
        "--no-version-bump",
        action="store_true",
        help="Use the current version without incrementing its last number.",
    )
    parser.add_argument(
        "--skip-update-repository",
        action="store_true",
        help="Create local artifacts only; do not copy/commit/push the update repository.",
    )
    parser.add_argument(
        "--output-dir",
        help="Artifact directory. Defaults to <application>/releases.",
    )
    return parser.parse_args()


def version_for_build(version_path, no_bump):
    current = version_path.read_text(encoding="ascii").strip() if version_path.exists() else ""
    if current and not all(part.isdigit() for part in current.split(".")):
        raise ValueError("Invalid VERSION.txt value: %s" % current)
    if no_bump:
        return current or "1.0.0"
    if not current:
        return "1.0.0"
    parts = current.split(".")
    parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def excluded(path, private_root=None):
    if any(part in EXCLUDED_NAMES for part in path.parts):
        return True
    if any(fnmatch.fnmatch(path.name, pattern) for pattern in EXCLUDED_PATTERNS):
        return True
    if private_root and path.is_relative_to(private_root):
        relative = path.relative_to(private_root)
        if len(relative.parts) == 1 and any(
            fnmatch.fnmatch(path.name, pattern) for pattern in PRIVATE_DEV_PATTERNS
        ):
            return True
    return False


def copy_directory(source, destination, private_root=None):
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.rglob("*"):
        if excluded(item, private_root=private_root):
            continue
        relative = item.relative_to(source)
        target = destination / relative
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif item.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(item), str(target))


def backup_sqlite(source, destination):
    """Create a transactionally consistent SQLite copy while the app is running."""
    source_uri = "file:%s?mode=ro" % source.as_posix()
    with sqlite3.connect(source_uri, uri=True) as source_db:
        with sqlite3.connect(str(destination)) as destination_db:
            source_db.backup(destination_db)
            result = destination_db.execute("PRAGMA quick_check").fetchone()
            if not result or result[0] != "ok":
                raise RuntimeError("SQLite quick_check failed for the release copy")


def stage_application(app_root, stage_app, version, include_data):
    stage_app.mkdir(parents=True, exist_ok=True)
    private_root = app_root / "private"
    for directory in APP_DIRECTORIES:
        source = app_root / directory
        if source.is_dir():
            copy_directory(source, stage_app / directory)
    if private_root.is_dir():
        copy_directory(private_root, stage_app / "private", private_root=private_root)

    for directory in RUNTIME_DIRECTORIES:
        (stage_app / directory).mkdir(parents=True, exist_ok=True)

    databases_source = app_root / "databases"
    databases_target = stage_app / "databases"
    if include_data and databases_source.is_dir():
        for item in databases_source.iterdir():
            if item.is_file() and item.name != "storage.sqlite" and not excluded(item):
                shutil.copy2(str(item), str(databases_target / item.name))
        sqlite_source = databases_source / "storage.sqlite"
        if sqlite_source.is_file():
            backup_sqlite(sqlite_source, databases_target / "storage.sqlite")

    for filename in ROOT_FILES:
        source = app_root / filename
        if source.is_file() and filename != "VERSION.txt":
            shutil.copy2(str(source), str(stage_app / filename))
    (stage_app / "VERSION.txt").write_text(version, encoding="ascii")
    (stage_app / "release-info.txt").write_text(
        "application=%s\nversion=%s\ndatabase_included=%s\n"
        % (app_root.name, version, "yes" if include_data else "no"),
        encoding="utf-8",
    )


def write_zip(source_app, destination):
    temp_destination = destination.with_suffix(destination.suffix + ".tmp")
    if temp_destination.exists():
        temp_destination.unlink()
    with zipfile.ZipFile(
        str(temp_destination), "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for directory in sorted(path for path in source_app.rglob("*") if path.is_dir()):
            relative = directory.relative_to(source_app)
            archive.writestr((Path(source_app.name) / relative).as_posix() + "/", b"")
        for item in sorted(path for path in source_app.rglob("*") if path.is_file()):
            relative = item.relative_to(source_app)
            archive.write(str(item), (Path(source_app.name) / relative).as_posix())
    os.replace(str(temp_destination), str(destination))


def write_w2p(source_app, destination, web2py_root):
    sys.path.insert(0, str(web2py_root))
    from gluon.fileutils import w2p_pack

    temp_destination = destination.with_suffix(destination.suffix + ".tmp")
    if temp_destination.exists():
        temp_destination.unlink()
    w2p_pack(str(temp_destination), str(source_app))
    os.replace(str(temp_destination), str(destination))


def write_update_zip(source_app, destination):
    temp_destination = destination.with_suffix(destination.suffix + ".tmp")
    if temp_destination.exists():
        temp_destination.unlink()
    with zipfile.ZipFile(
        str(temp_destination), "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for directory_name in UPDATE_DIRECTORIES:
            directory = source_app / directory_name
            if not directory.is_dir():
                continue
            for item in sorted(path for path in directory.rglob("*") if path.is_file()):
                archive.write(str(item), item.relative_to(source_app).as_posix())
        archive.write(str(source_app / "VERSION.txt"), "VERSION.txt")
    os.replace(str(temp_destination), str(destination))


def verify_artifacts(zip_path, w2p_path, app_name, include_data):
    zip_required = {
        "%s/controllers/default.py" % app_name,
        "%s/models/db.py" % app_name,
        "%s/private/appconfig.ini" % app_name,
        "%s/VERSION.txt" % app_name,
    }
    if include_data:
        zip_required.add("%s/databases/storage.sqlite" % app_name)
    with zipfile.ZipFile(str(zip_path), "r") as archive:
        bad_file = archive.testzip()
        if bad_file:
            raise RuntimeError("Corrupt file in ZIP: %s" % bad_file)
        missing = zip_required.difference(archive.namelist())
        if missing:
            raise RuntimeError("ZIP is missing required files: %s" % sorted(missing))

    w2p_required = {"controllers/default.py", "models/db.py", "private/appconfig.ini", "VERSION.txt"}
    if include_data:
        w2p_required.add("databases/storage.sqlite")
    with tarfile.open(str(w2p_path), "r:gz") as archive:
        missing = w2p_required.difference(archive.getnames())
        if missing:
            raise RuntimeError("W2P is missing required files: %s" % sorted(missing))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_git(update_dir, version, archive_name, version_name):
    if not (update_dir / ".git").exists():
        print("[INFO] Update directory is not a Git repository; files were copied only.")
        return
    try:
        subprocess.run(
            ["git", "-C", str(update_dir), "add", archive_name, version_name], check=True
        )
        staged = subprocess.run(
            ["git", "-C", str(update_dir), "diff", "--cached", "--quiet"]
        )
        if staged.returncode == 0:
            print("[INFO] No update-repository changes to commit.")
            return
        subprocess.run(
            ["git", "-C", str(update_dir), "commit", "-m", "Update aff release %s" % version],
            check=True,
        )
        subprocess.run(["git", "-C", str(update_dir), "push"], check=True)
        print("[DONE] Update repository committed and pushed.")
    except (OSError, subprocess.CalledProcessError) as error:
        print("[WARN] Release artifacts are valid, but update-repository Git failed: %s" % error)


def sync_update_repository(update_zip, version_path, version, skip):
    if skip:
        print("[INFO] Update-repository sync skipped by option.")
        return
    update_dir = Path(os.environ.get("AFF_UPDATE_REPO", r"D:\update my app")).resolve()
    if not update_dir.is_dir():
        print("[WARN] Update repository not found; local release files are still ready: %s" % update_dir)
        return
    target_zip = update_dir / update_zip.name
    target_version = update_dir / version_path.name
    shutil.copy2(str(update_zip), str(target_zip))
    shutil.copy2(str(version_path), str(target_version))
    print("[DONE] Update files copied to: %s" % update_dir)
    run_git(update_dir, version, target_zip.name, target_version.name)


def main():
    args = parse_args()
    app_root = Path(__file__).resolve().parents[1]
    web2py_root = app_root.parents[1]
    app_name = app_root.name
    version_path = app_root / "VERSION.txt"
    version = version_for_build(version_path, args.no_version_bump)
    include_data = not args.code_only
    output_dir = Path(args.output_dir).resolve() if args.output_dir else app_root / "releases"
    output_dir.mkdir(parents=True, exist_ok=True)

    zip_path = output_dir / ("%s-v%s.zip" % (app_name, version))
    w2p_path = output_dir / ("web2py.app.%s-v%s.w2p" % (app_name, version))
    update_zip = output_dir / ("%s-update.zip" % app_name)
    hash_path = output_dir / ("%s-v%s-SHA256.txt" % (app_name, version))
    legacy_update_zip = output_dir / "pha.zip"
    if legacy_update_zip.is_file():
        legacy_update_zip.unlink()
        print("[INFO] Removed obsolete package name: %s" % legacy_update_zip.name)

    print("[INFO] Application: %s" % app_name)
    print("[INFO] Release version: %s" % version)
    print("[INFO] Database included: %s" % ("yes" if include_data else "no"))

    with tempfile.TemporaryDirectory(prefix="%s-release-" % app_name) as temp_dir:
        stage_app = Path(temp_dir) / app_name
        stage_application(app_root, stage_app, version, include_data)
        write_zip(stage_app, zip_path)
        write_w2p(stage_app, w2p_path, web2py_root)
        write_update_zip(stage_app, update_zip)
        verify_artifacts(zip_path, w2p_path, app_name, include_data)

    version_path.write_text(version, encoding="ascii")
    hashes = [
        "%s  %s" % (sha256(path), path.name)
        for path in (zip_path, w2p_path, update_zip)
    ]
    hash_path.write_text("\n".join(hashes) + "\n", encoding="ascii")

    print("[DONE] Manual ZIP: %s" % zip_path)
    print("[DONE] web2py upload package: %s" % w2p_path)
    print("[DONE] Legacy update package: %s" % update_zip)
    print("[DONE] SHA-256 checksums: %s" % hash_path)
    sync_update_repository(
        update_zip, version_path, version, args.skip_update_repository
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print("[ERROR] %s" % error, file=sys.stderr)
        raise SystemExit(1)
