# -*- coding: utf-8 -*-
"""
اختبار وظيفي للشاشة الموحدة لتسجيل الموردين والأسر
يختبر: get_parties / save_party (إضافة + تعديل + تحقق) / toggle_party_stop
يعمل ضد الخادم المحلي على المنفذ 8000 وينظف بيانات الاختبار بعد الانتهاء
"""
import json
import re
import sqlite3
import sys
import urllib.request
import urllib.parse
import http.cookiejar

BASE = "http://127.0.0.1:8000/aff"
DB_PATH = r"D:\web2py\applications\aff\databases\storage.sqlite"

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("PASS: %s %s" % (name, extra))
    else:
        FAIL += 1
        print("FAIL: %s %s" % (name, extra))


jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def req(url, data=None, method=None):
    if data is not None:
        data = urllib.parse.urlencode(data).encode()
    r = urllib.request.Request(url, data=data, method=method)
    with opener.open(r, timeout=30) as resp:
        return resp.status, resp.read().decode("utf-8", "replace")


# 1) تسجيل الدخول
status, html = req(BASE + "/default/user/login")
check("login page", status == 200)
m = re.search(r'name="_formkey"[^>]*value="([^"]*)"', html)
formkey = m.group(1) if m else ""
status, html = req(BASE + "/default/user/login", data={
    "email": "admin@user.com", "password": "admin",
    "_formname": "login", "_formkey": formkey, "_next": "/",
})
status, html = req(BASE + "/families/index")
check("families/index page loads after login", status == 200 and "تسجيل الموردين والأسر" in html)

# 2) القائمة الموحدة الأولية
status, body = req(BASE + "/families_api/get_parties")
res = json.loads(body)
check("get_parties ok", res.get("ok") is True)
initial_count = res.get("count", 0)
print("   initial count =", initial_count)

# 3) إضافة أسرة جديدة
q = urllib.parse.urlencode({
    "kind": "family", "name": "اختبار_موحد_أسرة", "reg_date": "2026-07-18",
    "mobile": "0500000001", "prev_bal_for": "150.5", "prev_bal_on": "40",
})
status, body = req(BASE + "/families_api/save_party?" + q, data={}, method="POST")
res = json.loads(body)
check("save new family", res.get("ok") is True, body[:120])

# 4) إضافة مورد جديد
q = urllib.parse.urlencode({
    "kind": "supplier", "name": "اختبار_موحد_مورد", "reg_date": "2026-07-18",
    "mobile": "0500000002", "prev_bal_for": "0", "prev_bal_on": "275.25",
})
status, body = req(BASE + "/families_api/save_party?" + q, data={}, method="POST")
res = json.loads(body)
check("save new supplier", res.get("ok") is True, body[:120])
sup_id = (res.get("data") or {}).get("id")

# 5) رفض اسم فارغ
q = urllib.parse.urlencode({"kind": "family", "name": "", "mobile": "", "prev_bal_for": "", "prev_bal_on": ""})
status, body = req(BASE + "/families_api/save_party?" + q, data={}, method="POST")
res = json.loads(body)
check("reject empty name", res.get("ok") is False)

# 6) رفض جوال بصيغة خاطئة
q = urllib.parse.urlencode({"kind": "family", "name": "x", "mobile": "123", "prev_bal_for": "", "prev_bal_on": ""})
status, body = req(BASE + "/families_api/save_party?" + q, data={}, method="POST")
res = json.loads(body)
check("reject bad mobile", res.get("ok") is False)

# 7) رفض جوال مكرر لنفس النوع
q = urllib.parse.urlencode({"kind": "family", "name": "y", "mobile": "0500000001", "prev_bal_for": "", "prev_bal_on": ""})
status, body = req(BASE + "/families_api/save_party?" + q, data={}, method="POST")
res = json.loads(body)
check("reject duplicate mobile (same table)", res.get("ok") is False)

# 8) القائمة بعد الإضافة + تصفية النوع + البحث
status, body = req(BASE + "/families_api/get_parties?" + urllib.parse.urlencode({"SearchText": "اختبار_موحد"}))
res = json.loads(body)
rows = res.get("data") or []
check("search finds both test rows", res.get("count") == 2 and len(rows) == 2)
fam_row = next((r for r in rows if r["kind"] == "family"), None)
check("family row fields", fam_row
      and fam_row["reg_date"] == "2026-07-18"
      and abs(fam_row["prev_bal_for"] - 150.5) < 0.001
      and abs(fam_row["prev_bal_on"] - 40) < 0.001
      and fam_row["mobile"] == "0500000001", json.dumps(fam_row, ensure_ascii=False)[:160])

status, body = req(BASE + "/families_api/get_parties?" + urllib.parse.urlencode({"kind": "supplier", "SearchText": "اختبار_موحد"}))
res = json.loads(body)
check("kind filter supplier", res.get("count") == 1 and res["data"][0]["kind"] == "supplier")

# 9) تعديل المورد (الأرصدة والجوال)
q = urllib.parse.urlencode({
    "id": sup_id, "kind": "supplier", "name": "اختبار_موحد_مورد",
    "reg_date": "2026-07-18", "mobile": "0500000003",
    "prev_bal_for": "10", "prev_bal_on": "500",
})
status, body = req(BASE + "/families_api/save_party?" + q, data={}, method="POST")
res = json.loads(body)
check("edit supplier", res.get("ok") is True, body[:120])
status, body = req(BASE + "/families_api/get_parties?" + urllib.parse.urlencode({"kind": "supplier", "SearchText": "اختبار_موحد"}))
res = json.loads(body)
r0 = res["data"][0]
check("edit persisted", r0["mobile"] == "0500000003" and abs(r0["prev_bal_on"] - 500) < 0.001)

# 10) قفل وفتح السجل
q = urllib.parse.urlencode({"id": sup_id, "kind": "supplier"})
status, body = req(BASE + "/families_api/toggle_party_stop?" + q, data={}, method="POST")
res = json.loads(body)
check("toggle stop on", res.get("ok") is True and (res.get("data") or {}).get("stoped") is True)
status, body = req(BASE + "/families_api/toggle_party_stop?" + q, data={}, method="POST")
res = json.loads(body)
check("toggle stop off", res.get("ok") is True and (res.get("data") or {}).get("stoped") is False)

# تنظيف بيانات الاختبار مباشرة من قاعدة البيانات
con = sqlite3.connect(DB_PATH)
cur = con.cursor()
cur.execute("DELETE FROM families WHERE name LIKE 'اختبار_موحد%'")
cur.execute("DELETE FROM suppliers WHERE name LIKE 'اختبار_موحد%'")
con.commit()
left_f = cur.execute("SELECT COUNT(*) FROM families WHERE name LIKE 'اختبار_موحد%'").fetchone()[0]
left_s = cur.execute("SELECT COUNT(*) FROM suppliers WHERE name LIKE 'اختبار_موحد%'").fetchone()[0]
con.close()
check("cleanup test rows", left_f == 0 and left_s == 0)

print("\n=== RESULT: %d passed, %d failed ===" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
