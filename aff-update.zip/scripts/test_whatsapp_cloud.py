# -*- coding: utf-8 -*-
"""اختبارات وحدة ربط واتساب (modules/whatsapp_cloud.py) بلا اتصال حقيقي بميتا.

    python scripts/test_whatsapp_cloud.py
"""
import hashlib
import hmac
import json
import os
import re
import sys
import unittest

import httpx

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODULES = os.path.join(APP_ROOT, "modules")
if MODULES not in sys.path:
    sys.path.insert(0, MODULES)

import whatsapp_cloud as wa  # noqa: E402

CFG = {"token": "TEST-TOKEN", "phone_number_id": "123", "waba_id": "456", "api_version": "v26.0"}


def transport(status=200, body=None, capture=None, exc=None):
    """ناقل وهمي: يحفظ الطلب في capture ويعيد استجابة ثابتة أو يرفع خطأ اتصال."""
    def handler(request):
        if capture is not None:
            capture.append(request)
        if exc is not None:
            raise exc("simulated", request=request)
        return httpx.Response(status, json=body if body is not None else {})
    return httpx.MockTransport(handler)


class PreparationTests(unittest.TestCase):
    def test_normalizes_saudi_numbers(self):
        for raw in ("0551234567", "551234567", "966551234567", "+966551234567", "00966551234567"):
            self.assertEqual(wa.normalize_msisdn(raw), "966551234567", raw)
        for raw in ("", None, "12345", "0451234567", "05512345678"):
            self.assertIsNone(wa.normalize_msisdn(raw), raw)
        self.assertEqual(wa.local_mobile("966551234567"), "0551234567")

    def test_cleans_params_for_meta_rules(self):
        self.assertEqual(wa.clean_param("سطر\nثاني\tو     مسافات"), "سطر ثاني و مسافات")
        self.assertEqual(wa.clean_param(""), "-")
        self.assertEqual(wa.clean_param(None), "-")
        self.assertEqual(len(wa.clean_param("x" * 500)), 200)

    def test_formats_amounts(self):
        self.assertEqual(wa.fmt_amount(350), "350")
        self.assertEqual(wa.fmt_amount(350.5), "350.50")
        self.assertEqual(wa.fmt_amount(None), "0")

    def test_templates_follow_meta_variable_rules(self):
        for key, tpl in wa.TEMPLATES.items():
            body = tpl["body"]
            numbers = [int(n) for n in re.findall(r"\{\{(\d+)\}\}", body)]
            self.assertEqual(numbers, list(range(1, len(numbers) + 1)), key)
            self.assertEqual(len(tpl["example"]), len(numbers), key)
            self.assertFalse(body.lstrip().startswith("{{"), key)
            self.assertFalse(body.rstrip().endswith("}}"), key)
            self.assertIsNone(re.search(r"\}\}\s*\{\{", body), key)
            self.assertRegex(tpl["name"], r"^[a-z0-9_]+$")

    def test_preview_and_payload(self):
        params = wa.TEMPLATES["notice"]["example"]
        preview = wa.render_preview(wa.TEMPLATES["notice"]["body"], params)
        self.assertNotIn("{{", preview)
        self.assertIn("سند استلام", preview)
        payload = wa.build_template_payload("966551234567", "aff_transaction_notice", ["أ", "ب\nج"])
        self.assertEqual(payload["template"]["language"], {"code": "ar"})
        texts = [p["text"] for p in payload["template"]["components"][0]["parameters"]]
        self.assertEqual(texts, ["أ", "ب ج"])


class SendTests(unittest.TestCase):
    def test_success_returns_wamid_and_sends_expected_request(self):
        seen = []
        res = wa.send_template(
            CFG, "966551234567", "aff_transaction_notice", ["محمد", "سداد", "5", "100", "2026-10-03"],
            transport=transport(body={"messages": [{"id": "wamid.ABC", "message_status": "accepted"}]}, capture=seen),
        )
        self.assertTrue(res["ok"])
        self.assertEqual(res["wamid"], "wamid.ABC")
        request = seen[0]
        self.assertEqual(request.method, "POST")
        self.assertEqual(request.url.path, "/v26.0/123/messages")
        self.assertEqual(request.headers["Authorization"], "Bearer TEST-TOKEN")
        sent = json.loads(request.content.decode("utf-8"))
        self.assertEqual(sent["to"], "966551234567")
        self.assertEqual(sent["template"]["name"], "aff_transaction_notice")
        self.assertEqual(len(sent["template"]["components"][0]["parameters"]), 5)

    def test_permanent_error_is_not_retryable(self):
        body = {"error": {"message": "(#132001) Template name does not exist", "code": 132001,
                          "error_data": {"details": "template name does not exist in ar"}}}
        res = wa.send_template(CFG, "966551234567", "x", [], transport=transport(400, body))
        self.assertFalse(res["ok"])
        self.assertFalse(res["retryable"])
        self.assertEqual(res["error_code"], 132001)
        self.assertIn("القالب غير موجود", res["error_text"])
        self.assertIn("132001", res["error_text"])

    def test_rate_limits_and_server_errors_are_retryable(self):
        throttled = {"error": {"message": "throughput", "code": 130429}}
        self.assertTrue(wa.send_template(CFG, "1", "x", [], transport=transport(400, throttled))["retryable"])
        self.assertTrue(wa.send_template(CFG, "1", "x", [], transport=transport(503, {}))["retryable"])

    def test_connection_errors(self):
        # لم يصل الطلب: إعادة المحاولة آمنة
        res = wa.send_template(CFG, "1", "x", [], transport=transport(exc=httpx.ConnectError))
        self.assertFalse(res["ok"])
        self.assertTrue(res["retryable"])
        # انقطع الرد بعد الإرسال: قد تكون وصلت، فلا إعادة تلقائية
        res = wa.send_template(CFG, "1", "x", [], transport=transport(exc=httpx.ReadTimeout))
        self.assertFalse(res["ok"])
        self.assertFalse(res["retryable"])

    def test_missing_config_does_not_call_meta(self):
        seen = []
        res = wa.send_template({"token": ""}, "1", "x", [], transport=transport(capture=seen))
        self.assertFalse(res["ok"])
        self.assertEqual(seen, [])
        self.assertEqual(wa.missing_config({"token": "t"}), ["phone_number_id"])

    def test_unexpected_success_body(self):
        res = wa.send_template(CFG, "1", "x", [], transport=transport(body={"messages": []}))
        self.assertFalse(res["ok"])


class ManagementTests(unittest.TestCase):
    def test_template_status_marks_missing(self):
        body = {"data": [
            {"name": "aff_transaction_notice", "language": "ar", "status": "APPROVED", "category": "UTILITY"},
            {"name": "aff_account_statement", "language": "en", "status": "APPROVED", "category": "UTILITY"},
        ]}
        res = wa.template_status(CFG, transport=transport(body=body))
        self.assertTrue(res["ok"])
        status = {t["key"]: t["status"] for t in res["data"]}
        self.assertEqual(status, {"notice": "APPROVED", "statement": "MISSING"})

    def test_create_template_payload(self):
        seen = []
        res = wa.create_template(CFG, "statement",
                                 transport=transport(body={"id": "9", "status": "PENDING", "category": "UTILITY"},
                                                     capture=seen))
        self.assertTrue(res["ok"])
        self.assertEqual(seen[0].url.path, "/v26.0/456/message_templates")
        sent = json.loads(seen[0].content.decode("utf-8"))
        self.assertEqual(sent["language"], "ar")
        self.assertEqual(sent["category"], "UTILITY")
        self.assertEqual(sent["components"][0]["example"]["body_text"], [wa.TEMPLATES["statement"]["example"]])
        self.assertFalse(wa.create_template(CFG, "unknown")["ok"])

    def test_app_subscription(self):
        body = {"data": [{"whatsapp_business_api_data": {"id": "1", "name": "AFF App"}}]}
        res = wa.app_subscription(CFG, transport=transport(body=body))
        self.assertEqual(res["data"], {"subscribed": True, "apps": ["AFF App"]})
        res = wa.app_subscription(CFG, transport=transport(body={"data": []}))
        self.assertFalse(res["data"]["subscribed"])
        seen = []
        self.assertTrue(wa.subscribe_app(CFG, transport=transport(body={"success": True}, capture=seen))["ok"])
        self.assertEqual((seen[0].method, seen[0].url.path), ("POST", "/v26.0/456/subscribed_apps"))
        self.assertFalse(wa.subscribe_app(CFG, transport=transport(body={"success": False}))["ok"])

    def test_phone_info(self):
        seen = []
        body = {"display_phone_number": "+966 55 000 0000", "verified_name": "x",
                "quality_rating": "GREEN", "platform_type": "CLOUD_API", "id": "123"}
        res = wa.get_phone_info(CFG, transport=transport(body=body, capture=seen))
        self.assertTrue(res["ok"])
        self.assertEqual(res["data"]["quality_rating"], "GREEN")
        self.assertIn("fields=", str(seen[0].url))


class WebhookTests(unittest.TestCase):
    def test_signature(self):
        raw = '{"a":"\\u0645"}'.encode("utf-8")
        good = "sha256=" + hmac.new(b"secret", raw, hashlib.sha256).hexdigest()
        self.assertTrue(wa.verify_signature("secret", raw, good))
        self.assertFalse(wa.verify_signature("secret", raw + b" ", good))
        self.assertFalse(wa.verify_signature("", raw, good))
        self.assertFalse(wa.verify_signature("secret", raw, good[7:]))
        self.assertFalse(wa.verify_signature("secret", raw, None))

    def test_parse_statuses_and_messages(self):
        payload = {
            "object": "whatsapp_business_account",
            "entry": [{"id": "456", "changes": [
                {"field": "messages", "value": {
                    "messaging_product": "whatsapp",
                    "contacts": [{"wa_id": "966551234567", "profile": {"name": "Ali"}}],
                    "statuses": [
                        {"id": "wamid.1", "status": "delivered", "timestamp": "1790000000", "recipient_id": "966551234567"},
                        {"id": "wamid.2", "status": "failed", "timestamp": "1790000001", "recipient_id": "966551234567",
                         "errors": [{"code": 131026, "title": "Message undeliverable",
                                     "error_data": {"details": "not on WhatsApp"}}]},
                    ],
                    "messages": [
                        {"from": "966551234567", "id": "wamid.in1", "timestamp": "1790000002", "type": "text",
                         "text": {"body": "شكراً"}},
                        {"from": "966551234567", "id": "wamid.in2", "timestamp": "1790000003", "type": "image",
                         "image": {"caption": "فاتورة"}},
                    ],
                }},
                {"field": "smb_message_echoes", "value": {"messages": [{"id": "ignored"}]}},
            ]}],
        }
        statuses, inbound = wa.parse_webhook(payload)
        self.assertEqual([s["status"] for s in statuses], ["delivered", "failed"])
        self.assertEqual(statuses[1]["error_code"], 131026)
        self.assertEqual(statuses[1]["error_text"], "not on WhatsApp")
        self.assertIsNotNone(statuses[0]["timestamp"])
        self.assertEqual([m["wamid"] for m in inbound], ["wamid.in1", "wamid.in2"])
        self.assertEqual(inbound[0]["text"], "شكراً")
        self.assertEqual(inbound[0]["name"], "Ali")
        self.assertEqual(inbound[1]["text"], "[صورة] فاتورة")
        self.assertEqual(wa.parse_webhook({"object": "page"}), ([], []))
        self.assertEqual(wa.parse_webhook(None), ([], []))


if __name__ == "__main__":
    unittest.main()
