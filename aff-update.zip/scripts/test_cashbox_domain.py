# -*- coding: utf-8 -*-

import os
import sys
import unittest
from decimal import Decimal


APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODULES = os.path.join(APP_ROOT, "modules")
if MODULES not in sys.path:
    sys.path.insert(0, MODULES)

from cashbox_domain import (  # noqa: E402
    calculate_family_summary,
    calculate_separated_totals,
    calculate_totals,
    difference_needs_reason,
    money,
    validate_date_range,
)


class CashboxDomainTests(unittest.TestCase):
    def test_calculates_expected_actual_and_difference(self):
        totals = calculate_totals("100.10", "250.25", "50", "20", "80", "305.35")
        self.assertEqual(totals["total_in"], Decimal("400.35"))
        self.assertEqual(totals["total_out"], Decimal("100.00"))
        self.assertEqual(totals["closing_balance"], Decimal("300.35"))
        self.assertEqual(totals["cash_difference"], Decimal("5.00"))

    def test_uses_decimal_rounding(self):
        self.assertEqual(money("0.105"), Decimal("0.11"))

    def test_rejects_negative_and_non_numeric_money(self):
        with self.assertRaises(ValueError):
            money("-1")
        with self.assertRaises(ValueError):
            money("abc")

    def test_validates_date_range(self):
        validate_date_range("2026-08-01", "2026-08-31")
        with self.assertRaises(ValueError):
            validate_date_range("2026-08-31", "2026-08-01")

    def test_difference_requires_reason_only_when_nonzero(self):
        self.assertFalse(difference_needs_reason(Decimal("0.00")))
        self.assertTrue(difference_needs_reason(Decimal("0.01")))

    def test_separates_cash_and_bank_and_merges_pos_into_bank(self):
        totals = calculate_separated_totals(
            opening_cash="1000",
            cash_sales="300",
            bank_withdrawal="200",
            cash_expenses="50",
            cash_paid_to_parties="100",
            cash_deposit_to_bank="150",
            opening_bank="5000",
            bank_deposit="400",
            bank_paid_to_parties="700",
            bank_expenses="25",
            pos_sales="900",
            actual_closing_cash="1200",
            actual_closing_bank="5600",
        )
        self.assertEqual(totals["closing_balance"], Decimal("1200.00"))
        self.assertEqual(totals["pos_fees"], Decimal("7.20"))
        self.assertEqual(totals["pos_net_to_bank"], Decimal("892.80"))
        self.assertEqual(totals["bank_closing_balance"], Decimal("5517.80"))
        self.assertEqual(totals["cash_difference"], Decimal("0.00"))
        self.assertEqual(totals["bank_difference"], Decimal("82.20"))
        self.assertIsNone(totals["pos_difference"])
        self.assertEqual(totals["paid_to_suppliers"], Decimal("800.00"))

    def test_pos_fee_is_eight_riyals_per_thousand(self):
        totals = calculate_separated_totals(
            opening_cash="0",
            cash_sales="0",
            bank_withdrawal="0",
            cash_expenses="0",
            cash_paid_to_parties="0",
            cash_deposit_to_bank="0",
            opening_bank="0",
            bank_deposit="0",
            bank_paid_to_parties="0",
            bank_expenses="0",
            pos_sales="1000",
        )
        self.assertEqual(totals["pos_fees"], Decimal("8.00"))
        self.assertEqual(totals["bank_closing_balance"], Decimal("992.00"))

    def test_bank_to_cash_transfer_is_not_income(self):
        totals = calculate_separated_totals(
            opening_cash="100",
            cash_sales="0",
            bank_withdrawal="250",
            cash_expenses="0",
            cash_paid_to_parties="250",
            cash_deposit_to_bank="0",
            opening_bank="1000",
            bank_deposit="0",
            bank_paid_to_parties="0",
            bank_expenses="0",
            pos_sales="0",
        )
        self.assertEqual(totals["closing_balance"], Decimal("100.00"))
        self.assertEqual(totals["bank_closing_balance"], Decimal("750.00"))
        self.assertEqual(totals["net_sales"], Decimal("-250.00"))

    def test_rejects_overdrawn_separated_account(self):
        with self.assertRaises(ValueError):
            calculate_separated_totals(
                opening_cash="0",
                cash_sales="0",
                bank_withdrawal="100",
                cash_expenses="0",
                cash_paid_to_parties="0",
                cash_deposit_to_bank="0",
                opening_bank="50",
                bank_deposit="0",
                bank_paid_to_parties="0",
                bank_expenses="0",
                pos_sales="0",
            )

    def test_calculates_family_summary_and_rounds_each_family(self):
        summary = calculate_family_summary([{
            "family_id": 1,
            "family_name": "أسرة 1",
            "received": "1000",
            "returned": "100",
            "sale_percent": "10",
        }])
        self.assertEqual(summary["net_sales"], Decimal("900.00"))
        self.assertEqual(summary["commission_amount"], Decimal("90.00"))
        self.assertEqual(summary["net_amount"], Decimal("810.00"))
        self.assertEqual(summary["commission_rate"], Decimal("10.0000"))

    def test_family_summary_uses_weighted_rate_for_mixed_rates(self):
        summary = calculate_family_summary([
            {"received": "100", "returned": "0", "sale_percent": "10"},
            {"received": "300", "returned": "0", "sale_percent": "20"},
        ])
        self.assertEqual(summary["commission_amount"], Decimal("70.00"))
        self.assertEqual(summary["commission_rate"], Decimal("17.5000"))
        self.assertEqual(summary["net_amount"], Decimal("330.00"))

    def test_family_summary_handles_return_only_day(self):
        summary = calculate_family_summary([
            {"received": "0", "returned": "50", "sale_percent": "10"},
        ])
        self.assertEqual(summary["net_sales"], Decimal("-50.00"))
        self.assertEqual(summary["commission_amount"], Decimal("-5.00"))
        self.assertEqual(summary["net_amount"], Decimal("-45.00"))
        self.assertEqual(summary["commission_rate"], Decimal("10.0000"))


if __name__ == "__main__":
    unittest.main()
