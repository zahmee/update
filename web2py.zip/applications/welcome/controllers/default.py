# -*- coding: utf-8 -*-
# Welcome page of a fresh web2py environment (zahmee build): the server's root URL lands here.
# One page, no database, no session file. New applications are created from welcome.w2p
# (admin > New application), not from this app.
import sys


def index():
    session.forget(response)
    version, _, build = (request.env.web2py_version or "").partition("+")
    stamp = build.replace("timestamp.", "").split(".")
    return dict(
        version=version,
        built="-".join(stamp[:3]) if len(stamp) >= 3 else "",
        python=sys.version.split()[0],
        secure=request.is_https or request.is_local,
    )
