#!/usr/bin/env bash
# Start web2py (Rocket) inside the uv-managed environment — development and small installs.
#   Python version from .python-version, packages from uv.lock (installed/updated automatically).
#   "<recycle>" reuses the admin password saved for this port (parameters_<port>.py).
# Production on Linux: deploy/README.md (systemd + gunicorn + nginx).
# Extra arguments are passed through, e.g.:  ./start.sh -p 8099
# First run of a fresh copy (no saved password yet):  ./start.sh -a <password>
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONUTF8=1   # UTF-8 file I/O whatever the server locale (Arabic config/text files)
exec uv run web2py.py -a "<recycle>" "$@"
