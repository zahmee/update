@echo off
rem Copy one application (optionally with its database) to a server that runs web2py - see README.md.
rem   deploy-app.cmd                                 asks for the application, server and SSH user
rem   deploy-app.cmd -App asbab5 -Server 192.168.20.128 -User zahmee -WithDatabase
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\windows\deploy-app.ps1" %*
if "%~1"=="" pause
