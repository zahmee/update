@echo off
rem Start web2py inside the uv-managed environment:
rem   Python version from .python-version, packages from uv.lock (installed/updated automatically).
rem   "<recycle>" reuses the admin password saved for this port (parameters_<port>.py).
rem Extra arguments are passed through, e.g.:  start.bat -p 8099
rem First run of a fresh copy (no saved password yet):  start.bat -a <password>
cd /d "%~dp0"
rem UTF-8 file I/O whatever the Windows code page (Arabic config/text files)
set PYTHONUTF8=1
uv run web2py.py -a "<recycle>" %*
