#!/usr/bin/env bash
# Remove expired session files of every application (web2py's scripts/sessions2trash.py,
# once per app). Run by the systemd timer <name>-sessions.timer installed by setup-server.sh,
# or by hand from the web2py folder:  deploy/sessions2trash-all.sh [expiration-seconds]
set -uo pipefail
cd "$(dirname "$0")/.."
EXPIRATION="${1:-86400}"          # sessions untouched for a day are deleted (auth expiration wins when set)
export PYTHONUTF8=1
PY=".venv/bin/python"
[[ -x "$PY" ]] || PY="$(command -v python3)"
for dir in applications/*/; do
  app="${dir%/}"; app="${app#applications/}"
  [[ -d "applications/$app/sessions" && -d "applications/$app/models" ]] || continue
  "$PY" web2py.py -Q -S "$app" -M -R scripts/sessions2trash.py -A -o -x "$EXPIRATION" >/dev/null 2>&1 \
    || echo "sessions2trash: $app failed" >&2
done
