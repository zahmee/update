#!/usr/bin/env bash
# =============================================================================
#  Install an application on a server set up with deploy/setup-server.sh, or refresh its code.
#  Normally run for you by deploy-app.cmd on Windows; by hand:
#
#     sudo bash deploy/install-app.sh <app>.tar.gz [--db-dump <app>.dump] [--update] [--replace-db]
#                                     [--dir <web2py folder>] [--name <service name>]
#
#  <app>.tar.gz = the application folder without sessions, errors, cache, backups and development
#  folders (deploy/tools/pack.py app).
#   - a NEW application is copied with its private/ (appconfig.ini), databases/ and uploads/
#   - an application that already exists is never replaced; with --update only its code is
#     refreshed (models, controllers, views, modules, languages, static, ...), while private/,
#     databases/, uploads/ and sessions stay as they are (a backup goes to <dir>/backups)
#   - --db-dump restores a PostgreSQL dump (pg_dump -Fc) into the database named in the app's
#     settings: PostgreSQL is installed when that database is on this server, and the role and
#     the database are created as the settings say. A database that already has tables is left
#     alone unless --replace-db.
# =============================================================================
set -Eeuo pipefail
# psql under an ssh -t terminal would open a pager and wait for a key press (seen on the test server)
export PAGER=cat PSQL_PAGER=cat

ARCHIVE=""; DUMP=""; UPDATE=0; REPLACE_DB=0; DIR=""; NAME=web2py
usage() { sed -n '3,19p' "$0"; exit "${1:-0}"; }
while [[ $# -gt 0 ]]; do
  case "$1" in
    --db-dump) DUMP="$2"; shift 2 ;;
    --update) UPDATE=1; shift ;;
    --replace-db) REPLACE_DB=1; shift ;;
    --dir) DIR="${2%/}"; shift 2 ;;
    --name) NAME="$2"; shift 2 ;;
    -h|--help) usage 0 ;;
    -*) echo "unknown option: $1" >&2; usage 1 ;;
    *) ARCHIVE="$1"; shift ;;
  esac
done

log()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf 'WARNING: %s\n' "$*" >&2; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || fail "run as root:  sudo bash $0 ..."
[[ -n "$ARCHIVE" && -f "$ARCHIVE" ]] || { echo "application archive missing" >&2; usage 1; }
[[ -z "$DUMP" || -f "$DUMP" ]] || fail "database dump not found: $DUMP"
# shellcheck source=deploy/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

[[ -n "$DIR" ]] || DIR="$(detect_install_dir "$NAME")"
[[ -n "$DIR" && -d "$DIR/gluon" && -x "$DIR/.venv/bin/python" ]] \
  || fail "web2py is not installed on this server yet: run deploy/setup-server.sh first (or pass --dir)"
SVC_USER="$(install_owner "$DIR")"; SVC_USER="${SVC_USER:-web2py}"
SVC_GROUP="$(id -gn "$SVC_USER")"
STAMP="$(date +%Y%m%d-%H%M%S)"

# (|| true: head closes the pipe early, and pipefail would turn tar's SIGPIPE into a failure)
APP="$(tar -tzf "$ARCHIVE" 2>/dev/null | head -1 | cut -d/ -f1 || true)"
[[ "$APP" =~ ^[A-Za-z0-9_]+$ ]] || fail "unexpected archive layout (first entry: $APP)"
[[ "$APP" != admin ]] || fail "the admin app comes with the framework (deploy/setup-server.sh)"
TARGET="$DIR/applications/$APP"
WORK="$(mktemp -d /tmp/w2p-app.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT
chmod 755 "$WORK"
tar -xzf "$ARCHIVE" -C "$WORK"
[[ -d "$WORK/$APP/controllers" || -d "$WORK/$APP/models" ]] || fail "$APP does not look like a web2py application"

# ---------------------------------------------------------------- files
if [[ -d "$TARGET" ]]; then
  [[ $UPDATE -eq 1 ]] || fail "$APP is already installed in $TARGET and was left untouched (use --update to refresh its code only)"
  log "$APP: update code only (private/, databases/, uploads/, sessions kept)"
  mkdir -p "$DIR/backups"
  tar -czf "$DIR/backups/app-$APP-$STAMP.tar.gz" -C "$DIR/applications" \
      --exclude="$APP/sessions" --exclude="$APP/errors" --exclude="$APP/cache" --exclude="$APP/uploads" "$APP"
  echo "backup of the previous code -> $DIR/backups/app-$APP-$STAMP.tar.gz"
  for d in models controllers views modules languages cron scripts tests; do
    [[ -d "$WORK/$APP/$d" ]] && rsync -a --delete "$WORK/$APP/$d/" "$TARGET/$d/"
  done
  [[ -d "$WORK/$APP/static" ]] && rsync -a "$WORK/$APP/static/" "$TARGET/static/"
  find "$WORK/$APP" -maxdepth 1 -type f -exec cp -f {} "$TARGET/" \;
  [[ -n "$DUMP" ]] && warn "--db-dump ignored with --update: an installed application keeps its database"
  DUMP=""
else
  log "$APP: new application -> $TARGET"
  mv "$WORK/$APP" "$TARGET"
fi
chown -R "$SVC_USER:$SVC_GROUP" "$TARGET"
[[ -d "$TARGET/private" ]] && chmod 700 "$TARGET/private"
chmod o+x "$DIR/applications" "$TARGET"                         # nginx serves static/ directly
[[ -d "$TARGET/static" ]] && chmod -R o+rX "$TARGET/static"

# ---------------------------------------------------------------- database
db_settings() {   # DB_* variables from the app's appconfig.ini [db] uri, or a DAL('postgres://...') in models
  "$DIR/.venv/bin/python" - "$TARGET" <<'PY'
import configparser, glob, os, re, shlex, sys
from urllib.parse import unquote, urlsplit
app, uri = sys.argv[1], ""
ini = os.path.join(app, "private", "appconfig.ini")
if os.path.exists(ini):
    cp = configparser.RawConfigParser(inline_comment_prefixes=(";", "#"))
    cp.read(ini, encoding="utf8")
    if cp.has_option("db", "uri"):
        uri = cp.get("db", "uri").strip()
if not uri.startswith("postgres"):
    for f in sorted(glob.glob(os.path.join(app, "models", "*.py"))):
        m = re.search(r"""DAL\(\s*['"](postgres[^'"]+)['"]""", open(f, encoding="utf8", errors="replace").read())
        if m:
            uri = m.group(1)
            break
if not uri.startswith("postgres"):
    print("DB_KIND=" + shlex.quote(uri.split(":", 1)[0] or "none"))
    sys.exit()
u = urlsplit(re.sub(r"^postgres(ql)?(:\w+)?://", "postgres://", uri))
for k, v in (("DB_KIND", "postgres"), ("DB_USER", unquote(u.username or "")), ("DB_PASS", unquote(u.password or "")),
             ("DB_HOST", u.hostname or "localhost"), ("DB_PORT", str(u.port or 5432)), ("DB_NAME", u.path.lstrip("/"))):
    print(f"{k}={shlex.quote(v)}")
PY
}

if [[ -n "$DUMP" ]]; then
  DB_KIND=""; DB_USER=""; DB_PASS=""; DB_HOST=""; DB_PORT=""; DB_NAME=""
  eval "$(db_settings)"
  [[ "$DB_KIND" == postgres ]] || fail "$APP uses '$DB_KIND', not PostgreSQL: its data travels in databases/ (the dump is not needed)"
  [[ -n "$DB_USER" && -n "$DB_NAME" ]] || fail "incomplete PostgreSQL uri in $APP's settings"
  case "$DB_HOST" in
    localhost|127.0.0.1|::1) ;;
    *) fail "$APP's database lives on $DB_HOST: restore the dump on that server" ;;
  esac
  log "PostgreSQL: database $DB_NAME (role $DB_USER) on this server"
  if ! dpkg -s postgresql >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq && apt-get install -y -qq postgresql >/dev/null
  fi
  systemctl enable --now postgresql >/dev/null 2>&1 || true
  for _ in $(seq 1 30); do runuser -u postgres -- psql -qtAc 'SELECT 1' >/dev/null 2>&1 && break; sleep 1; done
  psql_su() { runuser -u postgres -- psql -X -P pager=off -v ON_ERROR_STOP=1 -qtA "$@"; }
  sqlq() { printf '%s' "${1//\'/\'\'}"; }            # SQL string literal content
  ident() { printf '"%s"' "${1//\"/\"\"}"; }          # SQL identifier

  if [[ -z "$(psql_su -c "SELECT 1 FROM pg_roles WHERE rolname = '$(sqlq "$DB_USER")'")" ]]; then
    # the password travels on stdin, never on a command line
    psql_su <<SQL
CREATE ROLE $(ident "$DB_USER") LOGIN CREATEDB PASSWORD '$(sqlq "$DB_PASS")';
SQL
    echo "role $DB_USER created"
  fi
  if [[ -n "$(psql_su -c "SELECT 1 FROM pg_database WHERE datname = '$(sqlq "$DB_NAME")'")" ]]; then
    ntab="$(psql_su -d "$DB_NAME" -c "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public'")"
    if [[ "$ntab" != 0 ]]; then
      [[ $REPLACE_DB -eq 1 ]] || fail "database $DB_NAME already has $ntab tables and was left untouched (--replace-db to drop it and restore the dump)"
      log "Dropping database $DB_NAME (--replace-db)"
      psql_su -c "DROP DATABASE $(ident "$DB_NAME") WITH (FORCE)"
      psql_su -c "CREATE DATABASE $(ident "$DB_NAME") OWNER $(ident "$DB_USER")"
    fi
  else
    psql_su -c "CREATE DATABASE $(ident "$DB_NAME") OWNER $(ident "$DB_USER")"
  fi
  install -m 644 "$DUMP" "$WORK/db.dump"                           # readable by the postgres user
  start=$(date +%s)
  # objects are created by the app's role (SET ROLE), so they belong to it like on the old server
  runuser -u postgres -- pg_restore --no-owner --no-privileges --role="$DB_USER" -j "$(nproc)" \
       -d "$DB_NAME" "$WORK/db.dump" 2>"$WORK/restore.err" || true
  # harmless and expected: the dump comments on the built-in plpgsql extension, which only its
  # owner (postgres) may do; everything else is reported
  grep 'error:' "$WORK/restore.err" | grep -v 'extension plpgsql' >"$WORK/restore.real" || true
  if [[ -s "$WORK/restore.real" ]]; then
    warn "pg_restore reported $(wc -l <"$WORK/restore.real") error(s):"
    head -5 "$WORK/restore.real" >&2
  else
    echo "restored in $(( $(date +%s) - start ))s"
  fi
  psql_su -d "$DB_NAME" -c "SELECT 'tables: ' || count(*) FROM information_schema.tables WHERE table_schema = 'public'"
  if PGPASSWORD="$DB_PASS" psql -X -w -h 127.0.0.1 -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -qtAc 'SELECT 1' >/dev/null 2>&1; then
    echo "the application's own login to $DB_NAME works"
  else
    warn "role $DB_USER existed with another password: the app cannot log in to $DB_NAME until the password in its appconfig.ini and the role match"
  fi
fi

# ---------------------------------------------------------------- restart + check
log "Restart $NAME and check $APP"
systemctl restart "$NAME" 2>/dev/null || warn "could not restart $NAME.service"
code=000
for _ in $(seq 1 60); do       # 502/503/504: nginx is up but the restarted service is not ready yet
  code="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 30 "https://127.0.0.1/$APP/default/index" || true)"
  [[ "$code" == 000 ]] && code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1/$APP/default/index" || true)"
  [[ "$code" =~ ^(000|502|503|504)$ ]] || break
  sleep 1
done
echo "$APP/default/index -> HTTP $code"
if [[ "$code" =~ ^5 ]]; then
  last="$(ls -1t "$TARGET/errors" 2>/dev/null | head -1 || true)"
  if [[ -n "$last" ]]; then
    warn "error ticket $last:"
    runuser -u "$SVC_USER" -- "$DIR/.venv/bin/python" -c "
import pickle, sys; sys.path.insert(0, '$DIR')
t = pickle.load(open('$TARGET/errors/$last', 'rb'))
print('\n'.join((t.get('traceback') or '').strip().splitlines()[-8:]))" >&2 || true
  fi
  exit 1
fi
echo "done: $APP is installed in $TARGET"
