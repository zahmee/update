# Shared helpers of deploy/setup-server.sh and deploy/install-app.sh (sourced, not run).

# Folder of an existing web2py installation on this server, or nothing:
# the systemd unit's WorkingDirectory, then the chdir of a classic uWSGI config (also one this
# kit moved aside), then the usual folders.
detect_install_dir() {
  local name="${1:-web2py}" d f
  d="$(systemctl show -p WorkingDirectory --value "$name.service" 2>/dev/null || true)"
  [[ -n "$d" && -d "$d/gluon" ]] && { echo "$d"; return 0; }
  for f in "/etc/uwsgi/$name.ini" "/etc/uwsgi/$name.xml" "/etc/uwsgi/apps-enabled/$name.ini" \
           "/etc/uwsgi/apps-enabled/$name.xml" /etc/uwsgi/"$name".ini.disabled-* /etc/uwsgi/"$name".xml.disabled-*; do
    [[ -f "$f" ]] || continue
    d="$(sed -nE 's#.*<chdir>([^<]+)</chdir>.*#\1#p; s#^[[:space:]]*chdir[[:space:]]*=[[:space:]]*([^[:space:];]+).*#\1#p' "$f" | head -1 || true)"
    [[ -n "$d" && -d "$d/gluon" ]] && { echo "$d"; return 0; }
  done
  for d in /opt/web2py /home/www-data/web2py /var/www/web2py /srv/web2py; do
    [[ -d "$d/gluon" ]] && { echo "$d"; return 0; }
  done
  return 0
}

# Owner of an installation's files (the service user), or nothing for root-owned trees.
install_owner() {
  local owner
  owner="$(stat -c %U "$1/gluon" 2>/dev/null || true)"
  [[ -n "$owner" && "$owner" != root && "$owner" != UNKNOWN ]] && echo "$owner"
  return 0
}
