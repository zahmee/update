<#
.SYNOPSIS
  Install or update web2py on a Linux server (new or existing) in one step, from this PC.

.DESCRIPTION
  Packs the standalone copy (D:\new_web2py), uploads it and runs deploy/setup-server.sh there.
  A new server gets web2py in /opt/web2py; an existing server is found and updated in place,
  keeping its applications, HTTPS certificate, service user and admin password.
  D:\new_web2py is the deployment base. Run from the development folder (D:\web2py) this script
  first refreshes it in place (what you added there is kept).

.EXAMPLE
  deploy.cmd
  deploy.cmd -Server 192.168.20.128 -User zahmee
  deploy.cmd -Server 203.0.113.5 -User root -Options "--domain example.com --email me@example.com"
  deploy.cmd -Server 192.168.20.128 -User zahmee -InstallKey
#>
param(
    [string]$Server,
    [string]$User,
    [string]$Options = "",
    [string]$Key = "",
    [switch]$InstallKey
)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
if (-not (Test-Path (Join-Path $root ".web2py-standalone"))) {
    Write-Step "Refreshing the deployment base D:\new_web2py from $root"
    Push-Location $root
    try { Invoke-Native "uv" @("run", "python", "scripts/make_standalone.py") } finally { Pop-Location }
    $root = "D:\new_web2py"
}

$target = Read-Target $Server $User
$server = $target.Split("@")[1]
if ($InstallKey) { Install-SshKey $target }
$ssh = Get-SshOpts $Key

$archive = Join-Path $env:TEMP "new_web2py-upload.tar.gz"
Write-Step "Packing $root"
Invoke-Py @((Join-Path $root "deploy\tools\pack.py"), "framework", $root, $archive)

Write-Step "Uploading to $target"
Invoke-Native "scp" ($ssh + @("-q", $archive, "${target}:web2py-upload.tar.gz"))
Remove-Item $archive -Force

Write-Step "Installing on $server (sudo asks for the password of the SSH user)"
$remote = "set -e; rm -rf ~/web2py-upload; mkdir -p ~/web2py-upload; " +
          "tar -xzf ~/web2py-upload.tar.gz -C ~/web2py-upload; rm -f ~/web2py-upload.tar.gz; " +
          "sudo bash ~/web2py-upload/new_web2py/deploy/setup-server.sh $Options"
Invoke-Native "ssh" ($ssh + @("-t", $target, $remote))

Write-Host ""
Write-Host "web2py is installed on $server." -ForegroundColor Green
Write-Host "Admin: https://$server/admin  (with a self-signed certificate the browser asks once to accept it)"
Write-Host "Add an application:  deploy-app.cmd -App <name> -Server $server -User $($target.Split('@')[0])"
