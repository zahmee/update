# Shared helpers of deploy.ps1 and deploy-app.ps1 (dot-sourced).
# ASCII only: Windows PowerShell 5.1 reads scripts without a BOM as ANSI.

$DeployKey = Join-Path $env:USERPROFILE ".ssh\id_ed25519_web2py"

function Write-Step([string]$Text) {
    Write-Host ""
    Write-Host "==> $Text" -ForegroundColor Cyan
}

function Invoke-Native([string]$Exe, [string[]]$ArgList) {
    & $Exe @ArgList
    if ($LASTEXITCODE -ne 0) { throw "$Exe failed (exit code $LASTEXITCODE)" }
}

# Python for deploy/tools/pack.py (standard library only): uv's Python, else python on PATH.
function Invoke-Py([string[]]$ArgList) {
    if (Get-Command uv -ErrorAction SilentlyContinue) {
        & uv run --no-project --quiet python @ArgList
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python @ArgList
    } else {
        throw "Neither uv nor python was found on this PC"
    }
    if ($LASTEXITCODE -ne 0) { throw "python $($ArgList -join ' ') failed (exit code $LASTEXITCODE)" }
}

# ssh/scp options: the deploy key when it exists (created with -InstallKey), else password login.
function Get-SshOpts([string]$Key) {
    $opts = @("-o", "ServerAliveInterval=30")
    if (-not $Key -and (Test-Path $DeployKey)) { $Key = $DeployKey }
    if ($Key) { $opts += @("-i", $Key) }
    return ,$opts
}

# One-time: create ~/.ssh/id_ed25519_web2py and add it to the server, so later deployments
# only ask for the sudo password (the SSH password is asked once, here).
function Install-SshKey([string]$Target) {
    if (-not (Test-Path $DeployKey)) {
        New-Item -ItemType Directory -Force (Split-Path $DeployKey) | Out-Null
        & cmd /c "ssh-keygen -q -t ed25519 -N `"`" -C web2py-deploy -f `"$DeployKey`""
        if ($LASTEXITCODE -ne 0) { throw "ssh-keygen failed" }
    }
    Write-Step "Adding the deploy key to $Target (asks for the SSH password once)"
    Get-Content "$DeployKey.pub" | & ssh $Target "umask 077; mkdir -p ~/.ssh; tr -d '\r' >> ~/.ssh/authorized_keys; echo key-installed"
    if ($LASTEXITCODE -ne 0) { throw "could not add the key to $Target" }
}

function Read-Target([string]$Server, [string]$User) {
    if (-not $Server) { $Server = Read-Host "Server (IP address or host name)" }
    if (-not $User) { $User = Read-Host "SSH user on $Server" }
    if (-not $Server -or -not $User) { throw "server and user are required" }
    return "$User@$Server"
}
