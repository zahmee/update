<#
.SYNOPSIS
  Copy one application to a server that already runs web2py (deploy.cmd), optionally with its data.

.DESCRIPTION
  Packs applications\<App> without sessions, errors, cache, backups and development folders,
  uploads it and runs deploy/install-app.sh there. The application is taken from the applications
  folder next to this script (D:\new_web2py\applications: welcome, or an app copied there), else
  from D:\web2py\applications; -AppsRoot overrides both.
    - a new application is installed with its private\appconfig.ini, databases\ and uploads\
    - an application that already exists on the server is left untouched, unless -Update:
      then only its code is refreshed and its settings, data and uploads stay
    - -WithDatabase also copies the app's PostgreSQL database (pg_dump here, pg_restore there);
      a server database that already has tables is never replaced unless -ReplaceDb

.EXAMPLE
  deploy-app.cmd -App asbab5 -Server 192.168.20.128 -User zahmee -WithDatabase
  deploy-app.cmd -App zah -Server 192.168.20.128 -User zahmee
  deploy-app.cmd -App asbab5 -Server 192.168.20.128 -User zahmee -Update
#>
param(
    [string]$App,
    [string]$Server,
    [string]$User,
    [string]$AppsRoot = "",
    [switch]$WithDatabase,
    [switch]$Update,
    [switch]$ReplaceDb,
    [string]$Key = ""
)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$pack = Join-Path $root "deploy\tools\pack.py"
if (-not $App) { $App = Read-Host "Application (folder name in applications)" }
if (-not $AppsRoot) {
    $AppsRoot = "D:\web2py\applications"
    $local = Join-Path $root "applications"
    if (Test-Path (Join-Path $local "$App\controllers")) { $AppsRoot = $local }
}
$appDir = Join-Path $AppsRoot $App
if (-not (Test-Path (Join-Path $appDir "controllers"))) { throw "$appDir is not a web2py application" }
$target = Read-Target $Server $User
$server = $target.Split("@")[1]
$ssh = Get-SshOpts $Key

$packArgs = @($pack, "app", $appDir)
$bundle = Join-Path $env:TEMP "w2p-app-$App.tar.gz"
$withDump = $false
if ($WithDatabase -and -not $Update) {
    $kind = (Invoke-Py @($pack, "dbinfo", $appDir)) | Select-Object -Last 1
    if ($kind -eq "postgres") { $withDump = $true }
    else { Write-Host "$App uses '$kind': its data is inside databases\ and travels with the application." }
}
Write-Step "Packing $appDir$(if ($withDump) { ' + its PostgreSQL database' })"
$packArgs += @($bundle)
if ($withDump) { $packArgs += "--with-db" }
Invoke-Py $packArgs

try {
    Write-Step "Uploading to $target"
    Invoke-Native "scp" ($ssh + @("-q", $bundle, "${target}:w2p-app-upload.tar.gz"))
} finally {
    Remove-Item $bundle -Force -ErrorAction SilentlyContinue      # may hold a database dump
}

$flags = ""
if ($withDump) { $flags += " --db-dump ~/w2p-app/$App.dump" }
if ($Update) { $flags += " --update" }
if ($ReplaceDb) { $flags += " --replace-db" }
Write-Step "Installing $App on $server (sudo asks for the password of the SSH user)"
$remote = "rm -rf ~/w2p-app; tar -xzf ~/w2p-app-upload.tar.gz -C ~ && rm -f ~/w2p-app-upload.tar.gz && " +
          "sudo bash ~/w2p-app/install-app.sh ~/w2p-app/$App.tar.gz$flags; rc=`$?; rm -rf ~/w2p-app; exit `$rc"
Invoke-Native "ssh" ($ssh + @("-t", $target, $remote))

Write-Host ""
Write-Host "$App is running on $server." -ForegroundColor Green
