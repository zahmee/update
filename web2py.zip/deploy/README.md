# نشر web2py 3.3.3-zahmee على خادم لينكس

`deploy/setup-server.sh` يثبّت الإطار على خادم جديد **أو يحدّث** خادماً قائماً، من النسخة المستقلة
`D:\new_web2py` التي ينتجها `scripts/make_standalone.py` (الإطار مع تطبيقيه `admin` و`welcome`)،
و`deploy/install-app.sh` يضيف إليه التطبيقات. مُختبَر على Ubuntu 24.04 و26.04 مع Python 3.14 (عبر uv) وgunicorn/uWSGI وnginx وPostgreSQL.

> **من ويندوز يكفي أمر واحد لكل حالة** (يرفع ويشغّل هذين السكربتين على الخادم):
> `deploy.cmd -Server <ip> -User <user>` للإطار (جديد أو تحديث)، و
> `deploy-app.cmd -App <name> -Server <ip> -User <user> [-WithDatabase] [-Update]` للتطبيقات.
> التفاصيل في `README.md` في جذر النسخة. هذا الملف للتشغيل اليدوي على الخادم.

## ما الذي ينشئه السكربت

| العنصر | التفاصيل |
|---|---|
| حزم النظام | `rsync`، عميل PostgreSQL، مكتبات Pango وخطوط Noto (تصدير PDF)، nginx، وأدوات البناء عند اختيار uWSGI |
| مستخدم الخدمة | `web2py` في الخادم الجديد؛ في التحديث مالك الملفات الحالي (مثل `www-data`)، و`--user` يتجاوزه |
| البيئة | uv + Python من `.python-version` + المكتبات من `uv.lock` حرفياً داخل `<dir>/.venv`؛ ذاكرة uv ونسخ بايثون داخل `<dir>/.uv-cache` و`<dir>/.uv-python` (مملوكة لمستخدم الخدمة) |
| خادم التطبيق | `gunicorn` (افتراضي، بلا ترجمة) أو `uwsgi` (`--server uwsgi`، يُترجَم داخل البيئة) كخدمة systemd باسم `--name` (افتراضي `web2py`) |
| nginx | موقع باسم الخدمة: الملفات الثابتة من القرص، حدّ الرفع (`--upload-limit`)، ضغط gzip، ترويسات أمان، TLS اختياري |
| تنظيف الجلسات | `web2py-sessions.timer` يومياً يشغّل `deploy/sessions2trash-all.sh` لكل التطبيقات |
| كلمة مرور الإدارة | `parameters_443.py` و`parameters_80.py` و`parameters_<port>.py` (نفس الكلمة) |

## خادم جديد

```bash
tar -xzf new_web2py.tar.gz && cd new_web2py
sudo bash deploy/setup-server.sh --admin-password 'كلمة-قوية'
sudo bash deploy/setup-server.sh --domain example.com --email admin@example.com --admin-password 'كلمة-قوية'
```

ثم أضف التطبيقات. كل تطبيق أرشيف `<app>.tar.gz` (من `deploy/tools/pack.py app`، أو ينشئه `deploy-app.cmd`):

```bash
sudo bash deploy/install-app.sh zah.tar.gz                           # تطبيق جديد مع إعداده وبياناته (sqlite)
sudo bash deploy/install-app.sh asbab5.tar.gz --db-dump asbab5.dump  # مع استعادة قاعدة PostgreSQL
sudo bash deploy/install-app.sh asbab5.tar.gz --update               # الكود فقط لتطبيق موجود
```

`install-app.sh` لا يستبدل تطبيقاً موجوداً بلا `--update` (وحينها تبقى `private/` و`databases/` و`uploads/`
والجلسات، وتُحفظ نسخة من الكود السابق في `<dir>/backups`)، ولا يكتب فوق قاعدة فيها جداول بلا
`--replace-db`. مع `--db-dump` يُثبّت PostgreSQL إن كانت القاعدة على الخادم نفسه، ويُنشئ الدور (بصلاحية
`LOGIN CREATEDB` لا مدير) والقاعدة كما في إعداد التطبيق، وتُستعاد الجداول مملوكة لدور التطبيق.

## تحديث خادم قائم (الحالة الأساسية)

السكربت لا يمس `applications/` (ولا `private/` ولا `databases/` ولا `uploads/` ولا `sessions/`) باستثناء
تطبيق `admin` الذي **يجب** أن يطابق نسخة النواة فيُستبدل من `applications/admin` في النسخة مع الإبقاء على مجلداته
التشغيلية. قبل التحديث يُحفظ `gluon/` القديم و`admin` في `<dir>/backups/framework-<تاريخ>.tar.gz`
(آخر 5 نسخ).

والتحديث يحافظ على طريقة الوصول إلى الخادم كما كانت، دون أي خيار إضافي:

- **HTTPS**: إن كان موقع nginx القائم يعمل بشهادة (ذاتية من السكربت الكلاسيكي في `/etc/nginx/ssl/web2py.crt`،
  أو Let's Encrypt) تُستخدم الشهادة نفسها، ويبقى المنفذ 80 محوّلاً إلى 443.
- **اسم الموقع** (`server_name`) و**مستخدم الخدمة** (مالك الملفات الحالي، مثل `www-data`).
- **كلمة مرور الإدارة**: الملف الموجود (`parameters_443.py` عادة) يُنسخ للمنافذ 443 و80 ومنفذ الخلفية.
- ملف موقع nginx السابق يُحفظ في `<dir>/backups/nginx-<name>-<تاريخ>.conf` قبل استبداله.

```bash
sudo bash deploy/setup-server.sh
```

بلا خيارات: مكان التثبيت القائم يُكتشف وحده (مجلد خدمة systemd، أو `chdir` في إعداد uWSGI الكلاسيكي،
أو `/opt/web2py` و`/home/www-data/web2py` و`/var/www/web2py` و`/srv/web2py`)، و`--dir` يتجاوز ذلك.
على خادم ثُبّت بسكربت web2py الكلاسيكي يوقف السكربت وحدة `emperor.uwsgi` القديمة ويزيح إعداد uWSGI
القديم جانباً (`--keep-legacy` لتركها)، ويكتب خدمة systemd جديدة (gunicorn، أو `--server uwsgi`).
كود التطبيقات المكتوب لـ web2py 2.x يعمل كما هو، فطبقة التوافق `gluon/_compat.py` تغطي ما حذفه الإصدار 3؛
وراجع بعد التحديث تذاكر الأخطاء في كل تطبيق.

## الخيارات

| الخيار | الافتراضي | الغرض |
|---|---|---|
| `--dir` | `/opt/web2py` | مجلد التثبيت |
| `--user` | `web2py` | مستخدم الخدمة |
| `--name` | `web2py` | اسم خدمة systemd وموقع nginx (لتثبيت أكثر من نسخة على خادم واحد) |
| `--server` | `gunicorn` | `gunicorn` أو `uwsgi` |
| `--port` | `8000` | منفذ الخلفية (gunicorn، أو uwsgi مع `--no-nginx`) |
| `--workers` / `--threads` | 2 / 8 | العمليات والخيوط |
| `--domain` / `--email` | — | اسم النطاق؛ مع البريد تُصدر شهادة Let's Encrypt |
| `--self-signed` / `--no-tls` | تلقائي | شهادة ذاتية (10 سنوات) أو HTTP فقط. التلقائي: Let's Encrypt مع `--domain` و`--email`، وإلا ما كان عليه الخادم عند التحديث، وإلا شهادة ذاتية لخادم جديد (لوحة الإدارة لا تقبل الدخول عبر HTTP) |
| `--upload-limit` | `200m` | حدّ الرفع في nginx |
| `--admin-password` / `--no-password` / `--password-only` | — | كلمة مرور لوحة الإدارة |
| `--no-nginx` | — | بلا nginx (خلف موازن أحمال آخر) |
| `--apt-upgrade` | — | ترقية حزم النظام كلها |
| `--no-backup` / `--keep-legacy` | — | بلا نسخة احتياطية / عدم إيقاف uwsgi-emperor القديم |

### اتصالات PostgreSQL (قبل زيادة العمليات)

كل عملية تحتفظ لكل تطبيق بعدد `pool_size` من الاتصالات إضافة إلى اتصال لكل خيط مشغول:

```
العمليات × (مجموع pool_size للتطبيقات + الخيوط)  <  max_connections
```

الإعداد الافتراضي (عمليتان × 8 خيوط) آمن مع التطبيقات الحالية. لزيادة العمليات ارفع `max_connections`
في `postgresql.conf` أو خفّض `pool_size` في `appconfig.ini`.

## التشغيل اليومي

| المهمة | الأمر |
|---|---|
| الحالة | `systemctl status web2py` |
| السجل الحي | `journalctl -u web2py -f` |
| إعادة التشغيل بعد تعديل تطبيق | `sudo systemctl restart web2py` |
| إعادة تحميل بلا انقطاع | `sudo systemctl reload web2py` |
| العمليات/الخيوط | `/etc/default/web2py` ثم إعادة التشغيل |
| سكربت داخل تطبيق | `sudo -u web2py /opt/web2py/.venv/bin/python web2py.py -S app -M -R applications/app/scripts/x.py` |
| صفحة الترحيب | `https://<domain>/` (التطبيق `welcome`، يُثبَّت على الخادم الجديد فقط، ويُحذف من لوحة الإدارة) |
| لوحة الإدارة | `https://<domain>/admin` أو عبر نفق SSH: `ssh -L 8000:127.0.0.1:8000 server` ثم `http://localhost:8000/admin` |
| تغيير كلمة الإدارة | `sudo bash deploy/setup-server.sh --password-only --admin-password '...'` |

## ملاحظات

- الخدمة تعمل بـ `PYTHONUTF8=1` لتُقرأ ملفات الإعداد والنصوص العربية بـ UTF-8 مهما كانت لغة النظام.
- كل عملية تحتفظ بذاكرتها المؤقتة (`cache.ram`) وتهيئتها لمرة واحدة؛ الجلسات على القرص مشتركة.
- مهلة الطلب 300 ثانية (تصدير تقارير سنة كاملة يأخذ عشرات الثواني).
- التشغيل البسيط بلا خدمة: `./start.sh` (خادم Rocket المدمج).
