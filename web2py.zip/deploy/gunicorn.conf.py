"""gunicorn settings for web2py — loaded by deploy/web2py.service.

Values can be overridden in /etc/default/web2py (WEB2PY_BIND, WEB2PY_WORKERS, WEB2PY_THREADS).
Each worker is a separate process: web2py's cache.ram and the apps' once-per-process bootstrap
live per worker; sessions stay on disk, shared by all workers.
"""
import multiprocessing
import os

bind = os.environ.get("WEB2PY_BIND", "127.0.0.1:8000")
# PostgreSQL connections: every worker keeps up to pool_size idle connections PER APP, plus one
# per busy thread. Keep  workers x (sum of the apps' pool_size + threads)  under the server's
# max_connections (default 100). 2 x 8 already gives ~4x Rocket's throughput under load.
workers = int(os.environ.get("WEB2PY_WORKERS") or min(2, multiprocessing.cpu_count()))
worker_class = "gthread"
threads = int(os.environ.get("WEB2PY_THREADS") or 8)

# Long Excel/report exports (a full year of sales takes ~36 s) must not be killed.
timeout = 300
graceful_timeout = 30
keepalive = 5

# Recycle workers now and then so memory growth in long-running apps stays bounded.
max_requests = 2000
max_requests_jitter = 200

# Behind nginx on the same host: trust its X-Forwarded-* headers only.
forwarded_allow_ips = "127.0.0.1,::1"

# gunicorn >= 26 opens a control socket in $HOME/.gunicorn by default; www-data (classic installs)
# cannot write its home, so under systemd keep it in the service's RuntimeDirectory (/run/<name>).
if os.environ.get("RUNTIME_DIRECTORY"):
    control_socket = os.path.join(os.environ["RUNTIME_DIRECTORY"].split(":")[0], "gunicorn.ctl")

accesslog = "-"
errorlog = "-"
loglevel = "info"
