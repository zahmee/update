"""Archives for deploy.cmd / deploy-app.cmd (standard library only; any Python 3.8+).

    python pack.py framework <copy_dir> <out.tar.gz>
        the standalone copy (D:\\new_web2py) as new_web2py/...: the framework and its own apps
        (admin, welcome) - no other applications, runtime folders, .venv, caches, logs, deposit,
        pid/log files or parameters_*.py
    python pack.py app <app_dir> <out.tar.gz> [--with-db]
        one upload for install-app.sh: w2p-app/install-app.sh, w2p-app/common.sh,
        w2p-app/<app>.tar.gz (the application without sessions, errors, cache, backups and
        development folders) and, with --with-db, w2p-app/<app>.dump (pg_dump of its database)
    python pack.py dbinfo <app_dir>
        "postgres" when the app uses PostgreSQL, else its DAL scheme - prints no secret

Windows' own tar.exe crashes on Arabic file names (seen with asbab5), hence Python's tarfile.
The database password is read from the app's settings here and handed to pg_dump through its
environment, so it never appears on a command line.
"""
import configparser
import glob
import io
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from urllib.parse import unquote, urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.dirname(HERE)

COMMON_SKIP_DIRS = {"__pycache__", ".git", ".github", "node_modules", ".venv", "venv", "test-venv",
                    ".pytest_cache", ".uv-cache", ".uv-python", ".mypy_cache", ".ruff_cache"}
APP_SKIP_DIRS = COMMON_SKIP_DIRS | {"sessions", "errors", "cache", "compiled", "archive", "backups", "dbbackup",
                                    "snapshots", ".claude", ".agents", ".kilo", ".vscode", ".idea",
                                    ".playwright-mcp"}
SKIP_SUFFIXES = (".pyc", ".pyo", ".log", ".pid", ".bak", ".zip", ".tar", ".gz", ".7z", ".dump", ".sql.gz")
# The framework archive carries the framework and its own applications only (in step with
# scripts/make_standalone.py): whatever else is put into the copy - applications tried locally,
# notes, the local admin password - never leaves this PC with it (apps go with deploy-app.cmd).
FRAMEWORK_TOP_DIRS = {"gluon", "handlers", "examples", "scripts", "deploy", "applications"}
FRAMEWORK_TOP_FILES = {"web2py.py", "anyserver.py", "wsgihandler.py", "pyproject.toml", "uv.lock",
                       ".python-version", "README.md", "LOCAL_PATCHES.md", "start.sh", "start.bat",
                       "welcome.w2p", "deploy.cmd", "deploy-app.cmd", ".web2py-standalone"}
FRAMEWORK_APPS = {"admin", "welcome"}
APP_RUNTIME_DIRS = {"sessions", "errors", "cache", "databases", "uploads", "private"}


def framework_keep_dir(parts, name):
    """parts: the folder being walked, relative to the copy ([] = the copy itself)."""
    if name in COMMON_SKIP_DIRS:
        return False
    if not parts:
        return name in FRAMEWORK_TOP_DIRS
    if parts == ["applications"]:
        return name in FRAMEWORK_APPS
    return not (len(parts) == 2 and parts[0] == "applications" and name in APP_RUNTIME_DIRS)


def framework_keep_file(parts, name):
    if not parts:
        return name in FRAMEWORK_TOP_FILES
    return parts != ["applications"] or name == "__init__.py"


def _add_tree(tar, root, arcroot, keep_dir, keep_file=lambda parts, name: True):
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        parts = [] if rel == "." else rel.split(os.sep)
        dirnames[:] = sorted(d for d in dirnames if keep_dir(parts, d))
        for name in sorted(filenames):
            if name.endswith(SKIP_SUFFIXES) or (not parts and name.startswith("parameters_")) \
                    or not keep_file(parts, name):
                continue
            path = os.path.join(dirpath, name)
            arc = arcroot + "/" + os.path.relpath(path, root).replace(os.sep, "/")
            info = tar.gettarinfo(path, arc)
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            if name.endswith(".sh"):
                data = open(path, "rb").read().replace(b"\r\n", b"\n")   # must run on Linux
                info.size, info.mode = len(data), 0o755
                tar.addfile(info, io.BytesIO(data))
            else:
                info.mode = 0o644
                with open(path, "rb") as fh:
                    tar.addfile(info, fh)
            count += 1
    return count


def db_uri(app_dir):
    ini = os.path.join(app_dir, "private", "appconfig.ini")
    if os.path.exists(ini):
        cp = configparser.RawConfigParser(inline_comment_prefixes=(";", "#"))
        cp.read(ini, encoding="utf8")
        if cp.has_option("db", "uri"):
            uri = cp.get("db", "uri").strip()
            if uri.startswith("postgres"):
                return uri
    for f in sorted(glob.glob(os.path.join(app_dir, "models", "*.py"))):
        m = re.search(r"""DAL\(\s*['"](postgres[^'"]+)['"]""", open(f, encoding="utf8", errors="replace").read())
        if m:
            return m.group(1)
    if os.path.exists(ini):
        return (cp.get("db", "uri") if cp.has_option("db", "uri") else "").strip()
    return ""


def pg_dump_exe():
    exe = shutil.which("pg_dump")
    if exe:
        return exe
    found = glob.glob(r"C:\Program Files\PostgreSQL\*\bin\pg_dump.exe")
    found.sort(key=lambda p: [int(x) for x in re.findall(r"\d+", p.split(os.sep)[-3])] or [0])
    if found:
        return found[-1]
    sys.exit("pg_dump not found: install the PostgreSQL client tools or add them to PATH")


def dump_db(app_dir, out):
    uri = db_uri(app_dir)
    if not uri.startswith("postgres"):
        sys.exit(f"{os.path.basename(app_dir)} does not use PostgreSQL")
    u = urlsplit(re.sub(r"^postgres(ql)?(:\w+)?://", "postgres://", uri))
    env = dict(os.environ, PGPASSWORD=unquote(u.password or ""))
    cmd = [pg_dump_exe(), "-Fc", "-Z", "6", "-h", u.hostname or "localhost", "-p", str(u.port or 5432),
           "-U", unquote(u.username or ""), "-f", out, u.path.lstrip("/")]
    subprocess.run(cmd, env=env, check=True)


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    mode = sys.argv[1]
    if mode == "dbinfo":
        uri = db_uri(sys.argv[2])
        print("postgres" if uri.startswith("postgres") else (uri.split(":", 1)[0] or "none"))
        return
    src, out = os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    if mode == "framework":
        if not os.path.exists(os.path.join(src, "gluon", "version.py")):
            sys.exit(f"{src} is not a web2py copy")
        with tarfile.open(out, "w:gz", compresslevel=6) as tar:
            n = _add_tree(tar, src, "new_web2py", framework_keep_dir, framework_keep_file)
        print(f"{n} files -> {out} ({os.path.getsize(out) / 1048576:.1f} MB)")
    elif mode == "app":
        app = os.path.basename(src.rstrip("\\/"))
        if not os.path.isdir(os.path.join(src, "controllers")):
            sys.exit(f"{src} is not a web2py application")
        with tempfile.TemporaryDirectory() as tmp:
            inner = os.path.join(tmp, app + ".tar.gz")
            with tarfile.open(inner, "w:gz", compresslevel=6) as tar:
                n = _add_tree(tar, src, app, lambda parts, d: d not in APP_SKIP_DIRS)
            with tarfile.open(out, "w:gz", compresslevel=1) as tar:
                for f in ("install-app.sh", "common.sh"):
                    data = open(os.path.join(DEPLOY, f), "rb").read().replace(b"\r\n", b"\n")
                    info = tarfile.TarInfo("w2p-app/" + f)
                    info.size, info.mode = len(data), 0o755
                    tar.addfile(info, io.BytesIO(data))
                tar.add(inner, "w2p-app/" + app + ".tar.gz")
                if "--with-db" in sys.argv:
                    dump = os.path.join(tmp, app + ".dump")
                    dump_db(src, dump)
                    tar.add(dump, "w2p-app/" + app + ".dump")
                    print(f"database dump: {os.path.getsize(dump) / 1048576:.1f} MB")
        print(f"{app}: {n} files -> {out} ({os.path.getsize(out) / 1048576:.1f} MB)")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
