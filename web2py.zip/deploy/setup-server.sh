#!/usr/bin/env bash
# =============================================================================
#  web2py 3.3.3-zahmee — server installer / updater (Ubuntu 22.04 / 24.04 / 26.04, Debian 12+)
#
#  Installs or UPDATES the framework from this standalone copy without touching the
#  applications that already live on the server. Everything the framework needs is
#  created by this script: system packages, service user, uv + Python (version from
#  .python-version) + the exact libraries of uv.lock inside <dir>/.venv, the
#  application server (gunicorn or uWSGI) as a systemd service, nginx (static files,
#  upload limit, optional TLS), a daily session-cleanup timer and the admin password.
#
#  Fresh server (HTTPS at once with a self-signed certificate: the browser asks once to accept it;
#  the root URL shows a welcome page, the admin interface is at /admin):
#     sudo bash deploy/setup-server.sh --admin-password 'strong-password'
#     sudo bash deploy/setup-server.sh --domain example.com --email admin@example.com --admin-password '...'
#
#  Update an existing server (applications, private/, databases/, uploads/, sessions
#  are never touched; gluon/ + the admin app are replaced, a backup is kept in <dir>/backups).
#  An update keeps how the server is reached: the owner of the existing files stays the service
#  user, and the nginx site keeps its server_name and HTTPS certificate (self-signed from the
#  classic installer or Let's Encrypt); the previous site file is saved in <dir>/backups:
#     sudo bash deploy/setup-server.sh
#  (the existing installation is found by itself: the systemd unit's folder, a classic uWSGI
#   config's chdir, or /opt/web2py, /home/www-data/web2py, /var/www/web2py, /srv/web2py;
#   --dir overrides). From Windows the same thing is one command: deploy.cmd
#
#  Applications are added afterwards with deploy/install-app.sh (deploy-app.cmd on Windows).
#
#  Change only the admin password:
#     sudo bash deploy/setup-server.sh --password-only --admin-password 'new-password'
#
#  Based on the classic setup-web2py-nginx-uwsgi-ubuntu script; extended with uv,
#  an update mode, gunicorn, systemd hardening, health checks and session cleanup.
# =============================================================================
set -Eeuo pipefail
# never wait for a key press under an ssh -t terminal (psql/systemctl/journalctl pagers)
export PAGER=cat PSQL_PAGER=cat SYSTEMD_PAGER=""

DIR=/opt/web2py              # --dir        install folder (default: the existing installation, else /opt/web2py)
DIR_SET=0
SVC_USER=web2py              # --user       service user (update: owner of the existing files)
USER_SET=0
NAME=web2py                  # --name       systemd service / nginx site name
SERVER=gunicorn              # --server     gunicorn | uwsgi
PORT=8000                    # --port       backend port (gunicorn; uwsgi with --no-nginx)
WORKERS=""                   # --workers    processes (default: 2, max cpu count)
THREADS=""                   # --threads    threads per process (default 8)
DOMAIN="_"                   # --domain     nginx server_name; enables Let's Encrypt with --email
EMAIL=""                     # --email
TLS=auto                     # --no-tls | --self-signed   (auto: Let's Encrypt with --domain+--email, else keep
                             #   what an existing server already has, else a self-signed certificate)
UPLOAD_LIMIT=200m            # --upload-limit
ADMIN_PW=""                  # --admin-password
NO_PASSWORD=0                # --no-password
PASSWORD_ONLY=0              # --password-only
WITH_NGINX=1                 # --no-nginx
APT_UPGRADE=0                # --apt-upgrade  (apt-get upgrade of the whole system)
KEEP_LEGACY=0                # --keep-legacy  (do not stop old uwsgi-emperor units)
NO_BACKUP=0                  # --no-backup

usage() { sed -n '3,25p' "$0"; exit "${1:-0}"; }
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dir) DIR="${2%/}"; DIR_SET=1; shift 2 ;;
    --user) SVC_USER="$2"; USER_SET=1; shift 2 ;;
    --name) NAME="$2"; shift 2 ;;
    --server) SERVER="$2"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --workers) WORKERS="$2"; shift 2 ;;
    --threads) THREADS="$2"; shift 2 ;;
    --domain) DOMAIN="$2"; shift 2 ;;
    --email) EMAIL="$2"; shift 2 ;;
    --no-tls) TLS=none; shift ;;
    --self-signed) TLS=selfsigned; shift ;;
    --upload-limit) UPLOAD_LIMIT="$2"; shift 2 ;;
    --admin-password) ADMIN_PW="$2"; shift 2 ;;
    --no-password) NO_PASSWORD=1; shift ;;
    --password-only) PASSWORD_ONLY=1; shift ;;
    --no-nginx) WITH_NGINX=0; shift ;;
    --apt-upgrade) APT_UPGRADE=1; shift ;;
    --keep-legacy) KEEP_LEGACY=1; shift ;;
    --no-backup) NO_BACKUP=1; shift ;;
    -h|--help) usage 0 ;;
    *) echo "unknown option: $1" >&2; usage 1 ;;
  esac
done

log()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || fail "run as root:  sudo bash $0 ..."
[[ "$SERVER" == gunicorn || "$SERVER" == uwsgi ]] || fail "--server must be gunicorn or uwsgi"
[[ "$UPLOAD_LIMIT" =~ ^[0-9]+[kKmMgG]?$ ]] || fail "--upload-limit: use values like 200m, 1g, 512k"
[[ "$PORT" =~ ^[0-9]+$ ]] || fail "--port must be a number"
[[ "$NAME" =~ ^[A-Za-z0-9_-]+$ ]] || fail "--name: letters, digits, - and _ only"
[[ $NO_PASSWORD -eq 0 || -z "$ADMIN_PW" ]] || fail "use either --admin-password or --no-password"
[[ -z "$EMAIL" || "$DOMAIN" != "_" ]] || fail "--email requires --domain"
# TLS=auto is resolved below, once we know whether this is an update of an existing server

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[[ -f "$SRC/gluon/version.py" && -f "$SRC/uv.lock" ]] || fail "$SRC is not a web2py standalone copy (gluon/version.py, uv.lock missing)"
VERSION="$(sed -n 's/^VERSION *= *"\([^"]*\)".*/\1/p' "$SRC/gluon/version.py")"
STAMP="$(date +%Y%m%d-%H%M%S)"
# shellcheck source=deploy/common.sh
source "$SRC/deploy/common.sh"

# No --dir: update the installation this server already has (systemd unit, classic uWSGI config
# or the usual folders), so old servers need no options; a fresh server gets /opt/web2py.
if [[ $DIR_SET -eq 0 ]]; then
  found="$(detect_install_dir "$NAME")"
  [[ -n "$found" ]] && DIR="$found"
fi

# uv keeps its cache and the Python builds inside the install folder: self-contained,
# owned by the service user, no dependency on that user's HOME.
uv_env() {
  runuser -u "$SVC_USER" -- env HOME="$SVC_HOME" PYTHONUTF8=1 \
    UV_CACHE_DIR="$DIR/.uv-cache" UV_PYTHON_INSTALL_DIR="$DIR/.uv-python" "$@"
}

# ---------------------------------------------------------------- admin password
set_admin_password() {
  [[ -x "$DIR/.venv/bin/python" ]] || fail "$DIR/.venv/bin/python missing: run the full installation first"
  [[ -n "$ADMIN_PW" ]] || fail "empty admin password"
  # web2py looks up parameters_<port>.py with the port the browser used: 443/80 through
  # nginx, the backend port through an SSH tunnel (ssh -L $PORT:127.0.0.1:$PORT server).
  local ports="443 80 $PORT"
  local names="${ports// /,}"
  log "Admin password -> parameters_{$names}.py"
  runuser -u "$SVC_USER" -- env HOME="$SVC_HOME" W2P_PW="$ADMIN_PW" W2P_PORTS="$ports" \
    bash -c "cd '$DIR' && .venv/bin/python - <<'PY'
import os, sys
sys.path.insert(0, '.')
from gluon.main import save_password
for port in os.environ['W2P_PORTS'].split():
    save_password(os.environ['W2P_PW'], int(port))
PY"
  chmod 600 "$DIR"/parameters_*.py
}

if [[ $PASSWORD_ONLY -eq 1 ]]; then
  [[ -n "$ADMIN_PW" ]] || { read -r -s -p "web2py admin password: " ADMIN_PW; printf '\n'; }
  SVC_HOME="$(getent passwd "$SVC_USER" | cut -d: -f6)"
  set_admin_password
  echo "done."
  exit 0
fi
if [[ $NO_PASSWORD -eq 0 && -z "$ADMIN_PW" ]] && ! compgen -G "$DIR/parameters_*.py" >/dev/null; then
  read -r -s -p "web2py admin password (empty = keep admin disabled): " ADMIN_PW; printf '\n'
fi

UPDATE=0
[[ -d "$DIR/gluon" ]] && UPDATE=1

# ---------------------------------------------------------------- keep what an existing server has
# An update must not change how the server is reached: same service user, same server_name and
# the same HTTPS certificate (self-signed from the classic installer, or Let's Encrypt).
SITE="/etc/nginx/sites-available/$NAME"
CERT=""; KEY=""
if [[ $UPDATE -eq 1 && $USER_SET -eq 0 ]]; then
  owner="$(install_owner "$DIR")"
  [[ -n "$owner" ]] && SVC_USER="$owner"
fi
if [[ "$DOMAIN" == "_" && -f "$SITE" ]]; then
  old_name="$(sed -nE 's/^[[:space:]]*server_name[[:space:]]+([^;]+);.*/\1/p' "$SITE" | head -1 | xargs || true)"
  [[ -n "$old_name" && "$old_name" != "_" ]] && DOMAIN="$old_name"
fi
if [[ "$TLS" == auto ]]; then
  if [[ "$DOMAIN" != "_" && -n "$EMAIL" ]]; then
    TLS=letsencrypt
  elif [[ -f "$SITE" ]] && grep -qE '^[[:space:]]*ssl_certificate[[:space:]]' "$SITE"; then
    CERT="$(sed -nE 's/^[[:space:]]*ssl_certificate[[:space:]]+([^;]+);.*/\1/p' "$SITE" | head -1 | xargs || true)"
    KEY="$(sed -nE 's/^[[:space:]]*ssl_certificate_key[[:space:]]+([^;]+);.*/\1/p' "$SITE" | head -1 | xargs || true)"
    TLS=existing
  elif [[ -f "/etc/nginx/ssl/$NAME.crt" && -f "/etc/nginx/ssl/$NAME.key" ]]; then
    CERT="/etc/nginx/ssl/$NAME.crt"; KEY="/etc/nginx/ssl/$NAME.key"
    TLS=existing
  elif [[ -f "$SITE" ]] && { grep -q '^# plain HTTP' "$SITE" || ! grep -q 'written by deploy/setup-server.sh' "$SITE"; }; then
    TLS=none          # plain HTTP on purpose (--no-tls, or a site this script did not write) stays so
  else
    TLS=selfsigned    # new server: HTTPS at once, the admin interface refuses logins over plain HTTP
  fi
fi
log "web2py $VERSION -> $DIR  ($( [[ $UPDATE -eq 1 ]] && echo UPDATE of an existing installation || echo NEW installation ); server=$SERVER user=$SVC_USER service=$NAME server_name=$DOMAIN tls=$TLS${CERT:+ ($CERT)})"

# ---------------------------------------------------------------- system packages
log "System packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
[[ $APT_UPGRADE -eq 1 ]] && apt-get -y -qq upgrade
PKGS=(curl ca-certificates rsync unzip openssl postgresql-client
      libpango-1.0-0 libpangoft2-1.0-0 libharfbuzz-subset0 fonts-noto-core)     # PDF export (weasyprint)
[[ "$SERVER" == uwsgi ]] && PKGS+=(build-essential libpcre2-dev libssl-dev)     # uWSGI is compiled
[[ $WITH_NGINX -eq 1 ]] && PKGS+=(nginx)
[[ "$TLS" == letsencrypt ]] && PKGS+=(certbot python3-certbot-nginx)
apt-get install -y -qq "${PKGS[@]}" >/dev/null

# ---------------------------------------------------------------- service user
log "Service user: $SVC_USER"
if ! id "$SVC_USER" >/dev/null 2>&1; then
  useradd --system --create-home --home-dir "/home/$SVC_USER" --shell /usr/sbin/nologin "$SVC_USER"
fi
SVC_HOME="$(getent passwd "$SVC_USER" | cut -d: -f6)"
[[ -d "$SVC_HOME" ]] || { mkdir -p "$SVC_HOME"; chown "$SVC_USER:" "$SVC_HOME"; }
SVC_GROUP="$(id -gn "$SVC_USER")"

# ---------------------------------------------------------------- legacy uwsgi-emperor installs
if [[ $UPDATE -eq 1 && $KEEP_LEGACY -eq 0 ]]; then
  for unit in emperor.uwsgi.service uwsgi-emperor.service uwsgi.service; do
    if systemctl list-unit-files "$unit" 2>/dev/null | grep -q "^$unit" && systemctl is-active -q "$unit"; then
      log "Stopping legacy $unit (replaced by $NAME.service; --keep-legacy to skip)"
      systemctl disable --now "$unit" || true
    fi
  done
  for f in /etc/uwsgi/web2py.xml /etc/uwsgi/apps-enabled/web2py.xml /etc/uwsgi/apps-enabled/web2py.ini; do
    [[ -f "$f" ]] && mv "$f" "$f.disabled-$STAMP" && echo "moved $f -> $f.disabled-$STAMP"
  done
  # uWSGI ini of the classic installer (its $NAME.service is replaced below)
  f="/etc/uwsgi/$NAME.ini"
  if [[ -f "$f" ]] && ! grep -q 'written by deploy/setup-server.sh' "$f"; then
    mv "$f" "$f.disabled-$STAMP" && echo "moved $f -> $f.disabled-$STAMP"
  fi
fi

# ---------------------------------------------------------------- files
if [[ $UPDATE -eq 1 && $NO_BACKUP -eq 0 ]]; then
  mkdir -p "$DIR/backups"
  log "Backup of the old framework -> $DIR/backups/framework-$STAMP.tar.gz"
  tar -czf "$DIR/backups/framework-$STAMP.tar.gz" -C "$DIR" gluon web2py.py \
      $( [[ -d "$DIR/applications/admin" ]] && echo applications/admin ) 2>/dev/null || true
  ls -1t "$DIR"/backups/framework-*.tar.gz 2>/dev/null | tail -n +6 | xargs -r rm -f   # keep 5
fi

log "Files -> $DIR"
mkdir -p "$DIR/applications" "$DIR/deposit" "$DIR/logs" "$DIR/site-packages"
if [[ "$SRC" != "$DIR" ]]; then
  rsync -a --delete "$SRC/gluon/" "$DIR/gluon/"
  for d in handlers examples scripts deploy; do
    [[ -d "$SRC/$d" ]] && rsync -a --delete "$SRC/$d/" "$DIR/$d/"
  done
  for f in web2py.py anyserver.py wsgihandler.py pyproject.toml uv.lock .python-version \
           README.md LOCAL_PATCHES.md start.sh start.bat welcome.w2p; do
    [[ -f "$SRC/$f" ]] && cp -f "$SRC/$f" "$DIR/$f"
  done
fi
[[ -f "$DIR/wsgihandler.py" ]] || cp "$DIR/handlers/wsgihandler.py" "$DIR/wsgihandler.py"
[[ -f "$DIR/applications/__init__.py" ]] || : > "$DIR/applications/__init__.py"
[[ -f "$DIR/site-packages/__init__.py" ]] || : > "$DIR/site-packages/__init__.py"
# the framework's own applications travel in the copy's applications/ (their runtime folders never do)
APP_SYNC=(rsync -a --exclude=/sessions --exclude=/errors --exclude=/cache --exclude=/databases
          --exclude=/uploads --exclude=/private --exclude=__pycache__)
# admin must match gluon: refresh its code, keep its runtime folders
if [[ "$SRC" != "$DIR" && -d "$SRC/applications/admin" ]]; then
  "${APP_SYNC[@]}" --delete "$SRC/applications/admin/" "$DIR/applications/admin/"
fi
[[ -d "$DIR/applications/admin" ]] && mkdir -p "$DIR"/applications/admin/{sessions,errors,cache,databases,uploads,private}
# the welcome page (root URL) comes with fresh environments only: a server that already hosts
# applications keeps its applications folder exactly as it is (deploy-app.cmd -App welcome adds it)
if [[ "$SRC" != "$DIR" && -d "$SRC/applications/welcome" && ! -e "$DIR/applications/welcome" &&
      -z "$(find "$DIR/applications" -mindepth 1 -maxdepth 1 -type d ! -name admin ! -name __pycache__ -print -quit)" ]]; then
  "${APP_SYNC[@]}" "$SRC/applications/welcome/" "$DIR/applications/welcome/"
  echo "welcome page installed -> $DIR/applications/welcome"
fi
# web2py 2.x leftovers that confuse version checks
for f in VERSION ABOUT CHANGELOG MANIFEST.in Makefile setup.py appveyor.yml tox.ini setup_exe.py setup_app.py; do
  [[ -f "$DIR/$f" ]] && rm -f "$DIR/$f" && echo "removed legacy $f"
done
rm -rf "$DIR/main.py" "$DIR/gluon/packages/pydal/test-venv" "$DIR/gluon/packages/rocket3/venv" 2>/dev/null || true
find "$DIR/gluon" "$DIR/applications/admin" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
chmod +x "$DIR"/start.sh "$DIR"/deploy/*.sh 2>/dev/null || true
chown -R "$SVC_USER:$SVC_GROUP" "$DIR"
find "$DIR/applications" -mindepth 2 -maxdepth 2 -type d -name private -exec chmod 700 {} + 2>/dev/null || true
find "$DIR" -maxdepth 1 -name 'parameters_*.py' -exec chmod 600 {} + 2>/dev/null || true

# ---------------------------------------------------------------- uv + Python + libraries
log "uv"
if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | env UV_INSTALL_DIR=/usr/local/bin UV_NO_MODIFY_PATH=1 sh >/dev/null
fi
uv --version

log "Python $(cat "$DIR/.python-version") + libraries from uv.lock -> $DIR/.venv"
uv_env bash -c "cd '$DIR' && uv sync --frozen --no-dev"
if [[ "$SERVER" == uwsgi ]]; then
  log "uWSGI (compiled for this Python; re-installed after every sync)"
  uv_env bash -c "cd '$DIR' && uv pip install --python .venv/bin/python 'uwsgi>=2.0.30'"
  "$DIR/.venv/bin/uwsgi" --version
fi
uv_env bash -c "cd '$DIR' && .venv/bin/python -c \"import sys; sys.path.insert(0, '.'); from gluon.version import VERSION; print('web2py', VERSION, '| python', sys.version.split()[0])\""

keep_pw=""
for f in "$DIR/parameters_443.py" "$DIR"/parameters_*.py; do [[ -f "$f" ]] && { keep_pw="$f"; break; }; done
if [[ -n "$ADMIN_PW" ]]; then
  set_admin_password
elif [[ -n "$keep_pw" ]]; then
  # same hash for every port web2py may be reached on: 443/80 through nginx, $PORT via SSH tunnel
  # (an install that only had parameters_443.py left /admin disabled on the other ports)
  for p in 443 80 "$PORT"; do
    [[ -f "$DIR/parameters_$p.py" ]] || cp -p "$keep_pw" "$DIR/parameters_$p.py"
  done
  chown "$SVC_USER:$SVC_GROUP" "$DIR"/parameters_*.py
  chmod 600 "$DIR"/parameters_*.py
  echo "admin password kept ($(basename "$keep_pw") -> parameters_{443,80,$PORT}.py)"
else
  echo "no admin password: the admin interface stays disabled (set later with --password-only)"
fi

# ---------------------------------------------------------------- application server
: "${WORKERS:=$(( $(nproc) < 2 ? $(nproc) : 2 ))}"
: "${THREADS:=8}"
{
  echo "WEB2PY_BIND=127.0.0.1:$PORT"
  echo "WEB2PY_WORKERS=$WORKERS"
  echo "WEB2PY_THREADS=$THREADS"
} > "/etc/default/$NAME"

if [[ "$SERVER" == gunicorn ]]; then
  EXEC="$DIR/.venv/bin/gunicorn -c $DIR/deploy/gunicorn.conf.py wsgihandler:application"
  TYPE=simple
else
  mkdir -p /etc/uwsgi
  if [[ $WITH_NGINX -eq 1 ]]; then
    # uWSGI runs unprivileged, so it cannot chown its socket: nginx's user joins the
    # service group instead and the socket stays 660 (owner+group only)
    if id www-data >/dev/null 2>&1 && ! id -nG www-data | tr ' ' '\n' | grep -qx "$SVC_GROUP"; then
      usermod -aG "$SVC_GROUP" www-data
    fi
    LISTEN="socket = /run/$NAME/$NAME.sock
chmod-socket = 660"
  else
    LISTEN="http = 127.0.0.1:$PORT"
  fi
  cat > "/etc/uwsgi/$NAME.ini" <<EOF
; uWSGI for web2py — written by deploy/setup-server.sh (workers/threads: /etc/default/$NAME is informative only)
[uwsgi]
chdir = $DIR
module = wsgihandler:application
virtualenv = $DIR/.venv
pythonpath = $DIR
env = PYTHONUTF8=1
master = true
processes = $WORKERS
threads = $THREADS
enable-threads = true
lazy-apps = true
harakiri = 300
post-buffering = 8192
max-requests = 2000
buffer-size = 32768
vacuum = true
die-on-term = true
need-app = true
$LISTEN
EOF
  EXEC="$DIR/.venv/bin/uwsgi --ini /etc/uwsgi/$NAME.ini"
  TYPE=notify
fi

log "systemd: $NAME.service ($SERVER, $WORKERS x $THREADS)"
cat > "/etc/systemd/system/$NAME.service" <<EOF
# web2py $VERSION under $SERVER — written by deploy/setup-server.sh
[Unit]
Description=web2py ($SERVER) — $DIR
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
Type=$TYPE
User=$SVC_USER
Group=$SVC_GROUP
WorkingDirectory=$DIR
Environment=PYTHONUTF8=1
Environment=LANG=C.UTF-8
EnvironmentFile=-/etc/default/$NAME
RuntimeDirectory=$NAME
RuntimeDirectoryMode=0755
ExecStart=$EXEC
ExecReload=/bin/kill -s HUP \$MAINPID
KillMode=mixed
$( [[ "$SERVER" == uwsgi ]] && echo "KillSignal=SIGQUIT" )
TimeoutStopSec=40
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=$DIR /run/$NAME

[Install]
WantedBy=multi-user.target
EOF

# daily cleanup of expired session files of every application
cat > "/etc/systemd/system/$NAME-sessions.service" <<EOF
[Unit]
Description=web2py: remove expired session files ($DIR)
[Service]
Type=oneshot
User=$SVC_USER
WorkingDirectory=$DIR
Environment=PYTHONUTF8=1
ExecStart=$DIR/deploy/sessions2trash-all.sh
EOF
cat > "/etc/systemd/system/$NAME-sessions.timer" <<EOF
[Unit]
Description=web2py: daily session cleanup
[Timer]
OnCalendar=daily
RandomizedDelaySec=1h
Persistent=true
[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable "$NAME.service" "$NAME-sessions.timer" >/dev/null 2>&1
systemctl restart "$NAME.service"
systemctl start "$NAME-sessions.timer"

# ---------------------------------------------------------------- nginx
if [[ $WITH_NGINX -eq 1 ]]; then
  log "nginx: site $NAME (server_name $DOMAIN, tls=$TLS, upload limit $UPLOAD_LIMIT)"
  mkdir -p /etc/nginx/snippets /etc/nginx/ssl
  if [[ "$SERVER" == gunicorn ]]; then
    UPSTREAM="upstream ${NAME}_app { server 127.0.0.1:$PORT; keepalive 16; }"
    PASS="        proxy_pass http://${NAME}_app;
        proxy_http_version 1.1;
        proxy_set_header Connection \"\";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;"
  else
    UPSTREAM=""
    PASS="        include uwsgi_params;
        uwsgi_pass unix:/run/$NAME/$NAME.sock;
        uwsgi_param UWSGI_SCHEME \$scheme;
        uwsgi_param SERVER_SOFTWARE nginx/\$nginx_version;
        uwsgi_read_timeout 300s;
        uwsgi_send_timeout 300s;"
  fi
  DEFAULT=""; [[ "$DOMAIN" == "_" ]] && DEFAULT=" default_server"
  if [[ -f "$SITE" ]]; then
    mkdir -p "$DIR/backups"
    cp -a "$SITE" "$DIR/backups/nginx-$NAME-$STAMP.conf"
    echo "previous nginx site saved -> $DIR/backups/nginx-$NAME-$STAMP.conf"
  fi
  cat > "/etc/nginx/snippets/$NAME-common.conf" <<EOF
    client_max_body_size $UPLOAD_LIMIT;
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header Referrer-Policy strict-origin-when-cross-origin always;
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;

    # browsers ask for /favicon.ico on pages without an icon link; web2py answers 400 there
    location = /favicon.ico { access_log off; log_not_found off; return 204; }

    # static files straight from disk (also versioned URLs /app/static/_1.2.3/...)
    location ~* ^/(\\w+)/static(?:/_[\\d]+\\.[\\d]+\\.[\\d]+)?/(.*)\$ {
        alias $DIR/applications/\$1/static/\$2;
        expires 7d;
        access_log off;
    }
    location / {
$PASS
    }
EOF
  if [[ "$TLS" == none ]]; then
    cat > "/etc/nginx/sites-available/$NAME" <<EOF
# web2py — written by deploy/setup-server.sh
# plain HTTP on purpose (kept by updates): the admin interface needs HTTPS or an SSH tunnel
$UPSTREAM
server {
    listen 80$DEFAULT;
    listen [::]:80$DEFAULT;
    server_name $DOMAIN;
    include /etc/nginx/snippets/$NAME-common.conf;
}
EOF
  else
    if [[ "$TLS" == existing && ( ! -f "$CERT" || ! -f "$KEY" ) ]]; then
      echo "certificate of the previous site not found ($CERT): switching to a self-signed one"
      TLS=selfsigned
    fi
    if [[ "$TLS" != existing ]]; then
      CERT="/etc/nginx/ssl/$NAME.crt"; KEY="/etc/nginx/ssl/$NAME.key"
    fi
    # generated only when missing: a self-signed cert (or the placeholder Let's Encrypt replaces
    # below) is never overwritten, so browsers that already trust it keep trusting it
    if [[ ! -f "$CERT" || ! -f "$KEY" ]]; then
      openssl req -x509 -nodes -newkey rsa:2048 -sha256 -days 3650 \
        -subj "/CN=${DOMAIN/_/localhost}" -keyout "$KEY" -out "$CERT" 2>/dev/null
      chmod 600 "$KEY"
    fi
    # "http2 on;" exists since nginx 1.25.1; older releases (Ubuntu 24.04 ships 1.24) take it on listen
    NGX_VER="$(nginx -v 2>&1 | sed -n 's#.*nginx/\([0-9.]*\).*#\1#p')"
    if [[ "$(printf '%s\n' 1.25.1 "${NGX_VER:-0}" | sort -V | head -1)" == 1.25.1 ]]; then
      H2_LISTEN=""; H2_LINE="    http2 on;"
    else
      H2_LISTEN=" http2"; H2_LINE=""
    fi
    cat > "/etc/nginx/sites-available/$NAME" <<EOF
# web2py — written by deploy/setup-server.sh
$UPSTREAM
server {
    listen 80$DEFAULT;
    listen [::]:80$DEFAULT;
    server_name $DOMAIN;
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl$H2_LISTEN$DEFAULT;
    listen [::]:443 ssl$H2_LISTEN$DEFAULT;
$H2_LINE
    server_name $DOMAIN;
    ssl_certificate $CERT;
    ssl_certificate_key $KEY;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_session_timeout 1d;
    ssl_session_cache shared:${NAME//-/_}_ssl:10m;
    include /etc/nginx/snippets/$NAME-common.conf;
}
EOF
  fi
  ln -sfn "/etc/nginx/sites-available/$NAME" "/etc/nginx/sites-enabled/$NAME"
  [[ "$NAME" != web2py || ! -e /etc/nginx/sites-enabled/default ]] || rm -f /etc/nginx/sites-enabled/default
  # nginx (www-data) must reach the static folders: traverse the tree, read static/ only
  chmod o+x "$(dirname "$DIR")" "$DIR" "$DIR/applications" 2>/dev/null || true
  find "$DIR/applications" -mindepth 1 -maxdepth 1 -type d -exec chmod o+x {} + 2>/dev/null || true
  find "$DIR/applications" -mindepth 2 -maxdepth 2 -type d -name static -exec chmod -R o+rX {} + 2>/dev/null || true
  nginx -t -q
  systemctl enable nginx >/dev/null 2>&1
  systemctl restart nginx
  if [[ "$TLS" == letsencrypt ]]; then
    log "Let's Encrypt certificate for $DOMAIN"
    certbot --nginx --non-interactive --agree-tos --redirect --email "$EMAIL" -d "$DOMAIN"
    systemctl reload nginx
  fi
fi

# ---------------------------------------------------------------- health check
log "Health check"
HOSTHDR="${DOMAIN/_/127.0.0.1}"
probe() { curl -s -o /dev/null -w '%{http_code}' -m 10 -k -H "Host: $HOSTHDR" "$1" 2>/dev/null || echo 000; }
for i in $(seq 1 30); do
  if [[ "$SERVER" == gunicorn || $WITH_NGINX -eq 0 ]]; then
    code=$(probe "http://127.0.0.1:$PORT/admin/default/index")
  else
    code=$(probe "http://127.0.0.1/admin/default/index")
  fi
  [[ "$code" != 000 ]] && break
  sleep 1
done
echo "$NAME.service ($SERVER)          -> HTTP $code  $(systemctl is-active "$NAME.service")"
if [[ $WITH_NGINX -eq 1 ]]; then
  echo "nginx :80  (Host $HOSTHDR)      -> HTTP $(probe http://127.0.0.1/admin/default/index)"
  [[ "$TLS" != none ]] && echo "nginx :443 (Host $HOSTHDR)      -> HTTP $(probe https://127.0.0.1/admin/default/index)"
fi
[[ "$code" =~ ^(200|303|30[0-9])$ ]] || { journalctl -u "$NAME.service" --no-pager -n 30; fail "$NAME.service does not answer (HTTP $code)"; }

SHOW="$DOMAIN"
[[ "$SHOW" == "_" ]] && SHOW="$(hostname -I 2>/dev/null | awk '{print $1}')"
: "${SHOW:=127.0.0.1}"
TUNNEL="ssh -L $PORT:127.0.0.1:$PORT <server> -> http://localhost:$PORT/admin"
if [[ $WITH_NGINX -eq 1 && "$TLS" != none ]]; then
  ADMIN="https://$SHOW/admin"
  [[ "$TLS" == selfsigned ]] && ADMIN="$ADMIN   (self-signed certificate: accept the browser warning once)"
else
  ADMIN="$TUNNEL   (plain HTTP refuses admin logins)"
fi
cat <<EOF

Done: web2py $VERSION in $DIR (${WORKERS} x ${THREADS} $SERVER, user $SVC_USER)
  admin        : $ADMIN
  applications : deploy-app.cmd from Windows, or copy each app with its private/appconfig.ini, then: systemctl restart $NAME
  status/logs  : systemctl status $NAME   |   journalctl -u $NAME -f
  reload       : systemctl reload $NAME   (graceful)   restart: systemctl restart $NAME
  sessions     : $NAME-sessions.timer (daily)   settings: /etc/default/$NAME
  update       : upload a newer standalone copy and run this script again with the same options
EOF
