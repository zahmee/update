# web2py 3.3.3-zahmee.5

نسخة web2py 3.3.3 معدّلة: تعمل على Python 3.14، وفيها إصلاحات أخطاء وتحسينات أداء وطبقة توافق
لكود تطبيقات web2py 2.x (القائمة في [LOCAL_PATCHES.md](LOCAL_PATCHES.md)). البيئة كلها تُدار عبر
[uv](https://docs.astral.sh/uv/): نسخة بايثون في `.python-version`، والمكتبات بإصدارات مثبّتة في `uv.lock`.

## النشر على خادم لينكس

`D:\new_web2py` هو **أساس النشر**: مجلد web2py كامل فيه الإطار، وتطبيق الإدارة `applications\admin`،
وصفحة الترحيب `applications\welcome`، وأدوات النشر. الأوامر تُشغَّل على جهاز ويندوز من داخله (أو من
`D:\web2py` فيُحدَّث `D:\new_web2py` تلقائياً أولاً). كل أمر يطلب كلمة مرور SSH ثم كلمة مرور `sudo` على
الخادم، ويمكن تشغيله بالنقر المزدوج فيسأل عن الخادم والمستخدم.

### 1) خادم جديد

```bat
deploy.cmd -Server 192.168.20.10 -User root
```

يثبّت الإطار في `/opt/web2py` مع كل ما يلزمه (Python 3.14 والمكتبات، gunicorn، nginx، تنظيف الجلسات)
ويسأل عن كلمة مرور لوحة الإدارة. يعمل الخادم فوراً عبر HTTPS بشهادة ذاتية (يطلب المتصفح قبولها مرة واحدة):
صفحة ترحيب على `https://<الخادم>/` ولوحة الإدارة على `https://<الخادم>/admin` (لا تقبل الدخول عبر HTTP العادي).
لخادم له اسم نطاق وشهادة Let's Encrypt:

```bat
deploy.cmd -Server 203.0.113.5 -User root -Options "--domain example.com --email me@example.com"
```

### 2) خادم قديم (تحديث)

```bat
deploy.cmd -Server 192.168.20.128 -User zahmee
```

الأمر نفسه. يكتشف التثبيت القائم وحده (ومنه تثبيت السكربت الكلاسيكي في `/home/www-data/web2py`)
ويحدّث الإطار فقط: التطبيقات وقواعدها وملفات إعدادها، وشهادة HTTPS، ومستخدم الخدمة، وكلمة مرور
الإدارة تبقى كما هي. قبل التحديث تُحفظ نسخة من الإطار السابق ومن إعداد nginx في `<مجلد التثبيت>/backups`.

### 3) إضافة تطبيق إلى خادم

```bat
deploy-app.cmd -App zah -Server 192.168.20.128 -User zahmee
deploy-app.cmd -App asbab5 -Server 192.168.20.128 -User zahmee -WithDatabase
deploy-app.cmd -App asbab5 -Server 192.168.20.128 -User zahmee -Update
```

| الخيار | ماذا يحدث |
|---|---|
| بلا خيار | تطبيق جديد يُنسخ مع `private\appconfig.ini` و`databases\` و`uploads\` (بلا الجلسات والأخطاء والنسخ الاحتياطية) |
| `-WithDatabase` | ينقل معه قاعدة PostgreSQL (يُثبَّت PostgreSQL على الخادم إن لم يوجد، ويُنشأ الدور والقاعدة كما في إعداد التطبيق) |
| `-Update` | تطبيق موجود على الخادم: يُحدَّث كوده فقط، وتبقى إعداداته وبياناته وملفاته المرفوعة |
| `-ReplaceDb` | يسمح باستبدال قاعدة على الخادم فيها جداول (بدونه لا تُمس أبداً) |

تطبيق موجود على الخادم لا يُستبدل أبداً بلا `-Update`، ولكل فرع إعداده وبياناته.

التطبيق يؤخذ من `D:\new_web2py\applications` إن كان فيه (مثل `welcome`)، وإلا من `D:\web2py\applications`
(و`-AppsRoot` يحدد مجلداً آخر). صفحة الترحيب تُثبَّت وحدها على الخادم الجديد؛ ولخادم فيه تطبيقات:
`deploy-app.cmd -App welcome -Server <ip> -User <user>`.

### اختياري: بلا كلمة مرور SSH في كل مرة

```bat
deploy.cmd -Server 192.168.20.128 -User zahmee -InstallKey
```

ينشئ مفتاحاً على هذا الجهاز ويضيفه إلى الخادم مرة واحدة؛ بعدها تُطلب كلمة مرور `sudo` فقط.

### بدون ويندوز

ارفع مجلد `new_web2py` إلى الخادم (WinSCP مثلاً) ثم: `sudo bash new_web2py/deploy/setup-server.sh`
— التفاصيل والخيارات في [deploy/README.md](deploy/README.md).

## التشغيل المحلي

| النظام | الأمر |
|---|---|
| ويندوز | `start.bat` |
| لينكس | `./start.sh` |

`uv run` يُنشئ البيئة أو يحدّثها تلقائياً قبل التشغيل. `"<recycle>"` يعيد استخدام كلمة مرور الإدارة
المحفوظة لهذا المنفذ (`parameters_8000.py`).

في نسخة جديدة (مثل `D:\new_web2py`) يكون التشغيل الأول بكلمة مرور للإدارة: `start.bat -a <كلمة المرور>`،
ثم `http://127.0.0.1:8000/` يفتح صفحة الترحيب. لتجربة تطبيق محلياً انسخ مجلده إلى `applications\`.

## إدارة المكتبات

| المهمة | الأمر |
|---|---|
| تجهيز البيئة على جهاز جديد | `uv sync` |
| إضافة مكتبة | `uv add <اسم>` (لنظام واحد: `uv add "<اسم>; sys_platform == 'linux'"`) |
| حذف مكتبة | `uv remove <اسم>` |
| تحديث الكل ضمن القيود | `uv lock --upgrade` ثم `uv sync` ثم تشغيل الاختبارات |
| المكتبات القديمة | `uv pip list --outdated` |
| سكربت داخل تطبيق | `uv run web2py.py -S asbab5 -M -R applications/asbab5/scripts/<script>.py` |
| اختبارات | `uv run python -m pytest applications/az/tests` · `applications/acc/tests` |

لا تثبّت بـ `pip` داخل `.venv` — ستُمسح عند أول `uv sync`. أوقف الخادم قبل `uv sync` على ويندوز
(الملفات المحمّلة تكون مقفلة).

## تحديث أساس النشر من بيئة التطوير

```bash
uv run python scripts/make_standalone.py      # D:\web2py -> D:\new_web2py
```

يُحدَّث `D:\new_web2py` في مكانه: ملفات الإطار وأدوات النشر و`admin` و`welcome` تُستبدل (ويُحذف منها ما
لم يعد في المصدر)، وكل ما أضفته أنت يبقى: التطبيقات الأخرى في `applications\`، وكلمة المرور المحلية
`parameters_*.py`، و`.venv`، والسجلات، وبيانات تشغيل `admin` و`welcome`. ولا يُرفع إلى الخوادم مع الإطار
إلا `admin` و`welcome`؛ أي تطبيق آخر يُنشر بـ `deploy-app.cmd`.

## نشر نسخة الإطار على قناة التحديث

```bash
uv run python scripts/publish_update.py       # D:\new_web2py -> github.com/zahmee/update (web2py.zip)
```

بعد أي تعديل على النواة: زِد رقم الوسم في `gluon/version.py` ثم شغّل الأمر. يرفع `web2py.zip` و`web2py_ver.txt`
و`web2py.sha256` إلى المستودع، ومنه يأخذ زر «Check for upgrades» ثم «upgrade now» في لوحة الإدارة على أي خادم
(يتحقق من البصمة والإصدار، ويحفظ نسخة احتياطية في `backups/`، ثم يلزم إعادة تشغيل الخادم). التفاصيل في
[LOCAL_PATCHES.md](LOCAL_PATCHES.md).
