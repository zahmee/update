# التعديلات المحلية على نواة الإطار

```
web2py 3.3.3-zahmee.6
VERSION = "3.3.3-zahmee.6+timestamp.2026.10.18.21.40.00"   (gluon/version.py)
base: official web2py 3.3.3 (tag v3.3.3, 2026-04-28) + pydal 20260313.1
      + 8 security commits from upstream master (see "إصلاحات أمنية من الفرع الرئيسي")
```

الأساس هو الإصدار الرسمي المذكور أعلاه. الوسم يميّز هذه النسخة المعدّلة؛ عند أي تعديل جديد على النواة زِد رقمه وحدّث الطابع الزمني. الصيغة يفرضها محلّل الإصدار في الإطار، فلا تحذف الطابع الزمني:

```
X.Y.Z-zahmee.N+timestamp.YYYY.MM.DD.HH.MM.SS      (gluon.fileutils.parse_semantic)
```

> زر الترقية في لوحة الإدارة لا يأخذ من الموقع الرسمي أبداً: منذ `zahmee.5` يأخذ نسختنا المعتمدة من قناة التحديث `github.com/zahmee/update` (التفاصيل في «التحديث الذاتي» أدناه). الفحص التلقائي بعد الدخول ما زال مطفأً؛ الفحص يدوي من زر «Check for upgrades». عند الترقية إلى إصدار رسمي جديد أعد تطبيق هذه القائمة يدوياً.

```
admin "Check for upgrades" / "upgrade now"  ->  gluon/selfupdate.py  ->  github.com/zahmee/update (web2py.zip)
publish a build                              ->  uv run python scripts/publish_update.py
```

---

## سجل الترقيات

### 3.3.3-zahmee.6 — ثلاث ثغرات عالية من الفرع الرئيسي

```
2026-10-18   3.3.3-zahmee.5  ->  3.3.3-zahmee.6
files:   gluon/contrib/multipart.py  gluon/tools.py  gluon/authapi.py  gluon/sqlhtml.py   (no local patches in them)
backup:  D:\web2py\old\backup_3.3.3-zahmee.5_2026-10-18\
report:  D:\web2py\old\post_3.3.3_security_eval_2026-10-18.md   (stage 1 of its merge plan)
```

المرحلة الأولى فقط من خطة الدمج. الباقي من إصلاحات الفرع الرئيسي لم يُدمج بعد، وتفاصيله في التقرير.

### 3.3.3-zahmee.5 — التحديث الذاتي من قناة التحديث

```
2026-10-18   3.3.3-zahmee.4  ->  3.3.3-zahmee.5   (gluon/admin.py, new gluon/selfupdate.py, admin 0.py/default.py/upgrade_web2py.html)
```

استبدال آلية الترقية فقط، ولا تغيير آخر في النواة. التفاصيل في قسم «التحديث الذاتي».

### الترقية إلى الإصدار 3.3.3

```
2026-10-17   3.3.1-zahmee.3  ->  3.3.3-zahmee.4   (local only, servers not yet deployed)
report:  D:\web2py\old\upgrade_3.3.3_report.md
files:   D:\web2py\old\upgrade_3.3.3\files\  +  upgrade.diff
backup:  D:\web2py\old\backup_3.3.1-zahmee.3_2026-10-17\   (gluon, applications\admin, LOCAL_PATCHES.md, README.md)
```

ما تغيّر:

- ملفات الإصدار الرسمي 3.3.3 دُمجت مع كل التعديلات المحلية: إصلاحات أمنية في إعادة التوجيه بعد الدخول، وخداع اسم الخادم، ولوحة قاعدة البيانات، وحدود المسارات في لوحة الإدارة، وقراءة التذاكر والترجمات بأمان، وترميز البريد بالعربية، ومكتبة الواجهة في لوحة الإدارة.
- مكتبة قواعد البيانات المرفقة حُدّثت مع الإبقاء على تعديل الأداء المحلي.
- إصلاح التذاكر مأخوذ من الفرع الرئيسي للمشروع، لأن الإصدار 3.3.3 وحده يخفي كل تذكرة جديدة. تفاصيله أدناه.
- اختبارات الإطار في مجلد الاختبارات حُدّثت إلى نسخة 3.3.3.
- تطبيق الترحيب المحلي لم يُستبدل لأنه نسخة مخصّصة.

تغيير سلوكي يجب الانتباه له: الحقل المرجعي الاختياري الذي يعتمد على المدقّق الافتراضي صار يقبل القيمة الفارغة في النماذج. الحل كتابة المدقّق صراحة على الحقل الذي يجب أن يبقى إلزامياً، ولا يحتاج ترحيلاً.

التحقق بعد التطبيق:

- اختبارات الإطار: 22 وحدة و274 اختباراً، كلها ناجحة على ملفات النواة المثبّتة فعلاً.
- اختبارات تطبيق المختبر: 53 ناجحة.
- كل التطبيقات فُتحت محلياً على منفذ جانبي، صفحتا الرئيسية والدخول مرتين مع الجلسة: كلها سليمة، ولم يتغيّر أي ملف ترحيل لقاعدة البيانات.
- تطبيق واحد أعطى خطأً موجوداً قبل الترقية أيضاً، لأن قاعدته غير موجودة في خادم قاعدة البيانات المحلي:

```
acc: psycopg2.OperationalError: database "acc" does not exist   (same 500 on the old 3.3.1 server)
```

الرجوع إلى النسخة السابقة: أوقف الخادم، ثم انسخ المجلدين والملفين من النسخة الاحتياطية فوق الأصل، ثم شغّل الخادم من جديد:

```
cd /d D:\web2py
robocopy old\backup_3.3.1-zahmee.3_2026-10-17\gluon gluon /MIR /XD __pycache__
robocopy old\backup_3.3.1-zahmee.3_2026-10-17\applications\admin applications\admin /E /XD __pycache__
copy /Y old\backup_3.3.1-zahmee.3_2026-10-17\LOCAL_PATCHES.md LOCAL_PATCHES.md
copy /Y old\backup_3.3.1-zahmee.3_2026-10-17\README.md README.md
```

لم يُنفَّذ بعد، وينتظر موافقة منفصلة:

- النشر على الخوادم بأمر نشر الإطار.
- جعل العميل إلزامياً في سداد العملاء، قبل النشر.
- تحديث نسخ لوحة قاعدة البيانات داخل التطبيقات، بعد ترقية الإطار على كل خادم لأنها تحتاج دالة جديدة.

```
deploy.cmd -Server <ip> -User <user>
asbab5: controllers/customers_api.py:235 + models/db_2_business.py:572 (customers_pay.customers_id)
appadmin.py copies: acc, asbab5, zah, af, af2
```

---

## توافق بايثون 3.13 و 3.14

**الروابط التلقائية**

```
gluon/contrib/autolinks.py
```

الصنف القديم لفتح الروابط حُذف في 3.14، ويستورده ملف الأدوات، فكانت كل صفحة ترجع خطأ 500. منذ 3.3.3 أصلحه الإصدار الرسمي، وبقي تعديلنا الوحيد: مهلة عشر ثوانٍ للطلب حتى لا تعلق الصفحة.

```
upstream: urllib.request.Request(..., headers={"User-Agent": "Mozilla/4.0"})
local:    urllib.request.urlopen(req, timeout=10)
```

**تحويل نصوص التنسيق**

```
gluon/contrib/markmin/markmin2html.py
ast.Str / ast.Num (removed in 3.14)  ->  ast.Constant
```

**تذاكر الأخطاء**

```
gluon/restricted.py
cgitb (removed in 3.13)  ->  internal _CgitbCompat (same scanvars)
```

بدونه تضيع قيم المتغيرات من تذاكر الأخطاء.

---

## إصلاح أمني مأخوذ من الفرع الرئيسي

**قراءة التذاكر بالقارئ الآمن**

```
gluon/restricted.py                          TicketStorage.TICKET_ALLOWED_CLASSES = {"gluon.html": {"XML", "XML_unpickle"}}
applications/admin/controllers/default.py    errors(): safe_load/safe_loads(..., allowed_classes=TicketStorage.TICKET_ALLOWED_CLASSES)
backport of upstream master 9005306c (after 3.3.3, unreleased)
```

الإصدار 3.3.3 يقرأ التذاكر بقارئ آمن لا يسمح بنوع عناصر الصفحة الجاهزة، بينما كل تذكرة فيها لقطة للطلب والاستجابة والجلسة من هذا النوع. النتيجة بدون هذا التعديل: كل تذكرة جديدة تُرفض بصمت وتختفي من صفحة الأخطاء. التعديل يسمح بهذا النوع فقط داخل التذاكر، ويسجّل تحذيراً عند رفض أي نوع آخر.

عند الترقية إلى إصدار رسمي يتضمّن هذا الإصلاح: احذف هذا التعديل، وراجع معه بديل وحدة تتبّع الأخطاء، لأن الإصلاح الرسمي نفسه يستغني عنها.

---

## إصلاح أخطاء

**رسالة الخطأ المترجمة**

```
gluon/http.py
raise HTTP(403, T("..."))
```

النص المترجم كان يُرسل حرفاً حرفاً كنص لا بايتات، فتنقطع الاستجابة وتعلق الصفحة. الإصلاح: النص المترجم وعناصر الصفحة تُحوَّل إلى نص قبل الإرسال.

**فحص الإصدار في لوحة الإدارة**

```
gluon/admin.py
```

فحص الإصدار كان يطبع تتبّع خطأ كاملاً لأن شهادة موقع الإطار منتهية، ودون مهلة؛ ودالة الترقية تستدعي دالة غير معرّفة. الإصلاح: سطر واحد في السجل، ومهلة عشر ثوانٍ، والدالة الصحيحة.

```
web2py.com certificate expired 2026-06-19
upgrade(): urlopen -> urllib.request.urlopen      (since zahmee.5 upgrade() delegates to gluon/selfupdate.py)
```

**المجدول**

```
gluon/scheduler.py
integer_types (undefined)  ->  int
```

**مشغّل اختبارات التوثيق في سطر الأوامر**

```
gluon/shell.py
ClassType (undefined)  ->  isinstance(obj, type)
```

**قراءة معاملات الدوال**

```
gluon/utils.py
get_callable_argspec: inspect.getargspec (removed in 3.11)  ->  inspect.getfullargspec
```

**بوابتا الدفع القديمتان**

```
gluon/contrib/AuthorizeNet.py, gluon/contrib/DowCommerce.py
FancyURLopener (removed in 3.14)  ->  build_opener(ProxyHandler(...)); POST data encoded to bytes
```

كان استيرادهما ينهار، وبيانات الإرسال نص لا بايتات.

**مصحّح الأخطاء في لوحة الإدارة**

```
gluon/contrib/dbg.py
imp (3.12), collections.Callable (3.10), formatargspec/getargspec (3.11)
->  runpy.run_path, callable(), inspect.signature
```

---

## أداء

**استيراد الوحدات من مجلد التطبيق**

```
gluon/custom_import.py
```

استيراد وحدة من مجلد الوحدات كان يمسح كل مسارات البحث في كل طلب قبل الرجوع لمجلد التطبيق. الآن تُحفظ ذاكرة للأسماء غير الموجودة، ويُسجَّل خطأ الوحدة غير الموجودة للاسم نفسه فقط، وتُمسح الذاكرة عند تغيّر مسارات البحث.

**ذاكرة القوالب**

```
gluon/compileapp.py   _cached_view_code
```

التطبيق غير المترجم كان يحلّل القالب مع القالب الأم والملفات المضمّنة ويترجمه في كل طلب، بين 2 و13 مللي ثانية للصفحة. الآن يُحفظ الكود المترجم في الذاكرة مع طابع تعديل كل ملف قرأه المحلّل، ويُعاد بناؤه فور تغيّر أي منها، فالتعديل على القوالب يعمل دون إعادة تشغيل. القوالب التي يكون فيها اسم القالب الأم أو الملف المضمّن تعبيراً لا نصاً حرفياً لا تُحفظ.

**ملف الإعدادات**

```
gluon/contrib/appconfig.py   AppConfig(reload=True)
```

كانت كل التطبيقات تعيد قراءة ملف الإعدادات وتحليله في كل طلب؛ الآن يُعاد فقط عند تغيّر طابع تعديل الملف أو تغيّر الملف المطلوب.

**المدقّقات الافتراضية في مكتبة قواعد البيانات**

```
gluon/packages/pydal/pydal/objects.py   get_default_validator   (pydal 20260313.1)
from . import validators  ->  resolved once into _validators_module
```

الاستيراد كان يُنفَّذ مرة لكل حقل في كل طلب، نحو 500 مرة للطلب؛ الآن مرة واحدة. أُعيد تطبيقه على النسخة الجديدة من المكتبة.

النتيجة، زمن الطلب الكامل لصفحة الدخول على ويندوز بالمللي ثانية:

```
asbab5 20 -> 14,  acc 13 -> 9,  az 53 -> 46,  light 15 -> 11,  alber 14 -> 11
```

ما تبقّى على ويندوز نحو 6 مللي ثانية في فتح ملف الجلسة بعد كتابته، بسبب الفحص الفوري لبرنامج الحماية لمجلد الجلسات، ولا يظهر على لينكس. والباقي زمن النماذج:

```
applications/*/sessions  (Windows Defender real-time scan);  remaining model time mostly in az
```

---

## توافق مع تطبيقات الإصدار الثاني

```
gluon/_compat.py   (new file; removed upstream in 3.x)
```

الإصدار الثالث حذف هذه الوحدة، وكود التطبيقات المكتوب للإصدار الثاني ما زال يستوردها، وأشهره ملف لوحة قاعدة البيانات في كل تطبيق، فكانت اللوحة تنهار على الخوادم القديمة بعد تحديث الإطار. أُعيدت بفرع بايثون 3 من الوحدة القديمة. الإطار نفسه لا يستوردها؛ لا تبنِ عليها كوداً جديداً.

```
from gluon._compat import iteritems, to_bytes, to_native, basestring, with_metaclass, ...
```

---

## لوحة الإدارة

**إيقاف فحص الإصدارات التلقائي**

```
applications/admin/models/0.py   CHECK_VERSION = False
```

زر فحص الترقيات اليدوي باقٍ.

**إعادة تصميم الواجهة**

```
applications/admin/models/buttons.py               (state-on / state-off classes instead of inline colors)
applications/admin/views/layout.html
applications/admin/views/appadmin.html
applications/admin/views/default/design.html
applications/admin/views/default/errors.html
applications/admin/views/default/index.html
applications/admin/views/default/site.html
applications/admin/views/default/ticket.html
applications/admin/static/css/admin.css            (new file, "visual system (zahmee build)")
```

واجهة مخصّصة للوحة الإدارة، لم تكن موثّقة هنا قبل ترقية 3.3.3. عند أي ترقية: لا تستبدل هذه الملفات بالنسخ الرسمية؛ ادمج التغييرات الرسمية فيها يدوياً إن وُجدت. بقية ملفات لوحة الإدارة رسمية، عدا ملف التحكم الرئيسي الذي فيه إصلاح التذاكر أعلاه.

---

## أصبحت في الإصدار الرسمي

```
gluon/fileutils.py   set_session: safe_math_join -> safe_path_join   (official since 3.3.3, issue #2552)
```

كان تعديلاً محلياً يمنع انهيار لوحة قاعدة البيانات لمن سجّل دخول الإدارة. الإصدار الرسمي أصلحه بالطريقة نفسها، فلم يعد تعديلاً محلياً.

---

## البيئة والنشر

```
pyproject.toml + uv.lock + .python-version          uv environment, Python 3.14
start.bat / start.sh                                 run through uv run
deploy.cmd + deploy/windows/deploy.ps1               deploy the framework from Windows to a new or existing server
deploy-app.cmd + deploy/windows/deploy-app.ps1       add an app (and its database on request) to a server
deploy/setup-server.sh + deploy/common.sh            server install/update (keeps HTTPS, service user, admin password)
deploy/install-app.sh + deploy/tools/pack.py         install an app on the server; safe packing of Arabic names
```

البيئة كاملة عبر مدير الحزم، والتشغيل والنشر بأوامر جاهزة. سكربت الخادم يكتشف التثبيت القائم ويحافظ على الشهادة والمستخدم وكلمة الإدارة، ويحفظ نسخة احتياطية من النواة قبل كل تحديث.

---

## التحديث الذاتي من قناة التحديث المعتمدة

```
gluon/selfupdate.py                            (new)  check_new_version(), upgrade(), inspect_archive(), apply_archive()
gluon/admin.py                                  upgrade() -> selfupdate.upgrade()
applications/admin/controllers/default.py       check_version(), upgrade_web2py() -> gluon.selfupdate
applications/admin/models/0.py                  WEB2PY_URL = https://github.com/zahmee/update
applications/admin/views/default/upgrade_web2py.html
scripts/publish_update.py                       (dev tool, not in the deployment base)
```

الدالة الرسمية كانت تنزّل الإطار من الموقع الرسمي عبر اتصال غير مشفّر وتفكّه فوق التثبيت، فتمسح كل تعديلاتنا وتسمح لمن يعترض الاتصال بزرع كود. البديل يتبع اصطلاح التطبيقات الموجودة في المستودع نفسه (`acc.zip` و`acc_ver.txt` و`acc.sha256`):

```
https://github.com/zahmee/update/raw/refs/heads/main/web2py_ver.txt   version (X.Y.Z-zahmee.N+timestamp...)
                                                    web2py.zip       framework + applications/admin + welcome
                                                    web2py.sha256    "<sha256>  web2py.zip"
```

قبل أي كتابة: يقبل فقط نسخة أحدث بالوسم نفسه (الرقم يُقارن كرقم: 10 بعد 9)، ويتحقق من البصمة، ومن كل مسار في الأرشيف، ومن أن ملف الإصدار داخله يطابق الإصدار المعلن، ومن أن كل ملف بايثون في النواة ولوحة الإدارة يُترجم. ثم يحفظ كل ملف سيستبدله في `backups/framework-<stamp>.tar.gz` (المجلد نفسه الذي يستخدمه سكربت الخادم، آخر خمس نسخ)، ويكتب ملفات الإطار وكود لوحة الإدارة، ولا يكتب تطبيق الترحيب إلا إن لم يكن موجوداً، ولا يمس كلمة المرور ولا التطبيقات الأخرى ولا بيانات تشغيل لوحة الإدارة، ولا يحذف شيئاً. إن فشلت أي كتابة أعاد الملفات السابقة. بعده يلزم إعادة تشغيل الخادم، و`uv sync` قبلها إن قالت الرسالة إن المكتبات تغيّرت.

لوحة الإدارة تستدعي الوحدة الجديدة مباشرة (لا عبر `gluon.admin`) لأن الخادم الذي يعمل منذ ما قبل التعديل يحتفظ بالدالة القديمة في الذاكرة حتى يُعاد تشغيله، بينما الوحدة الجديدة تُحمَّل من الملف أول مرة.

النشر: `uv run python scripts/publish_update.py` يحدّث أساس النشر، ويبني الأرشيف بقائمة ملفات `deploy/tools/pack.py framework` نفسها، ويفحصه بفحص الخوادم نفسه، ثم ينسخ الملفات الثلاثة إلى نسخة المستودع المحلية (`D:\update my app`) ويرفعها. يرفض نشر إصدار منشور سابقاً: زِد رقم الوسم أولاً.

---

## إصلاحات أمنية من الفرع الرئيسي

ثمانية تعديلات رسمية بعد 3.3.3 (لم تصدر في إصدار رسمي)، طُبّقت كما هي دون تعارض، والملفات الأربعة لم يكن فيها تعديل محلي. عند الترقية إلى إصدار رسمي يتضمّنها: احذف هذا القسم فقط.

```
8d44736d a0567fab                     gluon/contrib/multipart.py   Content-Type option regex: exponential backtracking (pre-login DoS)
53d3bb16                              gluon/tools.py               Auth.verify_email: refuse reserved keys (/verify_email/disabled re-enabled accounts)
4a8f9b6b                              gluon/authapi.py             AuthAPI.verify_key: same guard
022fcf70 b45ac47e 317a337d dead3b69   gluon/sqlhtml.py             SQLFORM.grid: new/view/edit/delete only on the grid's tables and query; orderby only on its sortable columns
```

تغيّر سلوكي: جدول الشبكة يعيد التوجيه إلى صفحته بدل فتح سجل خارج جدوله أو خارج استعلامه، وترتيب الأعمدة يقبل فقط الأعمدة المعروضة القابلة للترتيب. مسارات الجداول المترابطة المعتادة (الأب، الابن، إضافة، عرض، تعديل) جُرّبت وتعمل.

التحقق:

```
upstream PoC (in-memory):  3 exploits before -> 3 blocked after
gluon tests (3.3.3 + the commits' own tests): test_globals test_tools test_authapi test_sqlhtml   92 passed, 1 skipped
app tests acc/az/zah: 923 passed, 1 failed (az test_without_it_pydal_fails_on_the_self_reference:
                      pydal 20260313.1 from zahmee.4 no longer raises on a lazy self-reference; unrelated)
```
