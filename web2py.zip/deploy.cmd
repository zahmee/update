@echo off
rem Install or update web2py on a Linux server (new or existing) - see README.md.
rem   deploy.cmd                                     asks for the server and the SSH user
rem   deploy.cmd -Server 192.168.20.128 -User zahmee
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\windows\deploy.ps1" %*
if "%~1"=="" pause
