#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Self-update of this web2py build from its approved release channel (local patch, see LOCAL_PATCHES.md).

It replaces gluon.admin.upgrade(), which downloaded the upstream web2py over plain HTTP and unzipped
it over the installation, wiping every local patch. The channel is the zahmee/update repository and
follows the convention of the applications already published there (acc.zip, acc_ver.txt, acc.sha256):

    web2py_ver.txt   the version, e.g. 3.3.3-zahmee.5+timestamp.2026.10.18.19.00.00
    web2py.zip       the framework: gluon/, handlers/, examples/, scripts/, deploy/, the top-level
                     files and applications/admin + applications/welcome (no runtime folders)
    web2py.sha256    "<sha256>  web2py.zip"

They are published with scripts/publish_update.py. An update:

  1. accepts only a newer build of the same tag (zahmee): higher X.Y.Z, then build number, then timestamp;
  2. checks the archive: SHA-256, size, every path (no absolute, "..", drive or backslash paths),
     gluon/version.py carrying exactly the announced version, and that every Python file compiles;
  3. backs up every file it will overwrite to backups/framework-<stamp>.tar.gz (the same folder and
     naming as deploy/setup-server.sh, which keeps the last 5);
  4. writes the framework files and the code of applications/admin; applications/welcome only when
     it is missing; never parameters_*.py, other applications or the runtime folders of admin;
     it deletes nothing;
  5. puts the backed-up files back (and removes the files it created) if any write fails.

web2py must be restarted afterwards, and `uv sync` run first when pyproject.toml or uv.lock changed.
"""

import datetime
import hashlib
import io
import os
import re
import shutil
import tarfile
import tempfile
import urllib.request
import warnings
import zipfile

UPDATE_BASE_URL = "https://github.com/zahmee/update/raw/refs/heads/main/"
VER_FILE = "web2py_ver.txt"
ZIP_FILE = "web2py.zip"
SHA_FILE = "web2py.sha256"
PAGE_URL = "https://github.com/zahmee/update"

MAX_ZIP_SIZE = 100 * 1024 * 1024          # download
MAX_UNPACKED_SIZE = 300 * 1024 * 1024     # all members together
BACKUP_KEEP = 5

TOP_DIRS = {"gluon", "handlers", "examples", "scripts", "deploy"}
TOP_FILES = {"web2py.py", "anyserver.py", "wsgihandler.py", "pyproject.toml", "uv.lock", ".python-version",
             "README.md", "LOCAL_PATCHES.md", "start.sh", "start.bat", "welcome.w2p", "deploy.cmd",
             "deploy-app.cmd"}
APP_RUNTIME_DIRS = {"sessions", "errors", "cache", "databases", "uploads", "private"}
DEPENDENCY_FILES = ("pyproject.toml", "uv.lock", ".python-version")
# Python files that must compile before anything is written (handlers/ still has Python 2 files)
COMPILE_PREFIXES = ("gluon/", "applications/admin/controllers/", "applications/admin/models/",
                    "applications/admin/modules/")
COMPILE_TOP = {"web2py.py", "wsgihandler.py"}

_VERSION_RE = re.compile(r"(\d+)\.(\d+)\.(\d+)-([A-Za-z]+)\.(\d+)\+timestamp\.(\d{4}(?:\.\d{2}){5})")


class UpdateError(Exception):
    pass


def parse_version(text):
    """'3.3.3-zahmee.5+timestamp.2026.10.18.19.00.00' (also inside 'Version ...' or quotes)
    -> (3, 3, 3, 'zahmee', 5, datetime) or None when it is not a build of this kind."""
    if not text or not text.strip():
        return None
    token = text.strip().split()[-1].strip("\"'")
    m = _VERSION_RE.fullmatch(token)
    if not m:
        return None
    a, b, c, tag, n, stamp = m.groups()
    try:
        when = datetime.datetime.strptime(stamp, "%Y.%m.%d.%H.%M.%S")
    except ValueError:
        return None
    return int(a), int(b), int(c), tag, int(n), when


def is_newer(remote, local):
    """True when `remote` is a later build of the same tag as `local` (both version strings).
    The build number is compared as a number: zahmee.10 is newer than zahmee.9."""
    r, l = parse_version(remote), parse_version(local)
    if not r or not l or r[3] != l[3]:
        return False
    return (r[:3] + r[4:]) > (l[:3] + l[4:])


def root_folder(request=None):
    if request is not None and request.env.gluon_parent:
        return request.env.gluon_parent
    from gluon.settings import global_settings
    return global_settings.gluon_parent


def local_version(root, request=None):
    """The version of the files on disk (a running server reports the one it started with)."""
    try:
        with open(os.path.join(root, "gluon", "version.py"), encoding="utf8") as f:
            m = re.search(r'VERSION\s*=\s*"([^"]+)"', f.read())
        if m:
            return m.group(1)
    except OSError:
        pass
    return request.env.web2py_version if request is not None else ""


def _fetch(url, timeout, limit):
    req = urllib.request.Request(url, headers={"User-Agent": "web2py-selfupdate",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise UpdateError("%s is larger than %d MB" % (url, limit // 1048576))
    return data


def remote_version(base_url=UPDATE_BASE_URL, timeout=10):
    text = _fetch(base_url + VER_FILE, timeout, 1024).decode("utf8", "replace").strip()
    if not parse_version(text):
        raise UpdateError("invalid version on the release channel: %r" % text[:80])
    return text


def remote_sha256(base_url=UPDATE_BASE_URL, timeout=15):
    text = _fetch(base_url + SHA_FILE, timeout, 1024).decode("ascii", "replace").strip()
    m = re.match(r"^([0-9a-fA-F]{64})\s+\*?(\S+)$", text)
    if not m or m.group(2) != ZIP_FILE:
        raise UpdateError("invalid checksum file on the release channel")
    return m.group(1).lower()


def check_new_version(request=None, base_url=UPDATE_BASE_URL, root=None):
    """Same contract as gluon.admin.check_new_version: (True, version) when a newer build is
    published, (False, version) when up to date, (-1, local) on error, (-2, local) when offline."""
    root = root or root_folder(request)
    mine = local_version(root, request)
    try:
        theirs = remote_version(base_url)
    except (OSError, UpdateError) as e:
        reason = getattr(e, "reason", None)
        from socket import gaierror
        if isinstance(reason, gaierror):
            print("system is offline, cannot check the release channel")
            return -2, mine
        print("cannot check the release channel: %s" % (reason or e))
        return -1, mine
    return is_newer(theirs, mine), theirs


def _safe_rel(name):
    rel = name
    if "\\" in rel or rel.startswith("/") or ":" in rel.split("/")[0] or "\x00" in rel:
        raise UpdateError("unsafe path in the archive: %r" % name)
    parts = rel.rstrip("/").split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise UpdateError("unsafe path in the archive: %r" % name)
    return "/".join(parts)


def _target(rel, keep_welcome):
    """True when the archive member `rel` belongs to the files an update may write."""
    parts = rel.split("/")
    if len(parts) == 1:
        return rel in TOP_FILES
    if parts[0] in TOP_DIRS:
        return "__pycache__" not in parts and not rel.endswith((".pyc", ".pyo"))
    if parts[0] != "applications":
        return False
    if rel == "applications/__init__.py":
        return True
    if len(parts) < 3 or "__pycache__" in parts:
        return False
    if parts[1] == "admin":
        return parts[2] not in APP_RUNTIME_DIRS
    if parts[1] == "welcome":
        return not keep_welcome and parts[2] not in APP_RUNTIME_DIRS
    return False


def inspect_archive(path, version, sha256=None):
    """Checks a downloaded (or about to be published) web2py.zip; returns the list of its file
    members. Raises UpdateError on any problem."""
    if sha256:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1048576), b""):
                h.update(chunk)
        if h.hexdigest() != sha256:
            raise UpdateError("checksum mismatch: the archive is damaged or was replaced "
                              "(if it was published a few minutes ago, try again later)")
    try:
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile as e:
        raise UpdateError("not a valid zip archive: %s" % e)
    with zf:
        bad = zf.testzip()
        if bad:
            raise UpdateError("corrupt member in the archive: %s" % bad)
        members, total = [], 0
        for info in zf.infolist():
            rel = _safe_rel(info.filename)
            if info.is_dir():
                continue
            total += info.file_size
            if total > MAX_UNPACKED_SIZE:
                raise UpdateError("the archive unpacks to more than %d MB" % (MAX_UNPACKED_SIZE // 1048576))
            members.append((info, rel))
        names = {rel for _, rel in members}
        for required in ("gluon/version.py", "gluon/main.py", "applications/admin/controllers/default.py",
                         "web2py.py"):
            if required not in names:
                raise UpdateError("the archive has no %s" % required)
        found = re.search(r'VERSION\s*=\s*"([^"]+)"', zf.read("gluon/version.py").decode("utf8", "replace"))
        if not found or found.group(1) != version:
            raise UpdateError("the archive carries version %s, the channel announces %s"
                              % (found.group(1) if found else "?", version))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")          # SyntaxWarning of old escape sequences
            for info, rel in members:
                if rel.endswith(".py") and (rel.startswith(COMPILE_PREFIXES) or rel in COMPILE_TOP):
                    try:
                        compile(zf.read(info), rel, "exec")
                    except (SyntaxError, ValueError) as e:
                        raise UpdateError("%s does not compile: %s" % (rel, e))
    return members


def _backup(root, existing, created, old_version, new_version):
    folder = os.path.join(root, "backups")
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(folder, "framework-%s.tar.gz" % stamp)
    with tarfile.open(path, "w:gz", compresslevel=6) as tar:
        for rel in existing:
            tar.add(os.path.join(root, *rel.split("/")), rel, recursive=False)
        note = ("selfupdate %s -> %s\nfiles replaced: %d (in this archive)\nfiles created:\n%s\n"
                % (old_version, new_version, len(existing), "\n".join(created))).encode("utf8")
        info = tarfile.TarInfo(".selfupdate.txt")
        info.size = len(note)
        tar.addfile(info, io.BytesIO(note))
    olds = sorted(f for f in os.listdir(folder) if f.startswith("framework-") and f.endswith(".tar.gz"))
    for f in olds[:-BACKUP_KEEP]:
        os.remove(os.path.join(folder, f))
    return path


def _restore(root, backup, created):
    with tarfile.open(backup) as tar:
        for member in tar.getmembers():
            if member.isfile() and member.name != ".selfupdate.txt":
                data = tar.extractfile(member).read()
                with open(os.path.join(root, *member.name.split("/")), "wb") as f:
                    f.write(data)
    for rel in created:
        path = os.path.join(root, *rel.split("/"))
        if os.path.exists(path):
            os.remove(path)


def apply_archive(root, path, version, sha256=None):
    """Writes a checked web2py.zip into the installation at `root`. Returns a dict with the
    counts, the backup path and whether `uv sync` is needed."""
    members = inspect_archive(path, version, sha256)
    keep_welcome = os.path.isdir(os.path.join(root, "applications", "welcome"))
    plan = [(info, rel) for info, rel in members if _target(rel, keep_welcome)]
    if not plan:
        raise UpdateError("nothing to install from the archive")
    existing, created, unchanged = [], [], 0
    with zipfile.ZipFile(path) as zf:
        changed = []
        for info, rel in plan:
            dst = os.path.join(root, *rel.split("/"))
            data = zf.read(info)
            if os.path.isfile(dst):
                with open(dst, "rb") as f:
                    if f.read() == data:
                        unchanged += 1
                        continue
                if not os.access(dst, os.W_OK):
                    raise UpdateError("no write permission: %s" % dst)
                existing.append(rel)
            elif os.path.exists(dst):
                raise UpdateError("a folder is in the way of %s" % rel)
            else:
                created.append(rel)
            changed.append((rel, data))
        if not changed:
            return dict(written=0, created=0, unchanged=unchanged, backup=None, needs_sync=False)
        old_version = local_version(root)
        deps_before = {f: _read(os.path.join(root, f)) for f in DEPENDENCY_FILES}
        backup = _backup(root, existing, created, old_version, version)
        done = []
        try:
            for rel, data in changed:
                dst = os.path.join(root, *rel.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                tmp = dst + ".selfupdate-tmp"
                with open(tmp, "wb") as f:
                    f.write(data)
                if rel.endswith(".sh") and os.name != "nt":
                    os.chmod(tmp, 0o755)
                os.replace(tmp, dst)
                done.append(rel)
        except Exception as e:
            leftover = dst + ".selfupdate-tmp"
            if os.path.exists(leftover):
                os.remove(leftover)
            _restore(root, backup, [rel for rel in created if rel in done])
            raise UpdateError("writing %s failed (%s); the previous files were put back" % (rel, e))
    deps_after = {f: _read(os.path.join(root, f)) for f in DEPENDENCY_FILES}
    return dict(written=len(existing), created=len(created), unchanged=unchanged, backup=backup,
                needs_sync=deps_before != deps_after)


def _read(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except OSError:
        return None


def upgrade(request=None, base_url=UPDATE_BASE_URL, root=None):
    """Same contract as gluon.admin.upgrade: (True, message) on success, (False, reason)."""
    root = root or root_folder(request)
    lock = os.path.join(root, "backups", ".selfupdate.lock")
    try:
        mine = local_version(root, request)
        if not parse_version(mine):
            return False, "this installation (%s) is not a zahmee build" % mine
        theirs = remote_version(base_url)
        if not is_newer(theirs, mine):
            return False, "Already latest version (%s)" % mine
        sha = remote_sha256(base_url)
        os.makedirs(os.path.dirname(lock), exist_ok=True)
        try:
            os.close(os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
        except FileExistsError:
            return False, "another update is running (or crashed: remove %s)" % lock
        try:
            with tempfile.TemporaryDirectory(prefix="web2py-update-") as tmp:
                path = os.path.join(tmp, ZIP_FILE)
                with open(path, "wb") as f:
                    f.write(_fetch(base_url + ZIP_FILE, 120, MAX_ZIP_SIZE))
                result = apply_archive(root, path, theirs, sha)
        finally:
            os.remove(lock)
    except (OSError, UpdateError) as e:
        return False, str(getattr(e, "reason", None) or e)
    message = "%s -> %s: %d files replaced, %d added" % (mine.split("+")[0], theirs.split("+")[0],
                                                         result["written"], result["created"])
    if result["backup"]:
        message += "; backup: %s" % os.path.relpath(result["backup"], root)
    if result["needs_sync"]:
        message += "; dependencies changed: stop web2py, run `uv sync`, then start it"
    return True, message
