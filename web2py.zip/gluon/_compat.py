#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Local patch (zahmee): compatibility names for application code written for web2py 2.x.

web2py 3 dropped Python 2 and removed this module, but applications created with 2.x still
import from it - typically their copy of controllers/appadmin.py
(``from gluon._compat import iteritems``) - so after a framework upgrade on an old server those
pages failed with "No module named 'gluon._compat'". The names below are the Python 3 branch of
the old module; the framework itself never imports this file.
"""
import builtins
import configparser
import copyreg
import hashlib
import html
import os
import pickle
import queue as Queue
import sys
import _thread as thread
from functools import reduce
from html.parser import HTMLParser
from http import cookiejar as cookielib
from http import cookies as Cookie
from importlib import reload
from io import BytesIO, StringIO
from urllib import parse as urlparse
from urllib import request as urllib2
from urllib.parse import quote as urllib_quote
from urllib.parse import quote_plus as urllib_quote_plus
from urllib.parse import unquote as urllib_unquote
from urllib.parse import unquote_plus as urllib_unquote_plus
from urllib.parse import urlencode
from urllib.request import urlopen

PY2 = False
builtin = builtins
cPickle = pickle
basestring = str
unicodeT = str
text_type = str
unichr = chr
long = int
xrange = range
integer_types = (int,)
string_types = (str,)
ClassType = type
maketrans = str.maketrans
pjoin = os.path.join
exists = os.path.exists


def _identity(x):
    return x


implements_iterator = _identity
implements_bool = _identity


def iterkeys(d):
    return iter(d.keys())


def itervalues(d):
    return iter(d.values())


def iteritems(d):
    return iter(d.items())


def hashlib_md5(s):
    return hashlib.md5(s if isinstance(s, bytes) else str(s).encode("utf8"))


def to_bytes(obj, charset="utf-8", errors="strict"):
    if obj is None:
        return None
    if isinstance(obj, (bytes, bytearray, memoryview)):
        return bytes(obj)
    if isinstance(obj, str):
        return obj.encode(charset, errors)
    raise TypeError("Expected bytes")


def to_native(obj, charset="utf8", errors="strict"):
    if obj is None or isinstance(obj, str):
        return obj
    return obj.decode(charset, errors)


def to_unicode(obj, charset="utf-8", errors="strict"):
    if obj is None:
        return None
    if not hasattr(obj, "decode"):
        return str(obj)
    return obj.decode(charset, errors)


def with_metaclass(meta, *bases):
    """Create a base class with a metaclass (the classic six/web2py helper)."""

    class metaclass(meta):
        __call__ = type.__call__
        __init__ = type.__init__

        def __new__(cls, name, this_bases, d):
            if this_bases is None:
                return type.__new__(cls, name, (), d)
            return meta(name, bases, d)

    return metaclass("temporary_class", None, {})
