# Local build of web2py 3.3.3 customised for zahmee (see LOCAL_PATCHES.md).
# Format required by gluon.fileutils.parse_semantic: X.Y.Z-<tag>+timestamp.YYYY.MM.DD.HH.MM.SS
VERSION = "3.3.3-zahmee.5+timestamp.2026.10.18.18.57.58"
