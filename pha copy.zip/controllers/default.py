# -*- coding: utf-8 -*-
#  type: ignore
import httpx
import pathlib
from datetime import datetime
"""
@can_access(1001)
"""


# ---- example index page ----
def index():
    Headers = {}
    url = "https://raw.githubusercontent.com/zahmee/update/refs/heads/main/pha_ver.txt"
    resp = httpx.get(url, headers=Headers)
    site_ver = float(resp.text)
    app_path = pathlib.Path(__file__).resolve().parent.parent
    local_file = app_path / "pha_ver.txt"
    stats = local_file.stat()
    modification_time = datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
    with open(local_file, "r") as f:
        local_ver = float(f.read())
    # if site_ver > local_ver:
    #     redirect(URL("_t", "up"))
    ck_row = {}
    msg_id = 102
    if auth.is_logged_in():
        if db(db.public_msg.msg_id == msg_id).isempty() == True:
            db.public_msg.insert(
                msg_id=msg_id,
                msg_text="""
       تم اضافة ادخال فترات الشفت
       و تم اضافة مصروفات الصندوق 
                                """,
                msg_count=0,
                msg_max=15,
            )
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
        else:
            ck_row = db(db.public_msg.msg_id == msg_id).select()[0]
            if ck_row.msg_count < ck_row.msg_max:
                ck_row.msg_count = 1 + ck_row.msg_count
                ck_row.update_record()
            else:
                ck_row.msg_text = ""
        db.commit()
    return dict(msg=ck_row , local_ver=local_ver,modification_time=modification_time )


# ---- API (example) -----
@auth.requires_login()
def api_get_user_email():
    if not request.env.request_method == "GET":
        raise HTTP(403)
    return response.json({"status": "success", "email": auth.user.email})


# ---- Smart Grid (example) -----
@auth.requires_membership("admin")  # can only be accessed by members of admin groupd
def grid():
    response.view = "generic.html"  # use a generic view
    tablename = request.args(0)
    if not tablename in db.tables:
        raise HTTP(403)
    grid = SQLFORM.smartgrid(
        db[tablename], args=[tablename], deletable=False, editable=False
    )
    return dict(grid=grid)


# ---- Embedded wiki (example) ----
def wiki():
    auth.wikimenu()  # add the wiki to the menu
    return auth.wiki()


# ---- Action for login/register/etc (required for auth) -----
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


# ---- action to server uploaded static content (required) ---
@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def not_allow():
    return dict()


def about():
    return dict()


def history():
    return dict()
